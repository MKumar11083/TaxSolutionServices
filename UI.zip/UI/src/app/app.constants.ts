import { Injectable } from '@angular/core';

@Injectable()
export class Configuration {
    public Server = 'http://localhost:8080/';
    public ApiUrl = 'cavium/rest/';
    public ServerWithApiUrl = this.Server + this.ApiUrl;
    static readonly DATE_FMT = 'dd/MMM/yyyy';
    static readonly DATE_FMT_ONE = 'dd/MMM/yyyy';
    static readonly DATE_TIME_FMT = `${Configuration.DATE_FMT} hh:mm:ss`;
    static readonly DATE_TIME_FMT_ONE = `${Configuration.DATE_FMT_ONE} hh:mm:ss`;
    static readonly DATE_TIME = `hh:mm:ss`;
    static readonly STD_DATE_FMT = 'dd/MM/yyyy hh:mm:ss';
    static readonly LOCALE ='en';
    public logoutUrl = '';
    static readonly DATE_FMT_2 = 'yyyy-MM-dd hh:mm:ss';
    // Oauth2 Configuration Properties
    public GRANT_TYPE = 'password';
    public CLIENT_ID  = 'cavium-client'
    public CLIENT_SECRET = 'cavium-secret';
}