import { Injectable } from '@angular/core';

@Injectable()
export class AppURL {
    /* Appliance Management*/
    public readonly GET_IN_PROGRESS_ACTIVITIES="inProgressActivityForAppliance";
    public readonly GET_PARTITIONLIST_BY_APPID ="getListOfPartitionsByApplianceID"
   /* Partition Management */
    public readonly GET_LIST_PARTITIONS_URL = 'getListOfPartitions';
    public readonly POST_PARTITION_URL = 'createPartitions';
    public readonly VALIDATE_INIT_OPERATION = 'validateInitOperationForCreatePartition';
    public readonly CLOSE_SESSION_OPERATION_API ='closeSessionForPartition';
    public readonly DELETE_OPERATION_API ='deletePartition';
    public readonly RESET_OPERATION_API = 'resetPartition';
    public readonly CONFIGURE_NETWORK_API = 'setPartitionNetworkConfiguration';
    public readonly START_OR_STOP_API = 'stopStartPartitionCavSever';
    public readonly UPLOAD_CAV_SERVER_FILE_API = 'uploadCavServerConfigFile';
    public readonly DOWNLOAD_CAV_SERVER_FILE_API = 'downloadCavServerConfigFile';
    public readonly RESET_CAV_SERVER_FILE_API = 'resetCavServerConfig';
    public readonly BACKUP_AND_RESTORE_API = 'restorePartition';
    public readonly BACKUP_API = 'backupPartition';
    public readonly GET_LIST_CLUSTERS_URL='listClusters '; 
    
}