import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpModule } from '@angular/http';
import { HttpClientModule, HttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { AppRoutingModule } from './app-routing.module';
import { InlineEditorModule } from '@qontu/ngx-inline-editor';
import { ChartsModule } from 'ng2-charts';
import { NgxPermissionsModule } from 'ngx-permissions';
import { NgxGaugeModule } from 'ngx-gauge';
import { MatButtonModule, MatCheckboxModule, MatTooltipModule, 
  MatRadioModule,MatTabsModule,MatSliderModule } from '@angular/material';
import { TooltipModule } from 'ngx-bootstrap';

import { PopoverModule } from 'ngx-bootstrap';
import { LoadingModule, ANIMATION_TYPES } from 'ngx-loading';
import { ModalModule } from 'ngx-bootstrap/modal';
import { AppComponent } from './app.component';
import { DataTableModule } from './components/secure/data-table/index';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
import { MomentModule } from 'angular2-moment';
import { ProgressbarModule } from 'ngx-bootstrap/progressbar';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { environment } from '../environments/environment'

//custom pipes
import { NotAvailStrPipe } from './pipes/not-avail-str.pipe';
import { JodaTimeFormatPipe } from './pipes/joda-time-format.pipe';
import { DateTimeFormatPipe } from './pipes/date-time-format.pipe';
import { DateFormatPipe } from './pipes/date-format.pipe';
import { MapToIterable } from './pipes/map-to-Iterable';
import { FormatNumberPipe } from './pipes/format-number.pipe';

import { LoginComponent } from './components/public/login/login.component';
import { PublicComponent } from './layout/public/public.component';
import { SecureComponent } from './layout/secure/secure.component';
import { CreateUserComponent } from './components/secure/usermanagement/create-user/create-user.component';
//common
import { AuthGuard } from './../auth/auth.guard';
import { HomeComponent } from './components/secure/home/home.component';
import { Configuration } from './app.constants';
import { FileUploadComponent } from './components/secure/file-upload/file-upload.component'
//import { FileSelectDirective, FileDropDirective, FileUploader } from 'ng2-file-upload/ng2-file-upload';
import { FileUploadModule } from 'ng2-file-upload';
import { FileSelectDirective, FileDropDirective } from 'ng2-file-upload/ng2-file-upload';
//services
import { BreadcrumbComponent } from './components/secure/common/breadcrumb/breadcrumb.component';
import { BreadcrumbService } from './services/common/breadcrumb.service';
import { FieldErrorDisplayComponentComponent } from './components/secure/common/field-error-display-component/field-error-display-component.component';
import { BsDatepickerModule, TimepickerModule } from 'ngx-bootstrap';
import { FieldErrorDisplayService } from './services/common/field-error-display.service';
import { ResourceManagmentValidator } from './validators/resourcemanagment-validator';
import { SelectModule } from './components/secure/angular2-select';
import { I18nService } from './services/common/i18n/i18n.service';
import { LoaderSpinnerComponent } from './components/secure/common/loader-spinner/loader-spinner.component';
import { FontResizePipe } from './pipes/font-resize.pipe';
import { FileService } from './services/common/fileupload.service';
import { DateFormat2Pipe } from './pipes/date-format2.pipe';
import { ManageuserComponent } from './components/secure/usermanagement/manageuser/manageuser.component';
import { AppHeaderComponent } from './layout/secure/app-header/app-header.component';
import { AppFooterComponent } from './layout/secure/app-footer/app-footer.component';
import { AppLeftmenuComponent } from './layout/secure/app-leftmenu/app-leftmenu.component';
import { UserManagementService } from './services/usermanagement.service';
import { DashboardService } from './services/dashboard.service';
import { HttpServices } from './services/common/http.services';
import { UserGroupManagementService } from './services/common/user-group-management.service';
import { ManagegroupComponent } from './components/secure/usermanagement/managegroup/managegroup.component';
import { CreategroupComponent } from './components/secure/usermanagement/creategroup/creategroup.component';
import { ModifyuserComponent } from './components/secure/usermanagement/modifyuser/modifyuser.component';
import { ManageAclComponent } from './components/secure/usermanagement/manage-acl/manage-acl.component';
import { CreateAclComponent } from './components/secure/usermanagement/create-acl/create-acl.component';
import { ModifygroupComponent } from './components/secure/usermanagement/modifygroup/modifygroup.component';
import { LoginService } from './../app/services/login.service';
import { ListApplianceComponent } from './components/secure/appliancemanagement/list-appliance/list-appliance.component';
import { AddApplianceComponent } from './components/secure/appliancemanagement/add-appliance/add-appliance.component';
import { AddByDiscoveryComponent } from './components/secure/appliancemanagement/add-by-discovery/add-by-discovery.component';
import { SnapshotComponent } from './components/secure/appliancemanagement/snapshot/snapshot.component';
import { AppliancemanagementService } from './services/appliancemanagement.service';
import { AddApplianceService } from './services/addAppliance.service';
import { CompareAppliancesComponent } from './components/secure/appliancemanagement/compare-appliances/compare-appliances.component';
import { HostVmComponent } from './components/secure/appliancemanagement/host-vm/host-vm.component';
import { ChangepasswordComponent } from './components/secure/changepassword/changepassword.component'
import { CommonServices } from './services/common/common.services';
import { AdminVmComponent } from './components/secure/appliancemanagement/admin-vm/admin-vm.component';
import { InitializeApplianceComponent } from './components/secure/appliancemanagement/initialize-appliance/initialize-appliance.component';
import { ApplianceLoginComponent } from './components/secure/appliancemanagement/appliance-login/appliance-login.component';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { ApplianceOperationsComponent } from './components/secure/appliancemanagement/appliance-operations/appliance-operations.component'
import { PartitionmanagementComponent } from './components/secure/partitionmanagement/partitionmanagement.component';
import { PartitionappliancelistComponent } from './components/secure/partitionmanagement/partitionappliancelist/partitionappliancelist.component';
import { CreatenewpartitionComponent } from './components/secure/partitionmanagement/createnewpartition/createnewpartition.component';
import { PartitionhostvmComponent } from './components/secure/partitionmanagement/partitionhostvm/partitionhostvm.component';
import { PartitionManagementService } from './services/partitionmanagement/partitionmanagement.service';
import { AppURL } from './app.url';
import { FirmwareUpgradeApplianceComponent } from './components/secure/appliancemanagement/firmware-upgrade-appliance/firmware-upgrade-appliance.component';
import { PartitionLoginComponent } from './components/secure/partitionmanagement/partition-login/partition-login.component'
import { PartitionOperationsComponent } from './components/secure/partitionmanagement/partition-operations/partition-operations.component';
import { PartitionSnapshotComponent } from './components/secure/partitionmanagement/partition-snapshot/partition-snapshot.component';
import { ClusterListComponent } from './components/secure/clustermanagement/cluster-list/cluster-list.component';
import { ClusterInfoComponent } from './components/secure/clustermanagement/cluster-info/cluster-info.component';
import { ConfigureNetworkComponent } from './components/secure/partitionmanagement/configure-network/configure-network.component';
import { UploadConfigComponent } from './components/secure/partitionmanagement/cavserver/upload-config/upload-config.component';
import { ForgotPasswordComponent } from './components/public/forgot-password/forgot-password.component';
import { BackupRestoreComponent } from './components/secure/partitionmanagement/backup-restore/backup-restore.component';
import { PartitionBackupComponent } from './components/secure/partitionmanagement/partition-backup/partition-backup.component';
import { ZeroizeApplianceComponent} from './components/secure/appliancemanagement/zeroize-appliance/zeroize-appliance.component';
import { UploadcertificateComponent} from './components/secure/appliancemanagement/uploadcertificate/uploadcertificate.component';
import { DownloadcertificateComponent} from  './components/secure/appliancemanagement/downloadcertificate/downloadcertificate.component';
import { CreateClusterComponent } from './components/secure/clustermanagement/create-cluster/create-cluster.component';
import { LslogsApplianceComponent } from './components/secure/appliancemanagement/lslogs-appliance/lslogs-appliance.component';
import { ConfigurelogsApplianceComponent } from './components/secure/appliancemanagement/configurelogs-appliance/configurelogs-appliance.component';
import { MonitorComponent } from './components/secure/appliancemanagement/monitor/monitor.component';
import { ClustermanagementService } from './services/clustermanagement.service';
import { PartitionResizeComponent} from './components/secure/partitionmanagement/partition-resize/partition-resize.component';
import { ChangepassApplianceComponent} from './components/secure/appliancemanagement/changepass-appliance/changepass-appliance.component';
import { SnmpConfigureComponent } from './components/secure/appliancemanagement/snmp-configure/snmp-configure.component';
import { UploadMcokeyComponent} from './components/secure/appliancemanagement/upload-mcokey/upload-mcokey.component';
import { FilterdataPipe } from './components/secure/appliancemanagement/list-appliance/filterdata.pipe';
import { PartitionSelftestreportComponent } from './components/secure/partitionmanagement/partition-selftestreport/partition-selftestreport.component';
import { AdminvmmonitorComponent } from './components/secure/appliancemanagement/adminvmmonitor/adminvmmonitor.component';
import { MonitorConfigComponent } from './components/secure/partitionmanagement/monitor-config/monitor-config.component';
import { MonitorStatsComponent } from './components/secure/partitionmanagement/monitor-stats/monitor-stats.component';
export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, environment.i18NUrl, environment.format);
  //return new TranslateHttpLoader(http);
}

@NgModule({
  declarations: [
    AppComponent,
    NotAvailStrPipe,
    LoginComponent,
    PublicComponent,
    SecureComponent,
    HomeComponent,
    BreadcrumbComponent,
    FieldErrorDisplayComponentComponent,
    ResourceManagmentValidator,
    DateTimeFormatPipe,
    FileUploadComponent,
    LoaderSpinnerComponent,
    JodaTimeFormatPipe,
    DateFormatPipe,
    MapToIterable,
    FormatNumberPipe,
    FontResizePipe,
    DateFormat2Pipe,
    ManageuserComponent,
    AppHeaderComponent,
    AppFooterComponent,
    AppLeftmenuComponent,
    CreateUserComponent,
    ManagegroupComponent,
    CreategroupComponent,
    ModifyuserComponent,
    ManageAclComponent,
    CreateAclComponent, ModifygroupComponent,
    ListApplianceComponent,
    AddApplianceComponent,
    AddByDiscoveryComponent,
    SnapshotComponent,
    CompareAppliancesComponent,
    HostVmComponent,
    ChangepasswordComponent,
    AdminVmComponent,
    InitializeApplianceComponent,
    ApplianceLoginComponent,
    ApplianceOperationsComponent,
    PartitionmanagementComponent,
    PartitionappliancelistComponent,
    CreatenewpartitionComponent,
    PartitionhostvmComponent,
    FirmwareUpgradeApplianceComponent,
    ConfigureNetworkComponent,
    PartitionLoginComponent,
    PartitionOperationsComponent,
    PartitionSnapshotComponent,
    ClusterListComponent,
    ClusterInfoComponent,
    UploadConfigComponent,
    ForgotPasswordComponent,
    BackupRestoreComponent,
    PartitionBackupComponent,
    ZeroizeApplianceComponent,UploadcertificateComponent,DownloadcertificateComponent,
    CreateClusterComponent,LslogsApplianceComponent,ConfigurelogsApplianceComponent, MonitorComponent,
    PartitionResizeComponent,ChangepassApplianceComponent, SnmpConfigureComponent,UploadMcokeyComponent,
    FilterdataPipe,PartitionSelftestreportComponent, AdminvmmonitorComponent, MonitorConfigComponent, MonitorStatsComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
  imports: [
    BrowserModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    HttpClientModule,
    ChartsModule,
    NgxGaugeModule,
    LoadingModule.forRoot({
      animationType: ANIMATION_TYPES.circleSwish,
      backdropBackgroundColour: 'rgba(0,0,0,0.4)',
      backdropBorderRadius: '4px',
      primaryColour: '#ffffff',
      secondaryColour: '#ffffff',
      tertiaryColour: '#ffffff'
    }),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    }),
    AppRoutingModule,
    DataTableModule,
    SelectModule,
    InlineEditorModule,
    BsDatepickerModule.forRoot(),
    TimepickerModule.forRoot(),
    NgxPermissionsModule.forRoot(),
    MatButtonModule, MatCheckboxModule, MatTooltipModule,
    MomentModule,
    NgIdleKeepaliveModule.forRoot(),
    TooltipModule.forRoot(),
    //Ng4LoadingSpinnerModule.forRoot(),
    PopoverModule.forRoot(),
    ModalModule.forRoot(),
    TabsModule.forRoot(),
    ProgressbarModule.forRoot(),
    BrowserAnimationsModule,
    FileUploadModule,
    MatRadioModule,MatTabsModule,MatSliderModule
  ],
  providers: [Configuration, AuthGuard,
    BreadcrumbService,
    FieldErrorDisplayService,
    CommonServices,
    I18nService,
    LoginService,
    FileUploadComponent, FileService, UserManagementService, DashboardService,
    HttpServices, UserGroupManagementService,
    AppliancemanagementService, AddApplianceService, PartitionManagementService, AppURL,
    ClustermanagementService

  ],
  bootstrap: [AppComponent],
  exports: [MatButtonModule, MatCheckboxModule, MatTooltipModule],
})
export class AppModule { }
