import { Pipe, PipeTransform } from '@angular/core';
import { Configuration } from '../app.constants'

/**
 * @whatItDoes Formats a number according to locale passed or configured in app.constants.
 * @howToUse `number_expression | formatNumber[:locale]`
 *
 * Formats a number as a locale-specific seperators. 
 * where `expression` is a number:
 * - `locale` is a `string` defining the locale to use. 
 */
@Pipe({
  name: 'formatNumber'
})
export class FormatNumberPipe implements PipeTransform {

  transform(value: any, locale?: string): any {
    locale = locale || Configuration.LOCALE;
    let formattted = value;
    if(locale){
      if(typeof value == 'number'){
        formattted = value.toLocaleString(locale);
      }else if(typeof value == 'string'){
        formattted = Number(value).toLocaleString(locale);
      }else{
        formattted = value
      }
    }
    return formattted;
  }
}
