import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './../../components/public/login/login.component';
import { ForgotPasswordComponent } from './../../components/public/forgot-password/forgot-password.component'

export const PUBLIC_ROUTES : Routes = [
    {path:'', redirectTo:'login', pathMatch:'full'},
    {path:'login', component:LoginComponent},
    {path:'forgotPassword', component:ForgotPasswordComponent}
]