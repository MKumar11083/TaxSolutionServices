import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './../../../auth/auth.guard';
import { HomeComponent } from './../../components/secure/home/home.component';
import { ManageuserComponent} from './../../components/secure/usermanagement/manageuser/manageuser.component';
import {CreateUserComponent} from './../../components/secure/usermanagement/create-user/create-user.component';
import {ManagegroupComponent} from './../../components/secure/usermanagement/managegroup/managegroup.component';
import {CreategroupComponent} from './../../components/secure/usermanagement/creategroup/creategroup.component'; 
import {ModifyuserComponent}from './../../components/secure/usermanagement/modifyuser/modifyuser.component';
import {ManageAclComponent} from './../../components/secure/usermanagement/manage-acl/manage-acl.component';
import {ModifygroupComponent} from './../../components/secure/usermanagement/modifygroup/modifygroup.component';
import {ListApplianceComponent} from './../../components/secure/appliancemanagement/list-appliance/list-appliance.component';
import {SnapshotComponent} from './../../components/secure/appliancemanagement/snapshot/snapshot.component';
import {AddApplianceComponent} from './../../components/secure/appliancemanagement/add-appliance/add-appliance.component';
import {AddByDiscoveryComponent} from './../../components/secure/appliancemanagement/add-by-discovery/add-by-discovery.component';
import {CompareAppliancesComponent } from './../../components/secure/appliancemanagement/compare-appliances/compare-appliances.component';
import {HostVmComponent} from './../../components/secure/appliancemanagement/host-vm/host-vm.component';
import {ChangepasswordComponent} from './../../components/secure/changepassword/changepassword.component';
import {PartitionmanagementComponent} from './../../components/secure/partitionmanagement/partitionmanagement.component';
import {PartitionappliancelistComponent} from './../../components/secure/partitionmanagement/partitionappliancelist/partitionappliancelist.component';
import {CreatenewpartitionComponent} from './../../components/secure/partitionmanagement/createnewpartition/createnewpartition.component';
import {PartitionhostvmComponent} from './../../components/secure/partitionmanagement/partitionhostvm/partitionhostvm.component'; 
import {PartitionSnapshotComponent} from './../../components/secure/partitionmanagement/partition-snapshot/partition-snapshot.component';
import {ClusterListComponent} from './../../components/secure/clustermanagement/cluster-list/cluster-list.component';
import {ClusterInfoComponent} from './../../components/secure/clustermanagement/cluster-info/cluster-info.component';

export const SECURE_ROUTES : Routes =[
    {path : 'dashboard', component: HomeComponent, canActivate : [AuthGuard] },
    {path : 'manageuserlist', component: ManageuserComponent, canActivate : [AuthGuard] },
    {path : 'createUser', component: CreateUserComponent, canActivate : [AuthGuard] },
    {path : 'managegrouplist', component: ManagegroupComponent, canActivate : [AuthGuard] },
    {path : 'createGroup', component: CreategroupComponent, canActivate : [AuthGuard] },
    {path : 'modifyUser', component: ModifyuserComponent, canActivate : [AuthGuard] },
    {path: 'manageUser/:userID', component: ManageuserComponent,canActivate :[AuthGuard]},
    {path : 'manageACLlist', component: ManageAclComponent, canActivate : [AuthGuard] },
    {path : 'modifygroup', component: ModifygroupComponent, canActivate : [AuthGuard] },
    {path : 'snapshot', component: SnapshotComponent, canActivate : [AuthGuard] },
    {path : 'listAppliance', component: ListApplianceComponent, canActivate : [AuthGuard] },
    {path : 'addAppliance', component: AddApplianceComponent, canActivate : [AuthGuard] },
    {path : 'addAppliance/:ip', component: AddApplianceComponent, canActivate : [AuthGuard] },
    {path : 'goToDiscovery', component: AddByDiscoveryComponent, canActivate : [AuthGuard] },
    {path : 'compareAppliances', component: CompareAppliancesComponent, canActivate : [AuthGuard] },
    {path : 'hostAdminVM/:applianceId/:applianceName/:ip', component:HostVmComponent, canActivate : [AuthGuard] },
    {path : 'changePassword', component:ChangepasswordComponent, canActivate : [AuthGuard] },
    {path : 'partitionSnapshot', component:PartitionSnapshotComponent, canActivate : [AuthGuard] },
    {path : 'listPartition', component:PartitionmanagementComponent, canActivate : [AuthGuard] },
    {path : 'createPartition', component:PartitionappliancelistComponent, canActivate : [AuthGuard] },
    // {path : 'CreateNewPartition', component: CreatenewpartitionComponent, canActivate : [AuthGuard] },
    {path : 'Partitionhostvm/:partitionId/:partitionName/:appId/:appName/:ip', component: PartitionhostvmComponent, canActivate : [AuthGuard] }, 
    {path : 'listCluster', component:ClusterListComponent, canActivate : [AuthGuard] },
    {path : 'clusterInfo/:clusterId/:clusterName', component:ClusterInfoComponent, canActivate : [AuthGuard] },
]