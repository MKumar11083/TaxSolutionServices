import { Component, OnInit, OnDestroy } from '@angular/core';
import { Configuration } from '../../app.constants';
import { NgxPermissionsService } from 'ngx-permissions';
import { LoginService } from './../../services/login.service';
import { Router } from '@angular/router';
import { Cookie } from 'ng2-cookies';
import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { Keepalive } from '@ng-idle/keepalive';
import { CommonServices} from './../../services/common/common.services';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, FormControl } from '@angular/forms';
import { FieldErrorDisplayService } from './../../services/common/field-error-display.service';
import { AnonymousSubscription } from "rxjs/Subscription";
import { UserManagementService } from './../../services/usermanagement.service';

declare var $: any;
declare var jQuery: any;
@Component({
  selector: 'app-secure',
  templateUrl: './secure.component.html',
  styleUrls: ['./secure.component.css']
})
export class SecureComponent implements OnInit {
  errorMsg: string;
  idleState = '';
  timedOut = false;
  lastPing?: Date = null;
  form: FormGroup;
  successMessage: string;
  errorMessages: any = [];
  changePasswordSubsc: AnonymousSubscription;
  constructor(private permissionsService: NgxPermissionsService,
    private _loginService: LoginService,
    private _router: Router,
    private idle: Idle, private keepalive: Keepalive,
    private _commonServices: CommonServices,
    private _fieldErrorDisplayService:FieldErrorDisplayService,
    private builder: FormBuilder,
    private _userManagementService: UserManagementService
  ) {

    // sets an idle timeout of 5 seconds, for testing purposes.

    idle.setIdle(900);
    // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
    idle.setTimeout(15);
    // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
    idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

     idle.onIdleEnd.subscribe(() => this.idleState = '');
    idle.onTimeout.subscribe(() => {
      this.idleState = 'Timed out!';
      this.timedOut = true;
      console.log("Session Time Out....");

    });
     idle.onIdleStart.subscribe(() => this.idleState = '');
    idle.onTimeoutWarning.subscribe((countdown) => {
      $("#sessionTimeout").modal("show");
      this.idleState = 'Your Session Time Out will be in ' + countdown + ' seconds!. Please Click on Continue to avoid Session Time Out ';
   if(countdown==1){
    $("#sessionTimeout").modal("hide");
    this._commonServices.clearSession();
    this._router.navigate(['/login']);
     window.location.reload();
   }
    }
    );

    // sets the ping interval to 15 seconds
    keepalive.interval(15);
    keepalive.onPing.subscribe(() => this.lastPing = new Date());
    this.reset();
  }

  

  ngOnInit() {
    $('body').resize();
    this.checkpassword();
    this._loginService.getUserRoles().subscribe(
      response => {
        console.log(response);
        this.checkUserRolesOrStatus(response);
      },
      error => {
        console.log(error);
      }
    );
  }
  reset() {
    
    
    this.idle.watch();
    this.idleState = '';
    this.timedOut = false;
    $("#sessionTimeout").modal("hide");
  }

  goToLogin() {
    this.idle.stop();
    this.idle.ngOnDestroy(); //includes this.idle.stop() and this.clearInterrupts() both.
    this.reset();
    $("#sessionTimeout").modal("hide");
    this._commonServices.clearSession();
    this._router.navigate(['/login']);
  }

  /* This method is to load the roles of the logged in user*/
  checkUserRolesOrStatus(response) {
    const notActiveUser = "You are not a active User";
    const notPartOfGroup = "You are not a part of any Group"
    if (response.groupId != null) {
      /* If status is "SUSPENDED" ,user will not able to login*/
      if (response.status == "SUSPENDED") {
        this.failToLogin(notActiveUser);
        this._router.navigate(['/login']);
      } else {
        this.permissionsService.loadPermissions(response.roles);
        //sessionStorage.setItem("username",response.firstname);
      }
      // If user try to login first time , then tempPassword wil be "Y" value and 
      // redirects to change password screen
      if(response.tempPassowrd=="Y"){
        $("#changePassword").modal("show");
        //this._router.navigate(['/changePassword']);
      }
    } else {
      this.failToLogin(notPartOfGroup);
      this._router.navigate(['/login']);
    }
  }

  failToLogin(errorMessage) {
    this._commonServices.clearSession();
    this.errorMsg = errorMessage;
    sessionStorage.setItem("errorMsg",errorMessage);
  }

  checkpassword() {
    this.form = this.builder.group({
      oldPassword: ['', Validators.required],
      newPassword: ['', Validators.required],
      ConfirmPassword: ['', Validators.required],

    });
  }
  checkIfMatchingPasswords() {
    let newPassword = this.form.get("newPassword").value;
    let ConfirmPassword = this.form.get("ConfirmPassword").value;
    if (newPassword !== ConfirmPassword) {
      return false;
    }
    else {
      return true;
    }
  }
  onSubmit(isValid: boolean) {
    debugger;
    if (isValid) {
      let checksamePassword = this.checkIfMatchingPasswords();
      if (checksamePassword) {
        this.changePasswordSubsc = this._userManagementService.changePassword(this.form.value).subscribe(
          data => this.onSuccessOperation(data),
          err => this.onErrorOperation(err)
        );
      }
      else {
        this.errorMessages.push("New Password and Confirm Password should be same");
      }

    }else {
      this.formValidationFields = this._fieldErrorDisplayService.validateForm(this.form, this.formValidationFields, "changepassword", false)
    }
  }
  onSuccessOperation(response) {
    this.successMessage = "";
    this.errorMessages = [];
    let res = response;
    if (res.responseCode == "200") {
     // this.successMessage = res.responseMessage;
     this._commonServices.clearSession();
     sessionStorage.setItem("msg",res.responseMessage);
     $("#changePassword").modal("hide");
     this._router.navigateByUrl("/login");
    } else if (res.responseCode == "409" || res.responseCode == "-230") {
      this.errorMessages.push(res.responseMessage);
    } else if (res.responseCode == "500") {
      this.errorMessages.push(res.responseMessage);
    } else {
      this.errorMessages.push(res.responseMessage);
    }
  }
  onErrorOperation(errResp) {

  }
  reset1() {
    this.form.reset();
    this.successMessage = "";
    this.errorMessages = [];
  }
  public formValidationFields = {
    "oldPassword": '',
    "newPassword": '',
    "ConfirmPassword": '',

  }
  isFieldValid(field: string) {
    if (this.form.get(field).touched) {
      this.formValidationFields = this._fieldErrorDisplayService.validateField(this.form, field, this.formValidationFields, "changepassword")
    }
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }
  closeMessage(){
    this.successMessage = "";
    this.errorMessages = [];
  }

  redirectToLogin(){
    $("#changePassword").modal("hide");
    this._commonServices.clearSession();
    this._router.navigate(['/login']);
  }
}
