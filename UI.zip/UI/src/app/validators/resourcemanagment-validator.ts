import { Directive } from '@angular/core'; //  Will import the angular core features. Required for all components , modules, etc...
import { NG_VALIDATORS, FormControl, FormGroup, Validator, ValidationErrors, ValidatorFn } from '@angular/forms'; // Will import the angular forms
import { AbstractControl } from '@angular/forms';


@Directive({
    selector: '[age-validate]',
    providers: [{ provide: NG_VALIDATORS, useExisting: ResourceManagmentValidator, multi: true }]
})
export class ResourceManagmentValidator {


    static greaterthancheck(control: AbstractControl){
       const group = control.parent;
       if (group) {    
         var startRangeNumber = parseInt (group.controls['startRangeNumber'].value); 
         var endRangeNumber= parseInt(control.value);     
          if( endRangeNumber < startRangeNumber) {           
              return {greaterthan: true};
          }
       }    
   }


    static validateImsiStartRange(msisdnRange: string): ValidatorFn {
        return (control: AbstractControl): { [key: string]: any } => {
            const group = control.parent;
            if (group) {
                if (msisdnRange != null) {
                    var result = msisdnRange.split("-");
                    var assignedStartRangeNumber = parseInt(result[0]);
                    var assignedEndRangeNumber = parseInt(result[1]);
                    let temp = group.controls['startRangeNumber'].value;
                    if (temp == null || temp == '' || temp == undefined) {
                        return { required: true };
                    } else if (isNaN(temp)) {
                        return { pattern: true };
                    } else {
                        var startRangeNumber = parseInt(temp);
                        var endRangeNumber = parseInt(group.controls['endRangeNumber'].value);

                        if (Number(startRangeNumber) >= Number(assignedStartRangeNumber) && Number(startRangeNumber) <= Number(assignedEndRangeNumber)) {

                        } else {

                            return { imsistartrange: true };
                        }
                    }

                }
            }
        }

    }


    static validateImsiEndRange(msisdnRange: string): ValidatorFn {
        return (control: AbstractControl): { [key: string]: any } => {
            const group = control.parent;
            if (group) {
                if (msisdnRange != null) {
                    var result = msisdnRange.split("-");
                    var assignedStartRangeNumber = parseInt(result[0]);
                    var assignedEndRangeNumber = parseInt(result[1]);
                    var startRangeNumber = parseInt(group.controls['startRangeNumber'].value);
                    let temp = group.controls['endRangeNumber'].value;
                    if (temp == null || temp == '' || temp == undefined) {
                        return { required: true };
                    } else if (isNaN(temp)) {
                        return { pattern: true };
                    } else {
                        var endRangeNumber = parseInt(temp);
                        if (endRangeNumber < startRangeNumber) {
                            return { greaterthan: true };
                        }

                        if (Number(endRangeNumber) >= Number(assignedStartRangeNumber) && Number(endRangeNumber) <= Number(assignedEndRangeNumber)) {

                        } else {

                            return { imsiendrange: true };
                        }
                    }


                }
            }
        }

    }



    static validateNetmask(control: AbstractControl){
        const group = control.parent;
        if (group) {    
          let netmask = group.controls['netmask'].value; 
          let cidrNotation = group.controls['cidrNotation'].value;
          if (netmask == null || netmask == '' || netmask == undefined) {
              if(cidrNotation==null || cidrNotation =='' || cidrNotation ==undefined){
                return { required: true };
              }
           
        }           
        }    
    }


    static validateCidr(control: AbstractControl){
        const group = control.parent;
        if (group) {    
          let netmask = group.controls['netmask'].value; 
          let cidrNotation = group.controls['cidrNotation'].value;
        
              if(cidrNotation==null || cidrNotation =='' || cidrNotation ==undefined){

                if (netmask == null || netmask == '' || netmask == undefined) {

                return { required: true };
                }
              }
           
                 
        }    
    }


    static validateInclusionPattern(columnValue:string,headerValue: string): ValidatorFn {
        return (control: AbstractControl): { [key: string]: any } => {
            const group = control.parent;
            if (group) {              
                let dynamicColumnValue = group.controls[columnValue].value;
                var regx = /[Xx0-9\]\[,-]+$/g;
                var regx1 = /[!@#\$%\^\&*\)\(+=._\}\{]/;

                if(!regx.test(dynamicColumnValue)){                   
					return { inclusionpattern : true } ;
                }               
              
                if(regx1.test(dynamicColumnValue)){                     
                        return { inclusionpattern : true } ;
                }

                var parts = dynamicColumnValue.split(/[[\]]{1,2}/).filter(Boolean).length;
                var size = parseInt(headerValue);


            //  start


            if(parts !== size){
                if(parts === 1){
                    var dataSize = 0;
                    if(dynamicColumnValue.indexOf("-")>0){
                        if(dynamicColumnValue.length > 3){
                            var expr = /[-,]/;
                            if(expr.test(dynamicColumnValue)){
                               // bootbox.alert(headerName+" "+"<fmt:message key="iccid.error.in.pattren.js"/>");
                               return { inclusionpattern : true } ;
                            }
                        }else{
                            dataSize = dataSize + 1;
                        }
                    }else if(dynamicColumnValue.indexOf(",")>0){
                        var d1 = dynamicColumnValue.split(/[[\]]{1,2}/).filter(Boolean)[0].split(",");
                        for(var n = 0; n <= (d1.length -1); n++){
                            if(d1[n].length > 1){
                              //  bootbox.alert(headerName+" "+"<fmt:message key="iccid.error.in.pattren.js"/>");
                              return { inclusionpattern : true } ;
                            }
                        }
                        dataSize = dataSize + 1;
                    }else{
                        dataSize = dataSize + dynamicColumnValue.length;
                    }
                    if(size !== dataSize){
                      //  bootbox.alert(headerName+" "+" <fmt:message key="iccid.invalid.length"/>" +" "+headerName);
                      return { templatelength : true } ;
                    }
                }else{
                    var data = dynamicColumnValue.split(/[[\]]{1,2}/).filter(Boolean);
                    var dataSize = 0;
                    for(var k = 0; k <= (data.length-1) ; k++ ){
                        var item = data[k];
                        if(item !== "" || item === null){
                            if(item.indexOf("-")>0){
                                var eachChar = item.split('-');
                                for(var j = 0; j <= eachChar.length -1 ; j++){
                                    if(eachChar[j].length > 1){
                                     //   bootbox.alert(headerName+" "+"<fmt:message key="iccid.error.in.pattren.js"/>");
                                     return { inclusionpattern : true } ;
                                    }
                                }
                                dataSize = dataSize + 1;
                            }else if(item.indexOf(",")>0){
                                var eachChar = item.split(',');
                                for(var j = 0; j <= eachChar.length -1 ; j++){
                                    if(eachChar[j].length > 1){
                                       // bootbox.alert(headerName+" "+"<fmt:message key="iccid.error.in.pattren.js"/>");
                                       return { inclusionpattern : true } ;
                                    }
                                }
                                dataSize = dataSize + 1;
                            }else{
                                dataSize = dataSize + item.length;
                            }
                        }
                    }
                    if(size !== dataSize){
                       // bootbox.alert(headerName+" "+"<fmt:message key="iccid.invalid.length"/>"+" "+headerName);
                       return { templatelength : true } ;
                    }
                }
            } else{
                var data = dynamicColumnValue.split(/[[\]]{1,2}/).filter(Boolean);
                var dataSize = 0;
                for(var k = 0; k <= (data.length-1) ; k++ ){
                    var item = data[k];
                    if(item !== "" || item === null){
                        if(item.indexOf("-")>0){
                            var eachChar = item.split('-');
                            for(var j = 0; j <= eachChar.length -1 ; j++){
                                if(eachChar[j].length > 1){
                                  //  bootbox.alert(headerName+" "+"<fmt:message key="iccid.error.in.pattren.js"/>");
                                  return { inclusionpattern : true } ;
                                }
                            }
                            dataSize = dataSize + 1;
                        }else if(item.indexOf(",")>0){
                            var eachChar = item.split(',');
                            for(var j = 0; j <= eachChar.length -1 ; j++){
                                if(eachChar[j].length > 1){
                                  //  bootbox.alert(headerName+" "+"<fmt:message key="iccid.error.in.pattren.js"/>");
                                  return { inclusionpattern : true } ;
                                }
                            }
                            dataSize = dataSize + 1;
                        }else{
                            dataSize = dataSize + item.length;
                        }
                    }
                }
                if(size !== dataSize){
                   // bootbox.alert(headerName+" "+"<fmt:message key="iccid.invalid.length"/>"+" "+headerName);
                   return { templatelength : true } ;
                }
            }


            // end 





             
            }
        }

    }


}
