import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import { Configuration } from '../../app.constants';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';

@Injectable()
export class FileService {
    _baseURL: string ; 
    constructor(private http: Http,private _configuration: Configuration) {
        //this._baseURL = _configuration.ServerWithApiUrl;
     }

    upload(files){
        
        let headers = new Headers();
        let options = new RequestOptions({ headers: headers });
        return  this.http.post(this._baseURL + 'deploymentPlan/uploadFile', files, options)
        .map(res => JSON.stringify(res))
        .catch(this.errorHandler);

    }
    errorHandler(error:any){
        console.log(error);
        return Observable.throw(error);
    }
}