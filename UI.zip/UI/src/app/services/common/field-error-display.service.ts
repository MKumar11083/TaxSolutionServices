import { Injectable } from '@angular/core';
import { FormGroup } from '@angular/forms';
import * as fielderrorData from './../../../assets/data/fielderror.json';
import { I18nService } from '../../services/common/i18n/i18n.service';

@Injectable()
export class FieldErrorDisplayService {

  constructor(private _i18nService:I18nService) { }
  
  
    public validateForm(formToValidate: FormGroup, formErrors: any, key: any, checkDirty?: boolean) {
      const form = formToValidate;
      const messages = (<any>fielderrorData)[key];
      for (const fieldKey in formErrors) {
          if (fieldKey) {
              formErrors[fieldKey] = '';
              let control = form.get(fieldKey);
              const fieldMessage = messages[fieldKey];
              if (control && !control.valid) {
                  if (!checkDirty || (control.dirty || control.touched)) {
                      for (const errorKey in control.errors) {
                          control.markAsTouched({ onlySelf: true });
                          let errorMsg = this._i18nService.getI18n(fieldMessage[errorKey],undefined);
                          formErrors[fieldKey] = errorMsg;
                      }
                  }
              }
          }
      }
      return formErrors;
  }
  
  
  
  public validateField(formToValidate: FormGroup,field: string, formErrors: any, key: any) {
    const form = formToValidate; 
      
        formErrors[field] = '';
        const control = form.get(field);
        
        const messages = (<any>fielderrorData)[key];
        
        const fieldMessage=messages[field];
        
        if (control && !control.valid) {
          
          if ( control.dirty || control.touched) {
            
            for (const key in control.errors) {
              control.markAsTouched({ onlySelf: true });
             let errorMsg =this._i18nService.getI18n(fieldMessage[key],undefined);
             formErrors[field] = errorMsg;
              
            }
          }
        }
       
    return formErrors;
  }

}
