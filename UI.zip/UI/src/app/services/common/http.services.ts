import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, Headers,ResponseContentType } from '@angular/http';
import { Configuration } from '../../app.constants';
import { Observable } from 'rxjs/Observable';
import { Cookie } from 'ng2-cookies';
@Injectable()
export class HttpServices {
    errorMessages = [];
    private apiUrl: string;
    private Server:string;
    constructor(private _http: Http, private _configuration: Configuration) {
        //this.apiUrl = _configuration.ServerWithApiUrl;

        this.apiUrl = window.location.origin+'/'+_configuration.ApiUrl;
        this.Server= window.location.origin+'/cavium/oauth/token';
        this.Server=this.Server.replace('4200','8080');
        this.apiUrl= this.apiUrl.replace('4200','8080');
 
      }
   
      options() {
        let headers = new Headers({
            'Content-type': 'application/json',
            //'Authorization': 'Bearer '+Cookie.get('access_token')
            'Authorization': 'Bearer '+Cookie.get(sessionStorage.getItem('username'))
          });
        let options = new RequestOptions({ headers: headers });
        return options;
    }

    httpGet(url: String) {
        return this._http.get(this.apiUrl + url, this.options())
            .map(res => res.json())
    }

    httpPost(model, url: String) {
        return this._http.post(this.apiUrl + url, model, this.options())
            .map(res => res.json())
    }
    httpPut(model, url: String) {
        return this._http.put(this.apiUrl + url, model, this.options())
            .map(res => res)
    }
    httpDelete(url: String) {
        return this._http.delete(this.apiUrl + url, this.options())
            .map(res => res)
    }
    httpDeleteOperationWithBody(url:String,model){
        let headers = new Headers({ 'Content-Type': 'application/json' ,
        //'Authorization': 'Bearer '+Cookie.get('access_token')
        'Authorization': 'Bearer '+Cookie.get(sessionStorage.getItem('username'))
        });
           let options = new RequestOptions({
             headers: headers,
             body : model
           });
        return this._http.delete(this.apiUrl + url, options)
        .map(res => res)
    }

    httpOauthToken(params){
        params.append('grant_type',this._configuration.GRANT_TYPE);
        params.append('client_id',this._configuration.CLIENT_ID);
        params.append('client_secret',this._configuration.CLIENT_SECRET);
        let headers = new Headers({'Content-type': 'application/x-www-form-urlencoded; charset=utf-8', 'Authorization': 'Basic '+btoa("cavium-client:cavium-secret")});
        let options = new RequestOptions({ headers: headers });
        return this._http.post(this.Server, params.toString(), options)
        .map(res => res.json());
    }
   
    httpPostWithOutToken(model, url: String) {
        let headers = new Headers({'Content-type': 'application/json'});
        let options = new RequestOptions({ headers: headers });
        return this._http.post(this.apiUrl + url, model, options)
            .map(res => res.json())
    }

    httpPostForDownloadFile(model, url: String){
        return this._http.post(this.apiUrl + url, model, this.options()).map(res => res);
    }
    httpPostForDownloadZipFile(model, url: String) {
        const options = new RequestOptions({
            responseType: ResponseContentType.Blob,
            headers: new Headers({
                'Accept': 'application/zip',
                //'Authorization': 'Bearer ' + Cookie.get('access_token')
                'Authorization': 'Bearer '+Cookie.get(sessionStorage.getItem('username'))
            })
        })

        return this._http.post(this.apiUrl + url, model, options).map(
            (response) => {
                return response;
            }
        );
    }
	
    httpFileUploadPost(files, url) {
        let headers = new Headers({
            //'Content-type': 'multipart/form-data',
            //'Authorization': 'Bearer ' + Cookie.get('access_token')
            'Authorization': 'Bearer '+Cookie.get(sessionStorage.getItem('username'))
        });
        let options = new RequestOptions({ headers: headers });
        return this._http.post(this.apiUrl + url, files, options)
            .map(response => response.json())
    }
}
