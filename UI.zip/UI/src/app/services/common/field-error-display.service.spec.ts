import { TestBed, inject } from '@angular/core/testing';

import { FieldErrorDisplayService } from './field-error-display.service';

describe('FieldErrorDisplayService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FieldErrorDisplayService]
    });
  });

  it('should be created', inject([FieldErrorDisplayService], (service: FieldErrorDisplayService) => {
    expect(service).toBeTruthy();
  }));
});
