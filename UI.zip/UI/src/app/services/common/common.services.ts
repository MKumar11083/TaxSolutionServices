import { Injectable } from '@angular/core';
import { Cookie } from 'ng2-cookies';
import { HttpServices } from './http.services';
@Injectable()
export class CommonServices {

    constructor(private _httpServices: HttpServices) {

    }
    clearSession() {
        console.log("session clear before logout.....");
        sessionStorage.clear();
        localStorage.clear();
        console.log(localStorage.length);
        Cookie.delete('refresh_token');
        Cookie.delete('access_token');
    }

    forgotPassword(form) {
        let  url  =  "/forgotPassword";
        return  this._httpServices.httpPostWithOutToken(form,  url);
    }
}

