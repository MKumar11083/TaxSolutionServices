import {Injectable} from '@angular/core';
import {Router} from '@angular/router';
import { Cookie } from 'ng2-cookies';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { HttpServices} from './common/http.services';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
 
export class userData {
  constructor(
    public id: number,
    public name: string) { }
} 

@Injectable()
export class LoginService {
  errorMsg : string;
  public rolesSet:Set<any>;
  constructor(
    private _router: Router, private _http: Http,
    private _httpServices: HttpServices){
      
    }

  obtainAccessToken(loginData){
    let params = new URLSearchParams();
    params.append('username',loginData.get("userName").value);
    params.append('password',encodeURIComponent(loginData.get("Password").value)); 
    return this._httpServices.httpOauthToken(params);
  }

  getUserRoles(){
    return this._httpServices.httpGet("getUserRoles");
  }

  checkCredentials(){
    if (!Cookie.check('access_token')){
        //this._router.navigate(['/login']);
        return false;
    }else{
      return true;
    }
  }

  getTopologyDetails(){
    return this._httpServices.httpGet("getTopologyDetails");
  }
}