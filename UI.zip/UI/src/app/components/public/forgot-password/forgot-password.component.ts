import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonServices} from './../../../services/common/common.services';
import { de } from 'ngx-bootstrap';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {

  loginForm: FormGroup;
  errorMsg: string;
  message : string;
  constructor(private _router: Router, private _formBuilder:
    FormBuilder, 
    private _service : CommonServices) { }

  ngOnInit() {
    this._service.clearSession();
    this.errorMsg = "";
    this.message = "";
    this.loginForm = this._formBuilder.group({
      userName: '',
    });
  }

  onSubmit(){
    debugger;
    this._service.forgotPassword(this.loginForm.value).subscribe(
      data => {
        console.log(data);
        if(data.responseCode == "200"){
          this.message="Temporary password is sent to your registered email-address";
        }else if(data.responseCode == "-230"){
          this.errorMsg = data.responseMessage;
        }
      },
      err => {
        
        console.log(err);
      }
    );
  }
}
