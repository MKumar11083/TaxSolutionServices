import { Component, OnInit ,Input } from '@angular/core';

@Component({
  selector: 'show-error',
  templateUrl: './field-error-display-component.component.html',
  styleUrls: ['./field-error-display-component.component.css']
})
export class FieldErrorDisplayComponentComponent implements OnInit {
  @Input() errorMsg: String;
  @Input() displayError: boolean;
  constructor() { }

  ngOnInit() {
  }

}
