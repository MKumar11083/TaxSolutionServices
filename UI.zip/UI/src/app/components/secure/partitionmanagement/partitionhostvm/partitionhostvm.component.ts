import { Component, OnInit,ViewChild } from '@angular/core';
import { PartitionManagementService } from './../../../../services/partitionmanagement/partitionmanagement.service';
import { ActivatedRoute } from '@angular/router';
import { MonitorConfigComponent} from './../../partitionmanagement/monitor-config/monitor-config.component'
import { MonitorStatsComponent} from './../../partitionmanagement/monitor-stats/monitor-stats.component';
@Component({
  selector: 'app-partitionhostvm',
  templateUrl: './partitionhostvm.component.html',
  styleUrls: ['./partitionhostvm.component.css']
})
export class PartitionhostvmComponent implements OnInit {
  @ViewChild('monitorConfig')
  monitorConfig: MonitorConfigComponent;
  @ViewChild('monitorStats')
  monitorStats: MonitorStatsComponent;
  partitionId: string;
  partitionName: string;
  appId: string;
  appName: string;
  ip: string;
  tab: string;
  classStatic: string;
  classServer: string;

  maxKeys: any;
  totalSSLContexts: any;
  sessionCount: any;
  availUsers: any;
  minPasswordLength: any;
  occTokenKeys: any;
  keyExport: any;
  mValue: any;
  occSslCtxs: any;
  occSessionKeys: any;
  maximumUsers: any;
  maxPswdLength: any;
  maximumAcclrDevCount: any;
  certAuth: any;

  partitionModel: any = [];   //Partition Info Tab

  eth0LinkStatus: any;
  eth1LinkStatus: any;
  partitionInfo: any;
  partitionStats: any;
  partitionNetworkStats: any;
  vmStatus: any;
  diskFreeSpace: any;
  cavServerStatus: any;
  driverStatus: any;
  hoursTime: any;
  minTime: any;
  secTime: any;
  processCount: any;
  ramStatsTotal: any;
  ramStatsFree: any;
  ramStatsUsed: any;
  swapStatsTotal: any;
  swapStatsFree: any;
  swapStatsUsed: any;

  dhcp: any;
  dhcpStatus: any;
  hostname: any;
  ipAddress: any;
  ipStatus: any;
  subnetAddress: any;
  subnetStatus: any;
  macStatic: any;
  macAddress: any;
  gateway: any;
  gatewayStatus: any;
  vlan: any;
  dhcp1: any;
  dhcpStatus1: any;
  hostname1: any;
  ipAddress1: any;
  ipStatus1: any;
  subnetAddress1: any;
  subnetStatus1: any;
  macStatic1: any;
  macAddress1: any;
  gateway1: any;
  gatewayStatus1: any;
  vlan1: any;

  dnsServers: any = [];
  searchDomainNames: any = [];
  staticIpToHostConfig: any = [];
  applianceId : any = '';
  applianceName : any = '';
  applianceIp : any = '';
  partitionDetails : any ={};
  constructor(
    private _activatedRoute: ActivatedRoute,
    private _partitionManagementService: PartitionManagementService) { } //Partition Info Tab

  ngOnInit() {
    this.partitionId = "";
    this.applianceId= "";
    this.applianceName = '';
    this.applianceIp='';
    this._activatedRoute.params.subscribe(params => {
      this.partitionId = params['partitionId'];
      this.partitionName = params['partitionName'];
      this.applianceId = params['appId'];
      this.applianceName = params['appName'];
      this.applianceIp = params['ip'];
    });
    this.partitionDetails['partitionId']= this.partitionId;
    this.partitionDetails['partitionName']= this.partitionName;
    this.partitionDetails['applianceId']= this.applianceId;
    this.partitionDetails['applianceName']= this.applianceName;
    this.partitionDetails['ipAddress']= this.applianceIp;
    this._partitionManagementService.getPartitionInfoData(this.partitionId).subscribe(
      res => {
        this.partitionInfo = JSON.parse(res.message);
        console.log(this.partitionInfo);

        if (this.partitionInfo != null) {

          if (this.partitionInfo.maxKeys != null) {
            this.maxKeys = this.partitionInfo.maxKeys;
          }

          if (this.partitionInfo.totalSslCtxs != null) {
            this.totalSSLContexts = this.partitionInfo.totalSslCtxs;
          }

          if (this.partitionInfo.sessionCount != null) {
            this.sessionCount = this.partitionInfo.sessionCount;
          }

          if (this.partitionInfo.availableUsers != null) {
            this.availUsers = this.partitionInfo.availableUsers;
          }

          if (this.partitionInfo.minPswdLen != null) {
            this.minPasswordLength = this.partitionInfo.minPswdLen;
          }

          if (this.partitionInfo.occupiedTokenKeys != null) {
            this.occTokenKeys = this.partitionInfo.occupiedTokenKeys;
          }

          if (this.partitionInfo.keyExport != null) {
            this.keyExport = this.partitionInfo.keyExport;
          }

          if (this.partitionInfo["mValue[miscCO]"] != null) {
            this.mValue = this.partitionInfo["mValue[miscCO]"];
          }

          if (this.partitionInfo.occupiedSslCtxs != null) {
            this.occSslCtxs = this.partitionInfo.occupiedSslCtxs;
          }

          if (this.partitionInfo.occupiedSessionKeys != null) {
            this.occSessionKeys = this.partitionInfo.occupiedSessionKeys;
          }

          if (this.partitionInfo.maxUsers != null) {
            this.maximumUsers = this.partitionInfo.maxUsers;
          }

          if (this.partitionInfo.maxPswdLen != null) {
            this.maxPswdLength = this.partitionInfo.maxPswdLen;
          }

          if (this.partitionInfo.maxAcclrDevCount != null) {
            this.maximumAcclrDevCount = this.partitionInfo.maxAcclrDevCount;
          }

          if (this.partitionInfo.certAuth != null) {
            this.certAuth = this.partitionInfo.certAuth;
          }

  

        }
      },
      error => {
        console.log(error);
      },
    )

    this._partitionManagementService.getPartitionStats(this.partitionId).subscribe(
      res => {
        this.partitionStats = JSON.parse(res.message);
        console.log(this.partitionStats);

        if (this.partitionStats != null) {

          if (this.partitionStats.vmstats != null) {

            if (this.partitionStats.vmstats["linkStatus(eth0)"] != null) {
              if (this.partitionStats.vmstats["linkStatus(eth0)"] == 1) {
                this.eth0LinkStatus = "Up";
              } else if (this.partitionStats.vmstats["linkStatus(eth0)"] == 0) {
                this.eth0LinkStatus = "Down";
              }
            }

            if (this.partitionStats.vmstats["linkStatus(eth1)"] != null) {
              if (this.partitionStats.vmstats["linkStatus(eth1)"] == 1) {
                this.eth1LinkStatus = "Up";
              } else if (this.partitionStats.vmstats["linkStatus(eth1)"] == 0) {
                this.eth1LinkStatus = "Down";
              }
            }

            if (this.partitionStats.vmstats["diskSpace(mb)"].free != null) {
              this.diskFreeSpace = this.partitionStats.vmstats["diskSpace(mb)"].free;
            }

            if (this.partitionStats.vmstats.cavServerStatus != null) {
              if (this.partitionStats.vmstats.cavServerStatus == 1) {
                this.cavServerStatus = "Up";
              } else if (this.partitionStats.vmstats.cavServerStatus == 0) {
                this.cavServerStatus = "Down";
              }
            }

            if (this.partitionStats.vmstats.driverStatus != null) {
              if (this.partitionStats.vmstats.driverStatus == 1) {
                this.driverStatus = "Up";
              } else if (this.partitionStats.vmstats.driverStatus == 0) {
                this.driverStatus = "Down";
              }
            }

            if (this.partitionStats.vmstats.systemUpTime != null) {
              if (this.partitionStats.vmstats.systemUpTime.hours != null) {
                this.hoursTime = this.partitionStats.vmstats.systemUpTime.hours;
              }
            }

            if (this.partitionStats.vmstats.systemUpTime != null) {
              if (this.partitionStats.vmstats.systemUpTime.minutes != null) {
                this.minTime = this.partitionStats.vmstats.systemUpTime.minutes;
              }
            }

            if (this.partitionStats.vmstats.systemUpTime != null) {
              if (this.partitionStats.vmstats.systemUpTime.seconds != null) {
                this.secTime = this.partitionStats.vmstats.systemUpTime.seconds;
              }
            }

            if (this.partitionStats.vmstats.processCount != null) {
              this.processCount = this.partitionStats.vmstats.processCount;
            }

            if (this.partitionStats.vmstats["ramStats(mb)"] != null) {
              if (this.partitionStats.vmstats["ramStats(mb)"].total != null) {
                this.ramStatsTotal = this.partitionStats.vmstats["ramStats(mb)"].total;
              }
            }

            if (this.partitionStats.vmstats["ramStats(mb)"] != null) {
              if (this.partitionStats.vmstats["ramStats(mb)"].free != null) {
                this.ramStatsFree = this.partitionStats.vmstats["ramStats(mb)"].free;
              }
            }

            if (this.ramStatsTotal != null && this.ramStatsFree != null) {
              this.ramStatsUsed = this.ramStatsTotal - this.ramStatsFree;
            }

            if (this.ramStatsTotal != null && this.ramStatsUsed != null) {
              this.gaugeValue2 = (parseInt(this.ramStatsUsed) / parseInt(this.ramStatsTotal)) * 100;
            }

            if (this.partitionStats.vmstats["swapStats(mb)"] != null) {
              if (this.partitionStats.vmstats["swapStats(mb)"].total != null) {
                this.swapStatsTotal = this.partitionStats.vmstats["swapStats(mb)"].total;
              }
            }

            if (this.partitionStats.vmstats["swapStats(mb)"] != null) {
              if (this.partitionStats.vmstats["swapStats(mb)"].free != null) {
                this.swapStatsFree = this.partitionStats.vmstats["swapStats(mb)"].free;
              }
            }

            if (this.swapStatsTotal != null && this.swapStatsFree != null) {
              this.swapStatsUsed = this.swapStatsTotal - this.swapStatsFree;
            }

            if (this.swapStatsTotal != null && this.swapStatsUsed != null) {
              this.gaugeValue3 = (parseInt(this.swapStatsUsed) / parseInt(this.swapStatsTotal)) * 100;
            }

            if (this.partitionStats.vmstats["cpuUsage(%)"] != null) {
              this.gaugeValue = this.partitionStats.vmstats["cpuUsage(%)"];
            }

          }

          if (this.partitionStats.vmStatus != null) {
            if (this.partitionStats.vmStatus == 1) {
              this.vmStatus = "Up";
            } else if (this.partitionStats.vmStatus == 0) {
              this.vmStatus = "Down";
            }
          }
        }

      },
      error => {
        console.log(error);
      },
    )

    this._partitionManagementService.getPartitionNetworkStats(this.partitionId).subscribe(
      res => {
        debugger;
        this.tab = "1";
        console.log(res);
        this.partitionNetworkStats = JSON.parse(res.message);
        console.log(this.partitionNetworkStats);

        if (this.partitionNetworkStats != null) {

          if (this.partitionNetworkStats.general != null) {

            if (this.partitionNetworkStats.general.eth0 != null) {

              if (this.partitionNetworkStats.general.eth0.dhcp != null) {
                this.dhcp = this.partitionNetworkStats.general.eth0.dhcp;
              }

              if (this.partitionNetworkStats.general.eth0.dhcpStatus != null) {
                this.dhcpStatus = this.partitionNetworkStats.general.eth0.dhcpStatus;
              }

              if (this.partitionNetworkStats.general.eth0.hostname != null) {
                this.hostname = this.partitionNetworkStats.general.eth0.hostname;
              }

              if (this.partitionNetworkStats.general.eth0.ip != null) {
                this.ipAddress = this.partitionNetworkStats.general.eth0.ip;
              }

              if (this.partitionNetworkStats.general.eth0.ipStatus != null) {
                this.ipStatus = this.partitionNetworkStats.general.eth0.ipStatus;
              }

              if (this.partitionNetworkStats.general.eth0.subnet != null) {
                this.subnetAddress = this.partitionNetworkStats.general.eth0.subnet;
              }

              if (this.partitionNetworkStats.general.eth0.subnetStatus != null) {
                this.subnetStatus = this.partitionNetworkStats.general.eth0.subnetStatus;
              }

              if (this.partitionNetworkStats.general.eth0.macStatic != null) {
                this.macStatic = this.partitionNetworkStats.general.eth0.macStatic;
              }

              if (this.partitionNetworkStats.general.eth0.mac != null) {
                this.macAddress = this.partitionNetworkStats.general.eth0.mac;
              }

              if (this.partitionNetworkStats.general.eth0.gateway != null) {
                this.gateway = this.partitionNetworkStats.general.eth0.gateway;
              }

              if (this.partitionNetworkStats.general.eth0.gatewayStatus != null) {
                this.gatewayStatus = this.partitionNetworkStats.general.eth0.gatewayStatus;
              }

              if (this.partitionNetworkStats.general.eth0.vlan != null) {
                this.vlan = this.partitionNetworkStats.general.eth0.vlan;
              }
            }

            if (this.partitionNetworkStats.general.eth1 != null) {

              if (this.partitionNetworkStats.general.eth1.dhcp != null) {
                this.dhcp1 = this.partitionNetworkStats.general.eth1.dhcp;
              }

              if (this.partitionNetworkStats.general.eth1.dhcpStatus != null) {
                this.dhcpStatus1 = this.partitionNetworkStats.general.eth1.dhcpStatus;
              }

              if (this.partitionNetworkStats.general.eth1.hostname != null) {
                this.hostname1 = this.partitionNetworkStats.general.eth1.hostname;
              }

              if (this.partitionNetworkStats.general.eth1.ip != null) {
                this.ipAddress1 = this.partitionNetworkStats.general.eth1.ip;
              }

              if (this.partitionNetworkStats.general.eth1.ipStatus != null) {
                this.ipStatus1 = this.partitionNetworkStats.general.eth1.ipStatus;
              }

              if (this.partitionNetworkStats.general.eth1.subnet != null) {
                this.subnetAddress1 = this.partitionNetworkStats.general.eth1.subnet;
              }

              if (this.partitionNetworkStats.general.eth1.subnetStatus != null) {
                this.subnetStatus1 = this.partitionNetworkStats.general.eth1.subnetStatus;
              }

              if (this.partitionNetworkStats.general.eth1.macStatic != null) {
                this.macStatic1 = this.partitionNetworkStats.general.eth1.macStatic;
              }

              if (this.partitionNetworkStats.general.eth1.mac != null) {
                this.macAddress1 = this.partitionNetworkStats.general.eth1.mac;
              }

              // if (this.partitionNetworkStats.general.eth1.gateway != null) {
              //   this.gateway1 = this.partitionNetworkStats.general.eth1.gateway;
              // }

              // if (this.partitionNetworkStats.general.eth1.gatewayStatus != null) {
              //   this.gatewayStatus1 = this.partitionNetworkStats.general.eth1.gatewayStatus;
              // }

              if (this.partitionNetworkStats.general.eth1.vlan != null) {
                this.vlan1 = this.partitionNetworkStats.general.eth1.vlan;
              }
            }
          }

          if (this.partitionNetworkStats.advanced != null) {

            if (this.partitionNetworkStats.advanced.dnsServers != null) {
              this.dnsServers = this.partitionNetworkStats.advanced.dnsServers;
            }

            if (this.partitionNetworkStats.advanced.searchDomainNames != null) {
              this.searchDomainNames = this.partitionNetworkStats.advanced.searchDomainNames;
            }

            if (this.partitionNetworkStats.advanced.staticIpToHostConfig != null) {
              this.staticIpToHostConfig = this.partitionNetworkStats.advanced.staticIpToHostConfig;
            }
          }
        }
        let modal={
          "ip":this.ipAddress,
          partitionDetailModel:{
            "partitionId":this.partitionId
          }
        }
        this._partitionManagementService.updateEth01IpDetail(modal).subscribe(
          res => {
            console.log(res);
          },
          error => {
            console.log(error);
          },
        )
      },
      error => {
        console.log(error);
      },
    )

  }

  selectTab(tab_id: string) {
    if (tab_id == "1") {
      this.classStatic = "btn-primary";
      this.classServer = "btn-default";
    } else if (tab_id == "2") {
      this.classStatic = "btn-default";
      this.classServer = "btn-primary";
    }
    this.tab = tab_id;
  }

  gaugeType = "arch";
  gaugeThickness = 25;
  gaugeThresholdConfig = {
    '0': { color: 'rgb(0,179,30' },
    '60': { color: 'rgb(230,191,0' },
    '80': { color: 'rgb(204,0,0' }
  };
  gaugeAppendText = "%";

  // hostVM gauge
  gaugeValue = [];
  gaugeValue1 = [];
  gaugeValue2: number;
  gaugeValue3: number;


  // lineChart10
  public lineChartData010: Array<any> = [
    { data: [70, 59, 83, 81, 60, 87, 83], label: 'Head' },
    { data: [65, 48, 55, 50, 56, 60, 78], label: 'Tail' },
    { data: [45, 35, 45, 65, 47, 52, 40], label: 'Head' },
    { data: [27, 22, 33, 30, 38, 27, 32], label: 'Tail' },

  ];
  public lineChartLabels10: Array<any> = ['18:10', '18:20', '18:30', '18:40', '18:50', '19:00', '19:10'];
  public lineChartOptions10: any = {
    responsive: true,
    legend: {
      display: true,
      position: 'bottom'
    }
  };
  public lineChartColors10: Array<any> = [
    { // blue
      backgroundColor: 'rgba(0,102,204,0)',
      borderColor: 'rgba(0,102,204,1)',
      pointBackgroundColor: 'rgba(0,102,204,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(0,102,204,0.8)'
    },
    { //green
      backgroundColor: 'rgba(89,179,0,0)',
      borderColor: 'rgba(89,179,0,1)',
      pointBackgroundColor: 'rgba(89,179,0,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(89,179,0,0.8)'
    },

    { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
    },

    { // purple
      backgroundColor: 'rgba(102,0,153,0)',
      borderColor: 'rgba(102,0,153,1)',
      pointBackgroundColor: 'rgba(102,0,153,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(102,0,153,1)'
    },

  ];
  public lineChartLegend10: boolean = true;
  public lineChartType10: string = 'line';


  // events
  public chartClicked10(e: any): void {
    console.log(e);
  }

  public chartHovered10(e: any): void {
    console.log(e);
  }

  // lineChart11
  public lineChartData011: Array<any> = [
    { data: [70, 59, 83, 81, 60, 87, 83], label: 'Head' },
    { data: [65, 48, 55, 50, 56, 60, 78], label: 'Tail' },
    { data: [45, 35, 45, 65, 47, 52, 40], label: 'Head' },
    { data: [27, 22, 33, 30, 38, 27, 32], label: 'Tail' },
  ];
  public lineChartLabels11: Array<any> = ['18:10', '18:20', '18:30', '18:40', '18:50', '19:00', '19:10'];
  public lineChartOptions11: any = {
    responsive: true,
    legend: {
      display: true,
      position: 'bottom'
    }
  };
  public lineChartColors11: Array<any> = [
    { // blue
      backgroundColor: 'rgba(0,102,204,0)',
      borderColor: 'rgba(0,102,204,1)',
      pointBackgroundColor: 'rgba(0,102,204,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(0,102,204,0.8)'
    },
    { //green
      backgroundColor: 'rgba(89,179,0,0)',
      borderColor: 'rgba(89,179,0,1)',
      pointBackgroundColor: 'rgba(89,179,0,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(89,179,0,0.8)'
    },

    { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
    },

    { // purple
      backgroundColor: 'rgba(102,0,153,0)',
      borderColor: 'rgba(102,0,153,1)',
      pointBackgroundColor: 'rgba(102,0,153,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(102,0,153,1)'
    },

  ];
  public lineChartLegend11: boolean = true;
  public lineChartType11: string = 'line';


  // events
  public chartClicked11(e: any): void {
    console.log(e);
  }

  public chartHovered11(e: any): void {
    console.log(e);
  }

}










