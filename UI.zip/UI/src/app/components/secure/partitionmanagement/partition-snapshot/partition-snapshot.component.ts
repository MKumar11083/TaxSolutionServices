import { Component, OnInit } from '@angular/core';
import { ChartsModule, Color } from 'ng2-charts';
import { PartitionManagementService } from './../../../../services/partitionmanagement/partitionmanagement.service'
import { AnonymousSubscription } from "rxjs/Subscription";
import { Observable } from "rxjs/Observable";
declare var Chart: any;

@Component({
  selector: 'app-partition-snapshot',
  templateUrl: './partition-snapshot.component.html',
  styleUrls: ['./partition-snapshot.component.css']
})
export class PartitionSnapshotComponent implements OnInit {
  myBarChart: any;
  alertDetails: any = [];
  recentActivityList: any = [];
  inProgressActivityList = [];
  alertsList:any=[];
  availablePartition: any;
  occupiedPartition: any;

  functionalPartition: any;
  nonFunctionalPartition: any;

  zeroizedState: any;
  fipMode: any;
  fipModeWithDualfactor: any;
  nonFipMode: any;

  keyDetailsData: any = [];
  acclrDeviceDetailsData: any = [];
  contextDetailsData: any = [];

  public loading = false;

  public getProgressActivities: AnonymousSubscription;
  public getGraphData: AnonymousSubscription;
  public timer: AnonymousSubscription;
  graphTotalDetails: any = [];
  // keys variables 
  tenKeysList: any = [];
  twentyKeysList: any = [];
  thirtyKeysList: any = [];
  fourtyKeysList: any = [];
  fiftyKeysList: any = [];
  sixtyKeysList: any = [];
  seventyKeysList: any = [];
  eightyKeysList: any = [];
  ninetyKeysList: any = [];
  hundredKeysList: any = [];

  // Acceleration Device variables 
  tenAccDevList: any = [];
  twentyAccDevList: any = [];
  thirtyAccDevList: any = [];
  fourtyAccDevList: any = [];
  fiftyAccDevList: any = [];
  sixtyAccDevList: any = [];
  seventyAccDevList: any = [];
  eightyAccDevList: any = [];
  ninetyAccDevList: any = [];
  hundredAccDevList: any = [];

  // SSL Contexts variables 
  tenSSLCtxtList: any = [];
  twentySSLCtxtList: any = [];
  thirtySSLCtxtList: any = [];
  fourtySSLCtxtList: any = [];
  fiftySSLCtxtList: any = [];
  sixtySSLCtxtList: any = [];
  seventySSLCtxtList: any = [];
  eightySSLCtxtList: any = [];
  ninetySSLCtxtList: any = [];
  hundredSSLCtxtList: any = [];


  constructor(private _partitionManagementService: PartitionManagementService) { }

  ngOnInit() {
    this.loading = true;
    this.getAlerts();
    this.getGraphDetails();
    this.getRecentActivity();
    this.getInProgressActivity();
    this.createBarChart();
  }

  getAlerts() {
    this.loading = true;
    this._partitionManagementService.getAlertDetails().subscribe(
      res => {
        this.loading = false;
        this.alertsList=[];
        res.forEach(element=>{
          let alerts={};
          alerts['timezone'] = element.timezone;
          alerts['createdDate'] = element.createdDate;
          alerts['message'] = element.message;
          alerts['moduleId'] = element.moduleId;
          alerts['moduleName'] = element.moduleName;
          this.alertsList.push(alerts);
        });
        console.log(this.alertDetails);
      },
      error => {
        this.loading = false;
        console.log(error);
      },
    );
  }

  getGraphDetails() {
    this.loading = true;
    this._partitionManagementService.getBarGraphData().subscribe(
      res => {
        //usage
        this.doughnutChartData = [];
        this.availablePartition = res.avaliablePartitionSlots;
        this.occupiedPartition = res.occupiedPartitionSlots;
        this.doughnutChartData.push(this.occupiedPartition);
        this.doughnutChartData.push(this.availablePartition);

        //status
        this.doughnutChartData1 = [];
        this.functionalPartition = res.partitionFunctionalStatus;
        this.nonFunctionalPartition = res.partitionNonFunctionalStatus;
        this.doughnutChartData1.push(this.functionalPartition);
        this.doughnutChartData1.push(this.nonFunctionalPartition);

        //FIPS status
        this.doughnutChartData2 = [];
        this.zeroizedState = res.zeroizedState;
        this.fipMode = res.fipMode;
        this.fipModeWithDualfactor = res.fipModeWithDualfactor;
        this.nonFipMode = res.nonFipMode;
        this.doughnutChartData2.push(this.zeroizedState);
        this.doughnutChartData2.push(this.fipMode);
        this.doughnutChartData2.push(this.fipModeWithDualfactor);
        this.doughnutChartData2.push(this.nonFipMode);
        this.loading = false;
      },
      error => {
        this.loading = false;
        console.log(error);
      },
    );
  }

  getRecentActivity() {
    this.loading = true;
    this._partitionManagementService.getRecentActivityDetails().subscribe(
      res => {
        this.recentActivityList = [];
        let colors = ["red", "green", "blue"];
        let count = 0;
        res.forEach(element => {
          let recentActivity = {};
          if (count == 3) {
            count = 0;
          }
          recentActivity['timezone'] = element.timezone;
          recentActivity['message'] = element.message;
          recentActivity['createdDate'] = element.createdDate;
          recentActivity['color'] = colors[count];
          this.recentActivityList.push(recentActivity);
          count++;
          this.loading = false;
        });
      },
      error => {
        this.loading = false;
        console.log(error);
      },
    );
  }
  //Usage Donut chart 
  public doughnutChartData: number[] = [];
  public doughnutChartLabels: string[] = ['Used', 'Available'];
  public doughnutChartType: string = 'doughnut';
  public chartOptions = {
    responsive: true,
    legend: {
      display: true,
      position: 'right',
      labels: {
        boxWidth: 10
      }
    }
  };
  public mycolors: Array<Color> = [
    {
      backgroundColor: [
        'rgb(255,255,25)',
        'rgb(0,179,30)'],
      hoverBackgroundColor: ['rgb(255,255,25)', 'rgb(0,179,30)'],
    }
  ];


  // create keys , acceleration & context data bar graph.
  createBarChart() {
    this.clearBarGraphData();
    this.loading = true;
    this.getGraphData = this._partitionManagementService.getBarGraphData().subscribe(
      res => {
        this.loading = false;
        this.keyDetailsData = res.keyDetailsWithPercentage;
        this.acclrDeviceDetailsData = res.acclrDeviceDetailsWithPercentage;
        this.contextDetailsData = res.contextDetailsWithPercentage;
        // keys bar graph
        this.createKeysBarGraph();
        this.createAccDevBarGraph();
        this.createSSLContextsBarGraph();
      }
    );
  }
  clearBarGraphData(){
    // keys variables 
  this.tenKeysList= [];
  this.twentyKeysList = [];
  this.thirtyKeysList = [];
  this.fourtyKeysList = [];
  this.fiftyKeysList= [];
  this.sixtyKeysList = [];
  this.seventyKeysList = [];
  this.eightyKeysList= [];
  this.ninetyKeysList= [];
  this.hundredKeysList = [];

  // Acceleration Device variables 
  this.tenAccDevList = [];
  this.twentyAccDevList = [];
  this.thirtyAccDevList = [];
  this.fourtyAccDevList= [];
  this.fiftyAccDevList = [];
  this.sixtyAccDevList = [];
  this.seventyAccDevList = [];
  this.eightyAccDevList = [];
  this.ninetyAccDevList = [];
  this.hundredAccDevList = [];

  // SSL Contexts variables 
  this.tenSSLCtxtList = [];
  this.twentySSLCtxtList= [];
  this.thirtySSLCtxtList = [];
  this.fourtySSLCtxtList = [];
  this.fiftySSLCtxtList = [];
  this.sixtySSLCtxtList = [];
  this.seventySSLCtxtList = [];
  this.eightySSLCtxtList = [];
  this.ninetySSLCtxtList = [];
  this.hundredSSLCtxtList = [];
  }
  createKeysBarGraph() {
    if (this.keyDetailsData != null) {
      this.barChartData1.push('');
      // keys - 0 to 10 percentage data with appliance names.
      if (this.keyDetailsData.tenPercentList.length > 0) {
        let percentageList = this.keyDetailsData.tenPercentList.map(item => item.percentage);
        let applianceList = this.keyDetailsData.tenPercentList.map(item => item.applianceDetailModel.applianceName);
        this.barChartData1.push(String(applianceList.length));
        applianceList.forEach((item, index) => {
          this.tenKeysList.push(item + " : " + percentageList[index] + " % ");
        });
      }else{
        this.barChartData1.push(String(0));
      }
      // keys - 10 to 20 percentage data with appliance names.
      if (this.keyDetailsData.twentyPercentList.length > 0) {
        let percentageList = this.keyDetailsData.twentyPercentList.map(item => item.percentage);
        let applianceList = this.keyDetailsData.twentyPercentList.map(item => item.applianceDetailModel.applianceName);
        this.barChartData1.push(String(applianceList.length));
        applianceList.forEach((item, index) => {
          this.twentyKeysList.push(item + " : " + percentageList[index] + " % ");
        });
      }else{
        this.barChartData1.push(String(0));
      }
      // keys - 20 to 30 percentage data with appliance names.
      if (this.keyDetailsData.thirtyPercentList.length > 0) {
        let percentageList = this.keyDetailsData.thirtyPercentList.map(item => item.percentage);
        let applianceList = this.keyDetailsData.thirtyPercentList.map(item => item.applianceDetailModel.applianceName);
        this.barChartData1.push(String(applianceList.length));
        applianceList.forEach((item, index) => {
          this.thirtyKeysList.push(item + " : " + percentageList[index] + " % ");
        });
      }else{
        this.barChartData1.push(String(0));
      }

      // keys - 30 to 40 percentage data with appliance names.
      if (this.keyDetailsData.fortyPercentList.length > 0) {
        let percentageList = this.keyDetailsData.fortyPercentList.map(item => item.percentage);
        let applianceList = this.keyDetailsData.fortyPercentList.map(item => item.applianceDetailModel.applianceName);
        this.barChartData1.push(String(applianceList.length));
        applianceList.forEach((item, index) => {
          this.fourtyKeysList.push(item + " : " + percentageList[index] + " % ");
        });
      }else{
        this.barChartData1.push(String(0));
      }

      // keys - 40 to 50 percentage data with appliance names.
      if (this.keyDetailsData.fiftyPercentList.length > 0) {
        let percentageList = this.keyDetailsData.fiftyPercentList.map(item => item.percentage);
        let applianceList = this.keyDetailsData.fiftyPercentList.map(item => item.applianceDetailModel.applianceName);
        this.barChartData1.push(String(applianceList.length));
        applianceList.forEach((item, index) => {
          this.fiftyKeysList.push(item + " : " + percentageList[index] + " % ");
        });
      }else{
        this.barChartData1.push(String(0));
      }

      // keys - 50 to 60 percentage data with appliance names.
      if (this.keyDetailsData.sixtyPercentList.length > 0) {
        let percentageList = this.keyDetailsData.sixtyPercentList.map(item => item.percentage);
        let applianceList = this.keyDetailsData.sixtyPercentList.map(item => item.applianceDetailModel.applianceName);
        this.barChartData1.push(String(applianceList.length));
        applianceList.forEach((item, index) => {
          this.sixtyKeysList.push(item + " : " + percentageList[index] + " % ");
        });
      }else{
        this.barChartData1.push(String(0));
      }
      // keys - 60 to 70 percentage data with appliance names.
      if (this.keyDetailsData.seventyPercentList.length > 0) {
        let percentageList = this.keyDetailsData.seventyPercentList.map(item => item.percentage);
        let applianceList = this.keyDetailsData.seventyPercentList.map(item => item.applianceDetailModel.applianceName);
        this.barChartData1.push(String(applianceList.length));
        applianceList.forEach((item, index) => {
          this.seventyKeysList.push(item + " : " + percentageList[index] + " % ");
        });
      }else{
        this.barChartData1.push(String(0));
      }

      // keys - 70 to 80 percentage data with appliance names.
      if (this.keyDetailsData.eightyPercentList.length > 0) {
        let percentageList = this.keyDetailsData.eightyPercentList.map(item => item.percentage);
        let applianceList = this.keyDetailsData.eightyPercentList.map(item => item.applianceDetailModel.applianceName);
        this.barChartData1.push(String(applianceList.length));
        applianceList.forEach((item, index) => {
          this.eightyKeysList.push(item + " : " + percentageList[index] + " % ");
        });
      }else{
        this.barChartData1.push(String(0));
      }
      // keys - 80 to 90 percentage data with appliance names.
      if (this.keyDetailsData.ninetyPercentList.length > 0) {
        let percentageList = this.keyDetailsData.ninetyPercentList.map(item => item.percentage);
        let applianceList = this.keyDetailsData.ninetyPercentList.map(item => item.applianceDetailModel.applianceName);
        this.barChartData1.push(String(applianceList.length));
        applianceList.forEach((item, index) => {
          this.ninetyKeysList.push(item + " : " + percentageList[index] + " % ");
        });
      }else{
        this.barChartData1.push(String(0));
      }
      // keys - 90 to 100 percentage data with appliance names.
      if (this.keyDetailsData.hundredPercentList.length > 0) {
        let percentageList = this.keyDetailsData.hundredPercentList.map(item => item.percentage);
        let applianceList = this.keyDetailsData.hundredPercentList.map(item => item.applianceDetailModel.applianceName);
        this.barChartData1.push(String(applianceList.length));
        applianceList.forEach((item, index) => {
          this.hundredKeysList.push(item + " : " + percentageList[index] + " % ");
        });
      }else{
        this.barChartData1.push(String(0));
      }
    }
  }

  //keys bar chart options.
  public barChartOptionsKeys: any = {
    scaleShowVerticalLines: false,
    responsive: true,
    legend: {
      display: true,
      position: 'left',
    },
    scales: {
      yAxes: [{
        ticks: {
          min: 0, // it is for ignoring negative step.
          beginAtZero: true,
          callback: function (value, index, values) {
            if (Math.floor(value) === value) {
              return value;
            }
          }
        },
        scaleLabel: {
          display: true,
          labelString: 'No. of Appliances',
          fontStyle: 'bold'
        }
      }],
      xAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'Keys Percentage',
          fontStyle: 'bold'
        }
      }],
    },
    tooltips: {
      callbacks: {
        label: (tooltipItem, data) => {
          return '';
        },
        title: (items, data) => {
          let graphData: any;
          if (items[0].index == 1) {
            if (this.tenKeysList.length > 0) {
              graphData = this.tenKeysList;
            }
          } else if (items[0].index == 2) {
            if (this.twentyKeysList.length > 0) {
              graphData = this.twentyKeysList;
            }
          } else if (items[0].index == 3) {
            if (this.thirtyKeysList.length > 0) {
              graphData = this.thirtyKeysList;
            }

          } else if (items[0].index == 4) {
            if (this.fourtyKeysList.length > 0) {
              graphData = this.fourtyKeysList;
            }
          } else if (items[0].index == 5) {
            if (this.fiftyKeysList.length > 0) {
              graphData = this.fiftyKeysList;
            }

          } else if (items[0].index == 6) {
            if (this.sixtyKeysList.length > 0) {
              graphData = this.sixtyKeysList;
            }
          } else if (items[0].index == 7) {
            if (this.seventyKeysList.length > 0) {
              graphData = this.seventyKeysList;
            }

          } else if (items[0].index == 8) {
            if (this.eightyKeysList.length > 0) {
              graphData = this.eightyKeysList;
            }

          } else if (items[0].index == 9) {
            if (this.ninetyKeysList.length > 0) {
              graphData = this.ninetyKeysList;
            }

          } else if (items[0].index == 10) {
            if (this.hundredKeysList.length > 0) {
              graphData = this.hundredKeysList;
            }
          }
          return graphData;
        }
      }
    }
  };

  createAccDevBarGraph() {
    if (this.acclrDeviceDetailsData != null) {
      this.barChartData2.push('');
      // keys - 0 to 10 percentage data with appliance names.
      if (this.acclrDeviceDetailsData.tenPercentList.length > 0) {
        let percentageList = this.acclrDeviceDetailsData.tenPercentList.map(item => item.percentage);
        let applianceList = this.acclrDeviceDetailsData.tenPercentList.map(item => item.applianceDetailModel.applianceName);
        this.barChartData2.push(String(applianceList.length));
        applianceList.forEach((item, index) => {
          this.tenAccDevList.push(item + " : " + percentageList[index] + " % ");
        });
      }else{
        this.barChartData2.push(String(0));
      }
      // keys - 10 to 20 percentage data with appliance names.
      if (this.acclrDeviceDetailsData.twentyPercentList.length > 0) {
        let percentageList = this.acclrDeviceDetailsData.twentyPercentList.map(item => item.percentage);
        let applianceList = this.acclrDeviceDetailsData.twentyPercentList.map(item => item.applianceDetailModel.applianceName);
        this.barChartData2.push(String(applianceList.length));
        applianceList.forEach((item, index) => {
          this.twentyAccDevList.push(item + " : " + percentageList[index] + " % ");
        });
      }else{
        this.barChartData2.push(String(0));
      }
      // keys - 20 to 30 percentage data with appliance names.
      if (this.acclrDeviceDetailsData.thirtyPercentList.length > 0) {
        let percentageList = this.acclrDeviceDetailsData.thirtyPercentList.map(item => item.percentage);
        let applianceList = this.acclrDeviceDetailsData.thirtyPercentList.map(item => item.applianceDetailModel.applianceName);
        this.barChartData2.push(String(applianceList.length));
        applianceList.forEach((item, index) => {
          this.thirtyAccDevList.push(item + " : " + percentageList[index] + " % ");
        });
      }else{
        this.barChartData2.push(String(0));
      }

      // keys - 30 to 40 percentage data with appliance names.
      if (this.acclrDeviceDetailsData.fortyPercentList.length > 0) {
        let percentageList = this.acclrDeviceDetailsData.fortyPercentList.map(item => item.percentage);
        let applianceList = this.acclrDeviceDetailsData.fortyPercentList.map(item => item.applianceDetailModel.applianceName);
        this.barChartData2.push(String(applianceList.length));
        applianceList.forEach((item, index) => {
          this.fourtyAccDevList.push(item + " : " + percentageList[index] + " % ");
        });
      }else{
        this.barChartData2.push(String(0));
      }


      // keys - 40 to 50 percentage data with appliance names.
      if (this.acclrDeviceDetailsData.fiftyPercentList.length > 0) {
        let percentageList = this.acclrDeviceDetailsData.fiftyPercentList.map(item => item.percentage);
        let applianceList = this.acclrDeviceDetailsData.fiftyPercentList.map(item => item.applianceDetailModel.applianceName);
        this.barChartData2.push(String(applianceList.length));
        applianceList.forEach((item, index) => {
          this.fiftyAccDevList.push(item + " : " + percentageList[index] + " % ");
        });
      }else{
        this.barChartData2.push(String(0));
      }

      // keys - 50 to 60 percentage data with appliance names.
      if (this.acclrDeviceDetailsData.sixtyPercentList.length > 0) {
        let percentageList = this.acclrDeviceDetailsData.sixtyPercentList.map(item => item.percentage);
        let applianceList = this.acclrDeviceDetailsData.sixtyPercentList.map(item => item.applianceDetailModel.applianceName);
        this.barChartData2.push(String(applianceList.length));
        applianceList.forEach((item, index) => {
          this.sixtyAccDevList.push(item + " : " + percentageList[index] + " % ");
        });
      }else{
        this.barChartData2.push(String(0));
      }
      // keys - 60 to 70 percentage data with appliance names.
      if (this.acclrDeviceDetailsData.seventyPercentList.length > 0) {
        let percentageList = this.acclrDeviceDetailsData.seventyPercentList.map(item => item.percentage);
        let applianceList = this.acclrDeviceDetailsData.seventyPercentList.map(item => item.applianceDetailModel.applianceName);
        this.barChartData2.push(String(applianceList.length));
        applianceList.forEach((item, index) => {
          this.seventyAccDevList.push(item + " : " + percentageList[index] + " % ");
        });
      }else{
        this.barChartData2.push(String(0));
      }

      // keys - 70 to 80 percentage data with appliance names.
      if (this.acclrDeviceDetailsData.eightyPercentList.length > 0) {
        let percentageList = this.acclrDeviceDetailsData.eightyPercentList.map(item => item.percentage);
        let applianceList = this.acclrDeviceDetailsData.eightyPercentList.map(item => item.applianceDetailModel.applianceName);
        this.barChartData2.push(String(applianceList.length));
        applianceList.forEach((item, index) => {
          this.eightyAccDevList.push(item + " : " + percentageList[index] + " % ");
        });
      }else{
        this.barChartData2.push(String(0));
      }
      // keys - 80 to 90 percentage data with appliance names.
      if (this.acclrDeviceDetailsData.ninetyPercentList.length > 0) {
        let percentageList = this.acclrDeviceDetailsData.ninetyPercentList.map(item => item.percentage);
        let applianceList = this.acclrDeviceDetailsData.ninetyPercentList.map(item => item.applianceDetailModel.applianceName);
        this.barChartData2.push(String(applianceList.length));
        applianceList.forEach((item, index) => {
          this.ninetyAccDevList.push(item + " : " + percentageList[index] + " % ");
        });
      }else{
        this.barChartData2.push(String(0));
      }
      // keys - 90 to 100 percentage data with appliance names.
      if (this.acclrDeviceDetailsData.hundredPercentList.length > 0) {
        let percentageList = this.acclrDeviceDetailsData.hundredPercentList.map(item => item.percentage);
        let applianceList = this.acclrDeviceDetailsData.hundredPercentList.map(item => item.applianceDetailModel.applianceName);
        this.barChartData2.push(String(applianceList.length));
        applianceList.forEach((item, index) => {
          this.hundredAccDevList.push(item + " : " + percentageList[index] + " % ");
        });
      }else{
        this.barChartData2.push(String(0));
      }
    }
  }

  //Acceleration Device bar chart options.
  public barChartOptionsAccDev: any = {
    scaleShowVerticalLines: false,
    responsive: true,
    legend: {
      display: true,
    },
    scales: {
      yAxes: [{
        ticks: {
          min: 0, // it is for ignoring negative step.
          beginAtZero: true,
          callback: function (value, index, values) {
            if (Math.floor(value) === value) {
              return value;
            }
          }
        },
        scaleLabel: {
          display: true,
          labelString: 'No. of Appliances',
          fontStyle: 'bold'
        }
      }],
      xAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'Acceleration Devices Percentage',
          fontStyle: 'bold'
        }
      }],
    },
    tooltips: {
      callbacks: {
        label: (tooltipItem, data) => {
          return '';
        },
        title: (items, data) => {
          let graphData: any;
          if (items[0].index == 1) {
            if (this.tenAccDevList.length > 0) {
              graphData = this.tenAccDevList;
            }
          } else if (items[0].index == 2) {
            if (this.twentyAccDevList.length > 0) {
              graphData = this.twentyAccDevList;
            }
          } else if (items[0].index == 3) {
            if (this.thirtyAccDevList.length > 0) {
              graphData = this.thirtyAccDevList;
            }

          } else if (items[0].index == 4) {
            if (this.fourtyAccDevList.length > 0) {
              graphData = this.fourtyAccDevList;
            }
          } else if (items[0].index == 5) {
            if (this.fiftyAccDevList.length > 0) {
              graphData = this.fiftyAccDevList;
            }

          } else if (items[0].index == 6) {
            if (this.sixtyAccDevList.length > 0) {
              graphData = this.sixtyAccDevList;
            }
          } else if (items[0].index == 7) {
            if (this.seventyAccDevList.length > 0) {
              graphData = this.seventyAccDevList;
            }
          } else if (items[0].index == 8) {
            if (this.eightyAccDevList.length > 0) {
              graphData = this.eightyAccDevList;
            }

          } else if (items[0].index == 9) {
            if (this.ninetyAccDevList.length > 0) {
              graphData = this.ninetyAccDevList;
            }

          } else if (items[0].index == 10) {
            if (this.hundredAccDevList.length > 0) {
              graphData = this.hundredAccDevList;
            }
          }
          return graphData;
        }
      }
    }
  };


  createSSLContextsBarGraph() {
    if (this.contextDetailsData != null) {
      this.barChartData3.push('');
      // keys - 0 to 10 percentage data with appliance names.
      if (this.contextDetailsData.tenPercentList.length > 0) {
        let percentageList = this.contextDetailsData.tenPercentList.map(item => item.percentage);
        let applianceList = this.contextDetailsData.tenPercentList.map(item => item.applianceDetailModel.applianceName);
        this.barChartData3.push(applianceList.length);
        applianceList.forEach((item, index) => {
          this.tenSSLCtxtList.push(item + " : " + percentageList[index] + " % ");
        });
      }else{
        this.barChartData3.push(String(0));
      }
      // keys - 10 to 20 percentage data with appliance names.
      if (this.contextDetailsData.twentyPercentList.length > 0) {
        let percentageList = this.contextDetailsData.twentyPercentList.map(item => item.percentage);
        let applianceList = this.contextDetailsData.twentyPercentList.map(item => item.applianceDetailModel.applianceName);
        this.barChartData3.push(applianceList.length);
        applianceList.forEach((item, index) => {
          this.twentySSLCtxtList.push(item + " : " + percentageList[index] + " % ");
        });
      }else{
        this.barChartData3.push(String(0));
      }
      // keys - 20 to 30 percentage data with appliance names.
      if (this.contextDetailsData.thirtyPercentList.length > 0) {
        let percentageList = this.contextDetailsData.thirtyPercentList.map(item => item.percentage);
        let applianceList = this.contextDetailsData.thirtyPercentList.map(item => item.applianceDetailModel.applianceName);
        this.barChartData3.push(applianceList.length);
        applianceList.forEach((item, index) => {
          this.thirtySSLCtxtList.push(item + " : " + percentageList[index] + " % ");
        });
      }else{
        this.barChartData3.push(String(0));
      }

      // keys - 30 to 40 percentage data with appliance names.
      if (this.contextDetailsData.fortyPercentList.length > 0) {
        let percentageList = this.contextDetailsData.fortyPercentList.map(item => item.percentage);
        let applianceList = this.contextDetailsData.fortyPercentList.map(item => item.applianceDetailModel.applianceName);
        this.barChartData3.push(applianceList.length);
        applianceList.forEach((item, index) => {
          this.fourtySSLCtxtList.push(item + " : " + percentageList[index] + " % ");
        });
      }else{
        this.barChartData3.push(String(0));
      }


      // keys - 40 to 50 percentage data with appliance names.
      if (this.contextDetailsData.fiftyPercentList.length > 0) {
        let percentageList = this.contextDetailsData.fiftyPercentList.map(item => item.percentage);
        let applianceList = this.contextDetailsData.fiftyPercentList.map(item => item.applianceDetailModel.applianceName);
        this.barChartData3.push(applianceList.length);
        applianceList.forEach((item, index) => {
          this.fiftySSLCtxtList.push(item + " : " + percentageList[index] + " % ");
        });
      }else{
        this.barChartData3.push(String(0));
      }

      // keys - 50 to 60 percentage data with appliance names.
      if (this.contextDetailsData.sixtyPercentList.length > 0) {
        let percentageList = this.contextDetailsData.sixtyPercentList.map(item => item.percentage);
        let applianceList = this.contextDetailsData.sixtyPercentList.map(item => item.applianceDetailModel.applianceName);
        this.barChartData3.push(applianceList.length);
        applianceList.forEach((item, index) => {
          this.sixtySSLCtxtList.push(item + " : " + percentageList[index] + " % ");
        });
      }else{
        this.barChartData3.push(String(0));
      }
      // keys - 60 to 70 percentage data with appliance names.
      if (this.contextDetailsData.seventyPercentList.length > 0) {
        let percentageList = this.contextDetailsData.seventyPercentList.map(item => item.percentage);
        let applianceList = this.contextDetailsData.seventyPercentList.map(item => item.applianceDetailModel.applianceName);
        this.barChartData3.push(applianceList.length);
        applianceList.forEach((item, index) => {
          this.seventySSLCtxtList.push(item + " : " + percentageList[index] + " % ");
        });
      }else{
        this.barChartData3.push(String(0));
      }

      // keys - 70 to 80 percentage data with appliance names.
      if (this.contextDetailsData.eightyPercentList.length > 0) {
        let percentageList = this.contextDetailsData.eightyPercentList.map(item => item.percentage);
        let applianceList = this.contextDetailsData.eightyPercentList.map(item => item.applianceDetailModel.applianceName);
        this.barChartData3.push(applianceList.length);
        applianceList.forEach((item, index) => {
          this.eightySSLCtxtList.push(item + " : " + percentageList[index] + " % ");
        });
      }else{
        this.barChartData3.push(String(0));
      }
      // keys - 80 to 90 percentage data with appliance names.
      if (this.contextDetailsData.ninetyPercentList.length > 0) {
        let percentageList = this.contextDetailsData.ninetyPercentList.map(item => item.percentage);
        let applianceList = this.contextDetailsData.ninetyPercentList.map(item => item.applianceDetailModel.applianceName);
        this.barChartData3.push(applianceList.length);
        applianceList.forEach((item, index) => {
          this.ninetySSLCtxtList.push(item + " : " + percentageList[index] + " % ");
        });
      }else{
        this.barChartData3.push(String(0));
      }
      // keys - 90 to 100 percentage data with appliance names.
      if (this.contextDetailsData.hundredPercentList.length > 0) {
        let percentageList = this.contextDetailsData.hundredPercentList.map(item => item.percentage);
        let applianceList = this.contextDetailsData.hundredPercentList.map(item => item.applianceDetailModel.applianceName);
        this.barChartData3.push(applianceList.length);
        applianceList.forEach((item, index) => {
          this.hundredSSLCtxtList.push(item + " : " + percentageList[index] + " % ");
        });
      }else{
        this.barChartData3.push(String(0));
      }
    }
  }

  //SSL Contexts bar chart options.
  public barChartOptionsSSLContexts: any = {
    scaleShowVerticalLines: false,
    responsive: true,
    legend: {
      display: true,
    },
    scales: {
      yAxes: [{
        ticks: {
          min: 0, // it is for ignoring negative step.
          beginAtZero: true,
          callback: function (value, index, values) {
            if (Math.floor(value) === value) {
              return value;
            }
          }
        },
        scaleLabel: {
          display: true,
          labelString: 'No. of Appliances',
          fontStyle: 'bold'
        }
      }],
      xAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'SSL Contexts Percentage',
          fontStyle: 'bold'
        }
      }],
    },
    tooltips: {
      callbacks: {
        label: (tooltipItem, data) => {
          return '';
        },
        title: (items, data) => {
          let graphData: any;
          if (items[0].index == 1) {
            if (this.tenSSLCtxtList.length > 0) {
              graphData = this.tenSSLCtxtList;
            }
          } else if (items[0].index == 2) {
            if (this.twentySSLCtxtList.length > 0) {
              graphData = this.twentySSLCtxtList;
            }
          } else if (items[0].index == 3) {
            if (this.thirtySSLCtxtList.length > 0) {
              graphData = this.thirtySSLCtxtList;
            }

          } else if (items[0].index == 4) {
            if (this.fourtySSLCtxtList.length > 0) {
              graphData = this.fourtySSLCtxtList;
            }
          } else if (items[0].index == 5) {
            if (this.fiftySSLCtxtList.length > 0) {
              graphData = this.fiftySSLCtxtList;
            }

          } else if (items[0].index == 6) {
            if (this.sixtySSLCtxtList.length > 0) {
              graphData = this.sixtySSLCtxtList;
            }
          } else if (items[0].index == 7) {
            if (this.seventySSLCtxtList.length > 0) {
              graphData = this.seventySSLCtxtList;
            }

          } else if (items[0].index == 8) {
            if (this.eightySSLCtxtList.length > 0) {
              graphData = this.eightySSLCtxtList;
            }

          } else if (items[0].index == 9) {
            if (this.ninetySSLCtxtList.length > 0) {
              graphData = this.ninetySSLCtxtList;
            }

          } else if (items[0].index == 10) {
            if (this.hundredSSLCtxtList.length > 0) {
              graphData = this.hundredSSLCtxtList;
            }
          }
          return graphData;
        }
      }
    }
  };

  public barChartType1: string = 'bar';
  public barChartLegend1: boolean = false;

  //Keys Bar chart 

  public barChartLabels1: string[] = ['', '0-10', '10-20', '20-30', '30-40', '40-50', '50-60', '60-70', '70-80', '80-90', '90-100'];
  public barChartData1: any[] = [
  ];
  public mycolors1: Array<Color> = [
    {
      backgroundColor: ['rgb(255,128,0)', 'rgb(255,128,0)', 'rgb(255,128,0)', 'rgb(255,128,0)', 'rgb(255,128,0)',
        'rgb(255,128,0)', 'rgb(255,128,0)', 'rgb(255,128,0)', 'rgb(255,128,0)', 'rgb(255,128,0)', 'rgb(255,128,0)'],
    }
  ];

  //Acceleration Devices Bar chart 

  public barChartLabels2: string[] = ['', '0-10', '10-20', '20-30', '30-40', '40-50', '50-60', '60-70', '70-80', '80-90', '90-100'];
  public barChartData2: any[] = [
  ];
  public mycolors2: Array<Color> = [
    {
      backgroundColor: ['rgb(84, 198, 233)', 'rgb(84, 198, 233)', 'rgb(84, 198, 233)', 'rgb(84, 198, 233)', 'rgb(84, 198, 233)'
        , 'rgb(84, 198, 233)', 'rgb(84, 198, 233)', 'rgb(84, 198, 233)', 'rgb(84, 198, 233)', 'rgb(84, 198, 233)', 'rgb(84, 198, 233)']
    }
  ];

  //SSL Contexts Bar chart 

  public barChartLabels3: string[] = ['', '0-10', '10-20', '20-30', '30-40', '40-50', '50-60', '60-70', '70-80', '80-90', '90-100'];

  public barChartData3: any[] = [
  ];

  public mycolors3: Array<Color> = [
    {
      backgroundColor: ['rgb(255,51,51)', 'rgb(255,51,51)', 'rgb(255,51,51)', 'rgb(255,51,51)', 'rgb(255,51,51)'
        , 'rgb(255,51,51)', 'rgb(255,51,51)', 'rgb(255,51,51)', 'rgb(255,51,51)', 'rgb(255,51,51)', 'rgb(255,51,51)'],
    }
  ];


  //Status Donut chart 
  public doughnutChartData1: number[] = [];
  public doughnutChartLabels1: string[] = ['Functional Partition', 'Non-Functional Partition'];
  public mycolorsDC1: Array<Color> = [
    {
      backgroundColor: [
        'rgb(255,255,25)',
        'rgb(0,179,30)'],
      hoverBackgroundColor: ['rgb(255,255,25)', 'rgb(0,179,30)'],
    }
  ];


  //FIPS Status Donut chart 
  public doughnutChartData2: number[] = [];
  public doughnutChartLabels2: string[] = ['Zeroized State', 'FIPS mode', 'FIPS mode with 2 factor authorization', 'Non-FIPS mode'];
  public mycolorsDC2: Array<Color> = [
    {
      backgroundColor: [
        'rgb(255,51,51)',
        'rgb(255,255,25)',
        'rgb(84, 198, 233)',
        'rgb(0,179,30)'],
      hoverBackgroundColor: ['rgb(255,51,51)', 'rgb(255,255,25)', 'rgb(84, 198, 233)', 'rgb(0,179,30)'],
    }
  ];

  getInProgressActivity() {
    this.getProgressActivities = this._partitionManagementService.getInProgressActivities().subscribe(
      res => {
        this.inProgressActivityList = res
      }
    );
    this.getTimeIntervalData();
  }

  private getTimeIntervalData(): void {
    this.timer = Observable.timer(15000).first().subscribe(() => this.getInProgressActivity());

  }
  public ngOnDestroy(): void {
    if (this.timer) {
      this.timer.unsubscribe();
    }
  }
}



