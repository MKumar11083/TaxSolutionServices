import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PartitionSnapshotComponent } from './partition-snapshot.component';

describe('PartitionSnapshotComponent', () => {
  let component: PartitionSnapshotComponent;
  let fixture: ComponentFixture<PartitionSnapshotComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PartitionSnapshotComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PartitionSnapshotComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
