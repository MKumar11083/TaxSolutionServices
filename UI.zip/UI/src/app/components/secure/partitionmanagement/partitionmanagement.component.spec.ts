import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PartitionmanagementComponent } from './partitionmanagement.component';

describe('PartitionmanagementComponent', () => {
  let component: PartitionmanagementComponent;
  let fixture: ComponentFixture<PartitionmanagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PartitionmanagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PartitionmanagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
