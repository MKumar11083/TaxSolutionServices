import { Component, OnInit, ViewChild, Output, EventEmitter, TemplateRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, FormControl, FormArray } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { TabDirective } from 'ngx-bootstrap/tabs';
import { TabsetComponent } from 'ngx-bootstrap';
import { Router } from '@angular/router';
import { PartitionOperationsComponent } from './../partition-operations/partition-operations.component';
import { PartitionManagementService } from './../../../../services/partitionmanagement/partitionmanagement.service';
declare var $: any;
@Component({
  selector: 'app-configure-network',
  templateUrl: './configure-network.component.html',
  styleUrls: ['./configure-network.component.css']

})
export class ConfigureNetworkComponent implements OnInit {
  @ViewChild('configureNetworkModal') configureNetworkModal: ModalDirective;
  @ViewChild('staticTabs') staticTabs: TabsetComponent;
  @ViewChild('partitionOperationsComponent')
  private partitionOperationsComponent: PartitionOperationsComponent;
  @Output() messageEvent1 = new EventEmitter<any>();
  form: FormGroup;
  addAdvanced: FormGroup;
  tab: string;
  staticHostIp = [];
  dnsServers = [];
  domainNames = [];
  displayError: string;
  displayError1: string;
  successMessage: string;
  classStatic: string;
  classServer: string;
  classDomain: string;
  partitionCount: number = 1;
  totalPartitionCount: number = 0;
  selectedPartitionList = [];
  partitionName: string;
  showEth0: boolean = true;
  showEth1: boolean = true;
  finalPartitionList = [];
  isDNSserverChecked: boolean = false;
  showBackButton = false;
  tabName: string = "";
  showFinalPartitionList: boolean = false;
  state: string = 'inactive';
  isEth0IpValidate = false;
  isEth1IpValidate = false;
  eth0MacAddress = false;
  eth1MacAddress = false;
  constructor(private _fieldErrorDisplayService: FieldErrorDisplayService,
    private router: Router,
    private builder: FormBuilder,
    private _service: PartitionManagementService
  ) {
  }
  ngOnInit() {
    this.createForm();
    this.initItemRows(null, null, null);
    this.tab = "1";
  }
  createForm() {
    this.form = this.builder.group({
      partitionId: [''],
      partitionName: [''],
      csr: [null],
      keys: [],
      sslContexts: [],
      acclrDev: [],
      wrap: ['', Validators.required],
      backup: ['', Validators.required],
      sessionClose: [''],
      applianceDetailModel: this.builder.group({
        applianceId: [null],
        applianceName: [null],
        applianceStatus: [null],
        serialNumber: [null],
        networkTimezone: [null],
        gatewayIp: [null],
        ipAddress: [null],
        networkId: [null],
        subnetMask: [null],
      }),
      networkStats: this.builder.group({
        general: this.builder.group({
          partitionName: ['', Validators.required],
          dnsService: [false],
          eth0: this.builder.group({
            ethName: ['eth0'],
            dhcp: [true],
            ip: [null],
            gateway: [null],
            subnet: [null],
            hostname: [null],
            staticMac: [true],
            address: [null],
            vlan: [null],
          }),
          eth1: this.builder.group({
            ethName: ['eth1'],
            dhcp: [true],
            disableEth1: [true],
            ip: [null],
            gateway: [null],
            subnet: [null],
            staticMac: [true],
            address: [null],
            vlan: [null],
            id: [null],
          })
        }),
        advanced: this.builder.group({
          staticIpToHostConfig: this.builder.group({
            add: new FormArray([]),

          }),
          dnsConfig: this.builder.group({
            dnsServers: new FormArray([]),
            searchDomainNames: new FormArray([]),
            enableService: [false]
          }),
          ip: [''],
          hostname: [''],
          alias: [''],
          id: [''],
          dnsServer: [''],
          searchDomainName: ['']
        })
      }),
      partitionCertificate: [null],
      errorMessage: [null],
      username: [null],
      password: [null]
    });
  }

  initItemRows(ip, hostname, alias) {
    return this.addAdvanced = this.builder.group({
      ip: ip,
      hostname: hostname,
      alias: alias,
      id: [null]
    });

  }

  // create a form errors
  public formValidationFields = {
    "partitionName": '',
    "csr": '',
    "keys": '',
    "sslContexts": '',
    "acclrDev": '',
    "wrap": '',
    "backup": ''
  }

  isFieldValid(field: string) {
    if (this.form.get(field).touched) {
      this.formValidationFields = this._fieldErrorDisplayService.validateField(this.form, field, this.formValidationFields, "createPartition")
    }
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  selectTab(tab_id: string) {
    if (tab_id == "1") {
      this.classStatic = "btn-primary";
      this.classServer = "btn-default";
      this.classDomain = "btn-default";
    } else if (tab_id == "2") {
      this.classStatic = "btn-default";
      this.classServer = "btn-primary";
      this.classDomain = "btn-default";
    } else if (tab_id == "3") {
      this.classStatic = "btn-default";
      this.classServer = "btn-default";
      this.classDomain = "btn-primary";
    }
    this.tab = tab_id;
    this.displayError = "";
  }
  networkData: any;
  showConfigureNetworkModal(partitionList) {
    this.isEth0IpValidate = false;
    this.isEth1IpValidate = false;
    this.eth0MacAddress = false;
    this.eth1MacAddress = false;
    this.clearData();
    this.tab = "1";
    this.classStatic = "btn-primary";
    this.classServer = "btn-default";
    this.classDomain = "btn-default";
    this.selectedPartitionList = partitionList;
    this.totalPartitionCount = this.selectedPartitionList.length;
    this.isDNSserverChecked=true;
    // take the first record from the partitionlist to preload the data in modal.
    let count = this.partitionCount - 1;
    let partitionData = this.selectedPartitionList[count];
    // get Network stats details
    this._service.getPartitionNetworkStats(partitionData.partitionId).subscribe(
      response => {
        this.networkData = null;
        this.networkData = JSON.parse(response.message);
        console.log(this.networkData);
        this.setPartitionDataToForm(partitionData, this.networkData);
        this.partitionName = partitionData['partitionName'];
        this.configureNetworkModal.show();
      },
      error => {
        console.log(error);
      }
    )

  }

  nextConfigureNetwork() {
    this.isEth0IpValidate = false;
    this.isEth1IpValidate = false;
    this.eth0MacAddress = false;
    this.eth1MacAddress = false;
    this.isDNSserverChecked=true;
    // this.form.get('networkStats.general.eth1.dhcp').enable();
    // this.form.get('networkStats.general.eth1.staticMac').enable();
    // this.form.get('networkStats.general.eth1.address').enable();
    // this.form.get('networkStats.general.eth1.vlan').enable();
    let eth0DHCP = this.form.get('networkStats.general.eth0.dhcp').value;
    if (!eth0DHCP) {
      if (this.form.get('networkStats.general.eth0.ip').value == null || this.form.get('networkStats.general.eth0.ip').value == '') {
        this.isEth0IpValidate = true;
      }
    }
   
    let eth0StaticMac = this.form.get('networkStats.general.eth0.staticMac').value;
    if (eth0StaticMac) {
      if (this.form.get('networkStats.general.eth0.address').value == null || this.form.get('networkStats.general.eth0.address').value == '') {
        this.eth0MacAddress = true;
      }
    }
    
    let disableEth1 = this.form.get('networkStats.general.eth1.disableEth1').value;
    if (!this.isEth0IpValidate) {
      if (!this.eth0MacAddress) {
        if (disableEth1) {
          let eth1DHCP = this.form.get('networkStats.general.eth1.dhcp').value;
          if (!eth1DHCP) {
            if (this.form.get('networkStats.general.eth1.ip').value == null || this.form.get('networkStats.general.eth1.ip').value == '') {
              this.isEth1IpValidate = true;
            }
          }
          if (!this.isEth1IpValidate) {
            if (!this.eth1MacAddress) {
              let eth1StaticMac = this.form.get('networkStats.general.eth1.staticMac').value;
              if (eth1StaticMac) {
                if (this.form.get('networkStats.general.eth1.address').value == null || this.form.get('networkStats.general.eth1.address').value == '') {
                  this.eth1MacAddress = true;
                }
              }
                $("#network").fadeOut(20);
                if (typeof this.finalPartitionList[this.partitionCount - 1] === 'undefined') {
                  this.pushPartitionDataIntoList();
                } else {
                  if(this.form.get('networkStats.general.eth0.dhcp').value){
                    this.form.get('networkStats.general.eth0.ip').reset();
                    this.form.get('networkStats.general.eth0.gateway').reset();
                    this.form.get('networkStats.general.eth0.subnet').reset();
                  }
                  if(this.form.get('networkStats.general.eth1.dhcp').value){
                    this.form.get('networkStats.general.eth1.ip').reset();
                    this.form.get('networkStats.general.eth1.subnet').reset();
                  }
                  if(this.form.get('networkStats.general.eth0.staticMac').value==false){
                    this.form.get('networkStats.general.eth0.address').reset();
                  }
                  if(this.form.get('networkStats.general.eth1.staticMac').value==false){
                    this.form.get('networkStats.general.eth1.address').reset();
                  }
                  if(!this.form.get('networkStats.general.eth1.disableEth1').value){
                    this.form.get('networkStats.general.eth1.dhcp').reset();
                    this.form.get('networkStats.general.eth1.ip').reset();
                    this.form.get('networkStats.general.eth1.subnet').reset();
                    this.form.get('networkStats.general.eth1.staticMac').reset();
                    this.form.get('networkStats.general.eth1.address').reset();
                    this.form.get('networkStats.general.eth1.disableEth1').setValue(true);
                  }else{
                    this.form.get('networkStats.general.eth1.disableEth1').setValue(false);
                  }
                  this.finalPartitionList[this.partitionCount - 1] = this.form.value;
                }
                if (this.partitionCount < this.selectedPartitionList.length) {
                  this.form.reset();
                  //this.partitionName = this.selectedPartitionList[this.partitionCount]['partitionName'];
                  let partitionData = this.selectedPartitionList[this.partitionCount];
                  // get Network stats details
                  this._service.getPartitionNetworkStats(partitionData.partitionId).subscribe(
                    response => {
                      this.networkData = null;
                      this.networkData = JSON.parse(response.message);
                      this.setPartitionDataToForm(partitionData, JSON.parse(response.message));
                      this.partitionName = partitionData['partitionName'];
                      this.partitionCount = this.partitionCount + 1;
                      this.isDNSserverChecked = false;
                      this.showBackButton = true;
                    },
                    error => {
                      console.log(error);
                    }
                  )
                  // this.setPartitionDataToForm(partitionData);


                } else {
                  this.form.reset();
                  this.displayError = '';
                  this.showFinalPartitionList = true;
                }
                $("#network").fadeIn("slow");
              
            }
          }
        }else{
            $("#network").fadeOut(20);
            if (typeof this.finalPartitionList[this.partitionCount - 1] === 'undefined') {
              this.pushPartitionDataIntoList();
            } else {
              if(this.form.get('networkStats.general.eth0.dhcp').value){
                this.form.get('networkStats.general.eth0.ip').reset();
                this.form.get('networkStats.general.eth0.gateway').reset();
                this.form.get('networkStats.general.eth0.subnet').reset();
              }
              if(this.form.get('networkStats.general.eth1.dhcp').value){
                this.form.get('networkStats.general.eth1.ip').reset();
                this.form.get('networkStats.general.eth1.subnet').reset();
              }
              if(this.form.get('networkStats.general.eth0.staticMac').value==false){
                this.form.get('networkStats.general.eth0.address').reset();
              }
              if(this.form.get('networkStats.general.eth1.staticMac').value==false){
                this.form.get('networkStats.general.eth1.address').reset();
              }
              if(!this.form.get('networkStats.general.eth1.disableEth1').value){
                this.form.get('networkStats.general.eth1.dhcp').reset();
                this.form.get('networkStats.general.eth1.ip').reset();
                this.form.get('networkStats.general.eth1.subnet').reset();
                this.form.get('networkStats.general.eth1.staticMac').reset();
                this.form.get('networkStats.general.eth1.address').reset();
                this.form.get('networkStats.general.eth1.disableEth1').setValue(true);
              }else{
                this.form.get('networkStats.general.eth1.disableEth1').setValue(false);
              }
              this.finalPartitionList[this.partitionCount - 1] = this.form.value;
            }
            if (this.partitionCount < this.selectedPartitionList.length) {
              this.form.reset();
              //this.partitionName = this.selectedPartitionList[this.partitionCount]['partitionName'];
              let partitionData = this.selectedPartitionList[this.partitionCount];
              // get Network stats details
              this._service.getPartitionNetworkStats(partitionData.partitionId).subscribe(
                response => {
                  this.networkData = null;
                  this.networkData = JSON.parse(response.message);
                  this.setPartitionDataToForm(partitionData, JSON.parse(response.message));
                  this.partitionName = partitionData['partitionName'];
                  this.partitionCount = this.partitionCount + 1;
                  this.isDNSserverChecked = false;
                  this.showBackButton = true;
                },
                error => {
                  console.log(error);
                }
              )
              // this.setPartitionDataToForm(partitionData);


            } else {
              this.form.reset();
              this.displayError = '';
              this.showFinalPartitionList = true;
            }
            $("#network").fadeIn("slow");

        }
      }
    }

  }

  pushPartitionDataIntoList() {
    debugger;
    if(this.form.get('networkStats.general.eth0.dhcp').value){
      this.form.get('networkStats.general.eth0.ip').reset();
      this.form.get('networkStats.general.eth0.gateway').reset();
      this.form.get('networkStats.general.eth0.subnet').reset();
    }
    if(this.form.get('networkStats.general.eth1.dhcp').value){
      this.form.get('networkStats.general.eth1.ip').reset();
      this.form.get('networkStats.general.eth1.subnet').reset();
    }
    if(this.form.get('networkStats.general.eth0.staticMac').value==false){
      this.form.get('networkStats.general.eth0.address').reset();
    }
    if(this.form.get('networkStats.general.eth1.staticMac').value==false){
      this.form.get('networkStats.general.eth1.address').reset();
    }
    if(!this.form.get('networkStats.general.eth1.disableEth1').value){
      this.form.get('networkStats.general.eth1.dhcp').reset();
      this.form.get('networkStats.general.eth1.ip').reset();
      this.form.get('networkStats.general.eth1.subnet').reset();
      this.form.get('networkStats.general.eth1.staticMac').reset();
      this.form.get('networkStats.general.eth1.address').reset();
      this.form.get('networkStats.general.eth1.disableEth1').setValue(true);
    }else{
      this.form.get('networkStats.general.eth1.disableEth1').setValue(false);
    }
    // let staticIpData= this.form.get('networkStats.advanced.staticIpToHostConfig.add').value;
    // if (staticIpData != null) {
    //   this.form.get('networkStats.advanced.staticIpToHostConfig.add').reset();
    //   staticIpData.forEach(staticIpObj => {
    //     if(staticIpObj.ip!=null){
    //       const control = <FormArray>this.form.get('networkStats').get('advanced').get('staticIpToHostConfig').get('add');
    //       control.push(staticIpObj);
    //     }
       
    //   });
    // }
    this.finalPartitionList.push(this.form.value);
  }


  setPartitionDataToForm(partitionData, networkData) {
    this.form.get('username').patchValue(partitionData.username);
    this.form.get('password').patchValue(partitionData.password);
    this.form.get('partitionId').patchValue(partitionData.partitionId);
    this.form.get('networkStats.general.partitionName').patchValue(partitionData.partitionName);
    this.form.get('partitionName').patchValue(partitionData.partitionName);
    this.form.get('csr').patchValue(partitionData.csr);
    this.form.get('keys').patchValue(partitionData.keys);
    this.form.get('sslContexts').patchValue(partitionData.sslContexts);
    this.form.get('acclrDev').patchValue(partitionData.acclrDev);
    this.form.get('wrap').patchValue(partitionData.wrap);
    this.form.get('backup').patchValue(partitionData.backup);
    this.form.get('sessionClose').patchValue(partitionData.sessionClose);
    this.form.get('applianceDetailModel.applianceId').patchValue(partitionData.applianceDetailModel.applianceId);
    this.form.get('applianceDetailModel.applianceName').patchValue(partitionData.applianceDetailModel.applianceName);
    this.form.get('applianceDetailModel.ipAddress').patchValue(partitionData.applianceDetailModel.ipAddress);
    const control = <FormControl>this.form.get('networkStats').get('advanced').
    get('dnsConfig').get('enableService');
  control.setValue(false);
    // setting network details 
    if (networkData != null) {
      if (networkData.general != null) {
        this.form.get('networkStats.general.eth0.ethName').patchValue('eth0');
        this.form.get('networkStats.general.eth1.ethName').patchValue('eth1');
        if (networkData.general.eth0 != null) {
          if (networkData.general.eth0.dhcp != null) {
            this.form.get('networkStats.general.eth0.dhcp').patchValue(networkData.general.eth0.dhcp);
          }

          if (networkData.general.eth0.ip != null) {
            this.form.get('networkStats.general.eth0.ip').patchValue(networkData.general.eth0.ip);
          }
          if (networkData.general.eth0.gateway != null) {
            this.form.get('networkStats.general.eth0.gateway').patchValue(networkData.general.eth0.gateway);
          }
          if (networkData.general.eth0.subnet != null) {
            this.form.get('networkStats.general.eth0.subnet').patchValue(networkData.general.eth0.subnet);
          }
          if (networkData.general.eth0.hostname != null) {
            this.form.get('networkStats.general.eth0.hostname').patchValue(networkData.general.eth0.hostname);
          }
          if (networkData.general.eth0.macStatic != null) {
            if (networkData.general.eth0.macStatic) {
              this.form.get('networkStats.general.eth0.staticMac').patchValue(networkData.general.eth0.macStatic);
              this.form.get('networkStats.general.eth0.address').enable();
            } else {
              this.form.get('networkStats.general.eth0.staticMac').patchValue(networkData.general.eth0.macStatic);
              this.form.get('networkStats.general.eth0.address').disable();
            }
          }
          if (networkData.general.eth0.mac != null) {
            this.form.get('networkStats.general.eth0.address').patchValue(networkData.general.eth0.mac);
          }
          this.form.get('networkStats.general.eth0.vlan').patchValue(networkData.general.eth0.vlan);
        }
        this.form.get('networkStats.general.eth1.disableEth1').setValue(true);
        if (networkData.general.eth1 != null) {
         
          if (networkData.general.eth1.dhcp) {
            this.form.get('networkStats.general.eth1.ip').disable();
            this.form.get('networkStats.general.eth1.subnet').disable();
          } else {
            this.form.get('networkStats.general.eth1.ip').enable();
            this.form.get('networkStats.general.eth1.subnet').enable();
          }
          if (networkData.general.eth1.dhcp != null) {
            this.form.get('networkStats.general.eth1.dhcp').patchValue(networkData.general.eth1.dhcp);
          }
          if (networkData.general.eth1.ip != null) {
            this.form.get('networkStats.general.eth1.ip').patchValue(networkData.general.eth1.ip);
          }
          if (networkData.general.eth1.subnet != null) {
            this.form.get('networkStats.general.eth1.subnet').patchValue(networkData.general.eth1.subnet);
          }
          if (networkData.general.eth1.macStatic != null && networkData.general.eth1.macStatic != null) {
            if (networkData.general.eth1.macStatic) {
              this.form.get('networkStats.general.eth1.staticMac').patchValue(networkData.general.eth1.macStatic);
              this.form.get('networkStats.general.eth1.address').enable();
            } else {
              this.form.get('networkStats.general.eth1.staticMac').patchValue(networkData.general.eth1.macStatic);
              this.form.get('networkStats.general.eth1.address').disable();
            }
          }
          if (networkData.general.eth1.mac != null && networkData.general.eth1.mac != '') {
            this.form.get('networkStats.general.eth1.address').setValue(networkData.general.eth1.mac);
          }
          this.form.get('networkStats.general.eth1.vlan').patchValue(networkData.general.eth1.vlan);
        }
      }
      debugger;
      const control = <FormArray>this.form.get('networkStats').get('advanced').get('staticIpToHostConfig').get('add');
      control.controls=[];

      const control1 = <FormArray>this.form.get('networkStats').get('advanced').
      get('dnsConfig').get('dnsServers');

      const control2 = <FormArray>this.form.get('networkStats').get('advanced').
      get('dnsConfig').get('searchDomainNames');
      control2.controls=[];
      control1.controls=[];
      if (networkData.advanced != null) {
        if (networkData.advanced.staticIpToHostConfig.length > 0) {
          if (networkData.advanced.staticIpToHostConfig != null) {
            let staticIpHost = networkData.advanced.staticIpToHostConfig;
           
            staticIpHost.forEach(staticIpObj => {
              let ip = staticIpObj.ip;
              let hostname = staticIpObj.hostname;
              let alias = staticIpObj.alias;
              const control = <FormArray>this.form.get('networkStats').get('advanced').get('staticIpToHostConfig').get('add');
              let staticHostIpData = {};
              staticHostIpData['ip'] = ip;
              staticHostIpData['hostname'] = hostname;
              staticHostIpData['alias'] = alias;
              control.push(this.initItemRows(ip, hostname, alias));
              this.staticHostIp.push(staticHostIpData);
            });
          }
        }

        if (networkData.advanced.dnsConfig != null) {
          if (networkData.advanced.dnsConfig.dnsServers != null && networkData.advanced.dnsConfig.dnsServers != '') {
            let tempDnsServers = networkData.advanced.dnsConfig.dnsServers;
            tempDnsServers.forEach(dnsServer => {
              if (dnsServer != null && dnsServer != '') {
                this.dnsServers.push(dnsServer);
                const control = <FormArray>this.form.get('networkStats').get('advanced').
                  get('dnsConfig').get('dnsServers');
                control.push(new FormControl(dnsServer));
              }

            });
          }
          if (networkData.advanced.dnsConfig.searchDomainNames != null && networkData.advanced.dnsConfig.searchDomainNames != '') {
            let tempDomainNames = networkData.advanced.dnsConfig.searchDomainNames;
            tempDomainNames.forEach(domainName => {
              if (domainName != null && domainName != '') {
                this.domainNames.push(domainName);
                const control = <FormArray>this.form.get('networkStats').get('advanced').
                  get('dnsConfig').get('searchDomainNames');
                control.push(new FormControl(domainName));
              }

            });
          }
        }
      }
    }
  }

  // back Operation fetchs previous appliance data.
  backToPreviousPartition() {
    $("#network").fadeOut(20);
    this.form.reset();
    this.displayError = '';
    this.displayError1 = '';
    this.partitionName = this.selectedPartitionList[this.partitionCount - 2]['partitionName'];
    let backOperationCount = this.partitionCount - 2;
    let partitionData = this.finalPartitionList[backOperationCount];
    this.setPartitionDataToFormForBackOperation(partitionData);
    this.partitionCount = this.partitionCount - 1;
    if (this.partitionCount == 1) {
      this.showBackButton = false;
    }
    this.staticTabs.tabs[0].active = true;
    this.tabName = "General";
    $("#network").fadeIn("slow");
  }
  // Back Operation in Final list of appliance.
  backOperationFromFinalList() {
    $("#network").fadeOut(20);
    this.form.reset();
    this.displayError = '';
    this.displayError1 = '';
    this.partitionName = this.finalPartitionList[this.partitionCount - 1]['partitionName'];
    let partitionData = this.finalPartitionList[this.partitionCount - 1];
    this.setPartitionDataToFormForBackOperation(partitionData);
    if (this.partitionCount == 1) {
      this.showBackButton = false;
    } else {
      //this.applianceCount = this.applianceCount - 1;
      this.showBackButton = true;
    }
    this.showFinalPartitionList = false;
    this.tabName = "General";
    $("#network").fadeIn("slow");
  }
  // set data for back operation
  setPartitionDataToFormForBackOperation(partitionData) {
    this.form.get('username').patchValue(partitionData.username);
    this.form.get('password').patchValue(partitionData.password);
    this.form.get('partitionId').patchValue(partitionData.partitionId);
    this.form.get('networkStats.general.partitionName').patchValue(partitionData.partitionName);
    this.form.get('partitionName').patchValue(partitionData.partitionName);
    this.form.get('csr').patchValue(partitionData.csr);
    this.form.get('keys').patchValue(partitionData.keys);
    this.form.get('sslContexts').patchValue(partitionData.sslContexts);
    this.form.get('acclrDev').patchValue(partitionData.acclrDev);
    this.form.get('wrap').patchValue(partitionData.wrap);
    this.form.get('backup').patchValue(partitionData.backup);
    this.form.get('sessionClose').patchValue(partitionData.sessionClose);
    this.form.get('applianceDetailModel.applianceId').patchValue(partitionData.applianceDetailModel.applianceId);
    this.form.get('applianceDetailModel.applianceName').patchValue(partitionData.applianceDetailModel.applianceName);
    this.form.get('applianceDetailModel.ipAddress').patchValue(partitionData.applianceDetailModel.ipAddress);

    // setting network details 
    if (partitionData.networkStats != null) {
      if (partitionData.networkStats.general != null) {

        this.form.get('networkStats.general.eth0.ethName').patchValue('eth0');
        this.form.get('networkStats.general.eth1.ethName').patchValue('eth1');
        if (partitionData.networkStats.general.eth0 != null) {
          this.form.get('networkStats.general.eth0.dhcp').patchValue(true);
          if (partitionData.networkStats.general.eth0.ip != "null") {
            this.form.get('networkStats.general.eth0.ip').patchValue(partitionData.networkStats.general.eth0.ip);
          }
          if (partitionData.networkStats.general.eth0.gateway != "null") {
            this.form.get('networkStats.general.eth0.gateway').patchValue(partitionData.networkStats.general.eth0.gateway);
          }
          if (partitionData.networkStats.general.eth0.subnet != "null") {
            this.form.get('networkStats.general.eth0.subnet').patchValue(partitionData.networkStats.general.eth0.subnet);
          }
          if (partitionData.networkStats.general.eth0.hostname != "null") {
            this.form.get('networkStats.general.eth0.hostname').patchValue(partitionData.networkStats.general.eth0.hostname);
          }
          if (partitionData.networkStats.general.eth0.staticMac != null) {
            if (partitionData.networkStats.general.eth0.staticMac) {
              this.form.get('networkStats.general.eth0.staticMac').patchValue(partitionData.networkStats.general.eth0.staticMac);
              this.form.get('networkStats.general.eth0.address').enable();
            } else {
              this.form.get('networkStats.general.eth0.staticMac').patchValue(partitionData.networkStats.general.eth0.staticMac);
              this.form.get('networkStats.general.eth0.address').disable();
            }
          }
          if (partitionData.networkStats.general.eth0.address != "null") {
            this.form.get('networkStats.general.eth0.address').patchValue(partitionData.networkStats.general.eth0.address);
          }
          this.form.get('networkStats.general.eth0.vlan').patchValue(partitionData.networkStats.general.eth0.vlan);
        }
        if (partitionData.networkStats.general.eth1 != "null") {
          // if (partitionData.networkStats.general.eth1.disableEth1) {
          //   //this.form.get('networkStats.general.eth1.disableEth1').patchValue(true);
          // } else {
          //   //this.form.get('networkStats.general.eth1.disableEth1').patchValue(false);
          //   this.form.get('networkStats.general.eth1.dhcp').disable();
          //   this.form.get('networkStats.general.eth1.ip').disable();
          //   this.form.get('networkStats.general.eth1.subnet').disable();
          //   this.form.get('networkStats.general.eth1.staticMac').disable();
          //   this.form.get('networkStats.general.eth1.address').disable();
          //   this.form.get('networkStats.general.eth1.vlan').disable();

          // }
          this.form.get('networkStats.general.eth1.disableEth1').patchValue(partitionData.networkStats.general.eth1.disableEth1);
          if (partitionData.networkStats.general.eth1.dhcp) {
            this.form.get('networkStats.general.eth1.ip').disable();
            this.form.get('networkStats.general.eth1.subnet').disable();
          } else {
            this.form.get('networkStats.general.eth1.ip').enable();
            this.form.get('networkStats.general.eth1.subnet').enable();
          }
          this.form.get('networkStats.general.eth1.dhcp').patchValue(true);
          if (partitionData.networkStats.general.eth1.ip != null) {
            this.form.get('networkStats.general.eth1.ip').patchValue(partitionData.networkStats.general.eth1.ip);
          }
          if (partitionData.networkStats.general.eth1.subnet != null) {
            this.form.get('networkStats.general.eth1.subnet').patchValue(partitionData.networkStats.general.eth1.subnet);
          }
          if (partitionData.networkStats.general.eth1.staticMac != null && partitionData.networkStats.general.eth1.staticMac != null) {
            if (partitionData.networkStats.general.eth1.staticMac) {
              this.form.get('networkStats.general.eth1.staticMac').patchValue(partitionData.networkStats.general.eth1.staticMac);
              this.form.get('networkStats.general.eth1.address').enable();
            } else {
              this.form.get('networkStats.general.eth1.staticMac').patchValue(partitionData.networkStats.general.eth1.staticMac);
              this.form.get('networkStats.general.eth1.address').disable();
            }
          }
          if (partitionData.networkStats.general.eth1.address != null && partitionData.networkStats.general.eth1.address != null && partitionData.networkStats.general.eth1.address != '') {
            this.form.get('networkStats.general.eth1.address').setValue(partitionData.networkStats.general.eth1.address);
          }
          this.form.get('networkStats.general.eth1.vlan').patchValue(partitionData.networkStats.general.eth1.vlan);
        }
      }

      if (partitionData.networkStats.advanced != null) {
        if (partitionData.networkStats.advanced.staticIpToHostConfig != null) {
          if (partitionData.networkStats.advanced.staticIpToHostConfig.add != null) {
            let staticIpHost = partitionData.networkStats.advanced.staticIpToHostConfig.add;
            staticIpHost.forEach(staticIpObj => {
              let ip = staticIpObj.ip;
              let hostname = staticIpObj.hostname;
              let alias = staticIpObj.alias;
              const control = <FormArray>this.form.get('networkStats').get('advanced').get('staticIpToHostConfig').get('add');
              let staticHostIpData = {};
              staticHostIpData['ip'] = ip;
              staticHostIpData['hostname'] = hostname;
              staticHostIpData['alias'] = alias;
              control.push(this.initItemRows(ip, hostname, alias));
              this.staticHostIp.push(staticHostIpData);
            });
          }
        }

        if (partitionData.networkStats.advanced.dnsConfig != null) {
          if (partitionData.networkStats.advanced.dnsConfig.dnsServers != null && partitionData.networkStats.advanced.dnsConfig.dnsServers != '') {
            let tempDnsServers = partitionData.networkStats.advanced.dnsConfig.dnsServers;
            tempDnsServers.forEach(dnsServer => {
              if (dnsServer != null && dnsServer != '') {
                this.dnsServers.push(dnsServer);
                const control = <FormArray>this.form.get('networkStats').get('advanced').
                  get('dnsConfig').get('dnsServers');
                control.push(new FormControl(dnsServer));
              }

            });
          }
          if (partitionData.networkStats.advanced.dnsConfig.searchDomainNames != null && partitionData.networkStats.advanced.dnsConfig.searchDomainNames != '') {
            let tempDomainNames = partitionData.networkStats.advanced.dnsConfig.searchDomainNames;
            tempDomainNames.forEach(domainName => {
              if (domainName != null && domainName != '') {
                this.domainNames.push(domainName);
                const control = <FormArray>this.form.get('networkStats').get('advanced').
                  get('dnsConfig').get('searchDomainNames');
                control.push(new FormControl(domainName));
              }

            });
          }
        }
      }
    }
  }

  changeInterfaces(value) {
    if (value == "All") {
      this.showEth0 = true;
      this.showEth1 = true;
    } else if (value == "eth0") {
      this.showEth0 = true;
      this.showEth1 = false;
    } else if (value == "eth1") {
      this.showEth0 = false;
      this.showEth1 = true;
    }

  }
  closeConfigureNetworkModel() {
    this.configureNetworkModal.hide();
    this.clearData();
  }
  addStaticHostIp() {
    this.displayError = "";
    if (this.form.get('networkStats.advanced.ip').value != "" && this.form.get('networkStats.advanced.hostname').value != "") {
      if (this.staticHostIp.length < 16) {
        let ip = this.form.get('networkStats.advanced.ip').value;
        let hostname = this.form.get('networkStats.advanced.hostname').value;
        let alias = this.form.get('networkStats.advanced.alias').value;
        const control = <FormArray>this.form.get('networkStats').get('advanced').get('staticIpToHostConfig').get('add');
        let staticHostIpData = {};

        staticHostIpData['ip'] = ip;
        staticHostIpData['hostname'] = hostname;
        staticHostIpData['alias'] = alias;
        control.push(this.initItemRows(ip, hostname, alias));
        this.staticHostIp.push(staticHostIpData);

        this.form.get('networkStats.advanced.ip').setValue("");
        this.form.get('networkStats.advanced.hostname').setValue("");
        this.form.get('networkStats.advanced.alias').setValue("");
      } else {
        this.displayError = "Maximum records to add is 16."
      }
    } else {
      this.displayError = "Please enter the required fields"
    }
  }

  removeStaticHostIp(index) {
    const control = <FormArray>this.form.get('networkStats').get('advanced').get('staticIpToHostConfig').get('add');
    // remove the chosen row
    control.removeAt(index);
    let indexAt = this.staticHostIp.indexOf(index);
    this.staticHostIp.splice(indexAt);
  }

  addDnsServer() {
    this.displayError = "";
    if (this.dnsServers.length < 4) {
      if (this.form.get('networkStats.advanced.dnsServer').value != "") {
        const control = <FormArray>this.form.get('networkStats').get('advanced').
          get('dnsConfig').get('dnsServers');
        // control.push(this.form.get('networkStats.advanced.dnsServer').value);
        control.push(new FormControl(this.form.get('networkStats.advanced.dnsServer').value));
        this.dnsServers.push(this.form.get('networkStats.advanced.dnsServer').value);
        this.form.get('networkStats.advanced.dnsServer').setValue("");
      } else {
        this.displayError = "Please enter the required field";

      }
    } else {
      this.displayError = "Maximum records to add is 4."
    }
  }


  removeDnsServers(index) {
    const control = <FormArray>this.form.get('networkStats').get('advanced')
      .get('dnsConfig').get('dnsServers');
    // remove the chosen row
    control.removeAt(index);
    let indexAt = this.dnsServers.indexOf(index);
    this.dnsServers.splice(indexAt);
  }

  addDomainName() {
    this.displayError = "";
    if (this.domainNames.length < 4) {
      if (this.form.get('networkStats.advanced.searchDomainName').value != "") {
        const control = <FormArray>this.form.get('networkStats').get('advanced').
          get('dnsConfig').get('searchDomainNames');
        // control.push(this.form.get('networkStats.advanced.dnsServer').value);
        control.push(new FormControl(this.form.get('networkStats.advanced.searchDomainName').value));
        this.domainNames.push(this.form.get('networkStats.advanced.searchDomainName').value);
        this.form.get('networkStats.advanced.searchDomainName').setValue("");
      } else {
        this.displayError = " Please enter the required field"
      }
    } else {
      this.displayError = " Maximum records to add is 4."
    }
  }

  removeSearchDomain(index) {
    const control = <FormArray>this.form.get('networkStats').get('advanced')
      .get('dnsConfig').get('searchDomainNames');
    // remove the chosen row
    control.removeAt(index);
    let indexAt = this.domainNames.indexOf(index);
    this.domainNames.splice(indexAt);
  }

  toggleDhcpEth0(event) {
    this.isEth0IpValidate = false;
    // this.form.get("networkStats.general.eth0.ip").reset();
    // this.form.get("networkStats.general.eth0.gateway").reset();
    // this.form.get("networkStats.general.eth0.subnet").reset();
    if (event.checked) {
      this.form.get('networkStats.general.eth0.ip').disable();
      this.form.get('networkStats.general.eth0.gateway').disable();
      this.form.get('networkStats.general.eth0.subnet').disable();
    } else {
      this.form.get("networkStats.general.eth0.ip").setValue(this.networkData.general.eth0.ip);
      this.form.get("networkStats.general.eth0.gateway").setValue(this.networkData.general.eth0.gateway);
      this.form.get("networkStats.general.eth0.subnet").setValue(this.networkData.general.eth0.subnet);
      this.form.get('networkStats.general.eth0.ip').enable();
      this.form.get('networkStats.general.eth0.gateway').enable();
      this.form.get('networkStats.general.eth0.subnet').enable();
    }
  }

  toggleDhcpEth1(event) {
    this.isEth1IpValidate = false;
    // this.form.get("networkStats.general.eth1.ip").reset();
    // this.form.get("networkStats.general.eth1.gateway").reset();
    if (event.checked) {
      this.form.get('networkStats.general.eth1.ip').disable();
      this.form.get('networkStats.general.eth1.subnet').disable();
    } else {
      this.form.get("networkStats.general.eth1.ip").setValue(this.networkData.general.eth1.ip);
      this.form.get("networkStats.general.eth1.gateway").setValue(this.networkData.general.eth1.gateway);
      this.form.get('networkStats.general.eth1.ip').enable();
      this.form.get('networkStats.general.eth1.subnet').enable();
    }
  }

  disableEth1Fields(event) {
    this.eth1MacAddress = false;
    this.isEth1IpValidate = false;
    if (event.checked) {
      this.form.get('networkStats.general.eth1.dhcp').enable();
     // this.form.get('networkStats.general.eth1.dhcp').setValue(true);
      this.form.get('networkStats.general.eth1.staticMac').enable();
      this.form.get('networkStats.general.eth1.address').disable();
      this.form.get('networkStats.general.eth1.vlan').enable();
    } else {
      this.form.get('networkStats.general.eth1.dhcp').disable();
      this.form.get('networkStats.general.eth1.staticMac').disable();
      this.form.get('networkStats.general.eth1.address').disable();
      this.form.get('networkStats.general.eth1.vlan').disable();
    }
  }

  toggleMacAddressEth0(event) {
    this.eth0MacAddress = false;
    // this.form.get('networkStats.general.eth0.address').reset();
    if (event.checked) {
      this.form.get('networkStats.general.eth0.address').enable();
    } else {
      this.form.get('networkStats.general.eth0.address').disable();
      this.form.get('networkStats.general.eth0.address').setValue(this.networkData.general.eth0.mac);
    }
  }

  toggleMacAddressEth1(event) {
    this.eth1MacAddress = false;
    // this.form.get('networkStats.general.eth1.address').reset();
    if (event.checked) {
      this.form.get('networkStats.general.eth1.address').enable();
    } else {
      this.form.get('networkStats.general.eth1.address').disable();
      this.form.get('networkStats.general.eth1.address').setValue(this.networkData.general.eth1.mac);
    }
  }
  disableDNSserver(event) {
    if (event.checked) {
      this.isDNSserverChecked = false;
      const control = <FormControl>this.form.get('networkStats').get('advanced').
        get('dnsConfig').get('enableService');
      control.setValue(true);
    } else {
      this.isDNSserverChecked = true;
      const control = <FormControl>this.form.get('networkStats').get('advanced').
        get('dnsConfig').get('enableService');
      control.setValue(false);
    }


  }
  public OnlyNumericValues(e) {
    let input;
    if (e.metaKey || e.ctrlKey) {
      return true;
    }
    if (e.which === 32) {
      return false;
    }
    if (e.which === 0) {
      return true;
    }
    if (e.which < 33) {
      return true;
    }
    input = String.fromCharCode(e.which);
    return !!/[\d\s]/.test(input);
  }
  clearData() {
    this.form.reset();
    this.tab = ''
    this.staticHostIp = [];
    this.dnsServers = [];
    this.domainNames = [];
    this.displayError = '';
    this.displayError1 = '';
    this.successMessage = '';
    this.classStatic = '';
    this.classServer = '';
    this.classDomain = '';
    this.partitionCount = 1;
    this.totalPartitionCount = 0;
    this.selectedPartitionList = [];
    this.partitionName = '';
    this.showEth0 = true;
    this.showEth1 = true;
    this.finalPartitionList = []
    this.isDNSserverChecked = false;
    this.showBackButton = false;
    this.tabName = "";
    this.showFinalPartitionList = false;
  }

  submitConfigurationNetworkDetails() {
    this.configureNetworkModal.hide();
    this.partitionOperationsComponent.performSelectedOperation(this.finalPartitionList, "Configure Network");
  }

  callBackToPartitionLogin() {
    console.log("Configure Network  --> Call back to partition login page");
    this.clearData();
    this.messageEvent1.emit();
  }

  /* Remove appliance from the final list */
  removePartition(partitionId, template: TemplateRef<any>) {
    let selectedId = [];
    this.displayError = '';
    selectedId.push(partitionId);
    if (this.finalPartitionList.length == 1) {
      this.displayError = "Please maintain atleast one partition to continue the operation, otherwise you can click on Cancel button to exit.";
      return false;
    } else {
      this.finalPartitionList = this.finalPartitionList.filter(
        val => !selectedId.includes(val.partitionId));
      this.selectedPartitionList = this.selectedPartitionList.filter(
        val => !selectedId.includes(val.partitionId));
      this.partitionCount = this.partitionCount - 1;
      this.totalPartitionCount = this.finalPartitionList.length;
    }
  }
  setValueReset(event, value) {
    // console.log(this.selectedPartitionList);
    if (event.checked) {

      this.form.get("networkStats.general.eth0.ip").disable();
      this.form.get("networkStats.general.eth0.gateway").disable();
      this.form.get("networkStats.general.eth0.subnet").disable();
      this.form.get("networkStats.general.eth0.hostname").disable();


      this.form.get("networkStats.general.eth0.ip").setValue(this.selectedPartitionList[0].networkStats.general.eth0.ip);
      // alert(this.networkStats.general.eth0.ip);

      this.form.get("networkStats.general.eth0.gateway").setValue(this.selectedPartitionList[0].networkStats.general.eth0.gateway);

      this.form.get("networkStats.general.eth0.subnet").setValue(this.selectedPartitionList[0].networkStats.general.eth0.subnet);
      this.form.get("networkStats.general.eth0.hostname").setValue(this.selectedPartitionList[0].networkStats.general.eth0.hostname);
      // });



    } else {
      this.form.get("networkStats.general.eth0.ip").enable();
      this.form.get("networkStats.general.eth0.ip").setValue("");
      this.form.get("networkStats.general.eth0.gateway").enable();
      this.form.get("networkStats.general.eth0.gateway").setValue("");
      this.form.get("networkStats.general.eth0.subnet").enable();
      this.form.get("networkStats.general.eth0.subnet").setValue("");
      this.form.get("networkStats.general.eth0.hostname").enable();
      this.form.get("networkStats.general.eth0.hostname").setValue("");






    }
  }
  setValueReset1(event, value) {
    if (event.checked) {
      this.form.get('networkStats.general.eth0.address').disable();
      this.form.get('networkStats.general.eth0.vlan').disable();

      this.form.get('networkStats.general.eth0.address').setValue(this.selectedPartitionList[0].networkStats.general.eth0.address);
      this.form.get('networkStats.general.eth0.vlan').setValue(this.selectedPartitionList[0].networkStats.general.eth0.vlan);

    }
    else {
      this.form.get('networkStats.general.eth0.address').enable();
      this.form.get('networkStats.general.eth0.address').setValue("");

      this.form.get('networkStats.general.eth0.vlan').enable();
      this.form.get('networkStats.general.eth0.vlan').setValue("");

    }

  }
  setValueReset2(event, value) {
    if (event.checked) {
      this.form.get('networkStats.general.eth1.ip').disable();
      this.form.get('networkStats.general.eth1.subnet').disable();

      this.form.get('networkStats.general.eth1.ip').setValue(this.selectedPartitionList[0].networkStats.general.eth1.ip);
      this.form.get('networkStats.general.eth1.subnet').setValue(this.selectedPartitionList[0].networkStats.general.eth1.subnet);

    }
    else {
      this.form.get('networkStats.general.eth1.ip').enable();
      this.form.get('networkStats.general.eth1.ip').setValue("");
      this.form.get('networkStats.general.eth1.subnet').enable();

      this.form.get('networkStats.general.eth1.subnet').setValue("");
    }
  }
  setValueReset3(event, value) {
    if (event.checked) {
      this.form.get('networkStats.general.eth1.address').disable();
      this.form.get('networkStats.general.eth1.vlan').disable();
      this.form.get('networkStats.general.eth1.address').setValue(this.selectedPartitionList[0].networkStats.general.eth1.address);
      this.form.get('networkStats.general.eth1.vlan').setValue(this.selectedPartitionList[0].networkStats.general.eth1.vlan);

    }
    else {
      this.form.get('networkStats.general.eth1.address').enable();
      this.form.get('networkStats.general.eth1.address').setValue("");

      this.form.get('networkStats.general.eth1.vlan').enable();
      this.form.get('networkStats.general.eth1.vlan').setValue("");
    }
  }

  setValueReset4(event, value) {
    if (event.checked) {
      this.form.get('networkStats.general.eth1.subnet').enable();
      this.form.get('networkStats.general.eth1.subnet').setValue("");

      this.form.get('networkStats.general.eth1.vlan').enable();
      this.form.get('networkStats.general.eth1.vlan').setValue("");
    }
    else {
      this.form.get('networkStats.general.eth1.ip').disable();
      this.form.get('networkStats.general.eth1.address').disable();
      this.form.get('networkStats.general.eth1.subnet').setValue(this.selectedPartitionList[0].networkStats.general.eth1.subnet);
      this.form.get('networkStats.general.eth1.vlan').setValue(this.selectedPartitionList[0].networkStats.general.eth1.vlan);

    }

  }


  closeMessage() {

  }
  isValidIp = true;
  validateIPaddress(inputText) {
    this.isValidIp = true;
    var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    // var form = document.getElementById('form1');
    // var x;
    // x = (<HTMLInputElement>document.getElementById("ip")).value;
    if (inputText != '') {
      if (inputText.match(ipformat)) {
        this.isValidIp = true;
      }
      else {
        this.isValidIp = false;
      }
    }
  }


  clearErrors() {
    this.isEth0IpValidate = false;
  }
  clearErrors1() {
    this.isEth1IpValidate = false;
  }
  clearMacAddressError1() {
    this.eth1MacAddress = false;
  }
  clearMacAddressError() {
    this.eth0MacAddress = false;
  }
}
