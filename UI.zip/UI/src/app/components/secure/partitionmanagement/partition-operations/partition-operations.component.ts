import { Component, OnInit, EventEmitter, Output, OnDestroy, ViewChild } from '@angular/core';
import { AnonymousSubscription } from "rxjs/Subscription";
import { PartitionManagementService } from './../../../../services/partitionmanagement/partitionmanagement.service';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { saveAs } from 'file-saver';

import * as FileSaver from 'file-saver';
declare var $: any;
declare var bootbox: any;
declare var jQuery: any;
@Component({
  selector: 'app-partition-operations',
  templateUrl: './partition-operations.component.html',
  styleUrls: ['./partition-operations.component.css']
})
export class PartitionOperationsComponent implements OnInit, OnDestroy {
  @ViewChild('messageModal')
  messageModal: ModalDirective;
  @Output() messageEvent = new EventEmitter<any>();
  loading: boolean = false;
  tempPartitionList: any = [];
  closeSessionSubscription: AnonymousSubscription;
  deleteSubscription: AnonymousSubscription;
  resetSubscription: AnonymousSubscription;
  certificateNetworkSubscription: AnonymousSubscription;
  startCAVServerSubscription: AnonymousSubscription;
  resetConfigSubscription: AnonymousSubscription;
  uploadConfigSubscription: AnonymousSubscription;
  downloadConfigSubscription: AnonymousSubscription;
  backUpRestoreSubscription: AnonymousSubscription;
  backUpSubscription: AnonymousSubscription;
  selectedOperation: string;
  successMsg = [];
  errorMsg = [];
  errorMsg1 = '';
  errorMsgForDownload = '';
  isSessionClosed: boolean = true;
  checkCloseSession: boolean = false;
  constructor(private _service: PartitionManagementService) { }

  ngOnInit() {
  }
  // make api call to the selected operation
  performSelectedOperation(partitionList, partitionOperation) {
    debugger;
    this.loading = true;
    this.tempPartitionList = partitionList;
    this.selectedOperation = partitionOperation;
    if (partitionOperation == "closeSession") {
      this.callCloseSession('');
    } else if (partitionOperation == "Delete") {
      this.callDeleteOperation();
    }
    else if (partitionOperation == "Reset VM") {
      this.callResetPartition();
    }
    else if (partitionOperation == "Configure Network") {
      this.callConfigurationNetwork();
    }
    else if (partitionOperation == "Start") {
      this.callStartOrStopCAVServer();
    }
    else if (partitionOperation == "Stop") {
      this.callStartOrStopCAVServer();
    }
    else if (partitionOperation == "Reset Config") {
      this.callResetConfig();
    }
    else if (partitionOperation == "Upload") {
      this.callUploadConfig();
    }
    else if (partitionOperation == "Download") {
      this.callDownloadConfig();
    }
    else if (partitionOperation == "BackUp&Restore") {
      this.callBackUpAndRestore();
    }
    else if (partitionOperation == "Backup") {
      this.callBackUpOperation();
    }
  }

  // call close session operation api 
  callCloseSession(message) {
    this.loading = true;

    this.closeSessionSubscription = this._service.performCloseSessionOperation(this.tempPartitionList).subscribe(
      response => {
        debugger;
        this.responseOperation(response);
      },
      err => {
        this.loading = false;
        console.log(err);
      })
  }
  // call delete operation api
  callDeleteOperation() {
    debugger;
    this.loading = true;
    if (!this.isSessionClosed) {
      this.messageModal.hide();
    }

    this.deleteSubscription = this._service.performDeleteOperation(this.tempPartitionList).subscribe(
      deleteResponse => {
        console.log(deleteResponse.json());
        this.responseOperation(deleteResponse);
      },
      err => {
        this.loading = false;
        console.log(err);
      }
    )
  }

  // call reset operation api 
  callResetPartition() {
    this.loading = true;
    if (!this.isSessionClosed) {
      this.messageModal.hide();
    }
    this.resetSubscription = this._service.performResetOperation(this.tempPartitionList).subscribe(
      response => {
        this.responseOperation(response);
      },
      err => {
        this.loading = false;
        console.log(err);
      }
    )
  }

  // call ConfigurationNetwork api 
  callConfigurationNetwork() {
    this.loading = true;
    if (!this.isSessionClosed) {
      this.messageModal.hide();
    }
    this.certificateNetworkSubscription = this._service.performConfigureNetwork(this.tempPartitionList).subscribe(
      response => {
        this.responseOperation(response);
      },
      err => {
        this.loading = false;
        console.log(err);
      }
    )
  }

  callStartOrStopCAVServer() {
    this.loading = true;
    if (!this.isSessionClosed) {
      this.messageModal.hide();
    }
    this.startCAVServerSubscription = this._service.performStartOrStopCAVServer(this.tempPartitionList).subscribe(
      response => {
        this.responseOperation(response);
      },
      err => {
        this.loading = false;
        console.log(err);
      }
    )
  }

  callResetConfig() {
    console.log('Calling Reset Config API .....')
    this.loading = true;
    if (!this.isSessionClosed) {
      this.messageModal.hide();
    }
    this.resetConfigSubscription = this._service.performCallResetConfig(this.tempPartitionList).subscribe(
      response => {
        this.responseOperation(response);
      },
      err => {
        this.loading = false;
        console.log(err);
      }
    )
  }

  callUploadConfig() {
    console.log('Calling Upload Config API .....')
    this.loading = true;
    if (!this.isSessionClosed) {
      this.messageModal.hide();
    }
    this.uploadConfigSubscription = this._service.performUploadConfig(this.tempPartitionList).subscribe(
      response => {
        this.responseOperation(response);
      },
      err => {
        this.loading = false;
        console.log(err);
      }
    )
  }

  callDownloadConfig() {
    console.log('Calling Download Config API .....')
    this.loading = true;
    if (!this.isSessionClosed) {
      this.messageModal.hide();
    }
    this.downloadConfigSubscription = this._service.performDownloadConfig(this.tempPartitionList).subscribe(
      response => {
        this.downloadFile(response);
      },
      err => {
        this.loading = false;
        console.log(err);
      }
    )
  }


  callBackUpAndRestore() {
    console.log('Calling BackUp and Restore  API .....')
    this.loading = true;
    if (!this.isSessionClosed) {
      this.messageModal.hide();
    }
    this.backUpRestoreSubscription = this._service.performBackUpAndRestore(this.tempPartitionList).subscribe(
      response => {
        console.log(response);
        this.responseOperation(response);
      },
      err => {
        this.loading = false;
        console.log(err);
      }
    )
  }

  callBackUpOperation() {
    console.log('Calling BackUp API .....')
    this.loading = true;
    if (!this.isSessionClosed) {
      this.messageModal.hide();
    }
    this.backUpSubscription = this._service.performBackUp(this.tempPartitionList).subscribe(
      response => {
        console.log(response)
        this.downloadFile(response);
      },
      err => {
        this.loading = false;
        console.log(err);
      }
    )
  }
  
  downloadFile(response) {
    debugger;
    this.loading = false;
    const contentType = response.headers.get('Content-Type');
    if (contentType == 'application/zip') {
      const contentDispositionHeader: string = response.headers.get('Content-Disposition');
      if (contentDispositionHeader != null) {
        const parts: string[] = contentDispositionHeader.split(';');
        let filename = parts[1].split('=')[1];
        filename = filename.replace(/^"(.*)"$/, '$1');
        saveAs(response.blob(),filename);
      }
    } else {
      this.loading = false;
      this.successMsg = [];
      this.errorMsg = [];
      this.errorMsg1 = '';
      this.tempPartitionList = [];
      this.errorMsgForDownload = '';
      this.errorMsgForDownload="Error occured during download file";
      this.messageModal.show();
      // let res = JSON.stringify(response);
      // let res1 = JSON.parse(res);
      // this.responseOperation1(res1);
    }
  }

  // downloadFile(response) {
  //   debugger;
  //   this.loading = false;
  //   const contentType = response.headers.get('Content-Type');
  //   if (contentType != 'text/html') {
  //     const contentDispositionHeader: string = response.headers.get('Content-Disposition');
  //     if (contentDispositionHeader != null) {
  //       const parts: string[] = contentDispositionHeader.split(';');
  //       const filename = parts[1].split('=')[1];
  //       const blob = new Blob([response._body], { type: 'application/zip' });
  //        saveAs(blob, filename);

  //     }
  //   } else {
  //     let res = JSON.stringify(response);
  //     let res1 = JSON.parse(res);
  //     this.responseOperation1(res1);
  //   }
  // }

  // handle the response form the api.
  responseOperation(res) {
    this.loading = false;
    this.successMsg = [];
    this.errorMsg = [];
    this.errorMsg1 = '';
    this.tempPartitionList = [];
    this.errorMsgForDownload = '';
    if (res != null && res._body) {
      let responseBody = JSON.parse(res._body);
      this.setResponseMessage(responseBody);
    } else {
      let responseBody = res;
      this.setResponseMessage(responseBody);
    }
  }
  // handle the response form the api.
  responseOperation1(res) {
    this.loading = false;
    this.successMsg = [];
    this.errorMsg = [];
    this.errorMsg1 = '';
    this.tempPartitionList = [];
    this.errorMsgForDownload = '';
    if (res != null && res._body) {
      let responseBody = res._body;
      this.errorMsgForDownload = responseBody;
    }
    this.messageModal.show();
  }
  setResponseMessage(responseBody) {
    responseBody.forEach(obj => {
      if (obj.code == "200") {
        this.successMsg.push(obj);
      } else if (obj.code == "11032") {
        this.isSessionClosed = false;
        if (this.errorMsg1 != '') {
          this.errorMsg1 = this.errorMsg1 + "," + obj.applianceName;
        } else {
          this.errorMsg1 = obj.applianceName;
        }
        obj['sessionClose'] = true;
        this.tempPartitionList.push(obj);
      } else {
        this.errorMsg.push(obj);
      }
    });
    this.messageModal.show();
  }
  // callBackOperation() {
  //   if (this.selectedOperation == 'deletePartition') {
  //     this.callDeleteOperation();
  //   }
  // }

  // call back to partition list 
  callBackToPartitionList() {
    this.messageModal.hide();
    console.log("Partition Operation --> Call back method to partiton list")
    this.messageEvent.emit();
  }
  closeConfirmModal() {
    this.messageModal.hide();
  }
  ngOnDestroy() {
    if (this.closeSessionSubscription) {
      this.closeSessionSubscription.unsubscribe();
    }
    if (this.deleteSubscription) {
      this.deleteSubscription.unsubscribe();
    }
    if (this.resetSubscription) {
      this.resetSubscription.unsubscribe();
    }
    if (this.certificateNetworkSubscription) {
      this.certificateNetworkSubscription.unsubscribe();
    }
    if (this.startCAVServerSubscription) {
      this.startCAVServerSubscription.unsubscribe();
    }
    if (this.downloadConfigSubscription) {
      this.downloadConfigSubscription.unsubscribe();
    }
    if (this.uploadConfigSubscription) {
      this.uploadConfigSubscription.unsubscribe();
    }
    if (this.backUpRestoreSubscription) {
      this.backUpRestoreSubscription.unsubscribe();
    }
    if (this.backUpSubscription) {
      this.backUpSubscription.unsubscribe();
    }
  }
}
