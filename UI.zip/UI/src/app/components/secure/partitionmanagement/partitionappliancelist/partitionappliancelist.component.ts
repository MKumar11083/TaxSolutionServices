
import { Component, OnInit, TemplateRef,ViewChild,OnDestroy } from '@angular/core';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { AnonymousSubscription } from "rxjs/Subscription";
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { BsModalService } from 'ngx-bootstrap/modal';
import { DataTableResource } from './../../data-table/index';
import { I18nService } from '../../../../services/common/i18n/i18n.service';
import { BreadcrumbService } from './../../../../services/common/breadcrumb.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { PartitionManagementService } from './../../../../services/partitionmanagement/partitionmanagement.service';
import { CreatenewpartitionComponent } from './../../../secure/partitionmanagement/createnewpartition/createnewpartition.component';

@Component({
  selector: 'app-partitionappliancelist',
  templateUrl: './partitionappliancelist.component.html',
  styleUrls: ['./partitionappliancelist.component.css']
})
export class PartitionappliancelistComponent implements OnInit,OnDestroy {
  @ViewChild('loginModal') loginModal: ModalDirective;
  @ViewChild('createPartition') createPartition: CreatenewpartitionComponent;
  @ViewChild('messageModal') messageModal :ModalDirective;
  loginForm: FormGroup;
  modalRef: BsModalRef;
  title = "Partition Details";
  message: string;
  showButton: boolean = false;
  username: string = '';
  password: string = '';
  appliancesList: any = [];
  itemResource: any;
  displayErrors: any = [];
  showList: boolean = true;
  selectedAppliances: any = [];
  showPartitionList :boolean =true;
  applianceName:string;
  loginCredentialsArray: any = [];
  loading : boolean = false;
  checkLoginCredentialsResultArray : any =[];
  private applianceListSubscription : AnonymousSubscription;
  private validateApplianceSubscription : AnonymousSubscription;
  constructor(private _applianceManagementService: AppliancemanagementService,
    private _I18nService: I18nService,
    private _formBuilder: FormBuilder,
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _service: PartitionManagementService,
    private modalService: BsModalService) { }

  ngOnInit() {
    this.selectedAppliances = [];
    this.createLoginForm();
    this.applianceListSubscription = this._applianceManagementService.getAllListAppliances().subscribe(
      res => {
        if (res.length > 0) {
          for (var i = 0; i < res.length; i++) {
            let appliance = res[i];
            appliance['disabled'] = false;
            // this.appliancesList.push(appliance);
            let availableKeys = (appliance.totalKeys - appliance.occupiedKeys);
            appliance['availableKeys'] = availableKeys;
            let availableContexts = (appliance.totalContexts - appliance.occupiedContexts);
            appliance['availableContexts'] = availableContexts;
            let availableAcclrDevice = (appliance.totalAcclrDevice - appliance.occupiedAcclrDev);
            appliance['availableAcclrDevice'] = availableAcclrDevice;
            this.appliancesList.push(appliance);
            // this.appliancesList[1] = { totalKeys: 999999999, totalContexts: 1, totalAcclrDevice: 65, occupiedKeys: 1, availableKeys: 999999999, availableContexts: 2, availableAcclrDevice: 66 }
            // this.appliancesList[2] = { availableKeys: 1, availableContexts: 3, availableAcclrDevice: 4 }

          }
        }
      },
      error => {
        console.log(error);
      },
    );
  }

  getSortedList(option) {
    debugger;
    if (this.appliancesList.length > 0) {
      switch (option) {

        case "1": this.appliancesList.sort((a, b) => {
          if (a.availableKeys < b.availableKeys) {
            return 1;
          } else if (a.availableKeys > b.availableKeys) {
            return -1;
          } else {
            return 0;
          }
        });
          console.log("after sorting ==>")
          console.log(this.appliancesList);
          break;

        case "2": this.appliancesList.sort((a, b) => {
          if (a.availableContexts < b.availableContexts) {
            return 1;
          } else if (a.availableContexts > b.availableContexts) {
            return -1;
          } else {
            return 0;
          }
        });
          console.log(this.appliancesList);
          break;

        case "3": this.appliancesList.sort((a, b) => {
          if (a.totalAcclrDevice < b.totalAcclrDevice) {
            return 1;
          } else if (a.totalAcclrDevice > b.totalAcclrDevice) {
            return -1;
          } else {
            return 0;
          }
        });
          console.log(this.appliancesList);
          break;

        default: alert(" ERROR ")

      }
    }
  }


  createLoginForm() {
    this.loginForm = this._formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
    });
  }
  toggle() {
    this.showList = false;
  }
  toggle1() {
    this.showList = true;
  }

  selectApplianceItems(event, applianceId, template: TemplateRef<any>) {
    if (event.target.checked) {
      event.currentTarget.style.visibility = "visible";
      for (var i = 0; i < this.appliancesList.length; i++) {
        if (this.appliancesList[i].applianceId == applianceId) {
          this.selectedAppliances.push(this.appliancesList[i]);
          this.appliancesList[i]['checked'] = true;
          this.appliancesList[i]['disabled'] = false;
        }
        else if (!this.appliancesList[i]['checked']) {
          this.appliancesList[i]['disabled'] = true;
          this.appliancesList[i]['checked'] = false;
        }
      }
      this.validateInitOperation(this.selectedAppliances[0], template);
    } else {
      event.currentTarget.style.visibility = "";
      this.showButton = false;
      for (var i = 0; i < this.appliancesList.length; i++) {
        if (this.appliancesList[i].applianceId == applianceId) {
          let index = this.selectedAppliances.indexOf(applianceId);
          this.selectedAppliances.splice(index);
        }
        this.appliancesList[i]['disabled'] = false;
        this.appliancesList[i]['checked'] = false;
      }
    }
  }


  validateInitOperation(appliance, template) {
    // if(!appliance.applianceinitialized){
    //   this.message = "Selected Appliance is not Initialize ";
    //   //       this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
    // }
    appliance.partitionDetailModels=null; 
    this._service.validateInitOperation(appliance).subscribe(
      res => {
        if (res.responseCode == "200") {
          this.showButton = true;
          // this.message = "Selected Appliance is Initialize Successfully";
          // this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
        } else if (res.responseCode == "401") {
          this.showButton = false;
          this.message = "Selected Appliance is not Initialize ";
          this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
        }
      })
  }

  showLoginForm(){
    this.loginModal.show();
    this.loginForm.reset();
    this.applianceName = this.selectedAppliances[0].applianceName;
  }

  goToCreatePartition(){
    this.loginModal.hide();
    //this.showPartitionList= false;
    const username = this.loginForm.get('username').value;
    const password = this.loginForm.get('password').value;
    this.selectedAppliances[0].userName=username;
    this.selectedAppliances[0].userPassword=password;
    let loginDetailsModal = {};
    loginDetailsModal['applianceId'] = this.selectedAppliances[0].applianceId;
    loginDetailsModal['applianceName'] = this.selectedAppliances[0].applianceName;
    loginDetailsModal['ipAddress'] = this.selectedAppliances[0].ipAddress;
    loginDetailsModal['operationUsername'] = username;
    loginDetailsModal['operationPassword'] = password;
    this.loginCredentialsArray.push(loginDetailsModal);
    this.checkAppliancesCredentials();
  }

  checkAppliancesCredentials() {
    this.loading = true;
    this.checkLoginCredentialsResultArray = [];
    this._applianceManagementService.checkAppliancesCredentials(this.loginCredentialsArray).subscribe(
      (response) => {
        let isSuccess: boolean = true;
        this.loading = false;
        response.forEach(obj => {
          this.loginCredentialsArray = [];
          if (obj.code != "200") {
            
            this.checkLoginCredentialsResultArray.push(obj);
            isSuccess = false;
          }
        });
        if (isSuccess) {
          this.loginModal.hide();
          this.showPartitionList= false;
        } else {
          this.messageModal.show();
        }
      },
      (error) => {
        console.log(error);
      })
  }
  public formValidationFields1 = {
    "username": '',
    "password": ''

  }
  isFieldValid1(field: string) {
    if (this.loginForm.get(field).touched) {
      this.formValidationFields1 = this._fieldErrorDisplayService.validateField(this.loginForm, field, this.formValidationFields1, "login")
    }
    return !this.loginForm.get(field).valid && this.loginForm.get(field).touched;
  }

  displayFieldCss1(field: string) {
    return {
      'has-error': this.isFieldValid1(field),
      'has-feedback': this.isFieldValid1(field)
    };
  }

  ngOnDestroy(){
    if(this.applianceListSubscription){
      this.applianceListSubscription.unsubscribe();
    }
    if(this.validateApplianceSubscription){
      this.validateApplianceSubscription.unsubscribe();
    }
  }
}