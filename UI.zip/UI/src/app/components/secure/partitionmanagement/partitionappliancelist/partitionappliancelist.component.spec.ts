import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PartitionappliancelistComponent } from './partitionappliancelist.component';

describe('PartitionappliancelistComponent', () => {
  let component: PartitionappliancelistComponent;
  let fixture: ComponentFixture<PartitionappliancelistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PartitionappliancelistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PartitionappliancelistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
