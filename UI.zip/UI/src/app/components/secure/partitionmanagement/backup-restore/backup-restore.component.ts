import { Component, OnInit, ViewChild, Output, EventEmitter, OnDestroy ,ElementRef} from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { PartitionOperationsComponent } from './../partition-operations/partition-operations.component';
import { AnonymousSubscription } from "rxjs/Subscription";
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
@Component({
  selector: 'app-backup-restore',
  templateUrl: './backup-restore.component.html',
  styleUrls: ['./backup-restore.component.css']
})
export class BackupRestoreComponent implements OnInit, OnDestroy {
  @ViewChild('myInput')
  myInputVariable: ElementRef;
  @ViewChild('backupRestoreModal') backupRestoreModal: ModalDirective;
  @ViewChild('partitionOperationsComponent')
  private partitionOperationsComponent: PartitionOperationsComponent;
  @Output() messageEvent3 = new EventEmitter<any>();
  selectedPartitionList : any= [];
  selectedOperation: string;
  toggleRadioOperation: boolean;
  restoreBackUp : any = {
    'fileContent':[]
  }
  fileName: string = '';
  restorePartitionModel :any= {};
  applianceListSubscription: AnonymousSubscription;
  partitionListSubscription: AnonymousSubscription;
  appliancesList: any = [];
  partitionList: any = [];
  applianceId: string;
  partitionId: string;
  noKey: boolean = false;
  applianceModal :any= {}
  constructor(private _applianceService: AppliancemanagementService) {
   }

  ngOnInit() { 
  }

  showBackUpRestore(partitionList, operation) {
    this.clearData();
    this.toggleRadioOperation = true;
    this.selectedOperation = operation;
    this.getApplianceList();
    this.createPartitionList(partitionList);
    this.applianceModal = this.backUpFromPartition();
    this.backupRestoreModal.show();
  }

  getApplianceList() {
    this.applianceListSubscription = this._applianceService.getAllListAppliances().subscribe(
      response => {
        this.appliancesList = response;
      }, error => {
        console.log(error);
      })
  }
  createPartitionList(partitionList) {
    partitionList.forEach(obj => {
      let partitionModal = {
        'applianceDetailModel': {}
      };
      partitionModal['partitionId'] = obj.partitionId;
      partitionModal['partitionName'] = obj.partitionName;
      partitionModal['username'] = obj.username;
      partitionModal['password'] = obj.password;
      partitionModal['sessionClose'] = obj.sessionClose;
      partitionModal['noKey'] = false;
      partitionModal['checkIntegrity'] = false;
      partitionModal['nodeId'] = '';
      partitionModal['applianceDetailModel']['applianceId'] = obj.applianceDetailModel.applianceId;
      partitionModal['applianceDetailModel']['applianceName'] = obj.applianceDetailModel.applianceName;
      partitionModal['applianceDetailModel']['ipAddress'] = obj.applianceDetailModel.ipAddress;
      this.selectedPartitionList.push(partitionModal);
    });

  }
  backUpFromPartition() {
    let applianceModal = {
      'applianceId': '',
      'partitionDetailModels':[{
        'partitionId': '',
        'noKey':''
      }
      ]
    }
    return applianceModal;
  }
  toggleRadioButton(event) {
    this.restoreBackUp = [];
    this.fileName = '';
    this.applianceModal['applianceId'] = '';
    this.applianceModal['partitionDetailModels'][0]['partitionId']='';
    this.toggleRadioOperation = !this.toggleRadioOperation;
  }

  // file upload method
  onFileChange($event) {
     debugger;
    this.myInputVariable.nativeElement.value = "";
    this.restoreBackUp['fileName'] = '';
    this.restoreBackUp['fileContent'] = [];
    this.restoreBackUp['fileExtension'] = '';
    this.restoreBackUp['errorMsg'] = '';
    this.fileName = '';
    const filePicked = ($event.target as HTMLInputElement).files[0];
    let target = $event.target || $event.srcElement;
    target.value = '';
    if (filePicked != undefined) {
      const fileName = filePicked.name;
      this.fileName = fileName;
      this.restoreBackUp['fileName'] = fileName.substring(0, fileName.indexOf('.'));
      this.restoreBackUp['fileExtension'] = filePicked.name.split('.').pop() || filePicked.name;
      // this.restoreBackUp['noKey'] = false;
      const reader = new FileReader();
      let fileByteArray = [];
      reader.onload = () => {
        let fileContent = reader.result;
        let array = new Uint8Array(fileContent);
        for (var i = 0; i < array.length; i++) {
          fileByteArray.push(array[i]);
       }
        this.restoreBackUp['fileContent'] = fileByteArray;
      };
      reader.readAsArrayBuffer(filePicked);
    }
  }

  getPartitionListByAppId(applianceId) {
    this.applianceModal['applianceError']="";
    this.applianceModal['partitionError']="";
    this.applianceModal['partitionDetailModels'][0]['partitionId']='';
    if (applianceId != '') {
      let applianceModal = {};
      applianceModal['applianceId'] = applianceId;
      this.applianceListSubscription = this._applianceService.getPartitionListByAppId(applianceModal).subscribe(
        response => {
          this.partitionList = response;
        }, error => {
          console.log(error);
        })
    } else {
      this.partitionList = [];
    }
  }
  clearPartitionDropdownErrorMsg(){
    this.applianceModal['partitionError']="";
  }
  onSubmit() {
    let isValid = true;
    this.restoreBackUp['errorMsg'] = '';
    if (this.toggleRadioOperation) {
      if (this.restoreBackUp['fileContent'] == null || this.restoreBackUp['fileContent'] == '') {
        isValid = false;
        this.restoreBackUp['errorMsg'] = "Please select the Backup file."
      }
    } else if (this.applianceModal['applianceId'] == '' ||  this.applianceModal['partitionDetailModels'][0]['partitionId'] == '') {
        if(this.applianceModal['applianceId']==''){
          this.applianceModal['applianceError']="Please Select Appliance";
        }else if(this.applianceModal['partitionDetailModels'][0]['partitionId']==''){
          this.applianceModal['partitionError']="Please Select Partition";
        }
      isValid = false;
    }
    if (isValid) {
      this.restorePartitionModel = {
        'file': {},
        'backupFromPartition': {},
        'partitionList': []
      }
      if (this.toggleRadioOperation) {
        this.restorePartitionModel['backupFromPartition'] = null;
        this.restorePartitionModel['file'] = this.restoreBackUp;
      } else {
        this.restorePartitionModel['backupFromPartition'] = this.applianceModal;
        this.restorePartitionModel['file'] = null;
      }
      this.restorePartitionModel['partitionList'] = this.selectedPartitionList;
      this.backupRestoreModal.hide();
      this.partitionOperationsComponent.performSelectedOperation(this.restorePartitionModel, this.selectedOperation);
    }
  }

  closeBackUpRestoreModal() {
    this.backupRestoreModal.hide();
    this.clearData();
  }
  clearData() {
    this.selectedPartitionList = [];
    this.selectedOperation = '';
    this.toggleRadioOperation = true;
    this.restoreBackUp = {}
    this.fileName = '';
    this.restorePartitionModel = {};
    this.appliancesList = [];
    this.partitionList = [];
    this.applianceId = '';
    this.partitionId = '';
    this.noKey = false;
    this.applianceModal = {}
  }
  callBackToPartitionLogin() {
    console.log("BackUp & Restore  --> Call back to partition login page");
    this.clearData();
    this.messageEvent3.emit();
  }
  public onlyNumericValues(e) {
    let input;
    if (e.metaKey || e.ctrlKey) {
      return true;
    }
    if (e.which === 32) {
      return false;
    }
    if (e.which === 0) {
      return true;
    }
    if (e.which < 33) {
      return true;
    }
    input = String.fromCharCode(e.which);
    return !!/[\d\s]/.test(input);
  }

  ngOnDestroy() {
    if (this.applianceListSubscription) {
      this.applianceListSubscription.unsubscribe();
    }
    if (this.partitionListSubscription) {
      this.partitionListSubscription.unsubscribe();
    }
  }
}
