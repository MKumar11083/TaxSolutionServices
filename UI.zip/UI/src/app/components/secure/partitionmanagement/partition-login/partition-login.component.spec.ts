import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PartitionLoginComponent } from './partition-login.component';

describe('PartitionLoginComponent', () => {
  let component: PartitionLoginComponent;
  let fixture: ComponentFixture<PartitionLoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PartitionLoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PartitionLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
