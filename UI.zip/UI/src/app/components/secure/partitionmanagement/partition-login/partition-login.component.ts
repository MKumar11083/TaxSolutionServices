import { Component, OnInit, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { PartitionOperationsComponent } from './../partition-operations/partition-operations.component';
import { ConfigureNetworkComponent } from './../configure-network/configure-network.component';
import { UploadConfigComponent } from './../cavserver/upload-config/upload-config.component';
import { BackupRestoreComponent } from './../backup-restore/backup-restore.component';
import { PartitionBackupComponent } from './../partition-backup/partition-backup.component';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import {PartitionResizeComponent } from './../partition-resize/partition-resize.component';
@Component({
  selector: 'app-partition-login',
  templateUrl: './partition-login.component.html',
  styleUrls: ['./partition-login.component.css']
})
export class PartitionLoginComponent implements OnInit {
  @ViewChild('partitionLoginModal')
  partitionLoginModal: ModalDirective;
  @ViewChild('confirmModal')
  confirmModal: ModalDirective;
  @ViewChild('messageModal')
  messageModal:ModalDirective;
  @ViewChild('partitionOperationsComponent')
  private partitionOperationsComponent: PartitionOperationsComponent;
  @ViewChild('configureNetwork')
  private configureNetwork: ConfigureNetworkComponent;
  @ViewChild('uploadConfig')
  private uploadConfig: UploadConfigComponent;
  @ViewChild('backupRestore')
  private backupRestore: BackupRestoreComponent;
  @ViewChild('partitionBackup')
  private partitionBackup: PartitionBackupComponent;
  @ViewChild('partitionResize')
  private partitionResize: PartitionResizeComponent;

  @Input() selectedPartitionList;
  @Output() loginEvent = new EventEmitter<any>();
  loginForm: FormGroup;
  partitionOperation: string;
  nonCredentialSavedParitionList = [];
  credentialsSavedPartitionList = []
  partitionCount = 1;
  totalpartitionCount = 0;
  partitionName: string;
  message: string;
  isLastPartition: boolean = false;
  finalPartitionList = [];
  partitionMap: Map<string, Array<any>>;
  checkCloseSession: boolean = false;
  loginCredentialsArray: any = [];
  saveCredentialsToSessionArray: any = [];
  loading: boolean = false;
  constructor(private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _formBuilder: FormBuilder,
    private _service: AppliancemanagementService) { }

  ngOnInit() {
    this.createLoginForm();
  }

  createLoginForm() {
    this.loginForm = this._formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
    });
  }
  // initial method to execute for login form.
  showLoginModal(operation) {
    debugger;
    this.clearData();
    if (this.selectedPartitionList.length != 0) {
      if (this.selectedPartitionList.length <= 5) {
        this.partitionMap = new Map<string, Array<any>>();
        this.partitionOperation = operation;
        // construct map based on applianceId for selected PartitionList
        this.selectedPartitionList.forEach(partitionObj => {
          let tempMap: Array<any> = [];
          if (this.partitionMap.has(partitionObj['applianceId'])) {
            tempMap = this.partitionMap.get(partitionObj['applianceId']);
          }
          tempMap.push(partitionObj);
          this.partitionMap.set(partitionObj['applianceId'], tempMap);
        });
        //construct map code ends here
        // get all the applianceIds form the map and iterate each applianceId , to 
        // identity the credentialSaved or not 
        let applianceIds = Array.from(this.partitionMap.keys());
        applianceIds.forEach(appId => {
          if (this.partitionMap.has(appId)) {
            let partitionObj = this.partitionMap.get(appId)[0];
            if (partitionObj['credentialSaved']) {
              this.credentialsSavedPartitionList.push(partitionObj);
            } else {
              // check appliance credentials are available in localsession.
              // if available in localsession , skips the login for appliance.
              let loginCredentials = JSON.parse(localStorage.getItem(partitionObj.ipAddress));
              if (loginCredentials != null) {
                partitionObj['username'] = loginCredentials.username;
                partitionObj['password'] = loginCredentials.password;
                this.saveCredentialsToSessionArray.push(partitionObj);
              } else {
                this.nonCredentialSavedParitionList.push(partitionObj);
              }
            }
          }
        });
        //  check the length of non credentialsaved Partition List to show the login pop.
        // if length is 0 , then show the confirm modal,whether to continue the selected Operation or not.
        if (this.nonCredentialSavedParitionList.length > 0) {
          this.partitionName = this.nonCredentialSavedParitionList[this.partitionCount - 1]['applianceName'];
          this.totalpartitionCount = this.nonCredentialSavedParitionList.length;
          if (this.partitionCount == this.totalpartitionCount) {
            this.isLastPartition = true;
          }
          this.partitionLoginModal.show();
        } else {
          this.confirmModal.show();
        }
      } else {
        this.partitionLoginModal.show();
        this.message = "Sorry!Operation cannot be performed on more than five partitions";
      }
    } else {
      this.partitionLoginModal.show();
      this.message = "Please select any partition to perform the activity!";
    }
  }

  goToNextPartition() {
    debugger;
    let applianceData = this.nonCredentialSavedParitionList[this.partitionCount - 1];
    this.createListOfPartitions(applianceData,"login");
    let loginDetailsModal = {};
    loginDetailsModal['applianceId'] = applianceData.applianceId;
    loginDetailsModal['applianceName'] = applianceData.applianceName;
    loginDetailsModal['ipAddress'] = applianceData.ipAddress;
    loginDetailsModal['operationUsername'] = this.loginForm.get('username').value;
    loginDetailsModal['operationPassword'] = this.loginForm.get('password').value;
    this.loginCredentialsArray.push(loginDetailsModal);
    // Storing appliance login credentials in local session
    let ipAddress = applianceData.ipAddress;
    let loginCredentials = {
      username: this.loginForm.get('username').value,
      password: this.loginForm.get('password').value
    };
    localStorage.setItem(ipAddress, JSON.stringify(loginCredentials));
    // local session code ends here
    if (this.partitionCount < this.nonCredentialSavedParitionList.length) {
      this.partitionName = this.nonCredentialSavedParitionList[this.partitionCount]['applianceName'];
      this.partitionCount++;
      if (this.partitionCount == this.totalpartitionCount) {
        this.isLastPartition = true;
      }
    } else {
      this.partitionLoginModal.hide();
      this.checkAppliancesCredentials();
    }
    this.loginForm.reset();
  }

  checkAppliancesCredentials() {
    this.loading=true;
    this._service.checkAppliancesCredentials(this.loginCredentialsArray).subscribe(
      (response) => {
        this.loading=false;
        let isSuccess: boolean = true;
        response.forEach(obj => {
          this.partitionLoginModal.hide();
          this.loginCredentialsArray = [];
          if (obj.message != "success") {
            this.finalPartitionList= [];
            this.finalPartitionList.push(obj);
            localStorage.removeItem(obj.ipAddress);
            isSuccess = false;
          }
        });
        if (isSuccess) {
          if(this.partitionOperation == 'Configure Network'){
            this.performSelectedOperationForPartition();
          }else{
            this.confirmModal.show();
          }
        } else {
          this.messageModal.show();
        }
      },
      (error) => {
        console.log(error);
      })
  }
  // create the list of partitions .
  createListOfPartitions(partitionData,value) {
    if (this.partitionMap.has(partitionData.applianceId)) {
      let partitionList = this.partitionMap.get(partitionData.applianceId);
      partitionList.forEach(obj => {
        let partitionModel = {
          applianceDetailModel: {}
        };
        if(value == "login"){
          partitionModel['username'] = this.loginForm.get('username').value;
          partitionModel['password'] = this.loginForm.get('password').value;
        }else{
          partitionModel['username'] = partitionData.username;
          partitionModel['password'] = partitionData.password;
        }
        
        if (this.checkCloseSession) {
          partitionModel['sessionClose'] = true;
        } else {
          partitionModel['sessionClose'] = false;
        }
        if (this.partitionOperation == "Start") {
          partitionModel['enableCavServer'] = true;
        } else {
          partitionModel['enableCavServer'] = false;
        }
        partitionModel['partitionId'] = obj['partitionId'];
        partitionModel['partitionName'] = obj['partitionName'];
        partitionModel['csr'] = obj['csr'];
        partitionModel['keys'] = obj['keys'];
        partitionModel['sslContexts'] = obj['sslContexts'];
        partitionModel['acclrDev'] = obj['acclrDev'];
        partitionModel['wrap'] = obj['wrap'];
        partitionModel['backup'] = obj['backup'];
        partitionModel['networkStats'] = obj['networkStats'];
        partitionModel.applianceDetailModel['applianceId'] = obj['applianceId'];
        partitionModel.applianceDetailModel['applianceName'] = obj['applianceName'];
        partitionModel.applianceDetailModel['ipAddress'] = obj['ipAddress'];
        this.finalPartitionList.push(partitionModel);
      });
    }
  }
  // forward the control to the operation component
  performSelectedOperationForPartition() {
    debugger;
    this.confirmModal.hide();
    let count: number = 0;
    this.finalPartitionList.forEach(partitionObj => {
      if (this.checkCloseSession) {
        this.finalPartitionList[count]['sessionClose'] = true;
      } else {
        this.finalPartitionList[count]['sessionClose'] = false;
      }
      count = count + 1;
    });
    this.credentialsSavedPartitionList.forEach(partitionObj => {
      this.createListOfPartitions(partitionObj,"");
    });

    this.saveCredentialsToSessionArray.forEach(partitionObj => {
      this.createListOfPartitions(partitionObj,"");
    });
    if (this.partitionOperation == 'Configure Network') {
      this.configureNetwork.showConfigureNetworkModal(this.finalPartitionList);
    } else if (this.partitionOperation == 'Upload') {
      this.uploadConfig.showUploadConfig(this.finalPartitionList, this.partitionOperation);
    } else if (this.partitionOperation == 'BackUp&Restore') {
      this.backupRestore.showBackUpRestore(this.finalPartitionList, this.partitionOperation);
    } else if (this.partitionOperation == 'Backup') {
      this.partitionBackup.showPartitionBackupModal(this.finalPartitionList, this.partitionOperation);
    }else if (this.partitionOperation == 'Resize') {
      this.partitionResize.showPartitionResizeModal(this.finalPartitionList);
    }
    else {
      this.partitionOperationsComponent.performSelectedOperation(this.finalPartitionList, this.partitionOperation);
    }
  }

  closeLoginModal() {
    console.log("Close ----> Partition Login Modal");
    this.partitionLoginModal.hide();
    this.clearData();
  }

  closeConfirmModal() {
    console.log("Close ----> Confirm  Modal");
    this.confirmModal.hide();
    this.clearData();
  }
  // reset method
  clearData() {
    this.loginForm.reset();
    this.partitionOperation = '';
    this.nonCredentialSavedParitionList = [];
    this.credentialsSavedPartitionList = []
    this.partitionCount = 1;
    this.totalpartitionCount = 0;
    this.partitionName = '';
    this.message = '';
    this.isLastPartition = false;
    this.finalPartitionList = [];
    this.checkCloseSession = false;
    this.loginCredentialsArray = [];
    this.saveCredentialsToSessionArray=[];
  }
  // call back to partition list page
  callBackToPartitionList() {
    console.log("Partition Login  --> Call back to partition list");
    this.clearData();
    this.loginEvent.emit();
  }
  public formValidationFields1 = {
    "username": '',
    "password": ''

  }
  isFieldValid1(field: string) {
    if (this.loginForm.get(field).touched) {
      this.formValidationFields1 = this._fieldErrorDisplayService.validateField(this.loginForm, field, this.formValidationFields1, "login")
    }
    return !this.loginForm.get(field).valid && this.loginForm.get(field).touched;
  }

  displayFieldCss1(field: string) {
    return {
      'has-error': this.isFieldValid1(field),
      'has-feedback': this.isFieldValid1(field)
    };
  }
}
