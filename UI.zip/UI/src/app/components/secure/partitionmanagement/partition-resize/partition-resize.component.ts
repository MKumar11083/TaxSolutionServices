import { Component, OnInit, ViewChild, Output, EventEmitter, TemplateRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, FormControl, FormArray } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { TabDirective } from 'ngx-bootstrap/tabs';
import { TabsetComponent } from 'ngx-bootstrap';
import { Router } from '@angular/router';
import { PartitionOperationsComponent } from './../partition-operations/partition-operations.component';
import { PartitionManagementService } from './../../../../services/partitionmanagement/partitionmanagement.service';
import { BsModalService } from 'ngx-bootstrap/modal';
declare var $: any;
@Component({
  selector: 'app-partition-resize',
  templateUrl: './partition-resize.component.html',
  styleUrls: ['./partition-resize.component.css']
})
export class PartitionResizeComponent implements OnInit {
  @ViewChild('resizeModal') resizeModal: ModalDirective;
  @ViewChild('messageModal') messageModal: ModalDirective;

  @Output() messageEvent5 = new EventEmitter<any>();
  @ViewChild('partitionOperationsComponent')
  private partitionOperationsComponent: PartitionOperationsComponent;
  form: FormGroup;
  selectedPartitionList = [];
  partitionCount: number = 1;
  totalPartitionCount: number = 0;
  resizeDataList = [];
  partitionName: string;
  finalPartitionList = [];
  loading = false;
  showBackButton = false;
  showNextButton = true;
  displayError: string;
  displayError1: string;
  showFinalResize: boolean = false;
  backupChecked: boolean = false;
  modal: any = {};
  allocatedUserKeys: number = 1;
  allocatedSSLContexts: number = 1;
  allocatedAccelDevices: number = 1;
  ModifiedUserKeys: number = 0;
  ModifiedSSLContexts: number = 0;
  ModifiedAccelDevices: number = 0;
  
  keysAvailable: number;
  sslContextAvailable: number;
  acclrDevicesAvailable: number;
  message: string = '';


  constructor(private _formBuilder: FormBuilder,
    private _service: PartitionManagementService,
    private modalService: BsModalService) { }

  ngOnInit() {
    this.createResizeForm();

  }
  createResizeForm() {
    this.form = this._formBuilder.group({
      userkeys: [''],
      sslcontexts: [''],
      acclrdevices: [''],
      backup: [false],

    });
  }
  partitionResizeList: any = [];
  partitionResizeData: any = {};


  showPartitionResizeModal(partitionList) {
    this.form.reset();
    console.log("List of selected partitions --->" + partitionList);
    this.selectedPartitionList = partitionList;
    this.partitionResizeData = {};
    this.partitionResizeList = [];
    
    debugger;
    this._service.getPartitionInfoForResize(this.selectedPartitionList).subscribe(
      (response) => {
        console.log(response);
        
        response.forEach(obj => {
          let partitionResizeObj = {
            'partitionData': {}
          };
          partitionResizeObj['partitionId'] = obj.partitionId;
          partitionResizeObj['partitionName'] = obj.partitionName;
          partitionResizeObj['partOfCluster'] = obj.partOfCluster;
          partitionResizeObj['status'] = obj.status;
          partitionResizeObj['backup'] = obj.backup;
          partitionResizeObj['wrap'] = obj.wrap;
          partitionResizeObj['csr'] = obj.csr;
          if(obj.partitionData!=null){

            partitionResizeObj['partitionData']['keysAvaliable'] = obj.partitionData.keysAvaliable;
                partitionResizeObj['partitionData']['sslContextAvaliable'] = obj.partitionData.sslContextAvaliable;
          partitionResizeObj['partitionData']['acclrDevicesAvaliable'] = obj.partitionData.acclrDevicesAvaliable;
          partitionResizeObj['partitionData']['backup'] = obj.partitionData.backup;
          partitionResizeObj['partitionData']['allocatedAccelDevices'] = obj.partitionData.allocatedAccelDevices;
          partitionResizeObj['partitionData']['allocatedUserKeys'] = obj.partitionData.allocatedUserKeys;
          partitionResizeObj['partitionData']['allocatedSSLContexts'] = obj.partitionData.allocatedSSLContexts;

          partitionResizeObj['partitionData']['backup'] = obj.partitionData.backup;
          partitionResizeObj['partitionData']['modifiedUserKeys'] = obj.partitionData.modifiedUserKeys;
          partitionResizeObj['partitionData']['modifiedSSLContexts'] = obj.partitionData.modifiedSSLContexts;
          partitionResizeObj['partitionData']['modifiedAccelDevices'] = obj.partitionData.modifiedAccelDevices;
          // partitionResizeObj['partitionData']['incrementKeys'] = obj.partitionData.incrementKeys;
          // partitionResizeObj['partitionData']['incrementSslContexts'] = obj.partitionData.incrementSslContexts;
          // partitionResizeObj['partitionData']['incrementAcclrDev'] = obj.partitionData.incrementAcclrDev;
          this.partitionResizeList.push(partitionResizeObj);
          }
      
        });
        this.partitionResizeData = this.partitionResizeList[this.partitionCount - 1];
        this.partitionName = this.selectedPartitionList[this.partitionCount - 1]['partitionName'];
        this.totalPartitionCount = this.selectedPartitionList.length;
        console.log(this.totalPartitionCount);
        console.log(this.partitionResizeData);
        let count = this.partitionCount - 1;
        this.resizeModal.show();
        if (this.partitionCount < this.selectedPartitionList.length) {
          this.showNextButton = true;
          this.showBackButton = false;
        } else if (this.partitionCount == this.selectedPartitionList.length) {
          this.showNextButton = false;
          if (this.partitionCount != 1) {
            this.showBackButton = true;
          }
        }
        else {
          this.showNextButton = false;
          this.showBackButton = true;
        }
      }
    )

  }


  NextResize() {
    debugger;
    $("#resize").fadeOut(20);
    this.form.reset();
    if (this.partitionCount < this.selectedPartitionList.length) {
      this.partitionResizeData = {};
      this.partitionResizeData = this.partitionResizeList[this.partitionCount];
      this.displayError = '';
      this.displayError1 = '';
      this.form.reset();
      this.partitionName = this.selectedPartitionList[this.partitionCount]['partitionName'];
      this.partitionCount++;
      this.showBackButton = true;
      if (this.partitionCount == this.selectedPartitionList.length) {
        this.showNextButton = false;
      }
      this.modal = [];
      $("#logs").fadeIn("slow");
    }
    else {
      this.form.reset();
      // this.applianceCount++;
    }
  }
  backToPreviousPartition() {
    debugger;
    $("#resize").fadeOut(20);
    this.form.reset();
    this.displayError = '';
    this.displayError1 = '';
    this.partitionName = this.selectedPartitionList[this.partitionCount - 2]['partitionName'];
    let backOperationCount = this.partitionCount - 2;
    let partitionData = this.finalPartitionList[backOperationCount];
    this.partitionResizeData = {};
    this.partitionResizeData = this.partitionResizeList[this.partitionCount - 2];
    this.showNextButton = true;
    //this.setPartitionDataToForm(partitionData);
    this.partitionCount = this.partitionCount - 1;
    if (this.partitionCount == 1) {
      this.showBackButton = false;
    }
    // this.staticTabs.tabs[0].active = true;
    // this.tabName ="General";
    $("#resize").fadeIn("slow");
  }
  toggleSaveToDB($event) {
    if ($event.checked) {
      this.backupChecked = true;
    } else {
      this.backupChecked = false;
    }
  }


  pushPartitionDataIntoList() {
    this.finalPartitionList.push(this.form.value);
  }


  // backOperationFromFinalList() {
  //   debugger;
  //   $("#resize").fadeOut(20);
  //   //this.form.reset();
  //   this.partitionName = this.finalPartitionList[this.partitionCount - 1]['partitionName'];
  //   let partitionData = this.finalPartitionList[this.partitionCount - 1];
  //   //this.setPartitionDataToForm(partitionData);
  //   if (this.partitionCount == 1) {
  //     this.showBackButton = false;
  //   } else {
  //     //this.applianceCount = this.applianceCount - 1;
  //     this.showBackButton = true;
  //   }
  //   this.showFinalResize = false;

  //   $("#resize").fadeIn("slow");
  // }

  // closeresizeModel() {
  //   this.resizeModal.hide();
  //   this.clearData();
  // }

  resizeSubmit() {
    debugger;
    this.message = '';
    this.loading=true;

    let partitionModel = this.selectedPartitionList[this.partitionCount - 1];
    this.partitionResizeData['applianceDetailModel'] = partitionModel.applianceDetailModel;
    this.partitionResizeData['sessionClose'] = partitionModel.sessionClose;
    this.partitionResizeData['username'] = partitionModel.username;
    this.partitionResizeData['password'] = partitionModel.password;
    this.partitionResizeData['partitionData']['backup'] =this.backupChecked;
    this._service.submitResizeData(this.partitionResizeData).subscribe(
      (response) => {
        
        if (response.code == "200") {
          this.message = response.partitionName + ":-" + response.message;
        } else {
          this.message = response.partitionName + ":-" + response.errorMessage;
          
        }
        this.loading=false;
        this.messageModal.show();
        this.closeModal();
        
      }
    )
    
  }
  callBackToPartitionList() {
    this.clearData();
    this.messageEvent5.emit();
  }

  // setValuesToForm(backOperationCount) {
  //   this.form.get('ModifiedUserKeys').setValue(this.resizeDataList[backOperationCount]['ModifiedUserKeys']);
  //   this.form.get('ModifiedSSLContexts').setValue(this.resizeDataList[backOperationCount]['ModifiedSSLContexts']);
  //   this.form.get('ModifiedAccelDevices').setValue(this.resizeDataList[backOperationCount]['ModifiedAccelDevices']);
  // }

  clearData() {
    this.form.reset();
    this.partitionCount = 1;
    this.totalPartitionCount = 0;
    this.selectedPartitionList = [];
    this.partitionName = '';
    this.finalPartitionList = []
    this.showBackButton = false;
    this.showNextButton = true;
    this.showFinalResize = false;
    this.resizeDataList = [];
    this.ModifiedUserKeys = 0;
    this.ModifiedSSLContexts = 0;
    this.ModifiedAccelDevices = 0;
    this.partitionResizeData = {};
    
    
  }

  getUserKeys(value) {

    let allocatedUserKeys = this.partitionResizeData['partitionData']['allocatedUserKeys'];
    this.ModifiedUserKeys=parseInt(value)+parseInt(allocatedUserKeys); 
    if (this.ModifiedUserKeys < allocatedUserKeys) {
      this.partitionResizeData['partitionData']['incrementKeys'] = false;
      this.partitionResizeData['partitionData']['modifiedUserKeys'] = value*(-1);
    } else if(this.ModifiedUserKeys > allocatedUserKeys) {
      this.partitionResizeData['partitionData']['incrementKeys'] = true;
      this.partitionResizeData['partitionData']['modifiedUserKeys'] = value*(1);
    }
    if (value == 0) {
      this.ModifiedUserKeys= 0;

    }
  }
  getSslContexts(value) {
    let allocatedSSLContexts = this.partitionResizeData['partitionData']['allocatedSSLContexts'];
    this.ModifiedSSLContexts=parseInt(value)+parseInt(allocatedSSLContexts); 
    if (this.ModifiedSSLContexts < allocatedSSLContexts) {
      this.partitionResizeData['partitionData']['incrementSslContexts'] = false;
      this.partitionResizeData['partitionData']['modifiedSSLContexts'] = value*(-1);
    } else if(this.ModifiedSSLContexts > allocatedSSLContexts){
      this.partitionResizeData['partitionData']['incrementSslContexts'] = true;
      this.partitionResizeData['partitionData']['modifiedSSLContexts'] = value*(1);
    }
    
    if (value == 0) {
      this.ModifiedSSLContexts = 0;

    }
  }
  getAcclrDev(value) {
    let allocatedAccelDevices = this.partitionResizeData['partitionData']['allocatedAccelDevices'];
    this.ModifiedAccelDevices=parseInt(value)+parseInt(allocatedAccelDevices); 
    if (this.ModifiedAccelDevices < allocatedAccelDevices) {
      this.partitionResizeData['partitionData']['incrementAcclrDev'] = false;
      this.partitionResizeData['partitionData']['modifiedAccelDevices'] = value*(-1);
    } else if(this.ModifiedAccelDevices > allocatedAccelDevices){
      this.partitionResizeData['partitionData']['incrementAcclrDev'] = true;
      this.partitionResizeData['partitionData']['modifiedAccelDevices'] = value*(1);
    }
    

    if (value == 0) {
      this.ModifiedAccelDevices = 0;
    }
  }

  changeBackUp(event){
    debugger;
    if(event.checked){
      this.backupChecked=true;
    }else{
      this.backupChecked=false;
    }
  }
  closeModal(){
   if(this.partitionCount==this.totalPartitionCount){
      
      this.resizeModal.hide();
      this.clearData();
   }
    
  }
}
