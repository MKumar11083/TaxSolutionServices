
import { Component, OnInit, ViewChild, Input, TemplateRef } from '@angular/core';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, FormControl, FormArray } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { Router } from '@angular/router';
import { TabsetComponent } from 'ngx-bootstrap';
import { PartitionManagementService } from './../../../../services/partitionmanagement/partitionmanagement.service';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BsModalService } from 'ngx-bootstrap/modal';


declare var jquery: any;
declare var $: any;
declare var bootbox: any;
@Component({
  selector: 'app-createnewpartition',
  templateUrl: './createnewpartition.component.html',
  styleUrls: ['./createnewpartition.component.css']
})
export class CreatenewpartitionComponent implements OnInit {
  @ViewChild('staticTabs') staticTabs: TabsetComponent;
  @ViewChild('insideTabs') insideTabs: TabsetComponent;
  @Input() selectedApplianceList;
  form: FormGroup;
  addAdvanced: FormGroup;
  tab: string;
  staticHostIp = [];
  dnsServers = [];
  domainNames = [];
  displayError: string;
  displayError1: string;
  successMessage: string;
  message: string;
  modalRef: BsModalRef;
  classStatic: string;
  classServer: string;
  classDomain: string;
  public loading = false;
  availableKeys: number = 0;
  availableAcceleration: Number = 0;
  availableSSLContext: Number = 0;
  constructor(
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private router: Router,
    private builder: FormBuilder,
    private _service: PartitionManagementService,
    private modalService: BsModalService, ) { }


  ngOnInit() {
    debugger;
    this.availableAcceleration = 0;
    this.availableKeys = 0;
    this.availableSSLContext = 0;
    let totalKeys = this.selectedApplianceList[0]['totalKeys'];
    let occupiedKeys = this.selectedApplianceList[0]['occupiedKeys'];
    let totalAcclr = this.selectedApplianceList[0]['totalAcclrDevice'];
    let occupiedAcclr = this.selectedApplianceList[0]['occupiedAcclrDev'];
    let totalsslContext = this.selectedApplianceList[0]['totalContexts'];
    let occupiedsslContext = this.selectedApplianceList[0]['occupiedContexts']
    this.availableKeys = parseInt(totalKeys) - parseInt(occupiedKeys);
    this.availableAcceleration = parseInt(totalAcclr) - parseInt(occupiedAcclr);
    this.availableSSLContext = parseInt(totalsslContext) - parseInt(occupiedsslContext);
    this.createForm();
    this.initItemRows(null, null, null);
    this.tab = "1";
    // set the appliance details to the form.
    this.classStatic = "btn-primary";
    this.classServer = "btn-default";
    this.classDomain = "btn-default";
    this.form.get('networkStats.general.eth0.ip').disable();
    this.form.get('networkStats.general.eth0.gateway').disable();
    this.form.get('networkStats.general.eth0.subnet').disable();
    this.form.get('networkStats.general.eth0.address').disable();
    this.form.get('networkStats.general.eth1.ip').disable();
    this.form.get('networkStats.general.eth1.subnet').disable();
    this.form.get('networkStats.general.eth1.address').disable();


  }
  // create form for createpartition .
  createForm() {
    this.form = this.builder.group({
      partitionName: ['', Validators.required],
      csr: [null],
      keys: [1, Validators.required],
      sslContexts: [1, Validators.required],
      acclrDev: [1, Validators.required],
      wrap: [''],
      backup: [''],
      applianceDetailModel: this.builder.group({
        applianceId: [null],
        applianceName: [null],
        applianceStatus: [null],
        serialNumber: [null],
        networkTimezone: [null],
        gatewayIp: [null],
        ipAddress: [null],
        networkId: [null],
        subnetMask: [null],
      }),
      networkStats: this.builder.group({
        general: this.builder.group({
          eth0: this.builder.group({
            ethName: ['eth0'],
            dhcp: [true],
            ip: [null],
            gateway: [null],
            subnet: [null],
            hostname: [null],
            staticMac: [null],
            address: [null],
            vlan: [null],
          }),
          eth1: this.builder.group({
            ethName: ['eth1'],
            dhcp: [true],
            disableEth1: [true],
            ip: [null],
            gateway: [null],
            subnet: [null],
            hostname: [null],
            staticMac: [null],
            address: [null],
            vlan: [null],
            id: [null],
          })
        }),
        advanced: this.builder.group({
          staticIpToHostConfig: this.builder.group({
            add: new FormArray([]),

          }),
          dnsConfig: this.builder.group({
            dnsServers: new FormArray([]),
            searchDomainNames: new FormArray([]),
            enableService: [true]
          }),
          ip: [''],
          hostname: [''],
          alias: [''],
          id: [''],
          dnsServer: [''],
          searchDomainName: ['']
        })
      }),
      partitionCertificate: [null],
      errorMessage: [null],
      username: [null],
      password: [null]
    });
  }

  initItemRows(ip, hostname, alias) {
    return this.addAdvanced = this.builder.group({
      ip: ip,
      hostname: hostname,
      alias: alias,
      id: [null]
    });

  }

  setApplianceDataToForm() {
    debugger;
    if (this.selectedApplianceList[0]['applianceId'] != null && this.selectedApplianceList[0]['applianceId'] != "") {
      this.form.get('applianceDetailModel.applianceId').setValue(this.selectedApplianceList[0]['applianceId']);
    }
    if (this.selectedApplianceList[0]['applianceName'] != null && this.selectedApplianceList[0]['applianceName'] != "") {
      this.form.get('applianceDetailModel.applianceName').setValue(this.selectedApplianceList[0]['applianceName']);
    }
    if (this.selectedApplianceList[0]['applianceStatus'] != null && this.selectedApplianceList[0]['applianceStatus'] != "") {
      this.form.get('applianceDetailModel.applianceStatus').setValue(this.selectedApplianceList[0]['applianceStatus']);
    }
    if (this.selectedApplianceList[0]['serialNumber'] != null && this.selectedApplianceList[0]['serialNumber'] != "") {
      this.form.get('applianceDetailModel.serialNumber').setValue(this.selectedApplianceList[0]['serialNumber']);
    }
    if (this.selectedApplianceList[0]['networkTimezone'] != null && this.selectedApplianceList[0]['networkTimezone'] != "") {
      this.form.get('applianceDetailModel.networkTimezone').setValue(this.selectedApplianceList[0]['networkTimezone']);
    }
    if (this.selectedApplianceList[0]['gatewayIp'] != null && this.selectedApplianceList[0]['gatewayIp'] != "") {
      this.form.get('applianceDetailModel.gatewayIp').setValue(this.selectedApplianceList[0]['gatewayIp']);
    }
    if (this.selectedApplianceList[0]['ipAddress'] != null && this.selectedApplianceList[0]['ipAddress'] != "") {
      this.form.get('applianceDetailModel.ipAddress').setValue(this.selectedApplianceList[0]['ipAddress']);
    }
    if (this.selectedApplianceList[0]['networkId'] != null && this.selectedApplianceList[0]['networkId'] != "") {
      this.form.get('applianceDetailModel.networkId').setValue(this.selectedApplianceList[0]['networkId']);
    }
    if (this.selectedApplianceList[0]['subnetMask'] != null && this.selectedApplianceList[0]['subnetMask'] != "") {
      this.form.get('applianceDetailModel.subnetMask').setValue(this.selectedApplianceList[0]['subnetMask']);
    }
    if (this.selectedApplianceList[0]['userName'] != null && this.selectedApplianceList[0]['userName'] != "") {
      this.form.get('username').setValue(this.selectedApplianceList[0]['userName']);
    }
    if (this.selectedApplianceList[0]['userPassword'] != null && this.selectedApplianceList[0]['userPassword'] != "") {
      this.form.get('password').setValue(this.selectedApplianceList[0]['userPassword']);
    }
  }

  onErrorOperation(errResp) {

  }

  // create a form errors
  public formValidationFields = {
    "partitionName": '',
    "csr": '',
    "keys": '',
    "sslContexts": '',
    "acclrDev": '',
    "wrap": '',
    "backup": '',
    "networkStats": {
      "general": {
        "eth0": {
          "ip": {

          }
        }
      }
    }
  }

  isFieldValid(field: string) {
    if (this.form.get(field).touched) {
      if(field=="keys"){
        this.isValidKeys=true;
      }
      if(field=="sslContexts"){
        this.isValidSSLValue=true;
      }
      if(field=="acclrDev"){
        this.isValidAcclr=true;
      }
      this.formValidationFields = this._fieldErrorDisplayService.validateField(this.form, field, this.formValidationFields, "createPartition")
    }
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  selectTab(tab_id: string) {
    if (tab_id == "1") {
      this.classStatic = "btn-primary";
      this.classServer = "btn-default";
      this.classDomain = "btn-default";
    } else if (tab_id == "2") {
      this.classStatic = "btn-default";
      this.classServer = "btn-primary";
      this.classDomain = "btn-default";
    } else if (tab_id == "3") {
      this.classStatic = "btn-default";
      this.classServer = "btn-default";
      this.classDomain = "btn-primary";
    }
    this.tab = tab_id;
    this.displayError = "";
  }

  isEth0IpValidate: boolean = false;
  isEth1IpValidate: boolean = false;
  eth0MacAddress: boolean = false;
  eth1MacAddress: boolean = false;
  onSubmit(isValid, template: TemplateRef<any>) {
    debugger;
    if (isValid) {
      this.isEth0IpValidate = false;
      this.isEth1IpValidate = false;
      this.eth0MacAddress = false;
      this.eth1MacAddress = false;
      let eth0DHCP = this.form.get('networkStats.general.eth0.dhcp').value;
      if (!eth0DHCP) {
        if (this.form.get('networkStats.general.eth0.ip').value == null || this.form.get('networkStats.general.eth0.ip').value == '') {
          this.isEth0IpValidate = true;
        }
      }
      let eth1DHCP = this.form.get('networkStats.general.eth1.dhcp').value;
      if (!eth1DHCP) {
        if (this.form.get('networkStats.general.eth1.ip').value == null || this.form.get('networkStats.general.eth1.ip').value == '') {
          this.isEth1IpValidate = true;
        }
      }
      let eth0StaticMac = this.form.get('networkStats.general.eth0.staticMac').value;
      if (eth0StaticMac) {
        if (this.form.get('networkStats.general.eth0.address').value == null || this.form.get('networkStats.general.eth0.address').value == '') {
          this.eth0MacAddress = true;
        }
      }
      let eth1StaticMac = this.form.get('networkStats.general.eth1.staticMac').value;
      if (eth1StaticMac) {
        if (this.form.get('networkStats.general.eth1.address').value == null || this.form.get('networkStats.general.eth1.address').value == '') {
          this.eth1MacAddress = true;
        }
      }
      let disableEth1 = this.form.get('networkStats.general.eth1.disableEth1').value;
      // if((this.isEth0IpValidate == true) || (this.isEth1IpValidate==true) ){

      //   debugger;

      //   this.message = "Please fill the details in the Interface Section"

      //   this.modalRef = this.modalService.show(template, { class: 'modal-sm' });

      //   }
if(this.isValidAlphaNumeric==true && this.isValidAlphaNumeric1==true && this.isValidIp==true && this.isValidIp1==true
  && this.isValidmacAddress==true && this.isValidmacAddress1==true){
      if (!this.isEth0IpValidate) {
        if (!this.eth0MacAddress) {
          if (disableEth1) {
            if (!this.isEth1IpValidate) {
              if (!this.eth1MacAddress) {
                this.setApplianceDataToForm();
                this.loading = true;
                if (this.form.get('networkStats.general.eth0.dhcp').value) {
                  this.form.get('networkStats.general.eth0.ip').reset();
                  this.form.get('networkStats.general.eth0.gateway').reset();
                  this.form.get('networkStats.general.eth0.subnet').reset();
                }
                if (this.form.get('networkStats.general.eth1.dhcp').value) {
                  this.form.get('networkStats.general.eth1.ip').reset();
                  this.form.get('networkStats.general.eth1.subnet').reset();
                }
                if (this.form.get('networkStats.general.eth0.staticMac').value == false) {
                  this.form.get('networkStats.general.eth0.address').reset();
                }
                if (this.form.get('networkStats.general.eth1.staticMac').value == false) {
                  this.form.get('networkStats.general.eth1.address').reset();
                }
                if (!this.form.get('networkStats.general.eth1.disableEth1').value) {
                  this.form.get('networkStats.general.eth1.dhcp').reset();
                  this.form.get('networkStats.general.eth1.ip').reset();
                  this.form.get('networkStats.general.eth1.subnet').reset();
                  this.form.get('networkStats.general.eth1.staticMac').reset();
                  this.form.get('networkStats.general.eth1.address').reset();
                  this.form.get('networkStats.general.eth1.disableEth1').setValue(true);
                } else {
                  this.form.get('networkStats.general.eth1.disableEth1').setValue(false);
                }
                const control = <FormControl>this.form.get('networkStats').get('advanced').
                  get('dnsConfig').get('enableService');
                control.setValue(true);
                this._service.createPartition(this.form.value).subscribe(
                  res => {
                    this.loading = false;
                    if (res.code == "200") {
                      let message = "<b>" + res.message + "</b>"
                      bootbox.dialog({
                        message: message,
                        buttons: {
                          Ok: {
                            label: "Close",
                            className: 'btn btn-primary btn-flat',
                            callback: () => this.redirectToPartitionList()
                          }
                        }
                      });
                    } else {
                      //this.displayError1 = res.errorMessage;
                      let message = "<b>" + res.errorMessage + "</b>"
                      bootbox.dialog({
                        message: message,
                        buttons: {
                          cancel: {
                            label: "Close",
                            className: 'btn btn-primary btn-flat'
                          }

                        }
                      });
                    }
                  },
                  error => {
                    console.log(error);
                  },
                );
              } else {
                this.staticTabs.tabs[1].active = true;
              }
            } else {
              this.staticTabs.tabs[1].active = true;
            }
          } else {
            this.isEth1IpValidate = false;
            this.eth1MacAddress = false;
            this.setApplianceDataToForm();
            this.loading = true;
            if (this.form.get('networkStats.general.eth0.dhcp').value) {
              this.form.get('networkStats.general.eth0.ip').reset();
              this.form.get('networkStats.general.eth0.gateway').reset();
              this.form.get('networkStats.general.eth0.subnet').reset();
            }
            if (this.form.get('networkStats.general.eth1.dhcp').value) {
              this.form.get('networkStats.general.eth1.ip').reset();
              this.form.get('networkStats.general.eth1.subnet').reset();
            }
            if (this.form.get('networkStats.general.eth0.staticMac').value == false) {
              this.form.get('networkStats.general.eth0.address').reset();
            }
            if (this.form.get('networkStats.general.eth1.staticMac').value == false) {
              this.form.get('networkStats.general.eth1.address').reset();
            }
            if (!this.form.get('networkStats.general.eth1.disableEth1').value) {
              this.form.get('networkStats.general.eth1.dhcp').reset();
              this.form.get('networkStats.general.eth1.ip').reset();
              this.form.get('networkStats.general.eth1.subnet').reset();
              this.form.get('networkStats.general.eth1.staticMac').reset();
              this.form.get('networkStats.general.eth1.address').reset();
              this.form.get('networkStats.general.eth1.disableEth1').setValue(true);
            } else {
              this.form.get('networkStats.general.eth1.disableEth1').setValue(false);
            }
            const control = <FormControl>this.form.get('networkStats').get('advanced').
              get('dnsConfig').get('enableService');
            control.setValue(true);
            this._service.createPartition(this.form.value).subscribe(
              res => {
                this.loading = false;
                if (res.code == "200") {
                  let message = "<b>" + res.message + "</b>"
                  bootbox.dialog({
                    message: message,
                    buttons: {
                      Ok: {
                        label: "Close",
                        className: 'btn btn-primary btn-flat',
                        callback: () => this.redirectToPartitionList()
                      }
                    }
                  });
                } else {
                  //this.displayError1 = res.errorMessage;
                  let message = "<b>" + res.errorMessage + "</b>"
                  bootbox.dialog({
                    message: message,
                    buttons: {
                      cancel: {
                        label: "Close",
                        className: 'btn btn-primary btn-flat'
                      }

                    }
                  });
                }
              },
              error => {
                console.log(error);
              },
            );
          }
        } else {
          this.staticTabs.tabs[1].active = true;
        }
      } else {
        this.staticTabs.tabs[1].active = true;
      }
    }
    } else {
      this.formValidationFields = this._fieldErrorDisplayService.validateForm(this.form, this.formValidationFields, "createPartition", false)
      this.staticTabs.tabs[0].active = true;
    }

  }
  redirectToPartitionList() {
    this.router.navigateByUrl("/listPartition");
  }

  addStaticHostIp() {
    debugger;
    this.displayError = "";
    if (this.form.get('networkStats.advanced.ip').value != "" && this.form.get('networkStats.advanced.hostname').value != "") {
      if (this.staticHostIp.length < 16) {
        let ip = this.form.get('networkStats.advanced.ip').value;
        let hostname = this.form.get('networkStats.advanced.hostname').value;
        let alias = this.form.get('networkStats.advanced.alias').value;
        const control = <FormArray>this.form.get('networkStats').get('advanced').get('staticIpToHostConfig').get('add');
        let staticHostIpData = {};

        staticHostIpData['ip'] = ip;
        staticHostIpData['hostname'] = hostname;
        staticHostIpData['alias'] = alias;
        // this.addAdvanced.get('ip').setValue(ip);
        // this.addAdvanced.get('hostname').setValue(hostname);
        // this.addAdvanced.get('alias').setValue(alias);
        control.push(this.initItemRows(ip, hostname, alias));
        // if (this.staticHostIp.length == 0) {
        //   control.removeAt(1);
        // }
        this.staticHostIp.push(staticHostIpData);

        this.form.get('networkStats.advanced.ip').setValue("");
        this.form.get('networkStats.advanced.hostname').setValue("");
        this.form.get('networkStats.advanced.alias').setValue("");
      } else {
        this.displayError = "Maximum records to add is 16."
      }
    } else {
      this.displayError = "Please enter the required fields"
    }
  }

  removeStaticHostIp(index) {
    const control = <FormArray>this.form.get('networkStats').get('advanced').get('staticIpToHostConfig').get('add');
    // remove the chosen row
    control.removeAt(index);
    let indexAt = this.staticHostIp.indexOf(index);
    this.staticHostIp.splice(indexAt);
  }

  addDnsServer() {
    debugger;
    this.displayError = "";
    if (this.dnsServers.length < 4) {
      if (this.form.get('networkStats.advanced.dnsServer').value != "") {
        const control = <FormArray>this.form.get('networkStats').get('advanced').
          get('dnsConfig').get('dnsServers');
        // control.push(this.form.get('networkStats.advanced.dnsServer').value);
        control.push(new FormControl(this.form.get('networkStats.advanced.dnsServer').value));
        this.dnsServers.push(this.form.get('networkStats.advanced.dnsServer').value);
        this.form.get('networkStats.advanced.dnsServer').setValue("");
      } else {
        this.displayError = "Please enter the required field";

      }
    } else {
      this.displayError = "Maximum records to add is 4."
    }
  }


  removeDnsServers(index) {
    debugger;
    const control = <FormArray>this.form.get('networkStats').get('advanced')
      .get('dnsConfig').get('dnsServers');
    // remove the chosen row
    control.removeAt(index);
    let indexAt = this.dnsServers.indexOf(index);
    this.dnsServers.splice(indexAt);
  }

  addDomainName() {
    debugger;
    this.displayError = "";
    if (this.domainNames.length < 4) {
      if (this.form.get('networkStats.advanced.searchDomainName').value != "") {
        const control = <FormArray>this.form.get('networkStats').get('advanced').
          get('dnsConfig').get('searchDomainNames');
        // control.push(this.form.get('networkStats.advanced.dnsServer').value);
        control.push(new FormControl(this.form.get('networkStats.advanced.searchDomainName').value));
        this.domainNames.push(this.form.get('networkStats.advanced.searchDomainName').value);
        this.form.get('networkStats.advanced.searchDomainName').setValue("");
      } else {
        this.displayError = " Please enter the required field"
      }
    } else {
      this.displayError = " Maximum records to add is 4."
    }
  }

  removeSearchDomain(index) {
    const control = <FormArray>this.form.get('networkStats').get('advanced')
      .get('dnsConfig').get('searchDomainNames');
    // remove the chosen row
    control.removeAt(index);
    let indexAt = this.domainNames.indexOf(index);
    this.domainNames.splice(indexAt);
  }

  toggleDhcpEth0(event) {
    this.form.get('networkStats.general.eth0.ip').reset();
    this.form.get('networkStats.general.eth0.gateway').reset();
    this.form.get('networkStats.general.eth0.subnet').reset();
    this.isEth0IpValidate = false;
    if (event.checked) {
      this.form.get('networkStats.general.eth0.ip').disable();
      this.form.get('networkStats.general.eth0.gateway').disable();
      this.form.get('networkStats.general.eth0.subnet').disable();
    } else {
      this.form.get('networkStats.general.eth0.ip').enable();
      this.form.get('networkStats.general.eth0.gateway').enable();
      this.form.get('networkStats.general.eth0.subnet').enable();
    }
  }

  toggleDhcpEth1(event) {
    this.form.get('networkStats.general.eth1.ip').reset();
    this.form.get('networkStats.general.eth1.subnet').reset();
    this.isEth1IpValidate = false;
    if (event.checked) {
      this.form.get('networkStats.general.eth1.ip').disable();
      this.form.get('networkStats.general.eth1.subnet').disable();
    } else {
      this.form.get('networkStats.general.eth1.ip').enable();
      this.form.get('networkStats.general.eth1.subnet').enable();
    }
  }

  disableEth1Fields(event) {
    debugger;
    this.form.get('networkStats.general.eth1.dhcp').reset();
    // this.form.get('networkStats.general.eth1.ip').reset();
    // this.form.get('networkStats.general.eth1.subnet').reset();
    this.form.get('networkStats.general.eth1.hostname').reset();
    this.form.get('networkStats.general.eth1.staticMac').reset();
    this.form.get('networkStats.general.eth1.address').reset();
    this.form.get('networkStats.general.eth1.vlan').reset();
    if (event.checked) {
      this.form.get('networkStats.general.eth1.dhcp').enable();
      this.form.get('networkStats.general.eth1.dhcp').setValue(true);
      // this.form.get('networkStats.general.eth1.ip').enable();
      // this.form.get('networkStats.general.eth1.subnet').enable();
      this.form.get('networkStats.general.eth1.hostname').enable();
      this.form.get('networkStats.general.eth1.staticMac').enable();
      this.form.get('networkStats.general.eth1.address').disable();
      this.form.get('networkStats.general.eth1.vlan').enable();
    } else {

      this.form.get('networkStats.general.eth1.dhcp').disable();
      // this.form.get('networkStats.general.eth1.ip').disable();
      // this.form.get('networkStats.general.eth1.subnet').disable();
      this.form.get('networkStats.general.eth1.hostname').disable();
      this.form.get('networkStats.general.eth1.staticMac').disable();
      this.form.get('networkStats.general.eth1.address').disable();
      this.form.get('networkStats.general.eth1.vlan').disable();
    }
  }

  toggleMacAddressEth0(event) {
    this.eth0MacAddress = false;
    this.form.get('networkStats.general.eth0.address').reset();
    if (event.checked) {
      this.form.get('networkStats.general.eth0.address').enable();
    } else {
      this.form.get('networkStats.general.eth0.address').disable();
    }
  }

  toggleMacAddressEth1(event) {
    this.eth1MacAddress = false;
    this.form.get('networkStats.general.eth1.address').reset();
    if (event.checked) {
      this.form.get('networkStats.general.eth1.address').enable();
    } else {
      this.form.get('networkStats.general.eth1.address').disable();
    }
  }

  public OnlyNumericValues(e) {
    let input;
    if (e.metaKey || e.ctrlKey) {
      return true;
    }
    if (e.which === 32) {
      return false;
    }
    if (e.which === 0) {
      return true;
    }
    if (e.which < 33) {
      return true;
    }
    input = String.fromCharCode(e.which);
    return !!/[\d\s]/.test(input);
  }

  closeMessage() {
    this.displayError1 = "";
  }
  clearErrors() {
    this.isEth0IpValidate = false;
  }
  clearErrors1() {
    this.isEth1IpValidate = false;
  }
  clearMacAddressError1() {
    this.eth1MacAddress = false;
  }
  clearMacAddressError() {
    this.eth0MacAddress = false;
  }

  isValidIp = true;
  validateIPaddress(inputText) {
    this.isValidIp = true;
    var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    // var form = document.getElementById('form1');
    // var x;
    // x = (<HTMLInputElement>document.getElementById("ip")).value;
    if (inputText != '') {
      if (inputText.match(ipformat)) {
        this.isValidIp = true;
      }
      else {
        this.isValidIp = false;
      }
    }
  }

  isValidIp1 = true;
  validateIPaddress1(inputText) {
    this.isValidIp1 = true;
    var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    // var form = document.getElementById('form1');
    // var x;
    // x = (<HTMLInputElement>document.getElementById("ip")).value;
    if (inputText != '') {
      if (inputText.match(ipformat)) {
        this.isValidIp1 = true;
      }
      else {
        this.isValidIp1 = false;
      }
    }
  }

  isValidIp2 = true;
  validateIPaddress2(inputText) {
    this.isValidIp2 = true;
    var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    // var form = document.getElementById('form1');
    // var x;
    // x = (<HTMLInputElement>document.getElementById("ip")).value;
    if (inputText != '') {
      if (inputText.match(ipformat)) {
        this.isValidIp2 = true;
      }
      else {
        this.isValidIp2 = false;
      }
    }
  }

isValidHostname=true;
ValidateHostname(inputText){
  this.isValidHostname = true;
  var hostname=/^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9\-]*[A-Za-z0-9])$/;
  var form = document.getElementById('form1');
  if (inputText != '') {
    if (inputText.match(hostname)) {
      this.isValidHostname = true;
    }
    else {
      this.isValidHostname = false;    
    }
  }
}

  isValidmacAddress=true;
  ValidatMacAddress(inputText){
    this.isValidmacAddress = true;
    var macaddress= /^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/;
    var form = document.getElementById('form1');
    if (inputText != '') {
      if (inputText.match(macaddress)) {
        this.isValidmacAddress = true;
      }
      else {
        this.isValidmacAddress = false;    
      }
    }
  }

isValidmacAddress1=true;
ValidatMacAddress1(inputText){
  this.isValidmacAddress1 = true;
  var macaddress= /^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/;
  var form = document.getElementById('form1');
  if (inputText != '') {
    if (inputText.match(macaddress)) {
      this.isValidmacAddress1 = true;
    }
    else {
      this.isValidmacAddress1 = false;    
    }
  }
}

  isValidAlphaNumeric = true;
  validateAlphanumeric(inputText) {
    this.isValidAlphaNumeric = true;
    var alphanumericformat = /^[A-Za-z0-9_:]+$/;
    if (inputText != '') {
      if (inputText.match(alphanumericformat)) {
        this.isValidAlphaNumeric = true;
      }
      else {
        this.isValidAlphaNumeric = false;
      }
    }
  }

  isValidAlphaNumeric1 = true;
  validateAlphanumeric1(inputText) {
    this.isValidAlphaNumeric1 = true;
    var alphanumericformat = /^[A-Za-z0-9_]+$/;
    if (inputText != '') {
      if (inputText.match(alphanumericformat)) {
        this.isValidAlphaNumeric1 = true;
      }
      else {
        this.isValidAlphaNumeric1 = false;
      }
    }
  }
  isValidKeys = true;
  isValidAcclr = true;
  isValidSSLValue = true;
  checkMaxKeyValue(maxValue: Number) {
    this.isValidKeys = true;
    if (maxValue > this.availableKeys) {
      this.form.get('keys').reset();
      this.isValidKeys=false;
      return false;
    } else {
      return true;
    }

  }
  checkMaxAcclrValue(maxValue: Number) {
    this.isValidAcclr=true;
    if (maxValue > this.availableAcceleration) {
      this.form.get('acclrDev').reset();
      this.isValidAcclr=false;
      return false;
    } else {
      return true;
    }
  }
  checkMaxSSLValue(maxValue: Number) {
    this.isValidSSLValue= true;
    if (maxValue > this.availableSSLContext) {
      this.form.get('sslContexts').reset();
      this.isValidSSLValue= false;
      return false;
    } else {
      return true;
    }

  }
}





