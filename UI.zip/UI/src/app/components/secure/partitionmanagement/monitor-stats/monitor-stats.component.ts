import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { PartitionManagementService } from './../../../../services/partitionmanagement/partitionmanagement.service';
import { TabDirective } from 'ngx-bootstrap/tabs';
import { TabsetComponent } from 'ngx-bootstrap';

declare var $: any;
declare var jQuery: any;
@Component({
  selector: 'app-monitor-stats',
  templateUrl: './monitor-stats.component.html',
  styleUrls: ['./monitor-stats.component.css']
})
export class MonitorStatsComponent implements OnInit {
  @ViewChild('monitorModal3') monitorModal3: ModalDirective;
  @ViewChild('monitorLogin3') monitorLogin3: ModalDirective;
  @ViewChild('messageModal3') messageModal3: ModalDirective;
  @ViewChild('monitorTabs') monitorTabs: TabsetComponent;
  @ViewChild('memoryTab') memoryTab: TabsetComponent;
  @Input() applianceData;
  loginForm: FormGroup;
  autenticationDetailsArray: any = [];
  loading: boolean = false;
  responseArray: any = [];
  cpuList :any = [];
  memoryList :any =[];
  pcpuList :any =[];
  isMemoryUsage : boolean = true;
  constructor(private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _formBuilder: FormBuilder,
    private _service: AppliancemanagementService,
    private _service1: PartitionManagementService) { }

  ngOnInit() {
    this.cpuList = [];
    this.memoryList  =[];
    this.pcpuList  =[];
    this.createLoginForm();
  }
  createLoginForm() {
    this.loginForm = this._formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
    });
  }

  public formValidationFields1 = {
    "username": '',
    "password": ''

  }
  isFieldValid1(field: string) {
    if (this.loginForm.get(field).touched) {
      this.formValidationFields1 = this._fieldErrorDisplayService.validateField(this.loginForm, field, this.formValidationFields1, "login")
    }
    return !this.loginForm.get(field).valid && this.loginForm.get(field).touched;
  }

  displayFieldCss1(field: string) {
    return {
      'has-error': this.isFieldValid1(field),
      'has-feedback': this.isFieldValid1(field)
    };
  }

  showMonitorStats() {
    this.isMemoryUsage =true;
    this.cpuList = [];
    this.memoryList  =[];
    this.pcpuList  =[];
    this.loginForm.reset();
    this.monitorLogin3.show();
  }

  submitLoginDetails() {
    let loginDetailsModal = {};
    loginDetailsModal['applianceId'] = this.applianceData.applianceId;
    loginDetailsModal['applianceName'] = this.applianceData.applianceName;
    loginDetailsModal['ipAddress'] = this.applianceData.ipAddress;
    loginDetailsModal['operationUsername'] = this.loginForm.get('username').value;
    loginDetailsModal['operationPassword'] = this.loginForm.get('password').value;
    this.autenticationDetailsArray.push(loginDetailsModal);
    this.checkAppliancesCredentials();
  }

  checkAppliancesCredentials() {
    this.loading = true;
    this.responseArray = [];
    this.monitorLogin3.hide();
    this._service.checkAppliancesCredentials(this.autenticationDetailsArray).subscribe(
      (response) => {
        this.loading = false;
        let isSuccess: boolean = true;
        this.autenticationDetailsArray = [];
        response.forEach(obj => {
          if (obj.code != "200") {
            this.responseArray.push(obj);
            isSuccess = false;
          }
        });
        if (isSuccess) {
          this.getMonitorStatsDetails();
        } else {
          this.messageModal3.show();
        }
      },
      (error) => {
        console.log(error);
      })
  }

  getMonitorStatsDetails(){
    let applianceArray = this.setValuesToGetData();
    this._service1.getPartitionMonitorStatsDetails(applianceArray).subscribe(
      (response) => {
        this.monitorModal3.show();
        response.forEach(resp => {
        
          let res1 = JSON.parse(resp.message);

          if(res1.cpu!=null && res1.cpu!=''){
            this.cpuList = res1.cpu;
          }
          if(res1.memory!=null && res1.memory!=''){
            this.memoryList = res1.memory;
          }
          if(res1.pcpu!=null && res1.pcpu!=''){
            this.pcpuList = res1.pcpu;
          }
        });
 
      },
      (error)=>{
        console.log(error);
      }
    )
  }

  setValuesToGetData() {
    debugger;
    let applianceData = {
      'partitionName': this.applianceData.partitionName,
      'partitionId': this.applianceData.partitionId,
      'sessionClose': 0,
      'username': this.loginForm.get('username').value,
      'password': this.loginForm.get('password').value,
      'applianceDetailModel': {
        'applianceId': this.applianceData.applianceId,
        'applianceName': this.applianceData.applianceName,
        'ipAddress': this.applianceData.ipAddress
      }
    };
    let applianceArray: any = [];
    applianceArray.push(applianceData);
    return applianceArray;
  }

  showUsage(){
    this.isMemoryUsage = true;
  }
  showDetails(){
    this.isMemoryUsage = false;
  }
}
