import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MonitorConfigComponent } from './monitor-config.component';

describe('MonitorConfigComponent', () => {
  let component: MonitorConfigComponent;
  let fixture: ComponentFixture<MonitorConfigComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MonitorConfigComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MonitorConfigComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
