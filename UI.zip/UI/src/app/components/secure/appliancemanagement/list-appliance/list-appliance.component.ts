import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { AnonymousSubscription } from "rxjs/Subscription";
import { DataTableResource } from './../../data-table/index';
import { I18nService } from '../../../../services/common/i18n/i18n.service';
import { BreadcrumbService } from './../../../../services/common/breadcrumb.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { InitializeApplianceComponent } from './../../appliancemanagement/initialize-appliance/initialize-appliance.component';
import { ApplianceLoginComponent } from './../../appliancemanagement/appliance-login/appliance-login.component';
// import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { LoadingModule } from 'ngx-loading';
import { Router } from '@angular/router';
import { Observable } from "rxjs/Observable";
import { ApplianceOperationsComponent } from './../../appliancemanagement/appliance-operations/appliance-operations.component';
declare var $: any;
declare var bootbox: any;
declare var jQuery: any;
@Component({
  selector: 'app-list-appliance',
  templateUrl: './list-appliance.component.html',
  styleUrls: ['./list-appliance.component.css'],

})
export class ListApplianceComponent implements OnInit, OnDestroy {
  @ViewChild('initializeAppliance')
  private initializeAppliance: InitializeApplianceComponent;
  @ViewChild('applianceOperations')
  private applianceOperationsComponent: ApplianceOperationsComponent;


  @ViewChild('applianceLogin')
  private applianceLogin: ApplianceLoginComponent;
  title = "Appliance Details";
  private details: string;
  listofAppliancesSubscription: AnonymousSubscription;
  appliancesList: any = [];
  itemResource: any;
  displayErrors: any = [];
  showList: boolean = true;
  showCompareAppliance: boolean = false;
  selectedAppliances: any = [];
  formAdvanced: FormGroup;
  searchApplianceSubsc: AnonymousSubscription;
  valid: boolean = true;
  loginForm: FormGroup;
  public loading = false;
  checkInProgressStatus: boolean = false;
  errorMessage: string;
  templist: any = [];
  itemCount;
  listtrue:boolean=true;
  timer: AnonymousSubscription;
  constructor(private _applianceManagementService: AppliancemanagementService,
    private _I18nService: I18nService,
    private _formBuilder: FormBuilder,
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _router: Router,
  ) { }

  ngOnInit() {
    this.createForm();
    this.selectedAppliances = [];
    this.loadingListAppliances();
    if (sessionStorage.getItem("showList") == "true") {
      this.showList = true;
    } else {
      this.showList = false;
    }
  }

  loadingListAppliances() {
    // this.selectedAppliances = [];
    this.templist=[];
    console.log("loading list of appliances.....");
    this.listofAppliancesSubscription = this._applianceManagementService.getAllListAppliances().subscribe(
      res => {
        this.appliancesList = [];
        this.checkInProgressStatus = false;
        if (res.length > 0) {
          this.listtrue=true;
          this.valid = false;
          document.getElementById("operationTab").style.pointerEvents = "auto";
          res.forEach(applianceObj => {
            let modal = {};
            modal['applianceName'] = applianceObj.applianceName;
            modal['ipAddress'] = applianceObj.ipAddress;
            modal['applianceStatus'] = applianceObj.applianceStatus;
            modal['applianceId'] = applianceObj.applianceId;
            this.templist.push(modal);
            if (applianceObj['lastOperationStatus'] === 'In-Progress') {
              applianceObj['InProgress'] = true;
              this.checkInProgressStatus = true;

            } else {
              applianceObj['InProgress'] = false;
            }
            for (var i = 0; i < this.selectedAppliances.length; i++) {
              if (this.selectedAppliances[i].applianceId == applianceObj.applianceId) {
                applianceObj['checked'] = true;
              }           
            }       
            this.appliancesList.push(applianceObj);
          })
        }
        else {
          this.listtrue=false;
          document.getElementById("operationTab").style.pointerEvents = "none";
        }
        this.reloadApplianceList();
        this.itemResource = new DataTableResource(this.templist);
        this.itemCount = this.templist.length;
      },
      error => {
        document.getElementById("operationTab").style.pointerEvents = "none";
        console.log(error);
      },
    );
  }

  reloadItems(params) {
    if (this.itemResource) {
      this.itemResource.query(params).then(items => this.templist = items);
    }
  }

  reloadApplianceList(): void {
    this.timer = Observable.timer(10000).first().subscribe(() => this.loadingListAppliances());
  }
  clickGetAppliance(event, idName) {
    this.details = "";
    this.appliancesList.find
      (appliance => {
        if (appliance.applianceId == idName) {
          this.details = appliance;
        }
      })
  }

  toggle() {
    this.showList = true;
    sessionStorage.setItem("showList", "true");
  }
  toggle1() {
    this.showList = false;
    sessionStorage.setItem("showList", "false");
  }


  onErrorOperation(error) {
    console.log('OnError' + JSON.stringify(error));
    this.displayErrors = this._I18nService.getI18NMessagesForError(error, "", "");
    console.log('errorMessages -->' + JSON.stringify(this.displayErrors));
  }

  compareAppliance() {
    this.showCompareAppliance = true;
    this.checkValidationsForAppliances();
  }

  checkValidationsForAppliances() {
    if (this.selectedAppliances.length <= 1) {
      this.showCompareAppliance = false;
      $("#displayalert").modal("show");
      this.errorMessage = "Please select atleast two appliance to compare";
    } else if (this.selectedAppliances.length > 6) {
      $("#displayalert").modal("show");
      this.showCompareAppliance = false;
      this.errorMessage = "Maximum appliances to compare is 6";
    }
  }

  selectApplianceItems(event, applianceId: string) {
    debugger;
    if (event.target.checked) {
      event.currentTarget.style.visibility = "visible";
      for (var i = 0; i < this.appliancesList.length; i++) {
        if (this.appliancesList[i].applianceId == applianceId) {
          this.selectedAppliances.push(this.appliancesList[i]);
          this.appliancesList[i]['checked'] = true;
          this.templist[i]['checked'] = true;
        }
        // else if (!this.appliancesList[i]['checked']) {
        //   this.appliancesList[i]['checked'] = false;
        //   this.templist[i]['checked'] = false;
        // }
      }
    } else {
      for (var i = 0; i < this.appliancesList.length; i++) {
        if (this.appliancesList[i].applianceId == applianceId) {
          this.appliancesList[i]['checked'] = false;
          this.templist[i]['checked'] = false;
        }
      }
      const index = this.selectedAppliances.findIndex(appliance => appliance.applianceId === applianceId);
      this.selectedAppliances.splice(index, 1);
    }
    if ((this.selectedAppliances.length == null) || (this.selectedAppliances.length == 0)) {
      $(".floatactionbtn").css("opacity", "0.3");
      $(".floatactionbtn").css("cursor", "not-allowed");
    } else {
      $(".floatactionbtn").css("opacity", "1");
      $(".floatactionbtn").css("cursor", "pointer");
    }
  }

  navigateToCompareAppliance() {
    this.compareAppliance();
    if (this.showCompareAppliance) {
      this._applianceManagementService.setSelectedAppliances(this.selectedAppliances);
      this._applianceManagementService.setAllAppliances(this.appliancesList);
      this._router.navigate(['/compareAppliances']);
    } else {
      return false;
    }
  }


  // create form for advanced search.
  createForm() {
    this.formAdvanced = this._formBuilder.group({
      applianceName: '',
      ipAddress: '',
      applianceStatus: '',
      hostName: '',
      ipmiIp: '',
    });
  }

  // basic search operation
  searchAppliances(id) {
    let applianceDetailsModel = {
      "applianceName": id.value
    }
    this.getSearchResults(applianceDetailsModel);
  }
  // show search modal
  showAdvancedSearch() {
    $("#searchModel").modal("show");
    this.formAdvanced.reset();
  }

  // advance search operation
  advanceSearchAppliances() {
    this.getSearchResults(this.formAdvanced.value);
    $("#searchModel").modal("hide");
  }

  // get the search results
  getSearchResults(applianceDetailsModel) {
    this.searchApplianceSubsc = this._applianceManagementService.searchAppliances(applianceDetailsModel).subscribe(
      response => {
        this.appliancesList = response;
        if (response != null) {
          this.itemResource = new DataTableResource(this.appliancesList);
        }
      },
      error => {
        this.onErrorOperation(error);
      }
    )
  }


  callback() {
    console.log("Callback ----> List Appliance");
    this.selectedAppliances = [];
    this.loadingListAppliances();
  }

  ngOnDestroy() {
    if (this.listofAppliancesSubscription) {
      this.listofAppliancesSubscription.unsubscribe();
    }
    if (this.searchApplianceSubsc) {
      this.searchApplianceSubsc.unsubscribe();
    }
  }

  refreshListAppliancePage() {
    this.loading = true;
    this.loadingListAppliances();
    if (sessionStorage.getItem("showList") == "true") {
      this.showList = true;
    } else {
      this.showList = false;
    }
    this.loading = false;

  }

  subFilterOptions: any = [];
  filterLabel: string;
  getSubFilterList(value) {
    this.subFilterOptions = [];
    this.filterLabel = '';
    this.filterLabel = value;
    // this.subFilterOptions = this.getSubFilterOptions().filter((item) => {
    //   return item.level_id === Number(value)
    // }); 
  }

  showhideFilters: string = '0';
  searchListApplianceByStatus: string = '';
  finalAppliancesList: string;
  searchListApplianceByName: string;
  searchListApplianceByIP: string;

  CheckListAppFilterSelect(value){
    if (value === "0") {
      //alert("none");
      this.searchListApplianceByStatus = '';
      this.searchListApplianceByName = '';
      this.searchListApplianceByIP = '';
    } else if (value === "1") {
      //alert("Name");
      this.searchListApplianceByStatus = '';
      this.searchListApplianceByIP = '';
    }
    else if (value === "2") { 
      //alert("Status");
      this.searchListApplianceByName = '';
      this.searchListApplianceByIP = '';
    }
    else if (value === "3") { 
      //alert("IP");
      this.searchListApplianceByName = '';
      this.searchListApplianceByStatus = '';
    }
  }

  getListApplianceFilterDetails(value) {
    this.filterLabel = value;
    if (this.filterLabel === "1") { // Active status
      alert("Active");
      // this.appliancesList = this.finalappliancesList.filter((item) => {
      //return this.finalAppliancesList = this.appliancesList;
      // }); 
    } else if (this.filterLabel === "2") { // InActive status
      alert("Process");
      // this.appliancesList = this.finalappliancesList.filter((item) => {
      //   return item.partitionData.vmStatus === Number(value)
      // }); 
    }
    else if (this.filterLabel === "3") { // InActive status
      alert("InActive");
      // this.appliancesList = this.finalappliancesList.filter((item) => {
      //   return item.partitionData.vmStatus === Number(value)
      // }); 
    }

  }
  appliancedelete(){
    this.applianceOperationsComponent.submitApplianceOperations(this.selectedAppliances, 'delete');
  }


}