import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { forkJoin } from "rxjs/observable/forkJoin";
import { AdminvmmonitorComponent } from './../../appliancemanagement/adminvmmonitor/adminvmmonitor.component';
import { SnmpConfigureComponent } from './../../appliancemanagement/snmp-configure/snmp-configure.component';
import { ActivatedRoute } from '@angular/router';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, FormControl } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
declare var $: any;
declare var bootbox: any;

@Component({
  selector: 'app-admin-vm',
  templateUrl: './admin-vm.component.html',
  styleUrls: ['./admin-vm.component.css']
})
export class AdminVmComponent implements OnInit {
  @Input() applianceId;
  @Input() ip;

  @Input() applianceModel;
  @ViewChild('monitorComponent1')
  monitorComponent1: AdminvmmonitorComponent;
  @ViewChild('snmpConfigure')
  snmpConfigure: SnmpConfigureComponent;
  @ViewChild('selecterror')
  selecterror: ModalDirective;
  
  successMessage = '';
  errorMessages = [];
  form: FormGroup;
  appAdd: object[] = [];
  loginForm: FormGroup;
  submitApplianceNewtorkData = {};
  applianceObj: any;
  applianceObjAdvanced: object[] = [];
  applianceObjAdvancedDup: object[] = [];
  getApplianceAdvancedData: any;
  staticIpToHostConfigUpdated: object[] = [];
  saveModalFlag = false;
  ipAddressAdd: any;
  HostnameAdd: any;
  AliasAdd: any;
  stats: any = [];
  network: any = [];
  snmp: any = [];
  message: string;
  status: any = [];
  trapStatus: any = [];
  username: any = [];
  managerIp: any = [];
  applianceName: string;
  showlist: boolean = true;
  selfTestReport: string = '';
  selfTestRep: any = [];
  public loading = false;
  // adminVM gauge
  // gaugeLabe = 4;
  // gaugeLabe1 = 7;
  // gaugeLabel = 67;
  gaugeValue4 = [];
  gaugeValue5 = [];
  gaugeValue6 = [];
  gaugeValue7 = [];
  gaugeType = "arch";
  gaugeThickness = 25;
  gaugeThresholdConfig = {
    '0': { color: 'rgb(0,179,30' },
    '60': { color: 'rgb(230,191,0' },
    '80': { color: 'rgb(204,0,0' }
  };
  gaugeAppendText = "%";
  constructor(private _applianceManagementService: AppliancemanagementService, private _route: ActivatedRoute, private builder: FormBuilder
    , private _fieldErrorDisplayService: FieldErrorDisplayService) { }

  ngOnInit() {
    debugger;
    this.loading = true;
    this.createForm();
    this.createLoginForm();
    this.applianceId = "";
    this._route.params.subscribe(params => {
      this.applianceId = params['applianceId'];
      this.applianceName = params['applianceName'];
    });
    this._applianceManagementService.getHostSystemInfo(this.applianceId).subscribe(
      res => {
        this.stats = res.hostStats;
        this.applianceObj = res.adminVMConfig;
        this.applianceModel = res.applianceDetailModel;
        this.applianceModel["partitionDetailModels"] = null;
        this.getApplianceAdvancedData = res["adminVMConfig"]["adminVMData"]["advanced"]["staticIpToHostConfig"];
        console.log(this.applianceObj);
        // this.applianceObj.adminVMData["advanced"]["staticIpToHostConfig"][0]
        for (var i = 0; i < this.getApplianceAdvancedData.length; i++) {
          this.applianceObjAdvanced.push(this.getApplianceAdvancedData[i]);
          this.applianceObjAdvancedDup.push(this.getApplianceAdvancedData[i]);

        }
        for (var i = 0; i < this.applianceObjAdvancedDup.length; i++) {
          this.applianceObjAdvancedDup[i]["color"] = "Green";

        }

        // this.form.get("dhcp").setValue(this.applianceObj.adminVMData.general.dhcp);
        // this.form.get("ipAddress").setValue(this.applianceObj.adminVMData.general.ip);
        // this.form.get("gatewayIp").setValue(this.applianceObj.adminVMData.general.gateway);
        // this.form.get("subnetMask").setValue(this.applianceObj.adminVMData.general.subnet);
        // this.form.get("hostName").setValue(this.applianceObj.adminVMData.general.hostname);
        // this.form.get("vLanId").setValue(this.applianceObj.adminVMData.general.vlan);
        // this.form.get("macAddress").setValue(this.applianceObj.adminVMData.general.macAddress);
        // this.form.get("staticMac").setValue(this.applianceObj.adminVMData.general.macStatic);
        // this.form.get("dnsService").setValue(this.applianceObj.adminVMData.advanced.enableDNSService);

        this.form.get("ipAddress").setValue(this.applianceObj.adminVMData.general.ip);
        this.form.get("gatewayIp").setValue(this.applianceObj.adminVMData.general.gateway);
        this.form.get("subnetMask").setValue(this.applianceObj.adminVMData.general.subnet);
        if(this.applianceObj.adminVMData.general.hostname=="null"){
        this.form.get("hostName").setValue('');
        }
        else{
          this.form.get("hostName").setValue(this.applianceObj.adminVMData.general.hostname?this.applianceObj.adminVMData.general.hostname:'');
        }
        this.form.get("vLanId").setValue(this.applianceObj.adminVMData.general.vlan);
        this.form.get("macAddress").setValue(this.applianceObj.adminVMData.general.macAddress);
        this.form.get("dhcp").setValue(this.applianceObj.adminVMData.general.dhcp);
        this.form.get("staticMac").setValue(true);

      },
      error => {
        console.log(error);
      },
    );
    let adminVMInfo = this._applianceManagementService.getAdminVMInfo(this.applianceId);
    let adminMonitorStats = this._applianceManagementService.getAdminMonitorStats(this.applianceModel);
    forkJoin([adminVMInfo, adminMonitorStats]).subscribe(result => {
      this.setAdminVMInfo(result[0]);
      this.setAdminMonitorStats(result[1]);
    });

  }

  setAdminVMInfo(res) {
    this.stats = res.hostStats;
    if (this.stats != null) {
      if (this.stats.dataObject != null) {
        if (this.stats.dataObject.vmstatsObject != null) {
          this.gaugeValue4 = this.stats.dataObject.vmstatsObject.cpuUsage;
        }
      }
    }
    if (this.stats != null) {
      if (this.stats.dataObject != null) {
        if (this.stats.dataObject.vmstatsObject != null) {
          if (this.stats.dataObject.vmstatsObject.ramStats != null) {
            this.gaugeValue6 = this.stats.dataObject.vmstatsObject.ramStats.usedPercentage;
          }
        }
      }
    }
    if (this.stats != null) {
      if (this.stats.dataObject != null) {
        if (this.stats.dataObject.vmstatsObject != null) {
          if (this.stats.dataObject.vmstatsObject.diskSpace != null) {
            this.gaugeValue5 = this.stats.dataObject.vmstatsObject.diskSpace.usedPercentage;
          }
        }
      }
    }
    if (this.stats != null) {
      if (this.stats.dataObject != null) {
        if (this.stats.dataObject.vmstatsObject != null) {
          if (this.stats.dataObject.vmstatsObject.swapStats != null) {
            this.gaugeValue7 = this.stats.dataObject.vmstatsObject.swapStats.usedPercentage;
          }
        }
      }
    }

    // network and snmp pane start

    this.network = res.adminVMConfig;
    this.snmp = res.adminSNMPConfig;

    if (this.snmp != null) {
      if (this.snmp.adminSNMPData != null) {
        if (this.snmp.adminSNMPData.uname == null) {
          this.username = '';
        }
      }
    }
    if (this.snmp != null) {
      if (this.snmp.adminSNMPData != null) {
        if (this.snmp.adminSNMPData.ip == null) {
          this.managerIp = '';
        }
      }
    }

    if (this.snmp != null) {
      if (this.snmp.adminSNMPData != null) {
        if (this.snmp.adminSNMPData.enabled == false) {
          this.status = "Disabled";
        }
        else if (this.snmp.adminSNMPData.enabled == true) {
          this.status = "Enabled";
        }
      }
    }

    if (this.snmp != null) {
      if (this.snmp.adminSNMPData != null) {
        if (this.snmp.adminSNMPData.enableTrap == false) {
          this.trapStatus = "Disabled";
        }
        else if (this.snmp.adminSNMPData.enableTrap == true) {
          this.trapStatus = "Enabled";
        }
      }
    }
  }
  public processUsageTableList: any = [];
  public monitorStatMap = new Map<string, Array<string>>();
  public finalmonitorStatMap = new Map<string, Array<string>>();
  public processUsageChartData: Array<any> = [];
  public processMemoryLabel: Array<any> = [];
  public hoursMinutes: Array<any> = [];
  public memoryUsageChartData: Array<any> = [];
  public memoryUsageTableData: Array<any> = [];
  public networkEth0ChartData: Array<any> = [];
  public networkEth1ChartData: Array<any> = [];
  public networkEth0TableData: Array<any> = [];
  public memoryLabelList = ['buffers', 'cache', 'free', 'shared', 'used']
  public networkLableList = ["incoming", "outgoing"];
  finalcpuDataMap = new Map<string, Array<string>>();
  finalpcpuDataMap = new Map<string, Array<string>>();
  cpuDataMap = new Map<string, Array<string>>();
  pcpuDataMap = new Map<string, Array<string>>();
  public cpuLabel: Array<any> = [];
  public pcpuLabel: Array<any> = [];
  cpuDataList: any = [];
  pcpuDataList: any = [];
  public pcpuChartData: Array<any> = [];
  public cpuChartData: Array<any> = [];
  setAdminMonitorStats(response: any) {
    this.processUsageTableList = [];
    this.monitorStatMap = new Map<string, Array<string>>();
    this.finalmonitorStatMap = new Map<string, Array<string>>();
    this.processUsageChartData = [];
    this.processMemoryLabel = [];
    this.hoursMinutes = [];
    this.memoryUsageChartData = [];
    this.memoryUsageTableData = [];
    this.networkEth0ChartData = [];
    this.networkEth1ChartData = [];
    this.cpuDataList = [];
    this.pcpuDataList = [];
    this.cpuChartData = [];
    this.pcpuChartData = [];
    this.hoursMinutes = response.map(item => item["hoursminutes"]);
    this.getMemoryUsageDetails(response);
    this.getProcessMemoryStats(response);
    this.getNetworkEth0(response);
    this.getNetworkEth1(response);
    this.getCPUDetaills(response);
    this.getPCPUDetails(response);
  }

  // Memory Usage
  getMemoryUsageDetails(response) {
    this.memoryUsageChartData = new Array<any>();
    this.memoryUsageTableData = new Array<any>();
    let memoryUsage = response.map(item => item["usage"]);
    for (var i = 0; i < memoryUsage.length; i++) {
      let memoryUsageModel = {};
      memoryUsageModel['data'] = memoryUsage.map(item => item[0][this.memoryLabelList[i]]);
      memoryUsageModel['label'] = this.memoryLabelList[i];
      this.memoryUsageChartData.push(memoryUsageModel);
    }
    this.memoryUsageTableData.push(memoryUsage[memoryUsage.length - 1][0])
    this.memoryUsageTableData.push(memoryUsage[memoryUsage.length - 1][1])
  }
  //  Process Memory Usage
  getProcessMemoryStats(res) {
    let memoryStatDetails = res.map(item => item["details"]);
    this.processMemoryLabel = this.hoursMinutes;
    memoryStatDetails.forEach(element => {
      element.forEach(processMemory => {
        if (this.monitorStatMap.get(processMemory.pid)) {
          let processMemoryArray = this.monitorStatMap.get(processMemory.pid);
          processMemoryArray.push(processMemory);
          this.monitorStatMap.set(processMemory.pid, processMemoryArray);
        } else {
          let processMemoryArray = [];
          processMemoryArray.push(processMemory);
          this.monitorStatMap.set(processMemory.pid, processMemoryArray);
        }
      });

    });
    this.finalmonitorStatMap = this.monitorStatMap;
    let pids = Array.from(this.monitorStatMap.keys());
    pids.forEach(pid => {
      if (this.monitorStatMap.has(pid)) {
        let memory = {};
        let memoryStatArray: Array<any> = [];
        memoryStatArray = this.monitorStatMap.get(pid);
        let memoryArray: Array<any> = [];
        memoryStatArray.forEach(element => {
          memoryArray.push(element['mem']);
        });
        this.processUsageTableList.push(memoryStatArray[memoryStatArray.length - 1]);
        memory['data'] = memoryArray;
        memory['label'] = pid;
        this.processUsageChartData.push(memory);
      }

    });
  }

  getNetworkEth0(response) {
    this.networkEth0ChartData = new Array<any>();
    this.networkEth0TableData = new Array<any>();
    let networkData = response.map(item => item["eth0"]);
    this.getNetworkData(networkData, 'eth0');
  }

  getNetworkEth1(response) {
    this.networkEth1ChartData = new Array<any>();
    let networkData = response.map(item => item["eth1"]);
    this.getNetworkData(networkData, 'eth1');

  }

  getNetworkData(networkData, value) {
    for (var i = 0; i < this.networkLableList.length; i++) {
      let networkModel = {};
      let dataList = [];
      let finalDataList = [];
      dataList = networkData.map(item => {
        if (item != null) {
          if (item[this.networkLableList[i]] != null) {
            return item[this.networkLableList[i]]
          }
        }
      });
      dataList.forEach(element => {
        if (element != undefined && element != null) {
          let split = element.split(",");
          let split1 = split[1].split("=");
          finalDataList.push(split1[1]);
        }
      })
      networkModel['data'] = finalDataList;
      networkModel['label'] = this.networkLableList[i];
      if (value == 'eth0') {
        this.networkEth0ChartData.push(networkModel);
      } else if (value == 'eth1') {
        this.networkEth1ChartData.push(networkModel);
      }
    }
  }

  getPCPUDetails(res) {
    let PCPUDetaills = res.map(item => item["info"]);
    this.pcpuLabel = this.hoursMinutes;
    PCPUDetaills.forEach(element => {
      element.forEach(pcpuData => {
        if (this.pcpuDataMap.get(pcpuData.cpu)) {
          let pcpuDataArray = this.pcpuDataMap.get(pcpuData.cpu);
          pcpuDataArray.push(pcpuData);
          this.pcpuDataMap.set(pcpuData.cpu, pcpuDataArray);
        } else {
          let pcpuDataArray = [];
          pcpuDataArray.push(pcpuData);
          this.pcpuDataMap.set(pcpuData.cpu, pcpuDataArray);
        }
      });
    });
    this.finalpcpuDataMap = this.pcpuDataMap;

    let cpus = Array.from(this.pcpuDataMap.keys());
    cpus.forEach(cpu => {
      if (this.pcpuDataMap.has(cpu)) {
        let pcpu = {};
        let pcpuDetailsArray: Array<any> = [];
        pcpuDetailsArray = this.pcpuDataMap.get(cpu);
        let pcpuArray: Array<any> = [];
        pcpuDetailsArray.forEach(element => {
          pcpuArray.push(element['cpuPercent']);
        });
        this.pcpuDataList.push(pcpuDetailsArray[pcpuDetailsArray.length - 1]);
        pcpu['data'] = pcpuArray;
        pcpu['label'] = cpu;
        this.pcpuChartData.push(pcpu);
      }
    });
  }

  getCPUDetaills(res) {
    let CPUDetaills = res.map(item => item["usageInfo"]);
    this.cpuLabel = this.hoursMinutes;
    CPUDetaills.forEach(element => {
      element.forEach(cpuData => {
        if (this.cpuDataMap.get(cpuData.pid)) {
          let cpuDataArray = this.cpuDataMap.get(cpuData.pid);
          cpuDataArray.push(cpuData);
          this.cpuDataMap.set(cpuData.pid, cpuDataArray);
        } else {
          let cpuDataArray = [];
          cpuDataArray.push(cpuData);
          this.cpuDataMap.set(cpuData.pid, cpuDataArray);
        }
      });
    });
    this.finalcpuDataMap = this.cpuDataMap;

    let pids = Array.from(this.cpuDataMap.keys());
    pids.forEach(pid => {
      if (this.cpuDataMap.has(pid)) {
        let cpu = {};
        let cpuDetailsArray: Array<any> = [];
        cpuDetailsArray = this.cpuDataMap.get(pid);
        let cpuArray: Array<any> = [];
        cpuDetailsArray.forEach(element => {
          cpuArray.push(element['memUsage']);
        });
        this.cpuDataList.push(cpuDetailsArray[cpuDetailsArray.length - 1]);
        cpu['data'] = cpuArray;
        cpu['label'] = pid;
        this.cpuChartData.push(cpu);
      }
    });
  }



  // lineChart8
  public lineChartData8: Array<any> = [
    { data: [25, 40, 30, 81, 56, 55, 40], label: 'Outgoing' },
    { data: [12, 20, 15, 18, 25, 15, 26], label: 'Incoming' },

  ];

  toggle4() {
    this.showlist = true;
  }
  toggle5() {
    this.showlist = false;
  }
  public lineChartLabels8: Array<any> = ['18:10', '18:20', '18:30', '18:40', '18:50', '19:00', '19:10'];
  public lineChartOptions8: any = {
    responsive: true,
    legend: {
      display: true,
      position: 'bottom'
    }
  };
  public lineChartColors8: Array<any> = [
    { // blue
      backgroundColor: 'rgba(0,149,179,0)',
      borderColor: 'rgba(0,149,179,1)',
      pointBackgroundColor: 'rgba(0,149,179,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(0,149,179,0.8)'
    },

    { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
    },

  ];
  public lineChartLegend8: boolean = true;
  public lineChartType8: string = 'line';

  // lineChart9
  public lineChartData9: Array<any> = [
    { data: [25, 40, 30, 81, 56, 55, 40], label: 'Outgoing' },
    { data: [12, 20, 15, 18, 25, 15, 26], label: 'Incoming' },

  ];
  public lineChartLabels9: Array<any> = ['18:10', '18:20', '18:30', '18:40', '18:50', '19:00', '19:10'];
  public lineChartOptions9: any = {
    responsive: true,
    legend: {
      display: true,
      position: 'bottom'
    }
  };
  public lineChartColors9: Array<any> = [
    { // blue
      backgroundColor: 'rgba(0,149,179,0)',
      borderColor: 'rgba(0,149,179,1)',
      pointBackgroundColor: 'rgba(0,149,179,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(0,149,179,0.8)'
    },

    { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
    },

  ];
  public lineChartLegend9: boolean = true;
  public lineChartType9: string = 'line';


  // events
  public chartClicked9(e: any): void {
    console.log(e);
  }

  public chartHovered9(e: any): void {
    console.log(e);
  }

  // events
  public chartClicked8(e: any): void {
    console.log(e);
  }

  public chartHovered8(e: any): void {
    console.log(e);
  }

  // lineChart10
  public lineChartData10: Array<any> = [
    { data: [70, 59, 83, 81, 60, 87, 83], label: 'Head' },
    { data: [65, 48, 55, 50, 56, 60, 78], label: 'Tail' },
    { data: [45, 35, 45, 65, 47, 52, 40], label: 'Head' },
    { data: [27, 22, 33, 30, 38, 27, 32], label: 'Tail' },

  ];
  public lineChartLabels10: Array<any> = ['18:10', '18:20', '18:30', '18:40', '18:50', '19:00', '19:10'];
  public lineChartOptions10: any = {
    responsive: true,
    legend: {
      display: true,
      position: 'bottom'
    }
  };
  public lineChartColors10: Array<any> = [
    { // blue
      backgroundColor: 'rgba(0,102,204,0)',
      borderColor: 'rgba(0,102,204,1)',
      pointBackgroundColor: 'rgba(0,102,204,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(0,102,204,0.8)'
    },
    { //green
      backgroundColor: 'rgba(89,179,0,0)',
      borderColor: 'rgba(89,179,0,1)',
      pointBackgroundColor: 'rgba(89,179,0,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(89,179,0,0.8)'
    },

    { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
    },

    { // purple
      backgroundColor: 'rgba(102,0,153,0)',
      borderColor: 'rgba(102,0,153,1)',
      pointBackgroundColor: 'rgba(102,0,153,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(102,0,153,1)'
    },

  ];
  public lineChartLegend10: boolean = true;
  public lineChartType10: string = 'line';


  // events
  public chartClicked10(e: any): void {
    console.log(e);
  }

  public chartHovered10(e: any): void {
    console.log(e);
  }

  // lineChart11
  public lineChartData11: Array<any> = [
    { data: [70, 59, 83, 81, 60, 87, 83], label: 'Head' },
    { data: [65, 48, 55, 50, 56, 60, 78], label: 'Tail' },
    { data: [45, 35, 45, 65, 47, 52, 40], label: 'Head' },
    { data: [27, 22, 33, 30, 38, 27, 32], label: 'Tail' },
  ];
  public lineChartLabels11: Array<any> = ['18:10', '18:20', '18:30', '18:40', '18:50', '19:00', '19:10'];
  public lineChartOptions11: any = {
    responsive: true,
    legend: {
      display: true,
      position: 'bottom'
    }
  };
  public lineChartColors11: Array<any> = [
    { // blue
      backgroundColor: 'rgba(0,102,204,0)',
      borderColor: 'rgba(0,102,204,1)',
      pointBackgroundColor: 'rgba(0,102,204,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(0,102,204,0.8)'
    },
    { //green
      backgroundColor: 'rgba(89,179,0,0)',
      borderColor: 'rgba(89,179,0,1)',
      pointBackgroundColor: 'rgba(89,179,0,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(89,179,0,0.8)'
    },

    { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
    },

    { // purple
      backgroundColor: 'rgba(102,0,153,0)',
      borderColor: 'rgba(102,0,153,1)',
      pointBackgroundColor: 'rgba(102,0,153,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(102,0,153,1)'
    },

  ];
  public lineChartLegend11: boolean = true;
  public lineChartType11: string = 'line';


  // events
  public chartClicked11(e: any): void {
    console.log(e);
  }

  public chartHovered11(e: any): void {
    console.log(e);
  }


  // lineChart3
  public lineChartData3: Array<any> = [
    { data: [40, 59, 55, 81, 56, 55, 40], label: 'Series A' },
    { data: [28, 48, 40, 19, 86, 27, 60], label: 'Series B' },
  ];
  public lineChartLabels3: Array<any> = ['18:10', '18:20', '18:30', '18:40', '18:50', '19:00', '19:10'];
  public lineChartOptions3: any = {
    responsive: true,
    legend: {
      display: true,
      position: 'bottom'
    }
  };
  public lineChartColors3: Array<any> = [
    { // blue
      backgroundColor: 'rgba(0,149,179,0)',
      borderColor: 'rgba(0,149,179,1)',
      pointBackgroundColor: 'rgba(0,149,179,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(0,149,179,0.8)'
    },
    { // yellow
      backgroundColor: 'rgba(230,230,0,0)',
      borderColor: 'rgba(230,230,0,1)',
      pointBackgroundColor: 'rgba(230,230,0,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(230,230,0,1)'
    },

  ];
  public lineChartLegend3: boolean = true;
  public lineChartType3: string = 'line';


  // events
  public chartClicked3(e: any): void {
    console.log(e);
  }

  public chartHovered3(e: any): void {
    console.log(e);
  }

  // lineChart4
  public lineChartData4: Array<any> = [
    { data: [65, 59, 80, 81, 56, 55, 40], label: 'Series A' },
    { data: [28, 48, 40, 19, 86, 27, 90], label: 'Series B' },
    { data: [18, 48, 77, 9, 100, 27, 40], label: 'Series C' },
    { data: [40, 90, 56, 70, 30, 27, 40], label: 'Series D' },

  ];
  public lineChartLabels4: Array<any> = ['18:10', '18:20', '18:30', '18:40', '18:50', '19:00', '19:10'];
  public lineChartOptions4: any = {
    responsive: true,
    legend: {
      display: true,
      position: 'bottom'
    }
  };
  public lineChartColors4: Array<any> = [
    { // blue
      backgroundColor: 'rgba(0,149,179,0)',
      borderColor: 'rgba(0,149,179,1)',
      pointBackgroundColor: 'rgba(0,149,179,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(0,149,179,0.8)'
    },
    { // yellow
      backgroundColor: 'rgba(230,230,0,0)',
      borderColor: 'rgba(230,230,0,1)',
      pointBackgroundColor: 'rgba(230,230,0,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(230,230,0,1)'
    },

    { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
    },

    { //green
      backgroundColor: 'rgba(34,204,0,0)',
      borderColor: 'rgba(34,204,0,1)',
      pointBackgroundColor: 'rgba(34,204,0,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(34,204,0,0.8)'
    },

  ];
  public lineChartLegend4: boolean = true;
  public lineChartType4: string = 'line';


  // events
  public chartClicked4(e: any): void {
    console.log(e);
  }

  public chartHovered4(e: any): void {
    console.log(e);
  }


  // lineChart5
  public lineChartData5: Array<any> = [
    { data: [25, 40, 30, 81, 56, 55, 40], label: 'Outgoing' },
    { data: [12, 20, 15, 18, 25, 15, 26], label: 'Incoming' },

  ];
  public lineChartLabels5: Array<any> = ['18:10', '18:20', '18:30', '18:40', '18:50', '19:00', '19:10'];
  public lineChartOptions5: any = {
    responsive: true,
    legend: {
      display: true,
      position: 'bottom',
    },
    scales: {
      yAxes: [{
         ticks: {
          min: 0, // it is for ignoring negative step.
          beginAtZero: true,
          callback: function (value, index, values) {
            if (Math.floor(value) === value) {
              return value;
            }
          }
         }
      }]
   }
  };
  public lineChartColors5: Array<any> = [
    { // blue
      backgroundColor: 'rgba(0,149,179,0)',
      borderColor: 'rgba(0,149,179,1)',
      pointBackgroundColor: 'rgba(0,149,179,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(0,149,179,0.8)'
    },

    { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
    },

  ];
  public lineChartLegend5: boolean = true;
  public lineChartType5: string = 'line';


  // events
  public chartClicked5(e: any): void {
    console.log(e);
  }

  public chartHovered5(e: any): void {
    console.log(e);
  }

  // lineChart6
  public lineChartData6: Array<any> = [
    { data: [25, 40, 30, 81, 56, 55, 40], label: 'Outgoing' },
    { data: [12, 20, 15, 18, 25, 15, 26], label: 'Incoming' },

  ];
  public lineChartLabels6: Array<any> = ['18:10', '18:20', '18:30', '18:40', '18:50', '19:00', '19:10'];
  public lineChartOptions6: any = {
    responsive: true,
    legend: {
      display: true,
      position: 'bottom'
    }
  };
  public lineChartColors6: Array<any> = [
    { // blue
      backgroundColor: 'rgba(0,149,179,0)',
      borderColor: 'rgba(0,149,179,1)',
      pointBackgroundColor: 'rgba(0,149,179,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(0,149,179,0.8)'
    },

    { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
    },

  ];
  public lineChartLegend6: boolean = true;
  public lineChartType6: string = 'line';


  // events
  public chartClicked6(e: any): void {
    console.log(e);
  }

  public chartHovered6(e: any): void {
    console.log(e);
  }

  // lineChart7
  public lineChartData7: Array<any> = [
    { data: [65, 59, 80, 81, 56, 55, 40], label: 'Series A' },
    { data: [28, 48, 40, 19, 86, 27, 90], label: 'Series B' },
    { data: [18, 48, 77, 9, 100, 27, 40], label: 'Series C' },
    { data: [40, 90, 56, 70, 30, 27, 40], label: 'Series D' },

  ];
  public lineChartLabels7: Array<any> = ['18:10', '18:20', '18:30', '18:40', '18:50', '19:00', '19:10'];
  public lineChartOptions7: any = {
    responsive: true,
    legend: {
      display: true,
      position: 'bottom'
    }
  };
  public lineChartColors7: Array<any> = [
    { // blue
      backgroundColor: 'rgba(0,149,179,0)',
      borderColor: 'rgba(0,149,179,1)',
      pointBackgroundColor: 'rgba(0,149,179,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(0,149,179,0.8)'
    },
    { // yellow
      backgroundColor: 'rgba(230,230,0,0)',
      borderColor: 'rgba(230,230,0,1)',
      pointBackgroundColor: 'rgba(230,230,0,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(230,230,0,1)'
    },

    { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
    },

    { //green
      backgroundColor: 'rgba(34,204,0,0)',
      borderColor: 'rgba(34,204,0,1)',
      pointBackgroundColor: 'rgba(34,204,0,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(34,204,0,0.8)'
    },

  ];
  public lineChartLegend7: boolean = true;
  public lineChartType7: string = 'line';


  // events
  public chartClicked7(e: any): void {
    console.log(e);
  }

  public chartHovered7(e: any): void {
    console.log(e);
  }

  // lineChart2
  public lineChartData2: Array<any> = [
    { data: [15, 15, 15, 15, 15, 15, 15], label: 'Free Space' },
    { data: [22, 30, 28, 25, 32, 25, 36], label: 'Cache' },
    { data: [48, 54, 50, 56, 53, 50, 54], label: 'Used' },
    { data: [42, 38, 40, 38, 46, 40, 39], label: 'Shared' },
    { data: [55, 67, 60, 68, 65, 60, 66], label: 'Buffered' },


  ];
  public lineChartLabels2: Array<any> = ['18:10', '18:20', '18:30', '18:40', '18:50', '19:00', '19:10'];
  public lineChartOptions2: any = {
    responsive: true,
    legend: {
      display: true,
      position: 'bottom'
    }
  };
  public lineChartColors2: Array<any> = [
    { // light green
      backgroundColor: 'rgba(102,204,0,0.2)',
      borderColor: 'rgba(102,204,0,1)',
      pointBackgroundColor: 'rgba(102,204,0,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(102,204,0,0.8)'
    },
    // blue3
    {
      backgroundColor: 'rgba(0,149,179,0.2)',
      borderColor: 'rgba(0,149,179,1)',
      pointBackgroundColor: 'rgba(0,149,179,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(0,149,179,0.8)'
    },
    { // orange
      backgroundColor: 'rgba(255,166,77,0.2)',
      borderColor: 'rgba(255,166,77,1)',
      pointBackgroundColor: 'rgba(255,166,77,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,166,77,0.8)'
    },
    { // purple
      backgroundColor: 'rgba(136,77,255,0.2)',
      borderColor: 'rgba(136,77,255,1)',
      pointBackgroundColor: 'rgba(136,77,255,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(136,77,255,0.8)'
    },
    { // blue
      backgroundColor: 'rgba(51,119,255,0.2)',
      borderColor: 'rgba(51,119,255,1)',
      pointBackgroundColor: 'rgba(51,119,255,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(51,119,255,0.8)'
    }
  ];
  public lineChartLegend2: boolean = true;
  public lineChartType2: string = 'line';


  // events
  public chartClicked2(e: any): void {
    console.log(e);
  }

  public chartHovered2(e: any): void {
    console.log(e);
  }
  showSelfTest() {
    this.loading=true;
    this.selfTestRep=[];
    $("#SelfTestModal").modal("show");
    this.message="";
    let Modal = {};
    Modal["applianceId"] = this.applianceId;
    Modal["applianceName"] = this.applianceName;
    Modal["ipAddress"] = this.ip;
    Modal["selfReportType"] = 'admin';
    this._applianceManagementService.getSelfTestReport(Modal).subscribe(
      res => {
        console.log(res);
        console.log("Self Test Report" + JSON.stringify(res));
        let res1 = JSON.stringify(res);
        let res2 = JSON.parse(res1);
        this.selfTestRep = res2.responseMessage.split("\\n");
        // this.selfTestRep=res2.responseMessage.split("\\n");

        console.log(res2);
        this.selfTestReport = res2.responseMessage;

        if(res2.responseCode==408){
          this.selfTestRep=[];
          
          
          this.message =  res2.responseMessage;
          this.loading=false;

          this.selecterror.show();
          res2.responseCode=1;       

        }


        console.log(res2.responseMessage.split("\\n"));
        //var array = JSON.parse(res2.responseMessage[" + selfTest + "]);
        console.log(this.selfTestReport);
        // this.selfTestReport=res;
        // this.selfTestReport =JSON.parse(res.responseMessage);
        //  console.log(this.selfTestReport);
        this.loading=false;
      },
      error => {
        this.loading = false;
        console.log(error);
      },
    );
  }
  closeModalst() {

    $("#SelfTestModal").modal("hide");

  }
  getNetworkDetails() {
    
    $("#NetworkModal").modal("show");
  }
  closeModal() {

    $("#NetworkModal").modal("hide");
    this.successMessage = '';
    this.errorMessages = [];
  }
  submitData() {
    debugger;
  if(this.isValidIp==true && this.isValidgatewayIp==true && this.isValidsubnetmaskIP==true && this.isValidmacAddress==true &&
  this.isValidHostname==true){
    for (var i = 0; i < this.appAdd.length; i++) {

      this.staticIpToHostConfigUpdated.push(this.appAdd[i]);
    }

    this.submitApplianceNewtorkData = {
      "username": this.loginForm.get("username").value,
      "applianceId": this.applianceModel.applianceId,
      "password": this.loginForm.get("password").value,
      "applianceIp": this.applianceModel.ipAddress,
      "advanced": {
        "searchDomainNames": this.applianceObj.adminVMData.advanced.searchDomainNames,

        "dnsServers": this.applianceObj.adminVMData.advanced.dnsServers,
        "removedHostIPs": this.applianceObj.adminVMData.advanced.removedHostIPs,
        "staticIpToHostConfig": this.staticIpToHostConfigUpdated,
        "enableDNSService": this.form.get("dnsService").value
      },
      "general": {
        "ip": this.form.get("ipAddress").value, "dhcp": this.form.get("dhcp").value,
        "gateway": this.form.get("gatewayIp").value, "subnet": this.form.get("subnetMask").value,
        "hostname": this.form.get("hostName").value, "vlan": parseInt(this.form.get("vLanId").value),
        "macAddress": this.form.get("macAddress").value, "macStatic": this.form.get("staticMac").value,
      }
    }
    if (this.applianceModel.credentialSaved == false) {
      this.saveModalFlag = true;
      this.loginForm.reset();
      $("#NetworkModal").modal("hide");
      $("#myModal").modal("show");
    }
    if (this.applianceModel.credentialSaved == true) {
      this.saveModalFlag = false;
      this._applianceManagementService.networkSettingsDataSubmit(this.submitApplianceNewtorkData).subscribe(
        data => this.onSuccessOperation(data),
        err => this.onErrorOperation(err)
      )
    }
   }
  }
  addAdvancedData() {

    if (this.applianceObjAdvancedDup.length > 0) {
      for (var i = 0; i < this.applianceObjAdvancedDup.length; i++) {

        this.appAdd.push(this.applianceObjAdvancedDup[i]);
        this.applianceObjAdvancedDup.splice(i, 1);

      }
    }
    if (this.ipAddressAdd != null || this.HostnameAdd != null || this.AliasAdd != null) {
      this.applianceObjAdvancedDup.push({ "ip": this.ipAddressAdd, "hostname": this.HostnameAdd, "alias": this.AliasAdd, "color": "yellow" });


      for (var i = 0; i < this.applianceObjAdvancedDup.length; i++) {

        this.appAdd.push(this.applianceObjAdvancedDup[i]);
        this.applianceObjAdvancedDup.splice(i, 1)
      }

    }

    this.ipAddressAdd = null;
    this.HostnameAdd = null;
    this.AliasAdd = null;
  }
  delAddData(id) {
    for (var i = 0; i < this.appAdd.length; i++) {

      if (this.appAdd[i]["ip"] == id) {

        this.appAdd.splice(i, 1);
      }
    }

  }

  onSuccessOperation(response) {
    $("#myModal").modal("hide");
    if (this.saveModalFlag == false) {
      $("#NetworkModal").modal("hide");
    }

    this.successMessage = response.responseMessage;
    this.errorMessages = [];
    this.staticIpToHostConfigUpdated = [];
    let res = response;

    bootbox.dialog({
      message: this.successMessage,
      buttons: {

        Ok: {
          label: "Close",
          className: 'btn btn-primary btn-flat',
          //callback:location.reload()

        }
      }
    });
    this.saveModalFlag = false;
    this.staticIpToHostConfigUpdated = [];
    this.successMessage = '';

  }
  onErrorOperation(errResp) {
    $("#myModal").modal("hide");
  }

  createForm() {

    this.form = this.builder.group({
      applianceId: [''],
      ipAddress: [''],
      gatewayIp: [''],
      subnetMask: [''],
      macAddress: [''],
      hostName: [''],
      vLanId: [''],
      dnsService: [''],
      dhcp: [''],
      staticMac: ['']
    });
  }
  closeLoginModal() {
    this.loginForm.reset();
    $("#myModal").modal("hide");
  }
  submitNetworkSaveToDB() {
    debugger;
    this.submitApplianceNewtorkData["username"] = this.loginForm.get("username").value;
    this.submitApplianceNewtorkData["password"] = this.loginForm.get("password").value;
    this.submitApplianceNewtorkData["operationUsername"] = this.loginForm.get("username").value;
    this.submitApplianceNewtorkData["operationPassword"] = this.loginForm.get("password").value;
    this._applianceManagementService.networkSettingsDataSubmit(this.submitApplianceNewtorkData).subscribe(


      data => this.onSuccessOperation(data),
      err => this.onErrorOperation(err)
    )

  }
  public formValidationFields1 = {
    "username": '',
    "password": ''

  }
  isFieldValid1(field: string) {
    if (this.loginForm.get(field).touched) {
      this.formValidationFields1 = this._fieldErrorDisplayService.validateField(this.loginForm, field, this.formValidationFields1, "login")
    }
    return !this.loginForm.get(field).valid && this.loginForm.get(field).touched;
  }
  createLoginForm() {
    this.loginForm = this.builder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]

    });
  }
  displayFieldCss1(field: string) {
    return {
      'has-error': this.isFieldValid1(field),
      'has-feedback': this.isFieldValid1(field)
    };
  }



  toggleMacAddressEth0(event) {
    if (event.checked) {
      this.form.get('macAddress').enable();
    } else {
      this.form.get('macAddress').disable();
    }
  }
  setValueReset(event, value) {
    if (event.checked) {
      this.form.get("ipAddress").disable();
      this.form.get("gatewayIp").disable();
      this.form.get("subnetMask").disable();
      // this.form.get("ipAddress").setValue(this.applianceObj.adminVMData.general.ip);
      // this.form.get("gatewayIp").setValue(this.applianceObj.adminVMData.general.gateway);
      // this.form.get("subnetMask").setValue(this.applianceObj.adminVMData.general.subnet);
    } else {
      this.form.get("ipAddress").enable();
      this.form.get("gatewayIp").enable();
      this.form.get("subnetMask").enable();

    }
  }
  setValueReset1(event, value) {
    if (event.checked) {
      this.form.get("macAddress").disable();
      this.form.get("vLanId").disable();
      this.form.get("dnsService").disable();
      this.form.get("hostName").setValue(this.applianceObj.adminVMData.general.hostname);
      this.form.get("vLanId").setValue(this.applianceObj.adminVMData.general.vlan);
      this.form.get("macAddress").setValue(this.applianceObj.adminVMData.general.macAddress);
      this.form.get("dnsService").setValue(this.applianceObj.adminVMData.advanced.enableDNSService)
    }
    else {
      this.form.get("hostName").enable();
      this.form.get("hostName").setValue("");
      this.form.get("vLanId").enable();
      this.form.get("vLanId").setValue("");
      this.form.get("macAddress").enable();
      this.form.get("macAddress").setValue("");
      this.form.get("dnsService").enable();
      this.form.get("dnsService").setValue("");
      this.form.get("staticMac").enable();
      this.form.get("staticMac").setValue("");

    }

  }

isValidIp = true;
ValidateIPaddress(inputText) {
  this.isValidIp = true;
  var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (inputText != '') {
    if (inputText.match(ipformat)) {
      this.isValidIp = true;
    }
    else {
      this.isValidIp = false;    
    }
  }
}

isValidgatewayIp = true;
ValidategatewayIP(inputText) {
  this.isValidgatewayIp = true;
  var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (inputText != '') {
    if (inputText.match(ipformat)) {
      this.isValidgatewayIp = true;
    }
    else {
      this.isValidgatewayIp = false;    
    }
  }
}

isValidsubnetmaskIP=true;
ValidateSubnetMaskIp(inputText){
  this.isValidsubnetmaskIP = true;
  var subnetIp= /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (inputText != '') {
    if (inputText.match(subnetIp)) {
      this.isValidsubnetmaskIP = true;
    }
    else {
      this.isValidsubnetmaskIP = false;    
    }
  }
}

isValidmacAddress=true;
ValidatMacAddress(inputText){
  this.isValidmacAddress = true;
  var macaddress= /^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/;
  var form = document.getElementById('form1');
  if (inputText != '') {
    if (inputText.match(macaddress)) {
      this.isValidmacAddress = true;
    }
    else {
      this.isValidmacAddress = false;    
    }
  }
}

// isValidmacAddress1=true;
// ValidatMacAddress1(inputText){
//   this.isValidmacAddress1 = true;
//   var macaddress= /^[a-fA-F0-9:]{17}|[a-fA-F0-9]{12}$/;
//   var form = document.getElementById('form1');
//   if (inputText != '') {
//     if (inputText.match(macaddress)) {
//       this.isValidmacAddress1 = true;
//     }
//     else {
//       this.isValidmacAddress1 = false;    
//     }
//   }
// }

isValidHostname=true;
ValidateHostname(inputText){
  this.isValidHostname = true;
  var hostname=/^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9\-]*[A-Za-z0-9])$/;
  var form = document.getElementById('form1');
  if (inputText != '') {
    if (inputText.match(hostname)) {
      this.isValidHostname = true;
    }
    else {
      this.isValidHostname = false;    
    }
  }
}

isValidHostname1=true;
ValidateHostname1(inputText){
  this.isValidHostname1 = true;
  var ipformat = /^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9\-]*[A-Za-z0-9])$/;
  var form = document.getElementById('form1');
  var x;
  x = (<HTMLInputElement>document.getElementById("hostName1")).value;
  if (x.match(/^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9\-]*[A-Za-z0-9])$/)) {
    this.isValidHostname1 = true;
  }
  else {
    this.isValidHostname1 = false;
  }
}

isValidIp1 = true;
ValidateIPaddress1(inputText) {
  this.isValidIp1 = true;
  var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  var form = document.getElementById('form1');
  var x;
  x = (<HTMLInputElement>document.getElementById("ip1")).value;
  if (x.match(/^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/)) {
    this.isValidIp1 = true;
  }
  else {
    this.isValidIp1 = false;
  }
}

public OnlyNumericValues(e) {
  let input;
  if (e.metaKey || e.ctrlKey) {
    return true;
  }
  if (e.which === 32) {
    return false;
  }
  if (e.which === 0) {
    return true;
  }
  if (e.which < 33) {
    return true;
  }
  input = String.fromCharCode(e.which);
  return !!/[\d\s]/.test(input);
}


}


