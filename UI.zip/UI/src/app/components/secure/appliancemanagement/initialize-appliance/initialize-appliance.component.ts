import { Component, OnInit, ViewChild, Output, EventEmitter, TemplateRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { FormBuilder, FormGroup, Validators, ValidatorFn, AbstractControl } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { TabDirective } from 'ngx-bootstrap/tabs';
import { TabsetComponent } from 'ngx-bootstrap';

import { BsModalService } from 'ngx-bootstrap/modal';
declare var $: any;
declare var bootbox: any;
declare var jQuery: any;
@Component({
  selector: 'app-initialize-appliance',
  templateUrl: './initialize-appliance.component.html',
  styleUrls: ['./initialize-appliance.component.css']
})
export class InitializeApplianceComponent implements OnInit {
  @ViewChild('initializeModal') initializeModal: ModalDirective;
  @ViewChild('initializeTabs') initializeTabs: TabsetComponent;
  @Output() messageEvent1 = new EventEmitter<any>();
  modalRef: BsModalRef;
  form: FormGroup;
  applianceName: string;
  coLoginFailureCount: any;
  maxLength: number;
  minPwdLen: number;
  minpasslen: number;
  maxpasslen: number;

  applianceCount = 1;
  selectedAppliances = [];
  isLoginFailureValid = true;
  isMaxPasswordValid = true;
  isMinPasswordValid = true;
  certAuthenticationChecked: boolean = false;
  hsmAuditLogChecked: boolean = false;
  saveToDBChecked: boolean = false;
  showDualFactor: boolean = false;
  isValidPassword = true;
  totalAppliance = 0;
  initializeDataList = [];
  showFinalInitiazeList: boolean = false;
  tabName: string = "";
  errorMessage: string;
  showBackButton = false;
  loading = false;
  selectedLevel = 0; 
  selectedState = 0; 
  states = [];

  constructor(private _formBuilder: FormBuilder,
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _applianceManagementService: AppliancemanagementService,
    private modalService: BsModalService
  ) { }

  ngOnInit() {
    this.createInitializeForm();
    this.form.get('fileValidate').setValue("false");
    this.tabName ="Initialize";
    this.checkDualFactor(0);
  }
  createInitializeForm() {
    this.form = this._formBuilder.group({
      cryptoOffName: ['', Validators.required],
      cryptoOffPwd: ['', Validators.required],
      confirmPwd: ['', Validators.required],
      authLevel: ['', Validators.required],
      fipsState: ['', Validators.required],
      certAuthentication: [false],
      logFailureCount: [''],
      minPwdLength: [''],
      maxPwdLength: [''],
      hsmLabel: [''],
      hsmAuditLog: [false],
      saveToDB: [false],
      authServerAddress: [''],
      authServerPortNo: [''],
      authServerCert: [null],
      fileContent: [''],
      fileName: [''],
      fileExtension: [''],
      fileValidate : [''],
      fullName:['']
    });
  }

  rangeValidator(min: number, max: number): ValidatorFn {
    return (control: AbstractControl): { [key: string]: boolean } | null => {
      if (control.value !== undefined && (isNaN(control.value) || control.value < min || control.value > max)) {
        return { 'ageRange': true };
      }
      return null;
    };
  }
  // create a form errors
  public formValidationFields = {
    "cryptoOffName": '',
    "cryptoOffPwd": '',
    "confirmPwd": '',
    "authLevel": '',
    "fipsState": '',
    "authServerAddress": '',
    "authServerPortNo": '',
    "authServerCert": '',
    "fileContent": ''
  }

  isFieldValid(field: string) {
    if (this.form.get(field).touched) {
      this.formValidationFields = this._fieldErrorDisplayService.validateField(this.form, field, this.formValidationFields, "initialize")
    }
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  getminValue(value){
    this.minpasslen = parseInt(value);
    this.isMinPasswordValid = true
  }
  getmaxValue(value){
    this.maxpasslen = parseInt(value);
    this.isMaxPasswordValid = true;
  }

  showInitializeModal(listAppliances) {
    
    console.log("List of selected appliance --->" + listAppliances);
    this.clearData();
    this.form.get("authLevel").setValue(0);
    this.form.get("fipsState").setValue("");
    this.form.get("hsmLabel").setValue("Cavium");
    this.form.get("certAuthentication").setValue(true);
    this.showDualFactor =false;
    this.selectedAppliances = listAppliances;
    this.applianceName = this.selectedAppliances[this.applianceCount - 1]['applianceName'];
    this.totalAppliance = this.selectedAppliances.length;
    this.getRequiredValues();
    this.initializeModal.show();
  }


  saveInitializeAppliance(isvalid, template: TemplateRef<any>) {
    if (isvalid) {
      if (this.showDualFactor) {
        let authServerAddress = this.form.get("authServerAddress").value;
        let authServerPortNo = this.form.get('authServerPortNo').value;
        if ((authServerAddress == null || authServerAddress == "") || (authServerPortNo == null || authServerPortNo == "") 
        || ((this.form.get('fileValidate').value=="false") || this.form.get('fileValidate').value==null)) {
          this.errorMessage = "Please fill the Dual Factor Auth Tab.";
          this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
          return false;
        }
        if(this.form.get('fileValidate').value=='' || this.form.get('fileValidate').value==null  || this.form.get('fileValidate').value == "false") {
          return false;
        }
      }
      let checksamePassword = this.checkConfirmPassword();
      if (checksamePassword) {
        /* begins, pushing each appliance into list*/
        if (typeof this.initializeDataList[this.applianceCount - 1] === 'undefined') {
          this.pushApplianceDataIntoList();
        } else {
          this.initializeDataList[this.applianceCount - 1]['cryptoOfficerName'] = this.form.get('cryptoOffName').value;
          this.initializeDataList[this.applianceCount - 1]['cryptoOfficerPassword'] = this.form.get('cryptoOffPwd').value;
          this.initializeDataList[this.applianceCount - 1]['confirmCryptoOfficerpassword'] = this.form.get('confirmPwd').value;
          this.initializeDataList[this.applianceCount - 1]['authenticationLevel'] = this.form.get('authLevel').value;
          this.initializeDataList[this.applianceCount - 1]['fipsState'] = this.form.get('fipsState').value;
          if (this.form.get('certAuthentication').value == true) {
            this.initializeDataList[this.applianceCount - 1]['certAuthentication'] = 1;
          } else {
            this.initializeDataList[this.applianceCount - 1]['certAuthentication'] = 0;
          }
          if (this.form.get('hsmAuditLog').value == true) {
            this.initializeDataList[this.applianceCount - 1]['hsmAuditLog'] = 1;
          } else {
            this.initializeDataList[this.applianceCount - 1]['hsmAuditLog'] = 0;
          }
          if (this.form.get('saveToDB').value == true) {
            this.initializeDataList[this.applianceCount - 1]['credentialSaved'] = true;
          } else {
            this.initializeDataList[this.applianceCount - 1]['credentialSaved'] = false;
          }
          this.initializeDataList[this.applianceCount - 1]['hsmLabel'] = this.form.get('hsmLabel').value;

          this.initializeDataList[this.applianceCount - 1]['loginFailureCount'] = this.form.get('logFailureCount').value;
          this.initializeDataList[this.applianceCount - 1]['minimumPasswordLength'] = this.form.get('minPwdLength').value;
          this.initializeDataList[this.applianceCount - 1]['maximumPasswordLength'] = this.form.get('maxPwdLength').value;
          this.initializeDataList[this.applianceCount - 1]['dualFactorAuthDetailModel']['dualFactorAuthServerAddress'] = this.form.get('authServerAddress').value;
          this.initializeDataList[this.applianceCount - 1]['dualFactorAuthDetailModel']['dualFactorAuthServerPortNo'] = this.form.get('authServerPortNo').value;
          this.initializeDataList[this.applianceCount - 1]['dualFactorAuthDetailModel']['fileContent'] = this.form.get('fileContent').value;
          this.initializeDataList[this.applianceCount - 1]['dualFactorAuthDetailModel']['fileName'] = this.form.get('fileName').value;
          this.initializeDataList[this.applianceCount - 1]['dualFactorAuthDetailModel']['fileExtension'] = this.form.get('fileExtension').value;
          //this.initializeDataList.push(this.initializeDataList);
        }

        /* ends, pushing each appliance into list*/
        if (this.applianceCount < this.selectedAppliances.length) {
          /* get the next appliance coLoginFailureCount, min & max password length values */
          this.applianceName = this.selectedAppliances[this.applianceCount]['applianceName'];
          this.form.reset();
          this.getRequiredValues();
          if (typeof this.initializeDataList[this.applianceCount] != 'undefined') {
            this.setValuesToForm(this.applianceCount);
          }else {
            this.showDualFactor = false;
            this.form.get("authLevel").setValue(0);
            this.form.get("fipsState").setValue("");
            this.form.get("hsmLabel").setValue("Cavium");
            this.form.get("certAuthentication").setValue(true);
          }
          this.applianceCount++;
          this.showBackButton = true;
          
          this.initializeTabs.tabs[0].active = true;
        } else {
          this.form.reset();
          //this.applianceCount++;
          this.showFinalInitiazeList = true;
        }
      } else {
        return false;
      }
    } else {
      if (this.tabName == "Dual Factor Auth") {
        if (this.form.get("authServerAddress").valid && this.form.get('authServerPortNo').valid &&  this.form.get('fileValidate').value=="true" ) {
          this.errorMessage = "";
          this.errorMessage = "Please fill the Initialize Tab.";
          this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
          return false;
        } else {
          if( this.form.get('fileValidate').value!="true"){
            this.form.get('fileValidate').setValue("false");
          }
          this.formValidationFields = this._fieldErrorDisplayService.validateForm(this.form, this.formValidationFields, "initialize", false);
        }
      } else {
        this.formValidationFields = this._fieldErrorDisplayService.validateForm(this.form, this.formValidationFields, "initialize", false);
      }
    }
  }
  // construct appliance data list.
  pushApplianceDataIntoList() {
    let dualFactorAuthDetailModel = {};
    let initializeData = {
      "dualFactorAuthDetailModel": dualFactorAuthDetailModel,
      "applianceDetailModels": []
    };
    initializeData['userName'] = this.selectedAppliances[this.applianceCount - 1]["userName"];
    initializeData['password'] = this.selectedAppliances[this.applianceCount - 1]["userPassword"];
    initializeData['cryptoOfficerName'] = this.form.get('cryptoOffName').value;
    initializeData['cryptoOfficerPassword'] = this.form.get('cryptoOffPwd').value;
    initializeData['confirmCryptoOfficerpassword'] = this.form.get('confirmPwd').value;
    initializeData['authenticationLevel'] = this.form.get('authLevel').value;
    initializeData['fipsState'] = this.form.get('fipsState').value;
    if (this.form.get('certAuthentication').value == true) {
      initializeData['certAuthentication'] = 1;
    } else {
      initializeData['certAuthentication'] = 0;
    }
    if (this.form.get('hsmAuditLog').value == true) {
      initializeData['hsmAuditLog'] = 1;
    } else {
      initializeData['hsmAuditLog'] = 0;
    }
    if (this.form.get('saveToDB').value == true) {
      initializeData['credentialSaved'] = true;
    } else {
      initializeData['credentialSaved'] = false;
    }
    initializeData['hsmLabel'] = this.form.get('hsmLabel').value;
    initializeData['loginFailureCount'] = this.form.get('logFailureCount').value;
    initializeData['minimumPasswordLength'] = this.form.get('minPwdLength').value;
    initializeData['maximumPasswordLength'] = this.form.get('maxPwdLength').value;
    initializeData['dualFactorAuthDetailModel']['dualFactorAuthServerAddress'] = this.form.get('authServerAddress').value;
    initializeData['dualFactorAuthDetailModel']['dualFactorAuthServerPortNo'] = this.form.get('authServerPortNo').value;
    initializeData['dualFactorAuthDetailModel']['fileContent'] = this.form.get('fileContent').value;
    initializeData['dualFactorAuthDetailModel']['fileName'] = this.form.get('fileName').value;
    initializeData['dualFactorAuthDetailModel']['fileExtension'] = this.form.get('fileExtension').value;
    let applianceData = this.selectedAppliances[this.applianceCount - 1];
    applianceData['partitionDetailModels']=null;
    initializeData.applianceDetailModels.push(applianceData);
    this.initializeDataList.push(initializeData);

  }

  getRequiredValues() {
    let tempLoginCount = this.selectedAppliances[this.applianceCount - 1]['coLoginFailureCount'];
    if(tempLoginCount>0){
      this.coLoginFailureCount = tempLoginCount;
    }else{
      this.coLoginFailureCount = 20;
    }
    this.maxLength = this.selectedAppliances[this.applianceCount - 1]['maxPwdLen'];
    this.minPwdLen = this.selectedAppliances[this.applianceCount - 1]['minPwdLen'];
    this.form.get("logFailureCount").setValue(this.coLoginFailureCount);
    this.form.get("maxPwdLength").setValue(this.maxLength);
    this.form.get("minPwdLength").setValue(this.minPwdLen);
  }
  // Submit Method, to pass the data to service class.
  submitInitialize() {
    this.loading = true;
    console.log(this.initializeDataList);
    this._applianceManagementService.saveInitializedata(this.initializeDataList).subscribe((res) => {
      if (res.length > 0) {
        debugger;
        this.loading = false;
        let displaymsg: string = '';
        this.initializeModal.hide();
        res.forEach(obj => {
          if(obj.code == "200"){
            localStorage.removeItem(obj.ipAddress);
            displaymsg = displaymsg + " " + "<b>" + obj.applianceName + "</b> :-- " + obj["message"] + "<br>";
          }else{
            displaymsg = displaymsg + " " + "<b>" + obj.applianceName + "</b> :-- " + obj["errorMessage"] + "<br>";
          }
            
        });
        this.clearData();
        bootbox.dialog({
          message: displaymsg,
          buttons: {
            Ok: {
              label: "Close",
              className: 'btn btn-primary btn-flat',
              callback: () => this.callBack()
            }
          }
        });
        // this.initializeDataList = [];
        // this.form.reset();
      }
    }, (err) => {
      console.log(err);
    })
  }

  callBack() {
    this.messageEvent1.emit();
  }

  closeInitializeModal() {
    this.initializeModal.hide();
    this.clearData();
  }
  clearData() {
    this.form.reset();
    this.applianceName = "";
    this.applianceCount = 1;
    this.selectedAppliances = [];
    this.isLoginFailureValid = true;
    this.isMaxPasswordValid = true;
    this.isMinPasswordValid = true;
    this.certAuthenticationChecked = false;
    this.hsmAuditLogChecked = false;
    this.saveToDBChecked = false;
    this.showDualFactor = true;
    this.isValidPassword = true;
    this.initializeDataList = [];
    this.showFinalInitiazeList = false;
    this.tabName = "";
    this.errorMessage = "";
    this.showBackButton = false;
    this.loading = false;

  }
  toggleCertAuthentication($event) {
    if ($event.checked) {
      this.certAuthenticationChecked = true;
    } else {
      this.certAuthenticationChecked = false;
    }

  }
  toggleHSMAuditLog($event) {
    if ($event.checked) {
      this.hsmAuditLogChecked = true;
    } else {
      this.hsmAuditLogChecked = false;
    }
  }
  toggleSaveToDB($event) {
    if ($event.checked) {
      this.saveToDBChecked = true;
    } else {
      this.saveToDBChecked = false;
    }
  }


  validatelogFailureCount(property) {
    if (property.value < 1 || property.value > 20) {
      this.isLoginFailureValid = false;
      this.form.get("logFailureCount").setValue("");
    } else {
      this.isLoginFailureValid = true;
    }
  }

  
validateMaxPassword(e,property) {
  alert("use arrow button to change values");
  this.isMaxPasswordValid=false;
  this.form.get('maxPwdLength').reset();
  
}
validateMinPassword(e,property) {
  alert("use arrow button to change values");
  this.isMinPasswordValid=false;
  this.form.get('minPwdLength').reset();
}

  // To show/hide the dualfactor tab.
  checkDualFactor(value:number) {
    if (value == 0) {
      this.showDualFactor = false;
    } else {
      this.showDualFactor = true;
    }

    //this.selectedLevel = value;
    this.form.get('authLevel').setValue(value);
    this.states = this.getStates().filter((item) => {
      return item.level_id === Number(value)
    }); 
 
  }

  getLevels() {
    return [
      { id: 0, name: 'Single factor authentication' },
      { id: 1, name: 'Dual factor authentication' },
    ];
  }

  getStates() {
    return [
      { id: 2, level_id:0, name: 'FIPS mode' },
      { id: 0, level_id:0, name: 'Non FIPS mode' },
      { id: 3, level_id:1, name: 'FIPS mode' }
    ];
  }
  // Validate crypto & confirm Officer Password.
  checkConfirmPassword() {
    let cryptoOffPwd = this.form.get("cryptoOffPwd").value;
    let confirmPwd = this.form.get("confirmPwd").value;
    if (cryptoOffPwd !== confirmPwd) {
      this.isValidPassword = false;
      return false;
    }
    else {
      this.isValidPassword = true;
      return true;
    }
  }

  onSelect(data: TabDirective): void {
    this.tabName = data.heading;
    if (this.tabName == "Dual Factor Auth") {
      this.form.get('authServerAddress').setValidators(Validators.compose([Validators.required]));
      this.form.get('authServerPortNo').setValidators(Validators.compose([Validators.required]));
      //this.form.get('authServerCert').setValidators(Validators.compose([Validators.required]));
      this.form.get('authServerAddress').updateValueAndValidity();
      this.form.get('authServerPortNo').updateValueAndValidity();
     // this.form.get('authServerCert').updateValueAndValidity();
    } else if (this.tabName == "Initialize") {
      this.form.get('authServerAddress').setValidators(null);
      this.form.get('authServerPortNo').setValidators(null);
     // this.form.get('authServerCert').setValidators(null);
      this.form.get('authServerAddress').updateValueAndValidity();
      this.form.get('authServerPortNo').updateValueAndValidity();
     // this.form.get('authServerCert').updateValueAndValidity();
    }
  }
  // back Operation fetchs previous appliance data.
  backToPreviousAppliance() {
    this.form.reset();
    this.applianceName = this.selectedAppliances[this.applianceCount - 2]['applianceName'];
    let backOperationCount = this.applianceCount - 2;
    this.setValuesToForm(backOperationCount);
    this.applianceCount = this.applianceCount - 1;
    if (this.applianceCount == 1) {
      this.showBackButton = false;
    }
    this.setDualFactorValidation();
    
    this.initializeTabs.tabs[0].active = true;
    this.tabName ="Initialize";
  }
  // Back Operation in Final list of appliance.
  backOperationFromFinalList() {
    this.form.reset();
    this.applianceName = this.initializeDataList[this.applianceCount - 1]['applianceDetailModels'][0]['applianceName'];
    this.setValuesToForm(this.applianceCount - 1);
    if (this.applianceCount == 1) {
      this.showBackButton = false;
    } else {
      //this.applianceCount = this.applianceCount - 1;
      this.showBackButton = true;
    }
    this.setDualFactorValidation();
    this.showFinalInitiazeList = false;
    this.tabName ="Initialize";
    //this.initializeTabs.tabs[0].active = true;
  }

  setDualFactorValidation(){
    if(this.form.get("authLevel").value!=0){
      this.form.get('authServerAddress').setValidators(Validators.compose([Validators.required]));
      this.form.get('authServerPortNo').setValidators(Validators.compose([Validators.required]));
      //this.form.get('authServerCert').setValidators(Validators.compose([Validators.required]));
      this.form.get('fileValidate').setValue("true");
      this.form.get('authServerAddress').updateValueAndValidity();
      this.form.get('authServerPortNo').updateValueAndValidity();
     // this.form.get('authServerCert').updateValueAndValidity();
    }else if(this.form.get("authLevel").value==0){
      this.form.get('authServerAddress').setValidators(null);
      this.form.get('authServerPortNo').setValidators(null);
      //this.form.get('authServerCert').setValidators(null);
      this.form.get('fileValidate').setValue("false");
      this.form.get('authServerAddress').updateValueAndValidity();
      this.form.get('authServerPortNo').updateValueAndValidity();
      //this.form.get('authServerCert').updateValueAndValidity();
    
    }
  }
  // set the values to Form .
  setValuesToForm(backOperationCount) {
    this.form.get("cryptoOffName").setValue(this.initializeDataList[backOperationCount]['cryptoOfficerName']);
    this.form.get("cryptoOffPwd").setValue(this.initializeDataList[backOperationCount]['cryptoOfficerPassword']);
    this.form.get("confirmPwd").setValue(this.initializeDataList[backOperationCount]['cryptoOfficerPassword']);
    this.form.get("authLevel").setValue(this.initializeDataList[backOperationCount]['authenticationLevel']);
    this.form.get("fipsState").setValue(this.initializeDataList[backOperationCount]['fipsState']);
    if (this.initializeDataList[backOperationCount]['certAuthentication'] == 1) {
      this.form.get('certAuthentication').setValue(true);
    } else {
      this.form.get('certAuthentication').setValue(false);
    }
    if (this.initializeDataList[backOperationCount]['hsmAuditLog'] == 1) {
      this.form.get('hsmAuditLog').setValue(true);
    } else {
      this.form.get('hsmAuditLog').setValue(false);
    }
    if (this.initializeDataList[backOperationCount]['credentialSaved']) {
      this.form.get('saveToDB').setValue(true);
    } else {
      this.form.get('saveToDB').setValue(false);
    }
    this.form.get('hsmLabel').setValue(this.initializeDataList[backOperationCount]['hsmLabel']);
    this.form.get('logFailureCount').setValue(this.initializeDataList[backOperationCount]['loginFailureCount']);
    this.form.get('minPwdLength').setValue(this.initializeDataList[backOperationCount]['minimumPasswordLength']);
    this.form.get('maxPwdLength').setValue(this.initializeDataList[backOperationCount]['maximumPasswordLength']);
    this.form.get('authServerAddress').setValue(this.initializeDataList[backOperationCount]['dualFactorAuthDetailModel']['dualFactorAuthServerAddress']);
    this.form.get('authServerPortNo').setValue(this.initializeDataList[backOperationCount]['dualFactorAuthDetailModel']['dualFactorAuthServerPortNo']);
    this.form.get('fileContent').setValue(this.initializeDataList[backOperationCount]['dualFactorAuthDetailModel']['fileContent']);
    this.form.get('fileName').setValue(this.initializeDataList[backOperationCount]['dualFactorAuthDetailModel']['fileName']);
    this.form.get('fileExtension').setValue(this.initializeDataList[backOperationCount]['dualFactorAuthDetailModel']['fileExtension']);
    this.form.get('fileValidate').setValue("true");
    this.form.get('fullName').setValue(this.form.get('fileName').value+"."+this.form.get('fileExtension').value);

    if (this.form.get("authLevel").value == 0) {
      this.showDualFactor = false;
    } else {
      this.showDualFactor = true;
    }
  }
  // file upload method
  onFileChange(event) {
    const filePicked = (event.target as HTMLInputElement).files[0];
    if(filePicked!=undefined){
      const fileName = filePicked.name;
      this.form.get('fullName').setValue(fileName);
      this.form.get('fileName').setValue(fileName.substring(0, fileName.indexOf('.')));
      this.form.get('fileExtension').setValue(filePicked.name.split('.').pop() || filePicked.name);
      const reader = new FileReader();
      reader.onload = () => {
        this.form.get('fileContent').setValue(reader.result);
        if(this.form.get('fileContent').value!=null){
          this.form.get('fileValidate').setValue("true");
        }else {
          this.form.get('fileValidate').setValue("false");
        }
      };
      reader.readAsText(filePicked);
    }else {
      this.form.get('fullName').setValue(null);
      this.form.get('fileName').setValue("");
      this.form.get('fileExtension').setValue("");
      this.form.get('fileContent').setValue("");
      this.form.get('fileValidate').setValue("false");
      return false;
    }
   
   
  }
  /* Remove appliance from the final list */
  removeAppliance(applianceId) {
    let selectedIds = [];
    selectedIds.push(applianceId);
    this.initializeDataList = this.initializeDataList.filter(
      val => !selectedIds.includes(val.applianceDetailModels[0].applianceId));
    this.selectedAppliances = this.selectedAppliances.filter(
      val => !selectedIds.includes(val.applianceId));
    this.applianceCount = this.applianceCount - 1;
    this.totalAppliance = this.initializeDataList.length;
  }

  clearErrorMessage() {
    this.isValidPassword = true;
  }

  public OnlyNumericValues(e) {
    let input;
    if (e.metaKey || e.ctrlKey) {
      return true;
    }
    if (e.which === 32) {
      return false;
    }
    if (e.which === 0) {
      return true;
    }
    if (e.which < 33) {
      return true;
    }
    input = String.fromCharCode(e.which);
    return !!/[\d\s]/.test(input);
  }

}

