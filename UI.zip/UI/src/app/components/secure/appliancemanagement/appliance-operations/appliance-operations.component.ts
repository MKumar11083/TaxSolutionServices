import { Component, OnInit, EventEmitter, Output, ViewChild } from '@angular/core';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import  {  LoadingModule  }  from  'ngx-loading';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { Router } from '@angular/router';
declare var $: any;
declare var bootbox: any;
declare var jQuery: any;
@Component({
  selector: 'app-appliance-operations',
  templateUrl: './appliance-operations.component.html',
  styleUrls: ['./appliance-operations.component.css']
})
export class ApplianceOperationsComponent implements OnInit {
  @Output() messageEvent4 = new EventEmitter<any>();
  public  loading  =  false;
  dueToClusterList: any = [];
  fipStatusNonZerozied: any = [];
  successList: any = [];
  errorMessage: string = '';
  @ViewChild('deleteApplianceModal') deleteApplianceModal: ModalDirective;
  @ViewChild('messageModal') messageModal: ModalDirective;
  constructor(private _service: AppliancemanagementService,
    private _router: Router) { }

  ngOnInit() {
  }


  submitApplianceOperations(listAppliance, applianceOperation) {
    this.loading = true;
    if (applianceOperation == "Reboot") {
      this._service.setRebootActivity(listAppliance).subscribe(
        res => {
          this.responseOperation(res);
        },
        err => {
          console.log(err);
        }
      )
    } else if (applianceOperation == "delete") {
      this.loading = true;
      let applianceList: any = [];
      listAppliance.forEach(obj => {
        obj['partitionDetailModels'] = null;
        applianceList.push(obj);
      });
      this.dueToClusterList = [];
      this.fipStatusNonZerozied = [];
      this.successList = [];
      this.errorMessage = '';
      this._service.validateDeleteAppliance(applianceList).subscribe(
        res => {
          this.loading = false;
          this.dueToClusterList = res.dueToCluster;
          this.fipStatusNonZerozied = res.fipsStateNonZeroize;
          this.successList = res.successList;
          if (this.dueToClusterList.length == 0 && this.fipStatusNonZerozied.length == 0) {
            if (this.successList.length == 0) {
              this.errorMessage = "No Appliances to do delete operation";
              this.messageModal.show();
            } else {
              this.onSubmit();
            }

          } else {
            this.deleteApplianceModal.show();
          }
        },
        err => {
          console.log(err);
        }
      )
    }
  }

  callBack() {
    //this.messageEvent4.emit();
    this._router.navigate(['/listAppliance']);
  }

  responseOperation(res) {
    debugger;
    this.loading = false;
    let displaymsg: string = '';
    res.forEach(obj => {
      if (obj.code == "200") {
        displaymsg = displaymsg + " " + "<b>" + obj.applianceName + "</b> :-- " + obj["message"] + "<br>";
      } else {
        displaymsg = displaymsg + " " + "<b>" + obj.applianceName + "</b> :-- " + obj["errorMessage"] + "<br>";
      }

    });
    bootbox.dialog({
      message: displaymsg,
      buttons: {
        Ok: {
          label: "Close",
          className: 'btn btn-primary btn-flat',
          callback: () => this.callBack()
        }
      }
    });
  }

  selectAppliancesForDelete(event, applianceId) {
    if (event.checked) {
      this.fipStatusNonZerozied.find
        (appliance => {
          if (appliance.applianceId === applianceId) {
            this.successList.push(appliance);
          }
        })
    } else {
      const index = this.successList.findIndex(appliance => appliance.applianceId === applianceId);
      this.successList.splice(index, 1);
    }
  }

  closeModal() {
    this.dueToClusterList = [];
    this.fipStatusNonZerozied = [];
    this.successList = [];
    this.deleteApplianceModal.hide();
  }

  onSubmit() {
    if (this.successList.length > 0) {
      this.loading = true;
      this.deleteApplianceModal.hide();
      this._service.deleteAppliance(this.successList).subscribe(
        res => {
          this.loading = false;
          let response = res.json();
          this.closeModal();
          this.responseOperation(response);
        },

        err => {
          this.loading = false;
          console.log(err);
        }
      )
    } else {
      this.errorMessage = "No Appliances to do delete operation";
      this.messageModal.show();
    }

  }
}
