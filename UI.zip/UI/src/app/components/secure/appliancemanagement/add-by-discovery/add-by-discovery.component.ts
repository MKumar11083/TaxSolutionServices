import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, FormControl } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-add-by-discovery',
  templateUrl: './add-by-discovery.component.html',
  styleUrls: ['./add-by-discovery.component.css']
})
export class AddByDiscoveryComponent implements OnInit {
  displayErrors: any = [];
  ipDiscoveryResults = new Map<string, string>();
  errorMessage: string;
  showIPAddress: boolean = true;
  isvalid: boolean;
  buttontrue:boolean=true;
  form: FormGroup;
  public loading = false;
  constructor(private builder: FormBuilder,
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _addApplianceService: AppliancemanagementService,
    private _router: Router) { }

  ngOnInit() {
    this.createForm();
  }

  createForm() {
    this.form = this.builder.group({
      ipAddress: [''],
      ipAddressStartingRange: [''],
      ipAddressEndRange: ['']
    });
  }

  // create a form errors
  public formValidationFields = {
    "ipAddress": '',
    "ipAddressStartingRange": '',
    "ipAddressEndRange": '',
  }

  isFieldValid(field: string) {

    if (this.form.get(field).touched) {
      this.formValidationFields = this._fieldErrorDisplayService.validateField(this.form, field, this.formValidationFields, "add-by-discovery")
    }
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  result = [];
  validIpList = [];
  InvalidIpList = [];
  isValid: boolean = true;
  searchAppliance() {
    debugger;
    this.loading = true;
    this.result = [];
    this.validIpList = [];
    this.InvalidIpList = [];

    if (this.showIPAddress) {
      this._addApplianceService.getIPaddress(this.form.value).subscribe((res) => {
        console.log(res);
        this.errorMessage = res.errorMessage;
        this.ipDiscoveryResults = res.ipDiscoveryResults;
        const result = Object.keys(res.ipDiscoveryResults).map(key => {
          let ip = {};
          res.ipDiscoveryResults[key];
          ip['ip'] = key;
          ip['result'] = res.ipDiscoveryResults[key];
          this.result.push(ip);
          console.log(this.result);
          this.loading = false;
        });
        this.result.forEach(element => {
          if (element.result) {
            this.isValid = true;
            element['deviceName'] = "Liquid Security";
            this.validIpList.push(element);
          } else {
            this.isValid = false;
            this.InvalidIpList.push(element);
          }
        })
      });
    } else {
      this._addApplianceService.getIPaddressRange(this.form.value).subscribe((res) => {
        console.log(res);
        this.errorMessage = res.errorMessage;
        this.ipDiscoveryResults = res.ipDiscoveryResults;
        const result = Object.keys(res.ipDiscoveryResults).map(key => {
          let ip = {};
          res.ipDiscoveryResults[key];
          ip['ip'] = key;
          ip['result'] = res.ipDiscoveryResults[key];
          this.result.push(ip);
          console.log(this.result);
          this.loading = false;
        });
        this.result.forEach(element => {
          if (element.result) {
            this.isValid = true;
            element['deviceName'] = "Liquid Security";
            this.validIpList.push(element);
          } else {
            this.isValid = false;
            this.InvalidIpList.push(element);
          }
        })
      });

    }

  }

  showIpAddress(ip) {
    debugger;
    this.showIPAddress  =  !this.showIPAddress ;
    if (ip  ==  "ip") {
      // if(this.isValidIp==true){
      //   this.buttontrue=false;
      // }else{
      //   this.buttontrue=true;
      // }  
      this.form.get('ipAddress').setValidators(Validators.compose([Validators.required]));
      this.form.get('ipAddressStartingRange').setValidators(null);
      this.form.get('ipAddressEndRange').setValidators(null);
      this.form.get('ipAddress').updateValueAndValidity();
      this.form.get('ipAddressStartingRange').updateValueAndValidity();
      this.form.get('ipAddressEndRange').updateValueAndValidity();
    } else  if (ip  ==  "iprange") {
      // if(this.isValidIp==true){
      //   this.buttontrue=true;
      // }else{
      //   this.buttontrue=false;
      // }  
      this.form.get('ipAddressStartingRange').setValidators(Validators.compose([Validators.required]));
      this.form.get('ipAddressEndRange').setValidators(Validators.compose([Validators.required]));
      this.form.get('ipAddress').setValidators(null);
      this.form.get('ipAddress').updateValueAndValidity();
      this.form.get('ipAddressStartingRange').updateValueAndValidity();
      this.form.get('ipAddressEndRange').updateValueAndValidity();
    }
  }


  public OnlyNumericValues(e) {
    let input;
    if (e.metaKey || e.ctrlKey) {
      return true;
    }
    if (e.which === 32) {
      return false;
    }
    if (e.which === 0) {
      return true;
    }
    if (e.which < 33) {
      return true;
    }
    input = String.fromCharCode(e.which);
    return !!/[\d\s]/.test(input);
  }
  selectedIp = '';
  selectIpAddress(ip) {
    this.selectedIp = '';
    this.selectedIp = ip;
  }
  onSubmit() {
    this._router.navigate(['/addAppliance', this.selectedIp]);
  }

  isValidIp = true;
  validateIPaddress(inputText) {
    this.isValidIp = true;
    var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    // var form = document.getElementById('form1');
    // var x;
    // x = (<HTMLInputElement>document.getElementById("ip")).value;
    if (inputText != '') {
      if (inputText.match(ipformat)) {
        this.isValidIp = true;
        this.buttontrue=false;
      }
      else {
        this.isValidIp = false;
        this.buttontrue=true;
      }
    }
  }

  isValidIp1 = true;
  validateIPaddress1(inputText) {
    this.isValidIp1 = true;
    this.buttontrue=true;
    var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    // var form = document.getElementById('form1');
    // var x;
    // x = (<HTMLInputElement>document.getElementById("ip")).value;
    if (inputText != '') {
      if (inputText.match(ipformat)) {
        this.isValidIp1 = true;
        this.buttontrue=false;
      }
      else {
        this.isValidIp1 = false;
        this.buttontrue=true;
      }
    }
  }

  isValidIp2 = true;
  validateIPaddress2(inputText) {
    this.isValidIp2 = true;
    this.buttontrue=true;
    var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    // var form = document.getElementById('form1');
    // var x;
    // x = (<HTMLInputElement>document.getElementById("ip")).value;
    if (inputText != '') {
      if (inputText.match(ipformat)) {
        this.isValidIp2 = true;
        this.buttontrue=false;
      }
      else {
        this.isValidIp2 = false;
        this.buttontrue=true;
      }
    }
  }
}
