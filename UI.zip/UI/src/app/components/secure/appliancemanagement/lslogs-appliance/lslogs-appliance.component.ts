import { Component, OnInit, ViewChild, Output, EventEmitter, TemplateRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { FormBuilder, FormGroup, Validators, ValidatorFn, AbstractControl } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { TabsetComponent } from 'ngx-bootstrap';
import { TabDirective } from 'ngx-bootstrap/tabs';
import { saveAs } from 'file-saver';

import { BsModalService } from 'ngx-bootstrap/modal';
declare var $: any;
declare var bootbox: any;
declare var jQuery: any;

@Component({
  selector: 'app-lslogs-appliance',
  templateUrl: './lslogs-appliance.component.html',
  styleUrls: ['./lslogs-appliance.component.css']
})
export class LslogsApplianceComponent implements OnInit {
  @ViewChild('selecterror')
  selecterror: ModalDirective;
@ViewChild('lslogsModal') logsModal: ModalDirective;
  @ViewChild('selectedPartitionModal') selectedPartitionModal: ModalDirective;
  @Output() messageEvent = new EventEmitter<any>();
  @ViewChild('lslogsTabs') lslogsTabs: TabsetComponent;
  modalRef: BsModalRef;
  form: FormGroup;
  applianceName: string;
  selectedAppliances: any = [];
  totalAppliance = 0;
  applianceCount = 1;
  tabName: string = "";
  lslogsDataList = [];
  showBackButton = false;
  showDeleteButton = false;
  showDownloadButton = false;
  SelectPartitionButton = true;
  showNextButton = false;
  partitionListCount: number = 0;
  modal: any = {};
  selectedPartitions = [];
  selectedPartitionsDuplicate=[];
  list: any = [];
  hostList: any = [];
  partitionsList: any = [];
  loading: boolean = false;
  isSelected: boolean = true;
  errorMessage: string = "";
  constructor(private _formBuilder: FormBuilder,
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _applianceManagementService: AppliancemanagementService,
    private modalService: BsModalService
  ) { }

  ngOnInit() {
    debugger;
    
    //this.loading = true;
    this.createLslogsForm();
    this.tabName = "Lslogs";
  }

  showLslogsModal(listAppliances) {
    debugger;

    console.log("List of selected appliance --->" + listAppliances);
    this.clearData();
    this.selectedAppliances = listAppliances;
    this.applianceName = this.selectedAppliances[this.applianceCount - 1]['applianceName'];
    this.partitionListCount = this.selectedAppliances[this.applianceCount - 1]['partitionDetailModels'].length;
    this.totalAppliance = this.selectedAppliances.length;
    this.logsModal.show();
    this.getPartitionList();
    this.setValueAllChecked();
    if (this.applianceCount < this.selectedAppliances.length) {
      this.showNextButton = true;
      this.showDeleteButton = false;
    }
    else {
      this.showNextButton = false;
      this.showDeleteButton = true;
      this.showDownloadButton = true;
    }

  }
  checkAtleastOneChecked() {
    debugger;
    this.isSelected = true;
    if (this.list.length == 0) {
      if (this.hostList.length == 0) {
        if (this.partitionsList.length == 0) {
          this.isSelected = false;
        }
      }
    }
    if (this.isSelected == false) {
      return false;
    } else {
      return true;
    }

  }
  setValueAllChecked() {
    this.form.get('adminSystem').setValue(true);
    this.list.push('system');
    this.form.get('adminMiddleware').setValue(true);
    this.list.push('middleware');
    this.form.get('adminMonitor').setValue(true);
    this.list.push('monitor');
    this.form.get('adminApps').setValue(true);
    this.list.push('apps');
    this.form.get('hostApps').setValue(true);
    this.hostList.push('apps');
    this.form.get('hostMonitor').setValue(true);
    this.hostList.push('monitor');
    this.form.get('hostSystem').setValue(true);
    this.hostList.push('system');
    this.form.get('partitionApps').setValue(true);
    this.partitionsList.push('apps');
    this.form.get('partitionMonitor').setValue(true);
    this.partitionsList.push('monitor');
    this.form.get('partitionSystem').setValue(true);
    this.partitionsList.push('system');

  }
  setValuesToForm(backOperationCount) {
    if (this.lslogsDataList[backOperationCount]['adminSystem'] == 1) {
      this.form.get('adminSystem').setValue(true);
    } else {
      this.form.get('adminSystem').setValue(false);
    }
    if (this.lslogsDataList[backOperationCount]['adminMiddleware'] == 1) {
      this.form.get('adminMiddleware').setValue(true);
    } else {
      this.form.get('adminMiddleware').setValue(false);
    }
    if (this.lslogsDataList[backOperationCount]['adminMonitor'] == 1) {
      this.form.get('adminMonitor').setValue(true);
    } else {
      this.form.get('adminMonitor').setValue(false);
    }
    if (this.lslogsDataList[backOperationCount]['adminApps'] == 1) {
      this.form.get('adminApps').setValue(true);
    } else {
      this.form.get('adminApps').setValue(false);
    }
    if (this.lslogsDataList[backOperationCount]['hostApps'] == 1) {
      this.form.get('hostApps').setValue(true);
    } else {
      this.form.get('hostApps').setValue(false);
    }
    if (this.lslogsDataList[backOperationCount]['hostMonitor'] == 1) {
      this.form.get('hostMonitor').setValue(true);
    } else {
      this.form.get('hostMonitor').setValue(false);
    }
    if (this.lslogsDataList[backOperationCount]['hostSystem'] == 1) {
      this.form.get('hostSystem').setValue(true);
    } else {
      this.form.get('hostSystem').setValue(false);
    }
    if (this.lslogsDataList[backOperationCount]['partitionApps'] == 1) {
      this.form.get('partitionApps').setValue(true);
    } else {
      this.form.get('partitionApps').setValue(false);
    }
    if (this.lslogsDataList[backOperationCount]['partitionMonitor'] == 1) {
      this.form.get('partitionMonitor').setValue(true);
    } else {
      this.form.get('partitionMonitor').setValue(false);
    }
    if (this.lslogsDataList[backOperationCount]['partitionSystem'] == 1) {
      this.form.get('partitionSystem').setValue(true);
    } else {
      this.form.get('partitionSystem').setValue(false);
    }

  }

  backToPreviousAppliance() {
    debugger;

    this.form.reset();

    $("#logs").fadeOut(20);
    
    this.setValueAllChecked();
    this.applianceName = this.selectedAppliances[this.applianceCount - 2]['applianceName'];
    let backOperationCount = this.applianceCount - 2;
    //this.setValuesToForm(backOperationCount);
    this.applianceCount = this.applianceCount - 1;
    this.partitionListCount = this.selectedAppliances[this.applianceCount - 1]['partitionDetailModels'].length;
    this.list = [];
    this.hostList = [];
    this.partitionsList = [];
    this.selectedPartitions = [];
    this.selectedPartitionsDuplicate=[];
    this.setValueAllChecked();
    this.getPartitionList();
    this.showNextButton = true;
    //this.setValueAllChecked();
    if (this.applianceCount == 1) {
      this.showBackButton = false;
      this.showDeleteButton = false;
      this.showDownloadButton = false;

    }
    this.lslogsTabs.tabs[0].active = true;
    this.tabName = "Lslogs";
    $("#logs").fadeIn("slow");
  }
  saveLslogs() {
    debugger;
    $("#logs").fadeOut(20);
    if (this.applianceCount < this.selectedAppliances.length) {
      this.form.reset();
      this.applianceName = this.selectedAppliances[this.applianceCount]['applianceName'];
      this.applianceCount++;
      this.showBackButton = true;
      if(this.applianceCount == this.selectedAppliances.length){
        this.showNextButton = false;
      }
      
      this.showDeleteButton = true;
      this.showDownloadButton = true;
      this.lslogsTabs.tabs[0].active = true;

      this.list = [];
      this.hostList = [];
      this.partitionListCount = this.selectedAppliances[this.applianceCount - 1]['partitionDetailModels'].length;
      this.partitionsList = [];
      this.selectedPartitions = [];
      this.selectedPartitionsDuplicate=[];
      this.setValueAllChecked();
      this.getPartitionList();
      this.modal = [];
      $("#logs").fadeIn("slow");
    }
    else {
      this.form.reset();
      // this.applianceCount++;
    }
  }

  submitDownload() {
    this.checkAtleastOneChecked();
    if (this.isSelected == true) {
      debugger;
      this.createPayloadModal();
      this.loading = true;
      console.log(this.modal);
      this._applianceManagementService.downloadLogs(this.modal).subscribe(
        (res) => {
          this.loading = false;

          this.downloadFile(res);
          //alert("Selected Logs download will start shortly...")
        }, (err) => {
          console.log(err);
        })
    }
    else {
      this.errorMessage = "Select Atleast 1 module to download the Logs";
      this.selecterror.show();
    }

  }

  downloadFile(response) {
    debugger;
    const contentType = response.headers.get('Content-Type');
    if (contentType != 'text/html;charset=ISO-8859-1') {
      const contentDispositionHeader: string = response.headers.get('Content-Disposition');
      if (contentDispositionHeader != null) {
        this.loading = false;
        const parts: string[] = contentDispositionHeader.split(';');
        const filename = parts[1].split('=')[1];
        const blob = new Blob([response._body], { type: response.headers.get('Content-Type') });
        saveAs(blob, filename);
      }
    } else {
      let res = JSON.stringify(response);
      let res1 = JSON.parse(res);
      //this.responseOperation1(res1);
      let displaymsg = "";
      displaymsg = res1.errorMessage;
      bootbox.dialog({
        message: displaymsg,
        buttons: {
          Ok: {
            label: "Close",
            className: 'btn btn-primary btn-flat',
            callback: () => this.callBack()
          }
        }
      });
    }
  }

  responseOperation1(res) {
    this.loading = false;
    if (res != null && res._body) {
      let responseBody = res._body;
      //this.errorMsgForDownload=responseBody;
    }

  }

  deleteLogs() {
    this.checkAtleastOneChecked();
    if (this.isSelected == true) {
      this.createPayloadModal();
      this.loading = true;
      this._applianceManagementService.deleteLogs(this.modal).subscribe(
        (res) => {
          this.loading = false;

          let displaymsg = "";
          displaymsg = res.responseMessage;
          bootbox.dialog({
            message: displaymsg,
            buttons: {
              Ok: {
                label: "Close",
                className: 'btn btn-primary btn-flat',
                callback: () => this.callBack()
              }
            }
          });
        }, (err) => {
          console.log(err);
        })

    } else {
      this.errorMessage = "Select Atleast 1 module to Delete the Logs";
      this.selecterror.show();
    }
  }

  callBack() {
    this.form.reset();
    this.lslogsDataList = [];
    this.list = [];
    this.hostList = [];
    this.partitionsList = [];
    //this.selectedPartitions = [];
    //this.selectedPartitionsDuplicate=[];
    this.messageEvent.emit();
  }
  logsModalPayload() {
    let modal = {
      'logs': {
        // 'admin': {
        //   'options': []
        // },
        // 'host': {
        //   'options': []
        // },
        // 'partitions': {
        //   'options': [],
        //   'partitionsNames': []
        // }
      }
    }
    return modal;
  }
  createPayloadModal() {
    debugger;
    this.modal = this.logsModalPayload();
    this.modal['operationUsername'] = this.selectedAppliances[this.applianceCount - 1]['userName'];
    this.modal['operationPassword'] = this.selectedAppliances[this.applianceCount - 1]['userPassword'];
    this.modal['applianceIp'] = this.selectedAppliances[this.applianceCount - 1]['ipAddress'];
    this.modal['applianceName'] = this.selectedAppliances[this.applianceCount - 1]['applianceName'];
    this.modal['applianceId'] = this.selectedAppliances[this.applianceCount - 1]['applianceId'];

    if (this.list.length > 0) {

      this.modal['logs'] = {
        'admin': {
          'options': []
        }
      }
      this.list.forEach(element => {
        this.modal['logs']['admin']['options'].push(element);
      });

    }

    if (this.hostList.length > 0) {

      this.modal['logs'] = {

        'host': {
          'options': []
        }
      } 
      this.hostList.forEach(element => {
        this.modal['logs']['host']['options'].push(element);
      });

    }

    if (this.partitionsList.length > 0) {
      this.modal['logs'] = {

        'partitions': {
          'options': [],
          'partitionsNames': []
        }
      }
this.partitionsList.forEach(element => {
        this.modal['logs']['partitions']['options'].push(element);
      });
      this.selectedPartitionsDuplicate.forEach(element => {
        this.modal['logs']['partitions']['partitionsNames'].push(element.partitionName);
      })
    }

  

   

    if (this.list.length > 0) {
      if (this.hostList.length > 0) {

        this.modal['logs'] = {
          'admin': {
            'options': []
          },
          'host': {
            'options': []
          }
        }
        this.list.forEach(element => {
          this.modal['logs']['admin']['options'].push(element);
        });
        this.hostList.forEach(element => {
          this.modal['logs']['host']['options'].push(element);
        });
      }
    }

   

    if (this.hostList.length > 0) {
      if (this.partitionsList.length > 0) {
        this.modal['logs'] = {

          'host': {
            'options': []
          },
          'partitions': {
            'options': [],
            'partitionsNames': []
          }
        }

        this.hostList.forEach(element => {
          this.modal['logs']['host']['options'].push(element);
        });
        this.partitionsList.forEach(element => {
          this.modal['logs']['partitions']['options'].push(element);
        });
        this.selectedPartitionsDuplicate.forEach(element => {
          this.modal['logs']['partitions']['partitionsNames'].push(element.partitionName);
        })
      }
    }

    if (this.list.length > 0) {
      if (this.partitionsList.length > 0) {
        this.modal['logs'] = {

          'admin': {
            'options': []
          },
          'partitions': {
            'options': [],
            'partitionsNames': []
          }
        }

        this.list.forEach(element => {
          this.modal['logs']['admin']['options'].push(element);
        });
        this.partitionsList.forEach(element => {
          this.modal['logs']['partitions']['options'].push(element);
        });
        this.selectedPartitionsDuplicate.forEach(element => {
          this.modal['logs']['partitions']['partitionsNames'].push(element.partitionName);
        })
      }
    }


    if (this.list.length > 0) {
      if (this.hostList.length > 0) {
        if (this.partitionsList.length > 0) {
          this.modal['logs'] = {
            'admin': {
              'options': []
            },
            'host': {
              'options': []
            },
            'partitions': {
              'options': [],
              'partitionsNames': []
            }
          }
          this.list.forEach(element => {
            this.modal['logs']['admin']['options'].push(element);
          });
          this.hostList.forEach(element => {
            this.modal['logs']['host']['options'].push(element);
          });
          this.partitionsList.forEach(element => {
            this.modal['logs']['partitions']['options'].push(element);
          });
          this.selectedPartitionsDuplicate.forEach(element => {
            this.modal['logs']['partitions']['partitionsNames'].push(element.partitionName);
          })
        }
      }
    }



    // this.hostList.forEach(element => {
    //   this.modal['logs']['host']['options'].push(element);
    // });
    // this.partitionsList.forEach(element => {
    //   this.modal['logs']['partitions']['options'].push(element);
    // });
    // this.selectedPartitions.forEach(element=>{
    //   this.modal['logs']['partitions']['partitionsNames'].push(element.partitionName);
    // })

    // this.list = [];
    // this.hostList = [];
    // this.partitionsList = [];
    // this.selectedPartitions =[];
  }
  createLslogsForm() {
    this.form = this._formBuilder.group({
      adminSystem: [true],
      adminMiddleware: [true],
      adminMonitor: [true],
      adminApps: [true],
     hostApps: [true],
      hostMonitor: [true],
      hostSystem: [true],
      partitionApps: [true],
      partitionMonitor: [true],
      partitionSystem: [true],
    });
  }

  closeModal() {
    this.logsModal.hide();
    this.clearData();
  }
  clearData() {
    this.form.reset();
    this.isSelected == true;
    this.errorMessage = "";
    this.applianceName = "";
    this.applianceCount = 1;
    this.selectedAppliances = [];
    
    this.tabName = "";
    this.showBackButton = false;
    this.showNextButton = true;
    this.lslogsDataList = [];
    this.list = [];
    this.hostList = [];
    this.partitionsList = [];
    this.selectedPartitions = [];
    this.selectedPartitionsDuplicate=[];
  }

  setValue(event, value) {
    debugger;
    if (event.checked) {
      this.list.push(value)
    } else {
      const index = this.list.findIndex(element => element === value);
      this.list.splice(index, 1);

    }
  }

  setValue1(event, value) {
    debugger;
    if (event.checked) {
      this.hostList.push(value)
    } else {
      const index = this.hostList.findIndex(element => element === value);
      this.hostList.splice(index, 1);

    }
  }
  setValue2(event, value) {
    debugger;
    if (event.checked) {
      this.partitionsList.push(value)
    } else {
      const index = this.partitionsList.findIndex(element => element === value);
      this.partitionsList.splice(index, 1);
    }
  }
  setValue3(event, value) {
    debugger;
    if (event.checked) {
      //this.selectedPartitions.push(value)
      const index = this.selectedPartitions.findIndex(partitionName => partitionName.partitionName  === value);
      this.selectedPartitionsDuplicate.push(this.selectedPartitions[index])
      //this.selectedPartitions.splice(index, 1);
      this.partitionListCount = this.selectedPartitionsDuplicate.length;

    } else {
      const index = this.selectedPartitionsDuplicate.findIndex(partitionName => partitionName.partitionName === value);
      this.selectedPartitionsDuplicate.splice(index, 1);
      this.partitionListCount = this.selectedPartitionsDuplicate.length;
    }
  }

  getPartitionList() {
    debugger;
    this.selectedPartitions = [];
    this.selectedPartitionsDuplicate=[];
    let partitions = this.selectedAppliances[this.applianceCount - 1]['partitionDetailModels'];
    partitions.forEach(obj => {
      obj['checked'] = true;
      obj['partitionName'] = obj.partitionName;
      this.selectedPartitions.push(obj);
      this.selectedPartitionsDuplicate.push(obj);

    });

  }

  // openSelectedPartitions() {
  //   debugger;
  //   this.applianceName = this.selectedAppliances[this.applianceCount - 1]['applianceName'];
  //   this.partitionListCount = this.selectedAppliances[this.applianceCount - 1]['partitionDetailModels'].length;
  //   this.totalAppliance = this.selectedAppliances.length;
  //   //this.logsModal.show();
   

  //   this.selectedPartitionModal.show();
  // }
  openSelectedPartitions() {
    debugger;
    this.applianceName = this.selectedAppliances[this.applianceCount - 1]['applianceName'];
    this.partitionListCount = this.selectedPartitionsDuplicate.length;
    this.totalAppliance = this.selectedAppliances.length;
    //this.logsModal.show();
   

    this.selectedPartitionModal.show();
  }

}


