import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';

import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
@Component({
  selector: 'app-snmp-configure',
  templateUrl: './snmp-configure.component.html',
  styleUrls: ['./snmp-configure.component.css']
})
export class SnmpConfigureComponent implements OnInit {

  @ViewChild('snmpModal') snmpModal: ModalDirective;
  @ViewChild('messageModal') messageModal: ModalDirective;
  @ViewChild('monitorLogin') monitorLogin: ModalDirective;
  name: string;
  @Input() applianceId;
  @Input() applianceData;
  monitorModel: any = {};
  operation: string = '';
  loading: boolean = false;
  responseArray: any = [];
  message: string = '';
  applianceName: string = '';
  downloadError: string = '';
  snmpData: any;
  form: FormGroup;
  loginForm: FormGroup;
  autenticationDetailsArray: any = [];
  constructor(private _service: AppliancemanagementService,
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _formBuilder: FormBuilder) { }

  ngOnInit() {
    this.createSNMPForm();
    this.createLoginForm();
    this.form.get("authModeEncryption").setValue("MD5");
    this.form.get("privModeEncryption").setValue("DES");
  }
  createSNMPForm() {
    this.form = this._formBuilder.group({
      enable: [''],
      enableTrap: [''],
      snmpip: ['', Validators.required],
      uname: ['', Validators.required],
      port: ['', Validators.required],
      engineId: ['',[Validators.required,Validators.min(3),Validators.max(64)]],
      authMode: [true],
      privMode: [true],
      authModeEncryption: [''],
      authModePassword: [''],
      privModeEncryption: [''],
      privModePassword: ['']
    });
  }

  public formValidationFields2 = {
    "uname": '',
    "snmpip": '',
    "port": '',
    "engineId": '',
    "password": '',
  }

  isFieldValid2(field: string) {
    if (this.form.get(field).touched) {
      this.formValidationFields2 = this._fieldErrorDisplayService.validateField(this.form, field, this.formValidationFields2, "snmpvalid")
    }
    return !this.form.get(field).valid && this.form.get(field).touched;
  }
  displayFieldCss2(field: string) {
    return {
      'has-error': this.isFieldValid2(field),
      'has-feedback': this.isFieldValid2(field)
    };
  }

  showMonitorLogin(value) {
    this.clearDetails();
    this.name = value;
    this.loginForm.reset();
    this.form.reset();
    this.monitorLogin.show();
  }
  submitLoginDetails() {
    let loginDetailsModal = {};
    loginDetailsModal['applianceId'] = this.applianceData.applianceId;
    loginDetailsModal['applianceName'] = this.applianceData.applianceName;
    loginDetailsModal['ipAddress'] = this.applianceData.ipAddress;
    loginDetailsModal['operationUsername'] = this.loginForm.get('username').value;
    loginDetailsModal['operationPassword'] = this.loginForm.get('password').value;
    this.autenticationDetailsArray.push(loginDetailsModal);
    this.checkAppliancesCredentials();
  }

  checkAppliancesCredentials() {
    debugger;
    this.loading = true;
    this.responseArray = [];
    this.monitorLogin.hide();
    this._service.checkAppliancesCredentials(this.autenticationDetailsArray).subscribe(
      (response) => {
        this.loading = false;
        let isSuccess: boolean = true;
        this.autenticationDetailsArray = [];
        response.forEach(obj => {
          if (obj.code != "200") {
            this.responseArray.push(obj);
            isSuccess = false;
          }
        });
        if (isSuccess) {
          this.snmpModal.show();
          this.getSNMPDetails();
        } else {
          this.messageModal.show();
        }
      },
      (error) => {
        console.log(error);
      })
  }

  getSNMPDetails() {
    debugger;
    let applianceData = {};
    applianceData['applianceId'] = this.applianceData.applianceId;
    this._service.getSNMPDetails(applianceData).subscribe(
      (response) => {

        console.log(response);
        this.snmpData = JSON.parse(response.message);
        console.log(this.snmpData);
        if (this.snmpData.enabled == "yes") {
          this.form.get("enable").setValue(true);
        } else {
          this.form.get("enable").setValue(false);
          this.form.get("uname").disable();
          this.form.get("snmpip").disable();
          this.form.get("authMode").disable();
          this.form.get("privMode").disable();
          this.form.get("port").disable();
          this.form.get("engineId").disable();
          this.form.get("enableTrap").disable();
          this.form.get("authModeEncryption").disable();
          this.form.get("authModePassword").disable();
          this.form.get("privModeEncryption").disable();
          this.form.get("privModePassword").disable();
        }
        if (this.snmpData.trapEnabled == "yes") {
          this.form.get("enableTrap").setValue(true);
        } else {
          this.form.get("enableTrap").setValue(false);
        }
        this.form.get("uname").setValue(this.snmpData.uname);
        this.form.get("snmpip").setValue(this.snmpData.ip);
        this.form.get("port").setValue(this.snmpData.port);
        this.form.get("engineId").setValue(this.snmpData.engineId);
        if (this.snmpData.auth == "None" || this.snmpData.auth == null) {
          this.form.get("authMode").setValue(false);
          this.form.get("authModeEncryption").setValue("md5");
          this.form.get("privMode").disable();
          this.form.get("authModeEncryption").disable();
          this.form.get("authModePassword").disable();
          this.form.get("privModeEncryption").disable();
          this.form.get("privModePassword").disable();
        } else {
          let value = '';
          if (this.snmpData.auth == "MD5") {
            value = "md5";
          } else if (this.snmpData.auth == "SHA") {
            value = "sha";
          } else if (this.snmpData.auth == "SHA128") {
            value = "sha128";
          } else if (this.snmpData.auth == "SHA192") {
            value = "sha192";
          } else if (this.snmpData.auth == "SHA256") {
            value = "sha256";
          } else if (this.snmpData.auth == "SHA384") {
            value = "sha384";
          } else {
            value = "md5"
          }
          this.form.get("authMode").setValue(true);
          this.form.get("authModeEncryption").setValue(value);
        }
        if (this.snmpData.authPwd == "none") {
          this.form.get("authModePassword").setValue('');
        } else {
          this.form.get("authModePassword").setValue(this.snmpData.authPwd);
        }
        if (this.snmpData.priv == "None" || this.snmpData.priv == null) {
          this.form.get("privMode").setValue(false);
          this.form.get("privModeEncryption").setValue("des");
          this.form.get("privModeEncryption").disable();
          this.form.get("privModePassword").disable();
        }
        else {
          let value = '';
          if (this.snmpData.priv == "DES") {
            value = "des";
          } else if (this.snmpData.priv == "3DES") {
            value = "3des";
          } else if (this.snmpData.priv == "AES128") {
            value = "aes128";
          } else if (this.snmpData.priv == "AES192") {
            value = "aes192";
          } else if (this.snmpData.priv == "AES256") {
            value = "aes256";
          } else {
            value = "des"
          }
          this.form.get("privMode").setValue(true);
          this.form.get("privModeEncryption").setValue(value);
        }
        if (this.snmpData.privPwd == "none") {
          this.form.get("privModePassword").setValue('');
        } else {
          this.form.get("privModePassword").setValue(this.snmpData.privPwd);
        }
        console.log(this.form.value);
      }
    )
  }

  clearDetails() {
    this.message = '';
    this.applianceName = '';
    this.responseArray = [];
  }


  submitSNMPDetails() {
    if(this.isValidAlphaNumeric==true && this.isValidIp==true && this.isValidAlphaNumeric1==true){
    debugger;
    this.responseArray = [];
    this.message = '';
    this.applianceName = '';
    this.loading = true;
    let applianceData = {};
    if (this.form.get('enable').value == false) {
      applianceData['enable'] = this.form.get("enable").value;
      applianceData['applianceId'] = this.applianceData.applianceId;
      applianceData['operationUsername'] = this.loginForm.get('username').value;
      applianceData['operationPassword'] = this.loginForm.get('password').value;
      applianceData['applianceIp'] = this.applianceData.ipAddress;
    } else {
      if (this.form.get('authMode').value == false) {
        this.form.get("authModeEncryption").setValue("none");
      }
      if (this.form.get('privMode').value == false) {
        this.form.get("privModeEncryption").setValue("none");
      }
      applianceData['applianceId'] = this.applianceData.applianceId;
      applianceData['operationUsername'] = this.loginForm.get('username').value;
      applianceData['operationPassword'] = this.loginForm.get('password').value;
      applianceData['applianceIp'] = this.applianceData.ipAddress;
      applianceData['uname'] = this.form.get("uname").value;
      applianceData['snmpip'] = this.form.get("snmpip").value;
      applianceData['port'] = this.form.get("port").value;
      applianceData['engineId'] = this.form.get("engineId").value;
      applianceData['enable'] = this.form.get("enable").value;
      applianceData['enableTrap'] = this.form.get("enableTrap").value;
      applianceData['snmpip'] = this.form.get("snmpip").value;
      applianceData['authModeEncryption'] = this.form.get("authModeEncryption").value;
      applianceData['authModePassword'] = this.form.get("authModePassword").value;
      applianceData['privModeEncryption'] = this.form.get("privModeEncryption").value;
      applianceData['privModePassword'] = this.form.get("privModePassword").value;
    }

    this._service.setSNMPDetails(applianceData).subscribe(
      (response) => {
        this.loading = false;
        this.snmpModal.hide();
        this.messageModal.show();
        this.applianceName = this.applianceData.applianceName;
        this.message = response.message;
        console.log(response);
      },
      (error) => {
        this.loading = false;
        console.log(error);
      }
    )
   }
  }


  createLoginForm() {
    this.loginForm = this._formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
    });
  }

  public formValidationFields1 = {
    "username": '',
    "password": ''

  }
  isFieldValid1(field: string) {
    if (this.loginForm.get(field).touched) {
      this.formValidationFields1 = this._fieldErrorDisplayService.validateField(this.loginForm, field, this.formValidationFields1, "login")
    }
    return !this.loginForm.get(field).valid && this.loginForm.get(field).touched;
  }

  displayFieldCss1(field: string) {
    return {
      'has-error': this.isFieldValid1(field),
      'has-feedback': this.isFieldValid1(field)
    };
  }

  toggleEnable(event) {
    debugger;
    if (event.checked) {
      this.form.get("uname").enable();
      this.form.get("snmpip").enable();
      this.form.get("authMode").enable();
      this.form.get("port").enable();
      this.form.get("engineId").enable();
      this.form.get("enableTrap").enable();
      this.form.get("privMode").disable();
      this.form.get("authModeEncryption").disable();
      this.form.get("authModePassword").disable();
      this.form.get("privModeEncryption").disable();
      this.form.get("privModePassword").disable();
    } else {
      this.form.get("uname").disable();
      this.form.get("snmpip").disable();
      this.form.get("authMode").disable();
      this.form.get("privMode").disable();
      this.form.get("port").disable();
      this.form.get("engineId").disable();
      this.form.get("enableTrap").disable();
      this.form.get("authModeEncryption").disable();
      this.form.get("authModePassword").disable();
      this.form.get("privModeEncryption").disable();
      this.form.get("privModePassword").disable();
    }
  }

  toggleAuthMode(event) {
    if (event.checked) {
      this.form.get("privMode").enable();
      this.form.get("authModeEncryption").enable();
      this.form.get("authModePassword").enable();
      this.form.get("privModeEncryption").disable();
      this.form.get("privModePassword").disable();
    } else {
      this.form.get("privMode").disable();
      this.form.get("authModeEncryption").disable();
      this.form.get("authModePassword").disable();
      this.form.get("privModeEncryption").disable();
      this.form.get("privModePassword").disable();
    }
  }

  togglePrivMode(event) {
    if (event.checked) {
      this.form.get("privModeEncryption").enable();
      this.form.get("privModePassword").enable();
    } else {
      this.form.get("privModeEncryption").disable();
      this.form.get("privModePassword").disable();
    }
  }

  isValidIp = true;
  validateIPaddress(inputText) {
    this.isValidIp = true;
    var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    if (inputText != '') {
      if (inputText.match(ipformat)) {
        this.isValidIp = true;
      }
      else {
        this.isValidIp = false;
      }
    }
  }

  isValidAlphaNumeric = true;
  validateAlphanumeric(inputText) {
    this.isValidAlphaNumeric = true;
    var alphanumericformat = /^[0-9a-zA-Z]+$/;
    if (inputText != '') {
      if (inputText.match(alphanumericformat)) {
        this.isValidAlphaNumeric = true;
      }
      else {
        this.isValidAlphaNumeric = false;
      }
    }
  }

  isValidAlphaNumeric1 = true;
  validateAlphanumeric1(inputText) {
    this.isValidAlphaNumeric1 = true;
    var alphanumericformat = /^[0-9a-f]+$/;
    if (inputText != '') {
      if (inputText.match(alphanumericformat)) {
        this.isValidAlphaNumeric1 = true;
      }
      else {
        this.isValidAlphaNumeric1 = false;
      }
    }
    if(inputText.length<10 ){
      this.isValidAlphaNumeric1 = false;
      } 
  }

  public OnlyNumericValues(e) {
    let input;
    if (e.metaKey || e.ctrlKey) {
      return true;
    }
    if (e.which === 32) {
      return false;
    }
    if (e.which === 0) {
      return true;
    }
    if (e.which < 33) {
      return true;
    }
    input = String.fromCharCode(e.which);
    return !!/[\d\s]/.test(input);
  }
}  
