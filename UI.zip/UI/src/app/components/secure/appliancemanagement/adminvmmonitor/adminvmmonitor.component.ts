import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import * as Hammer from 'hammerjs';
import { saveAs } from 'file-saver';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
declare var $: any;
declare var jQuery: any;

@Component({
  selector: 'app-adminvmmonitor',
  templateUrl: './adminvmmonitor.component.html',
  styleUrls: ['./adminvmmonitor.component.css']
})
export class AdminvmmonitorComponent implements OnInit {

  @ViewChild('monitorModal1') monitorModal1: ModalDirective;
  @ViewChild('messageModal1') messageModal1: ModalDirective;
  @ViewChild('monitorLogin1') monitorLogin1: ModalDirective;
  name: string;
  @Input() applianceData;
  monitorModel: any = {};
  operation: string = '';
  info: string = '';
  warning: string = '';
  critical: string = '';
  isInfo: boolean = true;
  isWarning: boolean = false;
  isCritical: boolean = false;
  loading: boolean = false;
  responseArray: any = [];
  downloadError: string = '';
  loginForm: FormGroup;
  autenticationDetailsArray : any = [];
  savedLoginCredentails : any = {};
  constructor(private _service: AppliancemanagementService,
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _formBuilder: FormBuilder) { }

  ngOnInit() {
    this.monitorModel = this.createMonitorDataJSON();
    this.createLoginForm();
    $(document).ready(function() {
      $("div.bhoechie-tab-menu>div.list-group>a").click(function(e) {
          e.preventDefault();
          $(this).siblings('a.active').removeClass("active");
          $(this).addClass("active");
          var index = $(this).index();
          $("div.bhoechie-tab>div.bhoechie-tab-content").removeClass("active");
          $("div.bhoechie-tab>div.bhoechie-tab-content").eq(index).addClass("active");
      });
  });
  }
  createMonitorDataJSON() {
    let modal = {
      "applianceId": "",
      "applianceName": "",
      "applianceStatus": "",
      "serialNumber": "",
      "networkTimezone": "",
      "gatewayIp": "",
      "ipAddress": "",
      "networkId": "",
      "subnetMask": "",
      "monitorType": "admin",
      "operationUsername": "",
      "operationPassword": "",
      "monitorData": {
        "cpu": {
          "info": this.getFields(),
          "warn": this.getFields(),
          "crit": this.getFields()
        },
        "pcpu": {
          "info": this.getFields(),
          "warn": this.getFields(),
          "crit": this.getFields()
        },
        "memory": {
          "info": this.getFields(),
          "warn": this.getFields(),
          "crit": this.getFields()
        },
        "network": {
          "interfacename": ''
        }
      }
    }
    return modal;
  }

  getFields() {
    let fields = {
      'start': 'no',
      'threshold': '1',
      'samplecount': '1',
      'isDisabled': true,
      'isChecked': false
    }
    return fields;
  }

  showMonitorLogin(value) {
    this.savedLoginCredentails = {};
    this.clearDetails();
    this.name = value;
    this.loginForm.reset();
    let loginCredentials = JSON.parse(localStorage.getItem(this.applianceData.ipAddress));
    if (loginCredentials != null) {
      this.savedLoginCredentails['operationUsername'] = loginCredentials.username;
      this.savedLoginCredentails['operationPassword'] = loginCredentials.password;
      this.getMonitorDetails();
    } else{
      this.monitorLogin1.show();
    }
  }
  submitLoginDetails() {
    let loginDetailsModal = {};
    loginDetailsModal['applianceId'] = this.applianceData.applianceId;
    loginDetailsModal['applianceName'] = this.applianceData.applianceName;
    loginDetailsModal['ipAddress'] = this.applianceData.ipAddress;
    loginDetailsModal['operationUsername'] = this.loginForm.get('username').value;
    loginDetailsModal['operationPassword'] = this.loginForm.get('password').value;
    this.autenticationDetailsArray.push(loginDetailsModal);
    this.checkAppliancesCredentials();
  }
  
  checkAppliancesCredentials() {
    this.loading = true;
    this.responseArray = [];
    this.monitorLogin1.hide();
    this._service.checkAppliancesCredentials(this.autenticationDetailsArray).subscribe(
      (response) => {
        this.loading = false;
        let isSuccess: boolean = true;
        this.autenticationDetailsArray = [];
        response.forEach(obj => {
          if(obj.code!=null){
            if (obj.code != "200") {
              if(obj.code == "408"){
                this.downloadError = obj.errorMessage;
              }else{
                this.responseArray.push(obj);
              }
              isSuccess = false;
            } else {
              // Storing appliance login credentials in local session
              let ipAddress = obj.ipAddress;
              let loginCredentials = {
                username: this.loginForm.get('username').value,
                password: this.loginForm.get('password').value
              };
              localStorage.setItem(ipAddress, JSON.stringify(loginCredentials));
              // local session code ends here
            }
          }else{
            isSuccess = false;
            this.downloadError = "Operation can not perform due to connection error";
          }
        });
        if (isSuccess) {
          this.getMonitorDetails();
        } else{
          this.messageModal1.show();
        }
      },
      (error) => {
        this.loading = false;
        console.log(error);
      })
  }
  getMonitorDetails() {
    let applianceArray = this.setValuesToGetData();
    this._service.getApplianceMonitorData(applianceArray).subscribe(
      (response) => {
        this.setMonitorDataToModel(response);
        this.monitorModal1.show();
      },
      (error)=>{
        console.log(error);
      }
    )
  }

  clearDetails() {
    this.name = '';
    this.monitorModel = this.createMonitorDataJSON();
    this.operation = '';
    this.info = '';
    this.warning = '';
    this.critical = '';
    this.isInfo = true;
    this.isWarning = false;
    this.isCritical = false;
    // this.isNetwork = false;
    this.loading = false;
    this.responseArray = [];
    this.downloadError = '';
  }

  setValuesToGetData() {
    let applianceData = {};
    let applianceArray: any = [];
    applianceData['applianceId'] = this.applianceData.applianceId;
    applianceData['applianceName'] = this.applianceData.applianceName;
    applianceData['applianceStatus'] = this.applianceData.applianceStatus;
    applianceData['serialNumber'] = this.applianceData.serialNumber;
    applianceData['networkTimezone'] = this.applianceData.networkTimezone;
    applianceData['gatewayIp'] = this.applianceData.gatewayIp;
    applianceData['ipAddress'] = this.applianceData.ipAddress;
    applianceData['networkId'] = this.applianceData.networkId;
    applianceData['subnetMask'] = this.applianceData.subnetMask;
    applianceData['monitorType'] = "admin";
    // applianceData['operationUsername'] = this.loginForm.get('username').value;
    // applianceData['operationPassword'] = this.loginForm.get('password').value;
    if(this.savedLoginCredentails!=null){
      applianceData['operationUsername'] = this.savedLoginCredentails.operationUsername;
      applianceData['operationPassword'] = this.savedLoginCredentails.operationPassword;
    }else{
      applianceData['operationUsername'] = this.loginForm.get('username').value;
      applianceData['operationPassword'] = this.loginForm.get('password').value;
    }
    applianceArray.push(applianceData);
    return applianceArray;
  }

  setMonitorDataToModel(response) {
    this.setApplianceDetailsToModel();
    response.forEach(obj => {
      if(obj.monitorData!=null){
        this.setMemoryDetailsToModel(obj);
        this.setCpuDetailsToModel(obj);
        this.setPcpuDetailsToModel(obj);
        this.setNetworkDetailsToModel(obj);
      }
    });
  }

  setApplianceDetailsToModel() {
    // appliance data
    // this.monitorModel['applianceId'] = obj.applianceId;
    // this.monitorModel['applianceName'] = obj.applianceName;
    // this.monitorModel['applianceStatus'] = obj.applianceStatus;
    // this.monitorModel['serialNumber'] = obj.serialNumber;
    // this.monitorModel['networkTimezone'] = obj.networkTimezone;
    // this.monitorModel['gatewayIp'] = obj.gatewayIp;
    // this.monitorModel['ipAddress'] = obj.ipAddress;
    // this.monitorModel['networkId'] = obj.networkId;
    // this.monitorModel['subnetMask'] = obj.subnetMask;
    this.monitorModel['applianceId'] = this.applianceData.applianceId;
    this.monitorModel['applianceName'] = this.applianceData.applianceName;
    this.monitorModel['applianceStatus'] = this.applianceData.applianceStatus;
    this.monitorModel['serialNumber'] = this.applianceData.serialNumber;
    this.monitorModel['networkTimezone'] = this.applianceData.networkTimezone;
    this.monitorModel['gatewayIp'] = this.applianceData.gatewayIp;
    this.monitorModel['ipAddress'] = this.applianceData.ipAddress;
    this.monitorModel['networkId'] = this.applianceData.networkId;
    this.monitorModel['subnetMask'] = this.applianceData.subnetMask;
    this.monitorModel['monitorType'] = "admin";
    // this.monitorModel['operationUsername'] = this.loginForm.get('username').value;
    // this.monitorModel['operationPassword'] =this.loginForm.get('password').value;
    if(this.savedLoginCredentails!=null){
      this.monitorModel['operationUsername'] = this.savedLoginCredentails.operationUsername;
      this.monitorModel['operationPassword'] = this.savedLoginCredentails.operationPassword;
    }else{
      this.monitorModel['operationUsername'] = this.loginForm.get('username').value;
      this.monitorModel['operationPassword'] = this.loginForm.get('password').value;
    }
  }

  setMemoryDetailsToModel(obj) {
    // memory
    if(obj.monitorData.memory!=null){
      if(obj.monitorData.memory.crit!=null){
        this.monitorModel['monitorData']['memory']['crit']['samplecount'] = obj.monitorData.memory.crit.samplecount;
        this.monitorModel['monitorData']['memory']['crit']['threshold'] = obj.monitorData.memory.crit.threshold;
        this.monitorModel['monitorData']['memory']['crit']['start'] = obj.monitorData.memory.crit.start;
        if (obj.monitorData.memory.crit.start == "yes") {
          this.monitorModel['monitorData']['memory']['crit']['isChecked'] = true;
          this.monitorModel['monitorData']['memory']['crit']['isDisabled'] = false;
        }
      }
      if(obj.monitorData.memory.warn!=null){
        this.monitorModel['monitorData']['memory']['warn']['samplecount'] = obj.monitorData.memory.warn.samplecount;
        this.monitorModel['monitorData']['memory']['warn']['threshold'] = obj.monitorData.memory.warn.threshold;
        this.monitorModel['monitorData']['memory']['warn']['start'] = obj.monitorData.memory.warn.start;
        if (obj.monitorData.memory.warn.start == "yes") {
          this.monitorModel['monitorData']['memory']['warn']['isChecked'] = true;
          this.monitorModel['monitorData']['memory']['warn']['isDisabled'] = false;
        }
      }
      if(obj.monitorData.memory.info!=null){
        this.monitorModel['monitorData']['memory']['info']['samplecount'] = obj.monitorData.memory.info.samplecount;
        this.monitorModel['monitorData']['memory']['info']['threshold'] = obj.monitorData.memory.info.threshold;
        this.monitorModel['monitorData']['memory']['info']['start'] = obj.monitorData.memory.info.start;
        if (obj.monitorData.memory.info.start == "yes") {
          this.monitorModel['monitorData']['memory']['info']['isChecked'] = true;
          this.monitorModel['monitorData']['memory']['info']['isDisabled'] = false;
        }
      }
    }
  }

  setCpuDetailsToModel(obj) {
    // cpu
    if(obj.monitorData.cpu!=null){
      if(obj.monitorData.cpu.crit!=null){
        this.monitorModel['monitorData']['cpu']['crit']['samplecount'] = obj.monitorData.cpu.crit.samplecount;
        this.monitorModel['monitorData']['cpu']['crit']['threshold'] = obj.monitorData.cpu.crit.threshold;
        this.monitorModel['monitorData']['cpu']['crit']['start'] = obj.monitorData.cpu.crit.start;
        if (obj.monitorData.cpu.crit.start == "yes") {
          this.monitorModel['monitorData']['cpu']['crit']['isChecked'] = true;
          this.monitorModel['monitorData']['cpu']['crit']['isDisabled'] = false;
        }
      }
      if(obj.monitorData.cpu.warn!=null){
        this.monitorModel['monitorData']['cpu']['warn']['samplecount'] = obj.monitorData.cpu.warn.samplecount;
        this.monitorModel['monitorData']['cpu']['warn']['threshold'] = obj.monitorData.cpu.warn.threshold;
        this.monitorModel['monitorData']['cpu']['warn']['start'] = obj.monitorData.cpu.warn.start;
        if (obj.monitorData.cpu.warn.start == "yes") {
          this.monitorModel['monitorData']['cpu']['warn']['isChecked'] = true;
          this.monitorModel['monitorData']['cpu']['warn']['isDisabled'] = false;
        }
      }
      if(obj.monitorData.cpu.info!=null){
        this.monitorModel['monitorData']['cpu']['info']['samplecount'] = obj.monitorData.cpu.info.samplecount;
        this.monitorModel['monitorData']['cpu']['info']['threshold'] = obj.monitorData.cpu.info.threshold;
        this.monitorModel['monitorData']['cpu']['info']['start'] = obj.monitorData.cpu.info.start;
        if (obj.monitorData.cpu.info.start == "yes") {
          this.monitorModel['monitorData']['cpu']['info']['isChecked'] = true;
          this.monitorModel['monitorData']['cpu']['info']['isDisabled'] = false;
        }
      }
    }
  }

  setPcpuDetailsToModel(obj) {
    // pcpu
    if(obj.monitorData.pcpu!=null){
      if(obj.monitorData.pcpu.crit!=null){
        this.monitorModel['monitorData']['pcpu']['crit']['samplecount'] = obj.monitorData.pcpu.crit.samplecount;
        this.monitorModel['monitorData']['pcpu']['crit']['threshold'] = obj.monitorData.pcpu.crit.threshold;
        this.monitorModel['monitorData']['pcpu']['crit']['start'] = obj.monitorData.pcpu.crit.start;
        if (obj.monitorData.pcpu.crit.start == "yes") {
          this.monitorModel['monitorData']['pcpu']['crit']['isChecked'] = true;
          this.monitorModel['monitorData']['pcpu']['crit']['isDisabled'] = false;
        }
      }
      if(obj.monitorData.pcpu.warn!=null){
        this.monitorModel['monitorData']['pcpu']['warn']['samplecount'] = obj.monitorData.pcpu.warn.samplecount;
        this.monitorModel['monitorData']['pcpu']['warn']['threshold'] = obj.monitorData.pcpu.warn.threshold;
        this.monitorModel['monitorData']['pcpu']['warn']['start'] = obj.monitorData.pcpu.warn.start;
        if (obj.monitorData.pcpu.warn.start == "yes") {
          this.monitorModel['monitorData']['pcpu']['warn']['isChecked'] = true;
          this.monitorModel['monitorData']['pcpu']['warn']['isDisabled'] = false;
        }
      }
      if(obj.monitorData.pcpu.info!=null){
        this.monitorModel['monitorData']['pcpu']['info']['samplecount'] = obj.monitorData.pcpu.info.samplecount;
        this.monitorModel['monitorData']['pcpu']['info']['threshold'] = obj.monitorData.pcpu.info.threshold;
        this.monitorModel['monitorData']['pcpu']['info']['start'] = obj.monitorData.pcpu.info.start;
        if (obj.monitorData.pcpu.info.start == "yes") {
          this.monitorModel['monitorData']['pcpu']['info']['isChecked'] = true;
          this.monitorModel['monitorData']['pcpu']['info']['isDisabled'] = false;
        }
      }
    }
  }

  setNetworkDetailsToModel(obj){
    if(obj.monitorData.network!=null){
      if(obj.monitorData.network.interfacename!=null){
        this.monitorModel['monitorData']['network']['interfacename']=obj.monitorData.network.interfacename;
      }
    }
  }

  changeOperation(operation) {
    if (operation == "info") {
      this.info = "btn-primary";
      this.warning = "btn-default";
      this.critical = "btn-default";
      this.isInfo = true;
      this.isWarning = false;
      this.isCritical = false;
    } else if (operation == "warning") {
      this.info = "btn-default";
      this.warning = "btn-primary";
      this.critical = "btn-default";
      this.isInfo = false;
      this.isWarning = true;
      this.isCritical = false;
    } else if (operation == "critical") {
      this.info = "btn-default";
      this.warning = "btn-default";
      this.critical = "btn-primary";
      this.isInfo = false;
      this.isWarning = false;
      this.isCritical = true;
    }
  }

  enableSlider(event, value, value1) {
    if (event.checked) {
      this.monitorModel['monitorData'][value1][value]['isDisabled'] = false;
      this.monitorModel['monitorData'][value1][value]['start']="yes";
    } else {
      this.monitorModel['monitorData'][value1][value]['isDisabled'] = true;
      this.monitorModel['monitorData'][value1][value]['start']="no";
    }

  }

  submitMonitorDetails() {
    this.downloadError = '';
    this.responseArray = [];
    let applianceModelArray = [];
    applianceModelArray.push(this.monitorModel);
    this.loading = true;
    debugger;
    this._service.setApplianceMonitorData(applianceModelArray).subscribe(
      (response) => {
        this.loading = false;
        this.monitorModal1.hide();
        this.messageModal1.show();
        this.responseArray = response;
      },
      (error) => {
        this.loading = false;
        console.log(error);
      }
    )

  }


  formatLabel(value: number | null) {
    if (!value) {
      return 0;
    }

    if (value >= 100) {
      return Math.round(value / 100) + 'k';
    }

    return value;
  }

  downloadLogs() {
    this.loading = true;
    this.downloadError = '';
    this.responseArray = [];
    let applianceData = this.setValuesToGetData();
    this._service.downloadLogsForAppliance(applianceData[0]).subscribe(
      (response) => {
        this.loading = false;
        this.downloadFile(response);
      },
      (error) => {
        this.loading = false;
        console.log(error);
      }

    )
  }

  downloadFile(response) {
    const contentType = response.headers.get('Content-Type');
    if (contentType != 'text/html;charset=ISO-8859-1' && contentType != null) {
      const contentDispositionHeader: string = response.headers.get('Content-Disposition');
      if (contentDispositionHeader != null) {
        this.loading = false;
        const parts: string[] = contentDispositionHeader.split(';');
        const filename = parts[1].split('=')[1];
        const blob = new Blob([response._body], { type: response.headers.get('Content-Type') });
        saveAs(blob, filename);
      }
    } else {
      let res = JSON.stringify(response);
      let res1 = JSON.parse(res);
      this.downloadError = res1._body;
      this.messageModal1.show();
    }
  }

  createLoginForm() {
    this.loginForm = this._formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
    });
  }

  public formValidationFields1 = {
    "username": '',
    "password": ''

  }
  isFieldValid1(field: string) {
    if (this.loginForm.get(field).touched) {
      this.formValidationFields1 = this._fieldErrorDisplayService.validateField(this.loginForm, field, this.formValidationFields1, "login")
    }
    return !this.loginForm.get(field).valid && this.loginForm.get(field).touched;
  }

  displayFieldCss1(field: string) {
    return {
      'has-error': this.isFieldValid1(field),
      'has-feedback': this.isFieldValid1(field)
    };
  }
}
