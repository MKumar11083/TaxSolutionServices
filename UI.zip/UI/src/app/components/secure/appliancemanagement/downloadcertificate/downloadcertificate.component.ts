// import { Component, OnInit } from '@angular/core';
import { Component, OnInit, ViewChild, Output, EventEmitter, TemplateRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { FormBuilder, FormGroup, Validators, ValidatorFn, AbstractControl } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { saveAs } from 'file-saver';

declare var bootbox: any;
@Component({
  selector: 'app-downloadcertificate',
  templateUrl: './downloadcertificate.component.html',
  styleUrls: ['./downloadcertificate.component.css']
})
export class DownloadcertificateComponent implements OnInit {

@ViewChild('downloadCertificateModal') downloadCertificateModal: ModalDirective;
@Output() messageEvent = new EventEmitter<any>();
modalRef: BsModalRef;
form:FormGroup;
applianceCount = 1;
applianceName: string;
totalAppliance = 0;
selectedAppliances = [];
downloadCertificateList = [];
shownextbutton = false;
showBackButton = false;
loading = false;

  constructor(private _formBuilder: FormBuilder,private _applianceManagementService: AppliancemanagementService) { }

  ngOnInit() {
    this.createdownloadCertificateForm();
  }

  createdownloadCertificateForm(){
    this.form = this._formBuilder.group({
      fileName: [''],
      fileValidate : [''],
    });
  }

  showDownloadcertificateModal(listAppliances){
    debugger;
    
    console.log("List of selected appliance --->" + listAppliances); 
    //this.selectedAppliances = listAppliances;
    listAppliances.forEach(obj => {
      let downloadCertificateModal = {};
      downloadCertificateModal['operationUsername']= obj.operationUsername;
      downloadCertificateModal['operationPassword']= obj.operationPassword;
      downloadCertificateModal['applianceIp']= obj.ipAddress;
      downloadCertificateModal['applianceName']= obj.applianceName;
      downloadCertificateModal['certificateType']= '';
      downloadCertificateModal['applianceId']= obj.applianceId;
      this.selectedAppliances.push(downloadCertificateModal);
    });
    this.applianceName = this.selectedAppliances[this.applianceCount - 1]['applianceName'];
    this.totalAppliance = this.selectedAppliances.length;
    this.downloadCertificateModal.show();
    if (this.applianceCount < this.selectedAppliances.length) {
      this.shownextbutton = true;
    }
    else {
      this.shownextbutton = false;
    }
  }

  saveDownloadCertificate(){
    if (this.applianceCount < this.selectedAppliances.length) {
      /* get the next appliance coLoginFailureCount, min & max password length values */
      this.applianceName = this.selectedAppliances[this.applianceCount]['applianceName'];
      this.form.reset();
      
      this.applianceCount++;
      this.showBackButton = true;
      this.shownextbutton = true;
    }
    if (this.applianceCount == this.selectedAppliances.length) {
      this.shownextbutton = false;
    }
  }

  closedownloadCertificate() {
    this.downloadCertificateModal.hide();
    this.clearData();
  }

  clearData() {
    this.form.reset();
    this.applianceName = "";
    this.applianceCount = 1;
    this.selectedAppliances = [];
    this.loading = false;
  }

  backToPreviousAppliance() {
    debugger;
    this.form.reset();
    this.applianceName = this.selectedAppliances[this.applianceCount - 2]['applianceName'];
    this.applianceCount = this.applianceCount - 1;
    if (this.applianceCount == 1) {
      this.showBackButton = false;
    }
    this.shownextbutton = true;

  }

  downloadcertificates(certificatetype){
    debugger;
    let applianceData = this.selectedAppliances[this.applianceCount-1];
    if(certificatetype == "Cavium_root_certificate"){
      applianceData['certificateType'] = "export_cavium_certificate";
    }
    else if(certificatetype == "HSM_certificate_signed_by_root"){
      applianceData['certificateType'] = "export_hsm_certificate";
    }
    else if(certificatetype == "HSM_certificate_signing_request"){
      applianceData['certificateType'] = "export_hsm_csr";
    }
    else if(certificatetype == "HSM_Owner_certificate"){
      applianceData['certificateType'] = "export_hsm_owner_certificate";
    }
    else if(certificatetype == "HSM_Owner_signed_HSM_certificate"){
      applianceData['certificateType'] = "export_hsm_owner_signed_certificate";
    }
    else if(certificatetype == "Appliance_certificate"){
      applianceData['certificateType'] = "export_appliance_certificate";
    }
    debugger;
    this.loading = true;
    this._applianceManagementService.downloadcertificate(applianceData).subscribe((response) => {
        const contentType = response.headers.get('Content-Type');
        if(contentType!='text/html'){
          this.downloadFile(response);
        }
       
    }, (err) => {
      console.log(err);
    }) 
}


downloadFile(response) {
  debugger;
  const contentDispositionHeader: string = response.headers.get('Content-Disposition');
  if(contentDispositionHeader!=null){
    this.loading= false;
    const parts: string[] = contentDispositionHeader.split(';');
    const filename = parts[1].split('=')[1];
    const blob = new Blob([response._body], { type: response.headers.get('Content-Type')});
    saveAs(blob, filename);
   }
  //else{
  //   let res = JSON.stringify(response);
  //   let res1 = JSON.parse(res);
  //   this.responseOperation1(res1);
  // }
}

responseOperation1(res) {
  this.loading = false;
  
  if (res != null && res._body) {
    let responseBody = res._body;
    //this.errorMsgForDownload=responseBody;
  } 
 
}
callBack() {
  this.messageEvent.emit();
}


}
