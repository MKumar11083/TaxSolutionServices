import { Component, OnInit, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { InitializeApplianceComponent } from './../../appliancemanagement/initialize-appliance/initialize-appliance.component';
import { ApplianceOperationsComponent } from './../../appliancemanagement/appliance-operations/appliance-operations.component';
import { FirmwareUpgradeApplianceComponent } from './../../appliancemanagement/firmware-upgrade-appliance/firmware-upgrade-appliance.component';
import { ZeroizeApplianceComponent } from './../../appliancemanagement/zeroize-appliance/zeroize-appliance.component';
import { UploadcertificateComponent } from './../../appliancemanagement/uploadcertificate/uploadcertificate.component';
import { DownloadcertificateComponent } from './../../appliancemanagement/downloadcertificate/downloadcertificate.component';
import { LslogsApplianceComponent } from './../../appliancemanagement/lslogs-appliance/lslogs-appliance.component';
import { ConfigurelogsApplianceComponent } from './../../appliancemanagement/configurelogs-appliance/configurelogs-appliance.component';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { UploadMcokeyComponent } from './../../appliancemanagement/upload-mcokey/upload-mcokey.component';
@Component({
  selector: 'app-appliance-login',
  templateUrl: './appliance-login.component.html',
  styleUrls: ['./appliance-login.component.css']
})
export class ApplianceLoginComponent implements OnInit {
  @Input() selectedAppliances;
  @ViewChild('loginModal') loginModal: ModalDirective;
  @ViewChild('confirmModal')
  confirmModal: ModalDirective;
  @ViewChild('initializeAppliance')
  private initializeAppliance: InitializeApplianceComponent;
  @ViewChild('firmwareUpgradeAppliance')
  private firmwareUpgradeAppliance: FirmwareUpgradeApplianceComponent;
  @ViewChild('applianceOperations')
  private applianceOperationsComponent: ApplianceOperationsComponent;
  @ViewChild('zeroizeAppliance')
  private zeroizeAppliance: ZeroizeApplianceComponent;
  @ViewChild('uploadCertificate')
  private uploadCertificate: UploadcertificateComponent;
  @ViewChild('downloadCertificate')
  private downloadCertificate: DownloadcertificateComponent;
  @ViewChild('lslogsAppliance')
  private lslogsAppliance: LslogsApplianceComponent;
  @ViewChild('configureLogs')
  private configureLogs: ConfigurelogsApplianceComponent;
  @ViewChild('uploadMcokey')
  private uploadMcokey: UploadMcokeyComponent;
  loginForm: FormGroup;
  applianceOperation: string;
  listAppliances = [];
  applianceCount = 1;
  totalApplianceCount = 0;
  applianceName: string;
  message: string;
  isLastAppliance: boolean = false;
  autoLoginApplianceList: any = [];
  loading: boolean = false;
  autenticationDetailsArray: any = [];
  saveCredentialsToSessionArray: any = [];
  initializedApplianceList: any = [];
  @Output() loginEvent = new EventEmitter<any>();
  constructor(private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _formBuilder: FormBuilder,
    private _service: AppliancemanagementService) { }

  ngOnInit() {
    this.createLoginForm();
    this.clearDetails();
  }
  createLoginForm() {
    this.loginForm = this._formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      credentialSaved: ['']
    });
  }
  showloginModal(operation) {
    debugger;
    this.clearDetails();
    //this.listAppliances = this.selectedAppliances;
    //this.listAppliances = this.selectedAppliances.map(x => Object.assign({}, x));
    this.loginForm.reset();
    if (this.selectedAppliances.length != 0) {
      if (this.selectedAppliances.length <= 5) {
        // if credentialSaved="true" means autologin and if it false , show login popup
         if (operation == "Initialize") {
          this.selectedAppliances.forEach(appliance => {
            if (!appliance['applianceinitialized']) {
              if (appliance['credentialSaved']) {
                this.autoLoginApplianceList.push(appliance);
              } else {
                // check appliance credentials are available in localsession.
                // if available in localsession , skips the login for appliance.
                let loginCredentials = JSON.parse(localStorage.getItem(appliance.ipAddress));
                if (loginCredentials != null) {
                  appliance['operationUsername'] = loginCredentials.username;
                  appliance['operationPassword'] = loginCredentials.password;
                  appliance['userName'] = loginCredentials.username;
                  appliance['userPassword'] = loginCredentials.password;
                  this.saveCredentialsToSessionArray.push(appliance);
                } else {
                  this.listAppliances.push(appliance);
                }
              }
            } else {
              this.initializedApplianceList.push(appliance);
            }
          })
         }else{
          this.selectedAppliances.forEach(appliance => {
              if (appliance['credentialSaved']) {
                this.autoLoginApplianceList.push(appliance);
              } else {
                // check appliance credentials are available in localsession.
                // if available in localsession , skips the login for appliance.
                let loginCredentials = JSON.parse(localStorage.getItem(appliance.ipAddress));
                if (loginCredentials != null) {
                  appliance['operationUsername'] = loginCredentials.username;
                  appliance['operationPassword'] = loginCredentials.password;
                  appliance['userName'] = loginCredentials.username;
                  appliance['userPassword'] = loginCredentials.password;
                  this.saveCredentialsToSessionArray.push(appliance);
                } else {
                  this.listAppliances.push(appliance);
                }
              }
          })
         }
   
        if (operation == "Initialize") {
          if (this.initializedApplianceList.length <= 0) {
            this.applianceOperation = operation;
            if (this.listAppliances.length > 0) {
              this.applianceName = this.listAppliances[this.applianceCount - 1]['applianceName'];
              this.totalApplianceCount = this.listAppliances.length;
              if (this.applianceCount == this.totalApplianceCount) {
                this.isLastAppliance = true;
              }
              if (this.applianceOperation == 'downloadcertificate') {
                this.redirectToSelectedOperation();
              } else {
                this.loginModal.show();
              }

            } else {
              this.redirectToSelectedOperation();
            }
          } else {
            this.confirmModal.show();
          }
        }else{
          this.applianceOperation = operation;
          if (this.listAppliances.length > 0) {
            this.applianceName = this.listAppliances[this.applianceCount - 1]['applianceName'];
            this.totalApplianceCount = this.listAppliances.length;
            if (this.applianceCount == this.totalApplianceCount) {
              this.isLastAppliance = true;
            }
            if (this.applianceOperation == 'downloadcertificate') {
              this.redirectToSelectedOperation();
            } else {
              this.loginModal.show();
            }

          } else {
            this.redirectToSelectedOperation();
          }
        }

      } else {
        this.loginModal.show();
        this.message = "Sorry!Operation cannot be performed on more than five appliances";
      }
    } else {
      this.loginModal.show();
      this.message = "Please select any appliance to perform the activity!";
    }
  }


  goToNextLoginForm() {
    debugger;
    let applianceData = this.listAppliances[this.applianceCount - 1]
    let loginDetailsModal = {};
    loginDetailsModal['applianceId'] = applianceData.applianceId;
    loginDetailsModal['applianceName'] = applianceData.applianceName;
    loginDetailsModal['ipAddress'] = applianceData.ipAddress;
    loginDetailsModal['operationUsername'] = this.loginForm.get('username').value;
    loginDetailsModal['operationPassword'] = this.loginForm.get('password').value;
    this.autenticationDetailsArray.push(loginDetailsModal);
    this.listAppliances[this.applianceCount - 1]["userName"] = this.loginForm.get('username').value;
    this.listAppliances[this.applianceCount - 1]["userPassword"] = this.loginForm.get('password').value;
    this.listAppliances[this.applianceCount - 1]["operationUsername"] = this.loginForm.get('username').value;
    this.listAppliances[this.applianceCount - 1]["operationPassword"] = this.loginForm.get('password').value;
    if (this.loginForm.get('credentialSaved').value == true) {
      this.listAppliances[this.applianceCount - 1]["credentialSaved"] = true;
    } else {
      this.listAppliances[this.applianceCount - 1]["credentialSaved"] = false;
    }
    // Storing appliance login credentials in local session
    let ipAddress = this.listAppliances[this.applianceCount - 1]["ipAddress"]
    let loginCredentials = {
      username: this.loginForm.get('username').value,
      password: this.loginForm.get('password').value
    };
    localStorage.setItem(ipAddress, JSON.stringify(loginCredentials));
    // local session code ends here
    if (this.applianceCount < this.listAppliances.length) {
      this.applianceName = this.listAppliances[this.applianceCount]['applianceName'];
      this.applianceCount++;
      if (this.applianceCount == this.totalApplianceCount) {
        this.isLastAppliance = true;
      }
    } else {
      this.loginModal.hide();
      //this.redirectToSelectedOperation();
      this.checkAppliancesCredentials();
    }
    this.loginForm.reset();
  }

  checkAppliancesCredentials() {
    debugger;
    this.loading = true;
    this._service.checkAppliancesCredentials(this.autenticationDetailsArray).subscribe(
      (response) => {
        this.loading = false;
        let isSuccess: boolean = true;
        this.autenticationDetailsArray = [];
        response.forEach(obj => {
          if (obj.code != "200") {
            this.autenticationDetailsArray.push(obj);
            localStorage.removeItem(obj.ipAddress);
            isSuccess = false;
          }
        });
        if (isSuccess) {
          this.redirectToSelectedOperation();
        } else {
          this.confirmModal.show();
        }
      },
      (error) => {
        console.log(error);
      })
  }
  redirectToSelectedOperation() {
    debugger;
    // added the "credentialSaved=true" records to fill the initialize form.
    this.autoLoginApplianceList.forEach(applianceObj => {
      this.listAppliances.push(applianceObj);
    });
    // get the appliance Credentails saved in localSession.
    this.saveCredentialsToSessionArray.forEach(applianceObj => {
      this.listAppliances.push(applianceObj);
    });

    if (this.applianceOperation == "Initialize") {
      this.initializeAppliance.showInitializeModal(this.listAppliances);
    }
    else if (this.applianceOperation == "firmwareUpgrade") {
      this.firmwareUpgradeAppliance.showFirmwareUpgradeModal(this.listAppliances);
    }
    else if (this.applianceOperation == "Zeroize") {
      this.zeroizeAppliance.showZeroizeModal(this.listAppliances);
    }
    else if (this.applianceOperation == "uploadcertificate") {
      this.uploadCertificate.showUploadCertificateModal(this.listAppliances);
    }
    else if (this.applianceOperation == "downloadcertificate") {
      this.downloadCertificate.showDownloadcertificateModal(this.listAppliances);
    }
    else if (this.applianceOperation == "Lslogs") {
      this.lslogsAppliance.showLslogsModal(this.listAppliances);
    }
    else if (this.applianceOperation == "Configurelogs") {
      this.configureLogs.showConfigurelogsModal(this.listAppliances);
    }
    else if (this.applianceOperation == "uploadMcokey") {
      this.uploadMcokey.showuploadMcokeyModal(this.listAppliances);
    }
    else {
      this.applianceOperationsComponent.submitApplianceOperations(this.listAppliances, this.applianceOperation)
    }
  }
  closeLoginModal() {
    console.log("Close ----> Login Modal");
    this.loginModal.hide();
    this.clearDetails();
  }

  callback() {
    console.log("Call back ----> Appliance Login Form");
    this.clearDetails();
    this.loginEvent.emit();
  }
  clearDetails() {
    this.loginForm.reset();
    this.applianceOperation = "";
    this.listAppliances = [];
    this.applianceCount = 1;
    this.totalApplianceCount = 0;
    this.applianceName = "";
    this.message = "";
    this.isLastAppliance = false;
    this.autoLoginApplianceList = [];
    this.autenticationDetailsArray = [];
    this.saveCredentialsToSessionArray = [];
    this.initializedApplianceList = [];
  }

  public formValidationFields1 = {
    "username": '',
    "password": ''

  }
  isFieldValid1(field: string) {
    if (this.loginForm.get(field).touched) {
      this.formValidationFields1 = this._fieldErrorDisplayService.validateField(this.loginForm, field, this.formValidationFields1, "login")
    }
    return !this.loginForm.get(field).valid && this.loginForm.get(field).touched;
  }

  displayFieldCss1(field: string) {
    return {
      'has-error': this.isFieldValid1(field),
      'has-feedback': this.isFieldValid1(field)
    };
  }
}
