//import { Component, OnInit ,ChangeDetectorRef} from '@angular/core';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, FormControl } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { AddApplianceService } from './../../../../services/addAppliance.service';
import { Router } from '@angular/router';
import { Component, ChangeDetectorRef, OnInit, ViewChild, Output, EventEmitter, TemplateRef } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { TabsetComponent } from 'ngx-bootstrap';
import { TabDirective } from 'ngx-bootstrap/tabs';
import { ActivatedRoute } from '@angular/router';
import { Readable } from 'stream';
import { O_RDONLY } from 'constants';
import { readFile } from 'fs';

declare var jquery: any;
declare var $: any;
declare var bootbox: any;
@Component({
  selector: 'app-add-appliance',
  templateUrl: './add-appliance.component.html',
  styleUrls: ['./add-appliance.component.css']
})
export class AddApplianceComponent implements OnInit {
  @ViewChild('initializeTabs') initializeTabs: TabsetComponent;
  isValidZoneID = true;
  showlist: boolean = true;
  form: FormGroup;
  coLoginFailureCount: any;
  public loading = false;
  public successMessage: string;
  public successMessage1: string;
  private groupsList: string;
  getValidateRes: object[] = [];
  getValidateRes1: object[] = [];
  getValidateRes3: object[] = [];
  private applianceSent: object[] = [];
  private localStorageApplianceSent: object[] = [];
  private onPageApplianceSent: object[] = [];
  showApp: object[] = [];
  modalRef: BsModalRef;
  initializeDataList = [];
  applianceCount = 1;
  selectedAppliances = [];
  showAppliance: boolean = false;
  private checkboxFlag: string;
  private getAddStatusFlag: string;
  deleteStatusFlag: any;
  private localStorageDefault: object[] = [];
  displayErrors: any = [];
  errorMessage: string;
  errorMessage1: string;
  showmessage: boolean = false;
  applianceName: string;
  appliancesListTemp: any = [];
  showBackButton = false;
  showFinalInitiazeList: boolean = false;
  tabName: string = "";
  ipCheck: boolean = false;
  isValidIp  =  true;
  temp: number = 0;
  utcNames = ["(GMT-12:00) International Date Line West",
    "(GMT-11:00) Midway Island, Samoa",
    "(GMT-12:00) Tijuana, Baja California",
    "(GMT-12:00) Bogota, Lima, Quito, Rio Branco",
    "(GMT-12:00) Eastern Time",
    "(GMT+05:30) Chennai, Kolkata, Mumbai, New Delhi",
    "(GMT+07:00) Bangkok, Hanoi, Jakarta",
    "(GMT+05:30) Sri Jayawardenapura",
    "(GMT+08:00) Beijing, Chongqing, Hong Kong, Urumqi",
    "(GMT+12:00) Fiji, Kamchatka, Marshall Is.",
    "(GMT+12:00) Auckland, Wellington"
  ]



  constructor(
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _addApplianceService: AddApplianceService,
    private chRef: ChangeDetectorRef,
    private router: Router,
    private builder: FormBuilder, private modalService: BsModalService,
    private _route: ActivatedRoute, ) { }

  ngOnInit() {
    debugger;
    this.createForm();
    this.getTempdata();
    this._route.params.subscribe(params => {
      if (params['ip'] != null && params['ip'] != '') {
        this.ipCheck = true;
        this.form.get('ipAddress').patchValue(params['ip']);
      }
      else {
        this.ipCheck = false;
      }
    });
  }

  getRdirecttoListApp() {

    this.router.navigateByUrl("/listAppliance");
  }

  getTempdata() {
    this._addApplianceService.getAllTempAppliances().subscribe(
      res => {
        this.appliancesListTemp = res;

        console.log("hello", this.appliancesListTemp);

      },
      error => {
        console.log(error);
      },

    );

  }
  toggle() {
    this.showlist = true;
  }
  toggle1() {
    this.showlist = false;
  }

  createForm() {

    this.form = this.builder.group({
      applianceName: ['', Validators.required],
      authID: ['CaviumLiquidSA', Validators.required],
      serialNumber: ['', Validators.required],
      networkTimezone: [''],
      ipAddress: ['', Validators.required],
      gatewayIp: [''],
      subnetMask: [''],
      networkMode: [''],
      hostName: [''],
      ipmiIP: [''],
      userName: [''],
      userPassword: [''],
      cityName: ['', Validators.required],
      zoneId: ['', Validators.required],
      operationUsername: ['', Validators.required],
      operationPassword: ['', Validators.required],
    });
  }

  /* onSubmit function is to create users*/


  onSuccessOperation(res) {
    let response = JSON.parse(res['_body']);
    console.log(response);
    this.successMessage = response.responseMessage;
  }

  onErrorOperation(errResp) {
  }

  // create a form errors
  public formValidationFields = {
    "applianceName": '',
    "authID": '',
    "serialNumber": '',
    // "network": '',
    "ipAddress": '',
    // "gatewayIP": '',
    // "subnetMask": '',
    // "networkMode": '',
    // "hostname": '',
    "ipmiIP": '',
    "userName": '',
    "userPassword": '',
    "cityName": '',
    "zoneId": '',
    "operationUsername": '',
    "operationPassword": ''
  }

  isFieldValid(field: string) {

    if (this.form.get(field).touched) {
      this.formValidationFields = this._fieldErrorDisplayService.validateField(this.form, field, this.formValidationFields, "addAppliance")
    }
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  saveInitializeAppliance(isvalid, template: TemplateRef<any>) {
    debugger;
    if (isvalid) {
      let ipmiIP = this.form.get("ipmiIP").value;
      let cityName = this.form.get('cityName').value;
      let userName = this.form.get('userName').value;
      let userPassword = this.form.get('userPassword').value;

      if ((ipmiIP == null || ipmiIP == "") || (cityName == null || cityName == "") || (userName == null || userName == "") || (userPassword == null || userPassword == "")) {
        this.errorMessage = "Please fill the Advanced Section";
        this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
        return false;
      }


    } else {
      if (this.tabName == "Advanced") {
        if (this.form.get("ipmiIP").valid && this.form.get('userName').valid && this.form.get('userPassword').valid) {
          this.errorMessage = "";
          this.loading = false;
          this.errorMessage = "Please fill the General Section.";
          this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
          return false;
        } else {
          this.formValidationFields = this._fieldErrorDisplayService.validateForm(this.form, this.formValidationFields, "addAppliance", false);
        }
      } else {
        this.formValidationFields = this._fieldErrorDisplayService.validateForm(this.form, this.formValidationFields, "addAppliance", false);
      }
    }
  }

  submitApplication(isValid: boolean, template: TemplateRef<any>) {
    if(this.isValidIp==true && this.isValidAlphaNumeric==true && this.isValidAppName==true){
    debugger;
    this.loading = true;
    if (isValid) {
      let applianceName = this.form.get("applianceName").value;
      let serialNumber = this.form.get('serialNumber').value;
      let ipAddress = this.form.get('ipAddress').value;
      let cityName = this.form.get('cityName').value;
      let zoneId = this.form.get('zoneId').value;
      let operationUsername = this.form.get('operationUsername').value;
      let operationPassword = this.form.get('operationPassword').value;


      if ((applianceName == null || applianceName == "") || (serialNumber == null || serialNumber == "") || (ipAddress == null || ipAddress == "") || (cityName == null || cityName == "") || (zoneId == null || zoneId == "") ||
        (operationUsername == null || operationUsername == "") || (operationPassword == null || operationPassword == "")) {
        this.loading = false;
        this.errorMessage = "Please fill the General Section.";
        this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
        return false;
      }

      this._addApplianceService.verifyAppliances(this.form).subscribe((res) => {
        this.getValidateRes = res;
        this.loading = false;
        if (this.getValidateRes["code"] == "200") {
          this.appliancesListTemp.push(res);
          this.loading = false;
          let message = this.getValidateRes["message"] + ".Appliance is verified and  is available to add.";
          bootbox.dialog({
            message: message,
            buttons: {
              ok: {
                label: "Ok",
                className: 'btn btn-primary btn-flat',
              }
            }
          });

        }
        else if (this.getValidateRes["code"] == "409") {
          let message = this.getValidateRes["message"];
          bootbox.dialog({
            message: message,
            buttons: {

              ok: {
                label: "Ok",
                className: 'btn btn-primary btn-flat',

              }
            }
          });

        }

        this.errorMessage1 = res.errorMessage;
        if (this.errorMessage1 != null || this.errorMessage1 != '') {
          bootbox.dialog({
            message: this.errorMessage1,
            buttons: {
              ok: {
                label: "Ok",
                className: 'btn btn-primary btn-flat',
              }
            }
          });
        }
      },
        (err) => {
          this.loading = false;
          let message = "Sorry! Please try to add appliance again"
          bootbox.dialog({
            message: message,
            buttons: {
              ok: {
                label: "Ok",
                className: 'btn btn-primary btn-flat',

              }
            }
          });
        });
    }

    else {
      if (this.temp == 1) {
        this.modalRef.hide();
        this.temp = 2;
      }
      let applianceName = this.form.get("applianceName").value;
      let serialNumber = this.form.get('serialNumber').value;
      let ipAddress = this.form.get('ipAddress').value;
      let cityName = this.form.get('cityName').value;
      let zoneId = this.form.get('zoneId').value;
      let operationUsername = this.form.get('operationUsername').value;
      let operationPassword = this.form.get('operationPassword').value;


      if ((applianceName == null || applianceName == "") || (serialNumber == null || serialNumber == "") || (ipAddress == null || ipAddress == "") || (cityName == null || cityName == "") || (zoneId == null || zoneId == "") ||
        (operationUsername == null || operationUsername == "") || (operationPassword == null || operationPassword == "")) {
        this.loading = false;
        this.errorMessage = "Please fill the General Section";

        if (this.temp == 0) {
          this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
          this.temp = 1;
        }
        if (this.temp != 1) {
          this.temp = 0;
        }
        return false;

      }
      if (this.tabName == "Advanced") {

        let applianceName = this.form.get("applianceName").value;
        let serialNumber = this.form.get('serialNumber').value;
        let ipAddress = this.form.get('ipAddress').value;
        let cityName = this.form.get('cityName').value;
        let zoneId = this.form.get('zoneId').value;
        let operationUsername = this.form.get('operationUsername').value;
        let operationPassword = this.form.get('operationPassword').value;


        if ((applianceName == null || applianceName == "") || (serialNumber == null || serialNumber == "") || (ipAddress == null || ipAddress == "") || (cityName == null || cityName == "") || (zoneId == null || zoneId == "") ||
          (operationUsername == null || operationUsername == "") || (operationPassword == null || operationPassword == "")) {
          this.loading = false;
          this.errorMessage = "Please fill the General Section";
          this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
          return false;

        }
      }
    }
   }
  }


  onSelect(data: TabDirective): void {
    this.tabName = data.heading;
    if (this.tabName == "Advanced") {
      this.form.get('ipmiIP').setValidators(Validators.compose([Validators.required]));
      this.form.get('cityName').setValidators(Validators.compose([Validators.required]));
      this.form.get('userName').setValidators(Validators.compose([Validators.required]));
      this.form.get('userPassword').setValidators(Validators.compose([Validators.required]));
      this.form.get('ipmiIP').updateValueAndValidity();
      this.form.get('cityName').updateValueAndValidity();
      this.form.get('userName').updateValueAndValidity();
      this.form.get('userPassword').updateValueAndValidity();
    } else if (this.tabName == "General") {
      this.form.get('ipmiIP').setValidators(null);
      this.form.get('cityName').setValidators(null);
      this.form.get('userName').setValidators(null);
      this.form.get('userPassword').setValidators(null);
      this.form.get('ipmiIP').updateValueAndValidity();
      this.form.get('cityName').updateValueAndValidity();
      this.form.get('userName').updateValueAndValidity();
      this.form.get('userPassword').updateValueAndValidity();
    }
  }

  closeModal() {
    $("#myModal").modal("hide");

  }
  addApplianceToList() {


    debugger;
    this.loading = true;
    if (this.onPageApplianceSent.length > 0) {

      for (var i = 0; i < this.onPageApplianceSent.length; i++) {
        this.onPageApplianceSent[i]["applianceStatus"] = "Active";

        this.applianceSent.push(this.onPageApplianceSent[i]);

      }
    }


    this._addApplianceService.addAppliance(this.applianceSent).subscribe((res) => {
      console.log("UserGroup is created");

      this.getAddStatusFlag = res;
      this.loading = false;
      if (this.getAddStatusFlag["responseCode"] == "200") {


        let message = "Appliances added successfully.Please click OK to continue.";
        bootbox.dialog({
          message: message,
          buttons: {

            ok: {
              label: "Ok",
              className: 'btn btn-primary btn-flat',
              callback: () => this.getRdirecttoListApp()
            }
          }
        });
      }



    },
      (err) => {
        this.loading = false;
        console.log(JSON.stringify(err._body));
      });

  }

  deleteApplianceToList() {

    debugger;
    if (this.onPageApplianceSent.length > 0) {

      for (var i = 0; i < this.onPageApplianceSent.length; i++) {
        this.onPageApplianceSent[i]["applianceStatus"] = "Active";

        this.applianceSent.push(this.onPageApplianceSent[i]);

      }
    }


    this._addApplianceService.deleteAppliance(this.applianceSent).subscribe((res) => {
      console.log(res);

      this.deleteStatusFlag = JSON.parse(res['_body']);
      console.log(this.deleteStatusFlag);
      let displaymsg: string = '';
      this.deleteStatusFlag.forEach(element => {
       displaymsg = displaymsg + " " + "<b>" + element.responseMessage + "</b><br>";
      });
      bootbox.dialog({
        message: displaymsg,
        buttons: {

          ok: {
            label: "Ok",
            className: 'btn btn-primary btn-flat',
            callback: () => this.getRdirecttoListApp()
          }
        }
      });




    },
      (err) => {
        console.log(JSON.stringify(err._body));
      });

  }

  reloadPage() {
    location.reload();
  }

  addApplianceEvent(event, value) {

    debugger;
    if (event.target.checked) {
      if (this.appliancesListTemp.length > 0) {
        for (var i = 0; i < this.appliancesListTemp.length; i++) {
          if (this.appliancesListTemp[i]["applianceName"] == value) {
            //   delete this.appliancesListTemp[i]["applianceId"];
            this.onPageApplianceSent.push(this.appliancesListTemp[i]);


          }

        }

      }

    }
    else {
      for (var i = 0; i < this.onPageApplianceSent.length; i++) {

        if (this.onPageApplianceSent[i]["applianceName"] == value) {

          let index = i;
          this.onPageApplianceSent.splice(index, 1);
        }
      }
    }
  }

  validateIPaddress(inputText) {
    this.isValidIp = true;
    var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    // var form = document.getElementById('form1');
    // var x;
    // x = (<HTMLInputElement>document.getElementById("ip")).value;
    if (inputText != '') {
      if (inputText.match(ipformat)) {
        this.isValidIp = true;
      }
      else {
        this.isValidIp = false;
      }
    }
  }


  validatelogFailureCount(property) {
    if (property.value < 1 || property.value > 1000) {
      this.isValidZoneID = false;
      this.form.get("zoneId").setValue("");
    } else {
      this.isValidZoneID = true;
    }
  }

  isValidAppName = true;
  validateAppName(inputText) {
    this.isValidAppName = true;
    var alphanumericformat = /^[0-9a-zA-Z_]+$/;
    if (inputText != '') {
      if (inputText.match(alphanumericformat)) {
        this.isValidAppName = true;
      }
      else {
        this.isValidAppName = false;
      }
    }
  }

  isValidAlphaNumeric = true;
  validateAlphanumeric(inputText) {
    this.isValidAlphaNumeric = true;
    var alphanumericformat = /^[0-9a-zA-Z.-]+$/;
    if (inputText != '') {
      if (inputText.match(alphanumericformat)) {
        this.isValidAlphaNumeric = true;
      }
      else {
        this.isValidAlphaNumeric = false;
      }
    }
  }

  public OnlyNumericValues(e) {
    let input;
    if (e.metaKey || e.ctrlKey) {
      return true;
    }
    if (e.which === 32) {
      return false;
    }
    if (e.which === 0) {
      return true;
    }
    if (e.which < 33) {
      return true;
    }
    input = String.fromCharCode(e.which);
    return !!/[\d\s]/.test(input);
  }

}



