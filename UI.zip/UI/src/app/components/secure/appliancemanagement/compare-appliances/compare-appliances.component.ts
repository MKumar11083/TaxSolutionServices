import { Component, OnInit, Output, EventEmitter, Input, ViewChild } from '@angular/core';
import { ChartsModule, Color } from 'ng2-charts';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { Router } from '@angular/router';
import { ApplianceLoginComponent } from './../../appliancemanagement/appliance-login/appliance-login.component';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { ifError } from 'assert';
import { PartitionManagementService } from './../../../../services/partitionmanagement/partitionmanagement.service';
import { CreateClusterComponent } from './../../clustermanagement/create-cluster/create-cluster.component';

declare var $: any;
declare var jQuery: any;
declare var bootbox: any;

@Component({
  selector: 'app-compare-appliances',
  templateUrl: './compare-appliances.component.html',
  styleUrls: ['./compare-appliances.component.css']
})
export class CompareAppliancesComponent implements OnInit {
  @ViewChild('partitionLoginModal')
  partitionLoginModal: ModalDirective;
  @ViewChild('confirmModal')
  confirmModal: ModalDirective;
  @ViewChild('messageModal')
  messageModal: ModalDirective;
  @ViewChild('createClusterComponent')
  private createClusterComponent: CreateClusterComponent;
  selectedAppliances: any = [];
  selectedPartitions: any = [];
  allAppliances: any = [];
  loginForm: FormGroup;
  @Output() messageEvent = new EventEmitter<String>();
  unselectedAppliancesList: any = [];
  applianceList: any = [];
  partitionList: any = [];
  message: string;

  partitionMap: Map<string, Array<any>>;
  credentialsSavedPartitionList = [];
  nonCredentialSavedParitionList = [];
  partitionName: string;
  partitionCount = 1;
  totalpartitionCount = 0;
  isLastPartition: boolean = false;
  finalPartitionList = [];
  partitionOperation: string;
  isCreateClusterShow: boolean = false;
  errorMessage: string = '';
  errorMessage1: string = '';
  loading = false;
  loginCredentialsArray: any = [];
  checkLoginCredentialsResultArray: any = [];
  constructor(private _services: AppliancemanagementService,
    private _router: Router, private _formBuilder: FormBuilder,
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _partitionManagementService: PartitionManagementService
  ) {

  }
  // Doughnut
  public doughnutChartLabels: string[] = ['Used', 'Available'];
  public doughnutChartData: number[] = [];
  public doughnutChartType: string = 'doughnut';

  ngOnInit() {
    this._services.selectedAppliances.subscribe(appliances => this.selectedAppliances = appliances);
    this._services.allAppliancesList.subscribe(allAppliances => this.allAppliances = allAppliances);
    this.unselectedAppliancesList = this.allAppliances;
    this.createSelectedAppliancesList();
    this.createLoginForm();
    this.isCreateClusterShow = false;
  }

  createSelectedAppliancesList() {
    if (this.selectedAppliances != '') {
      this.selectedAppliances.forEach(obj => {
        let applianceObj = {
          "partitionList": []
        };
        let usedKeys: number;
        let availableKeys: number;
        let totalKeys: number;
        let usedContexts: number = 0;
        let availableContexts: number = 0;
        let totalContexts: number = 0;
        let usedAcclrDev: number = 0;
        let availableAcclrDev: number = 0;
        let totalAcclrDev: number = 0;
        applianceObj["appName"] = obj.applianceName;
        applianceObj["appId"] = obj.applianceId;
        applianceObj["status"] = obj.applianceStatus;
        applianceObj["ipAddress"] = obj.ipAddress;
        applianceObj["zoneId"] = obj.zoneId;

        //Keys
        if (obj.occupiedKeys != null) {
          usedKeys = obj.occupiedKeys;
        }

        if (obj.totalKeys != null) {
          totalKeys = obj.totalKeys;
        }

        if (usedKeys != null && totalKeys != null) {
          availableKeys = totalKeys - usedKeys;
        }

        //SSL Contexts
        if (obj.occupiedContexts != null) {
          usedContexts = obj.occupiedContexts;
        }

        if (obj.totalContexts != null) {
          totalContexts = obj.totalContexts;
        }

        if (usedContexts != null && totalContexts != null) {
          availableContexts = totalContexts - usedContexts;
        }

        //Acceleration device
        if (obj.occupiedAcclrDev != null) {
          usedAcclrDev = obj.occupiedAcclrDev;
        }

        if (obj.totalAcclrDevice != null) {
          totalAcclrDev = obj.totalAcclrDevice;
        }

        if (usedAcclrDev != null && totalAcclrDev != null) {
          availableAcclrDev = totalAcclrDev - usedAcclrDev;
        }

        let usedSize: number = 0;
        let availableSize: number = 0;
        let partitionSize: number = 0;
        let doughnutChartData: number[] = [];
        let doughnutChartData1: number[] = [];
        let doughnutChartData2: number[] = [];
        let partitionTotalKeys: number = 0;
        let partitionTotalSSLCtxt: number = 0;
        let partitionTotalAccDev: number = 0;
        if (obj.partitionDetailModels != null && obj.partitionDetailModels != "undefined") {
          obj.partitionDetailModels.forEach(partitionObj => {
            let partition = {};
            if (partitionObj.partitionName != null) {
              partition["name"] = partitionObj.partitionName;
            }
            if(partitionObj.partitionData!=null){
              if (partitionObj.partitionData.maxKeys != null) {
                partition["key"] = partitionObj.partitionData.maxKeys;
              }
              if (partitionObj.partitionData.totalSslCtxs != null) {
                partition["sslContexts"] = partitionObj.partitionData.totalSslCtxs;
              }
              if (partitionObj.partitionData.maxAcclrDevCount != null) {
                partition["acclrDev"] = partitionObj.partitionData.maxAcclrDevCount;
              }
              if (partitionObj.partitionData.nodeId != null) {
                partition['nodeID'] = partitionObj.partitionData.nodeId;
              }
              partitionTotalKeys = partitionTotalKeys + partitionObj.partitionData.maxKeys;
              partitionTotalSSLCtxt = partitionTotalSSLCtxt + partitionObj.partitionData.totalSslCtxs;
              partitionTotalAccDev = partitionTotalAccDev + partitionObj.partitionData.maxAcclrDevCount;
            }       
            if (partitionObj.partitionId != null) {
              partition["partitionID"] = partitionObj.partitionId;
            }
            if (obj.applianceId != null) {
              partition['applianceId'] = obj.applianceId;
            }
            if (partitionObj.partOfCluster != null) {
              partition['partOfCluster'] = partitionObj.partOfCluster;
            }
            if (partitionObj.networkStats.general.eth0.ip != null) {
              partition['ip'] = partitionObj.networkStats.general.eth0.ip;
            }
            if (partitionObj.networkStats.general.eth1.ip != null) {
              partition['ip1'] = partitionObj.networkStats.general.eth1.ip;
            }
           
            applianceObj.partitionList.push(partition);
          });
        }

        if (usedKeys != null) {
          doughnutChartData.push(usedKeys);
        }
        if (availableKeys != null) {
          doughnutChartData.push(availableKeys);
        }
        applianceObj["partitionTotalKeys"] = partitionTotalKeys;
        applianceObj["partitionTotalSSLCtxt"] = partitionTotalSSLCtxt;
        applianceObj["partitionTotalAccDev"] = partitionTotalAccDev;
        applianceObj["donutData"] = doughnutChartData;
        applianceObj["totalKeys"] = totalKeys;

        if (usedContexts != null) {
          doughnutChartData1.push(usedContexts);
        }
        if (availableContexts != null) {
          doughnutChartData1.push(availableContexts);
        }
        applianceObj["donutData1"] = doughnutChartData1;
        applianceObj["totalContexts"] = totalContexts;

        if (usedAcclrDev != null) {
          doughnutChartData2.push(usedAcclrDev);
        }
        if (availableAcclrDev != null) {
          doughnutChartData2.push(availableAcclrDev);
        }
        applianceObj["donutData2"] = doughnutChartData2;
        applianceObj["totalAcclrDev"] = totalAcclrDev;

        this.applianceList.push(applianceObj);
      });
    }
  }
  public chartOptions = {
    responsive: true,
    legend: {
      display: true,
      position: 'right',
      labels: {
        boxWidth: 10
      }
    }
  };

  public mycolors: Array<Color> = [
    {
      backgroundColor: [
        'rgba(244, 99, 132, 0.8)',
        'rgba(64, 162, 235, 0.8)',
        'rgba(255, 206, 86, 0.8)',
        'rgba(70, 192, 192, 0.8)',
        'rgba(287, 159, 64, 0.8)',
        'rgba(153, 102, 255, 0.8)',
        "#e28e41", "#3366cc", "#109618", "#dc3921"],
      hoverBackgroundColor: ['rgba(244, 99, 132, 0.8)',
        'rgba(64, 162, 235, 0.8)',
        'rgba(255, 206, 86, 0.8)',],
    }
  ];

  closeAppliance() {
    // this.applianceList = []
    // this.selectedAppliances = [];
    // this.messageEvent.emit("false");
    this._router.navigate(['/listAppliance']);
  }

  addMore() {
    let selectedIds = [];
    selectedIds = this.selectedAppliances.map(item => item.applianceId);
    this.unselectedAppliancesList = this.unselectedAppliancesList.filter(
      val => !selectedIds.includes(val.applianceId));
    $("#listappliances").modal("show");
  }

  closeModal() {
    $("#listappliances").modal("hide");
  }


  selectAppliances(event, applianceId) {
    if (event.checked) {
      this.allAppliances.find
        (appliance => {
          if (appliance.applianceId == applianceId) {
            this.selectedAppliances.push(appliance);
          }
        })
    } else {
      const index = this.selectedAppliances.findIndex(appliance => appliance.applianceId === applianceId);
      this.selectedAppliances.splice(index, 1);
    }
  }

  selectPartitionItems(event, applianceId, partitionId: string) {
    if (event.checked) {
      for (var i = 0; i < this.applianceList.length; i++) {
        if (this.applianceList[i].appId == applianceId) {
          let partitionList = this.applianceList[i].partitionList;
          partitionList.forEach(obj => {

            if (obj.partitionID == partitionId) {
              let partitionModal = {};
              partitionModal['applianceId'] = this.applianceList[i].appId;
              partitionModal['applianceName'] = this.applianceList[i].appName;
              partitionModal['ipAddress'] = this.applianceList[i].ipAddress;
              partitionModal['partitionId'] = obj.partitionID;
              partitionModal['partitionName'] = obj.name;
              partitionModal['partOfCluster'] = obj.partOfCluster;
              partitionModal['nodeId'] = obj.nodeID;
              partitionModal['remoteEth0Addr'] = obj.ip;
              partitionModal['remoteEth1Addr'] = obj.ip1;
              partitionModal['zoneId'] = this.applianceList[i].zoneId;
              this.selectedPartitions.push(partitionModal);
            }
          });
        }
      }
    } else {
      const index = this.selectedPartitions.findIndex(partition => partition.partitionId === partitionId);
      this.selectedPartitions.splice(index, 1);
    }
  }

  //Login Modal
  goToLoginModal(operation) {
    this.confirmModal.hide();
    // this.partitionLoginModal.show();
    this.clearData();

    this.partitionMap = new Map<string, Array<any>>();
    //this.partitionOperation = operation;
    // construct map based on applianceId for selected PartitionList
    this.selectedPartitions.forEach(partitionObj => {
      let tempMap: Array<any> = [];
      if (this.partitionMap.has(partitionObj['applianceId'])) {
        tempMap = this.partitionMap.get(partitionObj['applianceId']);
      }
      tempMap.push(partitionObj);
      this.partitionMap.set(partitionObj['applianceId'], tempMap);
    });
    //construct map code ends here
    // get all the applianceIds form the map and iterate each applianceId , to 
    // identity the credentialSaved or not 
    let applianceIds = Array.from(this.partitionMap.keys());
    applianceIds.forEach(appId => {
      if (this.partitionMap.has(appId)) {
        let partitionObj = this.partitionMap.get(appId)[0];
        if (partitionObj['credentialSaved']) {
          this.credentialsSavedPartitionList.push(partitionObj);
        } else {
          this.nonCredentialSavedParitionList.push(partitionObj);
        }
        // this.credentialsSavedPartitionList.push(partitionObj);
      }
    });
    //  check the length of non credentialsaved Partition List to show the login pop.
    // if length is 0 , then show the confirm modal,whether to continue the selected Operation or not.
    if (this.nonCredentialSavedParitionList.length > 0) {
      this.partitionName = this.nonCredentialSavedParitionList[this.partitionCount - 1]['applianceName'];
      this.totalpartitionCount = this.nonCredentialSavedParitionList.length;
      if (this.partitionCount == this.totalpartitionCount) {
        this.isLastPartition = true;
      }
      this.partitionLoginModal.show();
    } else {
      this.goToCreateCluster();
    }

  }

  goToNextPartition() {
    // let applianceId = this.nonCredentialSavedParitionList[this.partitionCount - 1]['applianceId'];
    // this.createListOfPartitions(applianceId);
    let applianceObj = this.nonCredentialSavedParitionList[this.partitionCount - 1];
    this.createListOfPartitions(applianceObj, "login");
    let loginDetailsModal = {};
    loginDetailsModal['applianceId'] = applianceObj.applianceId;
    loginDetailsModal['applianceName'] = applianceObj.applianceName;
    loginDetailsModal['ipAddress'] = applianceObj.ipAddress;
    loginDetailsModal['operationUsername'] = this.loginForm.get('username').value;
    loginDetailsModal['operationPassword'] = this.loginForm.get('password').value;
    this.loginCredentialsArray.push(loginDetailsModal);
    if (this.partitionCount < this.nonCredentialSavedParitionList.length) {
      this.partitionName = this.nonCredentialSavedParitionList[this.partitionCount]['applianceName'];
      this.partitionCount++;
      if (this.partitionCount == this.totalpartitionCount) {
        this.isLastPartition = true;
      }
    } else {
      this.partitionLoginModal.hide();
      //this.goToCreateCluster();
      this.checkAppliancesCredentials();
    }
    this.loginForm.reset();
  }

  checkAppliancesCredentials() {
    this.loading = true;
    this.message = '';
    this.errorMessage = '';
    this.errorMessage1 = '';
    this.checkLoginCredentialsResultArray = [];
    this._services.checkAppliancesCredentials(this.loginCredentialsArray).subscribe(
      (response) => {
        let isSuccess: boolean = true;
        this.loading = false;
        response.forEach(obj => {
          this.loginCredentialsArray = [];
          if (obj.code != "200") {

            this.checkLoginCredentialsResultArray.push(obj);
            isSuccess = false;
          }

        });
        if (isSuccess) {
          this.partitionLoginModal.hide();
          this.goToCreateCluster();

        } else {
          this.finalPartitionList = [];
          //this.selectedPartitions = [];
          this.messageModal.show();
        }
      },
      (error) => {
        console.log(error);
      })
  }
  goToCreateCluster() {
    this.confirmModal.hide();
    let count: number = 0;
    this.credentialsSavedPartitionList.forEach(partitionObj => {
      this.createListOfPartitions(partitionObj.applianceId, '');
    });
    this.isCreateClusterShow = true;
    this.createClusterComponent.performSelectedOperation(this.finalPartitionList, this.partitionOperation);

  }
  // create the list of partitions .
  createListOfPartitions(applianceObj, value) {
    if (this.partitionMap.has(applianceObj.applianceId)) {
      let partitionList = this.partitionMap.get(applianceObj.applianceId);
      partitionList.forEach(obj => {
        if (value == "login") {
          obj['operationPerformedUserName'] = this.loginForm.get('username').value;
          obj['operationPerformedPassword'] = this.loginForm.get('password').value;
        } else {
          obj['operationPerformedUserName'] = applianceObj.operationPerformedUserName;
          obj['operationPerformedPassword'] = applianceObj.operationPerformedPassword;
        }
        this.finalPartitionList.push(obj);
      });
    }
  }


  createLoginForm() {
    this.loginForm = this._formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
    });
  }

  public formValidationFields1 = {
    "username": '',
    "password": ''

  }
  isFieldValid1(field: string) {
    if (this.loginForm.get(field).touched) {
      this.formValidationFields1 = this._fieldErrorDisplayService.validateField(this.loginForm, field, this.formValidationFields1, "login")
    }
    return !this.loginForm.get(field).valid && this.loginForm.get(field).touched;
  }

  displayFieldCss1(field: string) {
    return {
      'has-error': this.isFieldValid1(field),
      'has-feedback': this.isFieldValid1(field)
    };
  }

  closeLoginModal() {
    console.log("Close ----> Partition Login Modal");
    this.partitionLoginModal.hide();
    this.clearData();
  }

  //Confirm Modal

  partOfClusterPartitions: string;
  isPartOfCluster = false;
  goToConfirmModal() {
    this.errorMessage = '';
    this.errorMessage1 = '';
    this.partOfClusterPartitions = '';
    this.isPartOfCluster = false;
    if (this.selectedPartitions.length >= 2) {
      if (this.selectedPartitions.length <= 32) {
        this.selectedPartitions.forEach(obj => {
          if (obj.partOfCluster) {
            if (this.partOfClusterPartitions != '') {
              this.partOfClusterPartitions = this.partOfClusterPartitions + "," + obj.partitionName;
            } else {
              this.partOfClusterPartitions = obj.partitionName;
            }
            this.isPartOfCluster = true;
          }
        });

        if (!this.isPartOfCluster) {
          let modal = {
            "clusterPartitionsRelationships": this.selectedPartitions
          }
          this._partitionManagementService.getComparePartitionsDetails(modal).subscribe(
            res => {
              this.errorMessage = '';
              this.errorMessage1 = '';
              this.selectedPartitions = [];
              let detailsList = res.clusterPartitionsRelationships;

              if (res.code == '409') {
                this.errorMessage1 = res.errorMessage;
              }
              else if (res.code == '415') {
                this.errorMessage = res.errorMessage;
              }
              this.clearData();

              detailsList.forEach(obj => {
                this.selectedPartitions.push(obj);
                if (this.isPartOfCluster || (this.errorMessage != null && this.errorMessage != '')
                  || (this.errorMessage1 != null && this.errorMessage1 != '')) {
                  this.confirmModal.show();
                } else {
                  this.goToLoginModal(this.selectedPartitions);
                }
              });
            },
            error => {
              console.log(error);
            },
          )
        } else {
          this.confirmModal.show();
        }

      }
      else {
        this.partitionLoginModal.show();
        this.message = "Sorry!Operation cannot be performed on more than 32 partitions";
      }
    }
    else {
      this.partitionLoginModal.show();
      this.message = "Please select alteast two partition to perform the activity!";
    }
  }

  closeConfirmModal() {
    console.log("Close ----> Confirm  Modal");
    this.confirmModal.hide();
    this.clearData();
  }

  clearData() {
    this.loginForm.reset();
    this.partitionOperation = '';
    this.nonCredentialSavedParitionList = [];
    this.credentialsSavedPartitionList = []
    this.partitionCount = 1;
    this.totalpartitionCount = 0;
    this.partitionName = '';
    this.message = '';
    this.isLastPartition = false;
    this.finalPartitionList = [];
  }

  showAppliances() {
    this.message = '';
    this.checkValidationsForAppliances();
  }

  checkValidationsForAppliances() {
    if (this.selectedAppliances.length > 6) {
      this.message = "Maximum appliances to compare is 6.";
    } else {
      this.applianceList = [];
      this.createSelectedAppliancesList();
      this.closeModal();
    }
  }

  removeAppliance(applianceId) {
    let selectedIds = [];
    selectedIds.push(applianceId);
    if (this.selectedAppliances.length > 2) {
      this.selectedAppliances = this.selectedAppliances.filter(
        val => !selectedIds.includes(val.applianceId));
      console.log(this.selectedAppliances);
      this.showAppliances();
    }
  }


  showCreateCluster(isShow: boolean) {
    this.isCreateClusterShow = isShow
  }

  hideCluster(){
    this.isCreateClusterShow = false;
  }
}
