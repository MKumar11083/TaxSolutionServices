
import { Component, OnInit,ViewChild,OnDestroy } from '@angular/core';
import { BreadcrumbService } from './../../../../services/common/breadcrumb.service';
import { UserGroupManagementService } from './../../../../services/common/user-group-management.service';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, FormControl, FormArray } from '@angular/forms';
import { AnonymousSubscription } from "rxjs/Subscription";
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { Router } from '@angular/router';
import { ModalDirective } from 'ngx-bootstrap/modal';
@Component({
  selector: 'app-modifygroup',
  templateUrl: './modifygroup.component.html',
  styleUrls: ['./modifygroup.component.css']
})
export class ModifygroupComponent implements OnInit,OnDestroy {
  @ViewChild('selecterror')
  selecterror: ModalDirective;

  form: FormGroup;
  applianceList: any = [];
  selectedApplianceList = [];
  unSelectedApplianceList = [];
  UserGroupId: string;
  displayErrors: any = [];
  successMessage: any = [];
  modifyGroupSubsc : AnonymousSubscription;
  check:number=0;
  uncheck:number=0;
  message1: string;

  constructor(
    // private _breadcrumbService: BreadcrumbService,
    private _userGroupManagementService: UserGroupManagementService, 
    private formBuilder: FormBuilder,
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private router: Router
  ) { }

  ngOnInit() {
    // this._breadcrumbService.getBreadCrumbDetails("modify-groups");
    this.modifyForm();
    //this.getApplianceDetails();
    this.applianceList=[];
    let UserGroupId = sessionStorage.getItem("selectedGroupList");
    this.getModifiedApplianceDetails(UserGroupId);
  }

  modifyForm() {
    this.form = this.formBuilder.group({
      id :'',
      roleName:['', Validators.required],
      listApplianceIds: '',
      defaultGroupApplianceIds : ''
    });
  }

  public formValidationFields = {
    "roleName": '',
    
  }
  isFieldValid(field: string) {
    if (this.form.get(field).touched) {
      this.formValidationFields = this._fieldErrorDisplayService.validateField(this.form, field, this.formValidationFields, "modifygroup")
    }
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }
  getModifiedApplianceDetails(UserGroupId) {
    this._userGroupManagementService.getuserGroupById(UserGroupId).subscribe(
      (res) => {
        if (res.objUserGroupModel != null) {
          if (res.objUserGroupModel.roleName != null) {
            this.form.patchValue({id: res.objUserGroupModel.id})
            this.form.patchValue({ roleName: res.objUserGroupModel.roleName });
          }
          if(res.objUserGroupModel.listDesignationApplianceModel!=null){
            res.objUserGroupModel.listDesignationApplianceModel.forEach(appliance => {
              this.selectedApplianceList.push(appliance.objApplianceDetailModel.applianceId);
              let obj = {
                "IsSelected" : true,
                "applianceId": appliance.objApplianceDetailModel.applianceId,
                "applianceName": appliance.objApplianceDetailModel.applianceName,
                "applianceStatus": appliance.objApplianceDetailModel.applianceStatus,
              }
    
              this.applianceList.push(obj);
            });
          }
        }
        if(res.listDesignationApplianceModel!=null){
          res.listDesignationApplianceModel.forEach(appliance => {
            this.unSelectedApplianceList.push(appliance.objApplianceDetailModel.applianceId);
            let obj = {
              "IsSelected" : false ,
              "applianceId": appliance.objApplianceDetailModel.applianceId,
              "applianceName": appliance.objApplianceDetailModel.applianceName,
              "applianceStatus": appliance.objApplianceDetailModel.applianceStatus,
            }
  
            this.applianceList.push(obj);
          });
        }
      },
      (err) => {
        this.onErrorOperation(err);
      }
    );

  }

  // getApplianceDetails() {
  //   this._userGroupManagementService.getlistofApplicance().subscribe(
  //     (res) => {
  //       res.forEach(appliance => {
  //         this.unSelectedApplianceList.push(appliance.objApplianceDetailModel.applianceId);
  //         let obj = {
  //           "applianceId": appliance.objApplianceDetailModel.applianceId,
  //           "applianceName": appliance.objApplianceDetailModel.applianceName,
  //           "applianceStatus": appliance.objApplianceDetailModel.applianceStatus,
  //         }

 //         this.applianceList.push(obj);
  //       });
  //     },
  //     (err) => {
  //       console.log(err);
  //     }
  //   );
  // }

  checkedItems(event, value) {
    if (event.target.checked) {
      event.currentTarget.style.visibility = "visible";
       let index = this.unSelectedApplianceList.indexOf(value);
       this.unSelectedApplianceList.splice(index,1);
      this.selectedApplianceList.push(value);
      this.check=1;
    } else {
      event.currentTarget.style.visibility = "";
      let index = this.selectedApplianceList.indexOf(value);
      this.selectedApplianceList.splice(index,1);
       this.unSelectedApplianceList.push(value);
       this.uncheck=1;
    }
  }

  onSubmit() {
    this.message1="";
    if((this.check==1)||(this.uncheck==1)){

    this.form.get('listApplianceIds').setValue(this.selectedApplianceList);
    this.form.get('defaultGroupApplianceIds').setValue(this.unSelectedApplianceList);
    this.modifyGroupSubsc = this._userGroupManagementService.modifyGroup(this.form.value).subscribe(
      (res) => {
        this.unSelectedApplianceList = [];
        this.selectedApplianceList =[];
        this.onSuccessOperation(res);
      },
      (err) => {
        this.unSelectedApplianceList = [];
        this.selectedApplianceList =[];
        this.onErrorOperation(err);
      }
    );
  }else{
    this.message1="No modifications are made to the user group. Please make any modification to continue";
      this.selecterror.show();
  }

  }

  onSuccessOperation(response) {
    this.successMessage = [];
    this.displayErrors = [];
    let res = response.json();
    if (res.responseCode == "200") {
      //this.successMessage.push(res.responseMessage);
      sessionStorage.setItem("msg",res.responseMessage);
      this.router.navigateByUrl("/managegrouplist");
    } else if (res.responseCode == "204" || res.responseCode == "500") {
      this.displayErrors.push(res.responseMessage);
    } else {
      this.displayErrors.push(res.responseMessage);
    }
    this.scrollToTop();

  }
  
  scrollToTop(){
    window.scrollTo(0, 0);
  }
  onErrorOperation(error) {
    this.scrollToTop();
    console.log('OnError' + JSON.stringify(error));
    //this.displayErrors = this._I18nService.getI18NMessagesForError(error, "", "");
    console.log('errorMessages -->' + JSON.stringify(this.displayErrors));
  }

  public ngOnDestroy(): void {
    if (this.modifyGroupSubsc) {
      this.modifyGroupSubsc.unsubscribe();
    }
       
  }
}



