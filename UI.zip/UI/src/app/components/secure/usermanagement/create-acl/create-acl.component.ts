import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-acl',
  templateUrl: './create-acl.component.html',
  styleUrls: ['./create-acl.component.css']
})
export class CreateAclComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
