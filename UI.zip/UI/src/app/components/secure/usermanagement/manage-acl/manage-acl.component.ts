import { Component, OnInit } from '@angular/core';
import { BreadcrumbService } from './../../../../services/common/breadcrumb.service';

@Component({
  selector: 'app-manage-acl',
  templateUrl: './manage-acl.component.html',
  styleUrls: ['./manage-acl.component.css']
})
export class ManageAclComponent implements OnInit {

  constructor( private _breadcrumbService:BreadcrumbService,) { }

  ngOnInit() {
    this._breadcrumbService.getBreadCrumbDetails("manage-ACL");
  }

}
