import { Component, OnInit, OnDestroy } from '@angular/core';
import { BreadcrumbService } from './../../../../services/common/breadcrumb.service';
import { UserManagementService } from './../../../../services/usermanagement.service';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, FormControl } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { AnonymousSubscription } from "rxjs/Subscription";
import { Router } from '@angular/router';
declare var $: any;
declare var bootbox: any;
@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.css']
})
export class CreateUserComponent implements OnInit, OnDestroy {

  form: FormGroup;
  list : any = [];
  aclList: any;
  groupList: any;
  dropdownList: any = [];
  successMessage: any = [];
  errorMessages: any = [];
  selectplaceholder = "Select the Options";
  canClearSelect: boolean = true;
  createUserSubsc: AnonymousSubscription;
  getGroupAndACLSubsc: AnonymousSubscription;
  displayUserGroup: boolean = false;
  tempAclList: any = [];
  constructor(
    // private _breadcrumbService: BreadcrumbService,
    private _userManagementService: UserManagementService,
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private builder: FormBuilder,
    private router: Router) { }

  ngOnInit() {
    // this._breadcrumbService.getBreadCrumbDetails("create-users");
    this.getdropdownList();
    this.createForm();
  }
  emailPattern = "^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$";
  createForm() {

    this.form = this.builder.group({
      userName: ['', Validators.required],
      password: ['', Validators.required],
      confirmPassword: ['', Validators.required],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      emailId: ['', [Validators.required, Validators.email]],
      phoneNumber: [null, Validators.required],
      userGroupId: ['', Validators.required],
      userACLId: ['', Validators.required],
      status: "ACTIVE",
      temporaryPassword: "Y"
    });
  }

  /* onSubmit function is to create users*/
  onSubmit(isValid: boolean) {
    console.log("onSubmit..");
    this.errorMessages = [];
    if (this.groupList.length <= 1) {
      let usergroup1 = this.groupList[0]["id"];
      this.form.get('userGroupId').setValue(usergroup1);
    }
    if (this.form.valid) {
      if (this.checkIfMatchingPasswords()) {
        if (this.checkPasswordlength()) {
         if (this.isValidUserName == true && this.isValidFirstName == true && this.isValidLastName == true){
          if (this.phonevalid == true) {
            this.createUserSubsc = this._userManagementService.createUser(this.form.value).subscribe(
              data => this.onSuccessOperation(data),
              err => this.onErrorOperation(err)
            );
          }
          else {
            this.errorMessages.push("You have entered an invalid Phone number");
          }
         }else{
          this.errorMessages.push("You have entered an invalid name");
         }
        }
        else {
          this.errorMessages.push("password length should be between 8 and 16");
        }

      }
      else {
        this.errorMessages.push("Password and Confirm Password should be same");
      }
    } else {
      this.formValidationFields = this._fieldErrorDisplayService.validateForm(this.form, this.formValidationFields, "createuser", false)
    }
  }

  checkPasswordlength() {
    let newPassword = this.form.get("password").value;
    if (newPassword.length > 7 && newPassword.length < 17) {
      return true;
    }
    else {
      return false;
    }
  }

  checkIfMatchingPasswords() {
    let newPassword = this.form.get("password").value;
    let ConfirmPassword = this.form.get("confirmPassword").value;
    if (newPassword !== ConfirmPassword) {
      return false;
    }
    else {
      return true;
    }
  }
  onSuccessOperation(response) {
    this.successMessage = [];
    this.errorMessages = [];
    let res = response;
    if (res.responseCode == "200") {
      //this.successMessage.push(res.responseMessage);
      sessionStorage.setItem("msg", res.responseMessage);
      this.router.navigateByUrl("/manageuserlist");
    } else if (res.responseCode == "409" || res.responseCode == "-230") {
      this.errorMessages.push(res.responseMessage);
    } else if (res.responseCode == "500") {
      this.errorMessages.push(res.responseMessage);
    } else {
      this.errorMessages.push(res.responseMessage);
    }
  }
  onErrorOperation(errResp) {

  }
  reset() {
    this.form.reset();
    this.successMessage = [];
    this.errorMessages = [];
  }

  getdropdownList() {
    this.tempAclList = [];
    this.aclList = [];
    this.groupList = [];
    this.getGroupAndACLSubsc = this._userManagementService.getdropdownList().subscribe(
      res => {
        this.tempAclList = res.listUserACLDetailsModel;
        this.aclList = res.listUserACLDetailsModel;
        this.groupList = res.listUserGroupModel;
        if (this.groupList.length > 1) {
          this.displayUserGroup = true;

        } else {
          this.form.get('userGroupId').setValidators(null);
        }
      },
      error => {
        console.log(error);
      },

    )
  }
  // create a form errors
  public formValidationFields = {
    "userName": '',
    "password": '',
    "firstName": '',
    "lastName": '',
    "emailId": '',
    "phoneNumber": '',
    "userGroupId": '',
    "userACLId": '',
    "status": '',
    "temporaryPassword": '',
    "confirmPassword": ''
  }

  isFieldValid(field: string) {
    if (this.form.get(field).touched) {
      this.formValidationFields = this._fieldErrorDisplayService.validateField(this.form, field, this.formValidationFields, "createuser")
    }
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }
  // destroy method 
  public ngOnDestroy(): void {
    if (this.createUserSubsc) {
      this.createUserSubsc.unsubscribe();
    }
    if (this.getGroupAndACLSubsc) {
      this.getGroupAndACLSubsc.unsubscribe();
    }

  }
  closeMessage() {
    this.successMessage = [];
    this.errorMessages = [];
  }

  // phonevalid=true;
  // ValidatephoneNumber() {
  //   this.phonevalid = true;
  //   var form = document.getElementById('form1');
  //   var x;
  //   x = (<HTMLInputElement>document.getElementById("Phone")).value;
  //   if (x.match(/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/)) {
  //     return true;
  //   }
  //   else {
  //     this.phonevalid = 0;
  //   }
  // }

  isValidUserName = true;
  ValidateName(inputText) {
    this.isValidUserName = true;
    var nameformat = /^[a-zA-Z ]*$/;
    if (inputText != '') {
      if (inputText.match(nameformat)) {
        this.isValidUserName = true;
      }
      else {
        this.isValidUserName = false;
      }
    }
  }

  isValidFirstName = true;
  ValidateName1(inputText) {
    this.isValidFirstName = true;
    var nameformat = /^[a-zA-Z ]*$/;
    if (inputText != '') {
      if (inputText.match(nameformat)) {
        this.isValidFirstName = true;
      }
      else {
        this.isValidFirstName = false;
      }
    }
  }

  isValidLastName = true;
  ValidateName2(inputText) {
    this.isValidLastName = true;
    var nameformat = /^[a-zA-Z ]*$/;
    if (inputText != '') {
      if (inputText.match(nameformat)) {
        this.isValidLastName = true;
      }
      else {
        this.isValidLastName = false;
      }
    }
  }

  phonevalid = true;
  ValidatephoneNumber(inputText) {
    this.phonevalid = true;
    var phonenoformat = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
    if (inputText != '') {
      if (inputText.match(phonenoformat)) {
        this.phonevalid = true;
      }
      else {
        this.phonevalid = false;
      }
    }
  }

  getACLDetails(args) {
    let value = args.target.options[args.target.selectedIndex].text;
    this.aclList = [];
    this.tempAclList.forEach(element => {
      if (value === "DefaultUserGroup") {
        var aclName = element.aclName;
        if (aclName.trim() != "GroupAdmin") {
          this.aclList.push(element);
        }
      } else {
        var aclName = element.aclName;
        if (aclName.trim() == "GroupAdmin") {
          this.aclList.push(element);
        }
      }
    });
  }

  // keyPress(event: any) {
  //   if (event.charCode !== 0) {
  //     const pattern = /[0-9\+\-\ ]/;
  //     const inputChar = String.fromCharCode(event.charCode);

  //     if (!pattern.test(inputChar)) {
  //       // invalid character, prevent input
  //       event.preventDefault();
  //     }
  //   }
  // }
}

export function setOption(value, label) {
  let option = new Option();
  option.value = value;
  option.label = label;
  return option;
} 
