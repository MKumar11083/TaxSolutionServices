export const HEADER_STYLE = `
.data-table-header {
    min-height: 25px;
    margin-bottom: 10px;
}
.title {
    display: inline-block;
    margin: 5px 0 0 5px;
}
.button-panel {
    float: right;
}
.button-panel button {
    outline: none !important;
}
.button-panel  .pagi-btn-default {
    color: #333;
    background-color: #fff;
    border-color: #ccc;
    min-width: auto;
}
.pagi-btn-default.disabled, .pagi-btn-default[disabled], .pagi-btn-default.disabled:hover, .pagi-btn-default[disabled]:hover, .pagi-btn-default.disabled:focus, .pagi-btn-default[disabled]:focus, .pagi-btn-default.disabled:active, .pagi-btn-default[disabled]:active, .pagi-btn-default.disabled.active, .pagi-btn-default[disabled].active{
    color: #333;
    background-color: #d4d4d4;
    border-color: #8c8c8c;
}

.column-selector-wrapper {
    position: relative;
}
.column-selector-box {
    box-shadow: 0 0 10px lightgray;
    width: 150px;
    padding: 10px;
    position: absolute;
    right: 0;
    top: 1px;
    z-index: 1060;
}
.column-selector-box .checkbox {
    margin-bottom: 4px;
}
.column-selector-fixed-column {
    font-style: italic;
}
`;