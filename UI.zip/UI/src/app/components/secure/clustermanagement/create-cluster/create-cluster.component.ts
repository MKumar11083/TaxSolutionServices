import { Component, OnInit, Output, EventEmitter, TemplateRef, ViewChild } from '@angular/core';
import { PartitionManagementService } from './../../../../services/partitionmanagement/partitionmanagement.service';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, FormControl } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { element } from 'protractor';
import { ModalDirective } from 'ngx-bootstrap/modal';


declare var bootbox: any;

@Component({
  selector: 'app-create-cluster',
  templateUrl: './create-cluster.component.html',
  styleUrls: ['./create-cluster.component.css']
})
export class CreateClusterComponent implements OnInit {
  @ViewChild('confirmModal')
  confirmModal: ModalDirective;
  tempPartitionList: any = [];
  selectedPartitions: any = [];
  clusterName: string = '';
  form: FormGroup;
  message: string = '';
  errorMessage: string = '';
  loading: boolean = false;
  @Output() backOperation =new EventEmitter();
  constructor(private _services: PartitionManagementService,
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private builder: FormBuilder) { }

  ngOnInit() {
    this.createForm();
  }
  partitionListLength: number = 0;
  performSelectedOperation(partitionList, partitionOperation) {
    this.tempPartitionList = partitionList;
    this.partitionListLength = this.tempPartitionList.length;
    console.log(this.tempPartitionList);
  }

  createForm() {

    this.form = this.builder.group({
      clusterName: ['', Validators.required],

    });
  }

  public formValidationFields = {
    "clusterName": '',
  }

  isFieldValid(field: string) {

    if (this.form.get(field).touched) {
      this.formValidationFields = this._fieldErrorDisplayService.validateField(this.form, field, this.formValidationFields, "createCluster")
    }
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  onSubmit(isValid) {
    if (!isValid) {
      this.formValidationFields = this._fieldErrorDisplayService.validateForm(this.form, this.formValidationFields, "createCluster", false);
    }
    else {
      if (this.partitionListLength == this.tempPartitionList.length) {
        let clusterModal = {
          'clusterName': '',
          'clusterPartitionsRelationships': []
        };
        // let clusterPartitionRelationshipArray= [];
        // this.tempPartitionList.forEach(cluster => {
        //   // let ip = cluster.partitionDetailModel.networkStats.general.eth0.ip;
        //   // let ip1 = cluster.partitionDetailModel.networkStats.general.eth1.ip;
        //   // cluster['remoteEth0Addr']=ip;
        //   // cluster['remoteEth1Addr']=ip1;
        //   clusterPartitionRelationshipArray.push(cluster);
        // });
        clusterModal['clusterName'] = this.form.get('clusterName').value;
        clusterModal['clusterPartitionsRelationships'] = this.tempPartitionList;
        this.loading = true;
        this._services.createCluster(clusterModal).subscribe((res) => {
          this.loading = false;
          this.message = '';
          this.errorMessage = '';
          this.confirmModal.show();
          if (res.code == "200") {
            this.message = res.message;
          } else {
            this.errorMessage = res.errorMessage;
          }
        })
      }
      else {
        let clusterModal = {
          'clusterName': '',
          'clusterPartitionsRelationships': []
        };
        // let clusterPartitionRelationshipArray= [];
        // this.tempPartitionList.forEach(cluster => {
        //   // let ip = cluster.partitionDetailModel.networkStats.general.eth0.ip;
        //   // let ip1 = cluster.partitionDetailModel.networkStats.general.eth1.ip;
        //   // cluster['remoteEth0Addr']=ip;
        //   // cluster['remoteEth1Addr']=ip1;
        //   clusterPartitionRelationshipArray.push(cluster);
        // });
        clusterModal['clusterName'] = this.form.get('clusterName').value;
        clusterModal['clusterPartitionsRelationships'] = this.tempPartitionList;
        this.loading = true;
        this._services.comparePartitionsAndCreateCluster(clusterModal).subscribe((res) => {
          this.loading = false;
          this.message = '';
          this.errorMessage = '';
          this.confirmModal.show();
          if (res.code == "200") {
            this.message = res.message;
          } else {
            this.errorMessage = res.errorMessage;
          }
        })
      }

    }
  }
  clearData() {
    this.form.reset();
  }

  removeAppliance(partitionId) {
    debugger;
    let selectedIds = [];
    selectedIds.push(partitionId);
    this.tempPartitionList = this.tempPartitionList.filter(
      val => !selectedIds.includes(val.partitionId));
    console.log(this.tempPartitionList);

    // this._services.comparePartitionsAndCreateCluster(this.form).subscribe((res) => {
    //   this.tempPartitionList.push(res);
    //   this.errorMessage='';
    //   this.errorMessage = res.errorMessage;
    //   if(this.errorMessage!=null && this.errorMessage!='' ){
    //   this.confirmModal.show();
    //   }
    // })
  }

  closeConfirmModal() {
    console.log("Close ----> Confirm  Modal");
    this.confirmModal.hide();
    this.clearData();
  }

  goBack(){
    this.backOperation.emit();
  }
}
