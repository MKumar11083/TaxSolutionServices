import { Component, OnInit, ViewChild } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { ActivatedRoute } from '@angular/router';
import { ClustermanagementService } from './../../../../services/clustermanagement.service';
import { PartitionManagementService } from './../../../../services/partitionmanagement/partitionmanagement.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { CreateClusterComponent } from './../../clustermanagement/create-cluster/create-cluster.component';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import '../../../../../../src/assets/plugins/clusterd3.js';
import '../../../../../../src/assets/plugins/clusterd3graph.js';
import { Router } from '@angular/router';
declare var d3plus;
@Component({
  selector: 'app-cluster-info',
  templateUrl: './cluster-info.component.html',
  styleUrls: ['./cluster-info.component.css']
})
export class ClusterInfoComponent implements OnInit {
  @ViewChild('addNodeModal')
  addNodeModal: ModalDirective;
  @ViewChild('removeNodeModal')
  removeNodeModal: ModalDirective;
  @ViewChild('partitionLoginModal')
  partitionLoginModal: ModalDirective;
  @ViewChild('messageModal')
  messageModal: ModalDirective;

  @ViewChild('createClusterComponent')
  private createClusterComponent: CreateClusterComponent;

  clusterId: string;
  clusterName: string;
  clusterDetails: any = {
    "clusterPartitionsRelationships": []
  };
  clusterPartitionsRelationships: any = [];
  partitionList: any = [];
  partitionListData: any = [];
  applianceList: any = [];
  addNodePartitions: any = [];
  selectedPartitions: any = [];
  errorMessage: string = '';
  errorMessage1: string = '';
  message: string;
  partitionMap: Map<string, Array<any>>;
  credentialsSavedPartitionList = [];
  nonCredentialSavedParitionList = [];
  partitionName: string;
  partitionCount = 1;
  totalpartitionCount = 0;
  isLastPartition: boolean = false;
  loginForm: FormGroup;
  finalPartitionList = [];
  partitionOperation: string;
  isCreateClusterShow: boolean = false;
  saveCredentialsToSessionArray: any = [];
  loginCredentialsArray: any = [];
  loading: boolean = false;
  checkLoginCredentialsResultArray: any = [];
  partitionDetailsTableList: any = [];
  selectedPartitionsIds: any = [];
  removeCheck: boolean = false;
  partitionNodeList: any = [];
  constructor(private _route: ActivatedRoute,
    private _service: ClustermanagementService,
    private _appService: AppliancemanagementService,
    private _partitionManagementService: PartitionManagementService,
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _formBuilder: FormBuilder, private _router: Router, ) { }

  ngOnInit() {
    this.createLoginForm();
    this.clusterDetails = {};
    this.clusterId = "";
    this._route.params.subscribe(params => {
      this.clusterId = params['clusterId'];
      this.clusterName = params['clusterName'];
    });

    let modal = {};
    modal["clusterId"] = this.clusterId;
    this._service.getClusterDetails(modal).subscribe(
      res => {
        this.setDataFromResponse(res);
      },
      error => {
        console.log(error);
      },
    );

    //this.isCreateClusterShow = false;
  }

  setDataFromResponse(response) {
    let clusterData = response;
    console.log(clusterData);
    this.clusterDetails['clusterId'] = clusterData.clusterId;
    this.clusterDetails['clusterName'] = clusterData.clusterName;
    this.clusterDetails['clusterVersion'] = clusterData.clusterVersion;
    this.clusterDetails['groupId'] = clusterData.groupId;
    if (clusterData.clusterPartitionsRelationships != null && clusterData.clusterPartitionsRelationships != '') {
      let clusterRelationshipArray = [];
      let partitionMap =new Map<string, string>();
      clusterData.clusterPartitionsRelationships.forEach(obj => {
        let clusterRelationshipModel = {};
        let partitionDetails = {};
        clusterRelationshipModel['nodeId'] = obj.nodeId;
        clusterRelationshipModel['zoneId'] = obj.zoneId;
        clusterRelationshipModel['remoteEth0Addr'] = obj.remoteEth0Addr;
        clusterRelationshipModel['operationPerformedUserName'] = obj.operationPerformedUserName;
        clusterRelationshipModel['operationPerformedPassword'] = obj.operationPerformedPassword;
        if (obj.partitionDetailModel != null) {
          clusterRelationshipModel['applianceId'] = obj.partitionDetailModel.applianceId;
          clusterRelationshipModel['ipAddress'] = obj.partitionDetailModel.ipAddress;
          clusterRelationshipModel['applianceName'] = obj.partitionDetailModel.applianceName;
          clusterRelationshipModel['partitionName'] = obj.partitionDetailModel.partitionName;
          clusterRelationshipModel['partitionId'] = obj.partitionDetailModel.partitionId;
        }

        clusterRelationshipModel['deletedPartitionId'] = null;
        clusterRelationshipArray.push(clusterRelationshipModel);
        this.clusterDetails['clusterPartitionsRelationships'] = clusterRelationshipArray;
        // partition Data 
        if (obj.remoteEth0Addr != null) {
          partitionDetails['remoteEth0Addr'] = obj.remoteEth0Addr;
        }
        if (obj.partitionDetailModel != null) {
          partitionDetails['partitionName'] = obj.partitionDetailModel.partitionName;
          partitionDetails['partitionId'] = obj.partitionDetailModel.partitionId;
          partitionDetails['applianceId'] = obj.partitionDetailModel.applianceId;
          partitionDetails['applianceName'] = obj.partitionDetailModel.applianceName;
          partitionDetails['ipAddress'] = obj.partitionDetailModel.ipAddress;
          partitionDetails["keys"] = obj.partitionDetailModel.keys;
          partitionDetails["sslContexts"] = obj.partitionDetailModel.sslContexts;
        }
        partitionDetails["nodeId"] = obj.nodeId;
        partitionDetails["zoneId"] = obj.zoneId;
        //  partitionDetailModel["sync"]=obj.partitionDetailModel.partitionId;
        partitionDetails["tombstoneKeys"] = obj.tombstoneKeys;
        this.partitionDetailsTableList.push(partitionDetails);

        // connection status 
        debugger;
        partitionMap.set(obj.partitionDetailModel.partitionId,obj.partitionDetailModel.partitionName);
        obj.connectedPartitions.forEach(element => {
          element['parentPartitionId']=obj.partitionDetailModel.partitionId;
          this.partitionNodeList.push(element);
        });
      
      });
      let partitionIds = Array.from(partitionMap.keys());
      let connectionList :any= [];
      let displayNodes: any =[];
      debugger;
      partitionIds.forEach(id=>{
        this.partitionNodeList.forEach(element => {
          let connectionPartition={};
          let partitionNames={};
          if(element.parentPartitionId == id){
            let partitionName =  partitionMap.get(element.partitionId);
            connectionPartition["source"]=partitionMap.get(id);
            connectionPartition["target"]=partitionName;
            if(element.connectivityStatus == "disconnected"){
              connectionPartition["color"]="Red";
              connectionPartition["status"]=partitionMap.get(id)+"-"+partitionName+": disconnected";
            }else{
              connectionPartition["status"]=partitionMap.get(id)+"-"+partitionName+": connected";
            }
            connectionList.push(connectionPartition);
          }
          partitionNames["name"]=partitionMap.get(id);
          partitionNames["size"]=5;
          displayNodes.push(partitionNames);
        });
      });
      if(connectionList.length>0){
        d3plus.viz()
        .container("#viz") 
        .type("network")
        .data(displayNodes) 
        .edges({
        "large": 100, 
        "label": "status",
        "arrows": true, 
        "value":connectionList, 
        }) 
       // .edges({"arrows": true}) 
        //.color("color")
        .size(1) 
        .id("name")
        .edges({"arrows": true}) 
        .draw() 

      }
    }
  }

  createLoginForm() {
    this.loginForm = this._formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
    });
  }
  goToAddNodeModal(operation) {
    this.partitionOperation = '';
    this.applianceList = [];
    this.selectedPartitions = [];
    this.finalPartitionList = [];
    this.partitionOperation = operation;
    this.addNodeModal.show();
    this._service.getAddNodeDetails().subscribe(
      res => {
        debugger;
        this.addNodePartitions = res;
        this.addNodePartitions.forEach(obj => {
          let applianceObj = {};

          applianceObj["applianceName"] = obj.applianceName;
          applianceObj["applianceId"] = obj.applianceId;
          applianceObj["partitionName"] = obj.partitionName;
          applianceObj["ipAddress"] = obj.ipAddress;
          applianceObj["partitionId"] = obj.partitionId;
          applianceObj["nodeId"] = obj.partitionData.nodeId;
          applianceObj["remoteEth0Addr"] = obj.networkStats.general.eth0.ip;
          applianceObj["remoteEth1Addr"] = obj.networkStats.general.eth1.ip;
          applianceObj["zoneId"] = obj.zoneId;
          applianceObj["operationPerformedUserName"] = '';
          applianceObj["operationPerformedPassword"] = '';
          applianceObj["deletedPartitionId"] = '';
          this.applianceList.push(applianceObj);
        });
      },
      error => {
        console.error(error);
      },
    );
  }

  selectPartitionItems(event, applianceId, partitionId: string) {
    if (event.checked) {
      for (var i = 0; i < this.applianceList.length; i++) {
        if (this.applianceList[i].applianceId == applianceId) {
          if (this.applianceList[i].partitionId == partitionId) {
            this.selectedPartitions.push(this.applianceList[i]);
          }
        }
      }
    } else {
      const index = this.selectedPartitions.findIndex(partition => partition.partitionId === partitionId);
      this.selectedPartitions.splice(index, 1);
    }
  }
  goToLoginModal(operation) {
    debugger;
    this.checkLoginCredentialsResultArray = [];
    if (this.selectedPartitions.length > 0) {
      this.clearData();
      if (this.partitionOperation === 'addNode') {
        this.partitionMap = new Map<string, Array<any>>();
        // need login credentials for existing cluster partitions.
        if (this.clusterDetails['clusterPartitionsRelationships'] != null && this.clusterDetails['clusterPartitionsRelationships'] != '') {
          let existingClusterDetails = this.clusterDetails['clusterPartitionsRelationships'];
          existingClusterDetails.forEach(obj => {
            this.selectedPartitions.push(obj);
          });
        }
        if (this.selectedPartitions.length <= 32) {
          // construct map based on applianceId for selected PartitionList
          this.selectedPartitions.forEach(partitionObj => {
            let tempMap: Array<any> = [];
            if (this.partitionMap.has(partitionObj['applianceId'])) {
              tempMap = this.partitionMap.get(partitionObj['applianceId']);
            }
            tempMap.push(partitionObj);
            this.partitionMap.set(partitionObj['applianceId'], tempMap);
          });
          //construct map code ends here
          // get all the applianceIds form the map and iterate each applianceId , to 
          // identity the credentialSaved or not 
          let applianceIds = Array.from(this.partitionMap.keys());
          applianceIds.forEach(appId => {
            if (this.partitionMap.has(appId)) {
              let partitionObj = this.partitionMap.get(appId)[0];
              if (partitionObj['credentialSaved']) {
                this.credentialsSavedPartitionList.push(partitionObj);
              } else {

                // check appliance credentials are available in localsession.
                // if available in localsession , skips the login for appliance.
                let loginCredentials = JSON.parse(localStorage.getItem(partitionObj.ipAddress));
                if (loginCredentials != null) {
                  partitionObj['operationPerformedUserName'] = loginCredentials.username;
                  partitionObj['operationPerformedPassword'] = loginCredentials.password;
                  this.saveCredentialsToSessionArray.push(partitionObj);
                } else {
                  this.nonCredentialSavedParitionList.push(partitionObj);
                }
              }
              // this.credentialsSavedPartitionList.push(partitionObj);
            }
          });
          //  check the length of non credentialsaved Partition List to show the login pop.
          // if length is 0 , then show the confirm modal,whether to continue the selected Operation or not.
          if (this.nonCredentialSavedParitionList.length > 0) {
            this.partitionName = this.nonCredentialSavedParitionList[this.partitionCount - 1]['applianceName'];
            this.totalpartitionCount = this.nonCredentialSavedParitionList.length;
            if (this.partitionCount == this.totalpartitionCount) {
              this.isLastPartition = true;
            }
            this.addNodeModal.hide();
            this.removeNodeModal.hide();
            this.partitionLoginModal.show();
          } else {
            this.invokeCreateCluster();
          }
        } else {
          this.partitionLoginModal.show();
          this.errorMessage1 = "Sorry!Operation cannot be performed on more than 32 partitions";
        }
      } else if (this.partitionOperation === 'removeNode') {
        this.partitionMap = new Map<string, Array<any>>();
        // need login credentials for existing cluster partitions.
        if (this.clusterDetails['clusterPartitionsRelationships'] != null && this.clusterDetails['clusterPartitionsRelationships'] != '') {
          let existingClusterDetails = this.clusterDetails['clusterPartitionsRelationships'];
          existingClusterDetails.forEach(obj => {
            if (this.selectedPartitionsIds.some(id => id != obj.partitionId)) {
              this.selectedPartitions.push(obj);
            }
          });
        }
        if (this.selectedPartitionsIds.length == this.partitionDetailsTableList.length) {
          this.selectedPartitions = [];
          this.partitionLoginModal.show();
          this.errorMessage1 = "Alteast One partition should be there in Cluster";
        } else {
          // construct map based on applianceId for selected PartitionList
          this.selectedPartitions.forEach(partitionObj => {
            let tempMap: Array<any> = [];
            if (this.partitionMap.has(partitionObj['applianceId'])) {
              tempMap = this.partitionMap.get(partitionObj['applianceId']);
            }
            tempMap.push(partitionObj);
            this.partitionMap.set(partitionObj['applianceId'], tempMap);
          });
          //construct map code ends here
          // get all the applianceIds form the map and iterate each applianceId , to 
          // identity the credentialSaved or not 
          let applianceIds = Array.from(this.partitionMap.keys());
          applianceIds.forEach(appId => {
            if (this.partitionMap.has(appId)) {
              let partitionObj = this.partitionMap.get(appId)[0];
              if (partitionObj['credentialSaved']) {
                this.credentialsSavedPartitionList.push(partitionObj);
              } else {

                // check appliance credentials are available in localsession.
                // if available in localsession , skips the login for appliance.
                let loginCredentials = JSON.parse(localStorage.getItem(partitionObj.ipAddress));
                if (loginCredentials != null) {
                  partitionObj['operationPerformedUserName'] = loginCredentials.username;
                  partitionObj['operationPerformedPassword'] = loginCredentials.password;
                  this.saveCredentialsToSessionArray.push(partitionObj);
                } else {
                  this.nonCredentialSavedParitionList.push(partitionObj);
                }
              }
              // this.credentialsSavedPartitionList.push(partitionObj);
            }
          });
          //  check the length of non credentialsaved Partition List to show the login pop.
          // if length is 0 , then show the confirm modal,whether to continue the selected Operation or not.
          if (this.nonCredentialSavedParitionList.length > 0) {
            this.partitionName = this.nonCredentialSavedParitionList[this.partitionCount - 1]['applianceName'];
            this.totalpartitionCount = this.nonCredentialSavedParitionList.length;
            if (this.partitionCount == this.totalpartitionCount) {
              this.isLastPartition = true;
            }
            this.addNodeModal.hide();
            this.removeNodeModal.hide();
            this.partitionLoginModal.show();
          } else {
            this.removePartition();
          }
        }

      }
    } else {
      this.partitionLoginModal.show();
      this.errorMessage1 = "Please select any partition to perform the activity!";
    }

  }

  goToNextPartition() {
    let applianceObj = this.nonCredentialSavedParitionList[this.partitionCount - 1];
    this.createListOfPartitions(applianceObj, "login");
    let loginDetailsModal = {};
    loginDetailsModal['applianceId'] = applianceObj.applianceId;
    loginDetailsModal['applianceName'] = applianceObj.applianceName;
    loginDetailsModal['ipAddress'] = applianceObj.ipAddress;
    loginDetailsModal['operationUsername'] = this.loginForm.get('username').value;
    loginDetailsModal['operationPassword'] = this.loginForm.get('password').value;
    this.loginCredentialsArray.push(loginDetailsModal);
    if (this.partitionCount < this.nonCredentialSavedParitionList.length) {
      this.partitionName = this.nonCredentialSavedParitionList[this.partitionCount]['applianceName'];
      this.partitionCount++;
      if (this.partitionCount == this.totalpartitionCount) {
        this.isLastPartition = true;
      }
    } else {
      this.partitionLoginModal.hide();
      //this.goToCreateCluster();
      this.checkAppliancesCredentials();
    }
    this.loginForm.reset();
  }

  checkAppliancesCredentials() {
    this.loading = true;
    this.message = '';
    this.errorMessage = '';
    this.errorMessage1 = '';
    this.checkLoginCredentialsResultArray = [];
    this._appService.checkAppliancesCredentials(this.loginCredentialsArray).subscribe(
      (response) => {
        let isSuccess: boolean = true;
        response.forEach(obj => {
          this.loginCredentialsArray = [];
          if (obj.code != "200") {
            this.loading = false;
            this.checkLoginCredentialsResultArray.push(obj);
            isSuccess = false;
          }

        });
        if (isSuccess) {
          this.partitionLoginModal.hide();
          // this.invokeCreateCluster();
          if (this.partitionOperation === 'addNode') {
            this.invokeCreateCluster();
          } else if (this.partitionOperation === 'removeNode') {
            this.removePartition();
          }
        } else {
          this.finalPartitionList = [];
          //this.selectedPartitionList = [];
          this.selectedPartitions = [];
          this.partitionLoginModal.show();
        }
      },
      (error) => {
        console.log(error);
      })
  }

  createListOfPartitions(applianceObj, value) {
    if (this.partitionMap.has(applianceObj.applianceId)) {
      let partitionList = this.partitionMap.get(applianceObj.applianceId);
      partitionList.forEach(obj => {
        if (value == "login") {
          obj['operationPerformedUserName'] = this.loginForm.get('username').value;
          obj['operationPerformedPassword'] = this.loginForm.get('password').value;
        } else {
          obj['operationPerformedUserName'] = applianceObj.operationPerformedUserName;
          obj['operationPerformedPassword'] = applianceObj.operationPerformedPassword;
        }
        this.finalPartitionList.push(obj);
      });
    }
  }

  invokeCreateCluster() {
    this.credentialsSavedPartitionList.forEach(partitionObj => {
      this.createListOfPartitions(partitionObj, "");
    });
    this.saveCredentialsToSessionArray.forEach(partitionObj => {
      this.createListOfPartitions(partitionObj, "");
    });
    this.clusterDetails['clusterPartitionsRelationships'] = this.finalPartitionList;
    this._partitionManagementService.comparePartitionsAndCreateCluster(this.clusterDetails).subscribe(
      res => {
        this.loading = false;
        this.message = '';
        this.errorMessage = '';
        this.errorMessage1 = '';
        this.selectedPartitions = [];
        this.finalPartitionList = [];
        if (res.code == "200") {
          this.message = res.message;
        } else if (res.code == "415") {
          this.errorMessage = res.errorMessage;
        } else {
          this.errorMessage1 = res.errorMessage;
        }
        this.partitionLoginModal.show();
        this.clearData();
      },
      error => {
        console.log(error);
      },
    )
  }


  public formValidationFields1 = {
    "username": '',
    "password": ''

  }
  isFieldValid1(field: string) {
    if (this.loginForm.get(field).touched) {
      this.formValidationFields1 = this._fieldErrorDisplayService.validateField(this.loginForm, field, this.formValidationFields1, "login")
    }
    return !this.loginForm.get(field).valid && this.loginForm.get(field).touched;
  }

  displayFieldCss1(field: string) {
    return {
      'has-error': this.isFieldValid1(field),
      'has-feedback': this.isFieldValid1(field)
    };
  }


  goToCreateCluster() {
    this._service.createCluster(this.clusterDetails).subscribe(
      (response) => {
        this.message = '';
        this.errorMessage = '';
        this.errorMessage1 = '';
        this.checkLoginCredentialsResultArray = [];
        if (response.code == "200") {
          this.message = response.message;
        } else {
          this.errorMessage1 = response.errorMessage;
        }
      },
      (error) => {
        console.error(error);
      }
    )
  }

  showCreateCluster(isShow: boolean) {
    this.isCreateClusterShow = isShow
  }


  goToRemoveNodeModal(operation) {
    debugger;
    this.partitionOperation = '';
    this.partitionOperation = operation;
    this.removeNodeModal.show();
    let list = this.partitionDetailsTableList;
    this.partitionDetailsTableList = [];
    list.forEach(element => {
      let partitionDetails = {};
      partitionDetails['partitionName'] = element.partitionName;
      partitionDetails['partitionId'] = element.partitionId;
      partitionDetails['applianceId'] = element.applianceId;
      partitionDetails['applianceName'] = element.applianceName;
      partitionDetails['ipAddress'] = element.ipAddress;
      partitionDetails["keys"] = element.keys;
      partitionDetails["sslContexts"] = element.sslContexts;
      partitionDetails["nodeId"] = element.nodeId;
      partitionDetails["zoneId"] = element.zoneId;
      //  partitionDetailModel["sync"]=obj.partitionDetailModel.partitionId;
      partitionDetails["tombstoneKeys"] = element.tombstoneKeys;
      if (element.remoteEth0Addr != null) {
        partitionDetails['remoteEth0Addr'] = element.remoteEth0Addr;
      }
      this.partitionDetailsTableList.push(partitionDetails);
    });
  }

  removePartition() {
    this.message = '';
    this.errorMessage = '';
    this.errorMessage1 = '';
    this.checkLoginCredentialsResultArray = [];
    this.loading = true;
    this.removeCheck = false;
    this.credentialsSavedPartitionList.forEach(partitionObj => {
      this.createListOfPartitions(partitionObj, "");
    });
    this.saveCredentialsToSessionArray.forEach(partitionObj => {
      this.createListOfPartitions(partitionObj, "");
    });
    this.clusterDetails['clusterPartitionsRelationships'] = this.finalPartitionList;
    this._service.deleteNodeDetails(this.clusterDetails).subscribe((response) => {
      this.loading = false;
      //this.messageModal.show();
      this.selectedPartitions = [];
      this.finalPartitionList = [];
      this.selectedPartitionsIds = [];
      let res = response.json();
      // res.forEach(obj => {
      //   obj.clusterPartitionsRelationships.forEach(element => {
      //     this.checkLoginCredentialsResultArray.push(element);
      //   });
      // });
      if (res.code == "200") {
        this.message = res.message;
      } else {
        this.errorMessage1 = res.errorMessage;
      }
    })

  }

  selectPartitionItems1(event, applianceId, partitionId: string) {
    if (event.checked) {
      for (var i = 0; i < this.partitionDetailsTableList.length; i++) {
        if (this.partitionDetailsTableList[i].applianceId == applianceId) {
          if (this.partitionDetailsTableList[i].partitionId == partitionId) {
            let selectedPartitionObject = this.partitionDetailsTableList[i];
            selectedPartitionObject['deletedPartitionId'] = partitionId;
            this.selectedPartitions.push(selectedPartitionObject);
            this.selectedPartitionsIds.push(partitionId);
          }
        }
      }
    } else {
      const index = this.selectedPartitions.findIndex(partition => partition.partitionId === partitionId);
      this.selectedPartitions.splice(index, 1);

      const index1 = this.selectedPartitionsIds.findIndex(id => id === partitionId);
      this.selectedPartitionsIds.splice(index1, 1);
    }
  }

  closeAddNodeModal() {
    this.addNodeModal.hide();
    this.clearData();
    this.selectedPartitions = [];
  }

  clearData() {
    //this.selectedPartitions = [];
    //this.message = '';
    //this.errorMessage = '';
    //this.errorMessage1 = '';
    this.loginForm.reset();
    //this.partitionOperation = '';
    this.nonCredentialSavedParitionList = [];
    this.credentialsSavedPartitionList = [];
    this.saveCredentialsToSessionArray = [];
    this.partitionCount = 1;
    this.totalpartitionCount = 0;
    this.partitionName = '';
    this.isLastPartition = false;
    //this.finalPartitionList = [];
  }

  closeRemoveNodeModal() {
    this.removeNodeModal.hide();
    this.clearData();
    this.selectedPartitions = [];
    this.selectedPartitionsIds = [];
  }

  closeLoginModal() {
    this.partitionLoginModal.hide();
    this.selectedPartitions = [];
    this.clearData();
  }

  redirectToListCluster() {
    this.clearData();
    this._router.navigate(['/listCluster']);
  }
}


