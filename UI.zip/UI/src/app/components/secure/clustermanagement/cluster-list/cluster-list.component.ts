import { Component, OnInit , OnDestroy,ViewChild} from '@angular/core';
import { PartitionManagementService } from '../../../../services/partitionmanagement/partitionmanagement.service';
import { AnonymousSubscription } from "rxjs/Subscription";
import { Observable } from "rxjs/Observable";
import { DataTableResource } from '../../data-table/index';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { I18nService } from '../../../../services/common/i18n/i18n.service';
import { BreadcrumbService } from '../../../../services/common/breadcrumb.service';
import { FieldErrorDisplayService } from '../../../../services/common/field-error-display.service';
//import { ClusterLoginComponent } from '/../cluster-login/cluster-login.component';

@Component({
  selector: 'app-cluster-list',
  templateUrl: './cluster-list.component.html',
  styleUrls: ['./cluster-list.component.css']
})

export class ClusterListComponent implements OnInit, OnDestroy {
 
  //@ViewChild('clusterLoginComponent')
  //private clusterLoginComponent: ClusterLoginComponent;
  title = "Partition List";
  clusterList: any = [];
  clusterPartitionsRelationships:any[];
  showList: boolean = false;
  selectedClusterList = [];
  toolTipData: any ={};
  timercount = 0;
  checkInProgressStatus: boolean = false;
  loading: boolean = false;
  private timer: AnonymousSubscription;
  private clusterListSubscription: AnonymousSubscription;
  valid: boolean = false;
  constructor(private _service: PartitionManagementService,
    private _I18nService: I18nService,
    private _formBuilder: FormBuilder,
    private _fieldErrorDisplayService: FieldErrorDisplayService) {
 
  }

  ngOnInit() {
    this.getClusterList();
  
  }
  getClusterList() {
    this.loading = true
    this._service.listClusters().subscribe(
      res => {
        console.log(res);
        this.loading = false;
        this.checkInProgressStatus = false;
        this. clusterList = [];
        this. clusterList = res;
        console.log(this. clusterList);
        let count: number = 0;
        this. clusterList.forEach(clusterObj => {

          if (clusterObj.clusterData != null) {
            const clusterData = clusterObj.clusterData;
            let fipsState = '';
            let vmStatus = '';
            let cavServerStatus = '';
            if (clusterData.fipsState != null) {
              fipsState = clusterData.fipsState.split(" ", 2)[1].replace(/[\[\]']+/g, '');
            }
            if (clusterData.vmStatus != null) {
              vmStatus = clusterData.vmStatus;
            }
            if (clusterData.cavServerStatus != null) {
              cavServerStatus = clusterData.cavServerStatus;
            }
            this.clusterList[count]['tempFipsStatus'] = fipsState;
            if (clusterData.totalSslCtxs != null) {
              this.clusterList[count]['tempTotalSslCtxs'] = clusterData.totalSslCtxs;
            }
            if (fipsState == "zeroized" && vmStatus == "0" && cavServerStatus == "0") {
              this.clusterList[count]['statusColor'] = "grey";
            } else if (fipsState == "zeroized" && vmStatus == "0" && cavServerStatus == "1") {
              this.clusterList[count]['statusColor'] = "grey";
            } else if (fipsState == "zeroized" && vmStatus == "0" && cavServerStatus == "-1") {
              this.clusterList[count]['statusColor'] = "orange";
            } else if (fipsState == "zeroized" && vmStatus == "1" && cavServerStatus == "1") {
              this.clusterList[count]['statusColor'] = "green";
            }
            else if (fipsState == "zeroized" && vmStatus == "1" && cavServerStatus == "0") {
              this.clusterList[count]['statusColor'] = "yellow";
            }
            else if (fipsState == "nonzeroized" && vmStatus == "1" && cavServerStatus == "0") {
              this.clusterList[count]['statusColor'] = "yellow";
            } else if (fipsState == "nonzeroized" && vmStatus == "1" && cavServerStatus == "1") {
              this.clusterList[count]['statusColor'] = "green";
            } else if (fipsState == "nonzeroized" && vmStatus == "1" && cavServerStatus == "-1") {
              this.clusterList[count]['statusColor'] = "red";
            } else if (fipsState == "nonzeroized" && vmStatus == "-1" && cavServerStatus == "0") {
              this.clusterList[count]['statusColor'] = "red";
            } else if (fipsState == "nonzeroized" && vmStatus == "-1" && cavServerStatus == "1") {
              this.clusterList[count]['statusColor'] = "red";
            } else if (fipsState == "nonzeroized" && vmStatus == "-1" && cavServerStatus == "-1") {
              this.clusterList[count]['statusColor'] = "red";
            } else if (fipsState == "zeroized" && vmStatus == "-1" && cavServerStatus == "0") {
              this.clusterList[count]['statusColor'] = "red";
            } else if (fipsState == "zeroized" && vmStatus == "-1" && cavServerStatus == "1") {
              this.clusterList[count]['statusColor'] = "red";
            } else if (fipsState == "zeroized" && vmStatus == "-1" && cavServerStatus == "11") {
              this.clusterList[count]['statusColor'] = "red";
            }

          }
          // if(this.partitionList[count]['lastOperationStatus'] === 'Failed'){
          //   this.partitionList[count]['statusColor']="red";
          // }
          if (this.clusterList[count]['lastOperationStatus'] === 'In-Progress') {
            this.clusterList[count]['InProgress'] = true;
            this.checkInProgressStatus = true;
            this.clusterList[count]['statusColor'] = "grey";
          } else {
            this.clusterList[count]['InProgress'] = false;
          }
          count = count + 1;
        });
        if (this.checkInProgressStatus) {
          this.getTimeIntervalData();
        }
      },
      error => {
        console.log(error);
      },
    );
  }

  private getTimeIntervalData(): void {
    this.timer = Observable.timer(30000).first().subscribe(() => this.getClusterList());
    this.timercount = this.timercount + 1;
  }

  toggle() {
    debugger;
    this.showList = true;
  }
  toggle1() {
    debugger;
    this.showList = false;
  }

  selectClusterItems(event, clusterId: string) {
    debugger;
    if (event.target.checked) {
      event.currentTarget.style.visibility = "visible";
      for (var i = 0; i < this.clusterList.length; i++) {
        if (this.clusterList[i].clusterId == clusterId) {
          this.clusterList[i]['checked'] = true;
          this. selectedClusterList.push(this.clusterList[i]);
        }
        else if (!this.clusterList[i]['checked']) {
          //this.partitionList[i]['checked']=false;
        }
      }

    } else {
      for (var i = 0; i < this.clusterList.length; i++) {
        if (this.clusterList[i].clusterId == clusterId) {
          let index = this. selectedClusterList.indexOf(clusterId);
          this.clusterList[i]['checked'] = false;
          this. selectedClusterList.splice(index);
        }
        else if (!this.clusterList[i]['checked']) {
          //this.partitionList[i]['checked']=false;
        }
      }
    }
  }

  getClusterToolTipData(clusterId) {
    this.toolTipData = "";
    this.clusterList.find
      (cluster => {
        if (cluster.clusterId == clusterId) {
         //this.toolTipData = cluster.clusterData;
         this.toolTipData = cluster;
        //   console.log( this.toolTipData);
        //  this.toolTipData['lastPerformedOperation'] = cluster.lastOperationPerformed;
        //  this.toolTipData['errorMsg'] = cluster.errorMessage;
        //   this.toolTipData['lastOperationStatus'] = cluster.lastOperationStatus;
          console.log( this.toolTipData);
        }
      })
  }
  callBackToClusterList() {
    console.log("Callback ----> List of Partitions");
    this.selectedClusterList = [];
    this.getClusterList();
  }

  ngOnDestroy() {
    if (this.timer) {
      this.timer.unsubscribe();
    }
    if (this.clusterListSubscription) {
      this.clusterListSubscription.unsubscribe();
    }
  }
}

