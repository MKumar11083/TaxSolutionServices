import { Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Configuration } from './app.constants';
import { LoadingModule } from 'ngx-loading'; 


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Cavium';

  constructor(private translate:TranslateService){
    translate.setDefaultLang(Configuration.LOCALE);
  }

  
  switchLanguage(language: string) {
    this.translate.use(language);
  }
}
