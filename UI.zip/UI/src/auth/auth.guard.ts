import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { LoginService} from './../app/services/login.service';
import { Cookie } from 'ng2-cookies';
@Injectable()
export class AuthGuard implements CanActivate {

    constructor(private router: Router,private _loginService:LoginService) { }

    canActivate() {
        console.log(Cookie.check(sessionStorage.getItem('username')));
        if (!Cookie.check(sessionStorage.getItem('username'))){
            console.log("checkCredentilas");
              this.router.navigate(['/login']);
              return false;
          }else{
            return true;
          }
    }

 
}