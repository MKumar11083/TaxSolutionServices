export const environment = {
  production: true,
  format : '.json',
  i18NUrl : '/dist/assets/i18n/'
};
