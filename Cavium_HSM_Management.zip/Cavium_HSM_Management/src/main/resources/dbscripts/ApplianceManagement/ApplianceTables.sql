CREATE TABLE appliance_details (
      appliance_id MEDIUMINT UNSIGNED NOT NULL auto_increment,
      appliance_name varchar(255),
      appliance_status varchar(50),
      serial_number varchar(100),
      network_timezone varchar(100),
      network_id varchar(100),
      gateway_ip varchar(100),
      ip_address varchar(100),
      subnet_mask varchar(100),
      network_mode varchar(100),
      hostname varchar(100),
      device_added_by_user varchar(255),
      operation_performed varchar(100),
      ipmi_ip varchar(100),
      user_name varchar(100) not null,
      user_password varchar(100) not null,
      PRIMARY KEY (appliance_id)
      );


create table partition_details(
partition_id MEDIUMINT UNSIGNED NOT NULL auto_increment,
appliance_id MEDIUMINT UNSIGNED NOT NULL,
partition_type varchar(50),
partition_total_space varchar(100),
partition_availble_space varchar(50),
partition_used_space varchar(50),
PRIMARY KEY (partition_id),
 KEY `fk_appliance_idx` (`appliance_id`),
CONSTRAINT FK_appliance FOREIGN KEY (appliance_id) REFERENCES appliance_details(appliance_id)ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE designation_appliance (
    ID MEDIUMINT UNSIGNED NOT NULL AUTO_INCREMENT,
    appliance_id MEDIUMINT UNSIGNED,
    design_id MEDIUMINT UNSIGNED,
    PRIMARY KEY (ID),
	FOREIGN KEY (appliance_id) REFERENCES appliance_details(appliance_id)
);


ALTER TABLE appliance_details 
ADD created_date DATETIME,
ADD created_by varchar(250),
ADD modified_by varchar(250),
ADD modified_date DATETIME;


ALTER TABLE appliance_details 
ADD authid varchar(100);


create table recent_activites
(ID MEDIUMINT UNSIGNED NOT NULL AUTO_INCREMENT key,user_groupid varchar(50),
 message varchar(500),created_date DATETIME);
 
ALTER TABLE appliance_details ADD city_name varchar(100) not null;


create table initialize(initialize_id MEDIUMINT UNSIGNED NOT NULL AUTO_INCREMENT,appliance_id MEDIUMINT UNSIGNED NOT NULL ,crypto_officer_name varchar(100),crypto_officer_password varchar(100), confirm_crypto_officer_password varchar(100),
authentication_level int(10),fips_state int(10),cert_authentication int(10),login_failure_count int(10),
minimum_password_length int(10),maximum_password_length int(10),hsm_label varchar(100),hsm_audit_log int(10),
PRIMARY KEY (ID),
	FOREIGN KEY (appliance_id) REFERENCES appliance_details(appliance_id));

create table dual_factor_auth(ID MEDIUMINT UNSIGNED NOT NULL AUTO_INCREMENT,initialize_id MEDIUMINT UNSIGNED NOT NULL, dual_factor_auth_server_address varchar(100),dual_factor_auth_server_port_no varchar(100),
dual_factor_auth_server_certificate blob,PRIMARY KEY (ID),
	FOREIGN KEY (initialize_id) REFERENCES initialize(initialize_id));
    
	
alter table partition_details add partition_name varchar(100) after appliance_id;	


 

create table network_stats(
network_stat_id varchar(255) NOT NULL,
initialize_id MEDIUMINT UNSIGNED NOT NULL,
dhcp bit,
ip_address varchar(100),
gateway varchar(100),
subnet varchar(100),
disable_eth1 bit,
vlan_id int(10),
PRIMARY KEY (network_stat_id,initialize_id),
KEY `fk_initialize_idx` (`initialize_id`),
CONSTRAINT FK_initialize FOREIGN KEY (initialize_id) REFERENCES initialize(initialize_id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;