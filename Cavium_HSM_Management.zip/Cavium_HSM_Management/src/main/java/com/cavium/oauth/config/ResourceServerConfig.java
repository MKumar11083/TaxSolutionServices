package com.cavium.oauth.config;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.error.OAuth2AccessDeniedHandler;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.oauth2.provider.token.store.InMemoryTokenStore;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

/**
 * This class is handling the resources authentication 
 * */
@Configuration
@EnableResourceServer
public class ResourceServerConfig extends ResourceServerConfigurerAdapter {
	private Logger logger = Logger.getLogger(this.getClass());
    private static final String RESOURCE_ID = "resource_id";

    @Override
    public void configure(ResourceServerSecurityConfigurer resources) {
        resources.resourceId(RESOURCE_ID).stateless(true);
    }

    @Override
    public void configure(HttpSecurity http) throws Exception {
    	logger.info("inside ResourceServerConfig's configure method");
        http.cors().and().anonymous().disable().logout().logoutRequestMatcher(new AntPathRequestMatcher("/logout", "DELETE"))
                .logoutSuccessHandler(new CustomLogoutSuccessHandler(tokenStore())).deleteCookies("JSESSIONID").
                invalidateHttpSession(true).permitAll().and()
                .authorizeRequests()
                .antMatchers("/rest/**").authenticated()
                .and().exceptionHandling().accessDeniedHandler(new OAuth2AccessDeniedHandler());
    }
    
    @Bean
    public TokenStore tokenStore() {
        return new InMemoryTokenStore();
    }

}