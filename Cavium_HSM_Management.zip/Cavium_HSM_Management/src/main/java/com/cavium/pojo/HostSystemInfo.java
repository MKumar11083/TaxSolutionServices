package com.cavium.pojo;

import org.springframework.stereotype.Component;

import com.cavium.pojo.AdminHostinfo.HostStats;
@Component
public class HostSystemInfo {
	
	HSMInfo hsmInfo;
	ApplianceInfo applianceInfo;
	PartitionsDetails partitionsDetails;
	HostStats hostStats;
	/**
	 * @return the hsmInfo
	 */
	public HSMInfo getHsmInfo() {
		return hsmInfo;
	}
	/**
	 * @param hsmInfo the hsmInfo to set
	 */
	public void setHsmInfo(HSMInfo hsmInfo) {
		this.hsmInfo = hsmInfo;
	}
	/**
	 * @return the applianceInfo
	 */
	public ApplianceInfo getApplianceInfo() {
		return applianceInfo;
	}
	/**
	 * @param applianceInfo the applianceInfo to set
	 */
	public void setApplianceInfo(ApplianceInfo applianceInfo) {
		this.applianceInfo = applianceInfo;
	}
	/**
	 * @return the partitionsDetails
	 */
	public PartitionsDetails getPartitionsDetails() {
		return partitionsDetails;
	}
	/**
	 * @param partitionsDetails the partitionsDetails to set
	 */
	public void setPartitionsDetails(PartitionsDetails partitionsDetails) {
		this.partitionsDetails = partitionsDetails;
	}
	/**
	 * @return the hostStats
	 */
	public HostStats getHostStats() {
		return hostStats;
	}
	/**
	 * @param hostStats the hostStats to set
	 */
	public void setHostStats(HostStats hostStats) {
		this.hostStats = hostStats;
	}
	 
	

}
