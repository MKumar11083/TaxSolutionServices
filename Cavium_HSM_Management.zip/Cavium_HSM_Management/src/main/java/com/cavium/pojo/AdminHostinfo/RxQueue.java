package com.cavium.pojo.AdminHostinfo;

public class RxQueue {
	 private double rdt;
	 private double rdh;
	/**
	 * @return the rdt
	 */
	public double getRdt() {
		return rdt;
	}
	/**
	 * @param rdt the rdt to set
	 */
	public void setRdt(double rdt) {
		this.rdt = rdt;
	}
	/**
	 * @return the rdh
	 */
	public double getRdh() {
		return rdh;
	}
	/**
	 * @param rdh the rdh to set
	 */
	public void setRdh(double rdh) {
		this.rdh = rdh;
	}
	 
	 
	}
