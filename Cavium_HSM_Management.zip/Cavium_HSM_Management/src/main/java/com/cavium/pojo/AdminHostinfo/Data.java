package com.cavium.pojo.AdminHostinfo;

public class Data {
	 Vmstats VmstatsObject;

	/**
	 * @return the vmstatsObject
	 */
	public Vmstats getVmstatsObject() {
		return VmstatsObject;
	}

	/**
	 * @param vmstatsObject the vmstatsObject to set
	 */
	public void setVmstatsObject(Vmstats vmstatsObject) {
		VmstatsObject = vmstatsObject;
	}

	}
