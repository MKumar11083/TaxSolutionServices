package com.cavium.pojo.AdminHostinfo;

public class SwapStats{
	 private double total;
	 private double free;
	 private double used;
	 private double usedPercentage;
	/**
	 * @return the total
	 */
	public double getTotal() {
		return total;
	}
	/**
	 * @param total the total to set
	 */
	public void setTotal(double total) {
		this.total = total;
	}
	/**
	 * @return the free
	 */
	public double getFree() {
		return free;
	}
	/**
	 * @param free the free to set
	 */
	public void setFree(double free) {
		this.free = free;
	}
	/**
	 * @return the used
	 */
	public double getUsed() {
		return used;
	}
	/**
	 * @param used the used to set
	 */
	public void setUsed(double used) {
		this.used = used;
	}
	/**
	 * @return the usedPercentage
	 */
	public double getUsedPercentage() {
		return usedPercentage;
	}
	/**
	 * @param usedPercentage the usedPercentage to set
	 */
	public void setUsedPercentage(double usedPercentage) {
		this.usedPercentage = usedPercentage;
	} 
	 
	}
