package com.cavium.pojo.AdminHostinfo;

public class Vmstats {
	private double cavServerStatus;
	private SystemUpTime SystemUpTimeObject;
	private double linkStatusEth0;
	private RxQueue RxQueueObject;
	private DrvReqIdQueue DrvReqIdQueueObject;
	private RamStats ramStats;
	private double cpuUsage;
	private double linkStatusEth1;
	private TxQueue TxQueueObject;
	private FwReqIdQueue FwReqIdQueueObject;
	private double processCount;
	private SwapStats SwapStats;
	private double freeSpace;
	private double driverStatus;
	/**
	 * @return the cavServerStatus
	 */
	public double getCavServerStatus() {
		return cavServerStatus;
	}
	/**
	 * @param cavServerStatus the cavServerStatus to set
	 */
	public void setCavServerStatus(double cavServerStatus) {
		this.cavServerStatus = cavServerStatus;
	}
	/**
	 * @return the systemUpTimeObject
	 */
	public SystemUpTime getSystemUpTimeObject() {
		return SystemUpTimeObject;
	}
	/**
	 * @param systemUpTimeObject the systemUpTimeObject to set
	 */
	public void setSystemUpTimeObject(SystemUpTime systemUpTimeObject) {
		SystemUpTimeObject = systemUpTimeObject;
	}
	/**
	 * @return the linkStatusEth0
	 */
	public double getLinkStatusEth0() {
		return linkStatusEth0;
	}
	/**
	 * @param linkStatusEth0 the linkStatusEth0 to set
	 */
	public void setLinkStatusEth0(double linkStatusEth0) {
		this.linkStatusEth0 = linkStatusEth0;
	}
	/**
	 * @return the rxQueueObject
	 */
	public RxQueue getRxQueueObject() {
		return RxQueueObject;
	}
	/**
	 * @param rxQueueObject the rxQueueObject to set
	 */
	public void setRxQueueObject(RxQueue rxQueueObject) {
		RxQueueObject = rxQueueObject;
	}
	/**
	 * @return the drvReqIdQueueObject
	 */
	public DrvReqIdQueue getDrvReqIdQueueObject() {
		return DrvReqIdQueueObject;
	}
	/**
	 * @param drvReqIdQueueObject the drvReqIdQueueObject to set
	 */
	public void setDrvReqIdQueueObject(DrvReqIdQueue drvReqIdQueueObject) {
		DrvReqIdQueueObject = drvReqIdQueueObject;
	}
	/**
	 * @return the ramStats
	 */
	public RamStats getRamStats() {
		return ramStats;
	}
	/**
	 * @param ramStats the ramStats to set
	 */
	public void setRamStats(RamStats ramStats) {
		this.ramStats = ramStats;
	}
	/**
	 * @return the cpuUsage
	 */
	public double getCpuUsage() {
		return cpuUsage;
	}
	/**
	 * @param cpuUsage the cpuUsage to set
	 */
	public void setCpuUsage(double cpuUsage) {
		this.cpuUsage = cpuUsage;
	}
	/**
	 * @return the linkStatusEth1
	 */
	public double getLinkStatusEth1() {
		return linkStatusEth1;
	}
	/**
	 * @param linkStatusEth1 the linkStatusEth1 to set
	 */
	public void setLinkStatusEth1(double linkStatusEth1) {
		this.linkStatusEth1 = linkStatusEth1;
	}
	/**
	 * @return the txQueueObject
	 */
	public TxQueue getTxQueueObject() {
		return TxQueueObject;
	}
	/**
	 * @param txQueueObject the txQueueObject to set
	 */
	public void setTxQueueObject(TxQueue txQueueObject) {
		TxQueueObject = txQueueObject;
	}
	/**
	 * @return the fwReqIdQueueObject
	 */
	public FwReqIdQueue getFwReqIdQueueObject() {
		return FwReqIdQueueObject;
	}
	/**
	 * @param fwReqIdQueueObject the fwReqIdQueueObject to set
	 */
	public void setFwReqIdQueueObject(FwReqIdQueue fwReqIdQueueObject) {
		FwReqIdQueueObject = fwReqIdQueueObject;
	}
	/**
	 * @return the processCount
	 */
	public double getProcessCount() {
		return processCount;
	}
	/**
	 * @param processCount the processCount to set
	 */
	public void setProcessCount(double processCount) {
		this.processCount = processCount;
	}
	/**
	 * @return the swapStats
	 */
	public SwapStats getSwapStats() {
		return SwapStats;
	}
	/**
	 * @param swapStats the swapStats to set
	 */
	public void setSwapStats(SwapStats swapStats) {
		SwapStats = swapStats;
	}
	/**
	 * @return the freeSpace
	 */
	public double getFreeSpace() {
		return freeSpace;
	}
	/**
	 * @param freeSpace the freeSpace to set
	 */
	public void setFreeSpace(double freeSpace) {
		this.freeSpace = freeSpace;
	}
	/**
	 * @return the driverStatus
	 */
	public double getDriverStatus() {
		return driverStatus;
	}
	/**
	 * @param driverStatus the driverStatus to set
	 */
	public void setDriverStatus(double driverStatus) {
		this.driverStatus = driverStatus;
	}
	 
}
