package com.cavium.pojo.AdminHostinfo;

public class TxQueue {
	 private double tdh;
	 private double tdt;
	/**
	 * @return the tdh
	 */
	public double getTdh() {
		return tdh;
	}
	/**
	 * @param tdh the tdh to set
	 */
	public void setTdh(double tdh) {
		this.tdh = tdh;
	}
	/**
	 * @return the tdt
	 */
	public double getTdt() {
		return tdt;
	}
	/**
	 * @param tdt the tdt to set
	 */
	public void setTdt(double tdt) {
		this.tdt = tdt;
	}
	 
	}
