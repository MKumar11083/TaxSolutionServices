package com.cavium.model.user;

/*
 * UserDetailModel Model class for UserDetails along with Group Detail and ACL Detail
 * author : RK00490847
 */
import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

@Entity
@Table(name="user_details")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class UserDetailModel implements Serializable  {
	
	private static final long serialVersionUID = 3494972263502251508L;
	
	@Id
	@Column(name="user_id",nullable = false)
	private String userName;
	@JsonProperty(access = Access.WRITE_ONLY)
	@Column(name="password")
	 private String password;
	 @Column(name="first_name")
	private String firstName;
	 @Column(name="last_name")
	private String lastName;
	 @Column(name="email_id")
	private String emailId;
	 @Column(name="phone_number")
	private String phoneNumber;
	 @Enumerated(EnumType.STRING)
	 @Column(name="status")
	 private Status status;	 
	 @Column(name="comments")
	 private String message;	 
	 @Enumerated(EnumType.STRING)
	 @Column(name="temporary_password" , nullable = false)
	 private TemporaryPassword temporaryPassword;
	 @Enumerated(EnumType.STRING)
	 @Transient
	 private String userGroupId;
	 @Transient
	 private String userACLId;
	 @JsonProperty(access = Access.WRITE_ONLY)
	 @Transient
	 private String oldPassword;
	 @JsonProperty(access = Access.WRITE_ONLY)
	 @Transient
	 private String newPassword;
	 @JsonProperty(access = Access.WRITE_ONLY)
	 @Transient
	 private List<String> deletedUserIds;
	 
	 /**
	 * @return the deletedUserIds
	 */
	public List<String> getDeletedUserIds() {
		return deletedUserIds;
	}
	/**
	 * @param deletedUserIds the deletedUserIds to set
	 */
	public void setDeletedUserIds(List<String> deletedUserIds) {
		this.deletedUserIds = deletedUserIds;
	}
	@OneToOne(cascade=CascadeType.ALL,fetch = FetchType.LAZY)
	 @JoinColumn(name = "role",nullable = false)
	 @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	 private UserGroupModel objUserGroupModel;
	 
	 @OneToOne(cascade=CascadeType.ALL,fetch = FetchType.LAZY)
	 @JoinColumn(name = "acl_id",nullable = false)
	 @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	 private UserACLDetailsModel objUserACLDetailsModel;
	 
	 public UserACLDetailsModel getObjUserACLDetailsModel() {
		return objUserACLDetailsModel;
	}
	public void setObjUserACLDetailsModel(UserACLDetailsModel objUserACLDetailsModel) {
		this.objUserACLDetailsModel = objUserACLDetailsModel;
	}
   
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return the emailId
	 */
	public String getEmailId() {
		return emailId;
	}
	/**
	 * @param emailId the emailId to set
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	/**
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}
	/**
	 * @param phoneNumber the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
/*	*//**
	 * @return the userGroup
	 *//*
	public int getUserGroupCode() {
		return userGroupCode;
	}
	*//**
	 * @param userGroup the userGroup to set
	 *//*
	public void setUserGroupCode(int userGroupCode) {
		this.userGroupCode = userGroupCode;
	}*/
	/**
	 * @return the status
	 */
	public Status getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(Status status) {
		this.status = status;
	}
	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	 
	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
 
	/**
	 * @return the objUserGroupModel
	 */
	public UserGroupModel getObjUserGroupModel() {
		if(objUserGroupModel!=null && objUserGroupModel.getRoleName().equals("DeletedUserGroup"))
		{
			return null;
		}else{
		return objUserGroupModel;
		}
	}
	/**
	 * @param objUserGroupModel the objUserGroupModel to set
	 */
	public void setObjUserGroupModel(UserGroupModel objUserGroupModel) {
		this.objUserGroupModel = objUserGroupModel;
	}
	 
	/**
	 * @return the temporaryPassword
	 */
	public TemporaryPassword getTemporaryPassword() {
		return temporaryPassword;
	}
	/**
	 * @param temporaryPassword the temporaryPassword to set
	 */
	public void setTemporaryPassword(TemporaryPassword temporaryPassword) {
		this.temporaryPassword = temporaryPassword;
	}
	/**
	 * @return the userGroupId
	 */
	public String getUserGroupId() {
		return userGroupId;
	}
	/**
	 * @param userGroupId the userGroupId to set
	 */
	public void setUserGroupId(String userGroupId) {
		this.userGroupId = userGroupId;
	}
	/**
	 * @return the userACLId
	 */
	public String getUserACLId() {
		return userACLId;
	}
	/**
	 * @param userACLId the userACLId to set
	 */
	public void setUserACLId(String userACLId) {
		this.userACLId = userACLId;
	}
	
	public String toString() {
	    return "userName: '" + this.userName + "', firstName: '" + this.firstName + "', lastName: '" + this.lastName + ","
	    + "emailId: '" + this.emailId + "', phoneNumber: '" + this.phoneNumber + "', status: '" + this.status + ","
	    + "message: '" + this.message + "', userGroupId: '" + this.userGroupId + "', userACLId: '" + this.userACLId + ","
	    +(this.objUserGroupModel == null ? " " :  "UserGroupModel Details: '" +objUserGroupModel.toString()) + ","
	    +(this.objUserACLDetailsModel == null ? " " :  "UserACLDetailsModel Details: '" +objUserACLDetailsModel.toString()); 
	}
	/**
	 * @return the oldPassword
	 */
	public String getOldPassword() {
		return oldPassword;
	}
	/**
	 * @param oldPassword the oldPassword to set
	 */
	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}
	/**
	 * @return the newPassword
	 */
	public String getNewPassword() {
		return newPassword;
	}
	/**
	 * @param newPassword the newPassword to set
	 */
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	} 
	
	}

