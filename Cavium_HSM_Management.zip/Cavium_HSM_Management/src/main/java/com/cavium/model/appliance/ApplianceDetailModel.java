package com.cavium.model.appliance;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.cavium.model.partition.PartitionDetailModel;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
/**
 *  * @author MK00497144
 *  Class is used as a bean entity for Appliance and Partition associations 
 */
 
@Entity
@Table(name = "appliance_details")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class ApplianceDetailModel implements Serializable {

	private static final long serialVersionUID = -3840562434180092945L;

	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "appliance_id", nullable = false)
	private Long applianceId;
	@Column(name = "appliance_name")
	private String applianceName;
	@Column(name = "appliance_status")
	private String applianceStatus;
	@Column(name = "serial_number")
	private String serialNumber;
	@Column(name = "network_timezone")
	private String networkTimezone;
	@Column(name = "gateway_ip")
	private String gatewayIp;
	@Column(name = "ip_address")
	private String ipAddress;
	@Column(name = "subnet_mask")
	private String subnetMask;
	@Column(name = "network_mode")
	private String networkMode;
	@Column(name = "network_id")
	private String networkId;
	@Column(name = "hostname")
	private String hostName;
	@Column(name = "device_added_by_user")
	private String deviceAddedByUser;
	@Column(name = "operation_performed")
	private String operationPerformed;
	@Column(name = "ipmi_ip")
	private String ipmiIp;
	@Column(name = "user_name")
	private String userName;

	@Column(name = "user_password")
	private String userPassword;
	
	@JsonManagedReference
	@OneToMany(fetch = FetchType.LAZY,mappedBy="applianceDetailModel",cascade = CascadeType.ALL)
	private List<PartitionDetailModel> partitionDetailModels;
	
	
	@Transient
	private String code;
	@Transient
	private String message;
	
	@Column(name = "created_date", columnDefinition = "DATETIME")
	private Date createdDate;
	@Column(name = "modified_date", columnDefinition = "DATETIME")
	private Date modifiedDate;
	@Column(name = "created_by")
	private String createdBy;
	@Column(name = "modified_by")
	private String modifiedBy;
	@Column(name = "authid")
	private String authId;
	
	@Column(name = "city_name")
	private String cityName;

	/**
	 * @return the cityName
	 */
	public String getCityName() {
		return cityName;
	}

	/**
	 * @param cityName the cityName to set
	 */
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public Long getApplianceId() {
		return applianceId;
	}

	public void setApplianceId(Long applianceId) {
		this.applianceId = applianceId;
	}

	public String getApplianceName() {
		return applianceName;
	}

	public void setApplianceName(String applianceName) {
		this.applianceName = applianceName;
	}

	public String getApplianceStatus() {
		return applianceStatus;
	}

	public void setApplianceStatus(String applianceStatus) {
		this.applianceStatus = applianceStatus;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getNetworkTimezone() {
		return networkTimezone;
	}

	public void setNetworkTimezone(String networkTimezone) {
		this.networkTimezone = networkTimezone;
	}

	public String getGatewayIp() {
		return gatewayIp;
	}

	public void setGatewayIp(String gatewayIp) {
		this.gatewayIp = gatewayIp;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public String getSubnetMask() {
		return subnetMask;
	}

	public void setSubnetMask(String subnetMask) {
		this.subnetMask = subnetMask;
	}

	public String getNetworkMode() {
		return networkMode;
	}

	public void setNetworkMode(String networkMode) {
		this.networkMode = networkMode;
	}

	public String getHostName() {
		return hostName;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	public String getDeviceAddedByUser() {
		return deviceAddedByUser;
	}

	public void setDeviceAddedByUser(String deviceAddedByUser) {
		this.deviceAddedByUser = deviceAddedByUser;
	}

	public String getOperationPerformed() {
		return operationPerformed;
	}

	public void setOperationPerformed(String operationPerformed) {
		this.operationPerformed = operationPerformed;
	}

	public String getIpmiIp() {
		return ipmiIp;
	}

	public void setIpmiIp(String ipmiIp) {
		this.ipmiIp = ipmiIp;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public List<PartitionDetailModel> getPartitionDetailModels() {
		return partitionDetailModels;
	}

	public void setPartitionDetailModels(List<PartitionDetailModel> partitionDetailModels) {
		this.partitionDetailModels = partitionDetailModels;
	}

	public String getNetworkId() {
		return networkId;
	}

	public void setNetworkId(String networkId) {
		this.networkId = networkId;
	}
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	
	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getAuthId() {
		return authId;
	}

	public void setAuthId(String authId) {
		this.authId = authId;
	}
	
	
}
