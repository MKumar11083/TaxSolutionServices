package com.cavium.model.user;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.cavium.model.partition.NetworkStatsModel;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

/*
 * PartitionNetworkStatsModel Model class hold the relationship between Partition and Network Stats.
 * author : RK00490847
 */
@Entity
@Table(name="partition_network_stats")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class PartitionNetworkStatsModel
implements Serializable
{
	private static final long serialVersionUID = 4692301322760007284L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	@Column(name="partition_id")
	@JsonProperty(access = Access.WRITE_ONLY)
	private Long partitionId;
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "network_stats_id",nullable = false)
	private NetworkStatsModel networkStatsModel;
	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * @return the partitionId
	 */
	public Long getPartitionId() {
		return partitionId;
	}
	/**
	 * @param partitionId the partitionId to set
	 */
	public void setPartitionId(Long partitionId) {
		this.partitionId = partitionId;
	}
	/**
	 * @return the networkStatsModel
	 */
	public NetworkStatsModel getNetworkStatsModel() {
		return networkStatsModel;
	}
	/**
	 * @param networkStatsModel the networkStatsModel to set
	 */
	public void setNetworkStatsModel(NetworkStatsModel networkStatsModel) {
		this.networkStatsModel = networkStatsModel;
	}
	
}
