package com.cavium.model.partition;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
/**
 *  * @author MK00497144
 * Class is used as a partition entity having association with Appliance entity
 */
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Table(name = "partition_details")
public class PartitionDetailModel implements Serializable {

	private static final long serialVersionUID = -3840562434180092945L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "partition_id", nullable = false)
	private Long partitionId;
	@Column(name = "partition_name")
	private String partitionName;
	@Column(name = "partition_type")
	private String partitionType;
	@Column(name = "partition_total_space")
	private String partitionSize;
	@Column(name = "partition_availble_space")
	private String partitionAvailableSize;
	@Column(name = "partition_used_space")
	private String partitionUsedSize;
	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name = "appliance_id", nullable = false)
	@JsonBackReference
	private ApplianceDetailModel applianceDetailModel;
	

	public Long getPartitionId() {
		return partitionId;
	}

	public void setPartitionId(Long partitionId) {
		this.partitionId = partitionId;
	}

	public String getPartitionType() {
		return partitionType;
	}

	public void setPartitionType(String partitionType) {
		this.partitionType = partitionType;
	}

	public String getPartitionSize() {
		return partitionSize;
	}

	public void setPartitionSize(String partitionSize) {
		this.partitionSize = partitionSize;
	}
	public String getPartitionAvailableSize() {
		return partitionAvailableSize;
	}

	public void setPartitionAvailableSize(String partitionAvailableSize) {
		this.partitionAvailableSize = partitionAvailableSize;
	}

	public String getPartitionUsedSize() {
		return partitionUsedSize;
	}

	public void setPartitionUsedSize(String partitionUsedSize) {
		this.partitionUsedSize = partitionUsedSize;
	}

	public ApplianceDetailModel getApplianceDetailModel() {
		return applianceDetailModel;
	}

	public void setApplianceDetailModel(ApplianceDetailModel applianceDetailModel) {
		this.applianceDetailModel = applianceDetailModel;
	}

	public String getPartitionName() {
		return partitionName;
	}

	public void setPartitionName(String partitionName) {
		this.partitionName = partitionName;
	}
	
}
