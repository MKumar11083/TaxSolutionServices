package com.cavium.model.appliance;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.cavium.model.partition.NetworkStatsModel;
import com.cavium.model.partition.PartitionDetailModel;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "initialize")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class InitializeApplianceDetailModel implements Serializable {
	private static final long serialVersionUID = -2649451575105269731L;
	/**
	 * 
	 */

	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "initialize_id", nullable = false)
	private Long initialize_id;
	@Transient
	private String userName;
	@Transient
	private String password;
	@Column(name = "crypto_officer_name")
	private String cryptoOfficerName;
	@Column(name = "crypto_officer_password")
	private String cryptoOfficerPassword;
	@Column(name = "confirm_crypto_officer_password")
	private String confirmCryptoOfficerpassword;
	@Column(name = "authentication_level")
	private Integer authenticationLevel;
	@Column(name = "fips_state")
	private Integer fipsState;
	@Column(name = "cert_authentication")
	private Integer certAuthentication;

	@Column(name = "login_failure_count")
	private Integer loginFailureCount;

	@Column(name = "minimum_password_length")
	private Integer minimumPasswordLength;

	@Column(name = "maximum_password_length")
	private Integer maximumPasswordLength;

	@Column(name = "hsm_label")
	private String hsmLabel;

	 
	@Column(name = "hsm_audit_log")
	private Integer hsmAuditLog;

	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "appliance_id",nullable = false)	
	private ApplianceDetailModel applianceDetailModel;
	
	@JsonManagedReference
	@OneToOne(fetch = FetchType.LAZY,mappedBy="initializeApplianceDetailModel",cascade = CascadeType.ALL)
	private DualFactorAuthDetailModel dualFactorAuthDetailModel;
 
  
	@JsonManagedReference
	@OneToMany(fetch = FetchType.LAZY,mappedBy="initializeApplianceDetailModel",cascade = CascadeType.ALL)
	private List<NetworkStatsModel> networkStatsModels;

	 
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the cryptoOfficerName
	 */
	public String getCryptoOfficerName() {
		return cryptoOfficerName;
	}

	/**
	 * @param cryptoOfficerName the cryptoOfficerName to set
	 */
	public void setCryptoOfficerName(String cryptoOfficerName) {
		this.cryptoOfficerName = cryptoOfficerName;
	}

	/**
	 * @return the cryptoOfficerPassword
	 */
	public String getCryptoOfficerPassword() {
		return cryptoOfficerPassword;
	}

	/**
	 * @param cryptoOfficerPassword the cryptoOfficerPassword to set
	 */
	public void setCryptoOfficerPassword(String cryptoOfficerPassword) {
		this.cryptoOfficerPassword = cryptoOfficerPassword;
	}

	/**
	 * @return the confirmCryptoOfficerpassword
	 */
	public String getConfirmCryptoOfficerpassword() {
		return confirmCryptoOfficerpassword;
	}

	/**
	 * @param confirmCryptoOfficerpassword the confirmCryptoOfficerpassword to set
	 */
	public void setConfirmCryptoOfficerpassword(String confirmCryptoOfficerpassword) {
		this.confirmCryptoOfficerpassword = confirmCryptoOfficerpassword;
	}

	/**
	 * @return the authenticationLevel
	 */
	public Integer getAuthenticationLevel() {
		return authenticationLevel;
	}

	/**
	 * @param authenticationLevel the authenticationLevel to set
	 */
	public void setAuthenticationLevel(Integer authenticationLevel) {
		this.authenticationLevel = authenticationLevel;
	}

	/**
	 * @return the fipsState
	 */
	public Integer getFipsState() {
		return fipsState;
	}

	/**
	 * @param fipsState the fipsState to set
	 */
	public void setFipsState(Integer fipsState) {
		this.fipsState = fipsState;
	}

	/**
	 * @return the certAuthentication
	 */
	public Integer getCertAuthentication() {
		return certAuthentication;
	}

	/**
	 * @param certAuthentication the certAuthentication to set
	 */
	public void setCertAuthentication(Integer certAuthentication) {
		this.certAuthentication = certAuthentication;
	}

	/**
	 * @return the loginFailureCount
	 */
	public Integer getLoginFailureCount() {
		return loginFailureCount;
	}

	/**
	 * @param loginFailureCount the loginFailureCount to set
	 */
	public void setLoginFailureCount(Integer loginFailureCount) {
		this.loginFailureCount = loginFailureCount;
	}

	/**
	 * @return the minimumPasswordLength
	 */
	public Integer getMinimumPasswordLength() {
		return minimumPasswordLength;
	}

	/**
	 * @param minimumPasswordLength the minimumPasswordLength to set
	 */
	public void setMinimumPasswordLength(Integer minimumPasswordLength) {
		this.minimumPasswordLength = minimumPasswordLength;
	}

	/**
	 * @return the maximumPasswordLength
	 */
	public Integer getMaximumPasswordLength() {
		return maximumPasswordLength;
	}

	/**
	 * @param maximumPasswordLength the maximumPasswordLength to set
	 */
	public void setMaximumPasswordLength(Integer maximumPasswordLength) {
		this.maximumPasswordLength = maximumPasswordLength;
	}

	/**
	 * @return the hsmLabel
	 */
	public String getHsmLabel() {
		return hsmLabel;
	}

	/**
	 * @param hsmLabel the hsmLabel to set
	 */
	public void setHsmLabel(String hsmLabel) {
		this.hsmLabel = hsmLabel;
	}

	/**
	 * @return the hsmAuditLog
	 */
	public Integer getHsmAuditLog() {
		return hsmAuditLog;
	}

	/**
	 * @param hsmAuditLog the hsmAuditLog to set
	 */
	public void setHsmAuditLog(Integer hsmAuditLog) {
		this.hsmAuditLog = hsmAuditLog;
	}

	/**
	 * @return the applianceDetailModel
	 */
	public ApplianceDetailModel getApplianceDetailModel() {
		return applianceDetailModel;
	}

	/**
	 * @param applianceDetailModel the applianceDetailModel to set
	 */
	public void setApplianceDetailModel(ApplianceDetailModel applianceDetailModel) {
		this.applianceDetailModel = applianceDetailModel;
	}

	/**
	 * @return the dualFactorAuthDetailModel
	 */
	public DualFactorAuthDetailModel getDualFactorAuthDetailModel() {
		return dualFactorAuthDetailModel;
	}

	/**
	 * @param dualFactorAuthDetailModel the dualFactorAuthDetailModel to set
	 */
	public void setDualFactorAuthDetailModel(DualFactorAuthDetailModel dualFactorAuthDetailModel) {
		this.dualFactorAuthDetailModel = dualFactorAuthDetailModel;
	}

	/**
	 * @return the networkStatsModels
	 */
	public List<NetworkStatsModel> getNetworkStatsModels() {
		return networkStatsModels;
	}

	/**
	 * @param networkStatsModels the networkStatsModels to set
	 */
	public void setNetworkStatsModels(List<NetworkStatsModel> networkStatsModels) {
		this.networkStatsModels = networkStatsModels;
	}
	 
}
