package com.cavium.model.appliance;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.sql.Blob;


@Entity
@Table(name="dual_factor_auth")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class DualFactorAuthDetailModel implements Serializable {
	private static final long serialVersionUID = 8893200516025118371L;
 
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	@Column(name="dual_factor_auth_server_address")
	private String dualFactorAuthServerAddress;
	@Column(name="dual_factor_auth_server_port_no")
	private String dualFactorAuthServerPortNo;
	@Column(name="dual_factor_auth_server_certificate")
	private Blob dualFactorAuthServerCertificate;
	
	@OneToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name = "initialize_id", nullable = false)
	@JsonBackReference
	private InitializeApplianceDetailModel initializeApplianceDetailModel;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getDualFactorAuthServerAddress() {
		return dualFactorAuthServerAddress;
	}
	public void setDualFactorAuthServerAddress(String dualFactorAuthServerAddress) {
		this.dualFactorAuthServerAddress = dualFactorAuthServerAddress;
	}
	public String getDualFactorAuthServerPortNo() {
		return dualFactorAuthServerPortNo;
	}
	public void setDualFactorAuthServerPortNo(String dualFactorAuthServerPortNo) {
		this.dualFactorAuthServerPortNo = dualFactorAuthServerPortNo;
	}
	public Blob getDualFactorAuthServerCertificate() {
		return dualFactorAuthServerCertificate;
	}
	public void setDualFactorAuthServerCertificate(Blob dualFactorAuthServerCertificate) {
		this.dualFactorAuthServerCertificate = dualFactorAuthServerCertificate;
	}
	public InitializeApplianceDetailModel getInitializeApplianceDetailModel() {
		return initializeApplianceDetailModel;
	}
	public void setInitializeApplianceDetailModel(InitializeApplianceDetailModel initializeApplianceDetailModel) {
		this.initializeApplianceDetailModel = initializeApplianceDetailModel;
	}
	
}
