package com.cavium;

import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.app.VelocityEngine;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.Scope;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.client.RestTemplate;

import com.cavium.utill.CuratorResponseModel;


/*MK00497144
 * This class is used to configure the spring boot framework
 * */
@SpringBootApplication
@PropertySource({"classpath:applicationMessages.properties","classpath:mail.properties"})
@EnableTransactionManagement
public class Application extends SpringBootServletInitializer {
	private Logger logger = LogManager.getLogger(this.getClass());

	@Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		logger.info("Welcome to the Spring Boot Project");
        return application.sources(Application.class);
        
    }
	
  /*  public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }*/
    
	/*
	 * This method is used to encrypt the password
	 * */
	
    @Bean
	public BCryptPasswordEncoder passwordEncoder() {
	    return new BCryptPasswordEncoder();
	}
   

    @Bean
    public VelocityEngine getVelocityEngine() throws  Exception {
        Properties properties = new Properties();
        properties.setProperty("input.encoding", "UTF-8");
        properties.setProperty("output.encoding", "UTF-8");
        properties.setProperty("resource.loader", "class");
        properties.setProperty("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
        VelocityEngine velocityEngine = new VelocityEngine(properties);
        return velocityEngine;
    } 
    
    @Bean
	public RestTemplate getRestTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}
    
    @Bean
    public ResourceBundleMessageSource messageSource() {
        ResourceBundleMessageSource source = new ResourceBundleMessageSource();
        source.setBasename("applicationMessages");
        source.setUseCodeAsDefaultMessage(true);
        return source;
    }
    
  
    
    @Bean
    @Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
    public CuratorResponseModel curatorResponseModel() {
        return new CuratorResponseModel();
    }
   
}
