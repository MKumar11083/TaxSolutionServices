package com.cavium.service.appliance;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.appliance.InitializeApplianceDetailModel;
import com.cavium.model.partition.NetworkStatsModel;
import com.cavium.model.partition.PartitionDetailModel;
import com.cavium.model.user.DesignationApplianceModel;
import com.cavium.model.user.UserDetailModel;
import com.cavium.model.user.UserGroupModel;
import com.cavium.pojo.ApplianceInfo;
import com.cavium.pojo.HSMInfo;
import com.cavium.pojo.UserAttributes;
import com.cavium.pojo.AdminHostinfo.Data;
import com.cavium.pojo.AdminHostinfo.DrvReqIdQueue;
import com.cavium.pojo.AdminHostinfo.FwReqIdQueue;
import com.cavium.pojo.AdminHostinfo.HostStats;
import com.cavium.pojo.AdminHostinfo.RamStats;
import com.cavium.pojo.AdminHostinfo.RxQueue;
import com.cavium.pojo.AdminHostinfo.SwapStats;
import com.cavium.pojo.AdminHostinfo.SystemUpTime;
import com.cavium.pojo.AdminHostinfo.TxQueue;
import com.cavium.pojo.AdminHostinfo.Vmstats;
import com.cavium.repository.appliance.ApplianceRepository;
import com.cavium.repository.appliance.DesignationAppliance;
import com.cavium.repository.appliance.InitializeRepository;
import com.cavium.repository.appliance.NetworkStatsRepository;
import com.cavium.repository.user.DesignationApplianceRepository;
import com.cavium.repository.user.UserGroupRepository;
import com.cavium.repository.user.UserRepository;
import com.cavium.service.recentactivity.RecentActivityServiceImpl;
import com.cavium.utill.CuratorResponseModel;
import com.cavium.utill.CuratorUtil;
import com.cavium.utill.RestClient;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
/**
 *  * @author MK00497144
 *  Class is used as a service implementation for Appliance Management
 */
@Component
public class ApplianceServiceImpl implements ApplianceService {
	private Logger logger = Logger.getLogger(this.getClass());

	/**
	 * ApplicationRepository - Repository class for perform Database operation on ApplicationDetailModel
	 */
	@Autowired
	private ApplianceRepository applianceRepository;
	
	
	@Autowired
	private InitializeRepository initializeRepository;
	
	@Autowired
	private NetworkStatsRepository networkStatsRepository;

	/**
	 * This class is used to set the response attributes for incoming requests
	 */
	@Lookup
	public CuratorResponseModel getCuratorResponseModel() {
		return null;
	}

	/**
	 * This Interface is used to get the values from the property file
	 */
	@Autowired
	Environment env;
	/*
	 * getAllAppliancesDetails method is used for fetch All appliances Details.
	 * 
	 * @return listApplianceDetailModel - List of ApplianceDetailModel Object.
	 * 
	 */

	@Autowired
	RestClient restClient;

	@Autowired
	DesignationAppliance designationAppliance;

	@Autowired
	UserGroupRepository userGroupRepository;

	@Autowired
	private UserAttributes userAttributes;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private RecentActivityServiceImpl recentActivityServiceImpl;

	@Autowired
	private DesignationApplianceRepository designationApplianceRepository;


	@Override
	@Transactional
	public List<ApplianceDetailModel> getListOfAppliances() {
		List<ApplianceDetailModel> listApplianceDetailModel = null;
		CuratorResponseModel responseModel=getCuratorResponseModel();
		try {	
			listApplianceDetailModel = applianceRepository.findAll();
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured due to db error inside getListOfAppliances Method of class ApplianceServiceImpl ::" + e.getMessage());
			responseModel.setResponseCode("500");
			responseModel.setResponseMessage(env.getProperty("applianceList.failureDB"));
		}
		return listApplianceDetailModel;
	}


	@Override
	@Transactional
	public CuratorResponseModel createAppliance(List<ApplianceDetailModel> applianceDetailModel) {

		// TODO Auto-generated method stub
		CuratorResponseModel responseModel=getCuratorResponseModel();
		try {
			if (applianceDetailModel != null && applianceDetailModel.size() > 0) {
				String loggedInUser = userAttributes.getlogInUserName();
				for(ApplianceDetailModel app : applianceDetailModel) {
					List<ApplianceDetailModel> isAvailable=applianceRepository.getApplianceExists(app.getIpAddress());
					if(isAvailable.isEmpty()) {
						app.setCreatedBy(loggedInUser);
						app.setCreatedDate(new Date());
						if(StringUtils.isEmpty(app.getAuthId())) {
							app.setAuthId("1234");
						}
						ApplianceDetailModel ap=applianceRepository.save(app);
						if(app!=null) {
							List<UserGroupModel> usg=userGroupRepository.findGroupDetailsForGroupName(env.getProperty("user.defaultusergroup")); 
							if(!usg.isEmpty()) {
								UserGroupModel userGroupModel=(UserGroupModel)usg.get(0);
								DesignationApplianceModel designationApplianceModel=new DesignationApplianceModel();
								designationApplianceModel.setDesignationId(userGroupModel.getId());
								designationApplianceModel.setObjApplianceDetailModel(ap);
								designationAppliance.save(designationApplianceModel);
							}
						}
						responseModel.setResponseCode("200");
						responseModel.setResponseMessage(env.getProperty("applianceCreation.success"));
						recentActivityServiceImpl.createRecentActivity(loggedInUser, "A new device "+app.getApplianceName()+" added by "+loggedInUser+"");
					}else {
						responseModel.setResponseCode("409");
						responseModel.setResponseMessage(env.getProperty("applianceCreation.failureExist"));
					}
				}
			} else {
				logger.error("ApplianceDetailModel is empty or null ::");
				responseModel.setResponseCode("204");
				responseModel.setResponseMessage(env.getProperty("applianceCreation.failureEmpty"));
			}
		} catch (Exception e) {
			logger.error("Error occured due to db error inside createAppliance Method of class ApplianceServiceImpl ::" + e.getMessage());
			responseModel.setResponseCode("500");
			responseModel.setResponseMessage(env.getProperty("applianceCreation.failureDB"));
		}
		return responseModel;
	}

	/*
	 * This method is used to modify the appliance 
	 * (non-Javadoc)
	 * @see com.cavium.service.appliance.ApplianceService#modifyAppliance(java.lang.String, com.cavium.model.appliance.ApplianceDetailModel)
	 */
	@Override
	@Transactional
	public CuratorResponseModel modifyAppliance(String loggedInUser, ApplianceDetailModel applianceDetailModel) {
		CuratorResponseModel responseModel=getCuratorResponseModel();
		try	{
			if(applianceDetailModel!=null && applianceDetailModel.getApplianceId()!=null && applianceDetailModel.getApplianceId().longValue() > 0) {
				ApplianceDetailModel applianceDetailFromDBModel=applianceRepository.findOne(applianceDetailModel.getApplianceId());
				if(applianceDetailFromDBModel!=null && applianceDetailFromDBModel.getApplianceId().longValue() > 0) {
					applianceDetailFromDBModel.setApplianceName(applianceDetailModel.getApplianceName());
					applianceDetailFromDBModel.setApplianceStatus(applianceDetailModel.getApplianceStatus());
					applianceDetailFromDBModel.setGatewayIp(applianceDetailModel.getGatewayIp());
					applianceDetailFromDBModel.setIpAddress(applianceDetailModel.getIpAddress());
					applianceDetailFromDBModel.setNetworkMode(applianceDetailModel.getNetworkMode());
					applianceDetailFromDBModel.setModifiedBy(loggedInUser);
					applianceDetailFromDBModel.setModifiedDate(new Date());
					if(!applianceDetailModel.getPartitionDetailModels().isEmpty()) {
						List<PartitionDetailModel> partitionResquestDetailModel=applianceDetailModel.getPartitionDetailModels();
						List<PartitionDetailModel> partitionDBDetailModel=applianceDetailFromDBModel.getPartitionDetailModels();
						int count=0;
						for(PartitionDetailModel db : partitionDBDetailModel){
							PartitionDetailModel req=partitionResquestDetailModel.get(count);
							db.setPartitionAvailableSize(req.getPartitionAvailableSize());
							db.setPartitionType(req.getPartitionType());
							count++;
						}
					}
					applianceRepository.save(applianceDetailFromDBModel);
					responseModel.setResponseCode("200");
					responseModel.setResponseMessage(env.getProperty("applianceModification.success"));
					recentActivityServiceImpl.createRecentActivity(loggedInUser, "Device "+applianceDetailFromDBModel.getApplianceName()+" modified by "+loggedInUser+" ");
				}else {
					responseModel.setResponseCode("409");
					responseModel.setResponseMessage(env.getProperty("applianceModification.failureNotExist"));
				}
			}

		}catch (Exception e) {
			logger.error("Error occured during Appliance modification :: "+ e.getMessage());
			responseModel.setResponseCode("-230");
			responseModel.setResponseMessage("Failed to execute the request at the backend");	 
		}
		return responseModel;	 
	}

	/**
	 * Method is used to delete the particular appliance
	 */
	@Override
	@Transactional
	public CuratorResponseModel deleteAppliance(String applianceID) {
		CuratorResponseModel responseModel=getCuratorResponseModel();
		try {
			ApplianceDetailModel appliance=applianceRepository.findOne(Long.parseLong(applianceID));
			if(appliance!=null) { 
				designationApplianceRepository.deleteApplianceFromDesignationAppliance(appliance);
				String loggedInUser = userAttributes.getlogInUserName();
				applianceRepository.delete(Long.parseLong(applianceID));
				responseModel.setResponseCode("200");
				responseModel.setResponseMessage(env.getProperty("applianceDeletion.success"));
				recentActivityServiceImpl.createRecentActivity(loggedInUser, "Device "+appliance.getApplianceName()+" deleted by "+loggedInUser+" ");
			}else {
				responseModel.setResponseCode("409");
				responseModel.setResponseMessage(env.getProperty("applianceDeletion.failureNotExist"));
			} 
		} catch (Exception e) {
			logger.error("Error occured due to db error inside deleteAppliance Method of class ApplianceServiceImpl ::"
					+ e.getMessage());
			responseModel.setResponseCode("500");
			responseModel.setResponseMessage(env.getProperty("applianceDeletion.failureDB"));
		}
		return responseModel; 
	}

	/***
	 * This method is used to validate the appliance whether exists or not
	 */
	@Override
	public ApplianceDetailModel validateAppliance(ApplianceDetailModel applianceDetailModel) {
		// TODO Auto-generated method stub
		try {
			List<ApplianceDetailModel> isAvailable=applianceRepository.getApplianceExists(applianceDetailModel.getIpAddress());
			if(isAvailable.isEmpty()) {
				ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/appliance_info");
				if(response!=null && response.getStatusCode().name().equals("OK")) {
					// Appliance can be add to list
					applianceDetailModel.setCode("200");
					applianceDetailModel.setMessage("Success");
				}else {
					applianceDetailModel.setCode("409");
					applianceDetailModel.setMessage(env.getProperty("appliance.notexists.cavium.network"));
					// Appliance not found hence can't add to list
				}
			}else {
				applianceDetailModel.setCode("409");
				applianceDetailModel.setMessage(env.getProperty("applianceCreation.failureExist"));
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Error occured during appliance validation.. into validateAppliance of class ApplianceServiceIMPL");
		}
		return applianceDetailModel;
	}

	/***
	 * This method is used to get appliance by id.
	 */
	@Override
	public ApplianceDetailModel getApplianceById(String applianceID) {
		// TODO Auto-generated method stub
		ApplianceDetailModel applianceDetailModel = null;
		CuratorResponseModel responseModel=getCuratorResponseModel();
		try {	
			applianceDetailModel = applianceRepository.findOne(Long.parseLong(applianceID));
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured due to db error inside getListOfAppliances Method of class ApplianceServiceImpl ::" + e.getMessage());
			responseModel.setResponseCode("500");
			responseModel.setResponseMessage(env.getProperty("applianceList.failureDB"));
		}
		return applianceDetailModel;
	}

	/***
	 * This method is used to get appliance by id.
	 */
	@Override
	public List<ApplianceDetailModel> listOfApplianceByGroupId(String loggedInUser) {
		// TODO Auto-generated method stub
		List<ApplianceDetailModel>  applianceDetailModel = null;
		CuratorResponseModel responseModel=getCuratorResponseModel();
		try {
			UserDetailModel objUserDetailModel=userRepository.findOne(loggedInUser);
			if(objUserDetailModel!=null && objUserDetailModel.getObjUserACLDetailsModel().getAclName().equals(env.getProperty("user.superadmin"))) {
				applianceDetailModel = applianceRepository.findAll();
			}else {
				applianceDetailModel = applianceRepository.getListOfApplianceByGroupId(loggedInUser);
			}

		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured due to db error inside getListOfAppliances Method of class ApplianceServiceImpl ::" + e.getMessage());
			responseModel.setResponseCode("500");
			responseModel.setResponseMessage(env.getProperty("applianceList.failureDB"));
		}
		return applianceDetailModel;
	}

	/***
	 * This method is used to reboot the appliance and update last operation performed column in db
	 */

	@Override
	public List<ApplianceDetailModel> rebootAppliance(List<ApplianceDetailModel> applianceDetailModellist) {
		// TODO Auto-generated method stub

		// TODO Auto-generated method stub
		String loggedInUser = userAttributes.getlogInUserName();
		List<ApplianceDetailModel> resonseList=new ArrayList<ApplianceDetailModel>();
		try {
			if(applianceDetailModellist.size() > 0) {
				Iterator<ApplianceDetailModel> itr=applianceDetailModellist.iterator();
				while(itr.hasNext()) {
					ApplianceDetailModel app=(ApplianceDetailModel)itr.next();
					ApplianceDetailModel dbAppliance=applianceRepository.findOne(app.getApplianceId()); 
					if(dbAppliance!=null) {

						/*MultiValueMap json = new MultiValueMa
						json.add("username", app.getUserName());
						json.add("password", app.getUserPassword());*/
						MultiValueMap<String, String> body = new LinkedMultiValueMap<String, String>();     
						body.add("username", app.getUserName());
						body.add("password", app.getUserPassword());
						ResponseEntity<String> response=restClient.invokePOSTMethod("https://"+app.getIpAddress()+"/liquidsa/admin_vm_reboot", body);

						if(response!=null && response.getBody().contains("success")) { 
							dbAppliance.setOperationPerformed(env.getProperty("appliance.reboot"));
							applianceRepository.save(dbAppliance);
							app.setOperationPerformed(env.getProperty("appliance.reboot"));
							app.setCode("200");
							app.setMessage(env.getProperty("appliance.reboot.success"));
							recentActivityServiceImpl.createRecentActivity(loggedInUser, "Device "+app.getApplianceName()+" rebooted by "+loggedInUser+" ");
						}else {
							app.setCode("409");
							app.setMessage(env.getProperty("appliance.notexists.cavium.network"));
						}
					}else {
						app.setCode("409");
						app.setMessage(env.getProperty("appliance.notexists.cavium"));
					}
					resonseList.add(app);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Error occured during appliance validation.. into validateAppliance of class ApplianceServiceIMPL");
		}
		return resonseList;
	}

	/***
	 * This method is used to reboot the appliance and update last operation performed column in db
	 */
	@Override
	public List<ApplianceDetailModel> zeroizeAppliance(List<ApplianceDetailModel> applianceDetailModellist) {
		// TODO Auto-generated method stub
		List<ApplianceDetailModel> resonseList=new ArrayList<ApplianceDetailModel>();
		// TODO Auto-generated method stub
		try {
			if(applianceDetailModellist.size() > 0) {
				Iterator<ApplianceDetailModel> itr=applianceDetailModellist.iterator();
				while(itr.hasNext()) {
					ApplianceDetailModel app=(ApplianceDetailModel)itr.next();
					ApplianceDetailModel dbAppliance=applianceRepository.findOne(app.getApplianceId()); 
					if(dbAppliance!=null) {
						Map<String,String> map=new HashMap<>();
						map.put("username", app.getUserName());
						map.put("password", app.getUserPassword());
						JSONObject json = new JSONObject(); 
						json.put("mcoLoginInfo", map);

						ResponseEntity<String> response=restClient.invokePOSTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/zeroize",json);

						if(response!=null && response.getBody().contains("success")) { 
							dbAppliance.setOperationPerformed(env.getProperty("appliance.zeroize"));
							applianceRepository.save(dbAppliance);
							app.setOperationPerformed(env.getProperty("appliance.zeroize"));
							app.setCode("200");
							app.setMessage(env.getProperty("appliance.zeroize.success"));
						}else {
							app.setCode("409");
							app.setMessage(env.getProperty("appliance.notexists.cavium.network"));
						}	
					}else {
						app.setCode("409");
						app.setMessage(env.getProperty("appliance.notexists.cavium"));
					}
					resonseList.add(app);
				}
			}} catch (Exception e) {
				// TODO: handle exception
				logger.info("Error occured during appliance validation.. into validateAppliance of class ApplianceServiceIMPL");
			}
		return resonseList;
	}

	/***
	 * This method is used to reboot the appliance and update last operation performed column in db
	 */
	@Override
	public List<ApplianceDetailModel> applianceFirmwareUpgrade(List<ApplianceDetailModel> applianceDetailModellist) {
		// TODO Auto-generated method stub
		List<ApplianceDetailModel> resonseList=new ArrayList<ApplianceDetailModel>();
		// TODO Auto-generated method stub
		try {
			if(applianceDetailModellist.size() > 0) {
				Iterator<ApplianceDetailModel> itr=applianceDetailModellist.iterator();
				while(itr.hasNext()) {
					ApplianceDetailModel app=(ApplianceDetailModel)itr.next();
					ApplianceDetailModel dbAppliance=applianceRepository.findOne(app.getApplianceId()); 
					if(dbAppliance!=null) {

						JSONObject json = new JSONObject(); 
						json.put("username", app.getUserName());
						json.put("password", app.getUserPassword());
						ResponseEntity<String> response=restClient.invokePOSTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/firmware_upgrade", json);

						if(response!=null && response.getBody().contains("success")) { 
							dbAppliance.setOperationPerformed("rebooted");
							applianceRepository.save(dbAppliance);
							app.setOperationPerformed("firmwareupgarde");
							app.setCode("200");
							app.setMessage(env.getProperty("appliance.firmwareupgrade.success"));
						}else {
							app.setCode("409");
							app.setMessage(env.getProperty("appliance.notexists.cavium.network"));
						}
					}else {
						app.setCode("409");
						app.setMessage(env.getProperty("appliance.notexists.cavium"));
					}
					resonseList.add(app);
				}
			}} catch (Exception e) {
				// TODO: handle exception
				logger.info("Error occured during appliance validation.. into validateAppliance of class ApplianceServiceIMPL");
			}
		return resonseList;
	}

	/***
	 * This method is used to initilizeAppliance the appliance and update last operation performed column in db
	 */
	@Override
	@Transactional
	public ApplianceDetailModel initilizeAppliance(InitializeApplianceDetailModel initializeApplianceDetailModel) throws RuntimeException{
		// TODO Auto-generated method stub

		// TODO Auto-generated method stub
		ApplianceDetailModel dbAppliance=null;
			if(initializeApplianceDetailModel.getApplianceDetailModel()!=null){
				 dbAppliance=applianceRepository.findOne(initializeApplianceDetailModel.getApplianceDetailModel().getApplianceId());
				if(dbAppliance!=null) {
						dbAppliance.setOperationPerformed("initialize");
						dbAppliance.setCode("200");
						dbAppliance.setMessage("Appliance rebooted successfully");
					initializeApplianceDetailModel.setApplianceDetailModel(dbAppliance);
					initializeRepository.save(initializeApplianceDetailModel);
				//	applianceRepository.save(dbAppliance);
					JSONObject json = new JSONObject(); 
					Map<String,Object> initData= new HashMap<String,Object>();
					json.put("username",initializeApplianceDetailModel.getUserName());
					json.put("password",initializeApplianceDetailModel.getPassword());

					//	Map<String,String> certificateList= new HashMap<String, String>();
					//certificateList.put("c1", "uploaderFileID1");
					//certificateList.put("c2", "uploaderFileID2");
					//json.put("certificateList", certificateList);
					initData.put("cryptoOfficerName",initializeApplianceDetailModel.getCryptoOfficerName());
					initData.put("cryptoOfficerPassword",initializeApplianceDetailModel.getConfirmCryptoOfficerpassword());
					initData.put("authenticationLevel",initializeApplianceDetailModel.getAuthenticationLevel());
					initData.put("fipsState",initializeApplianceDetailModel.getFipsState());
					initData.put("hsmAuditLog",initializeApplianceDetailModel.getHsmAuditLog());
					initData.put("certAuth",initializeApplianceDetailModel.getCertAuthentication());
					initData.put("loginFailCount",initializeApplianceDetailModel.getLoginFailureCount());
					initData.put("certAuthentication",initializeApplianceDetailModel.getCertAuthentication());			
					initData.put("maxPasswordLength",initializeApplianceDetailModel.getMaximumPasswordLength());
					initData.put("minPasswordLength",initializeApplianceDetailModel.getMinimumPasswordLength());				
					initData.put("label",initializeApplianceDetailModel.getHsmLabel());
					if(initializeApplianceDetailModel.getDualFactorAuthDetailModel()!=null){
						initData.put("dfHostname",initializeApplianceDetailModel.getDualFactorAuthDetailModel().getDualFactorAuthServerAddress());
						initData.put("dfPort",initializeApplianceDetailModel.getDualFactorAuthDetailModel().getDualFactorAuthServerPortNo());
						//initData.put("dfCertificate", "");
					}

					Map<String,Object> eth0Map= new HashMap<String,Object>();
					Map<String,Object> eth1Map= new HashMap<String,Object>();

					Map<String,Map<String, Object>> networkStats= new HashMap<String, Map<String, Object>>();
					if(initializeApplianceDetailModel.getNetworkStatsModels()!=null && initializeApplianceDetailModel.getNetworkStatsModels().size()>0){

						for (Iterator<NetworkStatsModel> iterator = initializeApplianceDetailModel.getNetworkStatsModels().iterator(); iterator.hasNext();) {
							NetworkStatsModel networkStatsModel = (NetworkStatsModel) iterator.next();
							if("eth0".equals(networkStatsModel.getNetworkStatId())) {
								eth0Map.put("dhcp", networkStatsModel.isDhcp());
								eth0Map.put("ip",networkStatsModel.getIpAddress() );
								eth0Map.put("gateway",networkStatsModel.getGateway());
								eth0Map.put("subnet", networkStatsModel.getSubnet());
								eth0Map.put("vlan", networkStatsModel.getVlanId());
							}
							if("eth1".equals(networkStatsModel.getNetworkStatId())){
								eth1Map.put("dhcp", networkStatsModel.isDhcp());
								eth1Map.put("ip",networkStatsModel.getIpAddress() );
								eth1Map.put("gateway",networkStatsModel.getGateway());
								eth1Map.put("subnet", networkStatsModel.getSubnet());
								eth1Map.put("vlan", networkStatsModel.getVlanId());
								eth1Map.put("disableEth1", networkStatsModel.isDisableEth1());
							}						 
						}
					 }
					networkStats.put("eth0", eth0Map);
					networkStats.put("eth1", eth1Map);
					json.put("initData", initData);
					json.put("networkStats", networkStats);
					try{
					ResponseEntity<String> response=restClient.invokePOSTMethodForOperations("https://"+"10.89.7.150"+"/liquidsa/initialize", json);
					if(response!=null && response.getStatusCode().name().equals("OK")) {
						
					}else {
						dbAppliance.setCode("409");
						dbAppliance.setMessage("Appliance does not exists into the cavium networks");
						throw new RuntimeException("Appliance does not exists into the cavium networks");
					}
				}catch (Exception e) {
					throw new RuntimeException("error in connection with Cavium network");
				}
				}else {
					dbAppliance=initializeApplianceDetailModel.getApplianceDetailModel();
					dbAppliance.setCode("409");
					dbAppliance.setMessage("Appliance does not exists into the system");
				}
			}
		 
	 return dbAppliance;
	}

	/*
	 * This method is used to get AdminHost Details from Cavium REST API
	 * 
	 */
	public HostStats GetAdminHostStats(ApplianceDetailModel applianceDetailModel,HostStats hostStats){
		try{
			ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/admin_host_stats");
			if(response!=null && response.getStatusCode().name().equals("OK")) {
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						String status = root.path("status").asText();
						JsonNode errors = root.path("errors");
						String operation = root.path("operation").asText();
						String partitionName = root.path("partitionName").asText();
						long startTime = root.path("startTime").asLong();
						long endTime = root.path("endTime").asLong();
						String startDateTime=CuratorUtil.formatDatefromLong(startTime);
						String endDateTime=CuratorUtil.formatDatefromLong(endTime);
						String message = root.path("message").asText();
						String jobId = root.path("jobId").asText();
						JsonNode dataNode = root.path("data");
						hostStats.setStatus(status);
						hostStats.setEndTime(endDateTime);
						hostStats.setStartTime(startDateTime);
						hostStats.setOperation(operation);
						hostStats.setPartitionName(partitionName);
						hostStats.setMessage(message);
						hostStats.setJobId(jobId);						 
						if(!errors.isNull()){
							Iterator<JsonNode> itr = errors.elements();					         
							while (itr.hasNext()) {
								JsonNode temp = itr.next();
							}
						}
						if(!dataNode.isNull()){
							if(dataNode.has("vmstats")){
								Data data = new Data();
								hostStats.setDataObject(data);
								JsonNode vmstatsNode = dataNode.path("vmstats");
								if(!vmstatsNode.isNull()){
									Vmstats vmstats= new Vmstats();
									data.setVmstatsObject(vmstats);
									if(vmstatsNode.has("cavServerStatus")){										
										double cavServerStatus=vmstatsNode.path("cavServerStatus").asDouble();
										vmstats.setCavServerStatus(cavServerStatus);
									}
									if(vmstatsNode.has("systemUpTime")){										
										JsonNode systemUpTimeNode = vmstatsNode.path("systemUpTime");
										if(!systemUpTimeNode.isNull()){
											long totalSeconds=0;
											SystemUpTime systemUpTime= new SystemUpTime();
											vmstats.setSystemUpTimeObject(systemUpTime);
											if(systemUpTimeNode.has("hours")){
												long hours=systemUpTimeNode.path("hours").asLong();
												systemUpTime.setHours(hours);
												totalSeconds=totalSeconds+CuratorUtil.hoursToSeconds(hours);
											}
											if(systemUpTimeNode.has("minutes")){
												long minutes=systemUpTimeNode.path("minutes").asLong();
												systemUpTime.setMinutes(minutes);
												totalSeconds=totalSeconds+CuratorUtil.minutesToSeconds(minutes);
											}
											if(systemUpTimeNode.has("seconds")){
												long seconds=systemUpTimeNode.path("seconds").asLong();
												systemUpTime.setSeconds(seconds);
												totalSeconds=totalSeconds+seconds;
											}
											systemUpTime.setFormatedDate(CuratorUtil.timeInDaysHoursFormat(totalSeconds));
										}
									}
									if(vmstatsNode.has("rxQueue")){
										JsonNode rxQueueNode = vmstatsNode.path("rxQueue");
										if(!rxQueueNode.isNull()){
											RxQueue rxQueue= new RxQueue();
											vmstats.setRxQueueObject(rxQueue);
											if(rxQueueNode.has("rdt")){
												double rdt=rxQueueNode.path("rdt").asDouble();
												rxQueue.setRdt(rdt);
											}
											if(rxQueueNode.has("rdh")){
												double rdh=rxQueueNode.path("rdh").asDouble();
												rxQueue.setRdh(rdh);
											}						 
										}
									}
									if(vmstatsNode.has("drvReqIdQueue")){
										JsonNode drvReqIdQueueNode = vmstatsNode.path("drvReqIdQueue");
										if(!drvReqIdQueueNode.isNull()){
											DrvReqIdQueue drvReqIdQueue = new DrvReqIdQueue();
											vmstats.setDrvReqIdQueueObject(drvReqIdQueue);
											if(drvReqIdQueueNode.has("head")){
												double head=drvReqIdQueueNode.path("head").asDouble();
												drvReqIdQueue.setHead(head);
											}
											if(drvReqIdQueueNode.has("tail")){
												double tail=drvReqIdQueueNode.path("tail").asDouble();
												drvReqIdQueue.setTail(tail);
											}						 
										}
									}
									if(vmstatsNode.has("ramStats(mb)")){
										JsonNode ramStatsNode = vmstatsNode.path("ramStats(mb)");
										if(!ramStatsNode.isNull()){
											RamStats ramStats= new RamStats();
											vmstats.setRamStats(ramStats);
											if(ramStatsNode.has("total")){
												double total=ramStatsNode.path("total").asDouble();
												ramStats.setTotal(total);
											}
											if(ramStatsNode.has("free")){
												double free=ramStatsNode.path("free").asDouble();
												ramStats.setFree(free);
											}	
											ramStats.setUsed(ramStats.getTotal()-ramStats.getFree());
										}
									}		
									if(vmstatsNode.has("txQueue")){
										JsonNode txQueueNode = vmstatsNode.path("txQueue");
										if(!txQueueNode.isNull()){
											TxQueue txQueue= new TxQueue();
											vmstats.setTxQueueObject(txQueue);
											if(txQueueNode.has("tdh")){
												double tdh=txQueueNode.path("tdh").asDouble();
												txQueue.setTdh(tdh);
											}
											if(txQueueNode.has("tdt")){
												double tdt=txQueueNode.path("tdt").asDouble();
												txQueue.setTdt(tdt);
											}						 
										}
									}
									if(vmstatsNode.has("fwReqIdQueue")){
										JsonNode fwReqIdQueueNode = vmstatsNode.path("fwReqIdQueue");
										if(!fwReqIdQueueNode.isNull()){
											FwReqIdQueue fwReqIdQueue= new FwReqIdQueue();
											vmstats.setFwReqIdQueueObject(fwReqIdQueue);
											if(fwReqIdQueueNode.has("head")){
												double head=fwReqIdQueueNode.path("head").asDouble();
												fwReqIdQueue.setHead(head);
											}
											if(fwReqIdQueueNode.has("tail")){
												double tail=fwReqIdQueueNode.path("tail").asDouble();
												fwReqIdQueue.setTail(tail);
											}						 
										}
									}
									if(vmstatsNode.has("swapStats(mb)")){
										JsonNode swapStatsNode = vmstatsNode.path("swapStats(mb)");
										if(!swapStatsNode.isNull()){
											SwapStats swapStats= new SwapStats();
											vmstats.setSwapStats(swapStats);
											if(swapStatsNode.has("total")){
												double total=swapStatsNode.path("total").asDouble();
												swapStats.setTotal(total);
											}
											if(swapStatsNode.has("free")){
												double free=swapStatsNode.path("free").asDouble();
												swapStats.setFree(free);
											}						 
										}
									}							
									if(vmstatsNode.has("linkStatus(eth0)")){
										double linkStatusEth0=vmstatsNode.path("linkStatus(eth0)").asDouble();
										vmstats.setLinkStatusEth0(linkStatusEth0);
									}
									if(vmstatsNode.has("cpuUsage(%)")){
										double cpuUsage=vmstatsNode.path("cpuUsage(%)").asDouble();	
										vmstats.setCpuUsage(cpuUsage);
									}
									if(vmstatsNode.has("linkStatus(eth1)")){
										double linkStatusEth01=vmstatsNode.path("linkStatus(eth1)").asDouble();
										vmstats.setLinkStatusEth1(linkStatusEth01);
									}
									if(vmstatsNode.has("processCount")){
										double processCount=vmstatsNode.path("processCount").asDouble();
										vmstats.setProcessCount(processCount);
									}
									if(vmstatsNode.has("freeSpace(mb)")){
										double freeSpace=vmstatsNode.path("freeSpace(mb)").asDouble();
										vmstats.setFreeSpace(freeSpace);									 
									}
									if(vmstatsNode.has("driverStatus")){
										double driverStatus=vmstatsNode.path("driverStatus").asDouble();
										vmstats.setDriverStatus(driverStatus);							 
									}		
								}

							}
						}
					}
				}
			}
		}catch(Exception exp){
			logger.error("Error occured during fetch AdminHostStats Info of class ApplianceServiceImpl ::" + exp.getMessage());
		}
		return hostStats;
	}
	/*
	 * This method is used to get Appliance Information from Cavium REST API 
	 *
	 */
	public ApplianceInfo GetApplianceInfo(ApplianceDetailModel applianceDetailModel ,ApplianceInfo applianceInfo){
		try{
			ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/appliance_info");
			if(response!=null && response.getStatusCode().name().equals("OK")) {
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						String status = root.path("status").asText();
						JsonNode errors = root.path("errors");
						String operation = root.path("operation").asText();
						long startTime = root.path("startTime").asLong();
						long endTime = root.path("endTime").asLong();
						String startDateTime=CuratorUtil.formatDatefromLong(startTime);
						String endDateTime=CuratorUtil.formatDatefromLong(endTime);
						String message = root.path("message").asText();
						applianceInfo.setStatus(status);
						applianceInfo.setOperation(operation);
						applianceInfo.setStartTime(startDateTime);
						applianceInfo.setEndTime(endDateTime);
						applianceInfo.setErrorMessage(message);
						if(!errors.isNull()){
							Iterator<JsonNode> itr = errors.elements();					         
							while (itr.hasNext()) {
								JsonNode temp = itr.next();
								System.out.println(temp.asInt());        
							}
						}						
						JsonNode dataNode = root.path("data");
						if(!dataNode.isNull()){
							if(dataNode.has("linuxVersion")) {
								String linuxVersion = dataNode.path("linuxVersion").asText();
								applianceInfo.setLinuxVersion(linuxVersion);
							}
							if(dataNode.has("serialNum")) {
								String serialNum = dataNode.path("serialNum").asText();
								applianceInfo.setSerialNum(serialNum);
							}
							if(dataNode.has("firmwareVersion")) {
								String firmwareVersion = dataNode.path("firmwareVersion").asText();
								applianceInfo.setFirmwareVersion(firmwareVersion);
							}
						}
					}
				}
			}		
		}catch(Exception exp){
			logger.error("Error occured during fetch Appliance Info of class ApplianceServiceImpl ::" + exp.getMessage());	
		}
		return applianceInfo;
	}

	/*
	 * This method is used to get HSM Information from Cavium REST API 
	 *  
	 */

	public HSMInfo getHSMInfo(ApplianceDetailModel applianceDetailModel,HSMInfo objHSMInfo){
		try{

			ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/info");
			if(response!=null && response.getStatusCode().name().equals("OK")) {
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						String status = root.path("status").asText();
						JsonNode errors = root.path("errors");
						String operation = root.path("operation").asText();
						String partitionName = root.path("partitionName").asText();
						long startTime = root.path("startTime").asLong();
						long endTime = root.path("endTime").asLong();
						String startDateTime=CuratorUtil.formatDatefromLong(startTime);
						String endDateTime=CuratorUtil.formatDatefromLong(endTime);
						String message = root.path("message").asText();
						float jobId = root.path("jobId").floatValue();
						JsonNode dataNode = root.path("data");
						objHSMInfo.setStatus(status);
						objHSMInfo.setOperation(operation);
						objHSMInfo.setPartitionName(partitionName);
						objHSMInfo.setStartTime(startDateTime);
						objHSMInfo.setEndTime(endDateTime);
						objHSMInfo.setErrorMessage(message);
						objHSMInfo.setJobId(jobId);
						if(!errors.isNull()){
							Iterator<JsonNode> itr = errors.elements();					         
							while (itr.hasNext()) {
								JsonNode temp = itr.next();						      
							}
						}
						if(!dataNode.isNull()){
							if(dataNode.has("totalPublicMemory(KB)")) {
								double totalPublicMemory = dataNode.path("totalPublicMemory(KB)").asDouble();
								objHSMInfo.setTotalPublicMemory(totalPublicMemory);
							}
							if(dataNode.has("mwVersion")) {
								String mwVersion = dataNode.path("mwVersion").asText();
								objHSMInfo.setMwVersion(mwVersion);
							}
							if(dataNode.has("hardwareMinor")) {
								String hardwareMinor = dataNode.path("hardwareMinor").asText();
								objHSMInfo.setHardwareMinor(hardwareMinor);
							}
							if(dataNode.has("systemVendorId")) {
								String systemVendorId = dataNode.path("systemVendorId").asText();
								objHSMInfo.setSystemVendorId(systemVendorId);
							}
							if(dataNode.has("cuLoginFailure")) {
								double cuLoginFailure = dataNode.path("cuLoginFailure").asDouble();
								objHSMInfo.setCuLoginFailure(cuLoginFailure);
							}
							if(dataNode.has("rwSessionCount")) {
								double rwSessionCount = dataNode.path("rwSessionCount").asDouble();
								objHSMInfo.setRwSessionCount(rwSessionCount);
							}
							if(dataNode.has("coLoginFailure")) {
								double coLoginFailure = dataNode.path("coLoginFailure").asDouble();
								objHSMInfo.setCoLoginFailure(coLoginFailure);
							}
							if(dataNode.has("freePrivateMemory(KB)")) {
								double freePrivateMemory = dataNode.path("freePrivateMemory(KB)").asDouble();
								objHSMInfo.setFreePrivateMemory(freePrivateMemory);
							}
							if(dataNode.has("slaveConfig")) {
								String slaveConfig = dataNode.path("slaveConfig").asText();
								objHSMInfo.setSlaveConfig(slaveConfig);
							}
							if(dataNode.has("temperature")) {
								String temperature = dataNode.path("temperature").asText();
								objHSMInfo.setTemperature(temperature);
							}
							if(dataNode.has("firmwareMajor")) {
								String firmwareMajor = dataNode.path("firmwareMajor").asText();
								objHSMInfo.setFirmwareMajor(firmwareMajor);;
							}
							if(dataNode.has("label")) {
								String label = dataNode.path("label").asText();
								objHSMInfo.setLabel(label);
							}
							if(dataNode.has("subSystemId")) {
								String subSystemId = dataNode.path("subSystemId").asText();
								objHSMInfo.setSubSystemId(subSystemId);
							}
							if(dataNode.has("manufacturerId")) {
								String manufacturerId = dataNode.path("manufacturerId").asText();
								objHSMInfo.setManufacturerId(manufacturerId);
							}
							if(dataNode.has("masterConfig")) {
								String masterConfig = dataNode.path("masterConfig").asText();
								objHSMInfo.setMasterConfig(masterConfig);
							}
							if(dataNode.has("authenticationPath")) {
								double authenticationPath = dataNode.path("authenticationPath").asDouble();
								objHSMInfo.setAuthenticationPath(authenticationPath);

							}
							if(dataNode.has("classCode")) {
								double classCode = dataNode.path("classCode").asDouble();
								objHSMInfo.setClassCode(classCode);
							}
							if(dataNode.has("maxSessionCount")) {
								double maxSessionCount = dataNode.path("maxSessionCount").asDouble();
								objHSMInfo.setMaxSessionCount(maxSessionCount);
							}
							if(dataNode.has("manufacturerId")) {
								String manufacturerId = dataNode.path("manufacturerId").asText();
								objHSMInfo.setManufacturerId(manufacturerId);
							}
							if(dataNode.has("sessionCount")) {
								double sessionCount = dataNode.path("sessionCount").asDouble();
								objHSMInfo.setSessionCount(sessionCount);
							}
							if(dataNode.has("firmwareId")) {
								String firmwareId = dataNode.path("firmwareId").asText();
								objHSMInfo.setFirmwareId(firmwareId);
							}
							if(dataNode.has("maxRwSessionCount")) {
								double maxRwSessionCount = dataNode.path("maxRwSessionCount").asDouble();
								objHSMInfo.setMaxRwSessionCount(maxRwSessionCount);
							}
							if(dataNode.has("buildNumber")) {
								String buildNumber = dataNode.path("buildNumber").asText();
								objHSMInfo.setBuildNumber(buildNumber);
							}
							if(dataNode.has("hardwareMajor")) {
								String hardwareMajor = dataNode.path("hardwareMajor").asText();
								objHSMInfo.setHardwareMajor(hardwareMajor);
							}
							if(dataNode.has("minPswdLen")) {
								double minPswdLen = dataNode.path("minPswdLen").asDouble();
								objHSMInfo.setMinPswdLen(minPswdLen);
							}
							if(dataNode.has("maxPswdLen")) {
								double maxPswdLen = dataNode.path("maxPswdLen").asDouble();
								objHSMInfo.setMaxPswdLen(maxPswdLen);
							}
							if(dataNode.has("totalPrivateMemory(KB)")) {
								double totalPrivateMemory = dataNode.path("totalPrivateMemory(KB)").asDouble();
								objHSMInfo.setTotalPrivateMemory(totalPrivateMemory);
							}
							if(dataNode.has("firmwareMinor")) {
								String firmwareMinor = dataNode.path("firmwareMinor").asText();
								objHSMInfo.setFirmwareMinor(firmwareMinor);
							}
							if(dataNode.has("partNumber")) {
								String partNumber = dataNode.path("partNumber").asText();
								objHSMInfo.setPartNumber(partNumber);
							}
							if(dataNode.has("freePublicMemory(KB)")) {
								double freePublicMemory = dataNode.path("freePublicMemory(KB)").asDouble();
								objHSMInfo.setFreePublicMemory(freePublicMemory);

							}
							if(dataNode.has("serialNumber")) {
								String serialNumber = dataNode.path("serialNumber").asText();
								objHSMInfo.setSerialNumber(serialNumber);
							}
							if(dataNode.has("fipsState")) {
								String fipsState = dataNode.path("fipsState").asText();
								objHSMInfo.setFipsState(fipsState);						
							}
							if(dataNode.has("hsmFlags")) {
								double hsmFlags = dataNode.path("hsmFlags").asDouble();
								objHSMInfo.setHsmFlags(hsmFlags);
							}
							if(dataNode.has("model")) {
								String model = dataNode.path("model").asText();
								objHSMInfo.setModel(model);
							}
							if(dataNode.has("deviceId")) {
								String deviceId = dataNode.path("deviceId").asText();
								objHSMInfo.setDeviceId(deviceId);
							}
						}
					}
				}
			}
		}catch(Exception exp){
			logger.error("Error occured during fetch HSM Info of class ApplianceServiceImpl ::" + exp.getMessage());	
		}
		return objHSMInfo;
	}

	/***
	 * This method is used for search operation as normal and advanced search
	 */
	@Override
	public List<ApplianceDetailModel> searchAppliance(ApplianceDetailModel applianceDetailModel) {
		List<ApplianceDetailModel> serachApplianceDetailModel=null;
		try {
			String applianceName = applianceDetailModel.getApplianceName();
			String applianceStatus = applianceDetailModel.getApplianceStatus();
			String ipAddress = applianceDetailModel.getIpAddress();
			String hostName = applianceDetailModel.getHostName();
			String ipmiIp = applianceDetailModel.getIpmiIp();

			if (applianceName == null) {
				applianceName = "";
			}
			if (applianceStatus == null) {
				applianceStatus = "";
			}
			if (ipAddress == null) {
				ipAddress = "";
			}

			if (hostName == null) {
				hostName = "";
			}
			if (ipmiIp == null) {
				ipmiIp = "";
			}
			serachApplianceDetailModel=applianceRepository.serchAppliance(applianceName,applianceStatus,ipAddress,hostName,ipmiIp);

		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Error occured during serach operation on appliance inside method searchAppliance of class ApplianceDetailModel ");
		}
		// TODO Auto-generated method stub
		return serachApplianceDetailModel;
	}
}

