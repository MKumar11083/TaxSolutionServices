package com.cavium.service.partition;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.pojo.PartitionsDetails;

/**
 *  * @author RK00490847
 *  This interface holds all the necessary operations for Partitions
 */
public interface PartitionService {
	
	public PartitionsDetails getPartitionInfo(ApplianceDetailModel applianceDetailModel);	 
}
