package com.cavium.service.partition;

import java.util.Iterator;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.pojo.PartitionsDetails;
import com.cavium.utill.CuratorResponseModel;
import com.cavium.utill.RestClient;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
/**
 *  * @author RK00490847
 *  Class is used as a service implementation for Partitions 
 */
@Component
public class PartitionServiceImpl implements PartitionService {
	private Logger logger = Logger.getLogger(this.getClass());



	/**
	 * This class is used to set the response attributes for incoming requests
	 */
	@Lookup
	public CuratorResponseModel getCuratorResponseModel() {
		return null;
	}

	/**
	 * This Interface is used to get the values from the property file
	 */
	@Autowired
	Environment env;

	@Autowired
	PartitionsDetails partitionsDetails;
	/*
	 * getAllAppliancesDetails method is used for fetch All appliances Details.
	 * 
	 * @return listApplianceDetailModel - List of ApplianceDetailModel Object.
	 * 
	 */

	@Autowired
	RestClient restClient;

	/***
	 * This method is used to validate the appliance whether exists or not
	 */
	@Override
	public PartitionsDetails getPartitionInfo(ApplianceDetailModel applianceDetailModel) {
		// TODO Auto-generated method stub
		try {
			// for testing purpose use this IP ::10.89.7.150
			//	ResponseEntity<String> response=restClient.invokeGETMethod("https://"+"10.89.7.150"+"/liquidsa/partitions");
			ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/partitions");
			if(response!=null && response.getStatusCode().name().equals("OK")) {
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());

					
					if(!root.isNull()){
						// read Status attribute from response
						//	JsonNode name = root.path("status");
						//read errors from response
						JsonNode errors = root.path("errors");
						if(!errors.isNull()){
							 Iterator<JsonNode> itr = errors.elements();					         
					            while (itr.hasNext()) {
					                JsonNode temp = itr.next();
					                System.out.println(temp.asInt());        
					            }
						}						
						JsonNode dataNode = root.path("data");
						if(!dataNode.isNull()){
							if(dataNode.has("totalKeys")) {
								int totalKeys = dataNode.path("totalKeys").asInt();
								partitionsDetails.setTotalKeys(partitionsDetails.getTotalKeys()+totalKeys);
							}
							if(dataNode.has("occupiedKeys")){
								int occupiedKeys = dataNode.path("occupiedKeys").asInt();
								partitionsDetails.setOccupiedKeys(partitionsDetails.getOccupiedKeys()+occupiedKeys);
							}
							if(dataNode.has("totalAcclrDev")) {
								int totalAcclrDev = dataNode.path("totalAcclrDev").asInt();
								partitionsDetails.setTotalAcclrDev(partitionsDetails.getTotalAcclrDev()+ totalAcclrDev);
							}
							if(dataNode.has("occupiedAcclrDev")) {
								int occupiedAcclrDev = dataNode.path("occupiedAcclrDev").asInt();
								partitionsDetails.setOccupiedAcclrDev(partitionsDetails.getOccupiedAcclrDev()+ occupiedAcclrDev);
							}
							if(dataNode.has("totalContexts")){
								int totalContexts = dataNode.path("totalContexts").asInt();
								partitionsDetails.setTotalContexts(partitionsDetails.getTotalContexts()+totalContexts);
							}
							if(dataNode.has("occupiedContexts")){
								int occupiedContexts = dataNode.path("occupiedContexts").asInt();
								partitionsDetails.setOccupiedContexts(partitionsDetails.getOccupiedContexts()+ occupiedContexts);
							}					 
						}
						// read header Data
						//response.getHeaders().get("Server");
					} 
				}
			}
		} catch (Exception e) {
			logger.error("Error occured during fetch  resource usag into getPartitionInfo of class PartitionServiceImpl ::" + e.getMessage());		 
		}
		return partitionsDetails;
	}
}
