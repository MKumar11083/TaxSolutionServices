package com.cavium.utill;

/**
 * 
 * Concrete PortalConstant hold the constant value for CISC0-XO Portal .
 * 
 * @author PK0041117
 * @version 1.0
 * @since 0.1
 * 
 */
public class CuratorConstant {
	/**
	 * The constructor create the instance of this class.
	 */
	private CuratorConstant() {
	}

	public static final int INDEX_ZERO = 0;
	public static final int INDEX_ONE = 1;
	public static final int INDEX_TWO = 2;
	public static final int INDEX_THREE = 3;
	public static final int INDEX_FOUR = 4;
	public static final int INDEX_FIVE = 5;
	public static final int INDEX_SIX = 6;
	public static final int INDEX_SEVEN = 7;
	public static final int INDEX_EIGHT = 8;
	public static final int INDEX_NINE = 9;
	public static final int INDEX_TEN = 10;
	public static final int INDEX_ELEVEN = 11;
	public static final int INDEX_TWELVE = 12;
	public static final int INDEX_THIRTEEN = 13;
	public static final int INDEX_FOURTEEN = 14;
	public static final int INDEX_FIFTEEN = 15;
	public static final int INDEX_SIXTEN = 16;
	public static final int INDEX_SEVENTEN = 17;
	public static final int INDEX_EIGHTEN = 18;
	public static final int INDEX_NINETEN = 19;
	public static final int INDEX_TWENTY = 20;
	public static final int INDEX_TWENTYONE = 21;
	public static final int INDEX_TWTWO = 22;
	public static final int INDEX_TWTHREE = 23;
	public static final int INDEX_TWFOUR = 24;
	public static final int INDEX_TWFIVE = 25;
	public static final int INDEX_TWSIX = 26;
	public static final int INDEX_TWSEVEN = 27;
	public static final int INDEX_TWEIGHT = 28;
	public static final int INDEX_TWNINE = 29;
	public static final int INDEX_THIRTY = 30;
	public static final int INDEX_THIRTYONE = 31;
	public static final int INDEX_THTWO = 32;
	public static final int INDEX_THTHREE = 33;
	public static final int INDEX_THFOUR = 34;
	public static final int INDEX_THFIVE = 35;
	public static final int INDEX_THSIX = 36;
	public static final int INDEX_THSEVEN = 37;
	public static final int INDEX_THEIGHT = 38;
	public static final int INDEX_THNINE = 39;
	public static final int INDEX_FOURTY = 40;
	public static final int INDEX_FTONE = 41;
	public static final int INDEX_FTTWO = 42;
	public static final int INDEX_FTTHREE = 43;
	public static final int INDEX_FTFOUR = 44;
	public static final int INDEX_FTFIVE = 45;
	public static final int INDEX_FTSIX = 46;
	public static final int INDEX_FTSEVEN = 47;
	public static final int INDEX_FTEIGHT = 48;
	public static final int INDEX_FTNINE = 49;
	public static final int INDEX_FIFTY = 50;
	public static final int INDEX_FFONE = 51;
	public static final int INDEX_FFTWO = 52;
	public static final int INDEX_FFTHREE = 53;
	public static final int INDEX_FFFOUR = 54;
	public static final int INDEX_FFFIVE = 55;
	public static final int INDEX_FFSIX = 56;
	public static final int INDEX_FFSEVEN = 57;
	public static final int INDEX_FFEIGHT = 58;
	public static final int INDEX_FFNINE = 59;
	public static final int INDEX_SIXTY = 60;

	public static final int LOG_TIME_TENTHOUSAND = 10000;

	public static final int WEB_RETURN_MINONE = -1;
	public static final int WEB_RETURN_MINTWO = -2;
	public static final int WEB_RETURN_MINTHREE = -3;
	public static final int INDEX_CREATECUSTFAILS = -2;

	public static final String WEB_ERROR = "WEB_ERROR";
	public static final String WEB_EXCEPTION = "WEB_EXCEPTION";
	public static final String WEB_SUCCESS = "WEB_SUCCESS";
	

	public static final String TOAST_DONE = "toastDone";

	/**
	 * The following is the "Components" used by DB logger for all the classes.
	 * This Component will identify the module
	 */
	public static final String DB_LOGGER_COMPONENT = "EMS";

	/**
	 * For the NETCONF message ID
	 */
	public static int NETCONF_ID = 100;

	/**
	 * Web service codes
	 */
	public static int CREATE_USER = 001;
	public static int MODIFY_USER = 002;
	public static int DELETE_USER = 003;
	public static int DEVICE_DISCOVERY = 4;
	public static int CREATE_SWITCH = 5;
	public static int ASSIGN_RESOURCE = 6;
	public static int CONFIGURE_PORT = 7;
	public static int CONFIGURE_QUEUE = 8;
	public static int CREATE_CONTROLLER = 9;
	public static int ASSIGN_CONTROLLER = 10;
	public static int MODIFY_CONTROLLER = 11;
	public static int INITIALIZE_DEVICE = 12;
	public static int REFRESH_SWITCH = 13;
	public static int CHANGE_PROFILE = 14;
	public static int CONFIGURE_ADVERTISED_FEATURE = 15;
	public static int CONFIGURE_OWNED_CERTIFICATE = 17;
	public static int TOPOLOGY_DISCOVERY=18;
	public static int DELETE_SWITCH = 19;
	public static int CONFIGURE_TUNNEL = 20;
	public static int CREATE_USER_GROUP = 21;
	public static int MODIFY_USER_GROUP =22;
	public static int MODIFY_DEVICE_GROUP =24;
    public static int CREATE_JMX=23;
    public static int MODIFY_JMX=25;
    public static int CREATE_Mbean=24;
    public static String key="1";
	public static int CREATE_KPI = 26;
	public static int MODIFY_KPI = 27;
	public static int DELETE_KPI = 28;
	public static int LIST_KPI = 29;
	
	public static int CREATE_PERFSCHEDULER = 30;
	public static int MODIFY_PERFSCHEDULER = 31;
	public static int DELETE_PERFSCHEDULER = 32;
	public static int LIST_PERFSCHEDULER = 33;
		
	public static int START_PERFSCHEDULERJOB = 33;
	public static int MANAGE_PERFSCHEDULERJOB = 34;
	public static int DELETE_PERFSCHEDULERJOB = 35;
	
	public static int CREATE_ALARMSCHEDULER = 36;
	public static int MODIFY_ALARMSCHEDULER=37;
	public static int DELETE_ALARMSCHEDULER=38;
	public static int START_ALARMSCHEDULERJOB=39;
	public static int DELETE_ALARMSCHEDULERJOB=40;
	public static int CREATE_CUSTOMER = 51; 
    
}
