package com.cavium.controller.appliance;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.pojo.ApplianceInfo;
import com.cavium.pojo.HSMInfo;
import com.cavium.pojo.HostSystemInfo;
import com.cavium.pojo.PartitionsDetails;
import com.cavium.pojo.AdminHostinfo.HostStats;
import com.cavium.service.appliance.ApplianceService;
import com.cavium.service.partition.PartitionService;

@RestController
@RequestMapping("rest")
public class HostSystemInfoController {

	@Autowired
	private ApplianceService applianceService;
	@Autowired
	private PartitionService partitionService;
	@Autowired
	private ApplianceInfo applianceInfo;
	@Autowired
	private HSMInfo hsmInfo;
	@Autowired
	HostStats hostStats;
	@Autowired
	HostSystemInfo hostSystemInfo;
 

	private Logger logger = Logger.getLogger(this.getClass());

	@RequestMapping(value = "getHostSystemInfo/{applianceIPAddress}", method = RequestMethod.GET)
	public HostSystemInfo getHostSystemInfo(@PathVariable("applianceIPAddress") String applianceIPAddress){
		logger.info("start of getPartitionsDetails Method");
		ApplianceDetailModel applianceDetailModel = new ApplianceDetailModel() ;
		applianceDetailModel.setIpAddress(applianceIPAddress);
		PartitionsDetails partitionsDetails=null;
		try{	 
			partitionsDetails=partitionService.getPartitionInfo(applianceDetailModel);		
			hostStats=applianceService.GetAdminHostStats(applianceDetailModel,hostStats);
			applianceInfo=applianceService.GetApplianceInfo(applianceDetailModel,applianceInfo);
			hsmInfo=applianceService.getHSMInfo(applianceDetailModel,hsmInfo);
			hostSystemInfo.setApplianceInfo(applianceInfo);
			hostSystemInfo.setHostStats(hostStats);
			hostSystemInfo.setPartitionsDetails(partitionsDetails);
			hostSystemInfo.setHsmInfo(hsmInfo);
			logger.info("end of getPartitionsDetails Method");
		}catch(Exception exp){
			logger.error("error while Initialize Appliance ::"+exp.getMessage());
		}
		return hostSystemInfo;
	}


}
