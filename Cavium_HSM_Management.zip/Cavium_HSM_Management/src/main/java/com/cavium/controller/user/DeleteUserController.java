package com.cavium.controller.user;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cavium.model.user.UserDetailModel;
import com.cavium.service.user.UserService;
import com.cavium.utill.CuratorResponseModel;

/**
 * @author RK00490847
 * 
 */
@RestController
@RequestMapping("rest")
public class DeleteUserController {

	// logger - instance of application log.
	private Logger logger = Logger.getLogger(this.getClass());

	// userService - Service class provide the interface for the Repository
	// Operation.
	@Autowired
	private UserService userService;

	@Lookup
	public CuratorResponseModel getCuratorResponseModel() {
		return null;
	}

	/**
	 * This deleteUser method delete the User and return listresponseModel to the
	 * List of CuratorResponseModel Object.
	 * 
	 * @return responseModel - CuratorResponseModel Object
	 * 
	 * @param userId
	 * 
	 */
		
	@RequestMapping(value = "deleteUser", method = RequestMethod.DELETE)
	public final List<CuratorResponseModel> deleteUser(@RequestBody UserDetailModel userDetailModel) {
		logger.info("Start of deleteUser Method");
		CuratorResponseModel responseModel = getCuratorResponseModel();
		List<CuratorResponseModel> listResponseModel = new ArrayList<CuratorResponseModel>();
		if (userDetailModel.getDeletedUserIds() != null && userDetailModel.getDeletedUserIds().size()>0) {
			Iterator<String> iterator = userDetailModel.getDeletedUserIds().iterator();
			while (iterator.hasNext()) {
				String userId = iterator.next();
				responseModel = userService.deleteUser(userId);
				listResponseModel.add(responseModel);
			}
			logger.info("ResponseModel for deleteUser :: " + listResponseModel.toString());
			logger.info("End of deleteUser Method");
		}
		return listResponseModel;
	}
}
