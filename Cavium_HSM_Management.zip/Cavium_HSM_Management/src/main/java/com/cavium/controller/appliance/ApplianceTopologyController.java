package com.cavium.controller.appliance;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.pojo.ApplianceCityDetail;
import com.cavium.pojo.UserAttributes;
import com.cavium.service.appliance.ApplianceService;

/*
 * 
 */
@RestController
@RequestMapping("rest")
public class ApplianceTopologyController {

	@Autowired
	private ApplianceService applianceService;
	@Autowired
	private UserAttributes userAttributes;
	 

	private Logger logger = Logger.getLogger(this.getClass());

	@RequestMapping(value = "getTopologyDetails", method = RequestMethod.GET)
	public List<ApplianceCityDetail>getTopologyDetails(){
		logger.info("start of getTopologyDetails Method");
		List<ApplianceCityDetail> listApplianceToplology=null;
		try{
			Map<String,ApplianceCityDetail> cityNameMap= new  HashMap<String,ApplianceCityDetail>();
			ApplianceCityDetail objApplianceCityDetail= null;	
			String loggedInUser = userAttributes.getlogInUserName();
			List<ApplianceDetailModel> listApplianceDetailModels = applianceService.listOfApplianceByGroupId(loggedInUser);	
			for (Iterator<ApplianceDetailModel> iterator = listApplianceDetailModels.iterator(); iterator.hasNext();) {
				ApplianceDetailModel applianceDetailModel = (ApplianceDetailModel) iterator.next();
				String cityName=applianceDetailModel.getCityName();
				logger.info("cityName :: Appliance Status "+cityName +"::"+applianceDetailModel.getApplianceStatus());	 
				if("Active".equals(applianceDetailModel.getApplianceStatus())){

					if(!cityNameMap.containsKey(cityName)){
						objApplianceCityDetail= new ApplianceCityDetail();
						objApplianceCityDetail.setCityName(cityName);
						cityNameMap.put(cityName,objApplianceCityDetail);	
					}					 					
					if(cityNameMap.containsKey(cityName)){
						objApplianceCityDetail=cityNameMap.get(cityName);
						objApplianceCityDetail.getApplianceStatus().setActiveStatus((objApplianceCityDetail.getApplianceStatus().getActiveStatus()+1));
					}
				}
				if("Inactive".equals(applianceDetailModel.getApplianceStatus())){
					if(!cityNameMap.containsKey(cityName)){		
						objApplianceCityDetail= new ApplianceCityDetail();
						objApplianceCityDetail.setCityName(cityName);
						cityNameMap.put(cityName,objApplianceCityDetail);
					}					 					
					if(cityNameMap.containsKey(cityName)){
						objApplianceCityDetail=cityNameMap.get(cityName);
						objApplianceCityDetail.getApplianceStatus().setInactiveStatus((objApplianceCityDetail.getApplianceStatus().getInactiveStatus()+1));
					}
				}
				if("Suspended".equals(applianceDetailModel.getApplianceStatus())){
					if(!cityNameMap.containsKey(cityName)){
						objApplianceCityDetail= new ApplianceCityDetail();
						objApplianceCityDetail.setCityName(cityName);
						cityNameMap.put(cityName,objApplianceCityDetail);	
					}					 					
					if(cityNameMap.containsKey(cityName)){
						objApplianceCityDetail=cityNameMap.get(cityName);
						objApplianceCityDetail.getApplianceStatus().setSuspendedStatus((objApplianceCityDetail.getApplianceStatus().getSuspendedStatus()+1));
					}
				}
			}
			listApplianceToplology = new ArrayList<ApplianceCityDetail>(cityNameMap.values());
			logger.info("end of getTopologyDetails Method");
		}catch(Exception exp){

		}
		return listApplianceToplology;
	}
}
