package com.cavium.controller.user;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cavium.model.user.UserACLDetailsModel;
import com.cavium.model.user.UserDetailModel;
import com.cavium.model.user.UserGroupModel;
import com.cavium.model.user.UserManagementDashboardModel;
import com.cavium.pojo.UserAttributes;
import com.cavium.service.user.UserService;
import com.cavium.utill.UserRoles;


/**
 * @author RK00490847
 * 
 */
@RestController
@RequestMapping("rest")
public class UserManagementDashboard {

	private Logger logger = Logger.getLogger(getClass());
	@Autowired
	private UserService userService;

	@Autowired
	private UserAttributes userAttributes;

	/**
	 * This Interface is used to get the values from the property file
	 */
	@Autowired
	Environment env;

	@RequestMapping(value = "getUserDashboardDetails" ,method = RequestMethod.GET)
	public UserManagementDashboardModel dashboardDeatils()
	{
		logger.info("Entered in dashboardDeatils Method:");
		String groupId="%";
		UserManagementDashboardModel userDashboardModel= new UserManagementDashboardModel();
		UserDetailModel  userDetailModel = new UserDetailModel();
		UserACLDetailsModel userACLDetailsModel= new UserACLDetailsModel();
		UserGroupModel userGroupModel= new UserGroupModel();

		List<UserACLDetailsModel> aclDetails= new ArrayList<UserACLDetailsModel>();
		List<UserGroupModel> userGroupData= new ArrayList<UserGroupModel>();
		List<UserDetailModel> userDetailsModel =new ArrayList<UserDetailModel>();

		String superAdmin="%";
		String loggedInUser = userAttributes.getlogInUserName();	
		UserDetailModel	objUserDetailModel=this.userService.getUserDetails(loggedInUser);
		if(objUserDetailModel.getObjUserACLDetailsModel()==null || !env.getProperty("user.superadmin").equals(objUserDetailModel.getObjUserACLDetailsModel().getAclName())) {
			if(objUserDetailModel.getObjUserGroupModel()!=null) {
				userGroupData = userService.getUserGroupData(userGroupModel,loggedInUser);
			}
		}else {
			userGroupData = userService.getUserGroupData(userGroupModel,superAdmin);
		}
		aclDetails = this.userService.getACLDetails(userACLDetailsModel);
		userDetailsModel = this.userService.listUsers(userDetailModel,groupId,loggedInUser);

		userDashboardModel.setListUserACLDetailsModel(aclDetails);
		userDashboardModel.setListUserDetailModel(userDetailsModel);
		userDashboardModel.setListUserGroupModel(userGroupData);

		logger.info("End of dashboardDeatils Method:");

		return userDashboardModel;
	}

	/***
	 * This method is used to get all logged in user roles 
	 * @return
	 */
	@RequestMapping(value = "getUserRoles" ,method = RequestMethod.GET)
	public UserRoles getUserRoles() {
		logger.info("Start of getUserRoles Method:");
		UserRoles userRoles = new UserRoles();
		List<String> userAuthorities=new ArrayList<>();
		try {
			String loggedInUser = userAttributes.getlogInUserName();
			if(!StringUtils.isEmpty(loggedInUser)) {
				UserDetailModel user=userService.findUserDeatils(loggedInUser);
				if(user!=null) {
					userRoles.setFirstname(user.getFirstName());
					userRoles.setLastname(user.getLastName());
					userRoles.setStatus(String.valueOf(user.getStatus()));	
					userRoles.setTempPassowrd(String.valueOf(user.getTemporaryPassword()));
					if(user.getObjUserGroupModel()!=null){
					userRoles.setGroupId(String.valueOf(user.getObjUserGroupModel().getId()));
					}
					else{
						user.setUserGroupId(null);
					}
				}
				List<SimpleGrantedAuthority> roles=userAttributes.getUserRoles();
				Iterator<SimpleGrantedAuthority> authority=roles.iterator();
				while(authority.hasNext()) {
					SimpleGrantedAuthority smplauthority=(SimpleGrantedAuthority)authority.next();
					userAuthorities.add(smplauthority.getAuthority());
				}
				userRoles.setRoles(userAuthorities);
			}
		} catch (Exception e) {
			logger.info("End of getUserRoles Method:");
			// TODO: handle exception
		}
		return userRoles;
	}

}
