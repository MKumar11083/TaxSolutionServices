package com.cavium.controller.recentactivity;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.recentactivity.RecentActivity;
import com.cavium.pojo.UserAttributes;
import com.cavium.service.recentactivity.RecentActivityService;

@RestController
@RequestMapping("rest")
public class RecentActivityController {
	
	private Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	private RecentActivityService recentActivityService;
	
	@Autowired
	private UserAttributes userAttributes;
	
	/***
	 * This method is used to get appliance by id.
	 */
	@RequestMapping(value = "getRecentActivity", method = RequestMethod.GET)
	public List<RecentActivity> getRecentActivity() {
		List<RecentActivity> recentActivity = null;
		logger.info("inside getRecentActivity");
		try {
			String loggedInUser = userAttributes.getlogInUserName();
			recentActivity=recentActivityService.getRecentActivity(loggedInUser);
		} catch (Exception e) {
			logger.error("error occured during getRecentActivity" + e.getMessage());
		}
		return recentActivity;
	}

}
