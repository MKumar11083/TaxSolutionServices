package com.cavium.controller.partition;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.pojo.ApplianceCityDetail;
import com.cavium.pojo.PartitionsDetails;
import com.cavium.pojo.UserAttributes;
import com.cavium.service.appliance.ApplianceService;
import com.cavium.service.partition.PartitionService;

/*
 * 
 */
@RestController
@RequestMapping("rest")
public class PartitionController {
	
		@Autowired
		private UserAttributes userAttributes;
		
		@Autowired
		private ApplianceService applianceService;
		
		@Autowired
		private PartitionService partitionService;
		
	private Logger logger = Logger.getLogger(this.getClass());

	@RequestMapping(value = "getPartitionsDetails", method = RequestMethod.GET)
	public PartitionsDetails getPartitionsDetails(){
		logger.info("start of getPartitionsDetails Method");
	 List<ApplianceDetailModel>listApplianceDetailModels= new ArrayList<ApplianceDetailModel>();
	 PartitionsDetails partitionsDetails=null;
		try{	 
			String loggedInUser = userAttributes.getlogInUserName(); 
			listApplianceDetailModels = applianceService.listOfApplianceByGroupId(loggedInUser);
			for (Iterator<ApplianceDetailModel> iterator = listApplianceDetailModels.iterator(); iterator.hasNext();) {
				ApplianceDetailModel applianceDetailModel = (ApplianceDetailModel) iterator.next();
				 partitionsDetails=partitionService.getPartitionInfo(applianceDetailModel);			
			}
			
		}catch(Exception exp){

		}
		return partitionsDetails;
	}
}
