package com.cavium.controller.acl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.service.user.UserService;
import com.cavium.utill.CuratorResponseModel;


/**
 * @author RK00490847
 * 
 */
@RestController
@RequestMapping("rest")
public class DeleteUserACLController {

	private Logger logger = Logger.getLogger(this.getClass());
	@Autowired
	private UserService userService;
	@Lookup
	public CuratorResponseModel getCuratorResponseModel() {
		return null;
	}
	/**
	 * This deleteACL method  delete the ACL and return responseModel to the response.
	 * 
	 *  @return responseModel
	 *  		-  CuratorResponseModel Object
	 * 
	 * @param aclId          
	 * 
	 */
	@RequestMapping(value = "deleteACL/{aclId}", method = RequestMethod.DELETE)
	public final CuratorResponseModel deleteACL(@PathVariable("aclId") String aclId)  {
		CuratorResponseModel responseModel=getCuratorResponseModel();
		logger.info("Start of deleteACL Method");
		logger.info("ACL ID " + aclId + " is going for deletion");
		responseModel = userService.deleteACL(aclId);
		logger.info("End of deleteACL Method");
		logger.info("ResponseModel for deleteACL :: " + responseModel.toString());
		return responseModel;
	}
}
