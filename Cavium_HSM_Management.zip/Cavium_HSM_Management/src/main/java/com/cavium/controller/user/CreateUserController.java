package com.cavium.controller.user;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.core.env.Environment;
import org.springframework.mail.MailException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cavium.model.user.UserACLDetailsModel;
import com.cavium.model.user.UserDetailModel;
import com.cavium.model.user.UserGroupModel;
import com.cavium.model.user.UserWithGroupACLDetailsModel;
import com.cavium.pojo.UserAttributes;
import com.cavium.service.user.UserService;
import com.cavium.utill.CuratorResponseModel;

/*
 * This CreateUserController class is used for create the new User in Database.
 *  @author RK00490847
 */

@RestController
@RequestMapping("rest")
public class CreateUserController {

	// logger - instance of application log.
	private Logger logger = Logger.getLogger(this.getClass());

	// userService - Service class provide the interface for the Repository
	// Operation.
	@Autowired
	private UserService userService;

	@Autowired
	private UserAttributes userAttributes;

	// passwordEncoder - used this class for encrypt the user password
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;



	@Lookup
	public CuratorResponseModel getCuratorResponseModel() {
		return null;
	}


	/**
	 * This Interface is used to get the values from the property file
	 */
	@Autowired
	Environment env;
	/*
	 * This getGroupACLUserDetails method will return all the Groups and ACLs that
	 * we have in Database.
	 * 
	 * @return - The List of All Groups and List of All ACLs.
	 */
	@RequestMapping(value = "getGroupACLDetails", method = RequestMethod.GET)
	public final UserWithGroupACLDetailsModel getGroupACLUserDetails() {
		logger.info("Entered getGroupACLUserDetails Method");
		List<UserGroupModel> listUserGroupModel = new ArrayList<UserGroupModel>();
		UserWithGroupACLDetailsModel objGroupACLDetails = new UserWithGroupACLDetailsModel();
		List<UserACLDetailsModel> listUserACLDetailsModel = new ArrayList<UserACLDetailsModel>();
		listUserGroupModel =this.userService.getUserGroups();
		logger.info("Inside modifyAppiance method of class ApplianceController.");
		String loggedInUser = userAttributes.getlogInUserName();
		listUserACLDetailsModel = this.userService.getAllACLDetails();
		UserDetailModel objUserDetailModel=this.userService.getUserDetails(loggedInUser);
		if(objUserDetailModel.getObjUserACLDetailsModel()==null || !env.getProperty("user.superadmin").equals(objUserDetailModel.getObjUserACLDetailsModel().getAclName())) {
			if(listUserGroupModel!=null) {
				for (Iterator<UserGroupModel> iterator = listUserGroupModel.iterator(); iterator.hasNext();) {
					UserGroupModel userGroupModel = (UserGroupModel) iterator.next();
					if(objUserDetailModel.getObjUserGroupModel()!=null) {
						if((!objUserDetailModel.getObjUserGroupModel().getRoleName().equals(userGroupModel.getRoleName())) && (!loggedInUser.equals(userGroupModel.getUsername()))) {
							iterator.remove();
						}
					}else {
						iterator.remove();
					}
				} 
			}	
		}
		if(listUserACLDetailsModel!=null) {
			for (Iterator<UserACLDetailsModel> iterator = listUserACLDetailsModel.iterator(); iterator.hasNext();) {
				UserACLDetailsModel aclDetailModel = (UserACLDetailsModel) iterator.next();
				if(env.getProperty("user.superadmin").equals(aclDetailModel.getAclName())) {
					iterator.remove();
				}				
			} 
		}

		objGroupACLDetails.setListUserACLDetailsModel(listUserACLDetailsModel);
		objGroupACLDetails.setListUserGroupModel(listUserGroupModel);
		logger.info("return Group Details: " + objGroupACLDetails);
		logger.info("End getGroupACLUserDetails Method");
		return objGroupACLDetails;
	}

	/*
	 * This method will create the user in Database and return the success message
	 * or error message .
	 * 
	 * @param RequestBody - UserDetailModel from Request
	 * 
	 * @return responseModel - CuratorResponseModel Object
	 */

	@RequestMapping(value = "createUser", method = RequestMethod.POST)
	public final CuratorResponseModel createUser(@RequestBody UserDetailModel userModel) {
		logger.info("Start of createUser method:");
		CuratorResponseModel responseModel=getCuratorResponseModel();
		try{
		String pwdWithoutEncoded=userModel.getPassword();
		String encodedPassword = passwordEncoder.encode(String.valueOf(userModel.getPassword()));
		userModel.setPassword(encodedPassword);
		responseModel = userService.createUser(userModel, pwdWithoutEncoded);
		logger.info("End of createUser Method :");
		logger.info("ResponseModel for createUser :: " + responseModel.toString());
		}catch(MailException exp){
			responseModel.setResponseCode("-230");
			responseModel.setResponseMessage("Error in Creating User.Some Error is coming while email send to user");
		}
		catch(Exception exp){
			logger.error("error while creating User");
			responseModel.setResponseCode("500");
			responseModel.setResponseMessage(env.getProperty("application.error"));
		}
		return responseModel;
	}
}
