package com.cavium.controller.appliance;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.core.env.Environment;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.appliance.InitializeApplianceDetailModel;
import com.cavium.pojo.UserAttributes;
import com.cavium.service.appliance.ApplianceService;
import com.cavium.utill.CuratorResponseModel;

/**
 * * @author MK00497144 This class handling the appliance management endpoints
 */

@RestController
@RequestMapping("rest")
public class ApplianceController {

	@Autowired
	Environment env;

	@Autowired
	private ApplianceService applianceService;
	@Autowired
	private UserAttributes userAttributes;
	@Lookup
	public CuratorResponseModel getCuratorResponseModel() {
		return null;
	}
	
	private Logger logger = Logger.getLogger(this.getClass());

	
	/***
	 * This method is used to get appliance by id.
	 */
	@RequestMapping(value = "getAppliance/{applianceId}", method = RequestMethod.GET)
	public ApplianceDetailModel getApplianceById(@PathVariable("applianceId") String applianceId) {
		ApplianceDetailModel applianceDetailModels = null;
		logger.info("inside listAppliance");
		try {
			if(!StringUtils.isEmpty(applianceId)) {
				applianceDetailModels = applianceService.getApplianceById(applianceId);
			}else {
				applianceDetailModels=new ApplianceDetailModel();
				applianceDetailModels.setMessage("ApplianceID is null or empty");
			}
		} catch (Exception e) {
			logger.error("error occured during listAppliance" + e.getMessage());
		}
		return applianceDetailModels;
	}
	
	/**
	 * Method is used to get list of Appliances
	 * @return
	 */
	@RequestMapping(value = "listAppliance", method = RequestMethod.GET)
	public List<ApplianceDetailModel> getListOfAppliance() {
		List<ApplianceDetailModel> listApplianceDetailModels = null;
		logger.info("inside listAppliance");
		try {
			String loggedInUser = userAttributes.getlogInUserName();
			listApplianceDetailModels = applianceService.listOfApplianceByGroupId(loggedInUser);
		} catch (Exception e) {
			logger.error("error occured during listAppliance" + e.getMessage());
		}
		return listApplianceDetailModels;

	}

	/**
	 * Method is used to create new appliance
	 * @param applianceDetailModel
	 * @return
	 */
	
	@RequestMapping(value = "createAppliance", method = RequestMethod.POST)
	public final CuratorResponseModel createAppliance(@RequestBody List<ApplianceDetailModel> applianceDetailModel) {
		logger.info("Creating user with the details:" + applianceDetailModel);
		CuratorResponseModel responseModel=getCuratorResponseModel();
		responseModel = applianceService.createAppliance(applianceDetailModel);
		if (responseModel.getResponseMessage() == null || responseModel.getResponseMessage().length() == 0) {
			logger.info(applianceDetailModel.toString() + " - is created successfully.");
		} else {
			logger.info(
					responseModel.toString() + " Creation Failed: Reason:" + responseModel.getResponseMessage());

		}
		return responseModel;
	}

	/**
	 * This method is used to modify the Appliance
	 * 
	 * @param applianceDetailModel
	 * @return
	 */
	@RequestMapping(value = "modifyAppliance",method = RequestMethod.PUT)
	public final CuratorResponseModel modifyAppiance(@RequestBody ApplianceDetailModel applianceDetailModel) {
		CuratorResponseModel responseModel=getCuratorResponseModel();
		try {		
			logger.info("Inside modifyAppiance method of class ApplianceController.");
			String loggedInUser = userAttributes.getlogInUserName();

			if (applianceDetailModel != null) {
				responseModel = applianceService.modifyAppliance(loggedInUser, applianceDetailModel);
			} else {
				logger.error(env.getProperty("applianceModification.failureEmpty"));
				responseModel.setResponseCode("204");
				responseModel.setResponseMessage(env.getProperty("applianceModification.failureEmpty"));
			}
		} catch (Exception e) {
			logger.error("Error occured due to" + e.getMessage());
			// TODO: handle exception
		}
		logger.info("End of modifyAppiance method");
		return responseModel;
	}

	/**
	 * Method is used to delete the particular appliance
	 * @param applianceId
	 * @return
	 */
	@RequestMapping(value = "deleteAppliance/{applianceId}", method = RequestMethod.DELETE)
	public final CuratorResponseModel deleteAppliance(@PathVariable("applianceId") String applianceId) {
		String loggedInUser = userAttributes.getlogInUserName(); 
		CuratorResponseModel responseModel=getCuratorResponseModel();
		logger.info("Appliance ID " + applianceId + " is going for deletion by " + loggedInUser + "");
		if (!StringUtils.isEmpty(applianceId)) {
			responseModel = applianceService.deleteAppliance(applianceId);
		} else {
			logger.error("applianceID is empty or null ::");
			responseModel.setResponseCode("204");
			responseModel.setResponseMessage(env.getProperty("applianceDeletion.failureEmpty"));
		}
		logger.info(env.getProperty("applianceCreation.success"));
		return responseModel;
	}
	
	/**
	 * Method is used to create new appliance
	 * @param applianceDetailModel
	 * @return
	 */
	@RequestMapping(value = "validateAppliance", method = RequestMethod.POST)
	public final ApplianceDetailModel validateAppliance(@RequestBody ApplianceDetailModel applianceDetailModel) {
		logger.info("Creating user with the details:" + applianceDetailModel);
		if(applianceDetailModel!=null) {
			applianceDetailModel = applianceService.validateAppliance(applianceDetailModel);
		}
		return applianceDetailModel;
	}
	
	
	@RequestMapping(value = "rebootAppliance", method = RequestMethod.POST)
	public final List<ApplianceDetailModel> rebootAppliance(@RequestBody List<ApplianceDetailModel>  applianceDetailModellist) {
		logger.info("Creating user with the details:" + applianceDetailModellist);
		if(applianceDetailModellist!=null) {
			applianceDetailModellist = applianceService.rebootAppliance(applianceDetailModellist);
		}
		return applianceDetailModellist;
	}
	
	
	@RequestMapping(value = "zeroizeAppliance", method = RequestMethod.POST)
	public final List<ApplianceDetailModel> zeroizeAppliance(@RequestBody List<ApplianceDetailModel> applianceDetailModellist) {
		logger.info("Creating user with the details:" + applianceDetailModellist);
		if(applianceDetailModellist!=null) {
			applianceDetailModellist = applianceService.zeroizeAppliance(applianceDetailModellist);
		}
		return applianceDetailModellist;
	}
	
	@RequestMapping(value = "initilizeAppliance", method = RequestMethod.POST)
	public final ApplianceDetailModel initilizeAppliance(@RequestBody InitializeApplianceDetailModel initializeApplianceDetailModel) {
		logger.info("Creating user with the details:" + initializeApplianceDetailModel);
		ApplianceDetailModel applianceDetailModel=null;
		try{
		if(initializeApplianceDetailModel!=null) {
			applianceDetailModel = applianceService.initilizeAppliance(initializeApplianceDetailModel);
		}
		}	 
		catch (RuntimeException e) {
			logger.error("error in Initilize Applaince :" + e.getMessage());
		}
		return applianceDetailModel;
	}
	
	
	@RequestMapping(value = "applianceFirmwareUpgrade", method = RequestMethod.POST)
	public final List<ApplianceDetailModel> applianceFirmwareUpgrade(@RequestBody List<ApplianceDetailModel> applianceDetailModellist) {
		logger.info("Creating user with the details:" + applianceDetailModellist);
		if(applianceDetailModellist!=null) {
			applianceDetailModellist = applianceService.applianceFirmwareUpgrade(applianceDetailModellist);
		}
		return applianceDetailModellist;
	}
	
	/**
	 * Method is used to get list of Appliances
	 * @return
	 */
	@RequestMapping(value = "searchAppliance", method = RequestMethod.POST)
	public List<ApplianceDetailModel> searchAppliance(@RequestBody ApplianceDetailModel applianceDetailModel) {
		List<ApplianceDetailModel> listApplianceDetailModels = null;
		logger.info("inside listAppliance");
		try {
			listApplianceDetailModels = applianceService.searchAppliance(applianceDetailModel);
		} catch (Exception e) {
			logger.error("error occured during listAppliance" + e.getMessage());
		}
		return listApplianceDetailModels;
	}
	
}
