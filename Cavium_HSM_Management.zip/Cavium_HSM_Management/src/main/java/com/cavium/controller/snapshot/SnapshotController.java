package com.cavium.controller.snapshot;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.controller.appliance.ApplianceTopologyController;
import com.cavium.controller.partition.PartitionController;
import com.cavium.controller.recentactivity.RecentActivityController;
import com.cavium.model.recentactivity.RecentActivity;
import com.cavium.pojo.ApplianceCityDetail;
import com.cavium.pojo.PartitionsDetails;
import com.cavium.pojo.SnapshotDetails;


@RestController
@RequestMapping("rest")
public class SnapshotController {


	@Autowired
	private ApplianceTopologyController applianceTopologyController;

	@Autowired
	private PartitionController partitionController;

	@Autowired
	private RecentActivityController recentActivityController;

	@Autowired
	private SnapshotDetails snapshotDetails;

	private Logger logger = Logger.getLogger(this.getClass());

	@RequestMapping(value = "getSnapshotDetails", method = RequestMethod.GET)
	public SnapshotDetails getPartitionsDetails(){
		
		logger.info("start of getSnapshotDetails Method");

		PartitionsDetails partitionsDetails=null;
		List<RecentActivity> recentActivity = null;
		List<ApplianceCityDetail> listApplianceToplology=null;
		try{	 
			recentActivity=	recentActivityController.getRecentActivity();
			partitionsDetails=partitionController.getPartitionsDetails();
			listApplianceToplology=applianceTopologyController.getTopologyDetails();
			snapshotDetails.setRecentActivity(recentActivity);
			snapshotDetails.setListApplianceToplology(listApplianceToplology);
			snapshotDetails.setPartitionsDetails(partitionsDetails);
		}catch(Exception exp){
			logger.error("error occured during getRecentActivity" + exp.getMessage());
		}
		logger.info("end of getSnapshotDetails Method");
		return snapshotDetails;
	}

}
