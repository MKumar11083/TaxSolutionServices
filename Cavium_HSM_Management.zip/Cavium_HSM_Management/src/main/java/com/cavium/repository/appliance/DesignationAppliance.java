package com.cavium.repository.appliance;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cavium.model.user.DesignationApplianceModel;

@Repository
public interface DesignationAppliance extends JpaRepository<DesignationApplianceModel, Long> {

}
