package com.cavium.repository.user;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.user.DesignationApplianceModel;

@Repository
public interface DesignationApplianceRepository extends JpaRepository<DesignationApplianceModel, String>{
	
	@Modifying
	@Query("delete from DesignationApplianceModel da where da.objApplianceDetailModel = :applianceId")
	public int deleteApplianceFromDesignationAppliance(@Param("applianceId") ApplianceDetailModel objApplianceDetailModel);

}
