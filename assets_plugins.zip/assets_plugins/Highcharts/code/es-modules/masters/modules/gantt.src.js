/**
 * @license @product.name@ JS v@product.version@ (@product.date@)
 * Gantt series
 *
 * (c) 2016 Lars A. V. Cabrera
 *
 * --- WORK IN PROGRESS ---
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../parts-gantt/gantt.js';
