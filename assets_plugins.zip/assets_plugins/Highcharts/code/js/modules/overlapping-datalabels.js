/*
 Highcharts JS v6.1.1 (2018-06-27)

 (c) 2009-2017 Torstein Honsi

 License: www.highcharts.com/license
*/
(function(a){"object"===typeof module&&module.exports?module.exports=a:a(Highcharts)})(function(a){});
