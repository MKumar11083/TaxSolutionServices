export const environment = {
  production: true,
  format : '.json',
  i18NUrl : '/MarvellHSM/assets/i18n/'
};
