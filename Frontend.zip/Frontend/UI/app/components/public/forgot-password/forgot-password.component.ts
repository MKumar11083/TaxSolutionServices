import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonServices} from './../../../services/common/common.services';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {

  loginForm: FormGroup;
  errorMsg: string;
  message : string;
  constructor(private _router: Router, private _formBuilder:
    FormBuilder, 
    private _service : CommonServices) { }

  ngOnInit() {
    this._service.clearSession();
    this.errorMsg = "";
    this.message = "";
    this.loginForm = this._formBuilder.group({
      userName: ['', Validators.required],
    });
  }

  onSubmit(){
    if(this.loginForm.valid){
      this._service.forgotPassword(this.loginForm.value).subscribe(
        data => {
          if(data.responseCode == "200"){
            this.message="Temporary password is sent to your registered email-address";
          }else if(data.responseCode == "-230"){
            this.errorMsg = data.responseMessage;
          }
        },
        err => {
          console.log(err);
        }
      );
    }else{
      // Check errors 
      const userName = this.loginForm.get('userName');
      if (userName.errors != null) {
        if (userName.hasError('required')) {
          userName.markAsTouched({ onlySelf: true });
        }
      }
    }
  }

  closeMessage() {
    this.errorMsg = '';
    this.message = '';
  }
}
