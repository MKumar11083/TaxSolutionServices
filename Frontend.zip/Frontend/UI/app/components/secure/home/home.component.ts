import { Component, OnInit, OnDestroy } from '@angular/core';
import { ChartsModule, Color } from 'ng2-charts';
import { DashboardService } from './../../../services/dashboard.service';
import { AnonymousSubscription } from "rxjs/Subscription";
import { Observable } from "rxjs/Observable";

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit, OnDestroy {
  alertsList:any=[];
  alertDetails:any=[];
  getRecentActivityDetails:any=[];
  groupWiseAppliancesData:any=[];
  groupWiseAppliancesLabels:any=[];
  usedDiskSpace: any;
  partitionData:any=[];
  appliancesDataLabels:any=[];
  usersData:any=[];
  systemData:any=[];
  usersDataLabels:any=[];
  recentActivityList: any = [];
  totaldiskSpace:any;
  userSessionData:any=[];
  timer: AnonymousSubscription;
  systemInformation: AnonymousSubscription;
  public loading=false;
  constructor(private _dashboardService: DashboardService) { }
  public doughnutChartLabels: string[] = ['Used', 'Available'];
  public doughnutChartData: number[] = [];
  public doughnutChartType: string = 'doughnut';

ngOnInit(){
  this.loading = true;
  this.groupwiseAppliance();
  this.partitionwiseAppliance();
  this.userDetailsforDashboard();
  this.getAlerts();
  this.recentActivityDetails();
  this.displaySystemInfo();
  this.displayUserTrackingInfo();

}

displaySystemInfo(){
  // this.loading = true;
  this.systemInformation=this._dashboardService.getSystemInfo().subscribe(    
    res => {
      this.systemData=res;
      this.usedDiskSpace = this.systemData.totaldiskSpace-this.systemData.diskSpaceAvaliabe;
      this.doughnutChartData=[];
      if (this.usedDiskSpace != null) {
        this.doughnutChartData.push(this.usedDiskSpace);
      }
      if (this.systemData.diskSpaceAvaliabe != null) {
        this.doughnutChartData.push(this.systemData.diskSpaceAvaliabe);
      }
      // this.loading = false;
      this.reloadSystemInformation();
    },
    error => {
      // this.loading = false;
      console.log(error);
    },
  );  
}

reloadSystemInformation(): void {
  this.timer = Observable.timer(10000).first().subscribe(() => this.displaySystemInfo());
}

ngOnDestroy() {
  if (this.timer) {
    this.timer.unsubscribe();
  }
  if(this.systemInformation){
    this.systemInformation.unsubscribe();
  }
}

public donutmycolors: Array<Color> = [
  {
    backgroundColor: [
      'rgba(244, 99, 132, 0.8)',
      'rgba(64, 162, 235, 0.8)',
      'rgba(255, 206, 86, 0.8)',
      'rgba(70, 192, 192, 0.8)',
      'rgba(287, 159, 64, 0.8)',
      'rgba(153, 102, 255, 0.8)',
      "#e28e41", "#3366cc", "#109618", "#dc3921"],
    hoverBackgroundColor: [ 'rgba(244, 99, 132, 0.8)',
    'rgba(64, 162, 235, 0.8)',
    'rgba(255, 206, 86, 0.8)',],
  }
];


groupwiseAppliance(){
  this.loading = true;
  this.pieChartData=[];
  this.pieChartLabels=[];
  this._dashboardService.getGroupWiseAppliances().subscribe(    
    res => {
      this.loading = false;
      this.groupWiseAppliancesData = res.applianceCounts; 
      this.groupWiseAppliancesLabels = res.groupNames;  
      if(this.groupWiseAppliancesData!=0){
        this.groupWiseAppliancesData.forEach(element => {
          this.pieChartData.push(element);
        });
      }
     if(this.groupWiseAppliancesLabels!=0){
      this.groupWiseAppliancesLabels.forEach(element => {
        if(element!=null){
          this.pieChartLabels.push(element); 
        }
      });
     }           
    },
    error => {
      this.loading = false;
      console.log(error);
    },
  );

}
partitionwiseAppliance(){
  this.loading = true;
  this.pieChartData2=[];
  this.pieChartLabels2=[];
  this._dashboardService.getPartitionWiseAppliances().subscribe(    
    res => {
      this.loading = false;
      this.partitionData = res.partitionCounts; 
      this.appliancesDataLabels = res.applianceNames;  
      let index:number=0;
      this.partitionData.forEach(element => {
          this.pieChartData2.push(element);
          this.pieChartLabels2.push(this.appliancesDataLabels[index]); 
          index++;
      });
    },
    error => {
      this.loading = false;
      console.log(error);
    },
  );
}

userDetailsforDashboard(){
  this.loading = true;
  this.pieChartData3=[];
  this.pieChartLabels3=[];
  this._dashboardService.getUsersDetailsForDashBoard().subscribe(    
    res => {
      this.loading = false;
      this.usersData = res.userCounts; 
      this.usersDataLabels = res.aclNames;   
      if(this.usersData !=0){
        this.usersData.forEach(element => {
          if(element!=null){
            this.pieChartData3.push(element);
          }
        });
      }
     if(this.usersDataLabels!=0){
      this.usersDataLabels.forEach(element => {
        if(element!=null){
          this.pieChartLabels3.push(element); 
        }
      });
     }         
    },
    error => {
      this.loading = false;
      console.log(error);
    },
  );
}


getAlerts(){
  this.loading = true;
  this._dashboardService.getAlertDetails().subscribe(    
    res => {
      this.loading = false;
      this.alertDetails = res.alerts;
      this.loading = false;   //alert details   
      // this.alertsList=[];
      // this.alertDetails = res.alerts;
      // this.alertDetails.forEach(element=>{
      //   let alerts={};
      //   // alerts['timezone'] = element.timezone;
      //   alerts['createdDate'] = element.createdDate;
      //   alerts['message'] = element.message;
      //   alerts['moduleId'] = element.moduleId;
      //   alerts['moduleName'] = element.moduleName;
      //   alerts['applianceId'] = element.applianceId;
      //   alerts['applianceIp'] = element.applianceIp;
      //   alerts['applianceName'] = element.applianceName;
      //   this.alertsList.push(alerts);
      // });
    },
    error => {
      this.loading = false;
      console.log(error);
    },
  );
}

recentActivityDetails(){
  this.loading = true;
  this._dashboardService.getRecentActivityDetails().subscribe(
    res => {
      this.loading = false;
      this.getRecentActivityDetails=res;
      this.recentActivityList=[];
      let colors = ["red", "green", "blue"];
      let count = 0;
      this.getRecentActivityDetails.recentActivity.forEach(element => {
        let recentActivity = {};
        if (count == 3) {
          count = 0;
        }
        // recentActivity['timezone'] = element.timezone;
        recentActivity['message'] = element.message;
        recentActivity['createdDate'] = element.createdDate;
        recentActivity['color'] = colors[count];
        this.recentActivityList.push(recentActivity);
        count++;
        
      });
    },
    error => {
      this.loading = false;
      console.log(error);
    },
  );
}


public pieChartType:string = 'pie';
public chartOptions = {
  responsive: true,
  legend: {
    display: true,
    position: 'right',
    labels: {
      boxWidth: 10
    }
  }

};
public chartOptions1 = {
  responsive: true,
  legend: {
    display: true,
    position: 'right',
    labels: {
      boxWidth: 10
    }
  },
  tooltips: {
    callbacks: {
      title: (items, data) => {
        const datasetLabel = data.datasets[0]['data'][items[0].index] || '';
        return  datasetLabel +'GB';
      }
    }
  }
};
public pieChartData:number[] = [];
public pieChartLabels:string[] = [];
public mycolors: Array<Color> = [
  {
    backgroundColor: [
      'rgb(77,136,255)',
      'rgb(255,195,77)',
      'rgb(204,68,0)',
      'rgb(0,102,153)',
      'rgb(211,211,211)',
      'rgb(112,128,144)'],
    hoverBackgroundColor: ['rgb(77,136,255)', 'rgb(255,195,77)','rgb(204,68,0)','rgb(0,102,153)',
                           'rgb(211,211,211)','rgb(112,128,144)'],
  }
];

public pieChartData2:number[] = [];
public pieChartLabels2:string[] = [];
public mycolors2: Array<Color> = [
  {
    backgroundColor: [
      'rgb(0,179,89)',
      'rgb(0,153,153)',
      'rgb(25,178,255)',
      'rgb(0,119,179)',
      'rgb(153,102,255)',
      'rgb(234,128,255)',
      'rgb(255,153,187)'
    ],
    hoverBackgroundColor: ['rgb(0,179,89)', 'rgb(0,153,153)','rgb(25,178,255)','rgb(0,119,179)',
                           'rgb(153,102,255)','rgb(234,128,255)','rgb(255,153,187)'],
  }
];

public pieChartData3:number[] = [];
public pieChartLabels3:string[] = [];
public mycolors3: Array<Color> = [
  {
    backgroundColor: [
      'rgb(255,51,51)',
      'rgb(0,204,204)',
      'rgb(255,195,77)',
      'rgb(0,179,89)',
    ],
    hoverBackgroundColor: ['rgb(255,51,51)', 'rgb(0,204,204)','rgb(255,195,77)','rgb(0,179,89)',],
  }
];

// events
public chartClicked(e:any):void {
  console.log(e);
}

public chartHovered(e:any):void {
  console.log(e);
}
displayUserTrackingInfo() {
  this.loading = true;
  this.userSessionData= [];
  this._dashboardService.getUserInfo().subscribe(
     res => {
       this.loading = false;
       this.userSessionData = res;
     },
     error => {
       this.loading = false;
       console.log(error);
     },
   );
 }

       
}

