
import { Component, OnInit, ViewChild, Output, EventEmitter, TemplateRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, FormControl, FormArray } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { TabDirective } from 'ngx-bootstrap/tabs';
import { TabsetComponent } from 'ngx-bootstrap';
import { Router } from '@angular/router';
import { PartitionOperationsComponent } from './../partition-operations/partition-operations.component';
import { PartitionManagementService } from './../../../../services/partitionmanagement/partitionmanagement.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { CommonValidator } from '../../../../validators/common-validator';

declare var $: any;

@Component({
  selector: 'app-partition-resize',
  templateUrl: './partition-resize.component.html',
  styleUrls: ['./partition-resize.component.css']
})

export class PartitionResizeComponent implements OnInit {
  @ViewChild('resizeModal') resizeModal: ModalDirective;
  @ViewChild('messageModal') messageModal: ModalDirective;
  @Output() messageEvent5 = new EventEmitter<any>();
  @ViewChild('partitionOperationsComponent')
  private partitionOperationsComponent: PartitionOperationsComponent;
  form: FormGroup;
  selectedPartitionList = [];
  partitionCount: number = 1;
  totalPartitionCount: number = 0;
  resizeDataList = [];
  invalidNumber = "Please enter a valid number";
  invalidUkey: boolean = true;
  invalidSSL: boolean = true;
  invalidAccl: boolean = true;
  partitionName: string;
  finalPartitionList = [];
  loading = false;
  showBackButton = false;
  showNextButton = false;
  displayError: string;
  displayError1: string;
  showFinalResize: boolean = false;
  backupChecked: boolean = false;
  modal: any = {};
  allocatedUserKeys: number = 1;
  allocatedSSLContexts: number = 1;
  allocatedAccelDevices: number = 1;
  ModifiedUserKeys: number = 0;
  ModifiedSSLContexts: number = 0;
  ModifiedAccelDevices: number = 0;
  togglechange: number = 0;
  keysAvailable: number;
  sslContextAvailable: number;
  acclrDevicesAvailable: number;
  message: string = '';
  validsslcont: boolean = false;
  validuserkeys: boolean = false;
  validacclrdev: boolean = false;
  setbackup: boolean = false;
  submitvalid = false;
  success: number = 0;
  stayButton: boolean;
  closeButton: boolean;
  partitionName1: string;
  constructor(private _formBuilder: FormBuilder,
    private _service: PartitionManagementService,
    private modalService: BsModalService) { }

  ngOnInit() {
    this.createResizeForm();

  }

  createResizeForm() {
    this.form = this._formBuilder.group({
      userkeys: [''],
      sslcontexts: [''],
      acclrdevices: [''],
      backup: [false],
    });



  }

  partitionResizeList: any = [];
  partitionResizeData: any = {};

  showPartitionResizeModal(partitionList) {
    this.form.reset();

    console.log("List of selected partitions --->" + partitionList);

    this.selectedPartitionList = partitionList;
    this.partitionResizeData = {};
    this.partitionResizeList = [];
    this.loading = true;
    this._service.getPartitionInfoForResize(this.selectedPartitionList).subscribe(
      (response) => {
        this.loading = false;
        response.forEach(obj => {
          let partitionResizeObj = {
            'partitionData': {}
          };

          partitionResizeObj['partitionId'] = obj.partitionId;
          partitionResizeObj['partitionName'] = obj.partitionName;
          partitionResizeObj['partOfCluster'] = obj.partOfCluster;
          partitionResizeObj['status'] = obj.status;
          partitionResizeObj['backup'] = obj.backup;
          partitionResizeObj['wrap'] = obj.wrap;
          partitionResizeObj['csr'] = obj.csr;
          if (obj.partitionData != null) {

            partitionResizeObj['partitionData']['keysAvaliable'] = obj.partitionData.keysAvaliable;
            partitionResizeObj['partitionData']['sslContextAvaliable'] = obj.partitionData.sslContextAvaliable;
            partitionResizeObj['partitionData']['acclrDevicesAvaliable'] = obj.partitionData.acclrDevicesAvaliable;
            partitionResizeObj['partitionData']['backup'] = obj.partitionData.backup;
            partitionResizeObj['partitionData']['allocatedAccelDevices'] = obj.partitionData.allocatedAccelDevices;
            partitionResizeObj['partitionData']['allocatedUserKeys'] = obj.partitionData.allocatedUserKeys;
            partitionResizeObj['partitionData']['allocatedSSLContexts'] = obj.partitionData.allocatedSSLContexts;
            partitionResizeObj['partitionData']['backup'] = obj.partitionData.backup;
            partitionResizeObj['partitionData']['modifiedUserKeys'] = obj.partitionData.modifiedUserKeys;
            partitionResizeObj['partitionData']['modifiedSSLContexts'] = obj.partitionData.modifiedSSLContexts;
            partitionResizeObj['partitionData']['modifiedAccelDevices'] = obj.partitionData.modifiedAccelDevices;
            // partitionResizeObj['partitionData']['incrementKeys'] = obj.partitionData.incrementKeys;
            // partitionResizeObj['partitionData']['incrementSslContexts'] = obj.partitionData.incrementSslContexts;
            // partitionResizeObj['partitionData']['incrementAcclrDev'] = obj.partitionData.incrementAcclrDev;
            this.partitionResizeList.push(partitionResizeObj);
          }
        });

        this.partitionResizeData = this.partitionResizeList[this.partitionCount - 1];
        this.partitionName = this.selectedPartitionList[this.partitionCount - 1]['applianceDetailModel']['applianceName'] + ":" + this.selectedPartitionList[this.partitionCount - 1]['partitionName'];
        this.partitionName1 = this.selectedPartitionList[this.partitionCount - 1]['partitionName'];
        this.setbackup = this.partitionResizeList[this.partitionCount - 1]['partitionData']['backup'];
        if (this.setbackup == true) {
          this.form.get('backup').setValue(true);
        }
        else {
          this.form.get('backup').setValue(false);
        }
        this.totalPartitionCount = this.selectedPartitionList.length;
        let count = this.partitionCount - 1;
        this.resizeModal.show();
        if (this.partitionCount < this.selectedPartitionList.length) {

          this.showBackButton = false;
        } else if (this.partitionCount == this.selectedPartitionList.length) {
          this.showNextButton = false;
          if (this.partitionCount != 1) {
            this.showBackButton = true;
          }
        }
        else {
          this.showNextButton = false;
          this.showBackButton = true;
        }
      }
    )
    this.form.get('userkeys').setValue(0);
    this.form.get('sslcontexts').setValue(0);
    this.form.get('acclrdevices').setValue(0);
    this.ModifiedAccelDevices = 0;
    this.ModifiedUserKeys = 0;
    this.ModifiedSSLContexts = 0;
  }

  NextResize() {
    $("#resize").fadeOut(20);
    this.form.reset();

    this.showNextButton = false;
    if (this.partitionCount < this.selectedPartitionList.length) {
      this.partitionResizeData = {};
      this.partitionResizeData = this.partitionResizeList[this.partitionCount];
      this.displayError = '';
      this.displayError1 = '';
      this.setbackup = false;
      this.form.reset();
      this.partitionName = this.selectedPartitionList[this.partitionCount]['applianceDetailModel']['applianceName'] + ":" + this.selectedPartitionList[this.partitionCount]['partitionName'];
      this.partitionName1 = this.selectedPartitionList[this.partitionCount]['partitionName'];
      this.setbackup = this.partitionResizeList[this.partitionCount]['partitionData']['backup'];
      this.form.get('userkeys').setValue(0);
      this.form.get('sslcontexts').setValue(0);
      this.form.get('acclrdevices').setValue(0);
      this.ModifiedAccelDevices = 0;
      this.ModifiedUserKeys = 0;
      this.ModifiedSSLContexts = 0;
      if (this.setbackup == true) {
        this.form.get('backup').setValue(true);
      }
      else {
        this.form.get('backup').setValue(false);
      }
      this.partitionCount++;
      this.showBackButton = true;
      if (this.partitionCount == this.selectedPartitionList.length) {
        this.showNextButton = false;
      }
      this.modal = [];
      $("#logs").fadeIn("slow");
    }
    else {
      this.form.reset();
      // this.applianceCount++;
    }
  }

  backToPreviousPartition() {
    $("#resize").fadeOut(20);
    this.form.reset();

    this.setbackup = false;
    this.displayError = '';
    this.displayError1 = '';
    this.form.get('userkeys').setValue(0);
    this.form.get('sslcontexts').setValue(0);
    this.form.get('acclrdevices').setValue(0);
    this.invalidUkey = true;
    this.invalidSSL = true;
    this.invalidAccl = true;
    this.partitionName1 = this.selectedPartitionList[this.partitionCount - 2]['partitionName'];
    this.partitionName = this.selectedPartitionList[this.partitionCount - 2]['applianceDetailModel']['applianceName'] + ":" + this.selectedPartitionList[this.partitionCount - 2]['partitionName'];
    this.setbackup = this.partitionResizeList[this.partitionCount - 2]['partitionData']['backup'];

    this.ModifiedAccelDevices = 0;
    this.ModifiedUserKeys = 0;
    this.ModifiedSSLContexts = 0;
    if (this.setbackup == true) {
      this.form.get('backup').setValue(true);
    }
    else {
      this.form.get('backup').setValue(false);
    }
    let backOperationCount = this.partitionCount - 2;
    let partitionData = this.finalPartitionList[backOperationCount];
    this.partitionResizeData = {};
    this.partitionResizeData = this.partitionResizeList[this.partitionCount - 2];
    this.showNextButton = false;
    //this.setPartitionDataToForm(partitionData);
    this.partitionCount = this.partitionCount - 1;
    if (this.partitionCount == 1) {
      this.showBackButton = false;
    }
    if (this.setbackup == true) {
      this.form.get('backup').setValue(true);
    }
    // this.staticTabs.tabs[0].active = true;
    // this.tabName ="General";
    $("#resize").fadeIn("slow");
  }

  pushPartitionDataIntoList() {
    this.finalPartitionList.push(this.form.value);
  }

  goToNext() {
    this.messageModal.hide();
    this.invalidUkey = true;
    this.invalidSSL = true;
    this.invalidAccl = true;
    this.NextResize();
  }

  // backOperationFromFinalList() {


  //   $("#resize").fadeOut(20);

  //   //this.form.reset();

  //   this.partitionName = this.finalPartitionList[this.partitionCount - 1]['partitionName'];

  //   let partitionData = this.finalPartitionList[this.partitionCount - 1];

  //   //this.setPartitionDataToForm(partitionData);

  //   if (this.partitionCount == 1) {

  //     this.showBackButton = false;

  //   } else {

  //     //this.applianceCount = this.applianceCount - 1;

  //     this.showBackButton = true;

  //   }

  //   this.showFinalResize = false;



  //   $("#resize").fadeIn("slow");

  // }



  // closeresizeModel() {

  //   this.resizeModal.hide();

  //   this.clearData();

  // }



  resizeSubmit() {
    this.message = '';
    this.success = 0;
    this.stayButton = false;
    let nomodify: boolean;

    let ukeymod: number = this.form.get('userkeys').value;
    let sslmod = this.form.get('sslcontexts').value;
    let acclmod = this.form.get('acclrdevices').value;
    let backupmod = this.form.get('backup').value;
    let backupcheck = this.setbackup;
    if (ukeymod == 0 && sslmod == 0 && acclmod == 0 && backupmod == backupcheck) {
      nomodify = false;

    } else {
      nomodify = true;
    }
    if (nomodify) {
      this.stayButton = false;
      this.loading = true;
      let partitionModel = this.selectedPartitionList[this.partitionCount - 1];
      this.partitionResizeData['applianceDetailModel'] = partitionModel.applianceDetailModel;
      this.partitionResizeData['sessionClose'] = partitionModel.sessionClose;
      this.partitionResizeData['username'] = partitionModel.username;
      this.partitionResizeData['password'] = partitionModel.password;
      if (this.setbackup == true) {
        this.partitionResizeData['partitionData']['backup'] = this.setbackup;
      } if (this.togglechange != 0) {
        this.partitionResizeData['partitionData']['backup'] = this.backupChecked;
      }
      this._service.submitResizeData(this.partitionResizeData).subscribe(
        (response) => {
          this.loading = false;
          //  this.resizeModal.hide();
          if (response.code == "200") {
            this.message = response.applianceName + ":" + response.partitionName + ":-" + response.message;
            this.success = 1;
          } else {
            this.message = response.applianceName + ":" + response.partitionName + ":-" + response.errorMessage;
            this.success = 0;
            if (this.partitionCount != this.selectedPartitionList.length) {

              this.showNextButton = true;
            }
          }
          if (this.partitionCount != this.selectedPartitionList.length) {
            this.closeButton = false;
          }
          else if (this.partitionCount == this.selectedPartitionList.length) {
            this.closeButton = true;
          }
          if (this.success == 0) {
            this.messageModal.show();
            this.closeButton = true;
          } else {
            this.messageModal.show();
          }

        }
      )
    }
    else {
      this.message = "No Modifications made. Please make your change or proceed to next operation.";
      this.messageModal.show();
      this.stayButton = true;
      if (this.partitionCount == this.selectedPartitionList.length) {
        this.closeButton = true;
        this.stayButton = false;
      }
      else {
        this.closeButton = false;
      }

    }

  }

  callBackToPartitionList() {

    if ((this.partitionCount == this.totalPartitionCount) && this.success == 1) {
      this.clearData();
      this.messageModal.hide();
      this.resizeModal.hide();
      this.messageEvent5.emit();
    } else if (this.stayButton == true) {
      this.goToNext();
    }
    else {
      this.closeModal();
      this.messageModal.hide();
    }

  }
  redirectToListAppliance() {
    this.clearData();
    this.messageModal.hide();
    this.resizeModal.hide();
    this.messageEvent5.emit();
  }


  // setValuesToForm(backOperationCount) {

  //   this.form.get('ModifiedUserKeys').setValue(this.resizeDataList[backOperationCount]['ModifiedUserKeys']);

  //   this.form.get('ModifiedSSLContexts').setValue(this.resizeDataList[backOperationCount]['ModifiedSSLContexts']);

  //   this.form.get('ModifiedAccelDevices').setValue(this.resizeDataList[backOperationCount]['ModifiedAccelDevices']);

  // }



  clearData() {
    this.form.reset();
    this.success = 0;
    this.partitionCount = 1;
    this.totalPartitionCount = 0;
    this.selectedPartitionList = [];
    this.partitionName = '';
    this.partitionName1 = '';
    this.finalPartitionList = []
    this.showBackButton = false;
    this.showNextButton = false;
    this.showFinalResize = false;
    this.submitvalid = false;
    this.resizeDataList = [];
    this.ModifiedUserKeys = 0;
    this.ModifiedSSLContexts = 0;
    this.ModifiedAccelDevices = 0;
    this.partitionResizeData = {};
    this.backupChecked = false;
    this.setbackup = false;
    this.invalidUkey = true;
    this.invalidSSL = true;
    this.invalidAccl = true;
  }



  getUserKeys(value) {
    let temp = this.partitionResizeData['partitionData']['allocatedUserKeys'];
    if (value != "") {
      this.invalidUkey = true;
      if (this.partitionResizeData != null) {
        if (this.validuserkeys == false && this.validsslcont == false && this.validacclrdev == false) {
          this.submitvalid = false;
        }
        let ukeyvalue = parseInt(value);
        let allocatedUserKeys = 0;
        if (this.partitionResizeData['partitionData']['allocatedUserKeys'] != null) {
          allocatedUserKeys = this.partitionResizeData['partitionData']['allocatedUserKeys'];
        }

        let keysAvaliable = this.partitionResizeData['partitionData']['keysAvaliable'];
        if (((allocatedUserKeys + ukeyvalue) < 1) || (ukeyvalue > keysAvaliable)) {
          this.ModifiedUserKeys = parseInt(value) + (allocatedUserKeys);
          this.validuserkeys = true;
          this.submitvalid = true;
        }
        else {
          this.validuserkeys = false;
          this.submitvalid = false;
          this.ModifiedUserKeys = parseInt(value) + (allocatedUserKeys);
          if (this.ModifiedUserKeys < allocatedUserKeys) {
            this.partitionResizeData['partitionData']['incrementKeys'] = false;
            this.partitionResizeData['partitionData']['modifiedUserKeys'] = value * (-1);
          } else if (this.ModifiedUserKeys > allocatedUserKeys) {
            this.partitionResizeData['partitionData']['incrementKeys'] = true;
            this.partitionResizeData['partitionData']['modifiedUserKeys'] = value * (1);
          }

        }
      }
      if (temp == this.ModifiedUserKeys) {
        this.ModifiedUserKeys = 0;
      }
    } else {
      this.submitvalid = true;
      this.invalidUkey = false;
      this.validuserkeys = false
    }
    if (this.submitvalid == false && this.invalidSSL == true && this.invalidUkey == true && this.invalidAccl == true) {
      this.submitvalid = false;
    }
    else {
      this.submitvalid = true;
    }

  }

  getSslContexts(value) {
    let temp = this.partitionResizeData['partitionData']['allocatedSSLContexts'];
    if (value != "") {
      this.invalidSSL = true;
      if (this.partitionResizeData != null) {
        if (this.validuserkeys == false && this.validsslcont == false && this.validacclrdev == false) {
          this.submitvalid = false;
        }
        let sslvalue = parseInt(value);
        let allocatedSSLContexts = 0;
        if (this.partitionResizeData['partitionData']['allocatedSSLContexts'] != null) {
          allocatedSSLContexts = this.partitionResizeData['partitionData']['allocatedSSLContexts'];
        }
        let sslContextAvaliable = this.partitionResizeData['partitionData']['sslContextAvaliable'];
        if (((allocatedSSLContexts + sslvalue) < 1) || (sslvalue > sslContextAvaliable)) {
          this.ModifiedSSLContexts = parseInt(value) + (allocatedSSLContexts);
          this.validsslcont = true;
          this.submitvalid = true;
        }
        else {
          this.validsslcont = false;
          this.submitvalid = false;
          this.ModifiedSSLContexts = parseInt(value) + (allocatedSSLContexts);
          if (this.ModifiedSSLContexts < allocatedSSLContexts) {
            this.partitionResizeData['partitionData']['incrementSslContexts'] = false;
            this.partitionResizeData['partitionData']['modifiedSSLContexts'] = value * (-1);
          } else if (this.ModifiedSSLContexts > allocatedSSLContexts) {
            this.partitionResizeData['partitionData']['incrementSslContexts'] = true;
            this.partitionResizeData['partitionData']['modifiedSSLContexts'] = value * (1);
          }

        }
      }
      if (temp == this.ModifiedSSLContexts) {
        this.ModifiedSSLContexts = 0;
      }
    }
    else {
      this.submitvalid = true;
      this.invalidSSL = false;
      this.validsslcont = false
    }
    if (this.submitvalid == false && this.invalidSSL == true && this.invalidUkey == true && this.invalidAccl == true) {
      this.submitvalid = false;
    }
    else {
      this.submitvalid = true;
    }

  }

  getAcclrDev(value) {
    let temp = this.partitionResizeData['partitionData']['allocatedAccelDevices'];
    if (value != "") {
      this.invalidAccl = true;
      if (this.partitionResizeData != null) {
        if (this.validuserkeys == false && this.validsslcont == false && this.validacclrdev == false) {
          this.submitvalid = false;
        }
        let acclrvalue = parseInt(value);
        let allocatedAccelDevices = 0
        if (this.partitionResizeData['partitionData']['allocatedAccelDevices'] != null) {
          allocatedAccelDevices = this.partitionResizeData['partitionData']['allocatedAccelDevices'];
        }

        let acclrDevicesAvaliable = this.partitionResizeData['partitionData']['acclrDevicesAvaliable'];
        if (((allocatedAccelDevices + acclrvalue) < 1) || (acclrvalue > acclrDevicesAvaliable)) {
          this.ModifiedAccelDevices = parseInt(value) + (allocatedAccelDevices);
          this.validacclrdev = true;
          this.submitvalid = true;
        } else {
          this.validacclrdev = false;
          this.submitvalid = false;
          this.ModifiedAccelDevices = parseInt(value) + (allocatedAccelDevices);
          if (this.ModifiedAccelDevices < allocatedAccelDevices) {
            this.partitionResizeData['partitionData']['incrementAcclrDev'] = false;
            this.partitionResizeData['partitionData']['modifiedAccelDevices'] = value * (-1);
          } else if (this.ModifiedAccelDevices > allocatedAccelDevices) {
            this.partitionResizeData['partitionData']['incrementAcclrDev'] = true;
            this.partitionResizeData['partitionData']['modifiedAccelDevices'] = value * (1);
          }

        }
      }
      if (temp == this.ModifiedAccelDevices) {
        this.ModifiedAccelDevices = 0;
      }
    }
    else {
      this.submitvalid = true;
      this.invalidAccl = false;
      this.validacclrdev = false
    }
    if (this.submitvalid == false && this.invalidSSL == true && this.invalidUkey == true && this.invalidAccl == true) {
      this.submitvalid = false;
    }
    else {
      this.submitvalid = true;
    }

  }

  changeBackUp(event) {
    if (event.checked) {
      this.backupChecked = true;
      this.togglechange = 1;
    } else {
      this.backupChecked = false;
      this.togglechange = 1;
    }
  }

  closeModal() {
    if ((this.partitionCount == this.totalPartitionCount) && (this.success == 1)) {
      this.resizeModal.hide();
      this.clearData();
    }
    if (this.success == 1) {
      this.NextResize();
    }

  }

}



