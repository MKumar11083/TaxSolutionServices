import { Component, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { PartitionOperationsComponent } from './../../partition-operations/partition-operations.component';
@Component({
  selector: 'app-upload-config',
  templateUrl: './upload-config.component.html',
  styleUrls: ['./upload-config.component.css']
})
export class UploadConfigComponent implements OnInit {
  @ViewChild('uploadModal') uploadModal: ModalDirective;
  @ViewChild('partitionOperationsComponent')
  private partitionOperationsComponent: PartitionOperationsComponent;
  @Output() messageEvent2 = new EventEmitter<any>();
  selectedPartitionList = [];
  selectedOperation: string;
  isFileValidate: boolean = true;
  constructor() { }

  ngOnInit() {

  }

  showUploadConfig(partitionList, operation) {
    this.clearData();
    this.selectedOperation = operation;
    this.createModalForUploadConfig(partitionList);
    this.uploadModal.show();
  }
  createModalForUploadConfig(partitionList) {

    partitionList.forEach(obj => {
      let modal = {
        'certificates': [],
        'applianceDetailModel': {}
      }
      let certificatesobj = {};
      let certificatesList = []
      modal['partitionName'] = obj.partitionName;
      modal['partitionId'] = obj.partitionId;
      modal['username'] = obj.username;
      modal['password'] = obj.password;
      modal['sessionClose'] = obj.sessionClose;
      modal['enableCavServer'] = obj.enableCavServer;
      modal['applianceDetailModel']['applianceId'] = obj.applianceDetailModel.applianceId;
      modal['applianceDetailModel']['applianceName'] = obj.applianceDetailModel.applianceName;
      modal['applianceDetailModel']['ipAddress'] = obj.applianceDetailModel.ipAddress;
      modal['fullName'] = '';
      modal['fileContent'] = '';
      modal['fileName'] = '';
      modal['fileExtension'] = '';
      // certificatesobj['fullName']='';
      certificatesobj['fileContent'] = '';
      certificatesobj['fileName'] = '';
      certificatesobj['fileExtension'] = '';
      certificatesList.push(certificatesobj);
      modal['certificates'] = certificatesList;
      this.selectedPartitionList.push(modal);
      console.log(this.selectedPartitionList);
    });
  }
  // file upload method
  onFileChange(event, index) {
    const filePicked = (event.target as HTMLInputElement).files[0];
    if (filePicked != undefined) {
      const fileName = filePicked.name;
      this.selectedPartitionList[index]['fullName'] = fileName;
      this.selectedPartitionList[index]['fileName'] = fileName.substring(0, fileName.indexOf('.'));
      this.selectedPartitionList[index]['fileExtension'] = filePicked.name.split('.').pop() || filePicked.name;
      const reader = new FileReader();
      reader.onload = () => {
        //let fileContent = reader.result;
        let fileContent =this.stringToBytes(reader.result);
        //let fileContent = this.b64toBlob(btoa(reader.result),'','');
        
        
        this.selectedPartitionList[index]['fileContent'] = fileContent;
        this.selectedPartitionList[index]['errorMsg'] = '';
      };
      reader.readAsText(filePicked);
    } else {
      this.selectedPartitionList[index]['fileName'] = '';
      this.selectedPartitionList[index]['fileContent'] = '';
      this.selectedPartitionList[index]['fileExtension'] = '';
      return false;
    }
  }

 stringToBytes(str) {
  // var ch, st, re = [];
  // for (var i = 0; i < str.length; i++ ) {
	// ch = str.charCodeAt(i);  // get char 
	// st = [];                 // set up "stack"
	// do {
	//   st.push( ch & 0xFF );  // push byte to stack
	//   ch = ch >> 8;          // shift value down by 1 byte
	// }  
	// while ( ch );
	// // add stack contents to result
	// // done because chars have "wrong" endianness
	// re = re.concat( st.reverse() );
  // }
  // // return an array of bytes
  // return re;

  var utf8 = [];
  for (var i=0; i < str.length; i++) {
      var charcode = str.charCodeAt(i);
      if (charcode < 0x80) utf8.push(charcode);
      else if (charcode < 0x800) {
          utf8.push(0xc0 | (charcode >> 6), 
                    0x80 | (charcode & 0x3f));
      }
      else if (charcode < 0xd800 || charcode >= 0xe000) {
          utf8.push(0xe0 | (charcode >> 12), 
                    0x80 | ((charcode>>6) & 0x3f), 
                    0x80 | (charcode & 0x3f));
      }
      // surrogate pair
      else {
          i++;
          // UTF-16 encodes 0x10000-0x10FFFF by
          // subtracting 0x10000 and splitting the
          // 20 bits of 0x0-0xFFFFF into two halves
          charcode = 0x10000 + (((charcode & 0x3ff)<<10)
                    | (str.charCodeAt(i) & 0x3ff));
          utf8.push(0xf0 | (charcode >>18), 
                    0x80 | ((charcode>>12) & 0x3f), 
                    0x80 | ((charcode>>6) & 0x3f), 
                    0x80 | (charcode & 0x3f));
      }
  }
  return utf8;
}

  uploadConfig() {
    let count = 0;
    this.isFileValidate = true;
    this.selectedPartitionList.forEach(obj => {
      let content = obj.fileContent;
      if (content != null && content != '') {
        let certificatesobj = {};
        let certificatesList = [];
        // certificatesobj['fileContent']=obj.fileContent;
        // certificatesobj['fileName']=obj.fileName;
        // certificatesobj['fileExtension']=obj.fileExtension;
        // certificatesList.push(certificatesobj);
        //this.selectedPartitionList[count]['certificates'] = certificatesList;
        this.selectedPartitionList[count]['certificates'][0]['fileContent'] = obj.fileContent;
        this.selectedPartitionList[count]['certificates'][0]['fileName'] = obj.fileName;
        this.selectedPartitionList[count]['certificates'][0]['fileExtension'] = obj.fileExtension;
        // let content1 = obj['certificates'][0].fileContent;
      } else {
        this.isFileValidate = false;
        this.selectedPartitionList[count]['errorMsg'] = "Please upload config file";
      }
      count = count + 1;
    });
    if (this.isFileValidate) {
      console.log(this.selectedPartitionList);
      this.uploadModal.hide();
      this.partitionOperationsComponent.performSelectedOperation(this.selectedPartitionList, this.selectedOperation);
    }
  }

  clearData() {
    this.selectedPartitionList = [];
    this.selectedOperation = '';
    this.isFileValidate = true;
  }
  closeUploadConfig() {
    this.uploadModal.hide();
    this.clearData();
  }
  callBackToPartitionLogin() {
    console.log("Upload Config  --> Call back to partition login page");
    this.clearData();
    this.messageEvent2.emit();
  }
}
