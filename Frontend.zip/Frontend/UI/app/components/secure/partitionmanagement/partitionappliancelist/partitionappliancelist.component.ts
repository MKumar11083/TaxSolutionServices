
import { Component, OnInit, TemplateRef, ViewChild, OnDestroy,ElementRef } from '@angular/core';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { AnonymousSubscription } from "rxjs/Subscription";
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { BsModalService } from 'ngx-bootstrap/modal';
import { DataTableResource } from './../../data-table/index';
import { I18nService } from '../../../../services/common/i18n/i18n.service';
import { BreadcrumbService } from './../../../../services/common/breadcrumb.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { PartitionManagementService } from './../../../../services/partitionmanagement/partitionmanagement.service';
import { CreatenewpartitionComponent } from './../../../secure/partitionmanagement/createnewpartition/createnewpartition.component';

@Component({
  selector: 'app-partitionappliancelist',
  templateUrl: './partitionappliancelist.component.html',
  styleUrls: ['./partitionappliancelist.component.css']
})
export class PartitionappliancelistComponent implements OnInit, OnDestroy {
  @ViewChild('certificate') certificateVariable: ElementRef;
  @ViewChild('key')
  keyVariable: ElementRef;
  @ViewChild('loginModal') loginModal: ModalDirective;
  @ViewChild('createPartition') createPartition: CreatenewpartitionComponent;
  @ViewChild('messageModal') messageModal: ModalDirective;
  loginForm: FormGroup;
  modalRef: BsModalRef;
  title = "Partition Details";
  message: string;
  showButton: boolean = false;
  username: string = '';
  password: string = '';
  appliancesList: any = [];
  itemResource: any;
  displayErrors: any = [];
  showList: boolean = true;
  selectedAppliances: any = [];
  showPartitionList: boolean = true;
  applianceName: string;
  loginCredentialsArray: any = [];
  loading: boolean = false;
  checkLoginCredentialsResultArray: any = [];
  private applianceListSubscription: AnonymousSubscription;
  private validateApplianceSubscription: AnonymousSubscription;
  applianceDualFactorInitialized : boolean = false;
  notReachableList : any= [];
  constructor(private _applianceManagementService: AppliancemanagementService,
    private _I18nService: I18nService,
    private _formBuilder: FormBuilder,
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _service: PartitionManagementService,
    private modalService: BsModalService) { }

  ngOnInit() {
    this.selectedAppliances = [];
    this.createLoginForm();
    this.applianceListSubscription = this._applianceManagementService.getAllListAppliances().subscribe(
      res => {
        if (res.length > 0) {
          for (var i = 0; i < res.length; i++) {
            let appliance = res[i];
            appliance['disabled'] = false;
            let availableKeys = (appliance.totalKeys - appliance.occupiedKeys);
            appliance['availableKeys'] = availableKeys;
            let availableContexts = (appliance.totalContexts - appliance.occupiedContexts);
            appliance['availableContexts'] = availableContexts;
            let availableAcclrDevice = (appliance.totalAcclrDevice - appliance.occupiedAcclrDev);
            appliance['availableAcclrDevice'] = availableAcclrDevice;

            if (appliance['applianceStatus'] == 'Active') {
              appliance['showColor'] = "green";
            } else if (appliance['applianceStatus'] == 'Inactive') {
              appliance['showColor'] = "red";
            } else if (appliance['applianceStatus'] == 'Suspended') {
              appliance['showColor'] = "yellow";
            }
            if (appliance['lastOperationStatus'] === 'In-Progress') {
              appliance['InProgress'] = true;
              appliance['showColor'] = "grey";
            } else if (appliance['lastOperationStatus'] === 'In-Progress'
              && appliance['grayedOut'] == true) {
                appliance['InProgress'] = true;
                appliance['showColor'] = "grey";
            } else if (appliance['lastOperationStatus'] != 'In-Progress'
              && appliance['grayedOut'] == true) {
                appliance['InProgress'] = false;
                appliance['showColor'] = "grey";
            } else {
              appliance['InProgress'] = false;
            }
            this.appliancesList.push(appliance);
          }
        }
      },
      error => {
        console.log(error);
      },
    );
  }

  getSortedList(option) {
    if (this.appliancesList.length > 0) {
      switch (option) {

        case "1": this.appliancesList.sort((a, b) => {
          if (a.availableKeys < b.availableKeys) {
            return 1;
          } else if (a.availableKeys > b.availableKeys) {
            return -1;
          } else {
            return 0;
          }
        });
          console.log("after sorting ==>")
          break;

        case "2": this.appliancesList.sort((a, b) => {
          if (a.availableContexts < b.availableContexts) {
            return 1;
          } else if (a.availableContexts > b.availableContexts) {
            return -1;
          } else {
            return 0;
          }
        });
          break;

        case "3": this.appliancesList.sort((a, b) => {
          if (a.totalAcclrDevice < b.totalAcclrDevice) {
            return 1;
          } else if (a.totalAcclrDevice > b.totalAcclrDevice) {
            return -1;
          } else {
            return 0;
          }
        });
          break;

        default: console.log("Error");

      }
    }
  }


  createLoginForm() {
    this.loginForm = this._formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      dualFactorAuthServerPortNo:[''],
      certificateFile: [""],
      keyFile: [""],
      certificateName: [''],
      certificateExtension: [''],
      certificateContent: [''],
      keyfileName: [''],
      keyfileExtension: [''],
      keyfileContent: ['']
	  
    });
  }
  toggle() {
    this.showList = false;
  }
  toggle1() {
    this.showList = true;
  }

  selectApplianceItems(event, applianceId, template: TemplateRef<any>) {
    if (event.target.checked) {
      event.currentTarget.style.visibility = "visible";
      for (var i = 0; i < this.appliancesList.length; i++) {
        if (this.appliancesList[i].applianceId == applianceId) {
          this.selectedAppliances.push(this.appliancesList[i]);
          this.appliancesList[i]['checked'] = true;
          this.appliancesList[i]['disabled'] = false;
        }
        else if (!this.appliancesList[i]['checked']) {
          this.appliancesList[i]['disabled'] = true;
          this.appliancesList[i]['checked'] = false;
        }
      }
      this.validateInitOperation(this.selectedAppliances[0], template);
    } else {
      event.currentTarget.style.visibility = "";
      this.showButton = false;
      for (var i = 0; i < this.appliancesList.length; i++) {
        if (this.appliancesList[i].applianceId == applianceId) {
          let index = this.selectedAppliances.indexOf(applianceId);
          this.selectedAppliances.splice(index);
        }
        this.appliancesList[i]['disabled'] = false;
        this.appliancesList[i]['checked'] = false;
      }
    }
  }


  validateInitOperation(appliance, template) {
    // if(!appliance.applianceinitialized){
    //   this.message = "Selected Appliance is not Initialize ";
    //   //       this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
    // }
    appliance.partitionDetailModels = null;
    this._service.validateInitOperation(appliance).subscribe(
      res => {
        if (res.responseCode == "200") {
          this.showButton = true;
          // this.message = "Selected Appliance is Initialize Successfully";
          // this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
        } else if (res.responseCode == "401") {
          this.showButton = false;
          this.message = "Selected Appliance is not Initialize ";
          this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
        }
      })
  }

  showLoginForm(template: TemplateRef<any>) {
    this.notReachableList = [];
    this.notReachableList = this.selectedAppliances.filter(appliance => {
      if (appliance['applianceStatus'] == 'Inactive') {
        return appliance;
      }
    });
    if(this.notReachableList<=0){
      if (this.selectedAppliances[0].occupiedPartitions < 32) {
        this.loginForm.reset();
        this.applianceDualFactorInitialized = false;
        this.applianceName = this.selectedAppliances[0].applianceName;
        // check appliance credentials are available in localsession.
        // if available in localsession , skips the login for appliance.
        if (!this.selectedAppliances[0]['credentialSaved']) {
          let loginCredentials = JSON.parse(localStorage.getItem(this.selectedAppliances[0].ipAddress));
          if (loginCredentials != null) {
            this.selectedAppliances[0]['operationUsername'] = loginCredentials.username;
            this.selectedAppliances[0]['operationPassword'] = loginCredentials.password;
            this.selectedAppliances[0]['userName'] = loginCredentials.username;
            this.selectedAppliances[0]['userPassword'] = loginCredentials.password;
            this.showPartitionList = false;
          } else {
            this.applianceDualFactorInitialized = this.selectedAppliances[0]['applianceDualFactorInitialized'];
            this.setValidationDualFactorAuthentication();
            this.loginModal.show();
          }
        } else {
          this.showPartitionList = false;
        }
      } else {
        this.message = "Selected Appliance has reached the maximum 32 partitions ";
        this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
      }
    }else{
      this.messageModal.show();
    }
  }

  goToCreatePartition() {
    this.loginModal.hide();
    //this.showPartitionList= false;
    const username = this.loginForm.get('username').value;
    const password = this.loginForm.get('password').value;
    this.selectedAppliances[0].userName = username;
    this.selectedAppliances[0].userPassword = password;
    let loginDetailsModal = {};
    loginDetailsModal['applianceId'] = this.selectedAppliances[0].applianceId;
    loginDetailsModal['applianceName'] = this.selectedAppliances[0].applianceName;
    loginDetailsModal['ipAddress'] = this.selectedAppliances[0].ipAddress;
    loginDetailsModal['operationUsername'] = username;
    loginDetailsModal['operationPassword'] = password;
    loginDetailsModal['applianceDualFactorInitialized'] = this.selectedAppliances[0].applianceDualFactorInitialized;
    let dualFactorCheck = this.selectedAppliances[0].applianceDualFactorInitialized;
    if (dualFactorCheck) {
      loginDetailsModal = this.setDualFactorData(loginDetailsModal);
    }
    this.loginCredentialsArray.push(loginDetailsModal);
    this.checkAppliancesCredentials();
  }

  checkAppliancesCredentials() {
    this.loading = true;
    if(this.applianceDualFactorInitialized){
      this.certificateVariable.nativeElement.value = '';
      this.keyVariable.nativeElement.value = "";
    }
    this.checkLoginCredentialsResultArray = [];
    this._applianceManagementService.checkAppliancesCredentials(this.loginCredentialsArray).subscribe(
      (response) => {
        let isSuccess: boolean = true;
        this.loading = false;
        response.forEach(obj => {
          this.loginCredentialsArray = [];
          if (obj.code != "200") {

            this.checkLoginCredentialsResultArray.push(obj);
            isSuccess = false;
          }
        });
        if (isSuccess) {
          // Storing appliance login credentials in local session
          let ipAddress = this.selectedAppliances[0].ipAddress;
          let loginCredentials = {
            username: this.loginForm.get('username').value,
            password: this.loginForm.get('password').value
          };
          localStorage.setItem(ipAddress, JSON.stringify(loginCredentials));
          // local session code ends here
          this.loginModal.hide();
          this.showPartitionList = false;
        } else {
          
          this.messageModal.show();
        }
      },
      (error) => {
        console.log(error);
      })
  }
  public formValidationFields1 = {
    "username": '',
    "password": '',
    "dualFactorAuthServerPortNo" :''

  }
  isFieldValid1(field: string) {
    if (this.loginForm.get(field).touched) {
      this.formValidationFields1 = this._fieldErrorDisplayService.validateField(this.loginForm, field, this.formValidationFields1, "login")
    }
    return !this.loginForm.get(field).valid && this.loginForm.get(field).touched;
  }

  displayFieldCss1(field: string) {
    return {
      'has-error': this.isFieldValid1(field),
      'has-feedback': this.isFieldValid1(field)
    };
  }

  ngOnDestroy() {
    if (this.applianceListSubscription) {
      this.applianceListSubscription.unsubscribe();
    }
    if (this.validateApplianceSubscription) {
      this.validateApplianceSubscription.unsubscribe();
    }
  }

  setDualFactorData(loginDetailsModal) {
    loginDetailsModal['initializeDetailModel'] = {};
    loginDetailsModal['initializeDetailModel']['cryptoOfficerName'] = this.loginForm.get('username').value;
    loginDetailsModal['initializeDetailModel']['cryptoOfficerPassword'] = this.loginForm.get('password').value;
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel'] = {};

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['dualFactorAuthServerPortNo'] = this.loginForm.get('dualFactorAuthServerPortNo').value;
    // certificate file details
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateContent'] = this.loginForm.get('certificateContent').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateName'] = this.loginForm.get('certificateName').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateExtension'] = this.loginForm.get('certificateExtension').value;
    // key file details
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileContent'] = this.loginForm.get('keyfileContent').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileName'] = this.loginForm.get('keyfileName').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileExtension'] = this.loginForm.get('keyfileExtension').value;
    return loginDetailsModal;
  }

  setValidationDualFactorAuthentication() {
    // set validations for dual factor properties 
    if (this.applianceDualFactorInitialized) {
      this.loginForm.get('dualFactorAuthServerPortNo').setValidators(Validators.required);
      this.loginForm.get('certificateFile').setValidators(Validators.required);
      this.loginForm.get('keyFile').setValidators(Validators.required);
    } else {
      this.loginForm.get('dualFactorAuthServerPortNo').setValidators(null);
      this.loginForm.get('certificateFile').setValidators(null);
      this.loginForm.get('keyFile').setValidators(null);
    }
    this.loginForm.get('dualFactorAuthServerPortNo').updateValueAndValidity();
    this.loginForm.get('certificateFile').updateValueAndValidity();
    this.loginForm.get('keyFile').updateValueAndValidity();
  }

  onCertificateFileChange($event) {
    this.loginForm.get('certificateFile').markAsTouched({ onlySelf: true });
    let file = $event.target.files[0]; 
    this.loginForm.controls['certificateFile'].setValue(file ? file.name : ''); // <-- Set Value for Validation
    const filePicked = (event.target as HTMLInputElement).files[0];
    if (filePicked != undefined) {
      const fileName = filePicked.name;
      const extension = filePicked.name.split('.').pop() || '';
      const reader = new FileReader();
      reader.onload = () => {
        if (extension == 'crt') {
          this.loginForm.get('certificateContent').setValue(reader.result);
          this.loginForm.get('certificateName').setValue(fileName.substring(0, fileName.indexOf('.')));
          this.loginForm.get('certificateExtension').setValue(extension);
        } else {
          this.loginForm.get('certificateFile').setErrors({"invalidExt":true})
         
        }
      };
      reader.readAsText(filePicked);
    } else {
      this.loginForm.get('certificateFile').setValue("");
      this.loginForm.get('certificateContent').setValue("");
      this.loginForm.get('certificateName').setValue("");
      this.loginForm.get('certificateExtension').setValue("");
      return false;
    }
  } 

  onKeyFileChange($event) {
    this.loginForm.controls['keyFile'].markAsTouched({ onlySelf: true });
    let file = $event.target.files[0]; 
    this.loginForm.controls['keyFile'].setValue(file ? file.name : ''); // <-- Set Value for Validation
    const filePicked = (event.target as HTMLInputElement).files[0];
    if (filePicked != undefined) {
      const fileName = filePicked.name;
      let ext  = filePicked.name.split('.');
      const extension =  ext[1];
      const reader = new FileReader();
      reader.onload = () => {
        if (extension == 'key') {
          this.loginForm.get('keyfileContent').setValue(reader.result);
          this.loginForm.get('keyfileName').setValue(fileName.substring(0, fileName.indexOf('.')));
          this.loginForm.get('keyfileExtension').setValue(extension);
        } else {
          this.loginForm.get('keyFile').setErrors({"invalidExt":true})
         
        }
      };
      reader.readAsText(filePicked);
    } else {
      this.loginForm.get('keyFile').setValue("");
      this.loginForm.get('keyfileContent').setValue("");
      this.loginForm.get('keyfileName').setValue("");
      this.loginForm.get('keyfileExtension').setValue("");
      return false;
    }
  } 
	  
}