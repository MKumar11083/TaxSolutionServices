import { Component, OnInit, ViewChild, Output, EventEmitter, OnDestroy, ElementRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { PartitionOperationsComponent } from './../partition-operations/partition-operations.component';
import { AnonymousSubscription } from "rxjs/Subscription";
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
@Component({
  selector: 'app-backup-restore',
  templateUrl: './backup-restore.component.html',
  styleUrls: ['./backup-restore.component.css']
})
export class BackupRestoreComponent implements OnInit, OnDestroy {
  @ViewChild('myInput')
  myInputVariable: ElementRef;
  @ViewChild('backupRestoreModal') backupRestoreModal: ModalDirective;
  @ViewChild('partitionOperationsComponent')
  private partitionOperationsComponent: PartitionOperationsComponent;
  @Output() messageEvent3 = new EventEmitter<any>();
  selectedPartitionList: any = [];
  selectedOperation: string;
  toggleRadioOperation: boolean;
  restoreBackUp: any = {
    'fileContent': []
  }
  fileName: string = '';
  restorePartitionModel: any = {};
  applianceListSubscription: AnonymousSubscription;
  partitionListSubscription: AnonymousSubscription;
  appliancesList: any = [];
  partitionList: any = [];
  applianceId: string;
  partitionId: string;
  noKey: boolean = false;
  applianceModal: any = {};
  showlogin: boolean = false;
  partitionIdsArray :any = [];
  checkNodeIdRequired : boolean = true;
  restoreFile: File;
  dualFactor : boolean = false;
  constructor(private _applianceService: AppliancemanagementService) {
  }

  ngOnInit() {
  }

  showBackUpRestore(partitionList, operation) {
    this.myInputVariable.nativeElement.value = "";
    this.showlogin = false;
    this.clearData();
    this.toggleRadioOperation = true;
    this.selectedOperation = operation;
    this.getApplianceList();
    this.createPartitionList(partitionList);
    this.applianceModal = this.backUpFromPartition();
    this.backupRestoreModal.show();
  }

  getApplianceList() {
    this.applianceListSubscription = this._applianceService.getAllListAppliances().subscribe(
      response => {
        this.appliancesList = response;
      }, error => {
        console.log(error);
      })
  }
  createPartitionList(partitionList) {
    partitionList.forEach(obj => {
      let partitionModal = {
        //'applianceDetailModel': {}
      };
      partitionModal['partitionId'] = obj.partitionId;
      this.partitionIdsArray.push(obj.partitionId);
      partitionModal['partitionName'] = obj.partitionName;
      partitionModal['username'] = obj.username;
      partitionModal['password'] = obj.password;
      partitionModal['sessionClose'] = obj.sessionClose;
      partitionModal['checkIntegrity'] = false;
      partitionModal['nodeId'] = '';
      this.selectedPartitionList.push(partitionModal);
    });

  }
  backUpFromPartition() {
    let applianceModal = {
      'fromApplianceId': '',
      'fromPartitionId': '',
      'fromRestoreUsername': '',
      'fromRestorePassword': '',
      'noKey': '',
      'partitionError': '',
      'applianceError': '',
      'dualFactorAuthServerPortNo':'',
      'certificateFile': '',
      'keyFile': '',
      'certificateName': '',
      'certificateExtension':'',
      'certificateContent': '',
      'keyfileName': '',
      'keyfileExtension': '',
      'keyfileContent': ''
    }
    return applianceModal;
  }
  toggleRadioButton(event) {
    this.myInputVariable.nativeElement.value = "";
    this.restoreFile = null;
    this.checkNodeIdRequired=true;
    this.showlogin = false;
    this.restoreBackUp = [];
    this.fileName = '';
    this.applianceModal['fromApplianceId'] = '';
    this.applianceModal['fromPartitionId'] = '';
    this.toggleRadioOperation = !this.toggleRadioOperation;
  }

  onFileChange(event) {
    this.restoreFile = null;
    this.fileName = '';
    //this.myInputVariable.nativeElement.value = "";
    const filePicked = (event.target as HTMLInputElement).files[0];
    // let target = event.target || event.srcElement;
    // target.value = '';
    if (filePicked != undefined) {
      this.restoreFile = filePicked;
      this.fileName = filePicked.name;
    }
  }

  getPartitionListByAppId(applianceId) {
    this.applianceModal['applianceError'] = "";
    this.applianceModal['partitionError'] = "";
    this.applianceModal['fromPartitionId'] = "";
    this.applianceModal['fromRestoreUsername'] = "";
    this.applianceModal['fromRestorePassword'] = "";
    this.dualFactor = false;
    if (applianceId != '') {
      const index = this.appliancesList.findIndex(appliance => appliance.applianceId == applianceId);
      if(index != -1){
        this.dualFactor = this.appliancesList[index]['applianceDualFactorInitialized'];
      }
      let applianceModal = {};
      applianceModal['applianceId'] = applianceId;
      this.partitionList = [];
      this.applianceListSubscription = this._applianceService.getPartitionListByAppId(applianceModal).subscribe(
        response => {
          if(response.length>0){
            response.forEach(element => {
              let flag = this.partitionIdsArray.some(partitionId => partitionId == element.partitionId);
              if(!flag){
                this.partitionList.push(element);
              }
            });
          }
        }, error => {
          console.log(error);
        })
    } else {
      this.showlogin = false;
      this.partitionList = [];
    }
  }

  clearPartitionDropdownErrorMsg(value) {
    this.showlogin = false;
    this.applianceModal['partitionError'] = "";
    this.applianceModal['fromRestoreUsername'] = "";
    this.applianceModal['fromRestorePassword'] = "";
    if (value != '') {
      this.showlogin = true;
    } else {
      this.showlogin = false;
    }
  }
  
  onSubmit() {
    let isValid = true;
    this.checkNodeIdRequired = true;
    this.restoreBackUp['errorMsg'] = '';
    if (this.toggleRadioOperation) {
      if (this.restoreFile == null) {
        isValid = false;
        this.restoreBackUp['errorMsg'] = "Please select the Backup file."
      }
    } else {
      if (this.applianceModal['fromApplianceId'] == '' || this.applianceModal['fromPartitionId'] == '') {
        isValid = false;
        if (this.applianceModal['fromApplianceId'] == '') {
          this.applianceModal['applianceError'] = "Please Select Appliance";
        } else if (this.applianceModal['fromPartitionId'] == '') {
          this.applianceModal['partitionError'] = "Please Select Partition";
        }
      }else{
        if(this.applianceModal.fromRestoreUsername==null || this.applianceModal.fromRestoreUsername==''){
          isValid = false;
          this.applianceModal['usernameRequired'] = true;
        }
        if(this.applianceModal.fromRestorePassword==null || this.applianceModal.fromRestorePassword==''){
          isValid = false;
          this.applianceModal['passwordRequired'] = true;
        }
        if(this.dualFactor){
          if(this.applianceModal.certificateFile==''){
            isValid = false;
            this.applianceModal['certificateFileReq'] = true;
          }
          if(this.applianceModal.keyFile==''){
            isValid = false;
            this.applianceModal['keyFileReq'] = true;
          }
          if(this.applianceModal.dualFactorAuthServerPortNo==''){
            isValid = false;
            this.applianceModal['dualFactorReq'] = true;
          }
        }
      }
    }

    if(this.selectedPartitionList.length>0){
      this.selectedPartitionList.forEach(obj => {
         if(obj.nodeId==null || obj.nodeId == ''){
           if(this.checkNodeIdRequired){
              isValid = false;
             this.checkNodeIdRequired = false;
           }
         }
      });
    }
   
    if (isValid) {
      const formData = new FormData();
      let finalApplianceModel = {
        'fromApplianceId': this.applianceModal.fromApplianceId,
        'fromPartitionId': this.applianceModal.fromPartitionId,
        'fromRestoreUsername': this.applianceModal.fromRestoreUsername,
        'fromRestorePassword': this.applianceModal.fromRestorePassword,
        'noKey': this.applianceModal.noKey
      }
      if(this.dualFactor){
        finalApplianceModel= this.setDualFactorData(finalApplianceModel);
      }
      if (this.toggleRadioOperation) {
        // this.restorePartitionModel['backupFromPartition'] = null;
        // this.restorePartitionModel['file'] = this.restoreBackUp;
        formData.append("backupFrom", JSON.stringify(finalApplianceModel));
        formData.append("partitions", JSON.stringify(this.selectedPartitionList));
        formData.append("restoreFile", this.restoreFile, this.restoreFile.name);
      } else {
        // this.restorePartitionModel['backupFromPartition'] = this.applianceModal;
        // this.restorePartitionModel['file'] = null;
        formData.append("backupFrom", JSON.stringify(finalApplianceModel));
        formData.append("partitions", JSON.stringify(this.selectedPartitionList));
        formData.append("restoreFile", '');
      }
      //this.restorePartitionModel['partitionList'] = this.selectedPartitionList;
      this.backupRestoreModal.hide();
      this.partitionOperationsComponent.performSelectedOperation(formData, this.selectedOperation);
    }
  }

  	  
  setDualFactorData(loginDetailsModal) {
    loginDetailsModal['initializeDetailModel'] = {};
    loginDetailsModal['initializeDetailModel']['cryptoOfficerName'] = this.applianceModal.fromRestoreUsername;
    loginDetailsModal['initializeDetailModel']['cryptoOfficerPassword'] = this.applianceModal.fromRestorePassword;
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel'] = {};

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['dualFactorAuthServerPortNo'] = this.applianceModal.dualFactorAuthServerPortNo;
    // certificate file details
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateContent'] = this.applianceModal.certificateContent;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateName'] =this.applianceModal.certificateName;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateExtension'] = this.applianceModal.certificateExtension;
    // key file details
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileContent'] = this.applianceModal.keyfileContent;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileName'] = this.applianceModal.keyfileName;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileExtension'] = this.applianceModal.keyfileExtension;
    return loginDetailsModal;
  }

  closeBackUpRestoreModal() {
    this.backupRestoreModal.hide();
    this.clearData();
  }
  clearData() {
    this.selectedPartitionList = [];
    this.selectedOperation = '';
    this.toggleRadioOperation = true;
    this.restoreBackUp = {}
    this.fileName = '';
    this.restorePartitionModel = {};
    this.appliancesList = [];
    this.partitionList = [];
    this.applianceId = '';
    this.partitionId = '';
    this.noKey = false;
    this.applianceModal = {}
    this.partitionIdsArray = [];
  }
  callBackToPartitionLogin() {
    console.log("BackUp & Restore  --> Call back to partition login page");
    this.clearData();
    this.messageEvent3.emit();
  }
  public onlyNumericValues(e) {
    let input;
    if (e.metaKey || e.ctrlKey) {
      return true;
    }
    if (e.which === 32) {
      return false;
    }
    if (e.which === 0) {
      return true;
    }
    if (e.which < 33) {
      return true;
    }
    input = String.fromCharCode(e.which);
    return !!/[\d\s]/.test(input);
  }

  ngOnDestroy() {
    if (this.applianceListSubscription) {
      this.applianceListSubscription.unsubscribe();
    }
    if (this.partitionListSubscription) {
      this.partitionListSubscription.unsubscribe();
    }
  }

  validateNodeId(index, nodeId) {
    if (nodeId > 31) {
      this.selectedPartitionList[index]['nodeId'] = '';
    }
  }


  onCertificateFileChange($event) {
    let file = $event.target.files[0]; 
    
    const filePicked = (event.target as HTMLInputElement).files[0];
    if (filePicked != undefined) {
      const fileName = filePicked.name;
      const extension = filePicked.name.split('.').pop() || '';
      this.applianceModal['certificateFile']=fileName; // <-- Set Value for Validation
      const reader = new FileReader();
      reader.onload = () => {
        if (extension == 'crt') {
          this.applianceModal['certificateContent']=reader.result;
          this.applianceModal['certificateName']=fileName.substring(0, fileName.indexOf('.'));
          this.applianceModal['certificateExtension']=extension;
        } else {
          this.applianceModal['certificateFile']='';
         
        }
      };
      reader.readAsText(filePicked);
    } else {
      this.applianceModal['certificateFile']='';
      this.applianceModal['certificateContent']= '';
      this.applianceModal['certificateName']=''
      this.applianceModal['certificateExtension']=''
      return false;
    }
  } 

  onKeyFileChange($event) {
    let file = $event.target.files[0]; 
    
    const filePicked = (event.target as HTMLInputElement).files[0];
    if (filePicked != undefined) {
      const fileName = filePicked.name;
      let ext  = filePicked.name.split('.');
      const extension =  ext[1];
      const reader = new FileReader();
      this.applianceModal['keyFile']=fileName; // <-- Set Value for Validation
      reader.onload = () => {
        if (extension == 'key') {
          this.applianceModal['keyfileContent']=reader.result;
          this.applianceModal['keyfileName']=fileName.substring(0, fileName.indexOf('.'));
          this.applianceModal['keyfileExtension']=extension;
        } else {
          this.applianceModal['keyFile']=''
         
        }
      };
      reader.readAsText(filePicked);
    } else {
      this.applianceModal['keyFile']=''
      this.applianceModal['keyfileContent']='';
      this.applianceModal['keyfileName']=='';
      this.applianceModal['keyfileExtension']='';
      return false;
    }
  } 
}
