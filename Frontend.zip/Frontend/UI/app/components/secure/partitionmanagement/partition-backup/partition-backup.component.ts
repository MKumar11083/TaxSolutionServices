import { Component, OnInit,ViewChild,Output,EventEmitter } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { PartitionOperationsComponent } from './../partition-operations/partition-operations.component';
@Component({
  selector: 'app-partition-backup',
  templateUrl: './partition-backup.component.html',
  styleUrls: ['./partition-backup.component.css']
})
export class PartitionBackupComponent implements OnInit {
  @ViewChild('backupModal') backupModal: ModalDirective;
  @ViewChild('partitionOperationsComponent')
  private partitionOperationsComponent: PartitionOperationsComponent;
  @Output() messageEvent4 = new EventEmitter<any>();
  selectedPartitionList = [];
  selectedOperation: string;

  constructor() { }

  ngOnInit() {}

  showPartitionBackupModal(partitionList,operation){
    this.clearData();
    this.selectedOperation=operation;
    this.createPartitionList(partitionList);
    this.backupModal.show();
  }

  createPartitionList(partitionList) {
    partitionList.forEach(obj => {
      let partitionModal = {
        'applianceDetailModel': {}
      };
      partitionModal['partitionId'] = obj.partitionId;
      partitionModal['partitionName'] = obj.partitionName;
      partitionModal['username'] = obj.username;
      partitionModal['password'] = obj.password;
      partitionModal['sessionClose'] = obj.sessionClose;
      partitionModal['noKey'] = false;
      partitionModal['applianceDetailModel']['applianceId'] = obj.applianceDetailModel.applianceId;
      partitionModal['applianceDetailModel']['applianceName'] = obj.applianceDetailModel.applianceName;
      partitionModal['applianceDetailModel']['ipAddress'] = obj.applianceDetailModel.ipAddress;
      partitionModal['cityName'] = obj.cityName;
      this.selectedPartitionList.push(partitionModal);
    });
  }
  onSubmit(){
    this.backupModal.hide();
    this.partitionOperationsComponent.performSelectedOperation(this.selectedPartitionList, this.selectedOperation);
  }
  closeBackupModel() {
    this.backupModal.hide();
    this.clearData();
  }
  clearData() {
    this.selectedPartitionList = [];
    this.selectedOperation = '';
  }
  callBackToPartitionLogin() {
    console.log("BackUp & Restore  --> Call back to partition login page");
    this.clearData();
    this.messageEvent4.emit();
  }
}
