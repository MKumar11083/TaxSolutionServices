import { Component, Input, OnInit } from '@angular/core';
import { BreadcrumbService } from './../../../../services/common/breadcrumb.service';

declare var $: any;

@Component({
  selector: 'app-breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.css']
})
export class BreadcrumbComponent implements OnInit {
  
  constructor(public _breadCrumbService:BreadcrumbService) { }

  ngOnInit() {
 
   
  }

}
