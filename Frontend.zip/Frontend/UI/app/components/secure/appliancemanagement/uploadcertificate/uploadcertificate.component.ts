// import { Component, OnInit } from '@angular/core';
import { Component, OnInit, ViewChild, Output, EventEmitter, TemplateRef, ElementRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { FormBuilder, FormGroup, Validators, ValidatorFn, AbstractControl } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { FileUploader } from 'ng2-file-upload';

const URL = '';
declare var $: any;
declare var bootbox: any;
declare var jQuery: any;
@Component({
  selector: 'app-uploadcertificate',
  templateUrl: './uploadcertificate.component.html',
  styleUrls: ['./uploadcertificate.component.css']
})

export class UploadcertificateComponent implements OnInit {
  @ViewChild('myInput')
  myInputVariable: ElementRef;
  @ViewChild('myInput1')
  myInputVariable1: ElementRef;
  @ViewChild('uploadCertificateModal') uploadCertificateModal: ModalDirective;
  @Output() messageEvent = new EventEmitter<any>();
  modalRef: BsModalRef;
  form: FormGroup;
  showFinalUploadCertificateList: boolean = false;
  applianceCount = 1;
  applianceName: string;
  totalAppliance = 0;
  selectedAppliances = [];
  applianceChecked: boolean = false;
  initializeDataList = [];
  uploadCertificateList = [];
  showBackButton = false;
  shownextbutton = false;
  loading = false;
  checked: boolean = true;
  uploadCertificateData = {};
  errorMessage = '';
  public uploader: FileUploader = new FileUploader({ url: URL });

  constructor(private _formBuilder: FormBuilder, private _applianceManagementService: AppliancemanagementService, ) { }

  ngOnInit() {
    this.createuploadCertificateForm();
  }

  createuploadCertificateForm() {
   this.form = this._formBuilder.group({
      signedHSMfileContent: [''],
      signedHSMfileName: [''],
      signedHSMfullName: [''],
      signedHSMfileExtension: [''],
      signedHSMfileValidate: [false],
      HSMfileContent: [''],
      HSMfileName: [''],
      HSMfullName: [''],
      HSMfileExtension: [''],
      HSMfileValidate: [false],
      fileValidate: [''],

    });
  }

  showUploadCertificateModal(listAppliances) {
    console.log("List of selected appliance --->" + listAppliances);
    this.clearData();
    this.selectedAppliances = listAppliances;
    this.applianceName = this.selectedAppliances[this.applianceCount - 1]['applianceName'];
    this.totalAppliance = this.selectedAppliances.length;
    this.uploadCertificateModal.show();
    if (this.applianceCount < this.selectedAppliances.length) {
      this.shownextbutton = true;
    }
    else {
      this.shownextbutton = false;
    }
  }

  saveUploadCertificate() {
    this.errorMessage = '';
    this.myInputVariable.nativeElement.value = "";
    this.myInputVariable1.nativeElement.value = "";
    if (this.applianceCount < this.selectedAppliances.length) {
      /* get the next appliance coLoginFailureCount, min & max password length values */
      this.applianceName = this.selectedAppliances[this.applianceCount]['applianceName'];
      this.form.reset();

      this.applianceCount++;
      this.showBackButton = true;
      this.shownextbutton = true;
    }
    if (this.applianceCount == this.selectedAppliances.length) {
      this.shownextbutton = false;
    }

  }

  uploadCertificate() {
    this.errorMessage = '';
    this.myInputVariable.nativeElement.value = "";
    this.myInputVariable1.nativeElement.value = "";
    if (this.form.get('signedHSMfileValidate').value && this.form.get('HSMfileValidate').value) {
      this.uploadCertificateData = {};
      let count: number;
      count = this.applianceCount - 1;
      this.uploadCertificateData['operationUsername'] = this.selectedAppliances[count]['operationUsername'];
      this.uploadCertificateData['operationPassword'] = this.selectedAppliances[count]['operationPassword'];
      this.uploadCertificateData['signedHSMfileName'] = this.form.get('signedHSMfileName').value;
     this.uploadCertificateData['signedHSMfileContent'] = this.form.get('signedHSMfileContent').value;
      this.uploadCertificateData['signedHSMfileExtension'] = this.form.get('signedHSMfileExtension').value;
      this.uploadCertificateData['hsmFileName'] = this.form.get('HSMfileName').value;
      this.uploadCertificateData['hsmFileContent'] = this.form.get('HSMfileContent').value;
      this.uploadCertificateData['hsmFileExtension'] = this.form.get('HSMfileExtension').value;
      this.uploadCertificateData['applianceName'] = this.selectedAppliances[count]['applianceName'];
      this.uploadCertificateData['applianceId'] = this.selectedAppliances[count]['applianceId'];
      this.uploadCertificateData['applianceIp'] = this.selectedAppliances[count]['ipAddress'];
      this.loading = true;
      this._applianceManagementService.uploadCertificate(this.uploadCertificateData).subscribe((res) => {
  
          this.loading = false;
          let displaymsg: string = '';
          if (this.applianceCount == this.selectedAppliances.length){
            this.uploadCertificateModal.hide();
            this.clearData();
          }
          
          displaymsg =  res.responseMessage;
         
          bootbox.dialog({
            message: displaymsg,
            buttons: {
              Ok: {
                label: "Close",
                className: 'btn btn-primary btn-flat',
                callback: () => this.callBack()
              }
            }
          });
        
      }, (err) => {
        console.log(err);
      })
    } else {
      this.errorMessage = "Please upload the files"
    }

  }

  closeuploadCertificate() {
    this.uploadCertificateModal.hide();
    this.clearData();
  }

  clearData() {
    this.form.reset();
    this.applianceName = "";
    this.applianceCount = 1;
    this.selectedAppliances = [];
    this.showFinalUploadCertificateList = false;
    this.uploadCertificateList = [];
    // this.showBackButton = false;
    this.loading = false;
    this.uploader = new FileUploader({ url: URL });
    this.myInputVariable.nativeElement.value = "";
    this.myInputVariable1.nativeElement.value = "";
  }

  onFileChange1(event) {
    const filePicked = (event.target as HTMLInputElement).files[0];
    if (filePicked != undefined) {
      const fileName = filePicked.name;
      this.form.get('signedHSMfullName').setValue(fileName);
      this.form.get('signedHSMfileName').setValue(fileName.substring(0, fileName.indexOf('.')));
      this.form.get('signedHSMfileExtension').setValue(filePicked.name.split('.').pop() || filePicked.name);
      const reader = new FileReader();
      reader.onload = () => {
        this.form.get('signedHSMfileContent').setValue(reader.result);
        if (this.form.get('signedHSMfileContent').value != null) {
          this.form.get('signedHSMfileValidate').setValue(true);
        } else {
          this.form.get('signedHSMfileValidate').setValue(false);
        }
      };
      reader.readAsText(filePicked);
    } else {
      this.form.get('signedHSMfullName').setValue(null);
      this.form.get('signedHSMfileName').setValue("");
      this.form.get('signedHSMfileExtension').setValue("");
      this.form.get('signedHSMfileContent').setValue("");
      this.form.get('signedHSMfileValidate').setValue(false);
      return false;
    }
  }

  onFileSelected2(event) {
    const filePicked = (event.target as HTMLInputElement).files[0];
   if (filePicked != undefined) {
      const fileName = filePicked.name;
      this.form.get('HSMfullName').setValue(fileName);
      this.form.get('HSMfileName').setValue(fileName.substring(0, fileName.indexOf('.')));
      this.form.get('HSMfileExtension').setValue(filePicked.name.split('.').pop() || filePicked.name);
      const reader = new FileReader();
      reader.onload = () => {
        this.form.get('HSMfileContent').setValue(reader.result);
        if (this.form.get('HSMfileContent').value != null) {
          this.form.get('HSMfileValidate').setValue(true);
        } else {
          this.form.get('HSMfileValidate').setValue(false);
        }
      };
      reader.readAsText(filePicked);
    } else {
      this.form.get('HSMfullName').setValue(null);
      this.form.get('HSMfileName').setValue("");
      this.form.get('HSMfileExtension').setValue("");
      this.form.get('HSMfileContent').setValue("");
      this.form.get('HSMfileValidate').setValue(false);
      return false;
    }
  }

  backToPreviousAppliance() {
    this.form.reset();
    this.applianceName = this.selectedAppliances[this.applianceCount - 2]['applianceName'];
    this.applianceCount = this.applianceCount - 1;
    if (this.applianceCount == 1) {
      this.showBackButton = false;
    }
    this.shownextbutton = true;

  }

  callBack() {
    this.messageEvent.emit();
  }

}


