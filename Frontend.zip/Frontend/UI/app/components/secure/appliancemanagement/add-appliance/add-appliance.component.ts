
//import { Component, OnInit ,ChangeDetectorRef} from '@angular/core';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, FormControl } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { AddApplianceService } from './../../../../services/addAppliance.service';
import { Router } from '@angular/router';
import { Component, ChangeDetectorRef, OnInit, ViewChild, Output, EventEmitter, TemplateRef } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { TabsetComponent } from 'ngx-bootstrap';
import { TabDirective } from 'ngx-bootstrap/tabs';
import { ActivatedRoute } from '@angular/router';

import { CommonValidator } from '../../../../validators/common-validator';
declare var jquery: any;
declare var $: any;
declare var bootbox: any;
@Component({
  selector: 'app-add-appliance',
  templateUrl: './add-appliance.component.html',
  styleUrls: ['./add-appliance.component.css']
})
export class AddApplianceComponent implements OnInit {
  @ViewChild('initializeTabs') initializeTabs: TabsetComponent;
  //isValidZoneID = true;
  showlist: boolean = true;
  form: FormGroup;
  coLoginFailureCount: any;
  public loading = false;
  public successMessage: string;
  public successMessage1: string;
  private groupsList: string;
  getValidateRes: object[] = [];
  getValidateRes1: object[] = [];
  getValidateRes3: object[] = [];
  private applianceSent: object[] = [];
  private localStorageApplianceSent: object[] = [];
  private onPageApplianceSent: any = [];
  showApp: object[] = [];
  modalRef: BsModalRef;
  initializeDataList = [];
  applianceCount = 1;
  selectedAppliances = [];
  showAppliance: boolean = false;
  private checkboxFlag: string;
  private getAddStatusFlag: string;
  deleteStatusFlag: any;
  private localStorageDefault: object[] = [];
  displayErrors: any = [];
  errorMessage: string;
  errorMessage1: string;
  showmessage: boolean = false;
  applianceName: string;
  appliancesListTemp: any = [];
  showBackButton = false;
  showFinalInitiazeList: boolean = false;
  tabName: string = "";
  ipCheck: boolean = false;
  //isValidIp = true;
  temp: number = 0;
  isEditMode: boolean = false;
  tzValue: boolean = true;
  utcNames = ["(UTC -12:00) International Date Line West Dateline Standard Time",
    "(UTC -11:00) Coordinated Universal Time",
    "(UTC -10:00) Aleutian Islands Aleutian Standard Time",
    "(UTC -10:00) Hawaii Hawaiian Standard Time",
    "(UTC -09:30) Marquesas Islands Marquesas Standard Time",
    "(UTC -09:00) Alaska Alaskan Standard Time",
    "(UTC -09:00) Coordinated Universal Time",
    "(UTC -08:00) Baja California Pacific Standard Time (Mexico)",
    "(UTC -08:00) Coordinated Universal Time",
    "(UTC -08:00) Pacific Time (US & Canada) Pacific Standard Time",
    "(UTC -07:00) Arizona US Mountain Standard Time",
    "(UTC -07:00) Chihuahua, La Paz, Mazatlan Mountain Standard Time (Mexico)",
    "(UTC -07:00) Mountain Time (US & Canada) Mountain Standard Time",
    "(UTC -06:00) Central America Central America Standard Time",
    "(UTC -06:00) Central Time (US & Canada) Central Standard Time",
    "(UTC -06:00) Easter Island Easter Island Standard Time",
    "(UTC -06:00) Guadalajara, Mexico City, Monterrey Central Standard Time (Mexico)",
    "(UTC -06:00) Saskatchewan Canada Central Standard Time",
    "(UTC -05:00) Bogota, Lima, Quito, Rio Branco SA Pacific Standard Time",
    "(UTC -05:00) Chetumal Eastern Standard Time (Mexico)",
    "(UTC -05:00) Eastern Time (US & Canada) Eastern Standard Time",
    "(UTC -05:00) Haiti Haiti Standard Time",
    "(UTC -05:00) Havana Cuba Standard Time",
    "(UTC -05:00) Indiana (East) US Eastern Standard Time",
    "(UTC -04:00) Asuncion Paraguay Standard Time",
    "(UTC -04:00) Atlantic Time (Canada) Atlantic Standard Time",
    "(UTC -04:00) Caracas Venezuela Standard Time",
    "(UTC -04:00) Cuiaba Central Brazilian Standard Time",
    "(UTC -04:00) Georgetown, La Paz, Manaus, San Juan SA Western Standard Time",
    "(UTC -04:00) Santiago Pacific SA Standard Time",
    "(UTC -04:00) Turks and Caicos Turks And Caicos Standard Time",
    "(UTC -03:30) Newfoundland Newfoundland Standard Time",
    "(UTC -03:00) Araguaina Tocantins Standard Time",
    "(UTC -03:00) Brasilia E. South America Standard Time",
    "(UTC -03:00) Cayenne, Fortaleza SA Eastern Standard Time",
    "(UTC -03:00) City of Buenos Aires Argentina Standard Time",
    "(UTC -03:00) Greenland Greenland Standard Time",
    "(UTC -03:00) Montevideo Montevideo Standard Time",
    "(UTC -03:00) Saint Pierre and Miquelon Saint Pierre Standard Time",
    "(UTC -03:00) Salvador Bahia Standard Time",
    "(UTC -02:00) Coordinated Universal Time-02 UTC-02",
    "(UTC -01:00) Azores Azores Standard Time",
    "(UTC -01:00) Cabo Verde Is. Cape Verde Standard Time",
    "(UTC  00:00) Coordinated Universal Time UTC",
    "(UTC +00:00) Casablanca Morocco Standard Time",
    "(UTC +00:00) Dublin, Edinburgh, Lisbon, London GMT Standard Time",
    "(UTC +00:00) Monrovia, Reykjavik Greenwich Standard Time",
    "(UTC +01:00) Amsterdam, Berlin, Bern, Rome, Stockholm, Vienna W. Europe Standard Time",
    "(UTC +01:00) Belgrade, Bratislava, Budapest, Ljubljana, Prague Central Europe Standard Time",
    "(UTC +01:00) Brussels, Copenhagen, Madrid, Paris Romance Standard Time",
    "(UTC +01:00) Sarajevo, Skopje, Warsaw, Zagreb Central European Standard Time",
    "(UTC +01:00) West Central Africa W. Central Africa Standard Time",
    "(UTC +01:00) Windhoek Namibia Standard Time",
    "(UTC +02:00) AmmanJordan Standard Time",
    "(UTC +02:00) Athens, Bucharest GTB Standard Time",
    "(UTC +02:00) Beirut Middle East Standard Time",
    "(UTC +02:00) Cairo Egypt Standard Time",
    "(UTC +02:00) Chisinau E. Europe Standard Time",
    "(UTC +02:00) Damascus Syria Standard Time",
    "(UTC +02:00) Gaza, Hebron West Bank Standard Time",
    "(UTC +02:00) Harare, Pretoria South Africa Standard Time",
    "(UTC +02:00) Helsinki, Kyiv, Riga, Sofia, Tallinn, Vilnius FLE Standard Time",
    "(UTC +02:00) Jerusalem Israel Standard Time",
    "(UTC +02:00) Kaliningrad Kaliningrad Standard Time",
    "(UTC +02:00) Tripoli Libya Standard Time",
    "(UTC +03:00) Baghdad Arabic Standard Time",
    "(UTC +03:00) Istanbul Turkey Standard Time",
    "(UTC +03:00) Kuwait, Riyadh Arab Standard Time",
    "(UTC +03:00) Minsk Belarus Standard Time",
    "(UTC +03:00) Moscow, St. Petersburg, Volgograd Russian Standard Time",
    "(UTC +03:00) Nairobi E. Africa Standard Time",
    "(UTC +03:30) Tehran Iran Standard Time",
    "(UTC +04:00) Abu Dhabi, Muscat Arabian Standard Time",
    "(UTC +04:00) Astrakhan, Ulyanovsk Astrakhan Standard Time",
    "(UTC +04:00) Baku Azerbaijan Standard Time",
    "(UTC +04:00) Izhevsk, Samara Russia Time Zone",
    "(UTC +04:00) Port Louis Mauritius Standard Time",
    "(UTC +04:00) Tbilisi Georgian Standard Time",
    "(UTC +04:00) Yerevan Caucasus Standard Time",
    "(UTC +04:30) Kabul Afghanistan Standard Time",
    "(UTC +05:00) Ashgabat, Tashkent West Asia Standard Time",
    "(UTC +05:00) Ekaterinburg Ekaterinburg Standard Time",
    "(UTC +05:00) Islamabad, Karachi Pakistan Standard Time",
    "(UTC +05:30) Chennai, Kolkata, Mumbai, New Delhi India Standard Time",
    "(UTC +05:30) Sri Jayawardenepura Sri Lanka Standard Time",
    "(UTC +05:45) Kathmandu Nepal Standard Time",
    "(UTC +06:00) Astana Central Asia Standard Time",
    "(UTC +06:00) Dhaka Bangladesh Standard Time",
    "(UTC +06:00) Omsk Omsk Standard Time",
    "(UTC +06:30) Yangon (Rangoon) Myanmar Standard Time",
    "(UTC +07:00) Bangkok, Hanoi, Jakarta SE Asia Standard Time",
    "(UTC +07:00) Barnaul, Gorno-Altaysk Altai Standard Time",
    "(UTC +07:00) Hovd W. Mongolia Standard Time",
    "(UTC +07:00) Krasnoyarsk North Asia Standard Time",
    "(UTC +07:00) Novosibirsk N. Central Asia Standard Time",
    "(UTC +07:00) Tomsk Tomsk Standard Time",
    "(UTC +08:00) Beijing, Chongqing, Hong Kong, Urumqi China Standard Time",
    "(UTC +08:00) Irkutsk North Asia East Standard Time",
    "(UTC +08:00) Kuala Lumpur, Singapore Singapore Standard Time",
    "(UTC +08:00) Perth W. Australia Standard Time",
    "(UTC +08:00) Taipei Taipei Standard Time",
    "(UTC +08:00) Ulaanbaatar Ulaanbaatar Standard Time",
    "(UTC +08:30) Pyongyang North Korea Standard Time",
    "(UTC +08:45) Eucla Aus Central W. Standard Time",
    "(UTC +09:00) Chita Transbaikal Standard Time",
    "(UTC +09:00) Osaka, Sapporo, Tokyo Tokyo Standard Time",
    "(UTC +09:00) Seoul Korea Standard Time",
    "(UTC +09:00) Yakutsk Yakutsk Standard Time",
    "(UTC +09:30) Adelaide Cen. Australia Standard Time",
    "(UTC +09:30) Darwin AUS Central Standard Time",
    "(UTC +10:00) Brisbane E. Australia Standard Time",
    "(UTC +10:00) Canberra, Melbourne, Sydney AUS Eastern Standard Time",
    "(UTC +10:00) Guam, Port Moresby West Pacific Standard Time",
    "(UTC +10:00) Hobart Tasmania Standard Time",
    "(UTC +10:00) Vladivostok Vladivostok Standard Time",
    "(UTC +10:30) Lord Howe Island Lord Howe Standard Time",
    "(UTC +11:00) Bougainville Island Bougainville Standard Time",
    "(UTC +11:00) Chokurdakh Russia Time Zone",
    "(UTC +11:00) Magadan Magadan Standard Time",
    "(UTC +11:00) Norfolk Island Norfolk Standard Time",
    "(UTC +11:00) Sakhalin Sakhalin Standard Time",
    "(UTC +11:00) Solomon Is., New Caledonia Central Pacific Standard Time",
    "(UTC +12:00) Anadyr, Petropavlovsk-Kamchatsky Russia Time Zone",
    "(UTC +12:00) Coordinated Universal Time",
    "(UTC +12:00) Fiji Fiji Standard Time",
    "(UTC +12:45) Chatham Islands Chatham Islands Standard Time",
    "(UTC +13:00) Nuku'alofa Tonga Standard Time",
    "(UTC +13:00) Samoa Samoa Standard Time",
    "(UTC +14:00) Kiritimati Island Line Islands Standard Time"
  ]

  constructor(
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _addApplianceService: AddApplianceService,
    private router: Router,
    private builder: FormBuilder, private modalService: BsModalService,
    private _route: ActivatedRoute, ) { }

  ngOnInit() {
    this.createForm();
    this.getTempdata();
    this.enableRequiredFields();
    this._route.params.subscribe(params => {
      if (params['ip'] != null && params['ip'] != '') {
        this.ipCheck = true;
        this.form.get('ipAddress').patchValue(params['ip']);
      }
      else {
        this.ipCheck = false;
      }
    });
    this.isEditMode = false;
  }

  getRdirecttoListApp() {
    this.router.navigateByUrl("/listAppliance");
  }

  getTempdata() {
    this._addApplianceService.getAllTempAppliances().subscribe(
      res => {
        this.appliancesListTemp = res;
      },
      error => {
        console.log(error);
      },
    );
  }

  createForm() {
    this.form = this.builder.group({
      applianceName: ['',
        Validators.compose([Validators.required, CommonValidator.validateAppName, Validators.maxLength(32)])
      ],
      authID: ['CaviumLiquidSA', Validators.compose([Validators.required, CommonValidator.validateRestAuthID, Validators.maxLength(100)])],
      serialNumber: ['',
        Validators.compose([Validators.required, Validators.maxLength(17), CommonValidator.validateSerialNumber])
      ],
      networkTimezone: [''],
      ipAddress: ['',
        Validators.compose([Validators.required, CommonValidator.ipAddressValidator])
      ],
      gatewayIp: [''],
      subnetMask: [''],
      networkMode: [''],
      hostName: [''],
      ipmiIp: [''],
      userName: [''],
      userPassword: [''],
      cityName: ['', Validators.compose([Validators.required, CommonValidator.validateZoneName, Validators.maxLength(32)])],
      zoneId: ['',
        Validators.compose([Validators.required, CommonValidator.validatelogFailureCount])
      ],
      operationUsername: ['', Validators.compose([Validators.required, CommonValidator.validateUsername, Validators.maxLength(32)])],
      operationPassword: ['', Validators.compose([Validators.required, CommonValidator.validatePassword])],
      fipsState: ['', Validators.required],
      dualFactorAuthServerPortNo: [''],
      certificateFile: [""],
      keyFile: [""],
      certificateName: [''],
      certificateExtension: [''],
      certificateContent: [''],
      keyfileName: [''],
      keyfileExtension: [''],
      keyfileContent: ['']
    });
  }

  // create a form errors
  public formValidationFields = {
    "applianceName": '',
    "authID": '',
    "serialNumber": '',
    "ipAddress": '',
    "ipmiIp": '',
    "userName": '',
    "userPassword": '',
    "cityName": '',
    "zoneId": '',
    "operationUsername": '',
    "operationPassword": '',
    "fipsState": '',
    "dualFactorAuthServerPortNo": ''
  }

  isFieldValid(field: string) {
    if (this.form.get(field).touched) {
      this.formValidationFields = this._fieldErrorDisplayService.validateField(this.form, field, this.formValidationFields, "addAppliance")
    }
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  submitApplication(isValid: boolean, template: TemplateRef<any>) {
    window.scrollTo(0, 0);
    if (isValid) {
      let ipAddress = this.form.get('ipAddress').value;
      let index = this.appliancesListTemp.filter(appliance => appliance.ipAddress === ipAddress);
      if (index.length == 0 || index.length == 1) {
        let modal = {};
        let userName = this.form.get('userName').value;
        modal["userName"] = userName;
        modal["ipmiIp"] = this.form.get('ipmiIp').value;
        let userPassword = this.form.get('userPassword').value;
        modal["userPassword"] = userPassword;
        modal["applianceName"] = this.form.get("applianceName").value;
        modal["authID"] = this.form.get("authID").value;
        modal["serialNumber"] = this.form.get('serialNumber').value;
        modal["networkTimezone"] = this.form.get('networkTimezone').value;
        modal["ipAddress"] = this.form.get('ipAddress').value;
        modal["cityName"] = this.form.get('cityName').value;
        modal["zoneId"] = this.form.get('zoneId').value;
        modal["operationUsername"] = this.form.get('operationUsername').value;
        modal["fipsState"] = this.form.get('fipsState').value;
        let password = this.form.get('operationPassword').value;
        modal["operationPassword"] = password;
        if (index.length > 0) {
          modal['applianceId'] = index[0]['applianceId'];
        }
        //set dual factor details

        modal = this.setDualFactorData(modal);
        this.loading = true;
        if (this.isEditMode) {
          this.invokeEditApplianceAPI(modal);
        } else {
          this.invokeVerifyAppliance(modal);
        }
      }
      else {
        bootbox.dialog({
          message: "Appliance is already exists in add list",
          buttons: {
            ok: {
              label: "Ok",
              className: 'btn btn-primary btn-flat',

            }
          }
        });
      }
    } else {
      this.formValidationFields = this._fieldErrorDisplayService.validateForm(this.form, this.formValidationFields, "addAppliance", false);
      const certificateFile = this.form.get('certificateFile');
      if (certificateFile.errors != null) {
        if (certificateFile.hasError('required')) {
          certificateFile.markAsTouched({ onlySelf: true });
        } else if (certificateFile.hasError('invalidExt')) {
          certificateFile.markAsTouched({ onlySelf: true });
        }
      }
      const keyFile = this.form.get('keyFile');
      if (keyFile.errors != null) {
        if (keyFile.hasError('required')) {
          keyFile.markAsTouched({ onlySelf: true });
        } else if (keyFile.hasError('invalidExt')) {
          keyFile.markAsTouched({ onlySelf: true });
        }
      }
      this.initializeTabs.tabs[0].active = true;
    }
  }
  // invoke edit appliance api
  invokeEditApplianceAPI(modal) {

    this._addApplianceService.editAppliance(modal).subscribe((res) => {
      this.getValidateRes = res;
      this.loading = false;
      if (this.getValidateRes["code"] == "200") {
        this.isEditMode = false;
        this.enableRequiredFields();
        this.form.reset();
        this.form.get('networkTimezone').setValue('');
        this.form.get('authID').setValue("CaviumLiquidSA");
        this.form.get('fipsState').setValue('');
        // this.isEditMode = false
        this.updateApplianceInEditMode(res);
        this.form.get('fipsState').setValidators([Validators.required, CommonValidator.isNumberCheck]);
        this.form.get('fipsState').updateValueAndValidity();
        let message = this.getValidateRes["message"];
        bootbox.dialog({
          message: message,
          buttons: {
            ok: {
              label: "Ok",
              className: 'btn btn-primary btn-flat',
            }
          }
        });
      }
      else {
        let codeArray = res.code.split(',');
        if (codeArray.some(e => e === '11056') || codeArray.some(e => e === '11185')) {
          this.form.reset();
          this.isEditMode = false;
          this.form.get('networkTimezone').setValue('');
          this.form.get('authID').setValue("CaviumLiquidSA");
          this.form.get('fipsState').setValue('');
          modal['applianceId'] = res.applianceId;
          this.form.get('fipsState').setValidators(null);
          this.form.get('fipsState').updateValueAndValidity();
          this.updateApplianceInEditMode(res);
          this.appliancesListTemp.push(modal);
        }
        if (res.message != null && res.message != '') {
          this.errorMessage1 = res.message;
        } else {
          this.errorMessage1 = res.errorMessage;
        }
        if (this.errorMessage1 != null || this.errorMessage1 != '') {
          bootbox.dialog({
            message: this.errorMessage1,
            buttons: {
              ok: {
                label: "Ok",
                className: 'btn btn-primary btn-flat',
              }
            }
          });
        }
      }
    },
      (err) => {
        this.loading = false;
        let message = "Sorry! Please try to add appliance again"
        bootbox.dialog({
          message: message,
          buttons: {
            ok: {
              label: "Ok",
              className: 'btn btn-primary btn-flat',

            }
          }
        });
      });
  }
  // invoke verify appliance api.
  invokeVerifyAppliance(modal) {
    this._addApplianceService.verifyAppliances(modal).subscribe((res) => {
      this.getValidateRes = res;
      this.loading = false;
      if (this.getValidateRes["code"] == "200") {
        this.enableRequiredFields();
        this.form.reset();
        this.form.get('operationPassword').setErrors(null);
        this.form.get('networkTimezone').setValue('');
        this.form.get('authID').setValue("CaviumLiquidSA");
        this.form.get('fipsState').setValue('');
        modal['applianceId'] = res.applianceId;
        this.form.get('dualFactorAuthServerPortNo').setValidators(null);
        this.form.get('certificateFile').setValidators(null);
        this.form.get('keyFile').setValidators(null);
        this.form.get('dualFactorAuthServerPortNo').updateValueAndValidity();
        this.form.get('certificateFile').updateValueAndValidity();
        this.form.get('keyFile').updateValueAndValidity();
        const index = this.appliancesListTemp.findIndex(appliance => appliance.ipAddress === res.ipAddress);
        if (index != -1) {
          this.updateApplianceInAddMode(res, index);
        } else {
          const index = this.appliancesListTemp.findIndex(appliance => appliance.applianceName === res.applianceName);
          if (index != -1) {
            this.updateApplianceInAddMode(res, index);
          } else {
            this.appliancesListTemp.push(modal);
          }
        }
        let message = this.getValidateRes["message"];
        bootbox.dialog({
          message: message,
          buttons: {
            ok: {
              label: "Ok",
              className: 'btn btn-primary btn-flat',
            }
          }
        });
      }
      else {
        if (res.code != null) {
          let codeArray = res.code.split(',');
          if (codeArray.some(e => e === '11056') || codeArray.some(e => e === '11185')) {
            this.form.reset();
            this.form.get('networkTimezone').setValue('');
            this.form.get('authID').setValue("CaviumLiquidSA");
            this.form.get('fipsState').setValue('');
            modal['applianceId'] = res.applianceId;
            this.form.get('operationPassword').setErrors(null);
            this.form.get('dualFactorAuthServerPortNo').setValidators(null);
            this.form.get('certificateFile').setValidators(null);
            this.form.get('keyFile').setValidators(null);
            this.form.get('dualFactorAuthServerPortNo').updateValueAndValidity();
            this.form.get('certificateFile').updateValueAndValidity();
            this.form.get('keyFile').updateValueAndValidity();
            this.appliancesListTemp.push(modal);
          }
        }
        if (res.message != null && res.message != '') {
          this.errorMessage1 = res.message;
        } else {
          this.errorMessage1 = res.errorMessage;
        }
        if (this.errorMessage1 != null || this.errorMessage1 != '') {
          bootbox.dialog({
            message: this.errorMessage1,
            buttons: {
              ok: {
                label: "Ok",
                className: 'btn btn-primary btn-flat',
              }
            }
          });
        }
      }
    },
      (err) => {
        this.loading = false;
        let message = "Sorry! Please try to add appliance again"
        bootbox.dialog({
          message: message,
          buttons: {
            ok: {
              label: "Ok",
              className: 'btn btn-primary btn-flat',

            }
          }
        });
      });
  }
  updateApplianceInAddMode(res, index) {
    // const index = this.appliancesListTemp.findIndex(appliance => appliance.ipAddress === res.ipAddress);
    this.appliancesListTemp[index]['userName'] = res.userName;
    this.appliancesListTemp[index]['applianceName'] = res.applianceName;
    this.appliancesListTemp[index]['applianceId'] = res.applianceId;
    this.appliancesListTemp[index]['authID'] = res.authID;
    this.appliancesListTemp[index]['serialNumber'] = res.serialNumber;
    this.appliancesListTemp[index]['networkTimezone'] = res.networkTimezone;
    this.appliancesListTemp[index]['cityName'] = res.cityName;
    this.appliancesListTemp[index]['zoneId'] = res.zoneId;
    this.appliancesListTemp[index]['ipmiIp'] = res.ipmiIp;

    this.appliancesListTemp[index]['userPassword'] = res.userPassword;
  }
  updateApplianceInEditMode(res) {
    const index = this.appliancesListTemp.findIndex(appliance => appliance.ipAddress === res.ipAddress);
    this.appliancesListTemp[index]['userName'] = res.userName;
    this.appliancesListTemp[index]['applianceId'] = res.applianceId;
    this.appliancesListTemp[index]['authID'] = res.authID;
    this.appliancesListTemp[index]['serialNumber'] = res.serialNumber;
    this.appliancesListTemp[index]['networkTimezone'] = res.networkTimezone;
    this.appliancesListTemp[index]['cityName'] = res.cityName;
    this.appliancesListTemp[index]['zoneId'] = res.zoneId;
    this.appliancesListTemp[index]['ipmiIp'] = res.ipmiIp;
    this.appliancesListTemp[index]['userPassword'] = res.userPassword;
  }

  enableRequiredFields() {
    this.form.get('applianceName').enable();
    this.form.get('ipAddress').enable();
    this.form.get('operationUsername').enable();
    this.form.get('operationPassword').enable();
    this.form.get('fipsState').enable();
  }

  onSelect(data: TabDirective): void {
    this.tabName = data.heading;
    if (this.tabName == "Advanced") {
      this.form.get('ipmiIp').setValidators(Validators.compose([Validators.required]));
      this.form.get('cityName').setValidators(Validators.compose([Validators.required]));
      this.form.get('userName').setValidators(Validators.compose([Validators.required]));
      this.form.get('userPassword').setValidators(Validators.compose([Validators.required]));
      this.form.get('ipmiIp').updateValueAndValidity();
      this.form.get('cityName').updateValueAndValidity();
      this.form.get('userName').updateValueAndValidity();
      this.form.get('userPassword').updateValueAndValidity();
    } else if (this.tabName == "General") {
      this.form.get('ipmiIp').setValidators(null);
      this.form.get('cityName').setValidators(null);
      this.form.get('userName').setValidators(null);
      this.form.get('userPassword').setValidators(null);
      this.form.get('ipmiIp').updateValueAndValidity();
      this.form.get('cityName').updateValueAndValidity();
      this.form.get('userName').updateValueAndValidity();
      this.form.get('userPassword').updateValueAndValidity();
    }
  }

  closeModal() {
    $("#myModal").modal("hide");

  }
  addApplianceToList() {
    this.loading = true;
    if (this.onPageApplianceSent.length > 0) {
      for (var i = 0; i < this.onPageApplianceSent.length; i++) {
        this.onPageApplianceSent[i]["applianceStatus"] = "Active";
        this.applianceSent.push(this.onPageApplianceSent[i]);
      }
    }
    this._addApplianceService.addAppliance(this.applianceSent).subscribe((res) => {
      this.getAddStatusFlag = res;
      this.loading = false;
      if (this.getAddStatusFlag["responseCode"] == "200") {
        let message = "Appliances added successfully.Please click OK to continue.";
        bootbox.dialog({
          message: message,
          buttons: {
            ok: {
              label: "Ok",
              className: 'btn btn-primary btn-flat',
              callback: () => this.getRdirecttoListApp()
            }
          }
        });
      }
    },
      (err) => {
        this.loading = false;
        console.log(JSON.stringify(err._body));
      });

  }

  deleteApplianceToList() {
    if (this.onPageApplianceSent.length > 0) {
      for (var i = 0; i < this.onPageApplianceSent.length; i++) {
        this.onPageApplianceSent[i]["applianceStatus"] = "Active";
        this.applianceSent.push(this.onPageApplianceSent[i]);
      }
    }
    this._addApplianceService.deleteAppliance(this.applianceSent).subscribe((res) => {
      this.deleteStatusFlag = JSON.parse(res['_body']);
      let displaymsg: string = '';
      this.deleteStatusFlag.forEach(element => {
        displaymsg = displaymsg + " " + "<b>" + element.responseMessage + "</b><br>";
      });
      bootbox.dialog({
        message: displaymsg,
        buttons: {
          ok: {
            label: "Ok",
            className: 'btn btn-primary btn-flat',
            callback: () => this.getRdirecttoListApp()
          }
        }
      });
    },
      (err) => {
        console.log(JSON.stringify(err._body));
      });
  }


  addApplianceEvent(event, value) {
    if (event.checked) {
      if (this.appliancesListTemp.length > 0) {
        for (var i = 0; i < this.appliancesListTemp.length; i++) {
          if (this.appliancesListTemp[i]["applianceName"] == value) {
            //   delete this.appliancesListTemp[i]["applianceId"];
            this.onPageApplianceSent.push(this.appliancesListTemp[i]);
          }
        }
      }
    }
    else {
      for (var i = 0; i < this.onPageApplianceSent.length; i++) {
        if (this.onPageApplianceSent[i]["applianceName"] == value) {
          let index = i;
          this.onPageApplianceSent.splice(index, 1);
        }
      }
    }
  }

  editAppliance(value) {
    let applianceDetails = this.appliancesListTemp.filter(appliance => {
      return appliance.applianceName === value;
    });
    this.populateSelectedApplianceDetailsInForm(applianceDetails);
  }
  populateSelectedApplianceDetailsInForm(applianceDetails) {
    this.isEditMode = true;
    this.form.get('ipmiIp').setValue(applianceDetails[0].ipmiIp);
    this.form.get('userName').setValue(applianceDetails[0].userName);
    this.form.get('applianceName').setValue(applianceDetails[0].applianceName);
    this.form.get('authID').setValue("CaviumLiquidSA");
    this.form.get('serialNumber').setValue(applianceDetails[0].serialNumber);
    this.form.get('networkTimezone').setValue(applianceDetails[0].networkTimezone);
    this.form.get('ipAddress').setValue(applianceDetails[0].ipAddress);
    this.form.get('cityName').setValue(applianceDetails[0].cityName);
    this.form.get('zoneId').setValue(applianceDetails[0].zoneId);
    let cryptoUserName = applianceDetails[0].cryptoUserName;
    let password = applianceDetails[0].cryptoUserPassword;
    if (cryptoUserName == undefined) {
      cryptoUserName = applianceDetails[0].operationUsername;
    }
    if (password == undefined) {
      password = applianceDetails[0].operationPassword;
    }
    this.form.get('operationUsername').setValue(cryptoUserName);
    this.form.get('operationPassword').setValue(password);

    this.form.get('userPassword').setValue(applianceDetails[0].userPassword);
    this.form.get('applianceName').disable();
    this.form.get('ipAddress').disable();
    this.form.get('operationUsername').disable();
    this.form.get('operationPassword').disable();
    this.form.get('applianceName').markAsUntouched();
    this.form.get('ipAddress').markAsUntouched();
    this.form.get('operationUsername').markAsUntouched();
    this.form.get('operationPassword').markAsUntouched();
    if (applianceDetails[0].fipsState != null) {
      this.form.get('fipsState').setValue(applianceDetails[0].fipsState);
    }
    this.form.get('fipsState').disable();
    this.form.get('fipsState').markAsUntouched();
    this.form.get('fipsState').setValidators(null);
    this.form.get('fipsState').updateValueAndValidity();
  }


  setDualFactorData(modal) {
    modal['initializeDetailModel'] = {};
    modal['initializeDetailModel']['cryptoOfficerName'] = this.form.get('operationUsername').value;
    modal['initializeDetailModel']['cryptoOfficerPassword'] = this.form.get('operationPassword').value;
    modal['initializeDetailModel']['dualFactorAuthDetailModel'] = {};

    modal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['dualFactorAuthServerPortNo'] = this.form.get('dualFactorAuthServerPortNo').value;
    // certificate file details
    modal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateContent'] = this.form.get('certificateContent').value;

    modal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateName'] = this.form.get('certificateName').value;

    modal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateExtension'] = this.form.get('certificateExtension').value;
    // key file details
    modal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileContent'] = this.form.get('keyfileContent').value;

    modal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileName'] = this.form.get('keyfileName').value;

    modal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileExtension'] = this.form.get('keyfileExtension').value;
    return modal;
  }

  changeFipsState(fipsState) {
    this.form.get('dualFactorAuthServerPortNo').setValue('');
    this.form.get('certificateFile').setValue('');
    this.form.get('keyFile').setValue('');
    if (fipsState == '') {
      this.form.get('fipsState').markAsTouched();
    } else {
      this.form.get('fipsState').markAsUntouched();
      if (fipsState == "3") {
        this.form.get('dualFactorAuthServerPortNo').setValidators([Validators.required, CommonValidator.isNumberCheck]);
        this.form.get('certificateFile').setValidators(Validators.required);
        this.form.get('keyFile').setValidators(Validators.required);
      } else {
        this.form.get('dualFactorAuthServerPortNo').setValidators(null);
        this.form.get('certificateFile').setValidators(null);
        this.form.get('keyFile').setValidators(null);
      }
      this.form.get('dualFactorAuthServerPortNo').updateValueAndValidity();
      this.form.get('certificateFile').updateValueAndValidity();
      this.form.get('keyFile').updateValueAndValidity();
    }
  }

  onCertificateFileChange($event) {
    this.form.get('certificateFile').markAsTouched({ onlySelf: true });
    let file = $event.target.files[0];
    this.form.controls['certificateFile'].setValue(file ? file.name : ''); // <-- Set Value for Validation
    const filePicked = (event.target as HTMLInputElement).files[0];
    if (filePicked != undefined) {
      const fileName = filePicked.name;
      const extension = filePicked.name.split('.').pop() || '';
      const reader = new FileReader();
      reader.onload = () => {
        if (extension == 'crt') {
          this.form.get('certificateContent').setValue(reader.result);
          this.form.get('certificateName').setValue(fileName.substring(0, fileName.indexOf('.')));
          this.form.get('certificateExtension').setValue(extension);
        } else {
          this.form.get('certificateFile').setErrors({ "invalidExt": true })

        }
      };
      reader.readAsText(filePicked);
    } else {
      this.form.get('certificateFile').setValue("");
      this.form.get('certificateContent').setValue("");
      this.form.get('certificateName').setValue("");
      this.form.get('certificateExtension').setValue("");
      return false;
    }
  }

  onKeyFileChange($event) {
    this.form.controls['keyFile'].markAsTouched({ onlySelf: true });
    let file = $event.target.files[0];
    this.form.controls['keyFile'].setValue(file ? file.name : ''); // <-- Set Value for Validation
    const filePicked = (event.target as HTMLInputElement).files[0];
    if (filePicked != undefined) {
      const fileName = filePicked.name;
      let ext = filePicked.name.split('.');
      const extension = ext[1];
      const reader = new FileReader();
      reader.onload = () => {
        if (extension == 'key') {
          this.form.get('keyfileContent').setValue(reader.result);
          this.form.get('keyfileName').setValue(fileName.substring(0, fileName.indexOf('.')));
          this.form.get('keyfileExtension').setValue(extension);
        } else {
          this.form.get('keyFile').setErrors({ "invalidExt": true })

        }
      };
      reader.readAsText(filePicked);
    } else {
      this.form.get('keyFile').setValue("");
      this.form.get('keyfileContent').setValue("");
      this.form.get('keyfileName').setValue("");
      this.form.get('keyfileExtension').setValue("");
      return false;
    }
  }

  clearOption() {
    this.form.get('networkTimezone').reset();
  }
  timeZoneChange(value) {
    if (value != "") {
      this.tzValue = false;
    }
    else {
      this.tzValue = true;
    }

  }
}



