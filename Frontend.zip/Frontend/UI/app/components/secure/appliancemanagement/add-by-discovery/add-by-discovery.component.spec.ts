import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddByDiscoveryComponent } from './add-by-discovery.component';

describe('AddByDiscoveryComponent', () => {
  let component: AddByDiscoveryComponent;
  let fixture: ComponentFixture<AddByDiscoveryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddByDiscoveryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddByDiscoveryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
