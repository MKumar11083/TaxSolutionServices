import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LslogsApplianceComponent } from './lslogs-appliance.component';

describe('LslogsApplianceComponent', () => {
  let component: LslogsApplianceComponent;
  let fixture: ComponentFixture<LslogsApplianceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LslogsApplianceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LslogsApplianceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
