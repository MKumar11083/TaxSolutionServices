import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplianceLoginComponent } from './appliance-login.component';

describe('ApplianceLoginComponent', () => {
  let component: ApplianceLoginComponent;
  let fixture: ComponentFixture<ApplianceLoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApplianceLoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplianceLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
