
import { Component, OnInit, ViewChild, Output, EventEmitter, TemplateRef, Input } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { AnonymousSubscription } from "rxjs/Subscription";
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, FormControl } from '@angular/forms';
import { ApplianceLoginComponent } from './../../appliancemanagement/appliance-login/appliance-login.component';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
declare var $: any;
@Component({
  selector: 'app-changepass-appliance',
  templateUrl: './changepass-appliance.component.html',
  styleUrls: ['./changepass-appliance.component.css']
})
export class ChangepassApplianceComponent implements OnInit {
  @ViewChild('changePassModal') changePassModal: ModalDirective;
  @ViewChild('loginChangePassword') loginChangePassword: ModalDirective;
  @ViewChild('ErrorLogin')
  ErrorLogin: ModalDirective;
  @ViewChild('applianceLogin')
  @Input() applianceData;
  private applianceLogin: ApplianceLoginComponent;
  modalRef: BsModalRef;
  applianceName: string;
  applianceModel: any = [];
  newPassword: string;
  successMessage: string;
  loading: boolean = false;
  loginForm: FormGroup;
  operationUsername: string;
  operationPassword: string;
  credentialSaved: any;
  errorMessages: any = [];
  form: FormGroup;
  changePasswordSubsc: AnonymousSubscription;
  saveToDBChecked: boolean = false;
  applianceId: any;
  ipAddress: any;
  message : string = '';
  autenticationDetailsArray: any = [];

  constructor(private _applianceManagementService: AppliancemanagementService, private _formBuilder: FormBuilder, private _fieldErrorDisplayService: FieldErrorDisplayService, private _service: AppliancemanagementService) { }

  ngOnInit() {
    this.message="";
    this.successMessage = "";
    this.errorMessages = [];
    this.createInitializeForm();
    this.createLoginForm();
  }
  createLoginForm() {
    this.loginForm = this._formBuilder.group({
      operationUsername: ['', Validators.required],
      operationPassword: ['', Validators.required],
    });
  }
  createInitializeForm() {
    this.form = this._formBuilder.group({
      OldPassword1: ['', Validators.required],
      NewPassword1: ['', Validators.required],
      ConfirmPassword1: ['', Validators.required],
      credentialSaved: [false]

    });
  }
  showChangePasswordModal() {
    this.message="";
    this.successMessage = "";
    this.errorMessages = [];
   this.loginChangePassword.hide()

    //this.applianceName =appliancename;
    this.changePassModal.show();

  }
  toggleSaveToDB($event) {
    if ($event.checked) {
      this.saveToDBChecked = true;
    } else {
      this.saveToDBChecked = false;
    }
  }
  onSuccessOperation(response) {
    this.message="";
    this.successMessage = "";
    this.errorMessages = [];
    let res = response;
    if (res.responseCode == "200") {
      // this.successMessage = res.responseMessage;
      //this._commonServices.clearSession();
      sessionStorage.setItem("msg", res.responseMessage);
      $("#changePassword").modal("hide");
      //this._router.navigateByUrl("/login");
    } else if (res.responseCode == "409" || res.responseCode == "-230") {
      this.errorMessages.push(res.responseMessage);
    } else if (res.responseCode == "500") {
      this.errorMessages.push(res.responseMessage);
    } else {
      this.errorMessages.push(res.responseMessage);
    }
  }
  onErrorOperation(errResp) {

  }
  checkPasswordlength() {
    let newPassword = this.form.get("NewPassword1").value;
    if (newPassword.length > 6 && newPassword.length < 33) {
      return true;
    }
    else {
      return false;
    }
  }
  onSubmitCP(isValid: boolean) {
    debugger;
    
    this.successMessage  =  "";
    this.errorMessages  =  [];
    if (isValid) {
      let checksamePassword = this.checkIfMatchingPasswordsCP();
      let checkbothsamePassword = this.bothnewold();
      if (checksamePassword) {
        if (checkbothsamePassword) {
        if (this.checkPasswordlength()){

        let Modal = {};
        Modal["applianceId"] = this.applianceData.applianceId;
        Modal["applianceName"] = this.applianceData.applianceName;
        Modal["ipAddress"] = this.applianceData.ipAddress;
        Modal["operationUsername"] = this.loginForm.get('operationUsername').value;
        Modal["operationPassword"] = this.form.get('OldPassword1').value;
        Modal["newPassword"] = this.form.get('NewPassword1').value;
        let saveTODB = this.form.get('credentialSaved').value;
        if (saveTODB) {
          Modal["credentialSaved"] = true;

        } else {
          Modal["credentialSaved"] = false;

        }

        this.changePassModal.hide();
        this.autenticationDetailsArray=[];
        this.message='';
        this._applianceManagementService.changeAppliancePassword(Modal).subscribe(
          res => {
              if (res.code != "200") {
                this.message=res.errorMessage;
              }else{
                localStorage.removeItem(res.ipAddress);
                this.message=res.message;
              }
              this.ErrorLogin.show();
          },
          error => {
            this.loading = false;
            console.log(error);
          },
        );
      }
    
    else {
      this.errorMessages.push("password length should be between 7 and 32");
    }
  }

  else {
    this.errorMessages.push(" Old password and new Password should not be the same");
  }
}
      else {
        this.errorMessages.push("New Password and Confirm Password should be same");
      }

    } else {
      this.formValidationFields1 = this._fieldErrorDisplayService.validateForm(this.form, this.formValidationFields1, "changepassword1", false)
    }

  }
  public formValidationFields2 = {
    "operationUsername": '',
    "operationPassword": ''

  }
  isFieldValid1(field: string) {
    if (this.form.get(field).touched) {
      this.formValidationFields1 = this._fieldErrorDisplayService.validateField(this.form, field, this.formValidationFields1, "changepassword1")
    }
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  isFieldValid2(field: string) {
    if (this.loginForm.get(field).touched) {
      this.formValidationFields2 = this._fieldErrorDisplayService.validateField(this.loginForm, field, this.formValidationFields2, "login1")
    }
    return !this.loginForm.get(field).valid && this.loginForm.get(field).touched;
  }
  displayFieldCss2(field: string) {
    return {
      'has-error': this.isFieldValid2(field),
      'has-feedback': this.isFieldValid2(field)
    };
  }
  displayFieldCss1(field: string) {
    return {
      'has-error': this.isFieldValid1(field),
      'has-feedback': this.isFieldValid1(field)
    };
  }
  closeModalCP() {
    this.changePassModal.hide();
  }
  closeMessageCP() {
    this.successMessage = "";
    this.errorMessages = [];
  }
  resetCP() {
    this.form.reset();
    this.successMessage = "";
    this.errorMessages = [];
    this.message  = '';
  }
  public formValidationFields1 = {
    "OldPassword1": '',
    "NewPassword1": '',
    "ConfirmPassword1": '',

  }
  checkIfMatchingPasswordsCP() {
    let newPassword = this.form.get("NewPassword1").value;
    let ConfirmPassword = this.form.get("ConfirmPassword1").value;
    if (newPassword !== ConfirmPassword) {
      return false;
    }
    else {
      return true;
    }
  }
  
  bothnewold() {
    let newPassword = this.form.get("NewPassword1").value;
    let oldPassword = this.form.get("OldPassword1").value;
    if (newPassword == oldPassword) {
      return false;
    }
    else {
      return true;
    }
  }
  showloginModal() {
    this.resetCP();
    this.loginForm.reset();
    this.loginChangePassword.show();
  }
  checkAppliancesCredentials() {
    debugger;
    this.loading = true;
    this.loginChangePassword.hide();
    this._service.checkAppliancesCredentials(this.autenticationDetailsArray).subscribe(
      (response) => {
        this.loading = false;
        let isSuccess: boolean = true;
        this.autenticationDetailsArray = [];
        response.forEach(obj => {
          if (obj.code != "200") {
            this.autenticationDetailsArray.push(obj);
            isSuccess = false;
          }
        });
        if (isSuccess) {
          this.redirectToSelectedOperation();
        } else {
          this.ErrorLogin.show();
        }
      },
      (error) => {
        console.log(error);
      })
  }
  redirectToSelectedOperation() {
    this.showChangePasswordModal();
  }

  SubmitDetails() {
    this.autenticationDetailsArray = [];
    let loginDetailsModal = {};
    loginDetailsModal['applianceId'] = this.applianceData.applianceId;
    loginDetailsModal['applianceName'] = this.applianceData.applianceName;
    loginDetailsModal['ipAddress'] = this.applianceData.ipAddress;
    loginDetailsModal['operationUsername'] = this.loginForm.get('operationUsername').value;
    loginDetailsModal['operationPassword'] = this.loginForm.get('operationPassword').value;
    this.autenticationDetailsArray.push(loginDetailsModal);
    this.checkAppliancesCredentials();

  }
}
