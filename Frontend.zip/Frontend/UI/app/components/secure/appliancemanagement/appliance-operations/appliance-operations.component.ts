import { Component, OnInit, EventEmitter, Output, ViewChild } from '@angular/core';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import  {  LoadingModule  }  from  'ngx-loading';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { Router } from '@angular/router';
declare var $: any;
declare var bootbox: any;
declare var jQuery: any;
@Component({
  selector: 'app-appliance-operations',
  templateUrl: './appliance-operations.component.html',
  styleUrls: ['./appliance-operations.component.css']
})
export class ApplianceOperationsComponent implements OnInit {
  @Output() rebootCallBackEvent = new EventEmitter<any>();
  @Output() deleteCallBackEvent = new EventEmitter<any>();
  public  loading  =  false;
  dueToClusterList: any = [];
  fipStatusNonZerozied: any = [];
  successList: any = [];
  errorMessage: string = '';
  selectedAppliance : any = [];
  selectedOperation : string = '';
  removeApplianceArray : any  = [];
  finalSelectedAppliances : any = [];
  showConfirmation: boolean = false;
  @ViewChild('deleteApplianceModal') deleteApplianceModal: ModalDirective;
  @ViewChild('messageModal') messageModal: ModalDirective;
  @ViewChild('confirmModal') confirmModal: ModalDirective;
  constructor(private _service: AppliancemanagementService,
    private _router: Router) { }

  ngOnInit() {
  }


  submitApplianceOperations(listAppliance, applianceOperation) {
    let applianceList: any = [];
    this.selectedAppliance = [];
    this.selectedOperation = '';
    this.removeApplianceArray = [];
    this.finalSelectedAppliances = [];
    this.showConfirmation= false;
    this.selectedOperation=applianceOperation;
    if (applianceOperation == "Reboot") {
      this.showConfirmation= true;
      this.selectedAppliance = listAppliance;
      this.finalSelectedAppliances =  listAppliance;
      this.confirmModal.show();
    } else if (applianceOperation == "delete") {
      this.loading = true;
      listAppliance.forEach(obj => {
        obj['partitionDetailModels'] = null;
        applianceList.push(obj);
      });
      this.dueToClusterList = [];
      this.fipStatusNonZerozied = [];
      this.successList = [];
      this.errorMessage = '';
      this._service.validateDeleteAppliance(applianceList).subscribe(
        res => {
          this.loading = false;
          if(res.dueToCluster!=null){
            if(res.dueToCluster.length>0){
              res.dueToCluster.forEach(element => {
                this.dueToClusterList.push(element);
              });
            }
          }
         if(res.fipsStateNonZeroize!=null){
           if(res.fipsStateNonZeroize.length>0){
             res.fipsStateNonZeroize.forEach(element => {
              this.fipStatusNonZerozied.push(element);
             });
           }
         }
         if(res.successList!=null){
           if(res.successList.length>0){
             res.successList.forEach(element => {
              this.successList.push(element);
             });
           }
         }
          if (this.dueToClusterList.length == 0 && this.fipStatusNonZerozied.length == 0) {
            if (this.successList.length == 0) {
              this.errorMessage = "Unable to delete Appliance(s)";
              this.messageModal.show();
            } else {
              this.onSubmit();
            }

          } else {
            this.deleteApplianceModal.show();
          }
        },
        err => {
          console.log(err);
        }
      )
    }
  }

  rebootOperation(){
    this.confirmModal.hide();
    this.loading = true;
    for (var index = 0; index < this.finalSelectedAppliances.length; index++) {
      this.finalSelectedAppliances[index]['partitionDetailModels']=null;
    }
    this._service.setRebootActivity(this.finalSelectedAppliances).subscribe(
      res => {
        this.loading = false;
        this.responseOperation(res);
      },
      err => {
        this.loading = false;
        console.log(err);
      }
    )
  }

  
  selectAppliancesForDelete(event, applianceId) {
    if (event.checked) {
      this.fipStatusNonZerozied.find
        (appliance => {
          if (appliance.applianceId === applianceId) {
            this.successList.push(appliance);
          }
        })
    } else {
      const index = this.successList.findIndex(appliance => appliance.applianceId === applianceId);
      this.successList.splice(index, 1);
    }
  }

  closeModal() {
    this.dueToClusterList = [];
    this.fipStatusNonZerozied = [];
    this.successList = [];
    this.deleteApplianceModal.hide();
  }

  onSubmit() {
    if (this.successList.length > 0) {
      this.loading = true;
      this.deleteApplianceModal.hide();
      this._service.deleteAppliance(this.successList).subscribe(
        res => {
          this.loading = false;
          let response = res.json();
          this.closeModal();
          this.responseOperationForDeleteAppliance(response);
        },

        err => {
          this.loading = false;
          console.log(err);
        }
      )
    } else {
      this.errorMessage = "No Appliances to do delete operation";
      this.messageModal.show();
    }

  }

  responseOperation(res) {
    this.loading = false;
    let displaymsg: string = '';
    res.forEach(obj => {
      if (obj.code == "200") {
        displaymsg = displaymsg + " " + "<b>" + obj.applianceName + "</b> :-- " + obj["message"] + "<br>";
      } else {
        displaymsg = displaymsg + " " + "<b>" + obj.applianceName + "</b> :-- " + obj["errorMessage"] + "<br>";
      }

    });
    // if(this.selectedOperation == 'Reboot'){
      this.showRebootModal(displaymsg);
    // }else if(this.selectedOperation == 'delete'){
    //   this.showDeleteModal(displaymsg);
    // }
  }

  responseOperationForDeleteAppliance(res) {
    this.loading = false;
    let displaymsg: string = '';
    res.forEach(obj => {
      if (obj.code == "200") {
        localStorage.removeItem(obj.ipAddress);
        displaymsg = displaymsg + " " + "<b>" + obj.applianceName + "</b> :-- " + obj["message"] + "<br>";
      } else {
        displaymsg = displaymsg + " " + "<b>" + obj.applianceName + "</b> :-- " + obj["errorMessage"] + "<br>";
      }

    });
      this.showDeleteModal(displaymsg);
  }
  showRebootModal(displaymsg){
    bootbox.dialog({
      message: displaymsg,
      buttons: {
        Ok: {
          label: "Close",
          className: 'btn btn-primary btn-flat',
          callback: () => this.rebootCallBackOperation()
        }
      }
    });
  }

  showDeleteModal(displaymsg){
    bootbox.dialog({
      message: displaymsg,
      buttons: {
        Ok: {
          label: "Close",
          className: 'btn btn-primary btn-flat',
          callback: () => this.deleteCallBackOperation()
        }
      }
    });
  }

  rebootCallBackOperation() {
    this.rebootCallBackEvent.emit();
  }

  deleteCallBackOperation(){
    this.deleteCallBackEvent.emit();
  }

  /* Remove appliance from the final list */
  removeAppliance(event,applianceId) {
    if (event.checked) {
      const index = this.removeApplianceArray.findIndex(val => val.applianceId==applianceId);
      if(index != -1){
        this.finalSelectedAppliances.push(this.removeApplianceArray[index]);
        this.removeApplianceArray.splice(index,1);
      }
    }else{
      let selectedIds = [];
      selectedIds.push(applianceId);
      const index = this.finalSelectedAppliances.findIndex(val => val.applianceId==applianceId);
      if(index != -1){
        this.removeApplianceArray.push(this.finalSelectedAppliances[index]);
      }
      this.finalSelectedAppliances = this.finalSelectedAppliances.filter(
        val => !selectedIds.includes(val.applianceId));

    }
  }

  confirmReboot(){
    this.showConfirmation = false;
  }
}
