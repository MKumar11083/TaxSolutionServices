import { Component, OnInit, ViewChild, Output, EventEmitter, TemplateRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { FormBuilder, FormGroup, Validators, ValidatorFn, AbstractControl } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { TabDirective } from 'ngx-bootstrap/tabs';
import { TabsetComponent } from 'ngx-bootstrap';
import { AnonymousSubscription } from "rxjs/Subscription";

import { BsModalService } from 'ngx-bootstrap/modal';
declare var $: any;
declare var bootbox: any;
declare var jQuery: any;

@Component({
  selector: 'app-configurelogs-appliance',
  templateUrl: './configurelogs-appliance.component.html',
  styleUrls: ['./configurelogs-appliance.component.css']
})
export class ConfigurelogsApplianceComponent implements OnInit {
  @ViewChild('configurelogsModal') configurelogsModal: ModalDirective;
  @Output() messageEvent = new EventEmitter<any>();
  modalRef: BsModalRef;
  applianceName: string;
  selectedAppliances = [];
  totalAppliance = 0;
  applianceCount = 1;
  showBackButton = false;
  showNextButton = false;
  listofAppliancesSubscription: AnonymousSubscription;
  configlogger: string = '';
  loading: boolean = false;
  constructor(private _formBuilder: FormBuilder,
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _applianceManagementService: AppliancemanagementService,
    private modalService: BsModalService) { }

  ngOnInit() {
    this.selectedAppliances = [];
  }

  showConfigurelogsModal(listAppliances) {
    console.log("List of selected appliance --->" + listAppliances);
    this.configurelogsModal.show();
    listAppliances.forEach(obj => {
      let model = {};
      model['applianceName'] = obj.applianceName;
      model['applianceIp'] = obj.ipAddress;
      model['applianceId'] = obj.applianceId;
      model['operationUsername'] = obj.operationUsername;
      model['operationPassword'] = obj.operationPassword;
      model['loggerType'] = '';
      this.selectedAppliances.push(model);
    });
    this.applianceName = this.selectedAppliances[this.applianceCount - 1]['applianceName'];
    this.totalAppliance = this.selectedAppliances.length;
    this.configurelogsModal.show();
    let applianceData = this.selectedAppliances[this.applianceCount - 1];
    this.getConfigLogsDetails(applianceData);
    if (this.applianceCount < this.selectedAppliances.length) {
      this.showNextButton = true;
    }
    else {
      this.showNextButton = false;
    }

  }

  getConfigLogsDetails(applianceData) {
    this.configlogger = '';
    this.listofAppliancesSubscription = this._applianceManagementService.getConfigLogsDetails(applianceData).subscribe(
      res => {
        this.configlogger = res.responseMessage;
      },
      err => {
        console.log(err);
      }
    )
  }
  backToPreviousAppliance() {
    if (this.applianceCount == this.selectedAppliances.length) {
      this.showNextButton = true;
    }

    this.applianceName = this.selectedAppliances[this.applianceCount - 2]['applianceName'];
    let applianceData = this.selectedAppliances[this.applianceCount - 2];
    this.getConfigLogsDetails(applianceData);
    this.applianceCount = this.applianceCount - 1;
    let backOperationCount = this.applianceCount - 2;
    // this.setValuesToForm(backOperationCount);
    if (this.applianceCount == 1) {
      this.showBackButton = false;
      this.showNextButton = true;
      // this.showNextButton = true;
    }
  }

  saveConfiglogs(isvalid, template: TemplateRef<any>) {
    if (this.applianceCount < this.selectedAppliances.length) {
      this.showNextButton = false;
      this.applianceName = this.selectedAppliances[this.applianceCount]['applianceName'];
      let applianceData = this.selectedAppliances[this.applianceCount];
      this.getConfigLogsDetails(applianceData);
      this.showBackButton = true;
      this.applianceCount++;
      if (this.applianceCount != this.selectedAppliances.length) {
        this.showNextButton = true;
      }
    }
  }

  onSubmit() {
    let applianceData = this.selectedAppliances[this.applianceCount - 1];
    applianceData['loggerType'] = this.configlogger;
    this.loading = true;
    this.listofAppliancesSubscription = this._applianceManagementService.updateConfiguredLoggerType(applianceData).subscribe(
      res => {
        this.loading = false;
        let displaymsg = "";
        displaymsg = res.responseMessage;
        bootbox.dialog({
          message: displaymsg,
          buttons: {
            Ok: {
              label: "Close",
              className: 'btn btn-primary btn-flat',
              callback: () => this.callBack()
            }
          }
        });
      },
      err => {
        console.log(err);
      }
    )
    if(this.applianceCount == this.selectedAppliances.length){
      this.configurelogsModal.hide();
      this.clearData();
      } 
  }

  callBack() {
    // this.clearData();
    this.messageEvent.emit();
  }
  closeConfigurelogsModal() {
    this.configurelogsModal.hide();
    this.clearData();
  }
  clearData() {
    this.applianceName = "";
    this.applianceCount = 1;
    this.selectedAppliances = [];
    this.configlogger = '';
    this.showBackButton = false;
    this.showNextButton = true;
  }
  changeType(type) {
    this.configlogger = type;
  }

}
