import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { AnonymousSubscription } from "rxjs/Subscription";
import { DataTableResource } from './../../data-table/index';
import { I18nService } from '../../../../services/common/i18n/i18n.service';
import { BreadcrumbService } from './../../../../services/common/breadcrumb.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { InitializeApplianceComponent } from './../../appliancemanagement/initialize-appliance/initialize-appliance.component';
import { ApplianceLoginComponent } from './../../appliancemanagement/appliance-login/appliance-login.component';
// import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { LoadingModule } from 'ngx-loading';
import { Router } from '@angular/router';
import { Observable } from "rxjs/Observable";
import { ApplianceOperationsComponent } from './../../appliancemanagement/appliance-operations/appliance-operations.component';
import { EditApplianceComponent } from './../../appliancemanagement/edit-appliance/edit-appliance.component';
declare var $: any;
declare var bootbox: any;
declare var jQuery: any;
import { ModalDirective } from 'ngx-bootstrap/modal';
@Component({
  selector: 'app-list-appliance',
  templateUrl: './list-appliance.component.html',
  styleUrls: ['./list-appliance.component.css'],

})
export class ListApplianceComponent implements OnInit, OnDestroy {
  // @ViewChild('initializeAppliance')
  // private initializeAppliance: InitializeApplianceComponent;
  @ViewChild('removeApplianceConfirmModal') removeApplianceConfirmModal: ModalDirective;
  @ViewChild('applianceOperations')
  private applianceOperationsComponent: ApplianceOperationsComponent;
  @ViewChild('applianceLogin')
  private applianceLogin: ApplianceLoginComponent;
  @ViewChild('editApplianceComponent')
  private editApplianceComponent: EditApplianceComponent;
  title = "Appliance Details";
  private details: string;
  listofAppliancesSubscription: AnonymousSubscription;
  appliancesList: any = [];
  itemResource: any;
  displayErrors: any = [];
  showList: boolean = true;
  showCompareAppliance: boolean = false;
  selectedAppliances: any = [];
  formAdvanced: FormGroup;
  searchApplianceSubsc: AnonymousSubscription;
  valid: boolean = true;
  loginForm: FormGroup;
  public loading = false;
  errorMessage: string;
  itemCount;
  listtrue: boolean = true;
  timer: AnonymousSubscription;
  selectedHeader: string = '';
  sortAsc: boolean = true;
  sortName: boolean = true;
  sortIp: boolean = true;
  userName: string = '';
  notReachableList: any = [];
  constructor(private _applianceManagementService: AppliancemanagementService,
    private _I18nService: I18nService,
    private _formBuilder: FormBuilder,
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _router: Router,
  ) { }

  ngOnInit() {
    this.userName = '';
    this.userName = sessionStorage.getItem('username');
    this.selectedAppliances = [];
    this.loadingListAppliances('');
    if (sessionStorage.getItem("showList") == "true") {
      this.showList = true;
    } else {
      this.showList = false;
    }
  }

  loadingListAppliances(value) {

    console.log("loading list of appliances.....");
    this.listofAppliancesSubscription = this._applianceManagementService.getAllListAppliances().subscribe(
      res => {
        this.appliancesList = [];
        if (res.length > 0) {
          this.listtrue = true;
          this.valid = false;
          res.forEach(applianceObj => {
            if (applianceObj['applianceStatus'] == 'Active') {
              applianceObj['applianceStatusMsg'] = ""
              applianceObj['showColor'] = "green";
            } else if (applianceObj['applianceStatus'] == 'Inactive') {
              applianceObj['applianceStatusMsg'] = "Appliance is not reachable"
              applianceObj['showColor'] = "maroon";
            } else if (applianceObj['applianceStatus'] == 'Suspended') {
              applianceObj['applianceStatusMsg'] = ""
              applianceObj['showColor'] = "yellow";
            }
            if (applianceObj['lastOperationStatus'] === 'In-Progress') {
              applianceObj['InProgress'] = true;
              applianceObj['showColor'] = "grey";
            } else if (applianceObj['lastOperationStatus'] === 'In-Progress'
              && applianceObj['grayedOut'] == true) {
              applianceObj['InProgress'] = true;
              applianceObj['showColor'] = "grey";
            } else if (applianceObj['lastOperationStatus'] != 'In-Progress'
              && applianceObj['grayedOut'] == true) {
              applianceObj['InProgress'] = false;
              applianceObj['showColor'] = "grey";
            } else {
              applianceObj['InProgress'] = false;
            }
            for (var i = 0; i < this.selectedAppliances.length; i++) {
              if (this.selectedAppliances[i].applianceId == applianceObj.applianceId) {
                applianceObj['checked'] = true;
              }
            }
            this.appliancesList.push(applianceObj);
          })
        }

        else {
          this.listtrue = false;
        }
        if (value != 'callback') {
          this.reloadApplianceList();
        }

        this.itemResource = new DataTableResource(this.appliancesList);
        this.itemResource.count().then(count => { this.itemCount = count });
        this.reloadItems({ "sortBy": this.selectedHeader, "sortAsc": !this.sortAsc });
      },
      error => {
        console.log(error);
      },
    );
  }

  reloadItems(params) {
    if (this.itemResource) {
      this.itemResource.query(params).then(items => this.appliancesList = items);
    }
  }

  headerClick(params) {
    this.selectedHeader = '';
    this.selectedHeader = params.column.property;
    if (this.selectedHeader == "applianceName") {
      this.sortAsc = !this.sortName;
      this.sortName = !this.sortName;
    }
    if (this.selectedHeader == "ipAddress") {
      this.sortAsc = !this.sortIp;
      this.sortIp = !this.sortIp;
    }
    this.reloadItems({ "sortBy": this.selectedHeader, "sortAsc": !this.sortAsc });
  }
  reloadApplianceList(): void {
    this.timer = Observable.timer(10000).first().subscribe(() => this.loadingListAppliances(''));
  }
  clickGetAppliance(event, idName) {
    this.details = "";
    this.appliancesList.find
      (appliance => {
        if (appliance.applianceId == idName) {
          this.details = appliance;
        }
      })
  }

  toggle() {
    this.showList = true;
    sessionStorage.setItem("showList", "true");
  }
  toggle1() {
    this.showList = false;
    sessionStorage.setItem("showList", "false");
  }


  onErrorOperation(error) {
    console.log('OnError' + JSON.stringify(error));
    this.displayErrors = this._I18nService.getI18NMessagesForError(error, "", "");
    console.log('errorMessages -->' + JSON.stringify(this.displayErrors));
  }

  compareAppliance() {
    this.showCompareAppliance = true;
    this.checkValidationsForAppliances();
  }

  checkValidationsForAppliances() {
    if (this.selectedAppliances.length < 1) {
      this.showCompareAppliance = false;
      $("#displayalert").modal("show");
      this.errorMessage = "Please select atleast one appliance to do compare operation";
    } else if (this.selectedAppliances.length > 6) {
      $("#displayalert").modal("show");
      this.showCompareAppliance = false;
      this.errorMessage = "Maximum 6 appliances to compare ";
    }
  }

  selectApplianceItems(event, applianceId: string) {
    if (event.target.checked) {
      event.currentTarget.style.visibility = "visible";
      for (var i = 0; i < this.appliancesList.length; i++) {
        if (this.appliancesList[i].applianceId == applianceId) {
          this.selectedAppliances.push(this.appliancesList[i]);
          this.appliancesList[i]['checked'] = true;
        }
      }
    } else {
      for (var i = 0; i < this.appliancesList.length; i++) {
        if (this.appliancesList[i].applianceId == applianceId) {
          this.appliancesList[i]['checked'] = false;
        }
      }
      const index = this.selectedAppliances.findIndex(appliance => appliance.applianceId === applianceId);
      this.selectedAppliances.splice(index, 1);
    }
    if ((this.selectedAppliances.length == null) || (this.selectedAppliances.length == 0)) {
      $(".floatactionbtn").css("opacity", "0.3");
      $(".floatactionbtn").css("cursor", "not-allowed");
    } else {
      $(".floatactionbtn").css("opacity", "1");
      $(".floatactionbtn").css("cursor", "pointer");
    }
  }

  navigateToCompareAppliance() {
    this.notReachableList = [];
    this.notReachableList = this.selectedAppliances.filter(appliance => {
      if (appliance['applianceStatus'] == 'Inactive') {
        return appliance;
      }
    });
    if (this.notReachableList <= 0) {
      this.compareAppliance();
      if (this.showCompareAppliance) {
        this._applianceManagementService.setSelectedAppliances(this.selectedAppliances);
        this._applianceManagementService.setAllAppliances(this.appliancesList);
        this._router.navigate(['/compareAppliances']);
      } else {
        return false;
      }
    }else{
      $("#displayalert").modal("show");
    }
  }

  callback() {
    console.log("Callback ----> List Appliance");
    this.selectedAppliances = [];
    $(".floatactionbtn").css("opacity", "0.3");
    $(".floatactionbtn").css("cursor", "not-allowed");
    this.loadingListAppliances('callback');
  }

  ngOnDestroy() {
    if (this.listofAppliancesSubscription) {
      this.listofAppliancesSubscription.unsubscribe();
    }
    if (this.searchApplianceSubsc) {
      this.searchApplianceSubsc.unsubscribe();
    }
    if (this.timer) {
      this.timer.unsubscribe();
    }
  }



  showhideFilters: string = '0';
  searchListApplianceByStatus: string = '';
  finalAppliancesList: string;
  searchListApplianceByName: string;
  searchListApplianceByIP: string;

  CheckListAppFilterSelect(value) {
    if (value === "0") {
      //alert("none");
      this.searchListApplianceByStatus = '';
      this.searchListApplianceByName = '';
      this.searchListApplianceByIP = '';
    } else if (value === "1") {
      //alert("Name");
      this.searchListApplianceByStatus = '';
      this.searchListApplianceByIP = '';
    }
    else if (value === "2") {
      //alert("Status");
      this.searchListApplianceByName = '';
      this.searchListApplianceByIP = '';
    }
    else if (value === "3") {
      //alert("IP");
      this.searchListApplianceByName = '';
      this.searchListApplianceByStatus = '';
    }
  }
  showRemoveApplianceConfirmationModal() {
    this.removeApplianceConfirmModal.show();
  }
  appliancedelete() {
    this.removeApplianceConfirmModal.hide();
    this.applianceOperationsComponent.submitApplianceOperations(this.selectedAppliances, 'delete');
  }
  editAppliance() {
    this.editApplianceComponent.showEditApplianceModal(this.selectedAppliances);
  }
  clearSelectedAppliances() {
    console.log("callback to list appliance.....")
    this.selectedAppliances = [];
    $(".floatactionbtn").css("opacity", "0.3");
    $(".floatactionbtn").css("cursor", "not-allowed");

    this.loadingListAppliances('callback');
  }

}