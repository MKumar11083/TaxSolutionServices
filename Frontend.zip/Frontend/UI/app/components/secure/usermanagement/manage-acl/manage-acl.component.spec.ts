import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageAclComponent } from './manage-acl.component';

describe('ManageAclComponent', () => {
  let component: ManageAclComponent;
  let fixture: ComponentFixture<ManageAclComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageAclComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageAclComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
