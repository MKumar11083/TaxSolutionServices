
export function paramsToQueryString(params) {
    const result = [];
//     if (params.offset != null) {
//         result.push(['pageIndex', getPageIndex(params.offset, params.limit)]);
//     }
//     if (params.limit != null) {
//         result.push(['pageSize', params.limit]);
//     }
//     // if (params.sortBy != null) {
//     //     result.push(['sort', params.sortBy]);
//     // }
//     // if (params.sortAsc != null) {
//     //     result.push(['order', params.sortAsc ? 'ASC' : 'DESC']);
//     // }
//     if (params.groupId != null) {
//         result.push(['groupId', params.groupId]);
//     }
//     if (params.simStatus != null) {
//         result.push(['simStatus', params.simStatus]);
//     }
//     if (params.simName != null) {
//         result.push(['simName', params.simName]);
//     }
//     if (params.imsi != null) {
//         result.push(['imsi', params.imsi]);
//     }
//     if (params.iccid != null) {
//         result.push(['iccid', params.iccid]);
//     }
//     if (params.msisdn != null) {
//         result.push(['msisdn', params.msisdn]);
//     }
//     if (params.scheduleId != null) {
//         result.push(['scheduleId', params.scheduleId]);
//     }
//     if (params.simProfileName != null) {
//         result.push(['simProfileId', params.simProfileId]);
//     }
//     if (params.imei != null) {
//         result.push(['imei', params.imei]);
//     }
//     if (params.profileTypeId != null) {
//         result.push(['profileTypeId', params.profileTypeId]);
//     }
//     if (params.eid != null) {
//         result.push(['eid', params.eid]);
//     }
//     //console.log(JSON.stringify(result));
//     //status
//     return result.map(param => param.join('=')).join('&');
 }
  
export function getPageIndex(num1, num2){
    return (num1 - (num1 % num2)) / num2 + 1;
}