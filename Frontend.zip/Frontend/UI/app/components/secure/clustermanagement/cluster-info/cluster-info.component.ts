import { Component, OnInit, ViewChild, ElementRef, OnDestroy } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { ActivatedRoute } from '@angular/router';
import { ClustermanagementService } from './../../../../services/clustermanagement.service';
import { PartitionManagementService } from './../../../../services/partitionmanagement/partitionmanagement.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { CreateClusterComponent } from './../../clustermanagement/create-cluster/create-cluster.component';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import '../../../../../../src/assets/plugins/clusterd3.js';
import '../../../../../../src/assets/plugins/clusterd3graph.js';
import { Router } from '@angular/router';
import { DataTableResource } from './../../data-table/index';
import { Observable } from "rxjs/Observable";
import { AnonymousSubscription } from "rxjs/Subscription";
declare var d3plus;
declare var d3;
declare var vis;
@Component({
  selector: 'app-cluster-info',
  templateUrl: './cluster-info.component.html',
  styleUrls: ['./cluster-info.component.css']
})
export class ClusterInfoComponent implements OnInit, OnDestroy {
  @ViewChild('certificate') certificateVariable: ElementRef;
  @ViewChild('key')
  keyVariable: ElementRef;
  @ViewChild('addNodeModal')
  addNodeModal: ModalDirective;
  @ViewChild('removeNodeModal')
  removeNodeModal: ModalDirective;
  @ViewChild('partitionLoginModal')
  partitionLoginModal: ModalDirective;
  @ViewChild('messageModal')
  messageModal: ModalDirective;
  @ViewChild('messageModal1')
  messageModal1: ModalDirective;
  @ViewChild('createClusterComponent')
  private createClusterComponent: CreateClusterComponent;
  itemResource: any;
  itemCount = 0;
  clusterId: string;
  clusterName: string;
  clusterDetails: any = {
    "clusterPartitionsRelationships": []
  };
  clusterPartitionsRelationships: any = [];
  partitionList: any = [];
  partitionListData: any = [];
  applianceList: any = [];
  addNodePartitions: any = [];
  selectedPartitions: any = [];
  errorMessage: any = [];
  errorMessage1: any = [];
  message: any = [];
  partitionMap: Map<string, Array<any>>;
  credentialsSavedPartitionList = [];
  nonCredentialSavedParitionList = [];
  partitionName: string;
  partitionCount = 1;
  totalpartitionCount = 0;
  isLastPartition: boolean = false;
  loginForm: FormGroup;
  finalPartitionList = [];
  partitionOperation: string;
  isCreateClusterShow: boolean = false;
  saveCredentialsToSessionArray: any = [];
  loginCredentialsArray: any = [];
  loading: boolean = false;
  checkLoginCredentialsResultArray: any = [];
  partitionDetailsTableList: any = [];
  selectedPartitionsIds: any = [];
  removeCheck: boolean = false;
  partitionNodeList: any = [];
  applianceDualFactorInitialized: boolean = false;
  private timer: AnonymousSubscription;
  private clusterTimer: AnonymousSubscription;
  @ViewChild("username") userNameField: ElementRef;
  constructor(private _route: ActivatedRoute,
    private _service: ClustermanagementService,
    private _appService: AppliancemanagementService,
    private _partitionManagementService: PartitionManagementService,
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _formBuilder: FormBuilder, private _router: Router, ) { }

  ngOnInit() {
    this.createLoginForm();
    this.clusterDetails = {};
    this.errorMessage1 = [];
    this.clusterId = "";
    this._route.params.subscribe(params => {
      this.clusterId = params['clusterId'];
      this.clusterName = params['clusterName'];
    });
    this.getClusterDetails();
  }
  getClusterDetails() {
    //this.loading = true;
    let modal = {};
    this.partitionNodeList = [];
    this.partitionDetailsTableList= [];
    modal["clusterId"] = this.clusterId;
    this.clusterTimer = this._service.getClusterDetails(modal).subscribe(
      res => {
        //this.loading = false;
        if (res.code == "200") {
          this.setDataFromResponse(res);
        } else {
          this.setDataFromResponse(res);
          // this.errorMessage1 = res.errorMessage.split("@#");
          // this.messageModal1.show();
        }
         //this.reloadClusterDetails();
      },
      error => {
        this.loading = false;
        console.log(error);
      },
    );
  }
 
  reloadClusterDetails() {
    this.timer = Observable.timer(10000).first().subscribe(() => this.getClusterDetails());
  }
  setDataFromResponse(response) {
    let clusterData = response;
    this.clusterDetails['clusterId'] = clusterData.clusterId;
    this.clusterDetails['clusterName'] = clusterData.clusterName;
    this.clusterDetails['clusterVersion'] = clusterData.clusterVersion;
    this.clusterDetails['groupId'] = clusterData.groupId;
    if (clusterData.clusterPartitionsRelationships != null && clusterData.clusterPartitionsRelationships != '') {
      let clusterRelationshipArray = [];
      let partitionMap = new Map<string, string>();
      clusterData.clusterPartitionsRelationships.forEach(obj => {
        let clusterRelationshipModel = {};
        let partitionDetails = {};
        clusterRelationshipModel['nodeId'] = obj.nodeId;
        clusterRelationshipModel['zoneId'] = obj.zoneId;
        clusterRelationshipModel['remoteEth0Addr'] = obj.remoteEth0Addr;
        clusterRelationshipModel['operationPerformedUserName'] = obj.operationPerformedUserName;
        clusterRelationshipModel['operationPerformedPassword'] = obj.operationPerformedPassword;
        if (obj.partitionDetailModel != null) {
          clusterRelationshipModel['applianceId'] = obj.partitionDetailModel.applianceId;
          clusterRelationshipModel['ipAddress'] = obj.partitionDetailModel.ipAddress;
          clusterRelationshipModel['applianceName'] = obj.partitionDetailModel.applianceName;
          clusterRelationshipModel['partitionName'] = obj.partitionDetailModel.partitionName;
          clusterRelationshipModel['partitionId'] = obj.partitionDetailModel.partitionId;
        }

        clusterRelationshipModel['deletedPartitionId'] = "";
        clusterRelationshipModel['applianceDualFactorInitialized'] = obj.partitionDetailModel.applianceDualFactorInitialized;
        clusterRelationshipArray.push(clusterRelationshipModel);
        this.clusterDetails['clusterPartitionsRelationships'] = clusterRelationshipArray;
        // partition Data 
        if (obj.remoteEth0Addr != null) {
          partitionDetails['remoteEth0Addr'] = obj.remoteEth0Addr;
        }
        if (obj.remoteEth1Addr != null) {
          partitionDetails['remoteEth1Addr'] = obj.remoteEth1Addr;
        }
        if (obj.partitionDetailModel != null) {
          partitionDetails['partitionName'] = obj.partitionDetailModel.partitionName;
          partitionDetails['partitionId'] = obj.partitionDetailModel.partitionId;
          partitionDetails['applianceId'] = obj.partitionDetailModel.applianceId;
          partitionDetails['applianceName'] = obj.partitionDetailModel.applianceName;
          partitionDetails['ipAddress'] = obj.partitionDetailModel.ipAddress;
          partitionDetails["keys"] = obj.partitionDetailModel.partitionData.maxKeys;
          partitionDetails["sslContexts"] = obj.partitionDetailModel.partitionData.totalSslCtxs;
          partitionDetails['applianceDualFactorInitialized'] = obj.partitionDetailModel.applianceDualFactorInitialized;
          let sync = [];
          obj.connectedPartitions.forEach(element => {
            sync.push(element.keySynced);
            element['partitionName'] = obj.partitionDetailModel.partitionName;
            element['partitionId1'] = obj.partitionDetailModel.partitionId;
            element['applianceId'] = obj.partitionDetailModel.applianceId;
            element['applianceName'] = obj.partitionDetailModel.applianceName;
            element['ipAddress'] = obj.partitionDetailModel.ipAddress;
            element['parentPartitionId'] = obj.partitionDetailModel.partitionId;
            this.partitionNodeList.push(element);
          });
          partitionDetails["sync"] = sync;
          partitionDetails["acclrDev"] = obj.partitionDetailModel.partitionData.maxAcclrDevCount;
        }
        partitionDetails["nodeId"] = obj.nodeId;
        partitionDetails["zoneId"] = obj.zoneId;
        //  partitionDetailModel["sync"]=obj.partitionDetailModel.partitionId;
        partitionDetails["tombstoneKeys"] = obj.tombstoneKeys;
        this.partitionDetailsTableList.push(partitionDetails);
        this.itemResource = new DataTableResource(this.partitionDetailsTableList);
        this.itemCount = this.partitionDetailsTableList.length;
        // connection status 
        partitionMap.set(obj.partitionDetailModel.partitionId, obj.partitionDetailModel.applianceName + "_" + obj.partitionDetailModel.partitionName);

      });
      let partitionIds = Array.from(partitionMap.keys());
      let connectionList: any = [];
      let displayNodes: any = [];
      partitionIds.forEach(id => {
        this.partitionNodeList.forEach(element => {
          //let connectionPartition = {};
          // let partitionNames = {};
          if (element.parentPartitionId == id) {
            let partitionName = partitionMap.get(element.partitionId);
            if (partitionName != undefined) {
              element["source"] = partitionMap.get(id);
              element["target"] = partitionName;
              if (element.connectivityStatus == "disconnected") {
                element["color"] = "Red";
                element["status"] = "disconnected";
                // connectionPartition["status"] = partitionMap.get(id) + "-" + partitionName + ": disconnected";
              } else {
                element["status"] = "connected";
                // connectionPartition["status"] = partitionMap.get(id) + "-" + partitionName + ": connected";
              }
            } else {
              element["source"] = partitionMap.get(id);
              element["status"] = "";
            }
            connectionList.push(element);
          }
          let flag = displayNodes.some(e => e == partitionMap.get(id));
          if (!flag) {
            displayNodes.push(partitionMap.get(id));
          }
        });
      });
      var nodes = null;
      var edges = null;
      var network = null;

      var DIR = 'assets/images/node.png';
      // Create a data table with nodes.
      nodes = [];
      // Create a data table with links.
      edges = [];
      displayNodes.forEach(element => {
        nodes.push({ id: element, image: DIR, shape: 'image', title: '<b>' + element + '</b>' });
      });
      connectionList.forEach(element => {
        if (element.status == "disconnected") {
          edges.push({ from: element.source, to: element.target, color:  {  color:  'red',highlight:'red'   }, arrows: 'to', length: 400 });
        } else if (element.status == "connected") {
          edges.push({ from: element.source, to: element.target, color:  {  color:  'green',highlight:'green'   }, arrows: 'to', length: 400 });
        }
      });

      // create a network
      var container = document.getElementById('mynetwork');
      var data = {
        nodes: nodes,
        edges: edges
      };
      var options = {};
      network = new vis.Network(container, data, options);
      network.on("stabilized", function handler(properties) {
        network.setOptions({ physics: { barnesHut: { gravitationalConstant: 0, centralGravity: 0, springConstant: 0 } } });
        network.storePositions();
        });  
      network.on('click', (params) => {
        nodes.forEach(element => {
          if (element.id == params.nodes[0]) {
            let clusterDetails= connectionList.filter(obj => {
              if (obj['source'] == params.nodes[0]) {
                return obj;
              }
            });
            this._router.navigate(['/Partitionhostvm',clusterDetails[0].partitionId1,
            clusterDetails[0].partitionName,
            clusterDetails[0].applianceId,
            clusterDetails[0].applianceName,
            clusterDetails[0].ipAddress]
            );
          }
        });
      });
    }
  }
  setClusterGraph(){}
  reloadItems(params) {
    if (this.itemResource) {
      this.itemResource.query(params).then(items => this.partitionDetailsTableList = items);
    }
  }
  createLoginForm() {
    this.loginForm = this._formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      dualFactorAuthServerPortNo: [''],
      certificateFile: [""],
      keyFile: [""],
      certificateName: [''],
      certificateExtension: [''],
      certificateContent: [''],
      keyfileName: [''],
      keyfileExtension: [''],
      keyfileContent: ['']
    });
  }
  goToAddNodeModal(operation) {
    this.partitionOperation = '';
    this.applianceList = [];
    this.selectedPartitions = [];
    this.finalPartitionList = [];
    this.partitionOperation = operation;
    this.addNodeModal.show();
    this._service.getAddNodeDetails().subscribe(
      res => {
        this.addNodePartitions = res;
        this.addNodePartitions.forEach(obj => {
          let applianceObj = {};

          applianceObj["applianceName"] = obj.applianceName;
          applianceObj["applianceId"] = obj.applianceId;
          applianceObj["partitionName"] = obj.partitionName;
          applianceObj["ipAddress"] = obj.ipAddress;
          applianceObj["partitionId"] = obj.partitionId;
          applianceObj["nodeId"] = obj.partitionData.nodeId;
          applianceObj["remoteEth0Addr"] = obj.networkStats.general.eth0.ip;
          applianceObj["remoteEth1Addr"] = obj.networkStats.general.eth1.ip;
          applianceObj["zoneId"] = obj.zoneId;
          applianceObj["operationPerformedUserName"] = '';
          applianceObj["operationPerformedPassword"] = '';
          applianceObj["deletedPartitionId"] = '';
          applianceObj["applianceDualFactorInitialized"] = obj.applianceDualFactorInitialized;
          this.applianceList.push(applianceObj);
        });
      },
      error => {
        console.error(error);
      },
    );
  }

  selectPartitionItems(event, applianceId, partitionId: string) {
    if (event.checked) {
      for (var i = 0; i < this.applianceList.length; i++) {
        if (this.applianceList[i].applianceId == applianceId) {
          if (this.applianceList[i].partitionId == partitionId) {
            this.selectedPartitions.push(this.applianceList[i]);
          }
        }
      }
    } else {
      const index = this.selectedPartitions.findIndex(partition => partition.partitionId === partitionId);
      this.selectedPartitions.splice(index, 1);
    }
  }
  goToLoginModal(operation) {
    this.message = [];
    this.errorMessage = [];
    this.errorMessage1 = [];
    this.checkLoginCredentialsResultArray = [];
    this.applianceDualFactorInitialized = false;
    if (this.selectedPartitions.length > 0) {
      this.clearData();
      if (this.partitionOperation === 'addNode') {
        this.partitionMap = new Map<string, Array<any>>();
        // need login credentials for existing cluster partitions.
        if (this.clusterDetails['clusterPartitionsRelationships'] != null && this.clusterDetails['clusterPartitionsRelationships'] != '') {
          let existingClusterDetails = this.clusterDetails['clusterPartitionsRelationships'];
          existingClusterDetails.forEach(obj => {
            this.selectedPartitions.push(obj);
          });
        }
        if (this.selectedPartitions.length <= 32) {
          // construct map based on applianceId for selected PartitionList
          this.selectedPartitions.forEach(partitionObj => {
            let tempMap: Array<any> = [];
            if (this.partitionMap.has(partitionObj['applianceId'])) {
              tempMap = this.partitionMap.get(partitionObj['applianceId']);
            }
            tempMap.push(partitionObj);
            this.partitionMap.set(partitionObj['applianceId'], tempMap);
          });
          //construct map code ends here
          // get all the applianceIds form the map and iterate each applianceId , to 
          // identity the credentialSaved or not 
          let applianceIds = Array.from(this.partitionMap.keys());
          applianceIds.forEach(appId => {
            if (this.partitionMap.has(appId)) {
              let partitionObj = this.partitionMap.get(appId)[0];
              if (partitionObj['credentialSaved']) {
                this.credentialsSavedPartitionList.push(partitionObj);
              } else {

                // check appliance credentials are available in localsession.
                // if available in localsession , skips the login for appliance.
                let loginCredentials = JSON.parse(localStorage.getItem(partitionObj.ipAddress));
                if (loginCredentials != null) {
                  partitionObj['operationPerformedUserName'] = loginCredentials.username;
                  partitionObj['operationPerformedPassword'] = loginCredentials.password;
                  this.saveCredentialsToSessionArray.push(partitionObj);
                } else {
                  this.nonCredentialSavedParitionList.push(partitionObj);
                }
              }
              // this.credentialsSavedPartitionList.push(partitionObj);
            }
          });
          //  check the length of non credentialsaved Partition List to show the login pop.
          // if length is 0 , then show the confirm modal,whether to continue the selected Operation or not.
          if (this.nonCredentialSavedParitionList.length > 0) {
            this.partitionName = this.nonCredentialSavedParitionList[this.partitionCount - 1]['applianceName'];
            // dual factor authentication
            this.applianceDualFactorInitialized = this.nonCredentialSavedParitionList[this.partitionCount - 1]['applianceDualFactorInitialized'];
            this.setValidationDualFactorAuthentication();
            // ends here 
            this.totalpartitionCount = this.nonCredentialSavedParitionList.length;
            if (this.partitionCount == this.totalpartitionCount) {
              this.isLastPartition = true;
            }
            this.addNodeModal.hide();
            this.removeNodeModal.hide();
            this.partitionLoginModal.show();
          } else {
            this.invokeCreateCluster();
          }
        } else {
          this.messageModal1.show();
          this.addNodeModal.hide();
          this.errorMessage1[0] = "Sorry!Operation cannot be performed on more than 32 partitions";
        }
      } else if (this.partitionOperation === 'removeNode') {
        debugger
        this.partitionMap = new Map<string, Array<any>>();
        // need login credentials for existing cluster partitions.
        if (this.clusterDetails['clusterPartitionsRelationships'] != null && this.clusterDetails['clusterPartitionsRelationships'] != '') {
          let existingClusterDetails = this.clusterDetails['clusterPartitionsRelationships'];
          existingClusterDetails.forEach(obj => {
            // if (this.selectedPartitionsIds.some(id => id != obj.partitionId)) {
            //   this.selectedPartitions.push(obj);
            // }
            const index = this.selectedPartitionsIds.findIndex(id => id === obj.partitionId);
            if(index == -1){
              this.selectedPartitions.push(obj);
            }
          });
        }
        if (this.selectedPartitionsIds.length == this.partitionDetailsTableList.length) {
          // this.selectedPartitions = [];
          this.removeNodeModal.hide();
          this.messageModal1.show();
          this.errorMessage1[0] = "Alteast One partition should be there in Cluster";
        } else {
          // construct map based on applianceId for selected PartitionList
          this.selectedPartitions.forEach(partitionObj => {
            let tempMap: Array<any> = [];
            if (this.partitionMap.has(partitionObj['applianceId'])) {
              tempMap = this.partitionMap.get(partitionObj['applianceId']);
            }
            tempMap.push(partitionObj);
            this.partitionMap.set(partitionObj['applianceId'], tempMap);
          });
          //construct map code ends here
          // get all the applianceIds form the map and iterate each applianceId , to 
          // identity the credentialSaved or not 
          let applianceIds = Array.from(this.partitionMap.keys());
          applianceIds.forEach(appId => {
            if (this.partitionMap.has(appId)) {
              let partitionObj = this.partitionMap.get(appId)[0];
              if (partitionObj['credentialSaved']) {
                this.credentialsSavedPartitionList.push(partitionObj);
              } else {

                // check appliance credentials are available in localsession.
                // if available in localsession , skips the login for appliance.
                let loginCredentials = JSON.parse(localStorage.getItem(partitionObj.ipAddress));
                if (loginCredentials != null) {
                  partitionObj['operationPerformedUserName'] = loginCredentials.username;
                  partitionObj['operationPerformedPassword'] = loginCredentials.password;
                  this.saveCredentialsToSessionArray.push(partitionObj);
                } else {
                  this.nonCredentialSavedParitionList.push(partitionObj);
                }
              }
              // this.credentialsSavedPartitionList.push(partitionObj);
            }
          });
          //  check the length of non credentialsaved Partition List to show the login pop.
          // if length is 0 , then show the confirm modal,whether to continue the selected Operation or not.
          if (this.nonCredentialSavedParitionList.length > 0) {
            this.partitionName = this.nonCredentialSavedParitionList[this.partitionCount - 1]['applianceName'];
            // dual factor authentication
            this.applianceDualFactorInitialized = this.nonCredentialSavedParitionList[this.partitionCount - 1]['applianceDualFactorInitialized'];
            this.setValidationDualFactorAuthentication();
            // ends here 
            this.totalpartitionCount = this.nonCredentialSavedParitionList.length;
            if (this.partitionCount == this.totalpartitionCount) {
              this.isLastPartition = true;
            }
            this.addNodeModal.hide();
            this.removeNodeModal.hide();
            this.partitionLoginModal.show();
          } else {
            this.removePartition();
          }
        }

      }
    } else {
      this.messageModal1.show();
      this.errorMessage1[0] = "Please select any partition to perform the activity!";
    }

  }

  goToNextPartition() {
    this.userNameField.nativeElement.focus();
    let applianceObj = this.nonCredentialSavedParitionList[this.partitionCount - 1];
    this.createListOfPartitions(applianceObj, "login");
    let loginDetailsModal = {};
    loginDetailsModal['applianceId'] = applianceObj.applianceId;
    loginDetailsModal['applianceName'] = applianceObj.applianceName;
    loginDetailsModal['ipAddress'] = applianceObj.ipAddress;
    loginDetailsModal['operationUsername'] = this.loginForm.get('username').value;
    loginDetailsModal['operationPassword'] = this.loginForm.get('password').value;
    loginDetailsModal['applianceDualFactorInitialized'] = applianceObj.applianceDualFactorInitialized;
    let dualFactorCheck = applianceObj.applianceDualFactorInitialized;
    if (dualFactorCheck) {
      loginDetailsModal = this.setDualFactorData(loginDetailsModal);
    }
    this.loginCredentialsArray.push(loginDetailsModal);
    // Storing appliance login credentials in local session
    let ipAddress = applianceObj.ipAddress;
    let loginCredentials = {
      username: this.loginForm.get('username').value,
      password: this.loginForm.get('password').value
    };
    localStorage.setItem(ipAddress, JSON.stringify(loginCredentials));
    // local session code ends here
    if (this.partitionCount < this.nonCredentialSavedParitionList.length) {
      this.partitionName = this.nonCredentialSavedParitionList[this.partitionCount]['applianceName'];
      this.applianceDualFactorInitialized = this.nonCredentialSavedParitionList[this.partitionCount]['applianceDualFactorInitialized'];
      this.setValidationDualFactorAuthentication();
      this.partitionCount++;
      if (this.partitionCount == this.totalpartitionCount) {
        this.isLastPartition = true;
      }
    } else {
      this.partitionLoginModal.hide();
      //this.goToCreateCluster();
      this.checkAppliancesCredentials();
    }
    if (dualFactorCheck) {
      this.certificateVariable.nativeElement.value = '';
      this.keyVariable.nativeElement.value = "";
    }
    this.loginForm.reset();
  }

  checkAppliancesCredentials() {
    this.loading = true;
    this.message = [];
    this.errorMessage = [];
    this.errorMessage1 = [];
    this.checkLoginCredentialsResultArray = [];
    this._appService.checkAppliancesCredentials(this.loginCredentialsArray).subscribe(
      (response) => {
        let isSuccess: boolean = true;
        response.forEach(obj => {
          this.loginCredentialsArray = [];
          if (obj.code != "200") {
            this.loading = false;
            this.checkLoginCredentialsResultArray.push(obj);
            isSuccess = false;
          }

        });
        if (isSuccess) {
          this.partitionLoginModal.hide();
          // this.invokeCreateCluster();
          if (this.partitionOperation === 'addNode') {
            this.invokeCreateCluster();
          } else if (this.partitionOperation === 'removeNode') {
            this.removePartition();
          }
        } else {
          this.finalPartitionList = [];
          //this.selectedPartitionList = [];
          this.selectedPartitions = [];
          this.partitionLoginModal.show();
        }
      },
      (error) => {
        console.log(error);
      })
  }

  createListOfPartitions(applianceObj, value) {
    if (this.partitionMap.has(applianceObj.applianceId)) {
      let partitionList = this.partitionMap.get(applianceObj.applianceId);
      partitionList.forEach(obj => {
        if (value == "login") {
          obj['operationPerformedUserName'] = this.loginForm.get('username').value;
          obj['operationPerformedPassword'] = this.loginForm.get('password').value;
        } else {
          obj['operationPerformedUserName'] = applianceObj.operationPerformedUserName;
          obj['operationPerformedPassword'] = applianceObj.operationPerformedPassword;
        }
        this.finalPartitionList.push(obj);
      });
    }
  }

  invokeCreateCluster() {
    this.addNodeModal.hide();
    this.loading = true;
    this.credentialsSavedPartitionList.forEach(partitionObj => {
      this.createListOfPartitions(partitionObj, "");
    });
    this.saveCredentialsToSessionArray.forEach(partitionObj => {
      this.createListOfPartitions(partitionObj, "");
    });
    //this.clusterDetails['clusterPartitionsRelationships'] = this.finalPartitionList;
    let clusterDetaisModel = {};
    clusterDetaisModel['clusterId'] = this.clusterDetails['clusterId'];
    clusterDetaisModel['clusterName'] = this.clusterDetails['clusterName'];
    clusterDetaisModel['clusterVersion'] = this.clusterDetails['clusterVersion'];
    clusterDetaisModel['groupId'] = this.clusterDetails['groupId'];
    clusterDetaisModel['clusterPartitionsRelationships'] = this.finalPartitionList;
    this._partitionManagementService.comparePartitionsAndCreateCluster(clusterDetaisModel).subscribe(
      res => {
        this.loading = false;
        this.message = [];
        this.errorMessage = [];
        this.errorMessage1 = [];
        this.selectedPartitions = [];
        this.finalPartitionList = [];
        if (res.code == "200") {

          this.message = res.message.split("@#");;
        } else if (res.code == "415") {
          // this.errorMessage = res.errorMessage.split("@#");
          let setError = res.errorMessage.split(".");
          this.errorMessage.push(setError[0] + ".Add Node is not allowed");
        } else {
          this.errorMessage1 = res.errorMessage.split("@#");
        }
        this.messageModal1.show();
        this.clearData();
      },
      error => {
        console.log(error);
      },
    )
  }


  public formValidationFields1 = {
    "username": '',
    "password": '',
    'dualFactorAuthServerPortNo': ''

  }
  isFieldValid1(field: string) {
    if (this.loginForm.get(field).touched) {
      this.formValidationFields1 = this._fieldErrorDisplayService.validateField(this.loginForm, field, this.formValidationFields1, "login")
    }
    return !this.loginForm.get(field).valid && this.loginForm.get(field).touched;
  }

  displayFieldCss1(field: string) {
    return {
      'has-error': this.isFieldValid1(field),
      'has-feedback': this.isFieldValid1(field)
    };
  }


  goToCreateCluster() {
    this.loading = true;
    this._service.createCluster(this.clusterDetails).subscribe(
      (response) => {
        this.loading = false;
        this.message = [];
        this.errorMessage = [];
        this.errorMessage1 = [];
        this.checkLoginCredentialsResultArray = [];
        if (response.code == "200") {
          this.message = response.message.split("@#");
        } else {
          this.errorMessage1 = response.errorMessage.split("@#");
        }
      },
      (error) => {
        this.loading = false;
        console.error(error);
      }
    )
  }

  showCreateCluster(isShow: boolean) {
    this.isCreateClusterShow = isShow
  }


  goToRemoveNodeModal(operation) {
    this.message = [];
    this.errorMessage = [];
    this.errorMessage1 = [];
    this.selectedPartitions = [];
    this.partitionOperation = '';
    this.partitionOperation = operation;
    this.removeNodeModal.show();
    let list = this.partitionDetailsTableList;
    this.partitionDetailsTableList = [];
    list.forEach(element => {
      let partitionDetails = {};
      partitionDetails['partitionName'] = element.partitionName;
      partitionDetails['partitionId'] = element.partitionId;
      partitionDetails['applianceId'] = element.applianceId;
      partitionDetails['applianceName'] = element.applianceName;
      partitionDetails['ipAddress'] = element.ipAddress;
      partitionDetails["keys"] = element.keys;
      partitionDetails["sslContexts"] = element.sslContexts;
      partitionDetails["nodeId"] = element.nodeId;
      partitionDetails["zoneId"] = element.zoneId;
      partitionDetails["acclrDev"] = element.acclrDev;
      partitionDetails["sync"] = element.sync;
      //  partitionDetailModel["sync"]=obj.partitionDetailModel.partitionId;
      partitionDetails["tombstoneKeys"] = element.tombstoneKeys;
      if (element.remoteEth0Addr != null) {
        partitionDetails['remoteEth0Addr'] = element.remoteEth0Addr;
      }
      partitionDetails['applianceDualFactorInitialized'] = element.applianceDualFactorInitialized;
      this.partitionDetailsTableList.push(partitionDetails);
    });
  }

  removePartition() {
    this.removeNodeModal.hide();
    this.message = [];
    this.errorMessage = [];
    this.errorMessage1 = [];
    this.checkLoginCredentialsResultArray = [];
    this.loading = true;
    this.removeCheck = false;
    this.credentialsSavedPartitionList.forEach(partitionObj => {
      this.createListOfPartitions(partitionObj, "");
    });
    this.saveCredentialsToSessionArray.forEach(partitionObj => {
      this.createListOfPartitions(partitionObj, "");
    });
    let clusterDetailsModel = {};
    clusterDetailsModel['clusterId'] = this.clusterDetails['clusterId'];
    clusterDetailsModel['clusterName'] = this.clusterDetails['clusterName'];
    clusterDetailsModel['clusterVersion'] = this.clusterDetails['clusterVersion'];
    clusterDetailsModel['groupId'] = this.clusterDetails['groupId'];
    clusterDetailsModel['clusterPartitionsRelationships'] = this.finalPartitionList;
    this._service.deleteNodeDetails(clusterDetailsModel).subscribe((response) => {
      this.loading = false;
      let res = response.json();
      this.selectedPartitions = [];
      this.finalPartitionList = [];
      this.selectedPartitionsIds = [];
      res.forEach(obj => {
        if (obj.code == "200") {
          this.message = obj.message.split("@#");;
        } else {
          this.errorMessage1 = obj.errorMessage.split("@#");;
        }
      });
      this.messageModal1.show();
    })

  }

  selectPartitionItems1(event, applianceId, partitionId: string) {
    if (event.checked) {
      for (var i = 0; i < this.partitionDetailsTableList.length; i++) {
        if (this.partitionDetailsTableList[i].applianceId == applianceId) {
          if (this.partitionDetailsTableList[i].partitionId == partitionId) {
            let selectedPartitionObject = this.partitionDetailsTableList[i];
            selectedPartitionObject['deletedPartitionId'] = partitionId;
            this.selectedPartitions.push(selectedPartitionObject);
            this.selectedPartitionsIds.push(partitionId);
          }
        }
      }
    } else {
      const index = this.selectedPartitions.findIndex(partition => partition.partitionId === partitionId);
      this.selectedPartitions.splice(index, 1);

      const index1 = this.selectedPartitionsIds.findIndex(id => id === partitionId);
      this.selectedPartitionsIds.splice(index1, 1);
    }
  }

  deleteCluster() {
    this.clusterDetails.clusterPartitionsRelationships.forEach(obj => {
      obj['deletedPartitionId'] = obj.partitionId;
      this.selectedPartitions.push(obj);
    });
    this.goToLoginModal('deleteCluster');
  }
  closeAddNodeModal() {
    this.addNodeModal.hide();
    this.clearData();
    this.selectedPartitions = [];
  }

  clearData() {
    this.loginForm.reset();
    this.nonCredentialSavedParitionList = [];
    this.credentialsSavedPartitionList = [];
    this.saveCredentialsToSessionArray = [];
    this.partitionCount = 1;
    this.totalpartitionCount = 0;
    this.partitionName = '';
    this.isLastPartition = false;
    //this.finalPartitionList = [];
  }

  closeRemoveNodeModal() {
    this.removeNodeModal.hide();
    this.clearData();
    this.selectedPartitions = [];
    this.selectedPartitionsIds = [];
  }

  closeLoginModal() {
    this.partitionLoginModal.hide();
    //this.selectedPartitions = [];
    //this.selectedPartitionsIds = [];
    this.clearData();
  }
  closeMessageModal() {
    this.messageModal1.hide();
    this.selectedPartitions = [];
    this.selectedPartitionsIds = [];
    this.clearData();
  }
  redirectToListCluster() {
    this.clearData();
    this.selectedPartitions = [];
    this.selectedPartitionsIds = [];
    this._router.navigate(['/listCluster']);
  }

  setDualFactorData(loginDetailsModal) {
    loginDetailsModal['initializeDetailModel'] = {};
    loginDetailsModal['initializeDetailModel']['cryptoOfficerName'] = this.loginForm.get('username').value;
    loginDetailsModal['initializeDetailModel']['cryptoOfficerPassword'] = this.loginForm.get('password').value;
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel'] = {};

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['dualFactorAuthServerPortNo'] = this.loginForm.get('dualFactorAuthServerPortNo').value;
    // certificate file details
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateContent'] = this.loginForm.get('certificateContent').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateName'] = this.loginForm.get('certificateName').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateExtension'] = this.loginForm.get('certificateExtension').value;
    // key file details
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileContent'] = this.loginForm.get('keyfileContent').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileName'] = this.loginForm.get('keyfileName').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileExtension'] = this.loginForm.get('keyfileExtension').value;
    return loginDetailsModal;
  }

  setValidationDualFactorAuthentication() {
    // set validations for dual factor properties 
    if (this.applianceDualFactorInitialized) {
      this.loginForm.get('dualFactorAuthServerPortNo').setValidators(Validators.required);
      this.loginForm.get('certificateFile').setValidators(Validators.required);
      this.loginForm.get('keyFile').setValidators(Validators.required);
    } else {
      this.loginForm.get('dualFactorAuthServerPortNo').setValidators(null);
      this.loginForm.get('certificateFile').setValidators(null);
      this.loginForm.get('keyFile').setValidators(null);
    }
    this.loginForm.get('dualFactorAuthServerPortNo').updateValueAndValidity();
    this.loginForm.get('certificateFile').updateValueAndValidity();
    this.loginForm.get('keyFile').updateValueAndValidity();
  }


  onCertificateFileChange($event) {
    this.loginForm.get('certificateFile').markAsTouched({ onlySelf: true });
    let file = $event.target.files[0];
    this.loginForm.controls['certificateFile'].setValue(file ? file.name : ''); // <-- Set Value for Validation
    const filePicked = (event.target as HTMLInputElement).files[0];
    if (filePicked != undefined) {
      const fileName = filePicked.name;
      const extension = filePicked.name.split('.').pop() || '';
      const reader = new FileReader();
      reader.onload = () => {
        if (extension == 'crt') {
          this.loginForm.get('certificateContent').setValue(reader.result);
          this.loginForm.get('certificateName').setValue(fileName.substring(0, fileName.indexOf('.')));
          this.loginForm.get('certificateExtension').setValue(extension);
        } else {
          this.loginForm.get('certificateFile').setErrors({ "invalidExt": true })

        }
      };
      reader.readAsText(filePicked);
    } else {
      this.loginForm.get('certificateFile').setValue("");
      this.loginForm.get('certificateContent').setValue("");
      this.loginForm.get('certificateName').setValue("");
      this.loginForm.get('certificateExtension').setValue("");
      return false;
    }
  }

  onKeyFileChange($event) {
    this.loginForm.controls['keyFile'].markAsTouched({ onlySelf: true });
    let file = $event.target.files[0];
    this.loginForm.controls['keyFile'].setValue(file ? file.name : ''); // <-- Set Value for Validation
    const filePicked = (event.target as HTMLInputElement).files[0];
    if (filePicked != undefined) {
      const fileName = filePicked.name;
      let ext = filePicked.name.split('.');
      const extension = ext[1];
      const reader = new FileReader();
      reader.onload = () => {
        if (extension == 'key') {
          this.loginForm.get('keyfileContent').setValue(reader.result);
          this.loginForm.get('keyfileName').setValue(fileName.substring(0, fileName.indexOf('.')));
          this.loginForm.get('keyfileExtension').setValue(extension);
        } else {
          this.loginForm.get('keyFile').setErrors({ "invalidExt": true })

        }
      };
      reader.readAsText(filePicked);
    } else {
      this.loginForm.get('keyFile').setValue("");
      this.loginForm.get('keyfileContent').setValue("");
      this.loginForm.get('keyfileName').setValue("");
      this.loginForm.get('keyfileExtension').setValue("");
      return false;
    }
  }

  ngOnDestroy() {
    if (this.timer) {
      this.timer.unsubscribe();
    }
    if (this.clusterTimer) {
      this.clusterTimer.unsubscribe();
    }
  }
}


