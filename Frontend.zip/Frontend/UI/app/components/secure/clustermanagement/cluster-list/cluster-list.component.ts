import { Component, OnInit, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { PartitionManagementService } from '../../../../services/partitionmanagement/partitionmanagement.service';
import { AnonymousSubscription } from "rxjs/Subscription";
import { Observable } from "rxjs/Observable";
import { DataTableResource } from '../../data-table/index';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { I18nService } from '../../../../services/common/i18n/i18n.service';
import { BreadcrumbService } from '../../../../services/common/breadcrumb.service';
import { FieldErrorDisplayService } from '../../../../services/common/field-error-display.service';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { ClustermanagementService } from './../../../../services/clustermanagement.service';
import { ClusterCreateComponent } from './../cluster-create/cluster-create.component';
import { Router } from '@angular/router';
@Component({
  selector: 'app-cluster-list',
  templateUrl: './cluster-list.component.html',
  styleUrls: ['./cluster-list.component.css']
})

export class ClusterListComponent implements OnInit, OnDestroy {
  @ViewChild("username") userNameField: ElementRef;
  @ViewChild('clusterLoginModal')
  clusterLoginModal: ModalDirective;
  @ViewChild('clusterMessageModal')
  clusterMessageModal: ModalDirective;
  @ViewChild('deleteClusterConfirmModal')
  deleteClusterConfirmModal: ModalDirective;
  title = "Partition List";
  clusterList: any = [];
  clusterPartitionsRelationships: any[];
  showList: boolean = false;
  selectedClusterList = [];
  toolTipData: any = {};
  timercount = 0;
  checkInProgressStatus: boolean = false;
  loading: boolean = false;
  private timer: AnonymousSubscription;
  private clusterListSubscription: AnonymousSubscription;
  loginForm: FormGroup;
  valid: boolean = false;
  checkLoginCredentialsResultArray: any = [];
  saveCredentialsToSessionArray: any = [];
  partitionMap: Map<string, Array<any>>;
  loginCredentailsArray: any = [];
  applianceCount = 1;
  totalApplianceCount = 0;
  applianceName = '';
  partitionDetailsTableList = [];
  selectedPartitions: any = [];
  credentialsSavedPartitionList: any = [];
  nonCredentialSavedParitionList: any = [];
  isLastPartition: boolean = false;
  loginCredentialsArray: any = [];
  errorMessage1:any=[];
  message:any=[];
  errorMessage:any=[];
  listtrue: boolean = true;
  finalPartitionList: any = [];
  applianceDualFactorInitialized : boolean = false;
  constructor(private _service: PartitionManagementService,
    private _clusterService: ClustermanagementService,
    private _I18nService: I18nService,
    private _formBuilder: FormBuilder,
    private _appService: AppliancemanagementService,
    private _fieldErrorDisplayService: FieldErrorDisplayService,private _router: Router) {

  }

  ngOnInit() {
    this.createLoginForm();
    this.getClusterList();

  }
  getClusterList() {
    this._service.listClusters().subscribe(
      res => {
        this.clusterList = [];
        if(res.length > 0){
        this.listtrue = true;
        this.checkInProgressStatus = false;
        this.clusterList = res;
        let count: number = 0;
        this.clusterList.forEach(clusterObj => {
          this.clusterList[count]['disabled'] = false;
          if (this.clusterList[count]['lastOperationStatus'] === 'In-Progress') {
            this.clusterList[count]['InProgress'] = true;
            this.checkInProgressStatus = true;
            this.clusterList[count]['statusColor'] = "grey";
          } else {
            this.clusterList[count]['InProgress'] = false;
            this.clusterList[count]['statusColor'] = "green";
          }
          count = count + 1;
        });
      }
      else{
        this.listtrue = false;
      }
      this.getTimeIntervalData();
      },
      error => {
        this.loading = false;
        console.log(error);
      },
    );
  }

  private getTimeIntervalData(): void {
    this.timer = Observable.timer(15000).first().subscribe(() => this.getClusterList());
    this.timercount = this.timercount + 1;
  }

  toggle() {
    this.showList = true;
  }
  toggle1() {
    this.showList = false;
  }

  selectClusterItems(event, clusterId: string) {
    
    this.partitionDetailsTableList = [];
    if (event.target.checked) {
      event.currentTarget.style.visibility = "visible";
      for (var i = 0; i < this.clusterList.length; i++) {
        if (this.clusterList[i].clusterId == clusterId) {
          this.clusterList[i]['checked'] = true;
          this.clusterList[i]['disabled'] = false;
          let clusterDetails = {};
          clusterDetails['clusterId'] = this.clusterList[i].clusterId;
          clusterDetails['clusterName'] = this.clusterList[i].clusterName;
          clusterDetails['clusterVersion'] = this.clusterList[i].clusterVersion;
          clusterDetails['groupId'] = this.clusterList[i].groupId;
          clusterDetails['operationType'] = "removeCluster";
          if (this.clusterList[i].clusterPartitionsRelationships != null && this.clusterList[i].clusterPartitionsRelationships != '') {
            let clusterRelationshipArray = [];
            let partitionMap = new Map<string, string>();
            this.clusterList[i].clusterPartitionsRelationships.forEach(obj => {
              let clusterRelationshipModel = {};
              let partitionDetails = {};
              clusterRelationshipModel['nodeId'] = obj.nodeId;
              clusterRelationshipModel['zoneId'] = obj.zoneId;
              clusterRelationshipModel['remoteEth0Addr'] = obj.remoteEth0Addr;
              clusterRelationshipModel['operationPerformedUserName'] = obj.operationPerformedUserName;
              clusterRelationshipModel['operationPerformedPassword'] = obj.operationPerformedPassword;
              clusterRelationshipModel['applianceId'] = obj.partitionDetailModel.applianceId;
              clusterRelationshipModel['ipAddress'] = obj.ipAddress;
              clusterRelationshipModel['applianceName'] = obj.applianceName;
              clusterRelationshipModel['partitionName'] = obj.partitionName;
              clusterRelationshipModel['applianceDualFactorInitialized'] = obj.partitionDetailModel.applianceDualFactorInitialized;
              if (obj.partitionDetailModel != null) {
                clusterRelationshipModel['partitionId'] = obj.partitionDetailModel.partitionId;
              }
              clusterRelationshipModel['deletedPartitionId'] = obj.partitionDetailModel.partitionId;
              clusterRelationshipArray.push(clusterRelationshipModel);
              clusterDetails['clusterPartitionsRelationships'] = clusterRelationshipArray;

            })
          }
          this.selectedClusterList.push(clusterDetails);
        }
        else if (!this.clusterList[i]['checked']) {
          this.clusterList[i]['disabled'] = true;
          this.clusterList[i]['checked'] = false;
        }
      }
    } else {
      event.currentTarget.style.visibility = "";
      const index = this.selectedClusterList.findIndex(
        cluster => cluster.clusterId === clusterId);
      this.selectedClusterList.splice(index, 1);
      for (var i = 0; i < this.clusterList.length; i++) {
        this.clusterList[i]['checked'] = false;
        this.clusterList[i]['disabled'] = false;
      }
    }
  }

  showDeleteConfirmModal(){
    this.deleteClusterConfirmModal.show();
  }
  goToLoginModal() {
    this.deleteClusterConfirmModal.hide();
    this.loginForm.reset();
    this.selectedPartitions = []
    this.checkLoginCredentialsResultArray = [];
    this.credentialsSavedPartitionList = [];
    this.saveCredentialsToSessionArray = [];
    this.nonCredentialSavedParitionList = [];
    this.applianceDualFactorInitialized = false;
    if (this.selectedClusterList.length > 0) {
      //this.clearData();
      this.partitionMap = new Map<string, Array<any>>();
      // need login credentials for existing cluster partitions.
      if (this.selectedClusterList[0]['clusterPartitionsRelationships'] != null && this.selectedClusterList[0]['clusterPartitionsRelationships'] != '') {
        let existingClusterDetails = this.selectedClusterList[0]['clusterPartitionsRelationships'];
        existingClusterDetails.forEach(obj => {
          this.selectedPartitions.push(obj);
        });
      }

      // construct map based on applianceId for selected PartitionList
      this.selectedPartitions.forEach(partitionObj => {
        let tempMap: Array<any> = [];
        if (this.partitionMap.has(partitionObj['applianceId'])) {
          tempMap = this.partitionMap.get(partitionObj['applianceId']);
        }
        tempMap.push(partitionObj);
        this.partitionMap.set(partitionObj['applianceId'], tempMap);
      });
      //construct map code ends here
      // get all the applianceIds form the map and iterate each applianceId , to 
      // identity the credentialSaved or not 
      let applianceIds = Array.from(this.partitionMap.keys());
      applianceIds.forEach(appId => {
        if (this.partitionMap.has(appId)) {
          let partitionObj = this.partitionMap.get(appId)[0];
          if (partitionObj['credentialSaved']) {
            this.credentialsSavedPartitionList.push(partitionObj);
          } else {
            // check appliance credentials are available in localsession.
            // if available in localsession , skips the login for appliance.
            let loginCredentials = JSON.parse(localStorage.getItem(partitionObj.ipAddress));
            if (loginCredentials != null) {
              partitionObj['operationPerformedUserName'] = loginCredentials.username;
              partitionObj['operationPerformedPassword'] = loginCredentials.password;
              this.saveCredentialsToSessionArray.push(partitionObj);
            } else {
              this.nonCredentialSavedParitionList.push(partitionObj);
            }
          }
        }
      });
      //  check the length of non credentialsaved Partition List to show the login pop.
      // if length is 0 , then show the confirm modal,whether to continue the selected Operation or not.
      if (this.nonCredentialSavedParitionList.length > 0) {
        this.applianceName = this.nonCredentialSavedParitionList[this.applianceCount - 1]['applianceName'];
        this.totalApplianceCount = this.nonCredentialSavedParitionList.length;
        // dual factor authentication
        this.applianceDualFactorInitialized = this.nonCredentialSavedParitionList[this.applianceCount - 1]['applianceDualFactorInitialized'];
        this.setValidationDualFactorAuthentication();
        // ends here 
        if (this.applianceCount == this.totalApplianceCount) {
          this.isLastPartition = true;
        }
        this.clusterLoginModal.show();
      } else {
        this.removePartition();
      }

    } else {
      this.clusterMessageModal.show();
      this.message = [];
      this.errorMessage = [];
      this.errorMessage1 = [];
      this.errorMessage1[0] = "Please select any cluster to perform the activity!";
    }

  }
  goToNextPartition() {
    this.userNameField.nativeElement.focus();
    let applianceObj = this.nonCredentialSavedParitionList[this.applianceCount - 1];
    this.createListOfPartitions(applianceObj, "login");
    let loginDetailsModal = {};
    loginDetailsModal['applianceId'] = applianceObj.applianceId;
    loginDetailsModal['applianceName'] = applianceObj.applianceName;
    loginDetailsModal['ipAddress'] = applianceObj.ipAddress;
    loginDetailsModal['operationUsername'] = this.loginForm.get('username').value;
    loginDetailsModal['operationPassword'] = this.loginForm.get('password').value;
    loginDetailsModal['applianceDualFactorInitialized'] = applianceObj.applianceDualFactorInitialized;
    let dualFactorCheck = applianceObj.applianceDualFactorInitialized;
    if (dualFactorCheck) {
      loginDetailsModal = this.setDualFactorData(loginDetailsModal);
    }
    this.loginCredentialsArray.push(loginDetailsModal);
    // Storing appliance login credentials in local session
    let ipAddress = applianceObj.ipAddress;
    let loginCredentials = {
      username: this.loginForm.get('username').value,
      password: this.loginForm.get('password').value
    };
    localStorage.setItem(ipAddress, JSON.stringify(loginCredentials));
    // local session code ends here
    if (this.applianceCount < this.nonCredentialSavedParitionList.length) {
      this.applianceName = this.nonCredentialSavedParitionList[this.applianceCount]['applianceName'];
      this.applianceDualFactorInitialized = this.nonCredentialSavedParitionList[this.applianceCount]['applianceDualFactorInitialized'];
      this.setValidationDualFactorAuthentication();
      this.applianceCount++;
      if (this.applianceCount == this.totalApplianceCount) {
        this.isLastPartition = true;
      }
    } else {
      this.clusterLoginModal.hide();
      this.checkAppliancesCredentials();
    }
    this.loginForm.reset();
  }

  checkAppliancesCredentials() {
    this.loading = true;
    this.message = [];
    this.errorMessage = [];
    this.errorMessage1 = [];
    this.checkLoginCredentialsResultArray = [];
    this._appService.checkAppliancesCredentials(this.loginCredentialsArray).subscribe(
      (response) => {
        let isSuccess: boolean = true;
        response.forEach(obj => {
          this.loginCredentialsArray = [];
          if (obj.code != "200") {
            this.loading = false;
            this.checkLoginCredentialsResultArray.push(obj);
            localStorage.removeItem(obj.ipAddress);
            isSuccess = false;
          }

        });
        if (isSuccess) {
          this.clusterLoginModal.hide();
          this.removePartition();
        } else {
          this.applianceCount = 1;
          this.finalPartitionList = [];
          //this.selectedPartitionList = [];
          this.selectedPartitions = [];
          //this.selectedClusterList = [];
          this.clusterMessageModal.show();
        }
      },
      (error) => {
        this.loading = false;
        console.log(error);
      })
  }

  createListOfPartitions(partitionObj, value) {
    if (this.partitionMap.has(partitionObj['applianceId'])) {
      let partitionList = this.partitionMap.get(partitionObj['applianceId']);
      partitionList.forEach(obj => {
        if (value == "login") {
          obj['operationPerformedUserName'] = this.loginForm.get('username').value;
          obj['operationPerformedPassword'] = this.loginForm.get('password').value;
        } else {
          obj['operationPerformedUserName'] = partitionObj.operationPerformedUserName;
          obj['operationPerformedPassword'] = partitionObj.operationPerformedPassword;
        }
        this.finalPartitionList.push(obj);
      });
    }
  }

  removePartition() {
    this.message = [];
    this.errorMessage = [];
    this.errorMessage1 = [];
    this.checkLoginCredentialsResultArray = [];
    this.loading = true;
    this.credentialsSavedPartitionList.forEach(partitionObj => {
      this.createListOfPartitions(partitionObj, "");
    });
    this.saveCredentialsToSessionArray.forEach(partitionObj => {
      this.createListOfPartitions(partitionObj, "");
    });
    this.selectedClusterList[0]['clusterPartitionsRelationships'] = this.finalPartitionList;
    this._clusterService.deleteNodeDetails(this.selectedClusterList[0]).subscribe((response) => {
      this.loading = false;
     
      this.finalPartitionList = [];
      let res = response.json();
      //this.selectedClusterList = [];
      res.forEach(obj => {
        if (obj.code == "200") {
          this.message = obj.message.split("@#");
          if(this.message == null || this.message == ''){
            this.message = obj.errorMessage.split("@#");
          }
          this.selectedClusterList = [];
          this.getClusterList();
        } else {
          this.errorMessage1 = obj.errorMessage.split("@#");
          if(this.errorMessage1 == null || this.errorMessage1==''){
            this.errorMessage1 =obj.message.split("@#");
          }
        }
      });
      // this.selectedClusterList = [];
      this.clusterMessageModal.show();
    })
  }
  getClusterToolTipData(clusterId) {
    this.toolTipData = "";
    this.clusterList.find
      (cluster => {
        if (cluster.clusterId == clusterId) {
          this.toolTipData = cluster;
        }
      })
  }

  redirectToListCluster(){
    this.clusterLoginModal.hide();
    this.clusterMessageModal.hide();
    this.getClusterList();
  }
  callBackToClusterList() {
    console.log("Callback ----> List of Partitions");
    this.selectedClusterList = [];
    this.getClusterList();
  }
  createLoginForm() {
    this.loginForm = this._formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      dualFactorAuthServerPortNo:[''],
      certificateFile: [""],
      keyFile: [""],
      certificateName: [''],
      certificateExtension: [''],
      certificateContent: [''],
      keyfileName: [''],
      keyfileExtension: [''],
      keyfileContent: ['']
    });
  }
  public formValidationFields1 = {
    "username": '',
    "password": '',
    'dualFactorAuthServerPortNo':''
  }
  isFieldValid1(field: string) {
    if (this.loginForm.get(field).touched) {
      this.formValidationFields1 = this._fieldErrorDisplayService.validateField(this.loginForm, field, this.formValidationFields1, "login")
    }
    return !this.loginForm.get(field).valid && this.loginForm.get(field).touched;
  }

  displayFieldCss1(field: string) {
    return {
      'has-error': this.isFieldValid1(field),
      'has-feedback': this.isFieldValid1(field)
    };
  }
  ngOnDestroy() {
    if (this.timer) {
      this.timer.unsubscribe();
    }
    if (this.clusterListSubscription) {
      this.clusterListSubscription.unsubscribe();
    }
  }

  showhideFilters: string = '0';
  subFilterOptions: any = [];
  searchListClusterByName: string;
  CheckListAppFilterSelect(value) {
    if (value === "0") {
      //alert("none");      
      this.searchListClusterByName = '';
    } else if (value === "1") {
      //alert("Name");     
    }
  }
  showClusterCreate(){
    this._router.navigate(['/createcluster']);
  }
  setDualFactorData(loginDetailsModal) {
    loginDetailsModal['initializeDetailModel'] = {};
    loginDetailsModal['initializeDetailModel']['cryptoOfficerName'] = this.loginForm.get('username').value;
    loginDetailsModal['initializeDetailModel']['cryptoOfficerPassword'] = this.loginForm.get('password').value;
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel'] = {};

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['dualFactorAuthServerPortNo'] = this.loginForm.get('dualFactorAuthServerPortNo').value;
    // certificate file details
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateContent'] = this.loginForm.get('certificateContent').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateName'] = this.loginForm.get('certificateName').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateExtension'] = this.loginForm.get('certificateExtension').value;
    // key file details
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileContent'] = this.loginForm.get('keyfileContent').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileName'] = this.loginForm.get('keyfileName').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileExtension'] = this.loginForm.get('keyfileExtension').value;
    return loginDetailsModal;
  }

  setValidationDualFactorAuthentication() {
    // set validations for dual factor properties 
    if (this.applianceDualFactorInitialized) {
      this.loginForm.get('dualFactorAuthServerPortNo').setValidators(Validators.required);
      this.loginForm.get('certificateFile').setValidators(Validators.required);
      this.loginForm.get('keyFile').setValidators(Validators.required);
    } else {
      this.loginForm.get('dualFactorAuthServerPortNo').setValidators(null);
      this.loginForm.get('certificateFile').setValidators(null);
      this.loginForm.get('keyFile').setValidators(null);
    }
    this.loginForm.get('dualFactorAuthServerPortNo').updateValueAndValidity();
    this.loginForm.get('certificateFile').updateValueAndValidity();
    this.loginForm.get('keyFile').updateValueAndValidity();
  }
  

  onCertificateFileChange($event) {
    this.loginForm.get('certificateFile').markAsTouched({ onlySelf: true });
    let file = $event.target.files[0]; 
    this.loginForm.controls['certificateFile'].setValue(file ? file.name : ''); // <-- Set Value for Validation
    const filePicked = (event.target as HTMLInputElement).files[0];
    if (filePicked != undefined) {
      const fileName = filePicked.name;
      const extension = filePicked.name.split('.').pop() || '';
      const reader = new FileReader();
      reader.onload = () => {
        if (extension == 'crt') {
          this.loginForm.get('certificateContent').setValue(reader.result);
          this.loginForm.get('certificateName').setValue(fileName.substring(0, fileName.indexOf('.')));
          this.loginForm.get('certificateExtension').setValue(extension);
        } else {
          this.loginForm.get('certificateFile').setErrors({"invalidExt":true})
         
        }
      };
      reader.readAsText(filePicked);
    } else {
      this.loginForm.get('certificateFile').setValue("");
      this.loginForm.get('certificateContent').setValue("");
      this.loginForm.get('certificateName').setValue("");
      this.loginForm.get('certificateExtension').setValue("");
      return false;
    }
  } 

  onKeyFileChange($event) {
    this.loginForm.controls['keyFile'].markAsTouched({ onlySelf: true });
    let file = $event.target.files[0]; 
    this.loginForm.controls['keyFile'].setValue(file ? file.name : ''); // <-- Set Value for Validation
    const filePicked = (event.target as HTMLInputElement).files[0];
    if (filePicked != undefined) {
      const fileName = filePicked.name;
      let ext  = filePicked.name.split('.');
      const extension =  ext[1];
      const reader = new FileReader();
      reader.onload = () => {
        if (extension == 'key') {
          this.loginForm.get('keyfileContent').setValue(reader.result);
          this.loginForm.get('keyfileName').setValue(fileName.substring(0, fileName.indexOf('.')));
          this.loginForm.get('keyfileExtension').setValue(extension);
        } else {
          this.loginForm.get('keyFile').setErrors({"invalidExt":true})
         
        }
      };
      reader.readAsText(filePicked);
    } else {
      this.loginForm.get('keyFile').setValue("");
      this.loginForm.get('keyfileContent').setValue("");
      this.loginForm.get('keyfileName').setValue("");
      this.loginForm.get('keyfileExtension').setValue("");
      return false;
    }
  } 
}

