import { Injectable } from '@angular/core';
import { Cookie } from 'ng2-cookies';
import { HttpServices } from './http.services';
@Injectable()
export class CommonServices {

    constructor(private _httpServices: HttpServices) {

    }
    clearSession() {
        console.log("session clear before logout.....");
        sessionStorage.clear();
        localStorage.clear();
        Cookie.delete('refresh_token');
        Cookie.delete(sessionStorage.getItem('username'));
    }

    forgotPassword(form) {
        let  url  =  "/forgotPassword";
        return  this._httpServices.httpPostWithOutToken(form,  url);
    }
    logout(){
        let  url  =  "/logout";
        return  this._httpServices.httpDeleteForLogout();
    }

    getRecentActivitiesNotification(){
        let url ="/recentActivityForNotification";
        return this._httpServices.httpGet(url);

    }
    getAlertNotification(){
        let url ="/alertForNotification";
        return this._httpServices.httpGet(url);
        
    }
}

