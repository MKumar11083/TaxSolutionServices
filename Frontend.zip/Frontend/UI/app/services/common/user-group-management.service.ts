import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Configuration } from '../../app.constants';
import {HttpServices} from './../common/http.services'
@Injectable()
export class UserGroupManagementService {
    private apiUrl: string;
    private UserGroupId: string;
    constructor(private _httpServices: HttpServices) {
        
    }

    getGroupList() {
        let url = "/listUserGroups";
        return this._httpServices.httpGet(url);
    }

    createGroup(form) {
        let url = "/createUserGroup";
        return this._httpServices.httpPost(form, url);
    }

    getuserGroupById(UserGroupId) {
        let url = "getUserGroupDetail/"+UserGroupId;
        return this._httpServices.httpGet(url);
    }
    getlistofApplicance(){
        let url = "/getDefaultGroupAppliances";
        return this._httpServices.httpGet(url);
    }

    deleteGroups(groupIds){
        var groupIdArray = JSON.parse("[" + groupIds + "]");
        let userGroupModel = 
            {
                "deletedUserGroupIds" :groupIdArray
            }
      
        let url = "deleteUserGroup";
        return this._httpServices.httpDeleteOperationWithBody(url,userGroupModel);
    }
    searchGroup(model){
        let url = "searchUserGroups";
        return this._httpServices.httpPost(model, url);
    }
    modifyGroup(form){
        let url = "modifyUserGroup";
        return this._httpServices.httpPut(form, url);
    }
}