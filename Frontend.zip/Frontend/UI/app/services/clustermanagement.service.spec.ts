import { TestBed, inject } from '@angular/core/testing';

import { ClustermanagementService } from './clustermanagement.service';

describe('ClustermanagementService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ClustermanagementService]
    });
  });

  it('should be created', inject([ClustermanagementService], (service: ClustermanagementService) => {
    expect(service).toBeTruthy();
  }));
});
