import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Configuration } from '../app.constants';
import { HttpServices } from './../services/common/http.services';
import { Cookie } from 'ng2-cookies';
@Injectable()
export class UserManagementService {
    private apiUrl: string;
    private userId: any = [];
    constructor(private _httpServices: HttpServices, private _http: Http) {

    }
    getUsersList() {
        let url = "/listUsers";
        return this._httpServices.httpGet(url);
    }
    getdropdownList() {
        let url = "/getGroupACLDetails";
        return this._httpServices.httpGet(url);
    }
    createUser(form) {
        let url = "/createUser";
        return this._httpServices.httpPost(form, url);
    }
    modifyUser(form) {
        console.log("modify .........");
        let url = "modifyUser";
        return this._httpServices.httpPut(form, url);
    }

    setuserId(userid) {
        this.clearUserId();
        userid.forEach(element => {
            this.userId.push(element);
        });
        
    }
    getuserId() {
        return this.userId;
    }
    getUserById(userId) {
        let url = "/getUserDetail/" + userId;
        return this._httpServices.httpGet(url);
    }
    clearUserId(){
        this.userId =[];
    }
    deleteUser(userIds) {
        let userDetailModel =
            {
                "deletedUserIds": userIds
            }

        let url = "deleteUser";
        return this._httpServices.httpDeleteOperationWithBody(url, userDetailModel);

    }
    searchUsers(model) {
        let url = "searchUserDetails";
        return this._httpServices.httpPost(model, url);
    }

    changePassword(form){
    let url = "/changePassword";
    return this._httpServices.httpPost(form, url);
    } 
    

}

