import { Injectable } from '@angular/core';
import { HttpServices } from './../../services/common/http.services';
import { AppURL } from '../../app.url';


@Injectable()
export class PartitionManagementService {

    constructor(private _httpServices: HttpServices,
        private _restURL: AppURL) {

    }

    getListOfPartition() {
        return this._httpServices.httpGet(this._restURL.GET_LIST_PARTITIONS_URL);
    }

    createPartition(form) {
        return this._httpServices.httpPost(form, this._restURL.POST_PARTITION_URL);
    }

    validateInitOperation(model) {
        return this._httpServices.httpPost(model, this._restURL.VALIDATE_INIT_OPERATION);
    }

    performCloseSessionOperation(model) {
        return this._httpServices.httpPut(model, this._restURL.CLOSE_SESSION_OPERATION_API);
    }

    performDeleteOperation(model) {
        return this._httpServices.httpDeleteOperationWithBody(this._restURL.DELETE_OPERATION_API, model);
    }

    performResetOperation(model) {
        return this._httpServices.httpPut(model, this._restURL.RESET_OPERATION_API, );
    }

    performConfigureNetwork(model) {
        return this._httpServices.httpPost(model, this._restURL.CONFIGURE_NETWORK_API);
    }
    performStartOrStopCAVServer(formData) {
        return this._httpServices.httpPost(formData, this._restURL.START_OR_STOP_API);
    }
    performCallResetConfig(formData) {
        return this._httpServices.httpPost(formData, this._restURL.RESET_CAV_SERVER_FILE_API);
    }
    performUploadConfig(formData) {
        return this._httpServices.httpPost(formData, this._restURL.UPLOAD_CAV_SERVER_FILE_API);
    }
    performDownloadConfig(formData) {
        return this._httpServices.httpPostForDownloadZipFile(formData, this._restURL.DOWNLOAD_CAV_SERVER_FILE_API);
    }
    performBackUpAndRestore(formData) {
        return this._httpServices.httpFileUploadPost(formData, this._restURL.BACKUP_AND_RESTORE_API);
    }
    performBackUp(formData) {
        return this._httpServices.httpPostForDownloadZipFile(formData, this._restURL.BACKUP_API);
    }
    getAlertDetails() {
        let url = "/alertsForPartition";
        return this._httpServices.httpGet(url);
    }

    getRecentActivityDetails() {
        let url = "/recentActivitiesForPartition";
        return this._httpServices.httpGet(url);
    }

    getInProgressActivities() {
        let url = "/inProgressActivityForPartition";
        return this._httpServices.httpGet(url);
    }

    getBarGraphData() {
        let url = "/partitionSnapshotDetails";
        return this._httpServices.httpGet(url);
    }

    getPartitionInfoData(partitionId) {
        let url = "/getPartitionInfo/" + partitionId + "/";
        return this._httpServices.httpGet(url);
    }

    getPartitionCavServerConfigData(partitionId) {
        let url = "/getPartitionCavServerConfig/" + partitionId + "/";
        return this._httpServices.httpGet(url);
    }

    getPartitionStats(partitionId) {
        let url = "/getPartitionStats/" + partitionId + "/";
        return this._httpServices.httpGet(url);
    }

    getPartitionCavServerStatsData(partitionId) {
        let url = "/getPartitionCavServerStats/" + partitionId + "/";
        return this._httpServices.httpGet(url);
    }

    getPartitionNetworkStats(partitionId) {
        let url = "/getPartitionNetworkStats/" + partitionId + "/";
        return this._httpServices.httpGet(url);
    }

    getComparePartitionsDetails(modal) {
        let url = "/comparePartitionsDetails";
        return this._httpServices.httpPost(modal, url);
    }

    createCluster(form) {
        let url = "/createCluster";
        return this._httpServices.httpPost(form, url);
    }

    comparePartitionsAndCreateCluster(form) {
        let url = "/comparePartitionsAndCreateCluster";
        return this._httpServices.httpPost(form, url);
    }

    listClusters() {
        return  this._httpServices.httpGet(this._restURL.GET_LIST_CLUSTERS_URL);
    }
    getPartitionInfoForResize(formData) {
        let url = "/getPartitionInfoForResize";
        return this._httpServices.httpPost(formData, url);
    }
    submitResizeData(formData){
        let url = "/resizePartitions";
        return this._httpServices.httpPost(formData, url);
    }

    updateEth01IpDetail(modal) {
        let url = "/updateEth01IpDetail";
        return this._httpServices.httpPost(modal, url);
    }
    getPartitionMonitorDetails(modal){
        let url = "/getPartitionMonitorData";
        return this._httpServices.httpPost(modal, url);
    }
    setPartitionMonitorData(modal){
        let url = "/setPartitionMonitorData";
        return this._httpServices.httpPost(modal, url);
    }
    getPartitionMonitorStatsDetails(modal){
        let url = "/getPartitionMonitorStats";
        return this._httpServices.httpPost(modal, url);
    }
   
}