import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'notAvail'
})
export class NotAvailStrPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    if(value != undefined){
      return value;
    }
    return "na";
  }
}
