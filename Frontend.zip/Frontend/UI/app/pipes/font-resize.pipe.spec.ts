import { FontResizePipe } from './font-resize.pipe';

describe('FontResizePipe', () => {
  it('create an instance', () => {
    const pipe = new FontResizePipe();
    expect(pipe).toBeTruthy();
  });
});
