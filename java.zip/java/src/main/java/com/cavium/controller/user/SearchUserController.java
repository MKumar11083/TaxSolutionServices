package com.cavium.controller.user;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.user.UserDetailModel;
import com.cavium.pojo.UserAttributes;
import com.cavium.service.user.UserService;

/*
 * This SearchUserController class is used for searching the user based on input in request
 * like userName, PhoneName, FirstName, lastName etc.
 *  @author RK00490847
 */
@RestController
@RequestMapping("rest")
public class SearchUserController
{
	// logger - instance of application log.
	private Logger logger = Logger.getLogger(this.getClass());

	// userService - Service class provide the interface for the Repository Operation.
	@Autowired
	private UserService userService;

	@Autowired
	private UserAttributes userAttributes;
	/**
	 * This Interface is used to get the values from the property file
	 */
	@Autowired
	Environment env;

	/*
	 * This searchUser method will return the users details.   
	 *  @return	
	 *  		- The List of Users
	 */
	@RequestMapping(value = "searchUserDetails" ,method = RequestMethod.POST)
	public List<UserDetailModel> searchUser(@RequestBody  UserDetailModel userDetailModel)
	{
		logger.info("Entered List userMethod:");
		String loggedInUser = userAttributes.getlogInUserName();	
		List<UserDetailModel> userDetailsModel =new ArrayList<UserDetailModel>(); 
		UserDetailModel	objUserDetailModel=this.userService.getUserDetails(loggedInUser);
		if(objUserDetailModel.getObjUserACLDetailsModel()==null || !env.getProperty("user.superadmin").equals(objUserDetailModel.getObjUserACLDetailsModel().getAclName())) {
			if(objUserDetailModel.getObjUserGroupModel()!=null && userDetailModel.getUserGroupId()==null ) {
				userDetailsModel = this.userService.listUsers(userDetailModel,String.valueOf(objUserDetailModel.getObjUserGroupModel().getId()),loggedInUser);
			}
		}else {
			String groupId="%";
			userDetailsModel = this.userService.listUsers(userDetailModel,groupId,loggedInUser);
		}
		for (Iterator<UserDetailModel> iterator = userDetailsModel.iterator(); iterator.hasNext();) {
			UserDetailModel objuserDetailModel = (UserDetailModel) iterator.next();
			if(!objUserDetailModel.getObjUserACLDetailsModel().getAclName().trim().equals(env.getProperty("user.superadmin"))){
				if(objuserDetailModel.getUserName().equals(loggedInUser) || objuserDetailModel.getObjUserACLDetailsModel().getAclName().trim().equals(env.getProperty("user.superadmin")) || 
					(objUserDetailModel.getObjUserACLDetailsModel().getAclName().trim().equals("SecondaryUser") && objuserDetailModel.getObjUserACLDetailsModel().getAclName().trim().equalsIgnoreCase("GroupAdmin")))
					iterator.remove();
				}
		
		if(objUserDetailModel.getObjUserACLDetailsModel().getAclName().trim().equals(env.getProperty("user.superadmin"))){
			if(!(loggedInUser.equalsIgnoreCase(objuserDetailModel.getCreatedBy())))
				iterator.remove();
			}
		}
		//List<UserDetailModel> userDetailModel = this.userService.listUsers(userDetailsModel);
		logger.info("List of Users:: "+userDetailsModel);

		return userDetailsModel;
	}
}
