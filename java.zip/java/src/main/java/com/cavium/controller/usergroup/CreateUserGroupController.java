package com.cavium.controller.usergroup;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.user.DesignationApplianceModel;
import com.cavium.model.user.UserGroupModel;
import com.cavium.pojo.UserAttributes;
import com.cavium.service.alerts.AlertsService;
import com.cavium.service.user.UserService;
import com.cavium.utill.CaviumConstant;
import com.cavium.utill.CaviumResponseModel;
import com.cavium.utill.CaviumUtil;



/*
 * This CreateUserGroupController class is used for creating the new UserGroup in Database.
 *  @author RK00490847
 */

@RestController
@RequestMapping("rest")
public class CreateUserGroupController {

	// logger - instance of application log.
	private Logger logger = Logger.getLogger(this.getClass());

	// userService - Service class provide the interface for the Repository Operation.
	@Autowired
	private UserService userService;

	// userAttributes - get LogIn User Details
	@Autowired
	private UserAttributes userAttributes;
	
	@Autowired
	private AlertsService alertsService;

	@Lookup
	public CaviumResponseModel getCaviumResponseModel() {
		return null;
	}

	/*
	 * This method will create the new userGroup and return the success message or error message . 
	 * 
	 *  @param RequestBody
	 *  		- UserGroupModel from Request	  
	 *  @return responseModel
	 *  		-  CaviumResponseModel Object
	 */
	@RequestMapping(value="createUserGroup", method = RequestMethod.POST)
	protected final CaviumResponseModel createUserGroup(@RequestBody UserGroupModel userGroupModel) {
		List<DesignationApplianceModel>listDesignationApplianceModel = new ArrayList<DesignationApplianceModel>();
		CaviumResponseModel responseModel=getCaviumResponseModel();
	String loggedInUser=userAttributes.getlogInUserName();
		try {
			if(userGroupModel.getRoleName()!=null){
				userGroupModel.setUsername(userAttributes.getlogInUserName());	 
				userGroupModel.setListDesignationApplianceModel(listDesignationApplianceModel);
				responseModel=userService.createUserGroup(userGroupModel);
			}else {
				responseModel.setResponseCode("204");
				responseModel.setResponseMessage("userGroup Name Empty");
				logger.error("userGroup Details Empty");
			}
		}catch (Exception e) {
			logger.error("Error coming while Saving the UserGroup");
			alertsService.createAlert(loggedInUser, "Error is coming while creating Group "+userGroupModel.getRoleName()+" by "+loggedInUser,CaviumConstant.USER_MANAGEMENT);
		}
		logger.info("ResponseModel for createUserGroup :: " + responseModel.toString());
		return responseModel;
	}

	/*
	 * This getAllAppliancesDetails method will return all the ACLs. 
	 * 	  
	 *  @return	
	 *  		- The List of All ACLs.
	 */
	@RequestMapping(value = "getAllAppliancesDetails" ,method = RequestMethod.GET)
	protected final  List<ApplianceDetailModel> getAllAppliancesDetails() {
		List<ApplianceDetailModel> listApplianceDetailModel = userService.getAllAppliancesDetails();
		return listApplianceDetailModel;
	}

	/*
	 * This getDefaultGroupAppliances method will return all the ACLs associated with Default UserGroup. 
	 * 	  
	 *  @return	
	 *  		- The List of All ACLs.
	 */
	@RequestMapping(value = "getDefaultGroupAppliances" ,method = RequestMethod.GET)
	protected final  List<DesignationApplianceModel> getDefaultGroupAppliances() {
		List<DesignationApplianceModel> listDesignationApplianceModel = userService.getDefaultGroupAppliances();
		return listDesignationApplianceModel;
	}
}
