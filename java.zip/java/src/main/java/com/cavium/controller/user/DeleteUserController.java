package com.cavium.controller.user;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cavium.model.user.UserDetailModel;
import com.cavium.pojo.UserAttributes;
import com.cavium.service.alerts.AlertsService;
import com.cavium.service.user.UserService;
import com.cavium.utill.CaviumConstant;
import com.cavium.utill.CaviumResponseModel;
import com.cavium.utill.CaviumUtil;

/**
 * @author RK00490847
 * 
 */
@RestController
@RequestMapping("rest")
public class DeleteUserController {

	// logger - instance of application log.
	private Logger logger = Logger.getLogger(this.getClass());

	// userService - Service class provide the interface for the Repository
	// Operation.
	@Autowired
	private UserService userService;

	@Lookup
	public CaviumResponseModel getCaviumResponseModel() {
		return null;
	}

	@Autowired
	private AlertsService alertsService;
	
	@Autowired
	private UserAttributes userAttributes;
	
	@Autowired
	private CaviumUtil caviumUtil;
	
	// for Dynamic Messages
	@Autowired
	private ResourceBundleMessageSource messageSource;
	/**
	 * This deleteUser method delete the User and return listresponseModel to the
	 * List of CaviumResponseModel Object.
	 * 
	 * @return responseModel - CaviumResponseModel Object
	 * 
	 * @param userId
	 * 
	 */
		
	@RequestMapping(value = "deleteUser", method = RequestMethod.DELETE)
	public final List<CaviumResponseModel> deleteUser(@RequestBody UserDetailModel userDetailModel) {
		logger.info("Start of deleteUser Method");
		String loggedInUser = userAttributes.getlogInUserName();
		String timezone=caviumUtil.getTimeZoneByUserName(loggedInUser);
		CaviumResponseModel responseModel = getCaviumResponseModel();
		List<CaviumResponseModel> listResponseModel = new ArrayList<CaviumResponseModel>();
		if (userDetailModel.getDeletedUserIds() != null && userDetailModel.getDeletedUserIds().size()>0) {
			Iterator<String> iterator = userDetailModel.getDeletedUserIds().iterator();
			while (iterator.hasNext()) {
				String userId = iterator.next();
				try{
				responseModel = userService.deleteUser(userId);
				}catch(Exception e)
				{
					responseModel.setResponseCode("204");
					 String message=messageSource.getMessage("userCreation.doesnot.exist", 
							new Object[] { userId }, Locale.US);
					responseModel.setResponseMessage(message);
					alertsService.createAlert(loggedInUser,"Error is coming while deleting user "+userId+" by "+loggedInUser +"",CaviumConstant.USER_MANAGEMENT);	
				}
				listResponseModel.add(responseModel);
			}
			logger.info("ResponseModel for deleteUser :: " + listResponseModel.toString());
			logger.info("End of deleteUser Method");
		}
		return listResponseModel;
	}
}
