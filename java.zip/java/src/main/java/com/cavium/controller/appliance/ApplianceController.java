package com.cavium.controller.appliance;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cavium.model.appliance.ApplianceDeleteFailureModel;
import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.appliance.DualFactorUsersRelationshipModel;
import com.cavium.model.appliance.FirmwareUpgradeDetailModel;
import com.cavium.model.appliance.InitializeApplianceDetailModel;
import com.cavium.model.partition.PartitionDetailModel;
import com.cavium.model.user.DesignationApplianceModel;
import com.cavium.pojo.MCOKeyCertificateDetails;
import com.cavium.pojo.ManageCertificatesDetails;
import com.cavium.pojo.SNMPDetails;
import com.cavium.pojo.UserAttributes;
import com.cavium.pojo.logs.LogsDetails;
import com.cavium.repository.appliance.ApplianceRepository;
import com.cavium.repository.appliance.DesignationAppliance;
import com.cavium.repository.partition.PartitionRepository;
import com.cavium.repository.user.UserGroupRepository;
import com.cavium.service.alerts.AlertsService;
import com.cavium.service.appliance.ApplianceService;
import com.cavium.service.partition.PartitionService;
import com.cavium.service.recentactivity.RecentActivityService;
import com.cavium.service.recentactivity.RecentActivityServiceImpl;
import com.cavium.utill.CaviumConstant;
import com.cavium.utill.CaviumResponseModel;
import com.cavium.utill.CaviumUtil;
import com.cavium.utill.RestClient;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.fasterxml.jackson.databind.type.TypeFactory;

/**
 * * @author MK00497144 This class handling the appliance management endpoints
 */

@RestController
@RequestMapping("rest")
public class ApplianceController {

	@Autowired
	Environment env;

	@Autowired
	private ApplianceService applianceService;

	@Autowired
	private UserAttributes userAttributes;

	@Autowired
	private PartitionService partitionService;

	@Autowired
	DesignationAppliance designationAppliance;
	@Autowired
	UserGroupRepository userGroupRepository;
	@Autowired
	private RecentActivityService recentActivityService;
	
	@Lookup
	public CaviumResponseModel getCaviumResponseModel() {
		return null;
	}

	@Autowired
	ServletContext context;

	@Autowired
	private AlertsService alertsService;

	private Logger logger = Logger.getLogger(this.getClass());

	@Autowired
	private ApplianceRepository applianceRepository;
	
	@Autowired
	private PartitionRepository partitionRepository;


	@Autowired
	RestClient restClient;



	/***
	 * This method is used to get appliance by id.
	 */
	@RequestMapping(value = "getAppliance/{applianceId}", method = RequestMethod.GET)
	public ApplianceDetailModel getApplianceById(@PathVariable("applianceId") String applianceId) {
		ApplianceDetailModel applianceDetailModels = null;
		logger.info("inside listAppliance");
		try {
			if(!StringUtils.isEmpty(applianceId)) {
				applianceDetailModels = applianceService.getApplianceById(applianceId);
			}else {
				applianceDetailModels=new ApplianceDetailModel();
				applianceDetailModels.setMessage("ApplianceID is null or empty");
			}
		} catch (Exception e) {
			logger.error("error occured during listAppliance" + e.getMessage());
		}
		return applianceDetailModels;
	}

	/**
	 * Method is used to get list of Appliances
	 * @return
	 */
	@RequestMapping(value = "listAppliance", method = RequestMethod.GET)
	public List<ApplianceDetailModel> getListOfAppliance() {
		List<ApplianceDetailModel> listApplianceDetailModels = null;
		logger.info("inside listAppliance");
		try {
			String loggedInUser = userAttributes.getlogInUserName();
			listApplianceDetailModels = applianceService.listOfApplianceByGroupId(loggedInUser);
			for(ApplianceDetailModel applianceDetailModel : listApplianceDetailModels)
			{
				DesignationApplianceModel design=designationAppliance.getDesignationModelByApplianceId(applianceDetailModel.getApplianceId());
				if(design!=null) {
					String groupName=userGroupRepository.getGroupName(design.getDesignationId());
					applianceDetailModel.setGroupName(groupName);
				}
				
				List<PartitionDetailModel> pdmList=applianceService.setPartitionDataInPartitonModel(applianceDetailModel);
				if(pdmList!=null){
					int numberOfpartitions=partitionRepository.getNumberofInprogressPartitions(applianceDetailModel.getApplianceId());
					if(numberOfpartitions==0){
					boolean grayedOut=false;
					 if(applianceDetailModel.getLastOperationPerformed()!=null && !applianceDetailModel.getLastOperationStatus().equalsIgnoreCase("In-Progress")){
						applianceRepository.updateGrayedOut(grayedOut, applianceDetailModel.getApplianceId());	
						partitionRepository.updateGrayedOut(grayedOut, applianceDetailModel.getApplianceId());	
					  }
					}					
					}
					 //applianceDetailModel.setPartitionDetailModels(pdmList);
					partitionService.setObjectsInPartitionDetailModel(pdmList);
				}			
		} catch (Exception e) {
			logger.error("error occured during listAppliance" + e.getMessage());
		}
		return listApplianceDetailModels;

	}

	/**
	 * Method is used to create new appliance
	 * @param applianceDetailModel
	 * @return
	 */

	@RequestMapping(value = "createAppliance", method = RequestMethod.POST)
	public final CaviumResponseModel createAppliance(@RequestBody List<ApplianceDetailModel> applianceDetailModel) {
		logger.info("createAppliance with the details:" + applianceDetailModel);
		CaviumResponseModel responseModel=getCaviumResponseModel();
		responseModel = applianceService.createAppliance(applianceDetailModel);
		if (responseModel.getResponseMessage() == null || responseModel.getResponseMessage().length() == 0) {
			logger.info(applianceDetailModel.toString() + " - is created successfully.");
		} else {
			logger.info(
					responseModel.toString() + " Creation Failed: Reason:" + responseModel.getResponseMessage());

		}
		return responseModel;
	}

	/**
	 * This method is used to modify the Appliance
	 * 
	 * @param applianceDetailModel
	 * @return
	 */
	@RequestMapping(value = "modifyAppliance",method = RequestMethod.PUT)
	public final CaviumResponseModel modifyAppiance(@RequestBody ApplianceDetailModel applianceDetailModel) {
		CaviumResponseModel responseModel=getCaviumResponseModel();
		try {		
			logger.info("Inside modifyAppiance method of class ApplianceController.");
			String loggedInUser = userAttributes.getlogInUserName();

			if (applianceDetailModel != null) {
				responseModel = applianceService.modifyAppliance(loggedInUser, applianceDetailModel);
			} else {
				logger.error(env.getProperty("applianceModification.failureEmpty"));
				responseModel.setResponseCode("204");
				responseModel.setResponseMessage(env.getProperty("applianceModification.failureEmpty"));
			}
		} catch (Exception e) {
			logger.error("Error occured due to" + e.getMessage());
			// TODO: handle exception
		}
		logger.info("End of modifyAppiance method");
		return responseModel;
	}

	/**
	 * Method is used to delete the particular appliance
	 * @param applianceId
	 * @return
	 */
	@RequestMapping(value = "deleteAppliances", method = RequestMethod.DELETE)
	public final List<ApplianceDetailModel> deleteAppliances(@RequestBody List<ApplianceDetailModel> listApplianceDetailModels) {
		logger.info("Start of deleteAppliance Method");
		CaviumResponseModel	caviumResponseModel=new CaviumResponseModel();
		List<ApplianceDetailModel> responseList=new ArrayList<>();
		for (ApplianceDetailModel app :  listApplianceDetailModels) {
			try{
				caviumResponseModel = applianceService.deleteAppliances(app);
				app.setMessage(caviumResponseModel.getResponseMessage());
				app.setCode(caviumResponseModel.getResponseCode());
				responseList.add(app);
			}catch (Exception e) {
				app.setCode("500");
				app.setErrorMessage(env.getProperty("applianceDeletion.failureDB"));
				responseList.add(app);
				logger.error("Error ocuured during delete applaince inside deleteAppliances method"+e.getMessage());
			}
		}
		logger.info("End of deleteAppliance Method");
		return responseList;
	}

	/**
	 * Method is used to create new appliance
	 * @param applianceDetailModel
	 * @return
	 */
	@RequestMapping(value = "validateAppliance", method = RequestMethod.POST)
	public final ApplianceDetailModel validateAppliance(@RequestBody ApplianceDetailModel applianceDetailModel) {
		logger.info("validateAppliance with the details:" + applianceDetailModel); 
		if(applianceDetailModel!=null) {
			applianceDetailModel = applianceService.validateAppliance(applianceDetailModel);
		}
		return applianceDetailModel;
	}


	@RequestMapping(value = "rebootAppliance", method = RequestMethod.POST)
	public final List<ApplianceDetailModel> rebootAppliance(@RequestBody List<ApplianceDetailModel>  applianceDetailModellist) {
		logger.info("Rebooting appliance with the details:" + applianceDetailModellist);
		List<ApplianceDetailModel> responseList=new ArrayList<>();
		String loggedInUser = userAttributes.getlogInUserName();

		if(applianceDetailModellist!=null) {
			ExecutorService executorService = Executors.newFixedThreadPool(50);
			for(ApplianceDetailModel app:applianceDetailModellist) {
				try {
					executorService.execute(new Runnable() {
					    public void run() {
					    	applianceService.rebootAppliance(app,loggedInUser);
					    }
					});
					
					ApplianceDetailModel dbAppliance = applianceRepository.findOne(app.getApplianceId());
					dbAppliance.setLastOperationPerformed(env.getProperty("appliance.reboot"));
					dbAppliance.setLastOperationStatus("In-Progress");
					dbAppliance.setApplianceinitialized(app.isApplianceinitialized());
					dbAppliance.setCode("200");
					dbAppliance.setMessage(env.getProperty("appliance.reboot.success"));
					dbAppliance.setErrorMessage("");
					applianceRepository.save(dbAppliance);
					Long applianceId=app.getApplianceId();
					//applianceRepository.maintainLastOperationStatus(applianceId);
					//partitionRepository.maintainLastOperationStatus(applianceId);
				//	partitionRepository.updateLastOperationStatusToInProgress(applianceId);
					boolean grayedOut=true;
					partitionRepository.updateGrayedOut(grayedOut, applianceId);				 
					responseList.add(dbAppliance);
				
				} catch (Exception e) {
					// TODO: handle exception
					logger.error("Error occured during reboot..");
				}
			}
			executorService.shutdown();
		}
		return responseList;
	}


	@RequestMapping(value = "zeroizeAppliance", method = RequestMethod.POST)
	public final List<ApplianceDetailModel> zeroizeAppliance(@RequestBody List<ApplianceDetailModel> applianceDetailModellist) {
		logger.info("Zeroize appliance with the details:" + applianceDetailModellist);
		List<ApplianceDetailModel> responseList=new ArrayList<>();
		String loggedInUser = userAttributes.getlogInUserName();
		if(applianceDetailModellist!=null && applianceDetailModellist.size() > 0) {
			try {
				ExecutorService executorService = Executors.newFixedThreadPool(50);
				for(ApplianceDetailModel app: applianceDetailModellist) {
					ApplianceDetailModel dbAppliance = applianceRepository.findOne(app.getApplianceId());
					if(dbAppliance!=null && dbAppliance.getApplianceId()!=0) {
						executorService.execute(new Runnable() {
						    public void run() {
						    	applianceService.zeroizeAppliance(loggedInUser,app);
						    }
						});
						dbAppliance.setLastOperationPerformed(env.getProperty("appliance.zeroize"));
						dbAppliance.setLastOperationStatus("In-Progress");
						dbAppliance.setApplianceinitialized(app.isApplianceinitialized());
						dbAppliance.setCode("200");
						dbAppliance.setMessage("Zeroize initiated successfully.");
						dbAppliance.setErrorMessage("");
						applianceRepository.save(dbAppliance);
						Long applianceId=app.getApplianceId();
						boolean grayedOut=true;
						partitionRepository.updateGrayedOut(grayedOut, applianceId);				 
						responseList.add(dbAppliance);
					}else {
						dbAppliance.setCode("405");
						dbAppliance.setMessage("");
						dbAppliance.setErrorMessage("Appliance does not exists.");
						applianceRepository.save(dbAppliance);
						responseList.add(dbAppliance);
						boolean grayedOut=false;
						Long applianceId=app.getApplianceId();
						partitionRepository.updateGrayedOut(grayedOut, applianceId);	
						responseList.add(dbAppliance);
					}
				}
				executorService.shutdown();
			} catch (Exception e) {
				// TODO: handle exception
				logger.error("Error occured during zeroize in method zeroizeAppliance.");
			}
		}
		return responseList;
	}

	/*
	 * Purpose of this method is when we have one InitializeApplianceDetailModel object with multiple Appliance Object  
	 */
	/*@RequestMapping(value = "initilizeAppliance", method = RequestMethod.POST)
	public final List<ApplianceDetailModel> initilizeAppliance(@RequestBody InitializeApplianceDetailModel initializeApplianceDetailModel) {
		logger.info("Start of initilizeAppliance Method");
		List<ApplianceDetailModel> applianceDetailModels=null;
		String message="";
		try{
			if(initializeApplianceDetailModel!=null) {
				applianceDetailModels = applianceService.initilizeAppliance(initializeApplianceDetailModel);
			}
		}	 
		catch (RuntimeException e) {
			logger.error("error in Initilize Applaince :" + e.getMessage());
			if("CaviumNetworkError".equals(e.getMessage())){
				message="CaviumNetworkError" ;
			}

		}
		if(applianceDetailModels==null){
			if(initializeApplianceDetailModel.getApplianceDetailModels()!=null && initializeApplianceDetailModel.getApplianceDetailModels().size()>0){
				applianceDetailModels= new ArrayList<ApplianceDetailModel>();
				for (Iterator<ApplianceDetailModel> iterator = initializeApplianceDetailModel.getApplianceDetailModels().iterator(); iterator.hasNext();) {
					ApplianceDetailModel applianceDetailModel = (ApplianceDetailModel) iterator.next();
					if("CaviumNetworkError".equals(message)){
						applianceDetailModel.setMessage("cavium network is not approachable for appliance "+applianceDetailModel.getApplianceName());
					 }else{
						 applianceDetailModel.setMessage("Error came while performing DB operation on appliance "+ applianceDetailModel.getApplianceName());
					 }
					applianceDetailModels.add(applianceDetailModel);
				}
			}	 
		}
		return applianceDetailModels;
	}*/

	@RequestMapping(value = "initilizeAppliance", method = RequestMethod.POST)
	public final List<ApplianceDetailModel> initilizeAppliance(@RequestBody List<InitializeApplianceDetailModel> initializeApplianceDetailModels) {
		logger.info("Start of initilizeAppliance Method");
		
		List<ApplianceDetailModel> listapplianceDetailModels=new ArrayList<ApplianceDetailModel>();
		String loggedInUser = userAttributes.getlogInUserName();
		if(initializeApplianceDetailModels!=null && initializeApplianceDetailModels.size()>0) {
			ExecutorService executorService = Executors.newFixedThreadPool(50);
			for (InitializeApplianceDetailModel initModel: initializeApplianceDetailModels) {
				executorService.execute(new Runnable() {
				    public void run() {
				    	applianceService.applianceInitialize(loggedInUser,initModel);
				    }
				});
				if(initModel!=null && initModel.getApplianceDetailModels()!=null && initModel.getApplianceDetailModels().size() > 0) {
					ApplianceDetailModel app=(ApplianceDetailModel)initModel.getApplianceDetailModels().get(0);
					ApplianceDetailModel dbAppliance=applianceRepository.findOne(app.getApplianceId());
					dbAppliance.setLastOperationPerformed(env.getProperty("appliance.initialize"));
					dbAppliance.setLastOperationStatus("In-Progress");
					dbAppliance.setCode("200");
					dbAppliance.setMessage("Appliance initialize initiated successfully.");
					dbAppliance.setApplianceinitialized(true);
					applianceRepository.save(dbAppliance);
					applianceRepository.updateGrayedOut(true, dbAppliance.getApplianceId());
					partitionRepository.updateGrayedOut(true, dbAppliance.getApplianceId());
					listapplianceDetailModels.add(dbAppliance);
				}
			}
		}
		return listapplianceDetailModels;
	}

	/**
	 * Method is used to get list of Appliances
	 * @return
	 */
	@RequestMapping(value = "searchAppliance", method = RequestMethod.POST)
	public List<ApplianceDetailModel> searchAppliance(@RequestBody ApplianceDetailModel applianceDetailModel) {
		List<ApplianceDetailModel> listApplianceDetailModels = null;
		logger.info("inside listAppliance");
		try {
			listApplianceDetailModels = applianceService.searchAppliance(applianceDetailModel);
		} catch (Exception e) {
			logger.error("error occured during listAppliance" + e.getMessage());
		}
		return listApplianceDetailModels;
	}

	/**
	 * Method is used to get listOfTempAppliances
	 * @param 
	 * @return
	 */

	@RequestMapping(value = "listOfTempAppliances", method = RequestMethod.GET)
	public final List<ApplianceDetailModel> listOfTempAppliances() {
		List<ApplianceDetailModel> applianceTempModel=null;
		logger.info("Geting list of temproary appliances");
		try {
			applianceTempModel = applianceService.getListOfTempAppliances();

		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Error occured during listOfTempAppliances");
		}
		return applianceTempModel;
	}

	@RequestMapping(value = "createApplianceForTesting", method = RequestMethod.POST)
	public final CaviumResponseModel createApplianceForTesting(@RequestBody List<ApplianceDetailModel> applianceDetailModel) {
		logger.info("createApplianceForTesting with the details:" + applianceDetailModel);
		CaviumResponseModel responseModel=getCaviumResponseModel();
		responseModel = applianceService.createApplianceForTesting(applianceDetailModel);
		if (responseModel.getResponseMessage() == null || responseModel.getResponseMessage().length() == 0) {
			logger.info(applianceDetailModel.toString() + " - is created successfully.");
		} else {
			logger.info(
					responseModel.toString() + " Creation Failed: Reason:" + responseModel.getResponseMessage());

		}
		return responseModel;
	}

	@RequestMapping(value = "downloadCertificate", method = RequestMethod.POST)
	public final void downloadCertificate(@RequestBody ManageCertificatesDetails manageCertificatesDetails,HttpServletResponse response ) {
		logger.info(" Start of downloadCertificate method of ApplianceController");
		String certificateType=manageCertificatesDetails.getCertificateType();
		String applianceIp=manageCertificatesDetails.getApplianceIp();
		CaviumResponseModel responseModel=getCaviumResponseModel();
		String loggedInUser = userAttributes.getlogInUserName();
		responseModel = applianceService.getCertificateURL(certificateType,applianceIp);
		File file=null;
		if(responseModel!=null && "200".equals(responseModel.getResponseCode())){
			try{
				file=applianceService.downloadFileFromURL(responseModel.getResponseMessage(),manageCertificatesDetails.getApplianceName());
				if(file==null){
					List<ApplianceDetailModel> applianceDetailmodels=applianceRepository.getApplianceExists(applianceIp);
					if(applianceDetailmodels.size() == 1 ) {	
					ApplianceDetailModel dbAppliance=applianceDetailmodels.get(0);
					try{
						alertsService.createAlert(loggedInUser,"Download file performed on device "+dbAppliance.getApplianceName()+" by "+loggedInUser+" did not complete due to some error.",dbAppliance.getApplianceName(),dbAppliance.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);						
						response.setContentType("text/html"); 
						PrintWriter pw = response.getWriter(); 
						pw.write("Some error is coming . Failed to download file"); 
						pw.close();
						
					}
					catch (Exception e) {
						alertsService.createAlert(loggedInUser,"Download file performed on device "+dbAppliance.getApplianceName()+" by "+loggedInUser+" did not complete due to some error.",dbAppliance.getApplianceName(),dbAppliance.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
						logger.error("Some error is coming . Failed to download file in downloadCertificate method of Appliance controller :: " + e.getMessage()); 
					}
				}
				}else{
				String  mimeType = "application/octet-stream";
				// Content-Type
				// application/pdf
				response.setContentType(mimeType);

				// Content-Disposition
				response.setHeader(HttpHeaders.CONTENT_DISPOSITION,"attachment;filename="+file.getName());

				// Content-Length
				response.setContentLength((int) file.length());

				BufferedInputStream inStream = new BufferedInputStream(new FileInputStream(file));
				BufferedOutputStream outStream = new BufferedOutputStream(response.getOutputStream());
				String certificateName="";
				if("export_cavium_certificate".equalsIgnoreCase(certificateType)){
					certificateName="Cavium Root certificate";
				}
				if("export_hsm_certificate".equalsIgnoreCase(certificateType)){
					certificateName="HSM Certificate signed by root";
				}
				if("export_hsm_csr".equalsIgnoreCase(certificateType)){
					certificateName="HSM Certificate signing request";
				}
				if("export_hsm_owner_certificate".equalsIgnoreCase(certificateType)){
					certificateName="HSM Owner Certificate";
				}
				if("export_hsm_owner_signed_certificate".equalsIgnoreCase(certificateType)){
					certificateName="HSM Owner Signed HSM certificate";
				}
				if("export_appliance_certificate".equalsIgnoreCase(certificateType)){
					certificateName="Appliance Certificate";
				}
				recentActivityService.createRecentActivity(loggedInUser,certificateName +" sucessfully downloaded by " +loggedInUser,CaviumConstant.APPLIANCE_MANAGEMENT);
				byte[] buffer = new byte[1024];
				int bytesRead = 0;
				while ((bytesRead = inStream.read(buffer)) != -1) {
					outStream.write(buffer, 0, bytesRead);
				}
				outStream.flush();
				inStream.close();
				}
			}
			catch (IOException e) {
				logger.error("error coming while download the certificate in downloadCertificate method of Appliance controller :: "+e.getMessage());
			}
			finally {
				if(file!=null){
					try{
						Files.deleteIfExists(Paths.get(file.getAbsolutePath()));
					}catch (Exception e) {
						logger.error("Error while deleting certificate file  in downloadCertificate method of Appliance controller :: " + e.getMessage()); 
					}
				}
			}     		
		}
		if(responseModel!=null && !StringUtils.isEmpty(responseModel.getResponseCode()) && !"200".equals(responseModel.getResponseCode())){
			try{
				response.setContentType("text/html"); 
				PrintWriter pw = response.getWriter(); 
				pw.write(responseModel.getResponseMessage()); 
				pw.close();
			}
			catch (Exception e) {
				logger.error("Error coming while writing error message to response in downloadCertificate method of Appliance controller :: " + e.getMessage()); 
			}
		}else {
			try{
				response.setContentType("text/html"); 
				PrintWriter pw = response.getWriter(); 
				pw.write("No error message available"); 
				pw.close();
			}
			catch (Exception e) {
				logger.error("Error coming while writing error message to response in downloadCertificate method of Appliance controller :: " + e.getMessage()); 
			}
		}
		logger.info("End of downloadCertificate method of ApplianceController");
	}	 
	@RequestMapping(value = "uploadCertificates", method = RequestMethod.POST)
	public final CaviumResponseModel uploadCertificates(@RequestBody ManageCertificatesDetails manageCertificatesDetails ) {
		logger.info(" Start of uploadCertificates method of ApplianceController");		
		CaviumResponseModel responseModel=getCaviumResponseModel();
		responseModel = applianceService.uploadCertificate(manageCertificatesDetails);
		logger.info("End of uploadCertificates method of ApplianceController");
		return responseModel;
	}


	@RequestMapping(value = "downloadlogsDetails", method = RequestMethod.POST)
	public final void downloadlogsDetails(@RequestBody LogsDetails logsDetail,HttpServletResponse response ) {
		logger.info(" Start of downloadlogsDetails method of ApplianceController");		
		String loggedInUser = userAttributes.getlogInUserName();
		CaviumResponseModel responseModel=getCaviumResponseModel();

		responseModel = applianceService.getDownloadlogsURL(logsDetail);
		File file=null;
		if(responseModel!=null && "200".equals(responseModel.getResponseCode())){
			try{
				file=applianceService.downloadFileFromURL(responseModel.getResponseMessage(),logsDetail.getApplianceName()+"_log");
			 if(file==null){
					List<ApplianceDetailModel> applianceDetailmodels=applianceRepository.getApplianceExists(logsDetail.getApplianceIp());
					if(applianceDetailmodels.size() == 1 ) {	
					ApplianceDetailModel dbAppliance=applianceDetailmodels.get(0);
					try{
						alertsService.createAlert(loggedInUser,"Download SecurityLog file performed on device "+dbAppliance.getApplianceName()+" by "+loggedInUser+" did not complete due to some error.",dbAppliance.getApplianceName(),dbAppliance.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);						
						response.setContentType("text/html"); 
						PrintWriter pw = response.getWriter(); 
						pw.write("Some error is coming . Failed to download file"); 
						pw.close();
						
					}
					catch (Exception e) {
						alertsService.createAlert(loggedInUser,"Download SecurityLog file performed on device "+dbAppliance.getApplianceName()+" by "+loggedInUser+" did not complete due to some error.",dbAppliance.getApplianceName(),dbAppliance.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
						logger.error("Some error is coming . Failed to download SecurityLog file in downloadlogsDetails method of Appliance controller :: " + e.getMessage()); 
					}
				}
				}
				else{
				String  mimeType = "application/octet-stream";
				// Content-Type
				// application/pdf
				response.setContentType(mimeType);

				// Content-Disposition
				response.setHeader(HttpHeaders.CONTENT_DISPOSITION,"attachment;filename=" +file.getName());

				// Content-Length
				response.setContentLength((int) file.length());

				BufferedInputStream inStream = new BufferedInputStream(new FileInputStream(file));
				BufferedOutputStream outStream = new BufferedOutputStream(response.getOutputStream());
				recentActivityService.createRecentActivity(loggedInUser, "Security Logs downloaded sucessfully by " +loggedInUser,CaviumConstant.APPLIANCE_MANAGEMENT);
				byte[] buffer = new byte[1024];
				int bytesRead = 0;
				while ((bytesRead = inStream.read(buffer)) != -1) {
					outStream.write(buffer, 0, bytesRead);
				}
				outStream.flush();
				inStream.close();
				}
			} catch (IOException e) {
				logger.error("error coming while download the log file in downloadlogsDetails method of Appliance controller :: "+e.getMessage());
			}
			finally {
				if(file==null){
					try{
						response.setContentType("text/html"); 
						PrintWriter pw = response.getWriter(); 
						pw.write("Some error is coming . Failed to download file"); 
						pw.close();
					}
					catch (Exception e) {
						logger.error("Some error is coming . Failed to download file in downloadlogsDetails method of Appliance controller :: " + e.getMessage()); 
					}
				}
				if(file!=null){
					try{
						Files.deleteIfExists(Paths.get(file.getAbsolutePath()));
					}catch (Exception e) {
						logger.error("Error while deleting log file  in downloadlogsDetails method of Appliance controller :: " + e.getMessage()); 
					}
				}
			}  

			if(responseModel!=null && "409".equals(responseModel.getResponseCode())){
				try{
					response.setContentType("text/html"); 
					PrintWriter pw = response.getWriter(); 
					pw.write(responseModel.getResponseMessage()); 
					pw.close();
				}
				catch (Exception e) {
					logger.error("Error coming while writing error message to response in downloadlogsDetails method of Appliance controller :: " + e.getMessage()); 
				}
			}	
		}else{ 
			try{
					response.setContentType("text/html"); 
					PrintWriter pw = response.getWriter(); 
					pw.write("Some error is coming . Failed to download file"); 
					pw.close();
				}
				catch (Exception e) {
					logger.error("Error coming while writing error message to response in downloadlogsDetails method of Appliance controller :: " + e.getMessage()); 
				}
			}
		
		logger.info("End of downloadlogsDetails method of ApplianceController");

	}

	@RequestMapping(value = "deleteLogs", method = RequestMethod.POST)
	public final CaviumResponseModel deleteLogs(@RequestBody LogsDetails logsDetail) {
		logger.info(" Start of deleteLogs method of ApplianceController");		
		CaviumResponseModel responseModel=getCaviumResponseModel();	 
		responseModel = applianceService.deleteAppliancelogs(logsDetail);		
		logger.info("End of deleteLogs method of ApplianceController");
		return responseModel;
	}


	@RequestMapping(value = "getConfiguredLoggerType", method = RequestMethod.POST)
	public final CaviumResponseModel getConfiguredLoggerType(@RequestBody LogsDetails logsDetail) {
		logger.info(" Start of getConfigureLogs method of ApplianceController");		
		CaviumResponseModel responseModel=getCaviumResponseModel();	 
		responseModel = applianceService.getAlreadyConfiguredLoggerType(logsDetail);		
		logger.info("End of getConfigureLogs method of ApplianceController");
		return responseModel;
	}

	@RequestMapping(value = "updateConfiguredLoggerType", method = RequestMethod.POST)
	public final CaviumResponseModel updateConfiguredLoggerType(@RequestBody LogsDetails logsDetail) {
		logger.info(" Start of getConfigureLogs method of ApplianceController");		
		CaviumResponseModel responseModel=getCaviumResponseModel();	 
		responseModel = applianceService.updateConfigureLoggerType(logsDetail);		
		logger.info("End of getConfigureLogs method of ApplianceController");
		return responseModel;
	}

	/**
	 * Method is used to get list of Appliances
	 * @return
	 */
	@RequestMapping(value = "validateCredentialsByLoginHSM", method = RequestMethod.POST)
	public List<ApplianceDetailModel> validateCredentialsByLoginHSM(@RequestBody List<ApplianceDetailModel>  listApplianceDetailModels) {
		logger.info("inside validateCredentialsByLoginHSM");
		try {
			listApplianceDetailModels=applianceService.validateCredentialsByLoginHSM(listApplianceDetailModels);
		} catch (Exception e) {
			logger.error("error occured during validateCredentialsByLoginHSM" + e.getMessage());
		}
		return listApplianceDetailModels;

	}


	/**
	 * This method is use to get the partition resize initial data
	 * @param partitionDetailModel
	 * @return
	 */
	@RequestMapping(value = "setApplianceMonitorData", method = RequestMethod.POST)
	public List<ApplianceDetailModel> setApplianceMonitorData(@RequestBody List<ApplianceDetailModel>  listApplianceDetailModels) {
		// TODO Auto-generated method stub
		try {
			listApplianceDetailModels=applianceService.setMonitorData(listApplianceDetailModels);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getPartitionInfoForResize method of PartitionController class"+e.getMessage());
		}
		return listApplianceDetailModels;
	}


	/**
	 * This method is use to get the partition resize initial data
	 * @param partitionDetailModel
	 * @return
	 */
	@RequestMapping(value = "getApplianceMonitorData", method = RequestMethod.POST)
	public  List<ApplianceDetailModel> getApplianceMonitorData(@RequestBody List<ApplianceDetailModel>  listApplianceDetailModels) {
		// TODO Auto-generated method stub
		try {
			listApplianceDetailModels=applianceService.getMonitorData(listApplianceDetailModels);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getPartitionMonitorStats method of PartitionController class"+e.getMessage());
		}
		return listApplianceDetailModels;
	}

	/**
	 * This method is use to get the partition resize initial data
	 * @param partitionDetailModel
	 * @return
	 */
	@RequestMapping(value = "getApplianceMonitorStats", method = RequestMethod.POST)
	public List<ApplianceDetailModel> getApplianceMonitorStats(@RequestBody List<ApplianceDetailModel>  listApplianceDetailModels) {
		// TODO Auto-generated method stub
		try {
			listApplianceDetailModels=applianceService.getApplianceMonitorStats(listApplianceDetailModels);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getPartitionInfoForResize method of PartitionController class"+e.getMessage());
		}
		return listApplianceDetailModels;
	}

	/**
	 * This method is use to get the partition resize initial data
	 * @param partitionDetailModel
	 * @return
	 */
	@RequestMapping(value = "changeAppliancePassword", method = RequestMethod.POST)
	public ApplianceDetailModel changeAppliancePassword(@RequestBody ApplianceDetailModel  listApplianceDetailModel) {
		// TODO Auto-generated method stub
		try {
			listApplianceDetailModel=applianceService.changeAppliancePassword(listApplianceDetailModel);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getPartitionInfoForResize method of PartitionController class"+e.getMessage());
		}
		return listApplianceDetailModel;
	}

	@RequestMapping(value = "downloadMonitorLogsFile", method = RequestMethod.POST)
	public final void downloadMonitorLogsFile(@RequestBody ApplianceDetailModel applianceDetailModel,HttpServletResponse response){
		try { 
			String url="";
			String name="";
			CaviumResponseModel responseModel=getCaviumResponseModel();
			if(applianceDetailModel.getPartitionDetailModels()!=null && !StringUtils.isEmpty(applianceDetailModel.getMonitorType()) && applianceDetailModel.getMonitorType().equalsIgnoreCase("partition")) {
				List<PartitionDetailModel> partlist=applianceDetailModel.getPartitionDetailModels();
				for(PartitionDetailModel pdm: partlist) {
					url="https://"+applianceDetailModel.getIpAddress()+"/liquidsa/download_monitor_logs/"+applianceDetailModel.getMonitorType()+"/"+pdm.getPartitionName()+"";
					name=pdm.getPartitionName();
				}
			}else {
				url="https://"+applianceDetailModel.getIpAddress()+"/liquidsa/download_monitor_logs/"+applianceDetailModel.getMonitorType()+"";
				name=applianceDetailModel.getApplianceName();
			}
			responseModel = applianceService.downloadMonitorLogsURL(url, applianceDetailModel);
			logger.info(" Start of downloadMonitorLogsFile method of ApplianceController");
			File file=null;
			try{
				if(!StringUtils.isEmpty(responseModel.getResponseMessage())) {
					file=applianceService.downloadMonitorFile(responseModel.getResponseMessage(),name);
					if(file!=null) {
						String  mimeType = "application/octet-stream";
						// Content-Type
						// application/pdf
						response.setContentType(mimeType);

						// Content-Disposition
						response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + file.getName());

						// Content-Length
						response.setContentLength((int) file.length());

						BufferedInputStream inStream = new BufferedInputStream(new FileInputStream(file));
						BufferedOutputStream outStream = new BufferedOutputStream(response.getOutputStream());

						byte[] buffer = new byte[1024];
						int bytesRead = 0;
						while ((bytesRead = inStream.read(buffer)) != -1) {
							outStream.write(buffer, 0, bytesRead);
						}
						outStream.flush();
						inStream.close();
					}else {
						response.setContentType("text/html"); 
						PrintWriter pw = response.getWriter(); 
						pw.write("Error occured during download file"); 
						pw.close();
					}
				}else {
					response.setContentType("text/html"); 
					PrintWriter pw = response.getWriter(); 
					pw.write("Error occured during download file"); 
					pw.close();
				}
			} catch (IOException e) {
				logger.error("error coming while download the certificate in downloadMonitorLogsFile method of ApplianceController :: "+e.getMessage());
			}
			finally {
				if(file!=null){
					try{
						Files.deleteIfExists(Paths.get(file.getAbsolutePath()));
					}catch (Exception e) {
						logger.error("Error while deleting certificate file  in downloadMonitorLogsFile method of ApplianceController :: " + e.getMessage()); 
					}
				}
			}     		
			if(responseModel!=null && "409".equals(responseModel.getResponseCode())){
				try{
					response.setContentType("text/html"); 
					PrintWriter pw = response.getWriter(); 
					pw.write("Error occured during download file"); 
					pw.close();
				}
				catch (Exception e) {
					logger.error("Error coming while writing error message to response in downloadMonitorLogsFile method of ApplianceController :: " + e.getMessage()); 
				}
			}
			logger.info("End of downloadMonitorLogsFile method of ApplianceController");
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during download file.");
		}
	}

	/**
	 * This method is use to get the partition resize initial data
	 * @param partitionDetailModel
	 * @return
	 */
	@RequestMapping(value = "getSelfReportData", method = RequestMethod.POST)
	public  CaviumResponseModel getSelfReportData(@RequestBody ApplianceDetailModel  applianceDetailModel) {
		// TODO Auto-generated method stub
		CaviumResponseModel caviumResponseModel=null;
		try {
			caviumResponseModel=applianceService.getSelfReportData(applianceDetailModel);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getPartitionMonitorStats method of PartitionController class"+e.getMessage());
		}
		return caviumResponseModel;
	}

	@RequestMapping(value = "getSNMPInfo", method = RequestMethod.POST)
	public  SNMPDetails getSNMPInfo(@RequestBody SNMPDetails  snmpDetails) {
		// TODO Auto-generated method stub
		try {
			snmpDetails=applianceService.getSNMPInfo(snmpDetails);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getPartitionMonitorStats method of PartitionController class"+e.getMessage());
		}
		return snmpDetails;
	}

	@RequestMapping(value = "setSNMPInfo", method = RequestMethod.POST)
	public  SNMPDetails setSNMPInfo(@RequestBody SNMPDetails  SNMPDetails) {
		// TODO Auto-generated method stub
		try {
			SNMPDetails=applianceService.setSNMPInfo(SNMPDetails);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getPartitionMonitorStats method of PartitionController class"+e.getMessage());
		}
		return SNMPDetails;
	}


	@RequestMapping(value = "uploadMCOKeyCertificate", method = RequestMethod.POST,consumes = {"multipart/form-data"})
	public final CaviumResponseModel uploadMCOKeyCertificate(@RequestPart("mcoKeyCertificate") MultipartFile mcoKeyCertificate,String details ) {
		logger.info(" Start of uploadMCOKeyCertificate method of ApplianceController class");		
		CaviumResponseModel responseModel=getCaviumResponseModel();
		File convMCOKeyKeyCertificate=null;
		try{
			MCOKeyCertificateDetails mcoKeyCertificateDetails = new ObjectMapper().readValue(details, MCOKeyCertificateDetails.class);
			convMCOKeyKeyCertificate=CaviumUtil.convertMultipartFileIntoNewFile(mcoKeyCertificate);
			if(convMCOKeyKeyCertificate!=null){
				responseModel = applianceService.uploadMCOKeyCertificate(mcoKeyCertificateDetails,convMCOKeyKeyCertificate,null);
			}else{
				responseModel.setResponseMessage("uploaded file is not correct");
				responseModel.setResponseCode("409");
			}
		}catch (Exception e) {
			responseModel.setResponseMessage("uploaded file is not correct");
			responseModel.setResponseCode("409");
		}finally {
			if(convMCOKeyKeyCertificate!=null && convMCOKeyKeyCertificate.exists()) {
				convMCOKeyKeyCertificate.delete();
			}
		}

		logger.info("End of uploadMCOKeyCertificate method of ApplianceController class");
		return responseModel;
	}
	/**
	 * Method is used to get list of Appliances
	 * @return
	 */
	@RequestMapping(value = "validateDeleteAppliance", method = RequestMethod.POST)
	public ApplianceDeleteFailureModel validateDeleteAppliance(@RequestBody List<ApplianceDetailModel>  listApplianceDetailModels) {
		ApplianceDeleteFailureModel applianceDeleteFailureModel=new ApplianceDeleteFailureModel();
		logger.info("inside validateCredentialsByLoginHSM");
		try {
			applianceDeleteFailureModel=applianceService.validateDeleteAppliance(listApplianceDetailModels);
		} catch (Exception e) {
			logger.error("error occured during validateCredentialsByLoginHSM" + e.getMessage());
		}
		return applianceDeleteFailureModel;
	}


	/**
	 * Method is used to delete the Temporary appliance
	 * @param ApplianceDetailModel 
	 * @return
	 */
	@RequestMapping(value = "deleteTemporaryAppliances", method = RequestMethod.DELETE)
	public final List<CaviumResponseModel> deleteTemporaryAppliances(@RequestBody List<ApplianceDetailModel> listApplianceDetailModels) {
		logger.info("Start of deleteAppliance Method");
		List<CaviumResponseModel>caviumResponseModels= new ArrayList<CaviumResponseModel>();
		CaviumResponseModel	caviumResponseModel=null;
		for (ApplianceDetailModel app :  listApplianceDetailModels) {
			caviumResponseModel = applianceService.deleteTemporaryAppliance(app);
			if(caviumResponseModel!=null){
				caviumResponseModels.add(caviumResponseModel);
			}
		}
		logger.info("End of deleteAppliance Method");
		return caviumResponseModels;
	}
	
	@RequestMapping(value = "applianceFirmwareUpgrade", method = RequestMethod.POST,consumes = {"multipart/form-data"})
	public List<ApplianceDetailModel> applianceFirmwareUpgrade(@RequestPart("appliances") String appliance, @RequestPart("sign") MultipartFile signFile,@RequestPart("image") MultipartFile imageFile)
	{
		String loggedInUser = userAttributes.getlogInUserName();
		List<ApplianceDetailModel> responseList=new ArrayList<>();
		try {
				if(!StringUtils.isEmpty(appliance)) {
					if(!signFile.isEmpty() && !imageFile.isEmpty()) {
						File signFileConvertedFile = CaviumUtil.convertMultipartFileIntoNewFile(signFile);
						File imageFileConvertedFile = CaviumUtil.convertMultipartFileIntoNewFile(imageFile);
						
						ObjectMapper mapper=new ObjectMapper();
						TypeFactory typeFactory = mapper.getTypeFactory();
						CollectionType collectionType = typeFactory.constructCollectionType(
								List.class, FirmwareUpgradeDetailModel.class);
						List<FirmwareUpgradeDetailModel> usersList =  mapper.readValue(appliance, collectionType);   
						ExecutorService executorService = Executors.newFixedThreadPool(10);
						for(FirmwareUpgradeDetailModel list: usersList) {
							try {
								Integer id = list.getApplianceId();
								Long appId = new Long(id);
								ApplianceDetailModel app=new ApplianceDetailModel();
								app.setApplianceId(appId);
								app.setOperationUsername(list.getUsername());
								app.setOperationPassword(list.getPassword());
								app.setForceReboot(list.getForceReboot());
								app.setFirmwareUpgradeDetailModel(list);
								/**
								 * Call parallel processing
								 */
								executorService.execute(new Runnable() {
								    public void run() {
								    	applianceService.doApplianceFirmwareUpgrade(app, imageFileConvertedFile, signFileConvertedFile,loggedInUser);
								    }
								});
								
								/**
								 * Update appliance detail model for firmware upgrade
								 */
								ApplianceDetailModel dbAppliance=applianceRepository.findOne(app.getApplianceId());
								dbAppliance.setLastOperationPerformed("FirmwareUpgrade");
								dbAppliance.setLastOperationStatus("In-Progress");
								Long applianceId=app.getApplianceId();
								boolean grayedOut=true;
								partitionRepository.updateGrayedOut(grayedOut, applianceId);	
								dbAppliance.setCode("200");
								dbAppliance.setMessage("success");
								dbAppliance.setErrorMessage("");
								applianceRepository.save(dbAppliance);
								dbAppliance.setMessage("Firmware Upgrade operation initiated successfully");
								responseList.add(dbAppliance);
							
							} catch (Exception e) {
								// TODO: handle exception
								logger.error("Error occured during fw");
							}
						}
					}else {
						ApplianceDetailModel dbAppliance=new ApplianceDetailModel();
						dbAppliance.setLastOperationPerformed("FirmwareUpgrade");
						dbAppliance.setLastOperationStatus("Completed");
						dbAppliance.setCode("400");
						dbAppliance.setMessage("Failed");
						dbAppliance.setErrorMessage("Firmware failed due to file creation..");
						dbAppliance.setMessage("");
						responseList.add(dbAppliance);
					}
				}
		} catch (Exception e) {
			logger.error("Error occured during applianceFirmwareUpgrade in ApplinaceController :: "+e.getMessage());
		}
		return responseList;
	}
	
	/*
	@RequestMapping(value = "dualFactorDetails", method = RequestMethod.POST)
	public final List<CaviumResponseModel> dualFactorDetails(@RequestBody List<InitializeApplianceDetailModel> initializeApplianceDetailModels) {
		logger.info("Start of dualFactorDetails Method");
		List<CaviumResponseModel> listCaviumResponseModel=new ArrayList<CaviumResponseModel>();
		InitializeApplianceDetailModel initializeApplianceDetailModel =null;
		if(initializeApplianceDetailModels!=null && initializeApplianceDetailModels.size()>0) {

			for (Iterator<InitializeApplianceDetailModel> iterator = initializeApplianceDetailModels.iterator(); iterator.hasNext();) {
				initializeApplianceDetailModel = (InitializeApplianceDetailModel) iterator.next();
				synchronized (initializeApplianceDetailModel) {
					try{
						CaviumResponseModel responseModel=getCaviumResponseModel();
						responseModel = applianceService.updateDualfactorDetails(initializeApplianceDetailModel);
						listCaviumResponseModel.add(responseModel);
					 }
					catch (Exception e) {
						logger.error("error in dualFactorDetails Appliance :" + e.getMessage());
					 }
				}
			 }
		}
		return listCaviumResponseModel;
	}*/
	@RequestMapping(value = "editAppliance", method = RequestMethod.POST)
	public ApplianceDetailModel editAppliance(@RequestBody ApplianceDetailModel applianceDetailModel) {
		try {
			applianceDetailModel=applianceService.editAppliance(applianceDetailModel);	
		} catch (Exception e) {
			logger.error("Error occured during edit appliance :: " +e.getMessage());
		}
		return applianceDetailModel;
	}

	@RequestMapping(value = "getUserDualFactorDetails/{applianceId}/{userId}", method = RequestMethod.GET)
	public boolean getUserDualFactorDetails(@PathVariable("applianceId") String applianceId ,@PathVariable("userId") String userId) {
		boolean isUserExist=false;
		try {
		 
			 isUserExist=applianceService.getUserDualFactorDetails(userId,applianceId);	
		} catch (Exception e) {
			isUserExist=false;
			logger.error("Error occured during getUserDualFactorDetails :: "+e.getMessage());
		}
		return isUserExist;
	}
	
	 

}
