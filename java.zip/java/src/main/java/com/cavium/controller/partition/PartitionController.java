package com.cavium.controller.partition;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.partition.PartitionDetailModel;
import com.cavium.model.partition.PartitionETH;
import com.cavium.model.partition.RestorePartitionModel;
import com.cavium.pojo.PartitionDetailsWithPercentage;
import com.cavium.pojo.PartitionSnapShotDetailModel;
import com.cavium.pojo.PartitionSnapshotDetails;
import com.cavium.pojo.PartitionsDetails;
import com.cavium.pojo.UserAttributes;
import com.cavium.pojo.partitionstats.PartitionStatsDetails;
import com.cavium.repository.appliance.ApplianceRepository;
import com.cavium.repository.partition.PartitionDetailsWithPercentageRepository;
import com.cavium.repository.partition.PartitionRepository;
import com.cavium.repository.partition.PartitionSnapShotDetailModelRepository;
import com.cavium.repository.recentactivity.InProgressActivityRepository;
import com.cavium.service.appliance.ApplianceService;
import com.cavium.service.partition.PartitionService;
import com.cavium.utill.CaviumResponseModel;
import com.cavium.utill.CaviumUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.fasterxml.jackson.databind.type.TypeFactory;

/*
 * 
 */
@RestController
@RequestMapping("rest")
public class PartitionController {

	@Autowired
	private UserAttributes userAttributes;

	@Autowired
	private ApplianceService applianceService;

	@Autowired
	private PartitionService partitionService;
	
	@Autowired
	private PartitionRepository partitionRepository;
	
	@Autowired
	private ApplianceRepository applianceRepository;
	
	@Autowired
	private PartitionDetailsWithPercentageRepository partitionDetailsWithPercentageRepository;
	@Autowired
	private PartitionSnapShotDetailModelRepository partitionSnapshotDetailsRepository;
	
	
	@Autowired
	private InProgressActivityRepository inProgressActivityRepository;

	@Lookup
	public PartitionsDetails getPartitionsDetails() {
		return null;
	}
	@Lookup
	public CaviumResponseModel getCaviumResponseModel() {
		return null;
	}


	private Logger logger = Logger.getLogger(this.getClass());

	/**
	 * This method is used to get PartitionsDetails
	 * @return
	 */
	@RequestMapping(value = "partitionsDetailsForApplianceSnapshot", method = RequestMethod.GET)
	public PartitionsDetails getPartitionsDetailsForApplianceSnapshot(){
		logger.info("start of getPartitionsDetails Method");
		List<ApplianceDetailModel>listApplianceDetailModels= new ArrayList<ApplianceDetailModel>();
		PartitionsDetails partitionsDetails=getPartitionsDetails();
		try{	 
			String loggedInUser = userAttributes.getlogInUserName(); 
			listApplianceDetailModels = applianceService.listOfApplianceByGroupId(loggedInUser);

			for (Iterator<ApplianceDetailModel> iterator = listApplianceDetailModels.iterator(); iterator.hasNext();) {
				ApplianceDetailModel applianceDetailModel = (ApplianceDetailModel) iterator.next();
				partitionsDetails=partitionService.getPartitionInfo(applianceDetailModel,partitionsDetails);			
			}

		}catch(Exception e){
			logger.error("Error occured during getPartitionsDetails method of PartitionController class"+e.getMessage());

		}
		return partitionsDetails;
	}

	/**
	 * This method is used to get list of all partitions
	 * @return
	 */
	@RequestMapping(value = "getListOfPartitions", method = RequestMethod.GET)
	public List<PartitionDetailModel> getListOfPartitions() {
		// TODO Auto-generated method stub
		List<PartitionDetailModel> listPartitions=new ArrayList<PartitionDetailModel>();
		try {
			String loggedInUser = userAttributes.getlogInUserName();
			listPartitions=partitionService.getListOfPartitions(loggedInUser);
			for(PartitionDetailModel pdm :listPartitions){
				if(StringUtils.isNotEmpty(pdm.getLastOperationStatus()) && "In-Progress".equalsIgnoreCase(pdm.getLastOperationStatus())){
					int count= inProgressActivityRepository.inprogressActivityCountForPartition(pdm.getPartitionId());
					if(count==0 && pdm.getApplianceDetailModel()!=null && pdm.getApplianceDetailModel().getApplianceId()!=null){
						pdm.setLastOperationStatus("Completed");
						partitionRepository.save(pdm);
					}
 				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getListOfPartitions method of PartitionController class"+e.getMessage());
		}
		return listPartitions;
	}
	/**
	 * This method is used to create partition
	 * @param partitionDetailModels
	 * @return
	 */
	@RequestMapping(value = "createPartitions", method = RequestMethod.POST)
	public PartitionDetailModel createPartition(@RequestBody PartitionDetailModel partitionDetailModels) {
		String loggedInUser = userAttributes.getlogInUserName();
		PartitionDetailModel partition=null;
		 try {
			 partition=partitionService.createPartition(loggedInUser, partitionDetailModels,null);
		} catch (Exception e) {
			logger.error("Error occured during createPartition method of PartitionController class"+e.getMessage());
		}
		return partition;
	}
	/**
	 * This method is used to modify the partition 
	 * this method is used for future use
	 * @param partitionDetailModels
	 * @return
	 */
	@RequestMapping(value = "modifyPartition", method = RequestMethod.PUT)
	public PartitionDetailModel modifyPartition(@RequestBody PartitionDetailModel partitionDetailModels) {
		// TODO Auto-generated method stub
		return null;
	}
	/**
	 * This method is used to delete the partition
	 * @param partitionDetailModels
	 * @return
	 */
	@RequestMapping(value = "deletePartition", method = RequestMethod.DELETE)
	public List<PartitionDetailModel> deletePartition(@RequestBody List<PartitionDetailModel> partitionDetailModels) {
		List<PartitionDetailModel> partitionDetailModel=null;
		try {
			String loggedInUser = userAttributes.getlogInUserName();
			partitionDetailModel=partitionService.deletePartition(loggedInUser, partitionDetailModels);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getPartitionNetworkStatsInfo of class PartitionContoller"+e.getMessage());
		}
		return partitionDetailModel;
	}
	/**
	 * This method is used to validate whether the init operation performed on appliance or not
	 * @param applianceDetailModel
	 * @return
	 */
	@RequestMapping(value = "validateInitOperationForCreatePartition", method = RequestMethod.POST)
	public CaviumResponseModel validateInitOperationForCreatePartition(@RequestBody ApplianceDetailModel applianceDetailModel) {
		CaviumResponseModel caviumResponse=null;
		// TODO Auto-generated method stub
		try {
			caviumResponse=partitionService.validateInitOperationForCreatePartition(applianceDetailModel);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during validateInitOperationForCreatePartition"+e.getMessage());
		}
		return caviumResponse;
	}
	/**
	 * This method is used to get partition info
	 * @param partitionDetailModels
	 * @return
	 */
	@RequestMapping(value = "getPartitionInfo/{partitionId}", method = RequestMethod.GET)
	public PartitionDetailModel getPartitionInfo(@PathVariable("partitionId") String partitionId) {
		PartitionDetailModel partitionDetailModel = new PartitionDetailModel();
		try {
			partitionDetailModel.setPartitionId(Long.valueOf(partitionId));
			partitionDetailModel=partitionService.getPartitionInfo(partitionDetailModel);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getPartitionInfo of class PartitionContoller"+e.getMessage());
		}
		return partitionDetailModel;
	}

	/**
	 * This method is used to get partition stats
	 * @param partitionDetailModels
	 * @return
	 */
	@RequestMapping(value = "getPartitionStats/{partitionId}", method = RequestMethod.GET)
	public PartitionDetailModel getPartitionStatsInfo(@PathVariable("partitionId") String partitionId) {
		PartitionDetailModel partitionDetailModel = new PartitionDetailModel();
		try {
			partitionDetailModel.setPartitionId(Long.valueOf(partitionId));
			partitionDetailModel=partitionService.getPartitionStatsInfo(partitionDetailModel);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getPartitionStats of class PartitionContoller"+e.getMessage());
		}
		return partitionDetailModel;
	}
	/**
	 * This method is used to get partition network stats 
	 * @param partitionDetailModels
	 * @return
	 */
	@RequestMapping(value = "getPartitionNetworkStats/{partitionId}", method = RequestMethod.GET)
	public PartitionDetailModel getPartitionNetworkStatsInfo(@PathVariable("partitionId") String partitionId) {
		PartitionDetailModel partitionDetailModel = new PartitionDetailModel();
		try {
			partitionDetailModel.setPartitionId(Long.valueOf(partitionId));
			partitionDetailModel=partitionService.getPartitionNetworkStatsInfo(partitionDetailModel);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getPartitionNetworkStatsInfo of class PartitionContoller"+e.getMessage());
		}
		return partitionDetailModel;
	}

	@RequestMapping(value = "closeSessionForPartition", method = RequestMethod.PUT)
	public List<PartitionDetailModel> closeSessionForPartition(@RequestBody List<PartitionDetailModel> partitionDetailModels) {
		List<PartitionDetailModel> partitionDetailModel=null;
		try {
			partitionDetailModel=partitionService.closeSessionForPartition(partitionDetailModels);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during closeSessionForPartition of class PartitionContoller"+e.getMessage());
		}
		return partitionDetailModel;
	}

	@RequestMapping(value = "rebootPartition", method = RequestMethod.PUT)
	public List<PartitionDetailModel> rebootPartition(@RequestBody List<PartitionDetailModel> partitionDetailModels) {
		List<PartitionDetailModel> partitionDetailModel=null;
		String loggedInUser = userAttributes.getlogInUserName();
		try {
			partitionDetailModel=partitionService.rebootPartition(loggedInUser, partitionDetailModels);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during resetPartition of class PartitionContoller"+e.getMessage());
		}
		return partitionDetailModel;
	}


	@RequestMapping(value = "partitionSnapshotDetails", method = RequestMethod.GET)
	public PartitionSnapshotDetails partitionSnapshotDetails(){
		logger.info("start of keysDetailsForPartitionSnapshot Method");
		PartitionSnapshotDetails partitionSnapshotDetails=null;
		try {
			partitionSnapshotDetails= partitionService.getPartitionSnapShotDetails();
		}catch(Exception e){
			logger.error("Error occured during keysDetailsForPartitionSnapshot method of PartitionController class "+e.getMessage());
		}
		return partitionSnapshotDetails;
	}


	@RequestMapping(value = "setPartitionNetworkConfiguration", method = RequestMethod.POST)
	public List<PartitionDetailModel> setPartitionNetworkConfiguration(@RequestBody List<PartitionDetailModel> partitionDetailModels) {
		List<PartitionDetailModel> partitionDetailModel=null;
		try {
			String loggedInUser = userAttributes.getlogInUserName();
			partitionDetailModel=partitionService.setNetworkConfiguration(loggedInUser,partitionDetailModels);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during setPartitionNetworkConfiguration of class PartitionContoller"+e.getMessage());
		}
		return partitionDetailModel;
	}

	@RequestMapping(value = "stopStartPartitionCavSever", method = RequestMethod.POST)
	public List<PartitionDetailModel> stopStartPartitionCavSever(@RequestBody List<PartitionDetailModel> partitionDetailModels){
		try {
			String loggedInUser = userAttributes.getlogInUserName();
			partitionDetailModels=partitionService.stopStartPartitionCavSever(loggedInUser, partitionDetailModels);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during stopStartPartitionCavSever of class PartitionContoller"+e.getMessage());
		}
		return partitionDetailModels;
	}

	@RequestMapping(value = "uploadCavServerConfigFile", method = RequestMethod.POST)
	public List<PartitionDetailModel> uploadCavServerConfigFile(@RequestBody List<PartitionDetailModel> partitionDetailModels){
		try {
			String loggedInUser = userAttributes.getlogInUserName();
			partitionDetailModels=partitionService.uploadCavServerConfigFile(loggedInUser, partitionDetailModels);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during uploadCavServerConfigFile of class PartitionContoller"+e.getMessage());
		}
		return partitionDetailModels;
	}

	@RequestMapping(value = "downloadCavServerConfigFile", method = RequestMethod.POST,produces="application/zip")
	public final void downloadCavServerConfigFile(@RequestBody List<PartitionDetailModel> partitionDetailModels,HttpServletResponse response){
		ArrayList<File> files = new ArrayList<>();
		BufferedOutputStream bufferedOutputStream =null;
		ZipOutputStream zipOutputStream=null;
		PrintWriter pw =null;
		try {
			boolean headerSet=false;
			bufferedOutputStream = new BufferedOutputStream(response.getOutputStream());
			pw = new PrintWriter(bufferedOutputStream);
			zipOutputStream   = new ZipOutputStream(bufferedOutputStream);
			for(PartitionDetailModel pdm: partitionDetailModels) {
				CaviumResponseModel responseModel=getCaviumResponseModel();
				responseModel = partitionService.downloadConfigFileURL(pdm,"download_cav_server_config","downloaCavServerConfig");
				logger.info(" Start of downloadCavServerConfigFile method of PartitionController");
				File file=null;
				if(!StringUtils.isEmpty(responseModel.getResponseMessage()) &&  "200".equalsIgnoreCase(responseModel.getResponseCode())) {
					PartitionDetailModel pdmm=partitionRepository.findOne(pdm.getPartitionId());
					String applianceName="";
					if(pdmm!=null && pdmm.getApplianceDetailModel()!=null && pdmm.getApplianceDetailModel().getApplianceName()!=null) {
						applianceName=pdmm.getApplianceDetailModel().getApplianceName();
					}
					file=partitionService.downloadConfigFile(responseModel.getResponseMessage(), pdm.getPartitionName(),applianceName);
					if(file!=null) {
						if(!headerSet){
							response.setContentType("application/zip");
							response.setStatus(HttpServletResponse.SC_OK);
							response.addHeader("Content-Disposition", "attachment; filename=\"CavServerConfigFile.zip\"");
							headerSet=true;
						}
						files.add(file);
					}
				}
			}
			if(!headerSet){
				response.setContentType("text/html"); 
				pw.write("Error occured during download file"); 
				pw.close();
			}
			for (File file : files) {
				//new zip entry and copying inputstream with file to zipOutputStream, after all closing streams
				zipOutputStream.putNextEntry(new ZipEntry(file.getName()));
				FileInputStream fileInputStream = new FileInputStream(file);

				IOUtils.copy(fileInputStream, zipOutputStream);

				fileInputStream.close();
				zipOutputStream.closeEntry();
			}
			
			try{
				if (zipOutputStream != null) {
					zipOutputStream.finish();
					zipOutputStream.flush();
					IOUtils.closeQuietly(zipOutputStream);
				}
				if(bufferedOutputStream!=null){
					IOUtils.closeQuietly(bufferedOutputStream);
				}
			}catch (Exception e) {
				logger.error("error coming while closing  zipOutputStream in downloadCavServerConfigFile method of PartitionController :: "+e.getMessage());	 
			
			}

		} catch (IOException e) {
			logger.error("error coming while download the certificate in downloadCavServerConfigFile method of PartitionController :: "+e.getMessage());
		}
		finally {

			for (File file : files) 
				if(file!=null){
					try{
						Files.deleteIfExists(Paths.get(file.getAbsolutePath()));
					}catch (Exception e) {
						logger.error("Error while deleting certificate file  in downloadCavServerConfigFile method of PartitionController :: " + e.getMessage()); 
					}
				}
	 }
logger.info("End of downloadCertificate method of PartitionController");
	}

	@RequestMapping(value = "resetCavServerConfig", method = RequestMethod.POST)
	public List<PartitionDetailModel> resetCavServerConfig(@RequestBody List<PartitionDetailModel> partitionDetailModels){
		try {
			String loggedInUser = userAttributes.getlogInUserName();
			partitionDetailModels=partitionService.resetCavServerConfig(loggedInUser, partitionDetailModels);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during resetCavServerConfig of class PartitionContoller"+e.getMessage());
		}
		return partitionDetailModels;
	}

	/*@RequestMapping(value = "uploadPartitionCertificate", method = RequestMethod.POST)
	public List<PartitionDetailModel> uploadPartitionCertificate(@RequestBody List<PartitionDetailModel> partitionDetailModels){
		try {
			String loggedInUser = userAttributes.getlogInUserName();
			partitionDetailModels=partitionService.uploadCavServerConfigFile(loggedInUser, partitionDetailModels);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during uploadCavServerConfigFile of class PartitionContoller"+e.getMessage());
		}
		return partitionDetailModels;
	}*/


	@RequestMapping(value = "backupPartition", method = RequestMethod.POST)
	public final void backupPartition(@RequestBody List<PartitionDetailModel> partitionDetailModels,HttpServletResponse response){

		ArrayList<File> files = new ArrayList<>();
		BufferedOutputStream bufferedOutputStream =null;
		ZipOutputStream zipOutputStream=null;
		PrintWriter pw =null;
		try {
			boolean headerSet=false;
			bufferedOutputStream = new BufferedOutputStream(response.getOutputStream());
			pw = new PrintWriter(bufferedOutputStream);
			zipOutputStream   = new ZipOutputStream(bufferedOutputStream);
			for(PartitionDetailModel pdm: partitionDetailModels) {
				try {
					if(pdm.isSessionClose()) {
						JSONObject jsonObject=new JSONObject();
						jsonObject=partitionService.getUserNamePassword(pdm, jsonObject);
						jsonObject.put("action", "close_session");
						pdm=partitionService.closeSession(pdm, "backupPartition",jsonObject);
					}
					if(pdm.getCode()!=null && pdm.getCode().equalsIgnoreCase("200") || pdm.isSessionClose() == false) {
						CaviumResponseModel responseModel=getCaviumResponseModel();
						String operation="backup";
						responseModel = partitionService.downloadConfigFileURL(pdm,"backup_partition",operation);
						logger.info(" Start of backupPartition method of PartitionController");
						File file=null;
						if(!StringUtils.isEmpty(responseModel.getResponseMessage()) && responseModel.getResponseCode().equalsIgnoreCase("200")) {
							PartitionDetailModel pdmm=partitionRepository.findOne(pdm.getPartitionId());
							String applianceName="";
							if(pdmm!=null && pdmm.getApplianceDetailModel()!=null && pdmm.getApplianceDetailModel().getApplianceName()!=null) {
								applianceName=pdmm.getApplianceDetailModel().getApplianceName();
							}
							file=partitionService.downloadConfigFile(responseModel.getResponseMessage(), pdm.getPartitionName(),applianceName);
							if(file!=null) {
								if(!headerSet){
									response.setContentType("application/zip");
									response.setStatus(HttpServletResponse.SC_OK);
									response.addHeader("Content-Disposition", "attachment; filename=\"backupPartitionFiles.zip\"");
									headerSet=true;
								}
								files.add(file);
							}
						}
					}
				
				} catch (Exception e) {
					// TODO: handle exception
					logger.error("Error occured during backupPartition of class PartitionContoller"+e.getMessage());
				}
			}
			if(!headerSet){
				response.setContentType("text/html"); 
				pw.write("Error occured during download file"); 
				pw.close();
			}
			for (File file : files) {
				//new zip entry and copying inputstream with file to zipOutputStream, after all closing streams
				zipOutputStream.putNextEntry(new ZipEntry(file.getName()));
				FileInputStream fileInputStream = new FileInputStream(file);

				IOUtils.copy(fileInputStream, zipOutputStream);

				fileInputStream.close();
				zipOutputStream.closeEntry();
			}
			
			try{
				if (zipOutputStream != null) {
					zipOutputStream.finish();
					zipOutputStream.flush();
					IOUtils.closeQuietly(zipOutputStream);
				}
				if(bufferedOutputStream!=null){
					IOUtils.closeQuietly(bufferedOutputStream);
				}
			}catch (Exception e) {
				logger.error("error coming while closing  zipOutputStream in downloadCavServerConfigFile method of PartitionController :: "+e.getMessage());	 
			}
		}
		catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during backupPartition of class PartitionContoller"+e.getMessage());
		}
		finally {

			for (File file : files) 
				if(file!=null){
					try{
						Files.deleteIfExists(Paths.get(file.getAbsolutePath()));
					}catch (Exception e) {
						logger.error("Error while deleting certificate file  in backupPartition method of PartitionController :: " + e.getMessage()); 
					}
				}
			if(pw!=null){
				pw.close();
			}
			try{
				if (zipOutputStream != null) {
					zipOutputStream.finish();
					zipOutputStream.flush();
					IOUtils.closeQuietly(zipOutputStream);
				}
				if(bufferedOutputStream!=null){
					IOUtils.closeQuietly(bufferedOutputStream);
				}
			}catch (Exception e) {
				logger.error("error coming while closing  zipOutputStream in backupPartition method of PartitionController :: "+e.getMessage());	 
			}
		}
	}

	@RequestMapping(value = "restorePartition", method = RequestMethod.POST)
	public List<PartitionDetailModel> restorePartition(@RequestBody RestorePartitionModel restorePartitionModel){
		List<PartitionDetailModel> partitionList=null;
		try {
			String loggedInUser = userAttributes.getlogInUserName();
			partitionList=partitionService.restorePartition(loggedInUser, restorePartitionModel);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during uploadCavServerConfigFile of class PartitionContoller"+e.getMessage());
		}
		return partitionList;
	}

	/**
	 * This method is used to get list of all partitions
	 * @return
	 */
	@RequestMapping(value = "getListOfPartitionsByApplianceID", method = RequestMethod.POST)
	public List<PartitionDetailModel> getListOfPartitionsByApplianceID(@RequestBody ApplianceDetailModel applianceDetailModel) {
		// TODO Auto-generated method stub
		List<PartitionDetailModel> listPartitions=new ArrayList<PartitionDetailModel>();
		try {
			String loggedInUser = userAttributes.getlogInUserName();
			if(applianceDetailModel.getApplianceId()!=null && applianceDetailModel.getApplianceId() > 0) {
				listPartitions=partitionService.getListOfPartitionsByApplianceID(loggedInUser, applianceDetailModel.getApplianceId());
			}else {
				PartitionDetailModel part=new PartitionDetailModel();
				part.setErrorMessage("No applianceID found..");
				listPartitions.add(part);
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getListOfPartitions method of PartitionController class"+e.getMessage());
		}
		return listPartitions;
	}
	/**
	 * This method is used to resize the partition
	 * @param partitionDetailModel
	 * @return
	 */
	@RequestMapping(value = "resizePartitions", method = RequestMethod.POST)
	public PartitionDetailModel resizePartitions(@RequestBody PartitionDetailModel partitionDetailModel) {
		// TODO Auto-generated method stub
		try {
			partitionDetailModel=partitionService.resizePartitions(partitionDetailModel);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during resizePartitions method of PartitionController class"+e.getMessage());
		}
		return partitionDetailModel;
	}
	/**
	 * This method is use to get the partition resize initial data
	 * @param partitionDetailModel
	 * @return
	 */
	@RequestMapping(value = "getPartitionInfoForResize", method = RequestMethod.POST)
	public List<PartitionDetailModel> getPartitionInfo(@RequestBody List<PartitionDetailModel> partitionDetailModel) {
		// TODO Auto-generated method stub
		try {
			partitionDetailModel=partitionService.getPartitionInfoData(partitionDetailModel);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getPartitionInfoForResize method of PartitionController class"+e.getMessage());
		}
		return partitionDetailModel;
	}

	/**
	 * This method is use to get the partition resize initial data
	 * @param partitionDetailModel
	 * @return
	 */
	@RequestMapping(value = "setPartitionMonitorData", method = RequestMethod.POST)
	public List<PartitionDetailModel> setPartitionMonitorData(@RequestBody List<PartitionDetailModel> partitionDetailModel) {
		// TODO Auto-generated method stub
		try {
			partitionDetailModel=partitionService.setPartitionMonitorConfig(partitionDetailModel);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getPartitionInfoForResize method of PartitionController class"+e.getMessage());
		}
		return partitionDetailModel;
	}


	/**
	 * This method is use to get the partition resize initial data
	 * @param partitionDetailModel
	 * @return
	 */
	@RequestMapping(value = "getPartitionMonitorData", method = RequestMethod.POST)
	public List<PartitionDetailModel> getPartitionMonitorData(@RequestBody List<PartitionDetailModel> partitionDetailModel) {
		// TODO Auto-generated method stub
		try {
			partitionDetailModel=partitionService.getPartitionMonitorData(partitionDetailModel);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getPartitionMonitorStats method of PartitionController class"+e.getMessage());
		}
		return partitionDetailModel;
	}

	@RequestMapping(value = "getPartitionMonitorStats", method = RequestMethod.POST)
	public List<PartitionDetailModel> getPartitionMonitorStats(@RequestBody  List<PartitionDetailModel> partitionDetailModels){
		try {
			partitionDetailModels=partitionService.getPartitionMonitorStats(partitionDetailModels);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getPartitionMonitorStats ");
		}
		return partitionDetailModels;
	}

	@RequestMapping(value = "updateEth01IpDetail", method = RequestMethod.POST)
	public  void updateEth01IpDetail(@RequestBody  PartitionETH partitionETH){
		try {
			partitionService.updateEth01IpAddress(partitionETH);
		} catch (Exception e) {	
			logger.error("Error occured in  updateEth01IpDetail method of PartitionController");
		}	 
	}
	
	@RequestMapping(value = "getPartitionStatsGraphDetails/{partitionId}", method = RequestMethod.GET)
	public  List<PartitionStatsDetails> getPartitionStatsGraphDetails(@PathVariable("partitionId") Long partitionId){
		List<PartitionStatsDetails> partitionStatsGraphDetails= new ArrayList<PartitionStatsDetails>();
		try {
			partitionStatsGraphDetails=	partitionService.getPartitionStatsGraphDetails(partitionId);
		} catch (Exception e) {	
			logger.error("Error occured in getPartitionStatsGraphDetails method of PartitionController");
		}
		return partitionStatsGraphDetails;
	}
	
	@RequestMapping(value = "partitionRestore", method = RequestMethod.POST,consumes = {"multipart/form-data"})
	public List<PartitionDetailModel> partitionRestore(@RequestPart("backupFrom") String backupFrom,@RequestPart("partitions") String partitions, @RequestPart(value="restoreFile",required=false) MultipartFile restoreFile)
	{
		List<PartitionDetailModel> responseList=new ArrayList<>();
		try {
			if(restoreFile==null || restoreFile.isEmpty()) {
				ObjectMapper mapper=new ObjectMapper();
				TypeFactory typeFactory = mapper.getTypeFactory();
				CollectionType collectionType = typeFactory.constructCollectionType(List.class, PartitionDetailModel.class);
				List<PartitionDetailModel> partlist =  mapper.readValue(partitions, collectionType);
				
				PartitionDetailModel toBebackupFrom=mapper.readValue(backupFrom, PartitionDetailModel.class);
				
				responseList=partitionService.partitionRestore(partlist, toBebackupFrom, null);
			}else {
				ObjectMapper mapper=new ObjectMapper();
				TypeFactory typeFactory = mapper.getTypeFactory();
				CollectionType collectionType = typeFactory.constructCollectionType(List.class, PartitionDetailModel.class);
				List<PartitionDetailModel> partlist =  mapper.readValue(partitions, collectionType);  
				responseList=partitionService.partitionRestore(partlist, null, restoreFile);
			}
		} catch (Exception e) {
				PartitionDetailModel partitionDetailModel= new PartitionDetailModel();
				partitionDetailModel.setCode("409");
				partitionDetailModel.setLastOperationPerformed("restore");
				partitionDetailModel.setLastOperationStatus("Failed");
				partitionDetailModel.setMessage("");
				partitionDetailModel.setErrorMessage("Error Coming while parsing PartitionModel");
				responseList.add(partitionDetailModel);
				logger.error("Error occured during ");
		}finally {
			if(restoreFile!=null) {
				 File convFile = new File(restoreFile.getOriginalFilename());
				 if(convFile!=null && convFile.exists()) {
					 convFile.delete();
				 }
			}
		}
		return responseList;
	}
	
	/**
	 * This method is used to get partition stats
	 * @param partitionDetailModels
	 * @return
	 */
	@RequestMapping(value = "getPartitionCavServerConfig/{partitionId}", method = RequestMethod.GET)
	public CaviumResponseModel getCavServerConfigInfo(@PathVariable("partitionId") String partitionId) {
		CaviumResponseModel caviumResponseModel=getCaviumResponseModel();
		PartitionDetailModel partitionDetailModel=new PartitionDetailModel();
		try {
			partitionDetailModel.setPartitionId(Long.valueOf(partitionId));
			caviumResponseModel=partitionService.getCavServerConfigInfo(partitionDetailModel);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getPartitionStats of class PartitionContoller"+e.getMessage());
		}
		return caviumResponseModel;
	}
	
	/**
	 * This method is used to get partition stats
	 * @param partitionDetailModels
	 * @return
	 */
	@RequestMapping(value = "getPartitionCavServerStats/{partitionId}", method = RequestMethod.GET)
	public CaviumResponseModel getPartitionCavServerStats(@PathVariable("partitionId") String partitionId) {
		CaviumResponseModel caviumResponseModel=getCaviumResponseModel();
		PartitionDetailModel partitionDetailModel=new PartitionDetailModel();
		try {
			partitionDetailModel.setPartitionId(Long.valueOf(partitionId));
			caviumResponseModel=partitionService.getPartitionCavServerStats(partitionDetailModel);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getPartitionStats of class PartitionContoller"+e.getMessage());
		}
		return caviumResponseModel;
	}
}
