package com.cavium.controller.recentactivity;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.recentactivity.InProgressActivity;
import com.cavium.pojo.UserAttributes;
import com.cavium.service.recentactivity.InProgressActivityService;
import com.cavium.utill.CaviumConstant;

@RestController
@RequestMapping("rest")
public class InProgressActivityController {

	private Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	private UserAttributes userAttributes;
	@Autowired
	private InProgressActivityService inProgressActivityService;

	@RequestMapping(value = "inProgressActivityForAppliance", method = RequestMethod.GET)
	public List<InProgressActivity> getInProgressActivityForAppliance() {
		List<InProgressActivity> inProgressActivity = null;
		String loggedInUser = userAttributes.getlogInUserName();
		try {
			inProgressActivity=inProgressActivityService.getListOfInProgressActivity(loggedInUser,CaviumConstant.APPLIANCE_MANAGEMENT);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("error occured inside getInProgressActivity of class InProgressActivityController" + e.getMessage());
		}
		return inProgressActivity;
	}
	
	@RequestMapping(value = "inProgressActivityForPartition", method = RequestMethod.GET)
	public List<InProgressActivity> getInProgressActivityForPartition() {
		List<InProgressActivity> inProgressActivity = null;
		String loggedInUser = userAttributes.getlogInUserName();
		try {
			inProgressActivity=inProgressActivityService.getListOfInProgressActivity(loggedInUser,CaviumConstant.PARTITION_MANAGEMENT);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("error occured inside getInProgressActivity of class InProgressActivityController" + e.getMessage());
		}
		return inProgressActivity;
	}
}
