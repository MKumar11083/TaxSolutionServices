package com.cavium.controller.usergroup;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.user.UserGroupModel;
import com.cavium.pojo.UserAttributes;
import com.cavium.service.alerts.AlertsService;
import com.cavium.service.user.UserService;
import com.cavium.utill.CaviumConstant;
import com.cavium.utill.CaviumResponseModel;

/**
 * @author RK00490847
 * 
 */
@RestController
@RequestMapping("rest")
public class DeleteUserGroupController {

	private Logger logger = Logger.getLogger(this.getClass());
	@Autowired
	private UserService userService;

	@Lookup
	public CaviumResponseModel getCaviumResponseModel() {
		return null;
	}
	@Autowired
	private AlertsService alertsService;
	
	@Autowired
	private UserAttributes userAttributes;
	
	/**
	 * This deleteUserGroup method delete the group and return responseModel to the
	 * response.
	 * 
	 * @return responseModel - CaviumResponseModel Object
	 * 
	 * @param aclId
	 * 
	 */
/*	@RequestMapping(value = "deleteUserGroup", method = RequestMethod.DELETE)
	public final CaviumResponseModel deleteUserGroup(@PathVariable("groupId") String groupId) {
		logger.info("Start of deleteUserGroup Method");
		CaviumResponseModel responseModel=getCaviumResponseModel();
		logger.info("Group ID " + groupId + " is going for deletion");
		responseModel = userService.deleteUserGroup(groupId);
		logger.info("ResponseModel for deleteUserGroup :: " + responseModel.toString());
		logger.info("End of deleteUserGroup Method");
		return responseModel;
	}*/
	
	
	/**
	 * This deleteUserGroup method delete the group and return responseModel to the
	 * response.
	 * 
	 * @return listResponseModel - List of CaviumResponseModel Object
	 * 
	 * @param userGroupModel -  UserGroupModel Object
	 * 
	 */
	@RequestMapping(value = "deleteUserGroup", method = RequestMethod.DELETE)
	public final List<CaviumResponseModel> deleteUser(@RequestBody UserGroupModel userGroupModel) {
		logger.info("Start of deleteUser Method");
		CaviumResponseModel responseModel = getCaviumResponseModel();
		String loggedInUser = userAttributes.getlogInUserName(); 
		List<CaviumResponseModel> listResponseModel = new ArrayList<CaviumResponseModel>();
		if (userGroupModel.getDeletedUserGroupIds() != null && userGroupModel.getDeletedUserGroupIds().size()>0) {
			Iterator<String> iterator = userGroupModel.getDeletedUserGroupIds().iterator();
			while (iterator.hasNext()) {
				String groupId = iterator.next();
				
				try {
				responseModel = userService.deleteUserGroup(groupId);
				listResponseModel.add(responseModel);
				} catch (DataIntegrityViolationException exp) {
					logger.error("Error is coming in Delete UserGroup :: " + exp.getMessage());
					responseModel.setResponseCode("-230");
					responseModel.setResponseMessage(groupId +" "+ "linked with some user");
					listResponseModel.add(responseModel);
					alertsService.createAlert(loggedInUser, "Error is coming while deleting Group "+groupId+" by "+loggedInUser,CaviumConstant.USER_MANAGEMENT);
				
				} catch (EmptyResultDataAccessException exp) {
					logger.error("UserGroupId does not exist in DB " + exp.getMessage());
					responseModel.setResponseCode("-230");
					responseModel.setResponseMessage(groupId +" "+"userGroupId does not exist");
					listResponseModel.add(responseModel);
					alertsService.createAlert(loggedInUser, "Error is coming while deleting Group "+groupId+" by "+loggedInUser,CaviumConstant.USER_MANAGEMENT);
				
				} catch (Exception exp) {
					logger.error("Error is coming in Delete UserGroup :: " + exp.getMessage());
					responseModel.setResponseCode("-230");
					responseModel.setResponseMessage(groupId +" "+"Failed to delete UserGroup");
					listResponseModel.add(responseModel);
					alertsService.createAlert(loggedInUser, "Error is coming while deleting Group "+groupId+" by "+loggedInUser,CaviumConstant.USER_MANAGEMENT);
				
				}
			}
			logger.info("ResponseModel for deleteUser :: " + listResponseModel.toString());
			logger.info("End of deleteUser Method");
		}
		return listResponseModel;
	}
}
