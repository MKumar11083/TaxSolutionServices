package com.cavium.model.appliance;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

 
@Entity
@Table(name="dualfactor_users_relationship")
public class DualFactorUsersRelationshipModel
  implements Serializable
{
  private static final long serialVersionUID = 4692301322760007284L;
  @Id
  @GeneratedValue(strategy=GenerationType.IDENTITY)
  private Long id;
  @Column(name="dual_factor_auth_server_port_no")
	private String dualFactorAuthServerPortNo;
   @Column(name="dual_factor_certificate_id")
	private String dualFactorCertificateId;
	@Column(name="dual_factor_key_file_id")
	private String dualFactorKeyFileId;
	@Column(name="user_id")
	private String userId;
	@Column(name="appliance_id")
	private Long applianceId;
	@Column(name="appliance_ip")
	private String applianceIp;
/**
 * @return the id
 */
public Long getId() {
	return id;
}
/**
 * @param id the id to set
 */
public void setId(Long id) {
	this.id = id;
}
/**
 * @return the dualFactorCertificateId
 */
public String getDualFactorCertificateId() {
	return dualFactorCertificateId;
}
/**
 * @param dualFactorCertificateId the dualFactorCertificateId to set
 */
public void setDualFactorCertificateId(String dualFactorCertificateId) {
	this.dualFactorCertificateId = dualFactorCertificateId;
}
/**
 * @return the dualFactorKeyFileId
 */
public String getDualFactorKeyFileId() {
	return dualFactorKeyFileId;
}
/**
 * @param dualFactorKeyFileId the dualFactorKeyFileId to set
 */
public void setDualFactorKeyFileId(String dualFactorKeyFileId) {
	this.dualFactorKeyFileId = dualFactorKeyFileId;
}
/**
 * @return the userId
 */
public String getUserId() {
	return userId;
}
/**
 * @param userId the userId to set
 */
public void setUserId(String userId) {
	this.userId = userId;
}
 
/**
 * @return the applianceId
 */
public Long getApplianceId() {
	return applianceId;
}
/**
 * @param applianceId the applianceId to set
 */
public void setApplianceId(Long applianceId) {
	this.applianceId = applianceId;
}
/**
 * @return the dualFactorAuthServerPortNo
 */
public String getDualFactorAuthServerPortNo() {
	return dualFactorAuthServerPortNo;
}
/**
 * @param dualFactorAuthServerPortNo the dualFactorAuthServerPortNo to set
 */
public void setDualFactorAuthServerPortNo(String dualFactorAuthServerPortNo) {
	this.dualFactorAuthServerPortNo = dualFactorAuthServerPortNo;
}
/**
 * @return the applianceIp
 */
public String getApplianceIp() {
	return applianceIp;
}
/**
 * @param applianceIp the applianceIp to set
 */
public void setApplianceIp(String applianceIp) {
	this.applianceIp = applianceIp;
}
 
 
 
}
