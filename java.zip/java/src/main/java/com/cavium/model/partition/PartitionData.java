package com.cavium.model.partition;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Table(name = "partition_data")
public class PartitionData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1358503479714760065L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	@Column(name="certauth")
	private Integer certAuth;
	@Column(name="pco_fixed_key_finger_print")
	private String pcoFixedKeyFingerPrint;
	@Column(name="max_keys")
	private Integer maxKeys;
	@Column(name="cloning_method")
	private String cloningMethod;
	@Column(name="total_ssl_ctxs")
	private Integer totalSslCtxs;
	@Column(name="mvalue_cloning")
	private Integer mValueCloning;
	@Column(name="kek_method")
	private Integer kekMethod;
	@Column(name="audit_log_status")
	private String auditLogStatus;
	@Column(name="block_delete_user_with_keys")
	private Integer blockDeleteUserWithKeys;
	@Column(name="cav_server_status")
	private int cavServerStatus;
	@Column(name="node_id")
	private String nodeId;
	@Column(name="mvalue_miscco")
	private Integer mValueMiscCO;
	@Column(name="max_acclr_dev_count")
	private Integer maxAcclrDevCount;
	@Column(name="key_import")
	private String keyImport;
	@Column(name="key_export")
	private String keyExport;
	@Column(name="occupied_session_keys")
	private Integer occupiedSessionKeys;
	@Column(name="export_user_keys_other_thankek")
	private String exportWithUserKeysOtherThanKEK;
	@Column(name="status")
	private String status;
	@Column(name="mvalue_backup_by_co")
	private Integer mValueBackupByCO;
	@Column(name="session_count")
	private Integer sessionCount;
	@Column(name="two_key_backup")
	private Integer twoKeyBackup;
	@Column(name="available_users")
	private Integer availableUsers;
	@Column(name="max_pswd_len")
	private Integer maxPswdLen;
	@Column(name="max_users")
	private Integer maxUsers;
	@Column(name="group_id")
	private String groupId;
	@Column(name="vm_status")
	private int vmStatus;
	@Column(name="partition_name")
	private String name;
	@Column(name="n_value")
	private Integer nValue;
	@Column(name="mco_backup_restore")
	private boolean mcoBackupRestore;
	@Column(name="occupied_ssl_ctxs")
	private Integer occupiedSslCtxs;
	@Column(name="fips_state")
	private String fipsState;
	@Column(name="occupied_token_keys")
	private Integer occupiedTokenKeys;
	@Column(name="mvalue_usermgmt")
	private Integer mValueUserMgmt;
	@Column(name="min_pswd_len")
	private Integer minPswdLen;
	@Column(name="partition_id")
	private Integer partitionId;
	@Transient
	private Integer keysUsage;
	@Transient
	private Integer keysUsed;
	@Transient
	private Integer keysAvaliable;
	@Transient
	private Integer sslContextAvaliable;
	@Transient
	private Integer acclrDevicesAvaliable;
	@Transient
	private boolean backup;
	@Transient 
	private Integer AllocatedUserKeys;
	@Transient 
	private Integer AllocatedSSLContexts;
	@Transient 
	private Integer AllocatedAccelDevices;
	@Transient 
	private Integer ModifiedUserKeys;
	@Transient 
	private Integer ModifiedSSLContexts;
	@Transient 
	private Integer ModifiedAccelDevices;
	@Transient
	private boolean incrementKeys;
	@Transient
	private boolean incrementSslContexts;
	@Transient
	private boolean incrementAcclrDev;
 
	/*@OneToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name = "partition_id", nullable = false)
	@JsonBackReference
	private PartitionDetailModel partitionDetailModel;*/
	
	public Integer getCertAuth() {
		return certAuth;
	}
	public void setCertAuth(Integer certAuth) {
		this.certAuth = certAuth;
	}
	public String getPcoFixedKeyFingerPrint() {
		return pcoFixedKeyFingerPrint;
	}
	public void setPcoFixedKeyFingerPrint(String pcoFixedKeyFingerPrint) {
		this.pcoFixedKeyFingerPrint = pcoFixedKeyFingerPrint;
	}
	public Integer getMaxKeys() {
		return maxKeys;
	}
	public void setMaxKeys(Integer maxKeys) {
		this.maxKeys = maxKeys;
	}
	public String getCloningMethod() {
		return cloningMethod;
	}
	public void setCloningMethod(String cloningMethod) {
		this.cloningMethod = cloningMethod;
	}
	public Integer getTotalSslCtxs() {
		return totalSslCtxs;
	}
	public void setTotalSslCtxs(Integer totalSslCtxs) {
		this.totalSslCtxs = totalSslCtxs;
	}
	public Integer getmValueCloning() {
		return mValueCloning;
	}
	public void setmValueCloning(Integer mValueCloning) {
		this.mValueCloning = mValueCloning;
	}
	public Integer getKekMethod() {
		return kekMethod;
	}
	public void setKekMethod(Integer kekMethod) {
		this.kekMethod = kekMethod;
	}
	public String getAuditLogStatus() {
		return auditLogStatus;
	}
	public void setAuditLogStatus(String auditLogStatus) {
		this.auditLogStatus = auditLogStatus;
	}
	public Integer getBlockDeleteUserWithKeys() {
		return blockDeleteUserWithKeys;
	}
	public void setBlockDeleteUserWithKeys(Integer blockDeleteUserWithKeys) {
		this.blockDeleteUserWithKeys = blockDeleteUserWithKeys;
	}
	public String getNodeId() {
		return nodeId;
	}
	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}
	public Integer getmValueMiscCO() {
		return mValueMiscCO;
	}
	public void setmValueMiscCO(Integer mValueMiscCO) {
		this.mValueMiscCO = mValueMiscCO;
	}
	public Integer getMaxAcclrDevCount() {
		return maxAcclrDevCount;
	}
	public void setMaxAcclrDevCount(Integer maxAcclrDevCount) {
		this.maxAcclrDevCount = maxAcclrDevCount;
	}
	public String getKeyImport() {
		return keyImport;
	}
	public void setKeyImport(String keyImport) {
		this.keyImport = keyImport;
	}
	public String getKeyExport() {
		return keyExport;
	}
	public void setKeyExport(String keyExport) {
		this.keyExport = keyExport;
	}
	public Integer getOccupiedSessionKeys() {
		return occupiedSessionKeys;
	}
	public void setOccupiedSessionKeys(Integer occupiedSessionKeys) {
		this.occupiedSessionKeys = occupiedSessionKeys;
	}
	public String getExportWithUserKeysOtherThanKEK() {
		return exportWithUserKeysOtherThanKEK;
	}
	public void setExportWithUserKeysOtherThanKEK(String exportWithUserKeysOtherThanKEK) {
		this.exportWithUserKeysOtherThanKEK = exportWithUserKeysOtherThanKEK;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Integer getmValueBackupByCO() {
		return mValueBackupByCO;
	}
	public void setmValueBackupByCO(Integer mValueBackupByCO) {
		this.mValueBackupByCO = mValueBackupByCO;
	}
	public Integer getSessionCount() {
		return sessionCount;
	}
	public void setSessionCount(Integer sessionCount) {
		this.sessionCount = sessionCount;
	}
	public Integer getTwoKeyBackup() {
		return twoKeyBackup;
	}
	public void setTwoKeyBackup(Integer twoKeyBackup) {
		this.twoKeyBackup = twoKeyBackup;
	}
	public Integer getAvailableUsers() {
		return availableUsers;
	}
	public void setAvailableUsers(Integer availableUsers) {
		this.availableUsers = availableUsers;
	}
	public Integer getMaxPswdLen() {
		return maxPswdLen;
	}
	public void setMaxPswdLen(Integer maxPswdLen) {
		this.maxPswdLen = maxPswdLen;
	}
	public Integer getMaxUsers() {
		return maxUsers;
	}
	public void setMaxUsers(Integer maxUsers) {
		this.maxUsers = maxUsers;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getnValue() {
		return nValue;
	}
	public void setnValue(Integer nValue) {
		this.nValue = nValue;
	}
	public boolean isMcoBackupRestore() {
		return mcoBackupRestore;
	}
	public void setMcoBackupRestore(boolean mcoBackupRestore) {
		this.mcoBackupRestore = mcoBackupRestore;
	}
	public Integer getOccupiedSslCtxs() {
		return occupiedSslCtxs;
	}
	public void setOccupiedSslCtxs(Integer occupiedSslCtxs) {
		this.occupiedSslCtxs = occupiedSslCtxs;
	}
	public String getFipsState() {
		return fipsState;
	}
	public void setFipsState(String fipsState) {
		this.fipsState = fipsState;
	}
	public Integer getOccupiedTokenKeys() {
		return occupiedTokenKeys;
	}
	public void setOccupiedTokenKeys(Integer occupiedTokenKeys) {
		this.occupiedTokenKeys = occupiedTokenKeys;
	}
	public Integer getmValueUserMgmt() {
		return mValueUserMgmt;
	}
	public void setmValueUserMgmt(Integer mValueUserMgmt) {
		this.mValueUserMgmt = mValueUserMgmt;
	}
	public Integer getMinPswdLen() {
		return minPswdLen;
	}
	public void setMinPswdLen(Integer minPswdLen) {
		this.minPswdLen = minPswdLen;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Integer getPartitionId() {
		return partitionId;
	}
	public void setPartitionId(Integer partitionId) {
		this.partitionId = partitionId;
	}
	public Integer getKeysUsage() {
		return keysUsage;
	}
	public void setKeysUsage(Integer keysUsage) {
		this.keysUsage = keysUsage;
	}
	/**
	 * @return the keysUsed
	 */
	public Integer getKeysUsed() {
		return keysUsed;
	}
	/**
	 * @param keysUsed the keysUsed to set
	 */
	public void setKeysUsed(Integer keysUsed) {
		this.keysUsed = keysUsed;
	}
	
	/**
	 * @return the sslContextAvaliabe
	 */
	
	public boolean isBackup() {
		return backup;
	}
	
	public void setBackup(boolean backup) {
		this.backup = backup;
	}
	public Integer getAllocatedUserKeys() {
		return AllocatedUserKeys;
	}
	public void setAllocatedUserKeys(Integer allocatedUserKeys) {
		AllocatedUserKeys = allocatedUserKeys;
	}
	public Integer getAllocatedSSLContexts() {
		return AllocatedSSLContexts;
	}
	public void setAllocatedSSLContexts(Integer allocatedSSLContexts) {
		AllocatedSSLContexts = allocatedSSLContexts;
	}
	public Integer getAllocatedAccelDevices() {
		return AllocatedAccelDevices;
	}
	public void setAllocatedAccelDevices(Integer allocatedAccelDevices) {
		AllocatedAccelDevices = allocatedAccelDevices;
	}
	public Integer getModifiedUserKeys() {
		return ModifiedUserKeys;
	}
	public void setModifiedUserKeys(Integer modifiedUserKeys) {
		ModifiedUserKeys = modifiedUserKeys;
	}
	public Integer getModifiedSSLContexts() {
		return ModifiedSSLContexts;
	}
	public void setModifiedSSLContexts(Integer modifiedSSLContexts) {
		ModifiedSSLContexts = modifiedSSLContexts;
	}
	public Integer getModifiedAccelDevices() {
		return ModifiedAccelDevices;
	}
	public void setModifiedAccelDevices(Integer modifiedAccelDevices) {
		ModifiedAccelDevices = modifiedAccelDevices;
	}
	 
	public boolean isIncrementKeys() {
		return incrementKeys;
	}
	public void setIncrementKeys(boolean incrementKeys) {
		this.incrementKeys = incrementKeys;
	}
	public boolean isIncrementSslContexts() {
		return incrementSslContexts;
	}
	public void setIncrementSslContexts(boolean incrementSslContexts) {
		this.incrementSslContexts = incrementSslContexts;
	}
	public boolean isIncrementAcclrDev() {
		return incrementAcclrDev;
	}
	public void setIncrementAcclrDev(boolean incrementAcclrDev) {
		this.incrementAcclrDev = incrementAcclrDev;
	}
	/**
	 * @return the keysAvaliable
	 */
	public Integer getKeysAvaliable() {
		return keysAvaliable;
	}
	/**
	 * @param keysAvaliable the keysAvaliable to set
	 */
	public void setKeysAvaliable(Integer keysAvaliable) {
		this.keysAvaliable = keysAvaliable;
	}
	/**
	 * @return the sslContextAvaliable
	 */
	public Integer getSslContextAvaliable() {
		return sslContextAvaliable;
	}
	/**
	 * @param sslContextAvaliable the sslContextAvaliable to set
	 */
	public void setSslContextAvaliable(Integer sslContextAvaliable) {
		this.sslContextAvaliable = sslContextAvaliable;
	}
	/**
	 * @return the acclrDevicesAvaliable
	 */
	public Integer getAcclrDevicesAvaliable() {
		return acclrDevicesAvaliable;
	}
	/**
	 * @param acclrDevicesAvaliable the acclrDevicesAvaliable to set
	 */
	public void setAcclrDevicesAvaliable(Integer acclrDevicesAvaliable) {
		this.acclrDevicesAvaliable = acclrDevicesAvaliable;
	}
	public int getCavServerStatus() {
		return cavServerStatus;
	}
	public void setCavServerStatus(int cavServerStatus) {
		this.cavServerStatus = cavServerStatus;
	}
	public int getVmStatus() {
		return vmStatus;
	}
	public void setVmStatus(int vmStatus) {
		this.vmStatus = vmStatus;
	}
}
