package com.cavium.model.cluster;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.cavium.model.partition.PartitionData;
import com.cavium.pojo.PartitionsDetails;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

@Entity
@Table(name = "cluster_details")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class ClusterDetailModel {
	
	 @SuppressWarnings("unused")
	private static final long serialVersionUID = -3840562434180092945L;

	 @Id
     @GeneratedValue(strategy=GenerationType.IDENTITY)
	 @Column(name = "cluster_id", nullable = false)
	 private Long clusterId;
	 @Column(name = "cluster_name")
     private String clusterName;
	 @Column(name = "cluster_version")
	 private Integer clusterVersion;	 
	 @Column(name = "group_id")
	 private Long groupId;
	 @Transient
	 private String operationType;
	 @Column(name = "pending_requests_count")
	 private Integer pendingRequestsCount;
	 @Transient
	 private List<Long> deletedPartitionIds=new ArrayList<Long>();
	 
	

	 @JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
		@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER
				)
		@JoinColumn(name = "cluster_id")
		private List<ClusterPartitionsRelationship> clusterPartitionsRelationships = new ArrayList<ClusterPartitionsRelationship>();
		
	 
	 @Transient
	 private String code;
	 @Transient
	 private String message;
	 
		@Column(name="last_operation_performed")
		private String lastOperationPerformed;
		@Column(name="error_message")
		private String errorMessage;
		@Column(name="last_operation_status")
		private String lastOperationStatus;
		@Column(name = "created_by")
		private String createdBy;
		
	/**
	 * @return the clusterId
	 */
	public Long getClusterId() {
		return clusterId;
	}
	/**
	 * @param clusterId the clusterId to set
	 */
	public void setClusterId(Long clusterId) {
		this.clusterId = clusterId;
	}
	/**
	 * @return the clusterName
	 */
	public String getClusterName() {
		return clusterName;
	}
	/**
	 * @param clusterName the clusterName to set
	 */
	public void setClusterName(String clusterName) {
		this.clusterName = clusterName;
	}
	 
	/**
	 * @return the clusterPartitionsRelationships
	 */
	public List<ClusterPartitionsRelationship> getClusterPartitionsRelationships() {
		return clusterPartitionsRelationships;
	}
	/**
	 * @param clusterPartitionsRelationships the clusterPartitionsRelationships to set
	 */
	public void setClusterPartitionsRelationships(List<ClusterPartitionsRelationship> clusterPartitionsRelationships) {
		this.clusterPartitionsRelationships = clusterPartitionsRelationships;
	}
	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}
	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}
	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	/**
	 * @return the clusterVersion
	 */
	public Integer getClusterVersion() {
		return clusterVersion;
	}
	/**
	 * @param clusterVersion the clusterVersion to set
	 */
	public void setClusterVersion(Integer clusterVersion) {
		this.clusterVersion = clusterVersion;
	}
	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}
	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	/**
	 * @return the groupId
	 */
 
	/**
	 * @return the lastOperationPerformed
	 */
	public String getLastOperationPerformed() {
		return lastOperationPerformed;
	}
	/**
	 * @param lastOperationPerformed the lastOperationPerformed to set
	 */
	public void setLastOperationPerformed(String lastOperationPerformed) {
		this.lastOperationPerformed = lastOperationPerformed;
	}
	/**
	 * @return the lastOperationStatus
	 */
	public String getLastOperationStatus() {
		return lastOperationStatus;
	}
	/**
	 * @param lastOperationStatus the lastOperationStatus to set
	 */
	public void setLastOperationStatus(String lastOperationStatus) {
		this.lastOperationStatus = lastOperationStatus;
	}
	/**
	 * @return the groupId
	 */
	public Long getGroupId() {
		return groupId;
	}
	/**
	 * @param groupId the groupId to set
	 */
	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}
	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	/**
	 * @return the deletedPartitionIds
	 */
	public List<Long> getDeletedPartitionIds() {
		return deletedPartitionIds;
	}
	/**
	 * @param deletedPartitionIds the deletedPartitionIds to set
	 */
	public void setDeletedPartitionIds(List<Long> deletedPartitionIds) {
		this.deletedPartitionIds = deletedPartitionIds;
	}
	/**
	 * @return the operationType
	 */
	public String getOperationType() {
		return operationType;
	}
	/**
	 * @param operationType the operationType to set
	 */
	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}
	/**
	 * @return the pendingRequestsCount
	 */
	public Integer getPendingRequestsCount() {
		return pendingRequestsCount;
	}
	/**
	 * @param pendingRequestsCount the pendingRequestsCount to set
	 */
	public void setPendingRequestsCount(Integer pendingRequestsCount) {
		this.pendingRequestsCount = pendingRequestsCount;
	}
	 
}
