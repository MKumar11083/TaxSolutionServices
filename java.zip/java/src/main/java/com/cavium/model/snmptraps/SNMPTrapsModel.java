package com.cavium.model.snmptraps;

import java.io.Serializable;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "snmp_trap_recvr")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class SNMPTrapsModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2112532259741278382L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "snmp_id")
	private Long snmpId;
	@Column(name = "message_recvd")
	private String messageRecvd;
	@Column(name = "appliance_ip")
	private String applianceIp;
	
	
	
	/**
	 * @return the snmpId
	 */
	public Long getSnmpId() {
		return snmpId;
	}
	/**
	 * @param snmpId the snmpId to set
	 */
	public void setSnmpId(Long snmpId) {
		this.snmpId = snmpId;
	}
	/**
	 * @return the messageRecvd
	 */
	public String getMessageRecvd() {
		return messageRecvd;
	}
	/**
	 * @param messageRecvd the messageRecvd to set
	 */
	public void setMessageRecvd(String messageRecvd) {
		this.messageRecvd = messageRecvd;
	}
	/**
	 * @return the applianceIp
	 */
	public String getApplianceIp() {
		return applianceIp;
	}
	/**
	 * @param applianceIp the applianceIp to set
	 */
	public void setApplianceIp(String applianceIp) {
		this.applianceIp = applianceIp;
	}	
}
