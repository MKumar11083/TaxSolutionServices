package com.cavium.model.hostadminvm.monitorstats;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name="monitor_stats_memory_details")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Memory
{
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "memory_id", nullable = false)
	private Long memoryId;
	
	@JsonManagedReference
	@OneToMany(fetch = FetchType.LAZY,mappedBy="memory", cascade = CascadeType.ALL)
    private List<Details> details;
	
	@Column(name = "usage_in_percentage")
    private String usageInPercentage;
	
	@JsonManagedReference
	@OneToMany(fetch = FetchType.LAZY,mappedBy="memory", cascade = CascadeType.ALL)
    private List<Usage> usage;
	
	@Column(name = "updated_time")
    private String updatedTime;

	/**
	 * @return the memoryId
	 */
	public Long getMemoryId() {
		return memoryId;
	}

	/**
	 * @param memoryId the memoryId to set
	 */
	public void setMemoryId(Long memoryId) {
		this.memoryId = memoryId;
	}

	/**
	 * @return the details
	 */
	public List<Details> getDetails() {
		return details;
	}

	/**
	 * @param details the details to set
	 */
	public void setDetails(List<Details> details) {
		this.details = details;
	}

	/**
	 * @return the usageInPercentage
	 */
	public String getUsageInPercentage() {
		return usageInPercentage;
	}

	/**
	 * @param usageInPercentage the usageInPercentage to set
	 */
	public void setUsageInPercentage(String usageInPercentage) {
		this.usageInPercentage = usageInPercentage;
	}

	/**
	 * @return the usage
	 */
	public List<Usage> getUsage() {
		return usage;
	}

	/**
	 * @param usage the usage to set
	 */
	public void setUsage(List<Usage> usage) {
		this.usage = usage;
	}

	/**
	 * @return the updatedTime
	 */
	public String getUpdatedTime() {
		return updatedTime;
	}

	/**
	 * @param updatedTime the updatedTime to set
	 */
	public void setUpdatedTime(String updatedTime) {
		this.updatedTime = updatedTime;
	}
}