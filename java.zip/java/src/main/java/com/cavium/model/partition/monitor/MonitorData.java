package com.cavium.model.partition.monitor;

import java.io.Serializable;

public class MonitorData implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7194300730628675402L;
	private PartitionMonitorPMNCData cpu;
	private PartitionMonitorPMNCData pcpu;
	private PartitionMonitorPMNCData memory;
	private PartitionNetworkMonitorStats network;
	public PartitionMonitorPMNCData getCpu() {
		return cpu;
	}
	public void setCpu(PartitionMonitorPMNCData cpu) {
		this.cpu = cpu;
	}
	public PartitionMonitorPMNCData getPcpu() {
		return pcpu;
	}
	public void setPcpu(PartitionMonitorPMNCData pcpu) {
		this.pcpu = pcpu;
	}
	public PartitionMonitorPMNCData getMemory() {
		return memory;
	}
	public void setMemory(PartitionMonitorPMNCData memory) {
		this.memory = memory;
	}
	public PartitionNetworkMonitorStats getNetwork() {
		return network;
	}
	public void setNetwork(PartitionNetworkMonitorStats network) {
		this.network = network;
	}
	

}
