package com.cavium.model.partition;

import java.io.Serializable;

public class PartitionInterfacesAdvance implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -9202305065549454393L;
	
	private StaticSearchADD staticIpToHostConfig; 
	private PartitionDnsConfig dnsConfig;

	public PartitionDnsConfig getDnsConfig() {
		return dnsConfig;
	}
	public void setDnsConfig(PartitionDnsConfig dnsConfig) {
		this.dnsConfig = dnsConfig;
	}
	public StaticSearchADD getStaticIpToHostConfig() {
		return staticIpToHostConfig;
	}
	public void setStaticIpToHostConfig(StaticSearchADD staticIpToHostConfig) {
		this.staticIpToHostConfig = staticIpToHostConfig;
	}
}
