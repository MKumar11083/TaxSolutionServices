package com.cavium.model.partition.monitor;

import java.io.Serializable;


public class PartitionMonitorCWI implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8462815262191394970L;
	
	private String start;
	private Integer threshold;
	private Integer samplecount;
	
	public String getStart() {
		return start;
	}
	public void setStart(String start) {
		this.start = start;
	}
	public Integer getThreshold() {
		return threshold;
	}
	public void setThreshold(Integer threshold) {
		this.threshold = threshold;
	}
	public Integer getSamplecount() {
		return samplecount;
	}
	public void setSamplecount(Integer samplecount) {
		this.samplecount = samplecount;
	}
	
}
