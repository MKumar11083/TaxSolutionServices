package com.cavium.model.appliance;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@Entity
@Table(name="dual_factor_auth")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class DualFactorAuthDetailModel implements Serializable {
	private static final long serialVersionUID = 8893200516025118371L;
 
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	@Column(name="dual_factor_auth_server_port_no")
	private String dualFactorAuthServerPortNo;
	@Column(name="keyfile_content")
	private String keyfileContent;
	@Column(name="keyfile_name")
	private String keyfileName;
	@Column(name="keyfile_extension")
	private String keyfileExtension;	
	@Column(name="certificate_content")
	private String certificateContent;
	@Column(name="certificate_name")
	private String certificateName;
	@Column(name="certificate_extension")
	private String certificateExtension;
 
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "initialize_id", nullable = false)
	@JsonBackReference
	private InitializeApplianceDetailModel initializeApplianceDetailModel;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	 
 
 
	public InitializeApplianceDetailModel getInitializeApplianceDetailModel() {
		return initializeApplianceDetailModel;
	}
	public void setInitializeApplianceDetailModel(InitializeApplianceDetailModel initializeApplianceDetailModel) {
		this.initializeApplianceDetailModel = initializeApplianceDetailModel;
	}
	 
 
	/**
	 * @return the keyfileContent
	 */
	public String getKeyfileContent() {
		return keyfileContent;
	}
	/**
	 * @param keyfileContent the keyfileContent to set
	 */
	public void setKeyfileContent(String keyfileContent) {
		this.keyfileContent = keyfileContent;
	}
	/**
	 * @return the keyfileName
	 */
	public String getKeyfileName() {
		return keyfileName;
	}
	/**
	 * @param keyfileName the keyfileName to set
	 */
	public void setKeyfileName(String keyfileName) {
		this.keyfileName = keyfileName;
	}
	/**
	 * @return the keyfileExtension
	 */
	public String getKeyfileExtension() {
		return keyfileExtension;
	}
	/**
	 * @param keyfileExtension the keyfileExtension to set
	 */
	public void setKeyfileExtension(String keyfileExtension) {
		this.keyfileExtension = keyfileExtension;
	}
	 
	 
	/**
	 * @return the certificateContent
	 */
	public String getCertificateContent() {
		return certificateContent;
	}
	/**
	 * @param certificateContent the certificateContent to set
	 */
	public void setCertificateContent(String certificateContent) {
		this.certificateContent = certificateContent;
	}
	/**
	 * @return the certificateName
	 */
	public String getCertificateName() {
		return certificateName;
	}
	/**
	 * @param certificateName the certificateName to set
	 */
	public void setCertificateName(String certificateName) {
		this.certificateName = certificateName;
	}
	/**
	 * @return the certificateExtension
	 */
	public String getCertificateExtension() {
		return certificateExtension;
	}
	/**
	 * @param certificateExtension the certificateExtension to set
	 */
	public void setCertificateExtension(String certificateExtension) {
		this.certificateExtension = certificateExtension;
	}
	/**
	 * @return the dualFactorAuthServerPortNo
	 */
	public String getDualFactorAuthServerPortNo() {
		return dualFactorAuthServerPortNo;
	}
	/**
	 * @param dualFactorAuthServerPortNo the dualFactorAuthServerPortNo to set
	 */
	public void setDualFactorAuthServerPortNo(String dualFactorAuthServerPortNo) {
		this.dualFactorAuthServerPortNo = dualFactorAuthServerPortNo;
	}
	 
	
}
