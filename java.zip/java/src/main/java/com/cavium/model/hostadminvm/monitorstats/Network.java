package com.cavium.model.hostadminvm.monitorstats;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="monitor_stats_network_details")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Network
{
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "network_id", nullable = false)
	@JsonIgnoreProperties(ignoreUnknown = true)
	private Long networkId;
	
	@OneToOne(cascade=CascadeType.ALL,fetch = FetchType.LAZY)
	 @JoinColumn(name = "lo_id",nullable = false)
	@JsonIgnoreProperties(ignoreUnknown = true)
    private Lo lo;

	@OneToOne(cascade=CascadeType.ALL,fetch = FetchType.LAZY)
	 @JoinColumn(name = "sit_id",nullable = false)
	@JsonIgnoreProperties(ignoreUnknown = true)
    private Sit sit0;

	@OneToOne(cascade=CascadeType.ALL,fetch = FetchType.LAZY)
	 @JoinColumn(name = "eth1_id",nullable = false)
	@JsonIgnoreProperties(ignoreUnknown = true)
    private Eth1 eth1;

	@OneToOne(cascade=CascadeType.ALL,fetch = FetchType.LAZY)
	 @JoinColumn(name = "eth0_id",nullable = false)
	@JsonIgnoreProperties(ignoreUnknown = true)
    private Eth0 eth0;
	
	@Column(name = "updated_time")
	@JsonIgnoreProperties(ignoreUnknown = true)
    private String updatedTime;

	/**
	 * @return the networkId
	 */
	public Long getNetworkId() {
		return networkId;
	}

	/**
	 * @param networkId the networkId to set
	 */
	public void setNetworkId(Long networkId) {
		this.networkId = networkId;
	}

	/**
	 * @return the lo
	 */
	public Lo getLo() {
		return lo;
	}

	/**
	 * @param lo the lo to set
	 */
	public void setLo(Lo lo) {
		this.lo = lo;
	}

	/**
	 * @return the sit0
	 */
	public Sit getSit0() {
		return sit0;
	}

	/**
	 * @param sit0 the sit0 to set
	 */
	public void setSit0(Sit sit0) {
		this.sit0 = sit0;
	}

	/**
	 * @return the eth1
	 */
	public Eth1 getEth1() {
		return eth1;
	}

	/**
	 * @param eth1 the eth1 to set
	 */
	public void setEth1(Eth1 eth1) {
		this.eth1 = eth1;
	}

	/**
	 * @return the eth0
	 */
	public Eth0 getEth0() {
		return eth0;
	}

	/**
	 * @param eth0 the eth0 to set
	 */
	public void setEth0(Eth0 eth0) {
		this.eth0 = eth0;
	}

	/**
	 * @return the updatedTime
	 */
	public String getUpdatedTime() {
		return updatedTime;
	}

	/**
	 * @param updatedTime the updatedTime to set
	 */
	public void setUpdatedTime(String updatedTime) {
		this.updatedTime = updatedTime;
	}

    
}
