package com.cavium.model.partition;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Table(name = "partition_interface_general_eth")
public class PartitionETH implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -4623076425047596603L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	private Long Id;
	@Column(name="eth_name")
	private String ethName;
	@Column(name="dhcp")
	private boolean dhcp;
	@Column(name="enable")
	private boolean disableEth1;
	@Column(name="ip_address")
	private String ip;
	@Column(name="gateway")
	private String gateway;
	@Column(name="subnet_mask")
	private String subnet;
	@Column(name="hostname")
	private String hostname;
	@Column(name="static_mac")
	private boolean staticMac;
	@Column(name="mac_address")
	private String address;
	@Column(name="vlan_id")
	private Integer vlan;
	/*@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name = "partition_id", nullable = false)
	@JsonBackReference*/
	@Column(name="partition_id")
	private Long partitionId;
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	public String getEthName() {
		return ethName;
	}
	public void setEthName(String ethName) {
		this.ethName = ethName;
	}
	public boolean isDhcp() {
		return dhcp;
	}
	public void setDhcp(boolean dhcp) {
		this.dhcp = dhcp;
	}
	
	public boolean isDisableEth1() {
		return disableEth1;
	}
	public void setDisableEth1(boolean disableEth1) {
		this.disableEth1 = disableEth1;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getGateway() {
		return gateway;
	}
	public void setGateway(String gateway) {
		this.gateway = gateway;
	}
	public String getHostname() {
		return hostname;
	}
	public void setHostname(String hostname) {
		this.hostname = hostname;
	}
	public boolean isStaticMac() {
		return staticMac;
	}
	public void setStaticMac(boolean staticMac) {
		this.staticMac = staticMac;
	}
	
	public Long getPartitionId() {
		return partitionId;
	}
	public void setPartitionId(Long partitionId) {
		this.partitionId = partitionId;
	}
	public String getSubnet() {
		return subnet;
	}
	public void setSubnet(String subnet) {
		this.subnet = subnet;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Integer getVlan() {
		return vlan;
	}
	public void setVlan(Integer vlan) {
		this.vlan = vlan;
	}
	
}
