package com.cavium.model.partition.monitor;

import java.io.Serializable;

public class PartitionMonitorPMNCData implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5729023701579161102L;
	private PartitionMonitorCWI info;
	private PartitionMonitorCWI warn;
	private PartitionMonitorCWI crit;
	public PartitionMonitorCWI getInfo() {
		return info;
	}
	public void setInfo(PartitionMonitorCWI info) {
		this.info = info;
	}
	public PartitionMonitorCWI getWarn() {
		return warn;
	}
	public void setWarn(PartitionMonitorCWI warn) {
		this.warn = warn;
	}
	public PartitionMonitorCWI getCrit() {
		return crit;
	}
	public void setCrit(PartitionMonitorCWI crit) {
		this.crit = crit;
	}
}
