package com.cavium.model.user;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

/*
 * ApplicationDetailModel Model class for Application Details along with Permission Details
 * author : RK00490847
 */

@Entity
@Table(name="application")
public class ApplicationDetailModel implements Serializable {

	private static final long serialVersionUID = 1159336588605492376L;
	@Id
	@Column(name="id",nullable = false)
	private Long applicationId;
	@Column(name="short_app_name")
	private String shortAppName;	 
	@Column(name="app_name")
	private String appName;

	@OneToMany(
			cascade = CascadeType.ALL, 
			fetch = FetchType.LAZY
			)	 
	@JoinColumn(name = "app_id")
	@JsonManagedReference
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	private List<PermisssionDetailModel>listPermission= new ArrayList<PermisssionDetailModel>();

	public List<PermisssionDetailModel> getListPermission() {
		return listPermission;
	}
	public void setListPermission(List<PermisssionDetailModel> listPermission) {
		this.listPermission = listPermission;
	}
	/**
	 * @return the applicationId
	 */
	public Long getApplicationId() {
		return applicationId;
	}
	/**
	 * @param applicationId the applicationId to set
	 */
	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}

	/**
	 * @return the appName
	 */
	public String getAppName() {
		return appName;
	}
	/**
	 * @param appName the appName to set
	 */
	public void setAppName(String appName) {
		this.appName = appName;
	}
	/**
	 * @return the shortAppName
	 */
	public String getShortAppName() {
		return shortAppName;
	}
	/**
	 * @param shortAppName the shortAppName to set
	 */
	public void setShortAppName(String shortAppName) {
		this.shortAppName = shortAppName;
	}
}
