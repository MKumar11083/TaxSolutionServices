package com.cavium.repository.partition;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cavium.pojo.partitionstats.PartitionStatsDetails;


@Repository
public interface PartitionStatsRepository extends JpaRepository<PartitionStatsDetails, Long> {
	
	
	@Query(value="select * from partition_stats_details partitionstats where partitionstats.partition_id= :partitionId order by partitionstats.created_date desc",nativeQuery=true)
	   public List<PartitionStatsDetails> getPartitionStats(@Param("partitionId") Long partitionId);

}
