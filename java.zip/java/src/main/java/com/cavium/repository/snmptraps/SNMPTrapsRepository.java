package com.cavium.repository.snmptraps;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.cavium.model.snmptraps.SNMPTrapsModel;

@Repository
public interface SNMPTrapsRepository  extends JpaRepository<SNMPTrapsModel, Long> {
	

}
