package com.cavium.repository.partition;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cavium.model.partition.PartitionDetailModel;

@Repository
public interface PartitionRepository extends JpaRepository<PartitionDetailModel, Long> {

	@Query(value="select  * from partition_configuration p join appliance_details a on \r\n" + 
			"  a.appliance_id=p.appliance_id where p.created_by=:userName",nativeQuery=true)
	public List<PartitionDetailModel> getListOfPartitionByLoggedInUser(@Param("userName") String userName);
	
	@Modifying
  	@Query("update PartitionDetailModel part set part.status=:status where part.partitionId=:partitionId")
  	public int updateStatus(@Param("status") String status,@Param("partitionId") Long partitionId);
	
	@Query(value="select  * from partition_configuration p where p.appliance_id=:applianceId",nativeQuery=true)
	public List<PartitionDetailModel> getListOfPartitionByApplianceID(@Param("applianceId") Long applianceId);
	
	@Query(value="select  * from partition_configuration p where p.appliance_id=:applianceId and p.partition_name=:partitionName",nativeQuery=true)
	public List<PartitionDetailModel> getListOfPartitionByPartitionNameAndApplianceId(@Param("partitionName") String partitionName,@Param("applianceId") Long applianceId); 
	
	
	@Query(value="select count(*) from partition_configuration where appliance_id=:applianceId ",nativeQuery=true)
	public int numberOfPartitionsforAppliance(@Param("applianceId") Long applianceId);
	
	@Transactional
	@Modifying
	@Query(value="update partition_configuration set last_operation_status=:lastOperationStatus ,status=:status , error_message=:errorMessage ,last_operation_performed=:lastOperationPerformed where partition_id=:partitionId",nativeQuery=true)
	public int updatePartitionStatus(@Param("status") String status,@Param("lastOperationStatus") String lastOperationStatus,@Param("lastOperationPerformed") String lastOperationPerformed,@Param("errorMessage") String errorMessage,@Param("partitionId") Long partitionId);
	
	@Transactional
	@Modifying
	@Query(value="update partition_configuration set part_of_cluster=:updatePartOfCluster  where partition_id=:partitionId",nativeQuery=true)
	public int updatePartOfCluster(@Param("updatePartOfCluster") boolean updatePartOfCluster,@Param("partitionId") Long partitionId);
	
	@Query(value="select * from partition_configuration p, appliance_details a, designation_appliance d, user_details u"
			+ "  where u.user_id=:userName and a.appliance_id=p.appliance_id and d.appliance_id=a.appliance_id  and u.role=d.design_id",nativeQuery=true)
	public List<PartitionDetailModel> getListOfPartitionByGroupId(@Param("userName") String userName);
	

	@Query(value="select * from partition_configuration p, appliance_details a, designation_appliance d, user_details u"
			+ "  where a.appliance_id=p.appliance_id and d.appliance_id=a.appliance_id  and u.role=d.design_id and p.part_of_cluster=0 and u.acl_id=:aclId",nativeQuery=true)
	public List<PartitionDetailModel> getListOfAllNotAssignedPartitions(@Param("aclId") Long aclId);
	
	@Query(value="select * from partition_configuration p, appliance_details a, designation_appliance d, user_details u"
			+ "  where u.user_id=:userName and a.appliance_id=p.appliance_id and d.appliance_id=a.appliance_id  and u.role=d.design_id and p.part_of_cluster=0",nativeQuery=true)
	public List<PartitionDetailModel> getListOfNotAssignedPartitionsByGroupId(@Param("userName") String userName);
	
	
	@Query(value="select partition_id from partition_configuration",nativeQuery=true)
	public List<Integer> getAllPartitions();
	
	@Transactional
	@Modifying
	@Query(value="update partition_configuration set previous_performed_operation_status=last_operation_status  where appliance_id=:applianceId",nativeQuery=true)
	public int maintainLastOperationStatus(@Param("applianceId") Long applianceId);
	
	@Query(value="select appliance_id from partition_configuration where partition_id=:partitionId",nativeQuery=true)
	 public  Long getApplianceIdfromPartitionId(@Param("partitionId") Long partitionId);
	
	@Transactional
	@Modifying
	@Query(value="update partition_configuration set grayed_out=:grayedOut  where appliance_id=:applianceId",nativeQuery=true)
	public int updateGrayedOut(@Param("grayedOut") boolean grayedOut,@Param("applianceId") Long applianceId);
	
	
	
	
	@Query(value="select count(*) from partition_configuration where appliance_id=:applianceId and last_operation_status='In-Progress'",nativeQuery=true)
	 public  int getNumberofInprogressPartitions(@Param("applianceId") Long applianceId);
	
	@Query(value="select partition_id  from partition_configuration p where p.appliance_id=:applianceId",nativeQuery=true)
	public List<Integer> getListOfPartitionIdByApplianceID(@Param("applianceId") Long applianceId);
}
