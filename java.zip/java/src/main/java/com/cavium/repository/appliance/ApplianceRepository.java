package com.cavium.repository.appliance;


import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.appliance.StoreType;
import com.cavium.model.recentactivity.InProgressActivity;


/**
 *  * @author MK00497144		
 * Class is used as a JPA repository to interact with the DB for Appliance and partitions
 */
@Repository
public interface ApplianceRepository
  extends JpaRepository<ApplianceDetailModel, Long>
{	
	
	@Query("select appliance from ApplianceDetailModel appliance where appliance.ipAddress = :ipAddress")
	public List<ApplianceDetailModel> getApplianceExists(@Param("ipAddress") String ipAddress);
	
	@Query(value="select  * from appliance_details a join designation_appliance d on "
			+ "d.appliance_id=a.appliance_id join user_details u on u.role=d.design_id where u.user_id= :userName and a.appliance_store_type='PERMANENT'", nativeQuery = true)
	public List<ApplianceDetailModel> getListOfApplianceByGroupId(@Param("userName") String userName);
	

@Query("SELECT appliance FROM ApplianceDetailModel appliance  WHERE appliance.storeType=:storeType and  appliance.applianceName LIKE CONCAT('%', :applianceName,'%') AND"
			+ " appliance.applianceStatus LIKE CONCAT('%',:applianceStatus,'%') AND"
			+ " appliance.ipAddress  LIKE CONCAT('%',:ipAddress,'%') AND"
	  		+ " appliance.hostName  LIKE CONCAT('%',:hostName,'%') AND"
	  		+ " appliance.ipmiIp  LIKE CONCAT('%',:ipmiIp,'%') "
	  		+ " ORDER BY appliance.applianceName ASC")
	public List<ApplianceDetailModel> serchAppliance(@Param("applianceName") String applianceName,@Param("applianceStatus") String applianceStatus,@Param("ipAddress") String ipAddress,@Param("hostName") String hostName,@Param("ipmiIp") String ipmiIp,@Param("storeType") StoreType storeType);
	

	@Query("select tempAppliance from ApplianceDetailModel tempAppliance where tempAppliance.createdBy = :createdBy and tempAppliance.storeType=:storeType")
	public List<ApplianceDetailModel> getListOfTempAppliancesByUserId(@Param("createdBy") String createdBy, @Param("storeType") StoreType storeType);
	
	@Query("select tempAppliance from ApplianceDetailModel tempAppliance where tempAppliance.applianceId = :applianceId and tempAppliance.storeType=:storeType")
	public ApplianceDetailModel getApplianceById(@Param("applianceId") Long applianceId, @Param("storeType") StoreType storeType);

	@Query("select tempAppliance from ApplianceDetailModel tempAppliance where tempAppliance.storeType=:storeType")
	public List<ApplianceDetailModel> getAllListOfAppliances(@Param("storeType") StoreType storeType);
	
	  @Query(value="select appliance_name from  appliance_details where appliance_id=:applianceId" ,nativeQuery=true)
	  public String getApplianceName(@Param("applianceId") Long applianceId);
	  
	    @Transactional
		@Modifying
		@Query(value="update appliance_details set credential_saved=:credentialSaved ,appliance_initialized=:applianceinitialized ,initialized__through_cavium=:initializedthroughCavium, appliance_dual_factor_initialized=:dualFactorInitialized where appliance_id=:applianceId",nativeQuery=true)
		public int updateApplianceStatus(@Param("credentialSaved") boolean credentialSaved,@Param("applianceinitialized") boolean applianceinitialized,@Param("initializedthroughCavium") boolean initializedthroughCavium,@Param("dualFactorInitialized") boolean dualFactorInitialized, @Param("applianceId") Long applianceId);
	    
	    
	    @Transactional
	    @Modifying
	  	@Query(value="delete from appliance_details where appliance_id = :applianceId",nativeQuery=true)
	  	public int deleteAppliance(@Param("applianceId") Long applianceId);
	    
	    
	    @Query(value="select count(*) from  appliance_details where ip_address=:ipAddress" ,nativeQuery=true)
		  public int checkIpExistorNot(@Param("ipAddress") String ipAddress);
	    
	    @Query(value="select count(*) from appliance_details  where appliance_store_type=:storeType",nativeQuery=true)
		public int getTotalNumberOfAppliances(@Param("storeType") String storeType);
	    
	    

		  @Query(value="select * from  appliance_details where appliance_name=:applianceName" ,nativeQuery=true)
		  public List<ApplianceDetailModel> getApplianceNameByGivenName(@Param("applianceName") String applianceName);
		  
		  @Transactional
		 @Modifying
		 @Query("update ApplianceDetailModel appliance set appliance.ipAddress=:newIpAddress where appliance.ipAddress=:ipAddress")
		  public int updateApplianceIp(@Param("newIpAddress") String newIpAddress,@Param("ipAddress") String ipAddress);
		  
			 @Transactional
			@Modifying
			@Query(value="update appliance_details set grayed_out=:grayedOut  where appliance_id=:applianceId",nativeQuery=true)
			public int updateGrayedOut(@Param("grayedOut") boolean grayedOut,@Param("applianceId") Long applianceId);
	    
}
