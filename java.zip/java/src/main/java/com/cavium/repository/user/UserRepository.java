package com.cavium.repository.user;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cavium.model.user.Status;
import com.cavium.model.user.TemporaryPassword;
import com.cavium.model.user.UserACLDetailsModel;
import com.cavium.model.user.UserDetailModel;
import com.cavium.model.user.UserGroupModel;

@Repository
public interface UserRepository
  extends JpaRepository<UserDetailModel, String>
{
 
  @Query("SELECT objUserDetailModel FROM UserDetailModel objUserDetailModel  WHERE objUserDetailModel.userName LIKE CONCAT('%', :userName,'%') AND objUserDetailModel.firstName LIKE CONCAT('%',:firstName,'%') AND objUserDetailModel.lastName  LIKE CONCAT('%',:lastName,'%')"
  		+ "AND objUserDetailModel.emailId  LIKE CONCAT('%',:emailId,'%') AND objUserDetailModel.phoneNumber  LIKE CONCAT('%',:phoneNumber,'%') AND (convert(objUserDetailModel.objUserGroupModel.id,char) LIKE :role or objUserDetailModel.objUserGroupModel.username like :createdBy) "
  		+ "ORDER BY objUserDetailModel.userName, objUserDetailModel.firstName, objUserDetailModel.lastName ,objUserDetailModel.emailId,objUserDetailModel.phoneNumber ASC")
  	 
  	/*	 @Query("SELECT objUserDetailModel FROM UserDetailModel objUserDetailModel  WHERE objUserDetailModel.userName LIKE CONCAT('%', :userName,'%') AND objUserDetailModel.firstName LIKE CONCAT('%',:firstName,'%') AND objUserDetailModel.lastName  LIKE CONCAT('%',:lastName,'%')"
  		+ "AND objUserDetailModel.emailId  LIKE CONCAT('%',:emailId,'%') AND objUserDetailModel.phoneNumber  LIKE CONCAT('%',:phoneNumber,'%') and objUserDetailModel.objUserGroupModel :concat "
  		+ "ORDER BY objUserDetailModel.userName, objUserDetailModel.firstName, objUserDetailModel.lastName ,objUserDetailModel.emailId,objUserDetailModel.phoneNumber ASC")
 */
 public List<UserDetailModel> searchUserDetails(@Param("userName") String userName, @Param("firstName") String firstName, @Param("lastName") String lastName,@Param("emailId") String emailId, @Param("phoneNumber") String phoneNumber,@Param("role") String role ,@Param("createdBy") String createdBy);
  
  @Query("SELECT objUserDetailModel FROM UserDetailModel objUserDetailModel  WHERE  objUserDetailModel.objUserGroupModel=:roleId and objUserDetailModel.userName LIKE CONCAT('%', :userName,'%') AND objUserDetailModel.firstName LIKE CONCAT('%',:firstName,'%') AND objUserDetailModel.lastName  LIKE CONCAT('%',:lastName,'%') ORDER BY objUserDetailModel.userName, objUserDetailModel.firstName, objUserDetailModel.lastName ASC")
  public List<UserDetailModel> searchUserDetailsByGroup(@Param("userName") String userName, @Param("firstName") String firstName, @Param("lastName") String lastName, @Param("roleId") UserGroupModel objUserGroupModel);
  
  @Query("SELECT objUserDetailModel FROM UserDetailModel objUserDetailModel  WHERE  objUserDetailModel.objUserGroupModel=:roleId and objUserDetailModel.objUserACLDetailsModel=:aclId and objUserDetailModel.userName LIKE CONCAT('%', :userName,'%') AND objUserDetailModel.firstName LIKE CONCAT('%',:firstName,'%') AND objUserDetailModel.lastName  LIKE CONCAT('%',:lastName,'%') ORDER BY objUserDetailModel.userName, objUserDetailModel.firstName, objUserDetailModel.lastName ASC")
  public List<UserDetailModel> searchUserDetailsByGroupAndACL(@Param("userName") String userName, @Param("firstName") String firstName, @Param("lastName") String lastName, @Param("roleId") UserGroupModel objUserGroupModel, @Param("aclId") UserACLDetailsModel objUserACLDetailsModel);
  
  
  @Query("SELECT objUserDetailModel FROM UserDetailModel objUserDetailModel  WHERE  objUserDetailModel.objUserACLDetailsModel=:aclId and objUserDetailModel.userName LIKE CONCAT('%', :userName,'%') AND objUserDetailModel.firstName LIKE CONCAT('%',:firstName,'%') AND objUserDetailModel.lastName  LIKE CONCAT('%',:lastName,'%') AND convert(objUserDetailModel.objUserGroupModel.id,char) LIKE :role ORDER BY objUserDetailModel.userName, objUserDetailModel.firstName, objUserDetailModel.lastName ASC")
  public List<UserDetailModel> searchUserDetailsByACL(@Param("userName") String userName, @Param("firstName") String firstName, @Param("lastName") String lastName, @Param("aclId") UserACLDetailsModel objUserACLDetailsModel ,@Param("role") String role);
  
  @Query("SELECT objUserDetailModel FROM UserDetailModel objUserDetailModel  WHERE objUserDetailModel.userName LIKE CONCAT('%', :userName,'%') AND objUserDetailModel.firstName LIKE CONCAT('%',:firstName,'%') AND objUserDetailModel.lastName  LIKE CONCAT('%',:lastName,'%') ORDER BY objUserDetailModel.userName, objUserDetailModel.firstName, objUserDetailModel.lastName ASC")
  public List<UserDetailModel> searchTotalNumberOfUsers(@Param("userName") String userName, @Param("firstName") String firstName, @Param("lastName") String lastName);
  
  @Query("SELECT objUserDetailModel FROM UserDetailModel objUserDetailModel  WHERE  objUserDetailModel.objUserGroupModel=:roleId and objUserDetailModel.userName LIKE CONCAT('%', :userName,'%') AND objUserDetailModel.firstName LIKE CONCAT('%',:firstName,'%') AND objUserDetailModel.lastName  LIKE CONCAT('%',:lastName,'%') ORDER BY objUserDetailModel.userName, objUserDetailModel.firstName, objUserDetailModel.lastName ASC")
  public List<UserDetailModel> searchTotalNumberOfUsersByGroup(@Param("userName") String userName, @Param("firstName") String firstName, @Param("lastName") String lastName, @Param("roleId") UserGroupModel objUserGroupModel);

  @Modifying
  @Query("update UserDetailModel user set user.firstName = :firstName,user.lastName = :lastName,user.emailId =:emailId,user.objUserGroupModel=:roleId,"+ 
		  "user.phoneNumber = :phoneNumber,user.status = :status,user.message=:message,"+
		  "user.temporaryPassword=:temporaryPassword,user.objUserACLDetailsModel= :aclId where user.userName = :userName")
  public int updateUserDetails(@Param("firstName") String firstName, @Param("lastName") String lastName, @Param("emailId") String emailId,
		  @Param("roleId") UserGroupModel objUserGroupModel ,@Param("phoneNumber") String phoneNumber,@Param("status") Status status,
		  @Param("message") String message,@Param("temporaryPassword") TemporaryPassword temporaryPassword,@Param("userName") String userName, @Param("aclId") UserACLDetailsModel objUserACLDetailsModel);
  
  	@Modifying
  	@Query("update UserDetailModel user set user.password=:newpassword where user.userName = :userid")
  	public int updatePassword(@Param("newpassword") String password,@Param("userid") String userid);
  	
  	@Modifying
  	@Query("update UserDetailModel user set user.temporaryPassword=:temporaryPassword  where user.userName = :userid")
  	public int updateTempPassword(@Param("temporaryPassword") TemporaryPassword temporaryPassword,@Param("userid") String userid);
  	
    @Modifying
  	@Query("DELETE FROM UserDetailModel objUserDetailModel where objUserDetailModel.userName = :userid")
  	public int deleteUser(@Param("userid") String userid);
    @Modifying
  	@Query("update UserDetailModel user set user.objUserGroupModel=:deletedGroupId,user.status='SUSPENDED' where user.objUserGroupModel=:roleId")
  	public int updateUserRole(@Param("roleId") UserGroupModel objUserGroupModel,@Param("deletedGroupId") UserGroupModel deletedGroupId);
    	
    @Query(value="select user.role from user_details user  where user.user_id = :userName",nativeQuery=true)
  	public String getRoleID(@Param("userName") String userName);
    
    @Query(value="select acl_id ,count(*) from user_details group by acl_id",nativeQuery=true)
  	 public List<Object[]>  getNumberOfUsersForEachACL();
  	 
  	@Query(value="select count(*) from user_details where role=:groupId and acl_id in (select id from acl_details where descr=\"GroupAdmin\")",nativeQuery=true)
 	 public  int getGroupAdimUserForUserGroup(@Param("groupId") Long groupId);
  	
  	@Query(value="select count(*) from user_details where role=:groupId and acl_id in (select id from acl_details where descr=\"SecondaryUser\")",nativeQuery=true)
	 public  int getSecondaryUserForUserGroup(@Param("groupId") Long groupId);
   
  	
  	@Query(value="select login_failure_count  from user_details where user_id = :userId",nativeQuery=true)
	 public  int getLoginFailureCount(@Param("userId") String userId);
  	
  	@Transactional
	@Modifying
 	@Query(value="update user_details set login_failure_count=:failureCount where user_id = :userId",nativeQuery=true)
	 public  int updateLoginFailureCount(@Param("userId") String userId,@Param("failureCount") Long failureCount);
  	
	@Query(value="select login_failure_count from user_details where user_id = :userId",nativeQuery=true)
	 public  int getNumberofLogInFailureCount(@Param("userId") String userId);
	
	@Query(value="select  a.network_timezone from appliance_details a \r\n" + 
			"join designation_appliance d on \r\n" + 
			"d.appliance_id=a.appliance_id join \r\n" + 
			"user_details u on \r\n" + 
			"u.role=d.design_id \r\n" + 
			"where u.user_id=:userId and a.appliance_store_type='PERMANENT'",nativeQuery=true)
	public List<String> getTimeZoneByUserName(@Param("userId") String userId);
	
	
	  @Query("SELECT userDetail FROM UserDetailModel userDetail WHERE  userDetail.createdBy=:loggedInUser")
	  public List<UserDetailModel>   getListUsersOnBasisOfCreatedBy (@Param("loggedInUser") String loggedInUser);
	  
	  	@Transactional
		@Modifying
	 	@Query(value="update user_details set login_status=:loginStatus where user_id = :userId",nativeQuery=true)
		 public  int updateLoginStatus(@Param("userId") String userId,@Param("loginStatus") boolean loginStatus);
	  
	  	@Query(value="select count(*) from user_details where login_status = :loginStatus",nativeQuery=true)
		 public  int getTotalNumberOfLoginUsers(@Param("loginStatus") boolean loginStatus);
	  	
	   
}
