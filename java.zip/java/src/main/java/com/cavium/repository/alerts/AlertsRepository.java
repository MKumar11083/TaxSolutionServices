package com.cavium.repository.alerts;


import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cavium.model.alerts.Alerts;

@Repository
public interface AlertsRepository  extends JpaRepository<Alerts, String> {
	
	
	@Query(value="select * from alerts alert where alert.user_groupid= :usergroupid && alert.module_Type= :moduleType order by alert.created_date desc",nativeQuery=true)
	public List<Alerts> getAlerts(@Param("usergroupid") String usergroupid,@Param("moduleType") String moduleType);
	
	    @Transactional
	    @Modifying
	  	@Query(value="delete from alerts where module_id = :applianceId",nativeQuery=true)
	  	public int deleteAlertsByApplianceId(@Param("applianceId") Long applianceId);
	    
	    @Query(value="select * from alerts alert where alert.user_groupid= :usergroupid order by alert.created_date desc",nativeQuery=true)
		public List<Alerts> getAlertsForDashboard(@Param("usergroupid") String usergroupid);
	
	    @Query(value="select * from alerts alert where alert.user_groupid= :usergroupid && already_read=:alreadyRead order by alert.created_date asc LIMIT 1",nativeQuery=true)
		public Alerts getAlertForNotification(@Param("alreadyRead") boolean alreadyRead,@Param("usergroupid") String usergroupid);
	 
		@Transactional
		@Modifying
		@Query(value="update alerts set already_read=:alreadyRead  where id=:id",nativeQuery=true)
		 public int updateAlreadyReadValue(@Param("alreadyRead") boolean alreadyRead,@Param("id") Long id);
		
		@Transactional
		@Modifying
		@Query(value="update alerts set appliance_ip=:applianceNewIp  where appliance_ip=:ipAddress",nativeQuery=true)
		public int updateIpAddress(@Param("applianceNewIp") String applianceNewIp, @Param("ipAddress") String ipAddress);
		
		 @Query(value="select * from alerts where appliance_id=:applianceid order by created_date desc limit 1",nativeQuery=true)
		 public Alerts getAlertByApplainceId(@Param("applianceid") Long applianceid);
}
