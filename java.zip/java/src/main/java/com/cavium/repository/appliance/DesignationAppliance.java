package com.cavium.repository.appliance;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cavium.model.user.DesignationApplianceModel;

@Repository
public interface DesignationAppliance extends JpaRepository<DesignationApplianceModel, Long> {
	
	@Modifying
	@Query(value="update designation_appliance set design_id=:designid where appliance_id=:applianceId",nativeQuery=true)
	public int updateDesignationId(@Param("designid") Long designid,@Param("applianceId") Long applianceId); 
	
	@Query(value="select * from designation_appliance where appliance_id=:applainceId",nativeQuery=true)
	public DesignationApplianceModel getDesignationModelByApplianceId(@Param("applainceId") Long applainceId);
		
	@Transactional
    @Modifying
  	@Query(value="delete from designation_appliance where appliance_id=:applianceId",nativeQuery=true)
  	public int deleteDesignationAppliance(@Param("applianceId") Long applianceId);
}
