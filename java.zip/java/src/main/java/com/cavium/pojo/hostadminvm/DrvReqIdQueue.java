package com.cavium.pojo.hostadminvm;

public class DrvReqIdQueue {
	 private double head;
	 private double tail;
	/**
	 * @return the head
	 */
	public double getHead() {
		return head;
	}
	/**
	 * @param head the head to set
	 */
	public void setHead(double head) {
		this.head = head;
	}
	/**
	 * @return the tail
	 */
	public double getTail() {
		return tail;
	}
	/**
	 * @param tail the tail to set
	 */
	public void setTail(double tail) {
		this.tail = tail;
	}
	 
	}