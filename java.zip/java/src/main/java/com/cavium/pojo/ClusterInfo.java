/*package com.cavium.pojo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "cluster_details")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class ClusterInfo {
	
	 private static final long serialVersionUID = -3840562434180092945L;

	 @Id
     @GeneratedValue(strategy=GenerationType.IDENTITY)
	 @Column(name = "cluster_id", nullable = false)
	 private Long clusterId;
	 
     private String clusterName;
	 
	 @OneToMany(fetch = FetchType.LAZY,mappedBy="ClusterInfo",cascade = CascadeType.ALL)
	 private List<Long> partitionsId = new ArrayList<Long>();
	 
	 @Transient
	 private String code;
	 @Transient
	 private String message;
	 
	 public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Long getClusterId() {
		return clusterId;
	}

	public void setClusterId(Long clusterId) {
		this.clusterId = clusterId;
	}

	public List<Long> getPartitionsId() {
		return partitionsId;
	}

	public void setPartitionsId(List<Long> partitionsId) {
		this.partitionsId = partitionsId;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
	 public String getClusterName() {
		return clusterName;
	 }
	 
	 public void setClusterName(String clusterName) {
		this.clusterName = clusterName;
	 }
	 
	 public List<Long> getPartitions() {
		return partitionsId;
	 }
	 
	 public void setPartitions(List<Long> partitionsId) {
		this.partitionsId = partitionsId;
	 }
	

}
*/