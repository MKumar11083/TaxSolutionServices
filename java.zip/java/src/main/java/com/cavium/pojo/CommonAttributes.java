package com.cavium.pojo;

import java.io.Serializable;

import org.springframework.stereotype.Component;

/**
 * @author PK0041117
 * 
 */
@Component
public class CommonAttributes implements Serializable {

	/**
	 * 
	 */ 
	private static final long serialVersionUID = 1L;
	private String userId;
	private String password;
	private String firstName;
	private String lastName;
	private String emailAddress;
	

	private String lastLoginTime;
	private String phoneNumber;
	
	private String elementSelected;
	
	public String getElementSelected() {
		return elementSelected;
	}

	public void setElementSelected(String elementSelected) {
		this.elementSelected = elementSelected;
	}
	

	// private String protectionTier;
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId
	 *            the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName
	 *            the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName
	 *            the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * @param emailAddress
	 *            the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	/**
	 * @return the lastLoginTime
	 */
	public String getLastLoginTime() {
		return lastLoginTime;
	}

	/**
	 * @param lastLoginTime
	 *            the lastLoginTime to set
	 */
	public void setLastLoginTime(String lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}

	/**
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * @param phoneNumber
	 *            the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	/**
	 * @return the protectionTier
	 */
	/*
	 * public String getProtectionTier() { return protectionTier; } /**
	 * 
	 * @param protectionTier the protectionTier to set
	 */
	/*
	 * public void setProtectionTier(String protectionTier) {
	 * this.protectionTier = protectionTier; }
	 */

	/**
	 * @return a string representation of this CommonAttribute, containing the
	 *         String representation of each element of Customer details.
	 */
	@Override
	public String toString() {
		return "CommonAttribute [userId =" + userId + ", firstName ="
				+ firstName + ", lastName =" + lastName + ", emailAddress ="
				+ emailAddress + ", lastLoginTime  =" + lastLoginTime
				+ ", phoneNumber  =" + phoneNumber + "]";
	}
}
