package com.cavium.pojo.logs;

import java.util.ArrayList;

public class Host
{
  private ArrayList<String> options;

  public ArrayList<String> getOptions() { return this.options; }

  public void setOptions(ArrayList<String> options) { this.options = options; }
}
