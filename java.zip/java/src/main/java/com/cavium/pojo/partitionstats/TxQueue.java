package com.cavium.pojo.partitionstats;
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

@Entity
@Table(name = "partition_stats_tx_queue_details")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class TxQueue implements Serializable {
	

/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
@JsonProperty(access = Access.WRITE_ONLY)
@Column(name = "id", nullable = false)
private Long id;

@Column(name = "tdh")
 private Long tdh;

@Column(name = "tdt")
 private Long tdt;
/**
 * @return the tdh
 */
public Long getTdh() {
	return tdh;
}
/**
 * @param tdh the tdh to set
 */
public void setTdh(Long tdh) {
	this.tdh = tdh;
}
/**
 * @return the tdt
 */
public Long getTdt() {
	return tdt;
}
/**
 * @param tdt the tdt to set
 */
public void setTdt(Long tdt) {
	this.tdt = tdt;
}
/**
 * @return the id
 */
public Long getId() {
	return id;
}
/**
 * @param id the id to set
 */
public void setId(Long id) {
	this.id = id;
}

 
}