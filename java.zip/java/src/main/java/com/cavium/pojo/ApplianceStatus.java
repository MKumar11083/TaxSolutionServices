package com.cavium.pojo;

public class ApplianceStatus {
	
	private int activeStatus;
	private int inactiveStatus;
	private int suspendedStatus;
	/**
	 * @return the activeStatus
	 */
	public int getActiveStatus() {
		return activeStatus;
	}
	/**
	 * @param activeStatus the activeStatus to set
	 */
	public void setActiveStatus(int activeStatus) {
		this.activeStatus = activeStatus;
	}
	/**
	 * @return the inactiveStatus
	 */
	public int getInactiveStatus() {
		return inactiveStatus;
	}
	/**
	 * @param inactiveStatus the inactiveStatus to set
	 */
	public void setInactiveStatus(int inactiveStatus) {
		this.inactiveStatus = inactiveStatus;
	}
	/**
	 * @return the suspendedStatus
	 */
	public int getSuspendedStatus() {
		return suspendedStatus;
	}
	/**
	 * @param suspendedStatus the suspendedStatus to set
	 */
	public void setSuspendedStatus(int suspendedStatus) {
		this.suspendedStatus = suspendedStatus;
	}
 

}
