package com.cavium.pojo;

import org.springframework.stereotype.Component;

@Component
public class MCOKeyCertificateDetails {
	

	private String operationUsername;
	private String operationPassword;
	private String applianceIp;
	private String applianceName;
	private long applianceId;
	/**
	 * @return the operationUsername
	 */
	public String getOperationUsername() {
		return operationUsername;
	}
	/**
	 * @param operationUsername the operationUsername to set
	 */
	public void setOperationUsername(String operationUsername) {
		this.operationUsername = operationUsername;
	}
	/**
	 * @return the operationPassword
	 */
	public String getOperationPassword() {
		return operationPassword;
	}
	/**
	 * @param operationPassword the operationPassword to set
	 */
	public void setOperationPassword(String operationPassword) {
		this.operationPassword = operationPassword;
	}
	/**
	 * @return the applianceIp
	 */
	public String getApplianceIp() {
		return applianceIp;
	}
	/**
	 * @param applianceIp the applianceIp to set
	 */
	public void setApplianceIp(String applianceIp) {
		this.applianceIp = applianceIp;
	}
	/**
	 * @return the applianceName
	 */
	public String getApplianceName() {
		return applianceName;
	}
	/**
	 * @param applianceName the applianceName to set
	 */
	public void setApplianceName(String applianceName) {
		this.applianceName = applianceName;
	}
	 
	/**
	 * @return the applianceId
	 */
	public long getApplianceId() {
		return applianceId;
	}
	/**
	 * @param applianceId the applianceId to set
	 */
	public void setApplianceId(long applianceId) {
		this.applianceId = applianceId;
	}
	 
}
