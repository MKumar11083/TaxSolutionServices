package com.cavium.pojo;

import java.util.HashMap;
import java.util.Map;

public class DeviceDiscoveryDetail {
	
	private String ipAddress;
	private String ipAddressStartingRange;
	private String ipAddressEndRange;
	private Map<String,Object> ipDiscoveryResults = new HashMap<String,Object>();
	private String errorMessage;
	/**
	 * @return the ipAddress
	 */
	public String getIpAddress() {
		return ipAddress;
	}
	/**
	 * @param ipAddress the ipAddress to set
	 */
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	/**
	 * @return the ipAddressStartingRange
	 */
	public String getIpAddressStartingRange() {
		return ipAddressStartingRange;
	}
	/**
	 * @param ipAddressStartingRange the ipAddressStartingRange to set
	 */
	public void setIpAddressStartingRange(String ipAddressStartingRange) {
		this.ipAddressStartingRange = ipAddressStartingRange;
	}
	/**
	 * @return the ipAddressEndRange
	 */
	public String getIpAddressEndRange() {
		return ipAddressEndRange;
	}
	/**
	 * @param ipAddressEndRange the ipAddressEndRange to set
	 */
	public void setIpAddressEndRange(String ipAddressEndRange) {
		this.ipAddressEndRange = ipAddressEndRange;
	}
 
	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}
	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	/**
	 * @return the ipDiscoveryResults
	 */
	public Map<String, Object> getIpDiscoveryResults() {
		return ipDiscoveryResults;
	}
	/**
	 * @param ipDiscoveryResults the ipDiscoveryResults to set
	 */
	public void setIpDiscoveryResults(Map<String, Object> ipDiscoveryResults) {
		this.ipDiscoveryResults = ipDiscoveryResults;
	}

}
