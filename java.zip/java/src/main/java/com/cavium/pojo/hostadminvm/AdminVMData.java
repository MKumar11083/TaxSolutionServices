package com.cavium.pojo.hostadminvm;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(value=Include.NON_NULL)
public class AdminVMData
{
	private String username;
	private String password;
	private String applianceIp;
	private String applianceId;
    private Advanced advanced;

    private General general;

    public void setAdvanced(Advanced advanced){
        this.advanced = advanced;
    }
    public Advanced getAdvanced(){
        return this.advanced;
    }
    public void setGeneral(General general){
        this.general = general;
    }
    public General getGeneral(){
        return this.general;
    }
	 
	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * @return the applianceIp
	 */
	public String getApplianceIp() {
		return applianceIp;
	}
	/**
	 * @param applianceIp the applianceIp to set
	 */
	public void setApplianceIp(String applianceIp) {
		this.applianceIp = applianceIp;
	}
	/**
	 * @return the applianceId
	 */
	public String getApplianceId() {
		return applianceId;
	}
	/**
	 * @param applianceId the applianceId to set
	 */
	public void setApplianceId(String applianceId) {
		this.applianceId = applianceId;
	}
	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}
	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}
}
