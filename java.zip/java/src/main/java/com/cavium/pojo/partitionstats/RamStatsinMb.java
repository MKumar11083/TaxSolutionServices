package com.cavium.pojo.partitionstats;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

@Entity
@Table(name = "partition_stats_ram_details")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class RamStatsinMb implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@JsonProperty(access = Access.WRITE_ONLY)
	@Column(name = "id", nullable = false)
	private Long id;
	@Column(name = "total")
 private Long total;
	
	@Column(name = "free")
 private Long free;
/**
 * @return the total
 */
public Long getTotal() {
	return total;
}
/**
 * @param total the total to set
 */
public void setTotal(Long total) {
	this.total = total;
}
/**
 * @return the free
 */
public Long getFree() {
	return free;
}
/**
 * @param free the free to set
 */
public void setFree(Long free) {
	this.free = free;
}
/**
 * @return the id
 */
public Long getId() {
	return id;
}
/**
 * @param id the id to set
 */
public void setId(Long id) {
	this.id = id;
}

 
}
