package com.cavium.service.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

import com.cavium.model.user.ACLRoleModel;
import com.cavium.model.user.PermisssionDetailModel;
import com.cavium.model.user.UserACLDetailsModel;
import com.cavium.model.user.UserDetailModel;
import com.cavium.repository.user.UserRepository;
import com.cavium.service.appliance.ApplianceService;
import com.cavium.service.recentactivity.RecentActivityServiceImpl;
import com.cavium.utill.CaviumConstant;
import com.cavium.utill.CaviumUtil;

/**
 * @author MK00497144
 * This class is used in oauth security for validating the user
 * */

@Service("userDetailsService")
public class Assembler implements UserDetailsService {

	 @Autowired
	 private UserRepository userRepository;
	private Logger logger = Logger.getLogger(this.getClass());
	@Autowired
	private RecentActivityServiceImpl recentActivityServiceImpl;
	@Autowired
	private ApplianceService applianceService;
	@Autowired
	private CaviumUtil caviumUtil;
	
	/**
	 * This method get the information by the username
	 */
	@Transactional
	public User loadUserByUsername(String username) {
		UserDetailModel userDetails = userRepository.findOne(username);
		String password = "";
		User user=null;
		Integer failureCount=null;
		try {
			if(userDetails!=null) {
				password = userDetails.getPassword();
			  failureCount=userDetails.getLoginFailureCount();
			}
				
			logger.info("Getting Roles for User:" + username);
			Collection<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
			List<String> userRoles=new ArrayList<String>();
			UserACLDetailsModel userACLDetailsModel=userDetails.getObjUserACLDetailsModel();
			List<ACLRoleModel> aCLRoleModel=userACLDetailsModel.getListACLRoleModel();
			if(aCLRoleModel!=null && !aCLRoleModel.isEmpty()) {
					Iterator<ACLRoleModel> itr=aCLRoleModel.iterator();
					while(itr.hasNext()) {
						ACLRoleModel acl=(ACLRoleModel)itr.next();
						PermisssionDetailModel permission=acl.getObjPermisssionDetailModel();
						if(permission!=null) {
							userRoles.add(permission.getShortPermission());
						}
				}
			}
			
			if (userRoles.size() > 0) {
				for (int i = 0; i < userRoles.size(); i++) {
					logger.info("Assigning role " + userRoles.get(i)
							+ " to the user " + username);
					authorities.add(new SimpleGrantedAuthority(userRoles.get(i).toString()));
				}
			}
			 
			if(failureCount!=null && failureCount>=5){
			user=	new User(username, password, true, true, true, false, authorities);
			}else{
				user = new User(username, password, authorities);
			}
			 if(userDetails.getStatus()!=null && !"SUSPENDED".equalsIgnoreCase(userDetails.getStatus().toString()))
			recentActivityServiceImpl.createRecentActivity(username, "User "+username+" logged-in successfully.",CaviumConstant.USER_LOGIN_MANAGEMENT);
		} catch (Exception exp) {
			// TODO: handle exception
			 logger.error("Error occured during authentication of user :: "+ exp.getMessage());
			 
		}
		return user;
	}
}
