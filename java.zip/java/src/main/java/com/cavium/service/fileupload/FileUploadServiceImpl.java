package com.cavium.service.fileupload;

import java.io.File;
import java.util.Iterator;

import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.appliance.DualFactorAuthDetailModel;
import com.cavium.model.appliance.DualFactorUsersRelationshipModel;
import com.cavium.model.recentactivity.InProgressActivity;
import com.cavium.pojo.UserAttributes;
import com.cavium.repository.appliance.ApplianceRepository;
import com.cavium.repository.recentactivity.InProgressActivityRepository;
import com.cavium.service.alerts.AlertsService;
import com.cavium.utill.CaviumConstant;
import com.cavium.utill.CaviumResponseModel;
import com.cavium.utill.CaviumUtil;
import com.cavium.utill.RestClient;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
/**
 *  * @author RK00490847
 * 
 */
@Component
public class FileUploadServiceImpl implements FileUploadService {
	private Logger logger = Logger.getLogger(this.getClass());
 

	/**
	 * This class is used to set the response attributes for incoming requests
	 */
	@Lookup
	public CaviumResponseModel getCaviumResponseModel() {
		return null;
	}
 
	@Autowired
	RestClient restClient;
	
	@Autowired
	private InProgressActivityRepository inProgressActivityRepository;
	
	
	@Autowired
	private UserAttributes userAttributes;
	
	
	@Autowired
	Environment env;

   
	@Override
	public CaviumResponseModel uploadFile(File certificate,String coUsername,String coPassword,String apiName,String applianceIp,DualFactorUsersRelationshipModel dualAuthModel) {
		logger.info("start of uploadFile method of FileUploadServiceImpl class");
		CaviumResponseModel caviumResponseModel=getCaviumResponseModel();
		MultiValueMap<String, Object> bodyMap = new LinkedMultiValueMap<>();
     try{
        bodyMap.add("file", CaviumUtil.getUserFileResource(certificate));
        bodyMap.add("username",coUsername);
        bodyMap.add("password", coPassword);
        bodyMap.add("type",apiName);
        if(dualAuthModel!=null) {
			 bodyMap.add("dualFactorKeyFile",dualAuthModel.getDualFactorKeyFileId());
			 bodyMap.add("dualFactorPort",dualAuthModel.getDualFactorAuthServerPortNo());
			 bodyMap.add("dualFactorCertificate",dualAuthModel.getDualFactorCertificateId());
        }
         ResponseEntity<String> response=restClient.invokePOSTMethodObject("https://"+applianceIp+"/liquidsa/upload", bodyMap);
         if(response!=null && response.getBody()!=null){
			ObjectMapper mapper = new ObjectMapper();
			JsonNode root = mapper.readTree(response.getBody());
			if(!root.isNull() && root.isArray()){
				for(int i=0;i<root.size();i++){
				JsonNode errors = root.get(i).path("errors");
				String status = root.get(i).path("status").asText();
				if(!errors.isNull() && errors.size() > 0){
					StringBuilder sbmessage=new StringBuilder();
					StringBuilder sbcode=new StringBuilder();
					Iterator<JsonNode> itr = errors.elements();	
					while (itr.hasNext()) {
						JsonNode temp = itr.next();
						sbcode.append(""+temp.asInt()+"");
						if(env.containsProperty(""+temp.asInt()+"")) {
							sbmessage.append(env.getProperty(""+temp.asInt()+""));
						}else {
							sbmessage.append("Error message not available");
						}
						sbcode.append(",");
						sbmessage.append(",");
					}
					String message=sbmessage.toString();
					message=message.substring(0, message.length()-1);
					message=message+".";
					String code=sbcode.toString();
					code=code.substring(0, code.length()-1);
					code=code+".";
					caviumResponseModel.setResponseCode(sbcode.toString());
					caviumResponseModel.setResponseMessage(message);
				}
				if(status.equalsIgnoreCase("Success")){
				String  uploadedFileID= root.get(i).path("uploadedFileID").asText();
				 caviumResponseModel.setResponseCode("200");
				 caviumResponseModel.setResponseMessage(uploadedFileID);
				 }
			 }
			}
		}else{
			if((response!=null && response.getStatusCodeValue()== 408) || response==null){
				caviumResponseModel.setResponseCode("408");
				caviumResponseModel.setResponseMessage("Applaince not reachable.");
			}else {
				 caviumResponseModel.setResponseCode("409");
				 caviumResponseModel.setResponseMessage("Error occured while uploading file.");	
			}
		}
  }catch (Exception e) {
	  logger.error("Error coming while upload file in uploadFile method of FileUploadServiceImpl class"+e.getMessage());
	}
 	logger.info("end of uploadFile method of FileUploadServiceImpl class");
  	return caviumResponseModel;
	}
@Override
public CaviumResponseModel uploadFileForFirmwareUpgrade(String fileName,File certificate,String apiName,ApplianceDetailModel appdetail,JSONObject jsonObject,String loggedInUser) {
		logger.info("start of uploadFileForFirmwareUpgrade method of FileUploadServiceImpl class");
		CaviumResponseModel caviumResponseModel = getCaviumResponseModel();
		MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		try {
			builder.addTextBody("username", jsonObject.getString("username"));
			builder.addTextBody("password", jsonObject.getString("password"));
			builder.addTextBody("type", apiName);
			if (jsonObject != null && jsonObject.has("dualFactorKeyFile")) {
				String dualFactorKeyFile = jsonObject.getString("dualFactorKeyFile");
				String dualFactorPort = String.valueOf(jsonObject.get("dualFactorPort"));
				String dualFactorCertificate = jsonObject.getString("dualFactorCertificate");
				builder.addTextBody("dualFactorKeyFile", dualFactorKeyFile);
				builder.addTextBody("dualFactorPort", dualFactorPort);
				builder.addTextBody("dualFactorCertificate", dualFactorCertificate);
			}
			
			/**
			 * 
			 */
			createInprogressActivity(appdetail,loggedInUser);
			
			/**
			 * This method call is uploading the firmware file
			 */
			logger.info(fileName+" is being uploaded for "+appdetail.getIpAddress()+"");
			String response = restClient.invokeMultiPartRequest("https://"+appdetail.getIpAddress()+"/liquidsa/upload", fileName,
					certificate, builder);
			if (response != null ) {
				if(response.contains("Connection")) {
					caviumResponseModel.setResponseCode("408");
					caviumResponseModel.setResponseMessage("Upload failed due to appliance connection error.");
				}else {
					JSONArray jsonarray = new JSONArray(response);
					if(response.contains("Success") && jsonarray.length() == 1) {
						JSONObject jsonobject = jsonarray.getJSONObject(0);
						if (jsonobject.has("uploadedFileID")) {
							String uploadedFileID = jsonobject.getString("uploadedFileID");
							caviumResponseModel.setResponseCode("200");
							caviumResponseModel.setResponseMessage(uploadedFileID);
							logger.info(fileName+" : "+uploadedFileID+" for "+appdetail.getIpAddress()+"");
							}
							} else {
								if(response.contains("Connection")) {
									caviumResponseModel.setResponseCode("408");
									caviumResponseModel.setResponseMessage("Upload failed due to appliance connection error.");
								}
								if (response != null && response.contains("error") && response.contains("message") && jsonarray.length() == 1) {
								JSONObject jsonobject = jsonarray.getJSONObject(0);
								String encodeMessage = jsonobject.getString("message");
								caviumResponseModel.setResponseCode("409");
								caviumResponseModel.setResponseMessage(CaviumUtil.decodeMessageBase64(encodeMessage));
							}
					}
				}
			}else {
				caviumResponseModel.setResponseCode("408");
				caviumResponseModel.setResponseMessage("Appliance not rechable. ");
			}
		} catch (Exception e) {
			logger.error("Error coming while upload file in uploadFile method of FileUploadServiceImpl class"
					+ e.getMessage());
			caviumResponseModel.setResponseCode("409");
			caviumResponseModel.setResponseMessage("Failed to upload due to "+e.getMessage()+"");
		}
		logger.info("end of uploadFileForFirmwareUpgrade method of FileUploadServiceImpl class");
		return caviumResponseModel;
	}

   private void createInprogressActivity(ApplianceDetailModel app,String loggedInUser) {
	   try {
		   logger.info("Creating inprogress activity for "+app.getApplianceName()+" for firmware upload");
		   InProgressActivity listInPorgress=inProgressActivityRepository.getInProgressActivity(app.getIpAddress(),"FirmwareUpgradeUpload");
			if(listInPorgress == null) {
				InProgressActivity activity=new InProgressActivity();
				activity.setApplianceID(app.getApplianceId());
				activity.setOperationName("FirmwareUpgradeUpload");
				activity.setJobId(0);
				activity.setIpAddress(app.getIpAddress());
				activity.setCreatedBy(loggedInUser);
				activity.setStatus("In-Progress");
				activity.setModuleName(CaviumConstant.APPLIANCE_MANAGEMENT);
				activity.setApplianceName(app.getApplianceName());
				inProgressActivityRepository.save(activity);
			}
	} catch (Exception e) {
		// TODO: handle exception
		logger.error("Error occured during firmware upgrade.");
	}
   }

}

