package com.cavium.service.appliance;

import java.io.File;
import java.util.HashMap;
import java.util.List;

import org.json.JSONObject;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.multipart.MultipartFile;

import com.cavium.model.appliance.ApplianceDeleteFailureModel;
import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.appliance.DualFactorUsersRelationshipModel;
import com.cavium.model.appliance.InitializeApplianceDetailModel;
import com.cavium.model.partition.PartitionDetailModel;
import com.cavium.model.recentactivity.InProgressActivity;
import com.cavium.pojo.AdminVMSelfTestReport;
import com.cavium.pojo.ApplianceCityDetail;
import com.cavium.pojo.ApplianceInfo;
import com.cavium.pojo.HSMInfo;
import com.cavium.pojo.HostSelfTestReport;
import com.cavium.pojo.MCOKeyCertificateDetails;
import com.cavium.pojo.ManageCertificatesDetails;
import com.cavium.pojo.SNMPDetails;
import com.cavium.pojo.logs.LogsDetails;
import com.cavium.utill.CaviumResponseModel;
/**
 *  * @author MK00497144
 *  This interface holds all the necessary operations for Appliance Management
 */
public interface ApplianceService {
	
	/**
	 * This method is used to create the appliance
	 * @param loggedInUser
	 * @param applianceDetailModel
	 * @return
	 */
	CaviumResponseModel createAppliance(List<ApplianceDetailModel> applianceDetailModel);
	/**
	 * This method is used to modify the appliance
	 * @param loggedInUser
	 * @param applianceDetailModel
	 * @return
	 */
	CaviumResponseModel modifyAppliance(String loggedInUser, ApplianceDetailModel applianceDetailModel);
	/**
	 * This method is used 
	 * @param userId
	 * @return
	 */
	CaviumResponseModel deleteAppliances(ApplianceDetailModel applianceDetailModel);

	/**
	 * This method is used get list of appliances
	 * @return
	 */
	List<ApplianceDetailModel> getListOfAppliances();
	
	/**
	 * This method is used to validate the appliance exists or not
	 * @param applianceDetailModel
	 * @return
	 */
	
	ApplianceDetailModel validateAppliance(ApplianceDetailModel applianceDetailModel);
	
	/***
	 * This method is used to get appliance by id.
	 */
	ApplianceDetailModel getApplianceById(String applianceID);
	/**
	 * 
	 * @param loggedInUser
	 * @return
	 */
	List<ApplianceDetailModel> listOfApplianceByGroupId(String loggedInUser);
	/**
	 * This method is used to reboot the appliance
	 * @param applianceDetailModel
	 * @return
	 */
		void  rebootAppliance(ApplianceDetailModel  applianceDetailModel,String user);
	/**
	 * This method is used to zeroize the appliance
	 * @param applianceDetailModel
	 * @return
	 */
	void zeroizeAppliance(String loggedInUser, ApplianceDetailModel applianceDetailModellist);
	
	/**
	 * 
	 * @param applianceDetailModel
	 * @return AdminVMSelfTestReport
	 */
	public AdminVMSelfTestReport getAdminVMSelfTestReport (ApplianceDetailModel applianceDetailModel,AdminVMSelfTestReport objAdminVMSFT);
	
	/**
	 * 
	 * @param applianceDetailModel
	 * @return HostSelfTestReport
	 */
	public HostSelfTestReport getHostSelfTestReport (ApplianceDetailModel applianceDetailModel,HostSelfTestReport objHostSFT);
	/**
	 * 
	 * @param applianceDetailModel
	 * @return
	 * @throws Exception 
	 */
	List<ApplianceDetailModel> initilizeAppliance(String userName, InitializeApplianceDetailModel initializeApplianceDetailModel) throws RuntimeException;
	
	
	/**
	 * 
	 * @param applianceDetailModel
	 * @return ApplianceInfo
	 */
	ApplianceInfo GetApplianceInfo(ApplianceDetailModel applianceDetailModel,ApplianceInfo applianceInfo);
	
	/**
	 * 
	 * @param applianceDetailModel
	 * @return HSMInfo
	 */
	HSMInfo getHSMInfo(ApplianceDetailModel applianceDetailModel,HSMInfo objHSMInfo) ;
	
	/***
	 * 
	 * @param applianceDetailModel
	 * @return
	 */
	List<ApplianceDetailModel> searchAppliance(ApplianceDetailModel applianceDetailModel);
	
	
	ApplianceDetailModel initilizeApplianceRelationship(String userName, ApplianceDetailModel applianceDetailModel, InitializeApplianceDetailModel initializeApplianceDetailModel,Long initializeId,CaviumResponseModel caviumResponseModel,DualFactorUsersRelationshipModel dualFactorUsersRelationship) throws RuntimeException;
	/***
	 * This method is used to fecth the temporary applainces 
	 * @return
	 */
	List<ApplianceDetailModel> getListOfTempAppliances();
	
	/**
	 * 
	 * @param applianceDetailModel
	 * @return
	 */
	CaviumResponseModel createApplianceForTesting(List<ApplianceDetailModel> applianceDetailModel);
	
	/**
	 * 
	 * @param listApplianceDetailModels
	 * @return
	 */
	List<ApplianceCityDetail> listAppliancesDetailCityWise(List<ApplianceDetailModel> listApplianceDetailModels);
	/**
	 * 
	 * @param certificateType
	 * @param applianceIp
	 * @return
	 */
	CaviumResponseModel getCertificateURL(String certificateType, String applianceIp);
	/**
	 * 
	 * @param manageCertificatesDetails
	 * @return
	 */
	CaviumResponseModel uploadCertificate(ManageCertificatesDetails manageCertificatesDetails);
	/**
	 * 
	 * @param certificateUrl
	 * @param applianceName
	 * @return
	 */
   File downloadFileFromURL(String certificateUrl,String applianceName);
   /**
    * 
    * @param logsDetail
    * @return
    */
   CaviumResponseModel  getDownloadlogsURL(LogsDetails logsDetail);
   /**
    * 
    * @param logsDetail
    * @return
    */
   CaviumResponseModel deleteAppliancelogs(LogsDetails logsDetail);
   /**
    * 
    * @param logsDetail
    * @return
    */
   CaviumResponseModel getAlreadyConfiguredLoggerType(LogsDetails logsDetail);
   /**
    * 
    * @param logsDetail
    * @return
    */
   CaviumResponseModel updateConfigureLoggerType(LogsDetails logsDetail);
 /**
  *   
  * @param app
  * @return
  */
 public  List<PartitionDetailModel> setPartitionDataInPartitonModel(ApplianceDetailModel app);
 /**
  * 
  * @param listApplianceDetailModels
  * @return
  */
 public List<ApplianceDetailModel> validateCredentialsByLoginHSM(List<ApplianceDetailModel>  listApplianceDetailModels);
 /**
  * 
  * @param applianceDetailModel
  * @return
  */
 public List<ApplianceDetailModel> getMonitorData(List<ApplianceDetailModel> applianceDetailModel);
 /**
  * 
  * @param applianceDetailModel
  * @return
  */
 public List<ApplianceDetailModel> setMonitorData(List<ApplianceDetailModel> applianceDetailModel);
 /**
  * 
  * @param listApplianceDetailModels
  * @return
  */
 public List<ApplianceDetailModel> getApplianceMonitorStats(List<ApplianceDetailModel>  listApplianceDetailModels);
 /**
  * 
  * @param listApplianceDetailModels
  * @return
  */
 public ApplianceDetailModel changeAppliancePassword(ApplianceDetailModel  listApplianceDetailModels);
 /**
  * 
  * @param url
  * @param applianceDetailModel
  * @return
  */
 public CaviumResponseModel downloadMonitorLogsURL(String url, ApplianceDetailModel applianceDetailModel);
 /**
  * 
  * @param certificateUrl
  * @param name
  * @return
  */
 public File downloadMonitorFile(String certificateUrl, String name);
 /**
  * 
  * @param applianceDetailModel
  * @return
  */
 public  CaviumResponseModel getSelfReportData(ApplianceDetailModel  applianceDetailModel);
 
 public SNMPDetails getSNMPInfo(SNMPDetails snmpDetails) ;

 public SNMPDetails setSNMPInfo(SNMPDetails snmpDetails);
 
 public CaviumResponseModel uploadMCOKeyCertificate(MCOKeyCertificateDetails mcoKeyCertificateDetails,File convMCOKeyKeyCertificate,String uploadedFileId);
 
 public ApplianceDeleteFailureModel validateDeleteAppliance(List<ApplianceDetailModel>  listApplianceDetailModels);
 
 
 public CaviumResponseModel deleteTemporaryAppliance(ApplianceDetailModel app);
 
 public ApplianceDetailModel updateApplianceDetails(ApplianceDetailModel applianceDetailModel);
 public void doApplianceFirmwareUpgrade(ApplianceDetailModel applianceDetailModels,File imageFileConvertedFile,File signFileConvertedFile,String loggedInUser);
 ApplianceDetailModel applianceFirmwareUpgrade(ApplianceDetailModel app,String loggedInUser,JSONObject jsonObject);
 
 public List<ApplianceDetailModel> getAllPermanentAppliances();
 
 public void updateApplianceInfo(ApplianceDetailModel app);
 
 public void deleteDualFactorDetailsForUser(String loggedInUser);
 
 public DualFactorUsersRelationshipModel updateDualfactorDetails(ApplianceDetailModel appliance,PartitionDetailModel pdm, CaviumResponseModel response);
 public ApplianceDetailModel editAppliance(ApplianceDetailModel applianceDetailModel);
 
 public void applianceInitialize(String userName,InitializeApplianceDetailModel initModel);
 
 public ApplianceDetailModel getErrorMessage(ResponseEntity<String> response,ApplianceDetailModel applianceDetailModel,String loggedInUser,String type);
 
 public boolean getUserDualFactorDetails(String userId,String applianceId);
 
 public List<ApplianceDetailModel> saveDualFactorDetails(DualFactorUsersRelationshipModel dual,List<ApplianceDetailModel> listDualAppModel,ApplianceDetailModel dbApplianceModel,String loggedInUser);
 /**
  * Method used to delete partitions and initialize object
  * @param app
  * @param in
  */
 public void deletePartitionsAndInitializeFromDB(ApplianceDetailModel app,String createdBy,String operationName);
 /**
  * delete partitionData
  * @param partitionDetailModel
  * @param in
  */
 public void deletePartitionData(PartitionDetailModel partitionDetailModel,String createdBy,String operationName);
}
