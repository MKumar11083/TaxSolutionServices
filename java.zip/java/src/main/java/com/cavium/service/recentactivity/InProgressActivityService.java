package com.cavium.service.recentactivity;

import java.util.List;

import com.cavium.model.recentactivity.InProgressActivity;

public interface InProgressActivityService {
	/**
	 * This method is used to create InProgressActivity
	 */
	public void createInProgressActivity(InProgressActivity inProgressActivity);
	/**
	 * This method is returning List of InProgressActivity
	 * @return
	 */
	public List<InProgressActivity> getListOfInProgressActivity(String loggedInUser,String moduleName);

}
