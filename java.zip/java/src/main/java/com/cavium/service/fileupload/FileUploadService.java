package com.cavium.service.fileupload;



import java.io.File;

import org.json.JSONObject;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.appliance.DualFactorAuthDetailModel;
import com.cavium.model.appliance.DualFactorUsersRelationshipModel;
import com.cavium.utill.CaviumResponseModel;
/**
 *  * @author RK00490847
 *  
 */
public interface FileUploadService {
	
	/**
	 * This method is used to create the appliance
	 * @param loggedInUser
	 * @param applianceDetailModel
	 * @return
	 */
	CaviumResponseModel uploadFile(File certificate,String coUsername, String coPassword,String apiName,String ApplianceIp,DualFactorUsersRelationshipModel dual);
	/**
	 * This method is used for firmware upload
	 * @param certificate
	 * @param coUsername
	 * @param coPassword
	 * @param apiName
	 * @param ApplianceIp
	 * @param dualAuthModel
	 * @return
	 */
	CaviumResponseModel uploadFileForFirmwareUpgrade(String fileName,File certificate,String apiName,ApplianceDetailModel app,JSONObject jsonObject,String loggedInUser);

		 
}
