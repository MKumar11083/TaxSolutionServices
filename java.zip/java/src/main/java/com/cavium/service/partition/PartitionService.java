package com.cavium.service.partition;

import java.io.File;
import java.util.List;

import org.json.JSONObject;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.partition.PartitionData;
import com.cavium.model.partition.PartitionDetailModel;
import com.cavium.model.partition.PartitionETH;
import com.cavium.model.partition.RestorePartitionModel;
import com.cavium.pojo.PartitionDetailsWithPercentage;
import com.cavium.pojo.PartitionSnapShotDetailModel;
import com.cavium.pojo.PartitionSnapshotDetails;
import com.cavium.pojo.PartitionsDetails;
import com.cavium.pojo.partitionstats.PartitionStatsDetails;
import com.cavium.rest.model.partition.PartitionModel;
import com.cavium.utill.CaviumResponseModel;

/**
 *  * @author MK00497144
 *  This interface holds all the necessary operations for Partitions
 */
public interface PartitionService {
	
	public PartitionsDetails getPartitionInfo(ApplianceDetailModel applianceDetailModel,PartitionsDetails partitionsDetails);
	
	/***
	 * This method is used to get list of all partitions 
	 * @param loggedInUser
	 * @return
	 */
	public List<PartitionDetailModel> getListOfPartitions(String loggedInUser);
	/***
	 * This method is used to create partitions
	 * @param loggedInUser
	 * @param partitionDetailModels
	 * @return
	 */
	public PartitionDetailModel createPartition(String loggedInUser,PartitionDetailModel partitionDetailModels,Boolean partitionAlreadyExist);
	/***
	 * This method is used to modify Partitions
	 * @param loggedInUser
	 * @param partitionDetailModels
	 * @return
	 */
	public PartitionDetailModel modifyPartition(String loggedInUser,PartitionDetailModel partitionDetailModels);
	/***
	 * This method is used to delete partions
	 * @param loggedInUser
	 * @param partitionDetailModels
	 * @return
	 */
	
	public List<PartitionDetailModel> deletePartition(String loggedInUser,List<PartitionDetailModel> partitionDetailModels);
	/**
	 * 
	 * @param applianceDetailModel
	 * @return
	 */
	public CaviumResponseModel validateInitOperationForCreatePartition(ApplianceDetailModel applianceDetailModel);
	/**
	 * 
	 * @param partitionDetailModel
	 */
	public void getPartitionInformationModel(PartitionDetailModel partitionDetailModel);
	/**
	 * This method is used to get paritition Info
	 * @param partitionDetailModels
	 * @return
	 */
	public PartitionDetailModel getPartitionInfo(PartitionDetailModel partitionDetailModels);
	/**
	 * This method is used to get paritition stats data
	 * @param partitionDetailModels
	 * @return
	 */
	public PartitionDetailModel getPartitionStatsInfo(PartitionDetailModel partitionDetailModels);
	/**
	 * This method is used to get paritition networks data
	 * @param partitionDetailModels
	 * @return
	 */
	public PartitionDetailModel getPartitionNetworkStatsInfo(PartitionDetailModel partitionDetailModels);
	/**
	 * This method is used to reset the partition
	 * @param loggedInUser
	 * @param partitionDetailModels
	 * @return
	 */
	public List<PartitionDetailModel> rebootPartition(String loggedInUser,List<PartitionDetailModel> partitionDetailModels);
	
	/**
	 * This method is used to close the partition session
	 * @param loggedInUser
	 * @param partitionDetailModels
	 * @return
	 */
	public List<PartitionDetailModel> closeSessionForPartition(List<PartitionDetailModel> partitionDetailModels);
	
	/**
	 * @param applianceDetailModel
	 * @return
	 */
	public List<PartitionData> getAllPartitionsDetails(ApplianceDetailModel applianceDetailModel);
	/**
	 * 
	 * @param loggedInUser
	 * @param partitionDetailModels
	 * @return
	 */
	public List<PartitionDetailModel> setNetworkConfiguration(String loggedInUser, List<PartitionDetailModel> partitionDetailModels);
	/**
	 * 
	 * @param loggedInUser
	 * @param partitionDetailModels
	 * @return
	 */
	public List<PartitionDetailModel> stopStartPartitionCavSever(String loggedInUser, List<PartitionDetailModel> partitionDetailModels);
	/**
	 * This method is used to upload the cav server config file for partition
	 * @param loggedInUser
	 * @param partitionDetailModels
	 * @return
	 */
	public List<PartitionDetailModel> uploadCavServerConfigFile(String loggedInUser, List<PartitionDetailModel> partitionDetailModels);
	/**
	 * This method is used to download the cav server config file for partition
	 * @param loggedInUser
	 * @param partitionDetailModels
	 * @return
	 */
	public CaviumResponseModel downloadConfigFileURL(PartitionDetailModel detailModel,String type,String operation);
	/**
	 * 
	 * @param certificateUrl
	 * @param partitionName
	 * @return
	 */
	public File downloadConfigFile(String certificateUrl,String partitionName,String applianceName);
	/**
	 * This method is used to reset config for cav server for partition
	 * @param loggedInUser
	 * @param partitionDetailModels
	 * @return
	 */
	public List<PartitionDetailModel> resetCavServerConfig(String loggedInUser, List<PartitionDetailModel> partitionDetailModels);
	
	/**
	 * 
	 * @param usedKeysPercentage
	 * @param partitionSnapshotDetails
	 * @param keysWithPercentage
	 */
	void getKeysDetails(double usedKeysPercentage , PartitionSnapshotDetails partitionSnapshotDetails, PartitionDetailsWithPercentage keysWithPercentage);
	/**
	 * 
	 * @param usedAcclrDevPercentage
	 * @param partitionSnapshotDetails
	 * @param accelerationDevicesWithPercentage
	 */
	void getAccelerationDeviceDetails(double usedAcclrDevPercentage , PartitionSnapshotDetails partitionSnapshotDetails, PartitionDetailsWithPercentage accelerationDevicesWithPercentage);
	/**
	 * 
	 * @param usedsslContextsPercentage
	 * @param partitionSnapshotDetails
	 * @param sslContextssWithPercentage
	 */
	void getSSlContextDetails( double usedsslContextsPercentage, PartitionSnapshotDetails partitionSnapshotDetails, PartitionDetailsWithPercentage sslContextssWithPercentage);
	/**
	 * 
	 * @param partitionSnapshotDetails
	 * @param partitionsDetails
	 */
	void getFipsState(PartitionSnapshotDetails partitionSnapshotDetails,PartitionsDetails partitionsDetails,PartitionSnapShotDetailModel partitionSnapShotDetailModel);
	/**
	 * 
	 * @param partitionSnapshotDetails
	 * @param partitionsDetails
	 */
	void getUsageDetails(PartitionSnapshotDetails partitionSnapshotDetails ,PartitionsDetails partitionsDetails,PartitionSnapShotDetailModel partitionSnapShotDetailModel);
	/**
	 * 
	 * @param partitionSnapshotDetails
	 * @param partitionsDetails
	 */
	void getPartitionStatusDetails(PartitionSnapshotDetails partitionSnapshotDetails ,PartitionsDetails partitionsDetails,PartitionSnapShotDetailModel partitionSnapShotDetailModel);
	/**
	 * 
	 * @param loggedInUser
	 * @param partitionDetailModels
	 * @return
	 */
	public List<PartitionDetailModel> uploadPartitionCertificate(String loggedInUser, List<PartitionDetailModel> partitionDetailModels);
	
	/**
	 * 
	 * @param loggedInUser
	 * @param partitionDetailModels
	 * @return
	 */
	public List<PartitionDetailModel> restorePartition(String loggedInUser, RestorePartitionModel restorePartitionModel);
	/**
	 * 
	 * @param detailModel
	 * @param type
	 * @return
	 */
	public PartitionDetailModel closeSession(PartitionDetailModel detailModel,String type,JSONObject jsonObject);
	
	/***
	 * This method is used to get list of all partitions by applaince id
	 * @param loggedInUser
	 * @return
	 */
		public List<PartitionDetailModel> getListOfPartitionsByApplianceID(String loggedInUser,Long applainceId);
	/**
	 * 
	 * @param listPartitionDetailModel
	 * @return
	 */
	 public List<PartitionDetailModel> setObjectsInPartitionDetailModel(List<PartitionDetailModel> listPartitionDetailModel);
	 /**
	  * 
	  * @param object
	  * @return
	  */
	 public PartitionData validatePartitionInformationModel(JSONObject object) ;
	 /**
	  * s
	  * @param listPartitionDetailModel
	  * @return
	  */
	 public List<PartitionDetailModel> setPartitionDataIntoPartitionModel(List<PartitionDetailModel> listPartitionDetailModel);
	 /**
	  * This method is used to send the partition resize prepopulated data
	  * @param partitionDetailModel
	  * @return
	  */
    public List<PartitionDetailModel> getPartitionInfoData(List<PartitionDetailModel> partitionDetailModel);
    /**
     * This method is used to resize the partition
     * @param partitionDetailModel
     * @return
     */
	public PartitionDetailModel resizePartitions(PartitionDetailModel partitionDetailModel);
	/**
	 * 
	 * @param partitionDetailModel
	 * @return
	 */
	public List<PartitionDetailModel> setPartitionMonitorConfig(List<PartitionDetailModel> partitionDetailModel);
	/**
	 * 
	 * @param partitionDetailModel
	 * @return
	 */
	public List<PartitionDetailModel> getPartitionMonitorData(List<PartitionDetailModel> partitionDetailModel);
	/**
	 * 
	 * @param partitionDetailModel
	 * @return
	 */
	public List<PartitionDetailModel> getPartitionMonitorStats(List<PartitionDetailModel> partitionDetailModel);
	
	
	public PartitionDetailModel getErrorMessage(ResponseEntity<String> response,PartitionDetailModel partitionDetailModel,String loggedInUser,String type);
	
	public List<PartitionDetailModel> getListOfNotAssignedPartitions(String loggedInUser);
	
	public JSONObject getUserNamePassword(PartitionDetailModel pdmobj,JSONObject jsonObject);
	
	public void updateEth01IpAddress(PartitionETH partitionETH);
		
	public void updateNodeIdforPartitionId(Integer nodeId,Long partitionId);
	
	
	public void savePartitionStatsGraphDetails(PartitionStatsDetails partitionStatsDetails);
	
	
	public List<PartitionStatsDetails> getPartitionStatsGraphDetails(Long partitionId);
	

	public void savePartitionStatsDetails(Long partitionId);
	
	public List<PartitionDetailModel> partitionRestore(List<PartitionDetailModel> partitionDetailModel,PartitionDetailModel backupFrom, MultipartFile file);
	
	public void updatePartitionData(PartitionDetailModel partitionDetailModel);
	public CaviumResponseModel getCavServerConfigInfo(PartitionDetailModel partitionDetailModel);
	public CaviumResponseModel getPartitionCavServerStats(PartitionDetailModel partitionDetailModel);
	public void setDefaultValuesForNetworkStats(PartitionDetailModel partitionModel);
	public String validateDualFactorDetails(ApplianceDetailModel appModel , PartitionModel partitionModel);
	public void setDetailsForBusyAppliance(PartitionSnapshotDetails partitionSnapshotDetails, Long applianceId,String loggedInUser);
	public PartitionSnapshotDetails getPartitionSnapShotDetails();
}
