package com.cavium.service.appliance;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

import javax.transaction.Transactional;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.log4j.Logger;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.glassfish.jersey.media.multipart.MultiPart;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.cavium.model.alerts.Alerts;
import com.cavium.model.appliance.ApplianceDeleteFailureModel;
import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.appliance.DualFactorAuthDetailModel;
import com.cavium.model.appliance.DualFactorUsersRelationshipModel;
import com.cavium.model.appliance.InitializeApplianceDetailModel;
import com.cavium.model.appliance.InitializeAppliancesRelationshipModel;
import com.cavium.model.appliance.StoreType;
import com.cavium.model.cluster.ClusterPartitionsRelationship;
import com.cavium.model.hostadminvm.monitorstats.MonitorStats;
import com.cavium.model.partition.PartitionAdvanceStaticHostIps;
import com.cavium.model.partition.PartitionData;
import com.cavium.model.partition.PartitionDetailModel;
import com.cavium.model.partition.PartitionDnsConfig;
import com.cavium.model.partition.PartitionETH;
import com.cavium.model.partition.PartitionInterfaces;
import com.cavium.model.partition.PartitionInterfacesAdvance;
import com.cavium.model.partition.PartitionInterfacesGeneral;
import com.cavium.model.partition.StaticSearchADD;
import com.cavium.model.partition.monitor.MonitorData;
import com.cavium.model.partition.monitor.PartitionMonitorCWI;
import com.cavium.model.partition.monitor.PartitionMonitorPMNCData;
import com.cavium.model.partition.monitor.PartitionNetworkMonitorStats;
import com.cavium.model.recentactivity.InProgressActivity;
import com.cavium.model.user.DesignationApplianceModel;
import com.cavium.model.user.UserDetailModel;
import com.cavium.model.user.UserGroupModel;
import com.cavium.pojo.AdminVMSelfTestReport;
import com.cavium.pojo.ApplianceCityDetail;
import com.cavium.pojo.ApplianceInfo;
import com.cavium.pojo.HSMInfo;
import com.cavium.pojo.HostSelfTestReport;
import com.cavium.pojo.MCOKeyCertificateDetails;
import com.cavium.pojo.ManageCertificatesDetails;
import com.cavium.pojo.PartitionsDetails;
import com.cavium.pojo.SNMPDetails;
import com.cavium.pojo.UserAttributes;
import com.cavium.pojo.hostadminvm.Data;
import com.cavium.pojo.hostadminvm.DrvReqIdQueue;
import com.cavium.pojo.hostadminvm.FwReqIdQueue;
import com.cavium.pojo.hostadminvm.HostStats;
import com.cavium.pojo.hostadminvm.RamStats;
import com.cavium.pojo.hostadminvm.RxQueue;
import com.cavium.pojo.hostadminvm.SwapStats;
import com.cavium.pojo.hostadminvm.SystemUpTime;
import com.cavium.pojo.hostadminvm.TxQueue;
import com.cavium.pojo.hostadminvm.Vmstats;
import com.cavium.pojo.logs.LogsDetails;
import com.cavium.repository.alerts.AlertsRepository;
import com.cavium.repository.appliance.ApplianceRepository;
import com.cavium.repository.appliance.DesignationAppliance;
import com.cavium.repository.appliance.DualFactorInitializeRepository;
import com.cavium.repository.appliance.DualFactorUsersRelationshipRepository;
import com.cavium.repository.appliance.InitializeAppliancesRelationshipReposiotry;
import com.cavium.repository.appliance.InitializeRepository;
import com.cavium.repository.cluster.ClusterPartitionsRelationshipRepository;
import com.cavium.repository.hostadmin.monitorstats.MonitorStatsRepository;
import com.cavium.repository.partition.PartitionAdvanceDNSServersRepository;
import com.cavium.repository.partition.PartitionAdvanceSearchDomainNamesRepository;
import com.cavium.repository.partition.PartitionAdvanceStaticHostIpsRepository;
import com.cavium.repository.partition.PartitionDataRepository;
import com.cavium.repository.partition.PartitionDetailsWithPercentageRepository;
import com.cavium.repository.partition.PartitionETHRepository;
import com.cavium.repository.partition.PartitionRepository;
import com.cavium.repository.partition.PartitionSnapShotDetailModelRepository;
import com.cavium.repository.recentactivity.InProgressActivityRepository;
import com.cavium.repository.user.UserGroupRepository;
import com.cavium.repository.user.UserRepository;
import com.cavium.service.alerts.AlertsService;
import com.cavium.service.fileupload.FileUploadService;
import com.cavium.service.hostadminvm.HostAdminVMService;
import com.cavium.service.partition.PartitionService;
import com.cavium.service.recentactivity.InProgressActivityService;
import com.cavium.service.recentactivity.RecentActivityServiceImpl;
import com.cavium.utill.CaviumConstant;
import com.cavium.utill.CaviumResponseModel;
import com.cavium.utill.CaviumUtil;
import com.cavium.utill.NotificationRecursion;
import com.cavium.utill.RestClient;
import com.cavium.utill.SNMPTrapReceiver;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
/**
 *  * @author MK00497144
 *  Class is used as a service implementation for Appliance Management
 */
@Component
public class ApplianceServiceImpl implements ApplianceService {
	private Logger logger = Logger.getLogger(this.getClass());

	/**
	 * ApplicationRepository - Repository class for perform Database operation on ApplicationDetailModel
	 */
	@Autowired
	private ApplianceRepository applianceRepository;


	@Autowired
	private ClusterPartitionsRelationshipRepository clusterPartitionsRelationshipRepository;

	@Autowired
	private InitializeRepository initializeRepository;

	@Autowired
	private FileUploadService fileUploadService;

	@Autowired
	private InitializeAppliancesRelationshipReposiotry initializeAppliancesRelationshipReposiotry;

	@Autowired
	private InProgressActivityRepository inProgressActivityRepository;

	@Autowired
	private PartitionService partitionService;

	@Autowired
	private PartitionRepository partitionRepository;
	@Autowired
	private MonitorStatsRepository monitorStatsRepository;
	@Autowired
	private AlertsRepository alertsRepository;


	@Autowired
	private DualFactorUsersRelationshipRepository dfUsersRelationshipRepository;

	@Autowired
	private DualFactorInitializeRepository dfInitializeRepository;

	@Autowired
	SNMPTrapReceiver snmpTrapReceiver ;

	@Autowired
	HostAdminVMService  hostAdminVMService;
	/**
	 * This class is used to set the response attributes for incoming requests
	 */
	@Lookup
	public CaviumResponseModel getCaviumResponseModel() {
		return null;
	}

	/**
	 * This Interface is used to get the values from the property file
	 */
	@Autowired
	Environment env;
	/*
	 * getAllAppliancesDetails method is used for fetch All appliances Details.
	 * 
	 * @return listApplianceDetailModel - List of ApplianceDetailModel Object.
	 * 
	 */

	@Autowired
	RestClient restClient;

	@Autowired
	DesignationAppliance designationAppliance;

	@Autowired
	UserGroupRepository userGroupRepository;

	@Autowired
	private UserAttributes userAttributes;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private RecentActivityServiceImpl recentActivityServiceImpl;

	@Autowired
	private AlertsService alertsService;

	@Lookup
	public HSMInfo getHSMInfo() {
		return null;
	}

	@Autowired
	private InProgressActivityService inProgressActivityService;

	@Autowired
	private PartitionAdvanceStaticHostIpsRepository advanceStaticHostIpsRepository;
	@Autowired
	private PartitionAdvanceDNSServersRepository advanceDNSServersRepository;
	@Autowired
	private PartitionAdvanceSearchDomainNamesRepository advanceSearchDomainNamesRepository;
	@Autowired
	private PartitionETHRepository partitionETHRepository;
	@Autowired
	private PartitionDataRepository partitionDataRepository;
	
	@Autowired
	private PartitionDetailsWithPercentageRepository partitionDetailsWithPercentageRepository;
	@Autowired
	private PartitionSnapShotDetailModelRepository partitionSnapshotDetailsRepository;

	@Override
	@Transactional
	public List<ApplianceDetailModel> getListOfAppliances() {
		List<ApplianceDetailModel> listApplianceDetailModel = null;
		CaviumResponseModel responseModel=getCaviumResponseModel();
		try {	
			listApplianceDetailModel = applianceRepository.findAll();
			inProgressActivityRepository.deleteInProgressActivityByStatus();
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured due to db error inside getListOfAppliances Method of class ApplianceServiceImpl ::" + e.getMessage());
			responseModel.setResponseCode("500");
			responseModel.setResponseMessage(env.getProperty("applianceList.failureDB"));
		}
		return listApplianceDetailModel;
	}


	@Override
	@Transactional
	public CaviumResponseModel createAppliance(List<ApplianceDetailModel> applianceDetailModel) {

		// TODO Auto-generated method stub
		CaviumResponseModel responseModel=getCaviumResponseModel();	 
		String loggedInUser = userAttributes.getlogInUserName();
		DesignationApplianceModel designationApplianceDB=null;
		if (applianceDetailModel != null && applianceDetailModel.size() > 0) {

			for(ApplianceDetailModel app : applianceDetailModel) {
				try{
					List<ApplianceDetailModel> tempApplianceDetailmodel=applianceRepository.getApplianceExists(app.getIpAddress());
					if(tempApplianceDetailmodel.size() == 1 ) {
						ApplianceDetailModel tempAppliance=tempApplianceDetailmodel.get(0);
						if(tempAppliance!=null && tempAppliance.getStoreType().equals(StoreType.TEMP)) {
							tempAppliance.setCreatedBy(loggedInUser);
							tempAppliance.setCreatedDate(new Date());
							tempAppliance.setStoreType(StoreType.PERMANENT);
							tempAppliance.setApplianceStatus("Active");
							tempAppliance.setCryptoUserName(null);
							tempAppliance.setCryptoUserPassword(null);
							if(StringUtils.isEmpty(tempAppliance.getAuthId())) {
								tempAppliance.setAuthId("1234");
							}
							HSMInfo	hsmInfo=getHSMInfo();
							hsmInfo=getHSMInfo(tempAppliance, hsmInfo);
							PartitionsDetails partitionsDetails=null;
							partitionsDetails=partitionService.getPartitionInfo(app,partitionsDetails);	
							if(partitionsDetails!=null){
								int totalAcclrDevice=partitionsDetails.getTotalAcclrDev();
								int occupiedAcclrDev=partitionsDetails.getOccupiedAcclrDev();
								int totalKeys=partitionsDetails.getTotalKeys();
								int occupiedKeys=partitionsDetails.getOccupiedKeys();
								int totalContexts=partitionsDetails.getTotalContexts();
								int occupiedContexts=partitionsDetails.getOccupiedContexts();
								int totalPartitions=partitionsDetails.getTotalPartitions();
								int occupiedPartitions=partitionsDetails.getOccupiedPartitions();
								tempAppliance.setTotalAcclrDevice(totalAcclrDevice);
								tempAppliance.setOccupiedAcclrDev(occupiedAcclrDev);
								tempAppliance.setOccupiedKeys(occupiedKeys);
								tempAppliance.setTotalKeys(totalKeys);
								tempAppliance.setOccupiedContexts(occupiedContexts);
								tempAppliance.setTotalContexts(totalContexts);
								tempAppliance.setTotalPartitions(totalPartitions);
								tempAppliance.setOccupiedPartitions(occupiedPartitions);
							}
							tempAppliance.setMaxPwdLen(hsmInfo.getMaxPswdLen());
							tempAppliance.setMinPwdLen(hsmInfo.getMinPswdLen());
							tempAppliance.setCoLoginFailureCount(hsmInfo.getCoLoginFailure());	
							tempAppliance.setMcoFixedKeyFingerprint(hsmInfo.getMcoFixedKeyFingerprint());
							tempAppliance.setLastOperationStatus("Completed");	
							ApplianceDetailModel applianceTemp=applianceRepository.save(tempAppliance);
							if(applianceTemp!=null) {
								List<UserGroupModel> usg=userGroupRepository.findGroupDetailsForGroupName(env.getProperty("user.defaultusergroup")); 
								if(!usg.isEmpty()) {
									UserGroupModel userGroupModel=(UserGroupModel)usg.get(0);
									DesignationApplianceModel designationApplianceModel=new DesignationApplianceModel();
									designationApplianceModel.setDesignationId(userGroupModel.getId());
									designationApplianceModel.setObjApplianceDetailModel(applianceTemp);
									designationApplianceDB=designationAppliance.save(designationApplianceModel);
								}


								if(!hsmInfo.getFipsState().replaceAll(" ","").contains("-1[zeroized]") && designationApplianceDB!=null){
									tempAppliance.setApplianceinitialized(true);
									tempAppliance.setLastOperationPerformed("initialized");
									tempAppliance.setInitializedthroughCavium(true);
									if(hsmInfo.getFipsState().replaceAll(" ","").contains("3")){
										tempAppliance.setApplianceDualFactorInitialized(true);
										dfUsersRelationshipRepository.updateAppIpToAppId(tempAppliance.getApplianceId(),tempAppliance.getIpAddress());
									}
									applianceRepository.save(tempAppliance);
									logger.info("Applaince is non Zeroize state");
									List<PartitionData>	partitionDataList =	partitionService.getAllPartitionsDetails(tempAppliance);
									for (Iterator<PartitionData> iterator = partitionDataList.iterator(); iterator.hasNext();) {
										PartitionData partitionData = (PartitionData) iterator.next();

										PartitionDetailModel partitionDetailModel = new PartitionDetailModel();
										partitionDetailModel.setPartitionData(partitionData);								
										partitionDetailModel.setPartitionName(partitionData.getName());
										partitionDetailModel.setApplianceDetailModel(tempAppliance);
										partitionDetailModel.setBackup(partitionData.isMcoBackupRestore());
										partitionDetailModel=partitionService.getPartitionNetworkStatsInfo(partitionDetailModel);

										if("200".equals(partitionDetailModel.getCode())){
											List<String> listSearchDomainName= new ArrayList<String>();
											List<String> listdnsServers= new ArrayList<String>();
											List<PartitionAdvanceStaticHostIps> listPartitionAdvanceStaticHostIps= new ArrayList<PartitionAdvanceStaticHostIps>();

											PartitionETH eth0=null;
											PartitionETH eth1=null;
											ObjectMapper mapper = new ObjectMapper();
											JsonNode dataNode = mapper.readTree(partitionDetailModel.getMessage());

											if(!dataNode.isNull()){
												if(dataNode.has("general")){
													logger.info("Setting General Tab data");
													JsonNode generalNode = dataNode.path("general");	
													if(!generalNode.isNull()){
														if(generalNode.has("eth1")){
															logger.info("Setting eth1 Tab data");
															eth1= new PartitionETH();
															eth1.setEthName("eth1");
															JsonNode eth1Node = generalNode.path("eth1");
															String subnet=eth1Node.path("subnet").asText();
															String hostname=eth1Node.path("hostname").asText();													 
															String vlan=eth1Node.path("vlan").asText();											
															String ip=eth1Node.path("ip").asText();
															if(!"127.0.0.1".equalsIgnoreCase(ip)){
																eth1.setDisableEth1(false);	
															}
															else{
																eth1.setDisableEth1(true);	
															}
															if(eth1Node.hasNonNull("dhcp")){
																boolean dhcp=eth1Node.path("dhcp").asBoolean();
																if(!dhcp){
																	eth1.setDhcp(true);
																}
															}
															else{
																eth1.setDhcp(false);
															}
															String gateway=eth1Node.path("gateway").asText();
															String macAddress=eth1Node.path("mac").asText();
															Boolean staticMac= eth1Node.path("macStatic").asBoolean();
															eth1.setSubnet(subnet);
															eth1.setHostname(hostname);
															if(vlan!=null && !vlan.equalsIgnoreCase("")){
																eth1.setVlan(Integer.valueOf(vlan));		
															}												
															eth1.setIp(ip);				
															eth1.setGateway(gateway);
															eth1.setAddress(macAddress);
															eth1.setStaticMac(staticMac);
														}
														if(generalNode.has("eth0")){
															logger.info("Setting eth0 Tab data");
															eth0=new PartitionETH();
															eth0.setEthName("eth0");
															JsonNode eth0Node = generalNode.path("eth0");
															String subnet=eth0Node.path("subnet").asText();
															String hostname=eth0Node.path("hostname").asText();
															String vlan=eth0Node.path("vlan").asText();																 
															String ip=eth0Node.path("ip").asText();													 
															Boolean dhcp=eth0Node.path("dhcp").asBoolean();
															String gateway=eth0Node.path("gateway").asText();	
															String macAddress=eth0Node.path("mac").asText();
															Boolean staticMac= eth0Node.path("macStatic").asBoolean();
															eth0.setStaticMac(staticMac);
															eth0.setSubnet(subnet);
															eth0.setHostname(hostname);
															if(vlan!=null && !vlan.equalsIgnoreCase("")){
																eth0.setVlan(Integer.valueOf(vlan));		
															}
															eth0.setIp(ip);
															eth0.setDhcp(dhcp);
															eth0.setGateway(gateway);
															eth0.setAddress(macAddress);
														}

													}
												}
											}
											PartitionInterfaces partitionInterfaces= new PartitionInterfaces();	
											PartitionInterfacesAdvance partitionInterfacesAdvance=new PartitionInterfacesAdvance();
											StaticSearchADD staticSearchADD= new StaticSearchADD();
											List<PartitionAdvanceStaticHostIps> partitionAdvanceStaticHostIpsList = new ArrayList<PartitionAdvanceStaticHostIps>();
											staticSearchADD.setAdd(partitionAdvanceStaticHostIpsList);
											PartitionDnsConfig partitionDnsConfig= new PartitionDnsConfig();
											partitionInterfacesAdvance.setStaticIpToHostConfig(staticSearchADD);
											partitionInterfacesAdvance.setDnsConfig(partitionDnsConfig);

											PartitionInterfacesGeneral partitionInterfacesGeneral = new PartitionInterfacesGeneral();
											partitionInterfacesGeneral.setEth0(eth0);
											partitionInterfacesGeneral.setEth1(eth1);

											partitionInterfaces.setAdvanced(partitionInterfacesAdvance);
											partitionInterfaces.setGeneral(partitionInterfacesGeneral);
											partitionDetailModel.setNetworkStats(partitionInterfaces);

											JsonNode advancedNode = dataNode.path("advanced");							 
											if(!advancedNode.isNull()){
												logger.info("Setting Advanced Tab data");
												JsonNode searchDomainNames=	advancedNode.path("searchDomainNames");
												JsonNode staticIpToHostConfigs=	advancedNode.path("staticIpToHostConfig");
												JsonNode dnsServers=advancedNode.path("dnsServers");
												if(!searchDomainNames.isNull()){
													Iterator<JsonNode> searchDomainName = searchDomainNames.elements();					         
													while (searchDomainName.hasNext()) {
														JsonNode temp = searchDomainName.next();    
														listSearchDomainName.add(temp.asText());
													}
													partitionDetailModel.getNetworkStats().getAdvanced().getDnsConfig().setSearchDomainNames(listSearchDomainName.toArray(new String[listSearchDomainName.size()]));
												}
												if(!dnsServers.isNull()){
													Iterator<JsonNode> dnsServer = dnsServers.elements();					         
													while (dnsServer.hasNext()) {
														JsonNode temp = dnsServer.next();
														listdnsServers.add(temp.asText());
													}
													partitionDetailModel.getNetworkStats().getAdvanced().getDnsConfig().setDnsServers(listdnsServers.toArray(new String[listdnsServers.size()]));
												}
												if (staticIpToHostConfigs.isArray()) {
													for (final JsonNode staticIpToHostConfig : staticIpToHostConfigs) {
														PartitionAdvanceStaticHostIps obj= new PartitionAdvanceStaticHostIps();
														//	listSearchDomainName.add(staticIpToHostConfig.asText());
														if(staticIpToHostConfig.has("alias")) {
															obj.setAlias(staticIpToHostConfig.get("alias").asText());
														}
														if(staticIpToHostConfig.has("hostname")) {
															obj.setHostname(staticIpToHostConfig.get("hostname").asText());
														}
														if(staticIpToHostConfig.has("ip")) {
															obj.setIp(staticIpToHostConfig.get("ip").asText());
														}
														listPartitionAdvanceStaticHostIps.add(obj);
													}
													partitionDetailModel.getNetworkStats().getAdvanced().getStaticIpToHostConfig().setAdd(listPartitionAdvanceStaticHostIps);
												}

											}
											Boolean partitionAlreadyExist=true;
											logger.info("Starting of create Partition");
											partitionDetailModel.setBackup(partitionData.isMcoBackupRestore());
											partitionService.createPartition(loggedInUser,partitionDetailModel,partitionAlreadyExist);
										}
									}
								}
								responseModel.setResponseCode("200");
								responseModel.setResponseMessage(env.getProperty("applianceCreation.success"));
								recentActivityServiceImpl.createRecentActivity(loggedInUser, "New device "+app.getApplianceName()+" added by "+loggedInUser+".",CaviumConstant.APPLIANCE_MANAGEMENT);							
							}
						}
					}else {
						alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+" added by "+loggedInUser+" did not exists in the system.",app.getApplianceName(),app.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
						responseModel.setResponseCode("409");
						responseModel.setResponseMessage(env.getProperty("appliance.notexists.cavium.network"));
					}
				} catch (Exception e) {
					logger.error("Error occured due to db error inside createAppliance Method of class ApplianceServiceImpl ::" + e.getMessage());
					responseModel.setResponseCode("500");
					responseModel.setResponseMessage(env.getProperty("applianceCreation.failureDB"));
					alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+" added by "+loggedInUser+" did not exists in the system.",app.getApplianceName(),app.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
				}
			}
		} else {
			logger.error("ApplianceDetailModel is empty or null ::");
			responseModel.setResponseCode("204");
			responseModel.setResponseMessage(env.getProperty("applianceCreation.failureEmpty"));
		}

		return responseModel;
	}

	/*
	 * This method is used to modify the appliance 
	 * (non-Javadoc)
	 * @see com.cavium.service.appliance.ApplianceService#modifyAppliance(java.lang.String, com.cavium.model.appliance.ApplianceDetailModel)
	 */
	@Override
	@Transactional
	public CaviumResponseModel modifyAppliance(String loggedInUser, ApplianceDetailModel applianceDetailModel) {
		CaviumResponseModel responseModel=getCaviumResponseModel();
		CaviumResponseModel response=null;
		try	{
			if(applianceDetailModel!=null && applianceDetailModel.getIpAddress()!=null){
				List<ApplianceDetailModel> isAvailable=applianceRepository.getApplianceExists(applianceDetailModel.getIpAddress());
				ApplianceDetailModel applianceDetailFromDBModel=applianceRepository.findOne(applianceDetailModel.getApplianceId());	
				if(isAvailable.isEmpty()){
					if(applianceDetailModel!=null && applianceDetailModel.getApplianceId()!=null && applianceDetailModel.getApplianceId() > 0) {								 
						if(applianceDetailFromDBModel!=null && applianceDetailFromDBModel.getApplianceId() > 0) {
							if(!StringUtils.isEmpty(applianceDetailModel.getIpAddress())) {
								response=hostAdminVMService.updateApplianceIp(applianceDetailFromDBModel.getIpAddress(), applianceDetailModel.getIpAddress());							
								if(response!=null && response.getResponseCode().equalsIgnoreCase("200")) {
									responseModel.setResponseCode("200");
									responseModel.setResponseMessage("Ip Changed Successfully");
									recentActivityServiceImpl.createRecentActivity(loggedInUser, "device "+applianceDetailFromDBModel.getApplianceName()+" Appliance IP modified successfully by "+loggedInUser+".",CaviumConstant.APPLIANCE_MANAGEMENT);
									response= updateSaveDBCredentails(applianceDetailFromDBModel,applianceDetailModel);	
									if(response!=null && response.getResponseCode().equalsIgnoreCase("200")) {
										responseModel.setResponseCode("200");
										responseModel.setResponseMessage("Saved Credentials modified.");
										recentActivityServiceImpl.createRecentActivity(loggedInUser, "device "+applianceDetailFromDBModel.getApplianceName()+" credentials modified successfully by "+loggedInUser+".",CaviumConstant.APPLIANCE_MANAGEMENT);
									}else{
										responseModel.setResponseCode("409");
										responseModel.setResponseMessage(env.getProperty("applianceModification.failureNotExist"));
										alertsService.createAlert(loggedInUser,"Device "+applianceDetailModel.getApplianceName()+" trying to modify credentials by "+loggedInUser+" and failed due to credentials failed to update in db.",applianceDetailModel.getApplianceName(),applianceDetailModel.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);	
									}
								} else{
									responseModel.setResponseCode("409");
									responseModel.setResponseMessage(env.getProperty("applianceModification.failureNotExist"));
									alertsService.createAlert(loggedInUser,"Device "+applianceDetailModel.getApplianceName()+" trying to modify Ip  by "+loggedInUser+" and failed due to ipAddress failed to update in db.",applianceDetailModel.getApplianceName(),applianceDetailModel.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
								}
							}else{
								responseModel.setResponseCode("409");
								responseModel.setResponseMessage(env.getProperty("applianceModification.failureNotExist"));
								alertsService.createAlert(loggedInUser,"Device "+applianceDetailModel.getApplianceName()+" trying to modify by "+loggedInUser+" and failed due to ipAddress failed to update in db.",applianceDetailModel.getApplianceName(),applianceDetailModel.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
							}
						}
					}
				}else {
					response=updateSaveDBCredentails(applianceDetailFromDBModel,applianceDetailModel);	 
					if(response!=null && response.getResponseCode().equalsIgnoreCase("200")) {
						responseModel.setResponseCode("200");
						responseModel.setResponseMessage("Saved Credentials modified.");
						recentActivityServiceImpl.createRecentActivity(loggedInUser, "device "+applianceDetailFromDBModel.getApplianceName()+" credentials modified successfully by "+loggedInUser+".",CaviumConstant.APPLIANCE_MANAGEMENT);
					}else{
						responseModel.setResponseCode("409");
						responseModel.setResponseMessage(env.getProperty("applianceModification.failureNotExist"));
						alertsService.createAlert(loggedInUser,"Device "+applianceDetailModel.getApplianceName()+" trying to modify credentials by "+loggedInUser+" and failed due to credentials failed to update in db.",applianceDetailModel.getApplianceName(),applianceDetailModel.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);	
					}
				}
			}
			else {
				responseModel.setResponseCode("409");
				responseModel.setResponseMessage(env.getProperty("applianceModification.alredayExist"));
			}
		}catch (Exception e) {
			logger.error("Error occured during Appliance modification :: "+ e.getMessage());
			responseModel.setResponseCode("409");
			responseModel.setResponseMessage("Failed to update due to db error.");
			alertsService.createAlert(loggedInUser,"Device "+applianceDetailModel.getApplianceName()+" trying to modify by "+loggedInUser+" and failed due to db error.",applianceDetailModel.getApplianceName(),applianceDetailModel.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
		}
		return responseModel;	 
	}

	/**
	 * Method is used to delete the particular appliance
	 */
	@Override
	@Transactional
	public CaviumResponseModel deleteAppliances(ApplianceDetailModel app) {
		CaviumResponseModel caviumResponseModel=getCaviumResponseModel();
		String loggedInUser = userAttributes.getlogInUserName();
		if(app!=null && app.getApplianceId()!=null) {
			try {
				logger.info("Deleted Appliance Id :: " +app.getApplianceId());
				DesignationApplianceModel design=designationAppliance.getDesignationModelByApplianceId(app.getApplianceId());
				if(design!=null) {
					String desc=userGroupRepository.getGroupName(design.getDesignationId());
					if(!desc.equalsIgnoreCase("DefaultUserGroup")) {
						/**
						 * move appliance to DefaultUserGroup 
						 */
						List<UserGroupModel> usg=userGroupRepository.findGroupDetailsForGroupName(env.getProperty("user.defaultusergroup")); 
						if(!usg.isEmpty()) {
							UserGroupModel userGroupModel=(UserGroupModel)usg.get(0);
							designationAppliance.updateDesignationId(userGroupModel.getId(), app.getApplianceId());
						}
						caviumResponseModel.setResponseCode("200");
						caviumResponseModel.setResponseMessage("Appliance "+app.getApplianceName()+" removed successfully.");
						recentActivityServiceImpl.createRecentActivity(loggedInUser, "device "+app.getApplianceName()+" removed successfully by "+loggedInUser+".",CaviumConstant.APPLIANCE_MANAGEMENT);
					}else {
						/**
						 * Delete for partition snapshot temp details
						 */
						partitionDetailsWithPercentageRepository.deleteSnapShotGraphDetailsById(app.getApplianceId());
						partitionSnapshotDetailsRepository.deleteSnapShotDetailsById(app.getApplianceId());
						
						logger.info("Starting block.. deleteInProgressByApplianceId");
						/**
						 * Delete in-progress activity and alerts for appliance
						 */
						inProgressActivityRepository.deleteInProgressByApplianceId(app.getApplianceId());
						logger.info("Completed.. deleteInProgressByApplianceId");
						
						logger.info("Starting block.. deleteAlertsByApplianceId");
						alertsRepository.deleteAlertsByApplianceId(app.getApplianceId());

						
						/**
						 * Delete all partitions related records
						 */
						logger.info("Starting block.. getListOfPartitionByApplianceID");
						List<PartitionDetailModel> partlist=partitionRepository.getListOfPartitionByApplianceID(app.getApplianceId());
						if(partlist!=null && partlist.size() > 0) {
							for(PartitionDetailModel partdm: partlist) {
								partdm.setSessionClose(true);
								List<ClusterPartitionsRelationship> clus=clusterPartitionsRelationshipRepository.getListOfClusters(partdm.getPartitionId());
								if(clus!=null && clus.size() > 0) {
									clusterPartitionsRelationshipRepository.deletePartitionFromCluster(partdm.getPartitionId());
									/*for(ClusterPartitionsRelationship cls: clus) {
										clusterRepository.delete(cls.getClusterId());
									}*/
								}
								PartitionDetailModel partitionDetailModel=partitionRepository.findOne(partdm.getPartitionId());
								logger.info("Starting block.. deletePartitionData inside loop");
								if(partitionDetailModel!=null) {
									deletePartitionData(partitionDetailModel);
								}
							}
						}
						
						/**
						 * Delete designation appliance record 
						 */
						logger.info("Deleting deleteDesignationAppliance");
						if(design!=null) {
							designationAppliance.deleteDesignationAppliance(app.getApplianceId());
							logger.info("deleteDesignationAppliance complted successfully.");
						}


						/**
						 * Delete all initialize related records 
						 */
						logger.info("Starting block Delete all initialize related records");
						InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(app.getApplianceId());
						if(initmodel!=null){
							InitializeApplianceDetailModel init=initializeRepository.findOne(initmodel.getInitializeId());
							if(init!=null) {
								initializeRepository.delete(init);
							}
							initializeAppliancesRelationshipReposiotry.delete(initmodel);
							dfUsersRelationshipRepository.deleteDfDetailsForUserAgainstAppliance(loggedInUser,app.getApplianceId());	
							logger.info("Ending Delete all initialize related records successfully");
						}

						/**
						 * Delete monitor data
						 */
						logger.info("Deleting monitor data");
						List<MonitorStats> monitorStats=monitorStatsRepository.getListOfMonistorStatsByApplianceIp(app.getIpAddress());
						if(monitorStats!=null && monitorStats.size() > 0) {
							monitorStatsRepository.delete(monitorStats);
						}
					
						logger.info("Successfully ending delete monitor data");
						/**
						 * Delete appliance in the last
						 */
						logger.info("starting actual delete");
						applianceRepository.deleteAppliance(app.getApplianceId());
						caviumResponseModel.setResponseCode("200");
						caviumResponseModel.setResponseMessage("Appliance "+app.getApplianceName()+" removed successfully.");
						recentActivityServiceImpl.createRecentActivity(loggedInUser, "device "+app.getApplianceName()+" removed successfully by "+loggedInUser+".",CaviumConstant.APPLIANCE_MANAGEMENT);
						logger.info("ending actual delete");
					}
				}
			}
			catch (Exception e) {
				logger.error("Error occured due to db error inside deleteAppliance Method of class ApplianceServiceImpl for "+ app.getApplianceName() +" :: "
						+ e.getMessage());
				caviumResponseModel.setResponseCode("500");
				caviumResponseModel.setResponseMessage(env.getProperty("applianceDeletion.failureDB"));
				alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+" trying to removed by "+loggedInUser+" did not removed due to "+ e.getMessage(),app.getApplianceName(),app.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
			}
		}
		return caviumResponseModel; 
	}

	@Override
	public synchronized ApplianceDetailModel validateAppliance(ApplianceDetailModel applianceDetailModel) {
		// TODO Auto-generated method stub

		try {
			String fipsState=null;
			String loggedInUser = userAttributes.getlogInUserName();
			List<ApplianceDetailModel> isAvailable=applianceRepository.getApplianceExists(applianceDetailModel.getIpAddress());
			if(isAvailable.isEmpty()) {
				List<ApplianceDetailModel> isNameAvailable=applianceRepository.getApplianceNameByGivenName(applianceDetailModel.getApplianceName());
				if(isNameAvailable.isEmpty()) {
					ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/info");
					if(response !=null && response.getStatusCode().name().equals("OK")) {
						String userEnteredfipsState=applianceDetailModel.getFipsState();
						ObjectMapper mapper = new ObjectMapper();
						if(response.getBody()!=null){
							JsonNode root = mapper.readTree(response.getBody());
							if(!root.isNull()){
								JsonNode dataNode = root.path("data");
								if(!dataNode.isNull()){
									if(dataNode.has("fipsState")) {
										String appfipsState = dataNode.path("fipsState").asText();										 
										if(!StringUtils.isEmpty(appfipsState) && appfipsState.contains("-1")){
											fipsState="-1";
										}
										if(!StringUtils.isEmpty(appfipsState) && appfipsState.contains("3")){
											fipsState="3";
										}
										if(!StringUtils.isEmpty(appfipsState) && (appfipsState.contains("0") || appfipsState.contains("2"))){
											fipsState="0";
										}
									}
								}
							}
						}
						if(!StringUtils.isEmpty(userEnteredfipsState) && !userEnteredfipsState.equals(fipsState))
						{
							applianceDetailModel.setErrorMessage("Selected FIPS state is not correct");
							applianceDetailModel.setCode("409");
						}
						if(StringUtils.isEmpty(applianceDetailModel.getCode())){
							List <ApplianceDetailModel> applianceDetailList= new ArrayList<ApplianceDetailModel>();
							applianceDetailList.add(applianceDetailModel);

							applianceDetailList=validateCredentialsByLoginHSM(applianceDetailList);
							for(ApplianceDetailModel applianceDetail: applianceDetailList){
								if("200".equals(applianceDetail.getCode()))
								{
									 if(applianceDetailModel.getApplianceId()!=null){
											dfUsersRelationshipRepository.deleteDfDetailsForUserAgainstAppliance(loggedInUser,applianceDetailModel.getApplianceId());
									}
									else{
										dfUsersRelationshipRepository.deleteDfDetailsForUserAgainstApplianceIp(loggedInUser,applianceDetailModel.getIpAddress());
									} 
									// Appliance can be add to list
									applianceDetailModel.setUserPassword(CaviumUtil.encrypt(applianceDetailModel.getUserPassword()));
									applianceDetailModel.setCode("200");
									applianceDetailModel.setMessage("Appliance added successfully.");
									applianceDetailModel.setCreatedBy(loggedInUser);
									applianceDetailModel.setStoreType(StoreType.TEMP);
									applianceDetailModel.setCryptoUserName(applianceDetailModel.getOperationUsername());
									applianceDetailModel.setCryptoUserPassword(CaviumUtil.encrypt(applianceDetailModel.getOperationPassword()));
									ApplianceDetailModel applianceDetailModeldb=applianceRepository.save(applianceDetailModel);
									applianceDetailModeldb.setOperationUsername(applianceDetailModel.getOperationUsername());
									applianceDetailModeldb.setOperationPassword(applianceDetailModel.getOperationPassword());
									if(!StringUtils.isEmpty(fipsState) && !fipsState.equals("-1")){
										saveZoneDetails(applianceDetailModeldb);
									}
									applianceDetailModel.setCode("200");
									applianceDetailModel.setMessage("Appliance added successfully.");
									applianceDetailModel.setErrorMessage("");
								
								 dfUsersRelationshipRepository.updateAppIpToAppId(applianceDetailModeldb.getApplianceId(),applianceDetailModeldb.getIpAddress());
								}else{
									applianceDetailModel=applianceDetail;
								}
							}				
						}
					}else {
						if(response!=null && response.getStatusCodeValue()== 408){
							applianceDetailModel.setCode("408");
							applianceDetailModel.setErrorMessage("Applaince not reachable.");
						}else {
							applianceDetailModel.setMessage(env.getProperty("appliance.notexists.cavium.network"));
						}
						alertsService.createAlert(loggedInUser,"Device "+applianceDetailModel.getApplianceName()+" added by "+loggedInUser+" "+applianceDetailModel.getErrorMessage()+".",applianceDetailModel.getApplianceName(),applianceDetailModel.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
					}
				}else { 
					applianceDetailModel.setCode("409");
					applianceDetailModel.setErrorMessage(env.getProperty("applianceCreation.failureNameExist"));
				}
			}else {
				applianceDetailModel.setCode("409");
				applianceDetailModel.setErrorMessage(env.getProperty("applianceCreation.failureIPExist"));
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Error occured during appliance validation.. into validateAppliance of class ApplianceServiceIMPL");
		}
		return applianceDetailModel;
	}

	/***
	 * This method is used to get appliance by id.
	 */
	@Override
	public ApplianceDetailModel getApplianceById(String applianceID) {
		// TODO Auto-generated method stub
		ApplianceDetailModel applianceDetailModel = null;
		CaviumResponseModel responseModel=getCaviumResponseModel();

		try {	
			applianceDetailModel = applianceRepository.getApplianceById(Long.parseLong(applianceID), StoreType.PERMANENT);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured due to db error inside getListOfAppliances Method of class ApplianceServiceImpl ::" + e.getMessage());
			responseModel.setResponseCode("500");
			responseModel.setResponseMessage(env.getProperty("applianceList.failureDB"));
		}
		return applianceDetailModel;
	}

	/***
	 * This method is used to get appliance by id.
	 */
	@Override
	public List<ApplianceDetailModel> listOfApplianceByGroupId(String loggedInUser) {
		// TODO Auto-generated method stub
		List<ApplianceDetailModel>  applianceDetailModel = null;
		CaviumResponseModel responseModel=getCaviumResponseModel();
		try {
			UserDetailModel objUserDetailModel=userRepository.findOne(loggedInUser);
			if(objUserDetailModel!=null && objUserDetailModel.getObjUserACLDetailsModel().getAclName().equals(env.getProperty("user.superadmin"))) {
				applianceDetailModel = applianceRepository.getAllListOfAppliances(StoreType.PERMANENT);
			}else {
				applianceDetailModel = applianceRepository.getListOfApplianceByGroupId(loggedInUser);
			}
			inProgressActivityRepository.deleteInProgressActivityByStatus();
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured due to db error inside getListOfAppliances Method of class ApplianceServiceImpl ::" + e.getMessage());
			responseModel.setResponseCode("500");
			responseModel.setResponseMessage(env.getProperty("applianceList.failureDB"));
		}
		return applianceDetailModel;
	}

	/***
	 * This method is used to reboot the appliance and update last operation performed column in db
	 */

	@Override
	public void rebootAppliance(ApplianceDetailModel app, String loggedInUser) {
		// TODO Auto-generated method stub
		try {
			if (app!=null) {
				ResponseEntity<String> response = null;
				ApplianceDetailModel dbAppliance = applianceRepository.findOne(app.getApplianceId());
				if (dbAppliance != null) {
					JSONObject body = new JSONObject(); 
					body=getUserNamePassword(app, body,loggedInUser);
					if(body!=null && body.length() > 0) {
						logger.info("Reboot starting.. for "+app.getApplianceName()+"");
						response = restClient.invokePOSTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/system_reboot",body);
						logger.info("for "+app.getApplianceName()+" "+response);
						if (response != null && response.getBody() != null) {
							ObjectMapper mapper = new ObjectMapper();
							JsonNode root = mapper.readTree(response.getBody());
							if (response != null && response.getBody() != null && response.getBody().contains("success")) {
								updateInProgressActivity(dbAppliance, loggedInUser, root);
							} else {
								dbAppliance = getErrorMessage(response, dbAppliance, loggedInUser, "Reboot");
								applianceRepository.save(dbAppliance);
								Long applianceId=dbAppliance.getApplianceId();
								int numberOfpartitions=partitionRepository.getNumberofInprogressPartitions(applianceId);
								if(numberOfpartitions==0){
									boolean grayedOut=false;
									partitionRepository.updateGrayedOut(grayedOut, applianceId);
								}
								//Long partitionId=Long.valueOf("-1");
								//partitionRepository.updateInProgressStatusToActualStatus(applianceId,partitionId);
							}
						} else {
							dbAppliance = getErrorMessage(response, dbAppliance, loggedInUser, "Reboot");
							applianceRepository.save(dbAppliance);
							Long applianceId=dbAppliance.getApplianceId();
							int numberOfpartitions=partitionRepository.getNumberofInprogressPartitions(applianceId);
							if(numberOfpartitions==0){
								boolean grayedOut=false;
								partitionRepository.updateGrayedOut(grayedOut, applianceId);
							}
							//Long partitionId=Long.valueOf("-1");
							//partitionRepository.updateInProgressStatusToActualStatus(applianceId,partitionId);
						}
					}else {
						dbAppliance.setLastOperationPerformed(env.getProperty("appliance.reboot"));
						dbAppliance.setLastOperationStatus("Failed");
						dbAppliance.setApplianceinitialized(app.isApplianceinitialized());
						dbAppliance.setCode("412");
						dbAppliance.setMessage("");
						dbAppliance.setErrorMessage("Failed due to credentials not found.");
						applianceRepository.save(dbAppliance);
						partitionRepository.updateGrayedOut(false, app.getApplianceId());	
					}
				} else {
					app.setCode("409");
					app.setMessage(env.getProperty("appliance.notexists.cavium"));
					alertsService.createAlert(loggedInUser, "Device " + app.getApplianceName()
					+ "  try to perform reboot by " + loggedInUser + " did not exist in cavium netwoork.",app.getApplianceName(),app.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
				}
			}
		}catch (Exception e) {
			// TODO: handle exception
			logger.info("Error occured during appliance rebootAppliance.. into rebootAppliance of class ApplianceServiceIMPL");
		}
	}

	/***
	 * This method is used to reboot the appliance and update last operation performed column in db
	 */
	@Override
	public void zeroizeAppliance(String loggedInUser,ApplianceDetailModel app) {
		// TODO Auto-generated method stub
		List<ApplianceDetailModel> responseList=new ArrayList<ApplianceDetailModel>();
		// TODO Auto-generated method stub
		List<ApplianceDetailModel> clusterFailureList=new ArrayList<>();
		try {
			try {
				ResponseEntity<String> response=null;
				List<PartitionDetailModel> partlist = partitionRepository.getListOfPartitionByApplianceID(app.getApplianceId());
				if (partlist != null && partlist.size() > 0) {
					for (PartitionDetailModel partdm : partlist) {
						List<ClusterPartitionsRelationship> clus = clusterPartitionsRelationshipRepository.getListOfClusters(partdm.getPartitionId());
						if (clus != null && clus.size() > 0) {
							clusterFailureList.add(app);
						}
					}
				}
				if(clusterFailureList!=null && clusterFailureList.size() == 0) {
					ApplianceDetailModel dbAppliance=applianceRepository.findOne(app.getApplianceId()); 
					Map<String,Object> map=new HashMap<>();
					JSONObject json = new JSONObject(); 
					if(dbAppliance!=null) {
						if(app.getType()!=null && !app.getType().equalsIgnoreCase("adapter")){
							json.put("type",app.getType());
						}
						if(app.getForceZeroize()!=null && app.getType()!=null && app.getType().equalsIgnoreCase("adapter")){
							json.put("forceZeroize",app.getForceZeroize().booleanValue());
						}
						long applianceId=dbAppliance.getApplianceId();
						List<DualFactorUsersRelationshipModel> dfmodelList=dfUsersRelationshipRepository.getDualFactorDetails(loggedInUser, applianceId);		
						DualFactorUsersRelationshipModel dfmodel=null;
						if(dfmodelList!=null && dfmodelList.size()>0){
							dfmodel=dfmodelList.get(0);
						}

						InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(applianceId);
						if(initmodel!=null) {
							InitializeApplianceDetailModel initAppDetailModel = initializeRepository.findOne(initmodel.getInitializeId());
							DualFactorAuthDetailModel dualAuthModel=initAppDetailModel.getDualFactorAuthDetailModel();
							if(!StringUtils.isEmpty(app.getOperationUsername()) && !StringUtils.isEmpty(app.getOperationPassword())) {
								if(initAppDetailModel.getAuthenticationLevel()==0) {
									map.put("username", app.getOperationUsername());
									map.put("password", app.getOperationPassword());
								}if(initAppDetailModel.getAuthenticationLevel()==1) {
									if(initAppDetailModel.getAuthenticationLevel() == 1 && dfmodel==null){
										dfmodel=createDualFile(loggedInUser, dbAppliance.getApplianceId(),initAppDetailModel.getCryptoOfficerName(),CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()),dualAuthModel);
									}
									map.put("username", app.getOperationUsername());
									map.put("password", app.getOperationPassword());										
									map.put("dualFactorKeyFile", dfmodel.getDualFactorKeyFileId());
									map.put("dualFactorPort", Integer.parseInt(dfmodel.getDualFactorAuthServerPortNo()));
									map.put("dualFactorCertificate", dfmodel.getDualFactorCertificateId());
								}
								if(!app.getType().equalsIgnoreCase("adapter")) {
									json.put("mcoLoginInfo", map);
								}
							}else {
								if(initAppDetailModel.getAuthenticationLevel()==0) {
									map.put("username", initAppDetailModel.getCryptoOfficerName());
									map.put("password", CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));
								}
								if(initAppDetailModel.getAuthenticationLevel() == 1 && dfmodel==null){
									dfmodel=createDualFile(loggedInUser, dbAppliance.getApplianceId(),initAppDetailModel.getCryptoOfficerName(),CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()),dualAuthModel);
								}
								if(initAppDetailModel.getAuthenticationLevel()==1) {
									map.put("username", initAppDetailModel.getCryptoOfficerName());
									map.put("password", CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));
									map.put("dualFactorKeyFile", dfmodel.getDualFactorKeyFileId());
									map.put("dualFactorPort", Integer.parseInt(dfmodel.getDualFactorAuthServerPortNo()));
									map.put("dualFactorCertificate", dfmodel.getDualFactorCertificateId());
								}
								if(!app.getType().equalsIgnoreCase("adapter")) {
									json.put("mcoLoginInfo", map);
								}
							}
							response=restClient.invokePOSTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/zeroize",json);
						}else {
							if(dfmodel!=null){
								map.put("dualFactorKeyFile", dfmodel.getDualFactorKeyFileId());
								map.put("dualFactorPort", Integer.parseInt(dfmodel.getDualFactorAuthServerPortNo()));
								map.put("dualFactorCertificate", dfmodel.getDualFactorCertificateId());
							}
							if(!StringUtils.isEmpty(app.getOperationUsername()) && !StringUtils.isEmpty(app.getOperationPassword())) {
								map.put("username", app.getOperationUsername());
								map.put("password", app.getOperationPassword());
								if(!app.getType().equalsIgnoreCase("adapter")) {
									json.put("mcoLoginInfo", map);
								}
								response=restClient.invokePOSTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/zeroize",json);
							}else {
								app.setMessage("Appliance not zeroized due to credentials not available");
								alertsService.createAlert(loggedInUser,"zeroize performed on device "+app.getApplianceName()+" by "+loggedInUser+" did not zeroize due to credentials not available.",app.getApplianceName(),app.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
							}
						}

						if(response!=null && response.getBody()!=null)
						{
							ObjectMapper mapper = new ObjectMapper();
							JsonNode root = mapper.readTree(response.getBody());
							if(response!=null && response.getBody()!=null && response.getBody().contains("success")) {
								dbAppliance.setLastOperationPerformed(env.getProperty("appliance.zeroize"));
								dbAppliance.setLastOperationStatus("In-Progress");
								dbAppliance.setCode("200");
								dbAppliance.setErrorMessage("");
								dbAppliance.setMessage(env.getProperty("appliance.zeroize.success"));
								applianceRepository.save(dbAppliance);

								updateInProgressActivity(dbAppliance, loggedInUser, root);
							}else {
								dbAppliance = getErrorMessage(response, dbAppliance, loggedInUser, "Zeroize");
								applianceRepository.save(dbAppliance);
								applianceRepository.updateGrayedOut(false, applianceId);
								partitionRepository.updateGrayedOut(false, applianceId);
							}	
						}else {
							dbAppliance = getErrorMessage(response, dbAppliance, loggedInUser, "Zeroize");
							applianceRepository.save(dbAppliance);
							applianceRepository.updateGrayedOut(false, applianceId);
							partitionRepository.updateGrayedOut(false, applianceId);
						}
						responseList.add(dbAppliance);
					}else {
						app.setCode("409");
						app.setMessage(env.getProperty("appliance.notexists.cavium"));
						alertsService.createAlert(loggedInUser,"zeroize performed on device "+app.getApplianceName()+" by "+loggedInUser+" did not exist in system.",app.getApplianceName(),app.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
						responseList.add(app);
						applianceRepository.updateGrayedOut(false, app.getApplianceId());
						partitionRepository.updateGrayedOut(false, app.getApplianceId());
					}
				}else {
					app.setCode("409");
					app.setLastOperationPerformed(env.getProperty("appliance.zeroize"));
					app.setLastOperationStatus("Failed");
					app.setErrorMessage(env.getProperty("appliance.partitionexists.cluster"));
					app.setMessage("");
					alertsService.createAlert(loggedInUser,"zeroize performed on device "+app.getApplianceName()+" by "+loggedInUser+" but failed due to cluster association.",app.getApplianceName(),app.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
					responseList.add(app);
					applianceRepository.updateGrayedOut(false, app.getApplianceId());
					partitionRepository.updateGrayedOut(false, app.getApplianceId());
				}
			} catch (Exception e) {
				// TODO: handle exception
				logger.info("Error occured during appliance zeroizeAppliance.. into zeroizeAppliance of class ApplianceServiceIMPL");
			}
		}catch (Exception e) {
			// TODO: handle exception
			logger.info("Error occured during appliance zeroizeAppliance.. into zeroizeAppliance of class ApplianceServiceIMPL");
		}
	}


	/***
	 * This method is used to initilizeAppliance the appliance and update last operation performed column in db
	 */
	@Override
	@Transactional
	public List<ApplianceDetailModel> initilizeAppliance(String loggedInUser, InitializeApplianceDetailModel initializeApplianceDetailModel) throws RuntimeException{
		logger.error("Start of initilizeAppliance method"); 
		List<ApplianceDetailModel> listApplianceDetailModel= new ArrayList<ApplianceDetailModel>();	
		synchronized (initializeApplianceDetailModel) {
			
			ApplianceDetailModel objApplianceDetailModel=null;
			CaviumResponseModel caviumResponseModel=null;
			
			if(initializeApplianceDetailModel.getAuthenticationLevel()!=null){
				if(initializeApplianceDetailModel.getApplianceDetailModels()!=null && initializeApplianceDetailModel.getApplianceDetailModels().size()>0 ){
					
					for(ApplianceDetailModel appliance: initializeApplianceDetailModel.getApplianceDetailModels()) {
						
						initializeApplianceDetailModel.setApplianceId(appliance.getApplianceId());
						DualFactorUsersRelationshipModel dualFactorUsersRelationship=null;
						
						try{
							if(initializeApplianceDetailModel.getAuthenticationLevel()==1){
								List<DualFactorUsersRelationshipModel> dfmodelList=null;
								if(appliance.getApplianceId()!=null){
									dfmodelList=dfUsersRelationshipRepository.getDualFactorDetails(loggedInUser, appliance.getApplianceId());	
								}
								/**
								 * This method will return dualFactor Details
								 */if(dfmodelList.size()==0 && initializeApplianceDetailModel.getDualFactorAuthDetailModel().getCertificateContent()!=null) {
										dualFactorUsersRelationship=getDualFactorUsersRelationshipViaFileUpload(dualFactorUsersRelationship, initializeApplianceDetailModel, appliance, loggedInUser);
								 }else {
									 if(dfmodelList!=null && dfmodelList.size() > 0) {
										 dualFactorUsersRelationship=dfmodelList.get(0);
									 }
								 }
								if(dualFactorUsersRelationship==null) {
									logger.error("Error occured during certificate file to network."); 
									throw new RuntimeException("FileUploadError");
									}
								}
								initializeApplianceDetailModel.setConfirmCryptoOfficerpassword(CaviumUtil.encrypt(initializeApplianceDetailModel.getConfirmCryptoOfficerpassword()));
								initializeApplianceDetailModel.setCryptoOfficerPassword(CaviumUtil.encrypt(initializeApplianceDetailModel.getCryptoOfficerPassword()));						
								
								InitializeApplianceDetailModel dbinitializeApplianceDetailModel=initializeRepository.save(initializeApplianceDetailModel);
								objApplianceDetailModel= initilizeApplianceRelationship(loggedInUser,appliance,initializeApplianceDetailModel,dbinitializeApplianceDetailModel.getInitialize_id(),caviumResponseModel,dualFactorUsersRelationship);
								
								listApplianceDetailModel.add(objApplianceDetailModel);
								
								logger.info("Appliance Initilized Succesfully"); 
						}
						catch (Exception e) {
							logger.error("Error coming while initilize Appliance in initilizeAppliance method"+e.getMessage()); 
							applianceRepository.updateGrayedOut(false, appliance.getApplianceId());
							partitionRepository.updateGrayedOut(false, appliance.getApplianceId());
							throw new RuntimeException(e.getMessage());
						}
					}
				}
			}
		}
		logger.info("End of initilizeAppliance method"); 
		return listApplianceDetailModel;
	}
	@Override
	@Transactional
	public ApplianceDetailModel  initilizeApplianceRelationship(String loggedInUser, ApplianceDetailModel applianceDetailModel, InitializeApplianceDetailModel initializeApplianceDetailModel,Long initializeId,CaviumResponseModel caviumResponseModel,DualFactorUsersRelationshipModel dualFactorUsersRelationship) throws RuntimeException{
		synchronized (initializeApplianceDetailModel) {
			ApplianceDetailModel dbAppliance=applianceRepository.findOne(applianceDetailModel.getApplianceId()); 
			if(dbAppliance!=null) {
				InitializeAppliancesRelationshipModel initializeAppliancesRelationshipModel=new InitializeAppliancesRelationshipModel();
				initializeAppliancesRelationshipModel.setInitializeId(initializeId);
				initializeAppliancesRelationshipModel.setApplianceDetailModel(dbAppliance);
				if(initializeApplianceDetailModel.isCredentialSaved()){
					initializeAppliancesRelationshipModel.setOperationPerformUserName(initializeApplianceDetailModel.getUserName());
					initializeAppliancesRelationshipModel.setOperationPerformPassword(CaviumUtil.encrypt(initializeApplianceDetailModel.getPassword()));
				}
				/**
				 * Creating json request for Initialize api
				 */
				JSONObject json = new JSONObject(); 
				json=getJsonForInitializeApi(initializeApplianceDetailModel, dualFactorUsersRelationship, json);
				
				try{
					ResponseEntity<String> response=restClient.invokePOSTMethodForOperations("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/initialize", json);
					if (response != null && response.getBody() != null) {
						ObjectMapper mapper = new ObjectMapper();
						JsonNode root = mapper.readTree(response.getBody());
						if(response!=null && response.getBody()!=null && response.getBody().contains("success")) {
							long applianceId=applianceDetailModel.getApplianceId();
							InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(applianceId);
							if(initmodel!=null){
								initializeRepository.delete(initmodel.getInitializeId());
								initializeAppliancesRelationshipReposiotry.delete(initmodel.getId());
							}
							applianceRepository.save(dbAppliance);
							initializeAppliancesRelationshipReposiotry.save(initializeAppliancesRelationshipModel);    
							dbAppliance.setLastOperationPerformed(env.getProperty("appliance.initialize"));
							dbAppliance.setLastOperationStatus("In-Progress");
							dbAppliance.setCode("200");
							dbAppliance.setMessage(env.getProperty("appliance.initialize.success"));
							dbAppliance.setCredentialSaved(initializeApplianceDetailModel.isCredentialSaved());
							dbAppliance.setApplianceinitialized(true);
							if(dualFactorUsersRelationship!=null){
								dbAppliance.setApplianceDualFactorInitialized(true);								 
							}
							applianceRepository.save(dbAppliance);
							updateInProgressActivity(dbAppliance, loggedInUser, root);
							if(dualFactorUsersRelationship!=null) {
								dfUsersRelationshipRepository.delete(dualFactorUsersRelationship);
							}
						}else {
						    revertInitializeData(response, dbAppliance, loggedInUser, dualFactorUsersRelationship, initializeApplianceDetailModel);
						}
					}else {
						 revertInitializeData(response, dbAppliance, loggedInUser, dualFactorUsersRelationship, initializeApplianceDetailModel);
					}
				}catch (Exception e) {
					 revertInitializeData(null, dbAppliance, loggedInUser, dualFactorUsersRelationship, initializeApplianceDetailModel);
				}
			}else {
				dbAppliance=applianceDetailModel;
				dbAppliance.setCode("409");
				dbAppliance.setMessage("appliance did not exists into the system");
			}
			return dbAppliance;
		}
	}

	/*
	 * This method is used to get AdminHost Details from Cavium REST API
	 * 
	 */
	public HostStats GetHostAdminVMStats(ApplianceDetailModel applianceDetailModel,HostStats hostStats,String apiName){
		try{
			ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/"+apiName);
			if(response!=null && response.getStatusCode().name().equals("OK")) {
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						String status = root.path("status").asText();
						String operation = root.path("operation").asText();
						String partitionName = root.path("partitionName").asText();
						long startTime = root.path("startTime").asLong();
						long endTime = root.path("endTime").asLong();
						String startDateTime=CaviumUtil.formatDatefromLong(startTime);
						String endDateTime=CaviumUtil.formatDatefromLong(endTime);
						String message = root.path("message").asText();
						String jobId = root.path("jobId").asText();
						JsonNode dataNode = root.path("data");
						hostStats.setStatus(status);
						hostStats.setEndTime(endDateTime);
						hostStats.setStartTime(startDateTime);
						hostStats.setOperation(operation);
						hostStats.setPartitionName(partitionName);
						hostStats.setMessage(message);
						hostStats.setJobId(jobId);						 
						/*	if(!errors.isNull()){
							Iterator<JsonNode> itr = errors.elements();					         
							while (itr.hasNext()) {
								JsonNode temp = itr.next();
							}
						}*/
						if(!dataNode.isNull()){
							if(dataNode.has("vmstats")){
								Data data = new Data();
								hostStats.setDataObject(data);
								JsonNode vmstatsNode = dataNode.path("vmstats");
								if(!vmstatsNode.isNull()){
									Vmstats vmstats= new Vmstats();
									data.setVmstatsObject(vmstats);
									if(vmstatsNode.has("cavServerStatus")){										
										double cavServerStatus=vmstatsNode.path("cavServerStatus").asDouble();
										vmstats.setCavServerStatus(cavServerStatus);
									}
									if(vmstatsNode.has("systemUpTime")){										
										JsonNode systemUpTimeNode = vmstatsNode.path("systemUpTime");
										if(!systemUpTimeNode.isNull()){
											long totalSeconds=0;
											SystemUpTime systemUpTime= new SystemUpTime();
											vmstats.setSystemUpTimeObject(systemUpTime);
											if(systemUpTimeNode.has("hours")){
												long hours=systemUpTimeNode.path("hours").asLong();
												systemUpTime.setHours(hours);
												totalSeconds=totalSeconds+CaviumUtil.hoursToSeconds(hours);
											}
											if(systemUpTimeNode.has("minutes")){
												long minutes=systemUpTimeNode.path("minutes").asLong();
												systemUpTime.setMinutes(minutes);
												totalSeconds=totalSeconds+CaviumUtil.minutesToSeconds(minutes);
											}
											if(systemUpTimeNode.has("seconds")){
												long seconds=systemUpTimeNode.path("seconds").asLong();
												systemUpTime.setSeconds(seconds);
												totalSeconds=totalSeconds+seconds;
											}
											systemUpTime.setFormatedDate(CaviumUtil.timeInDaysHoursFormat(totalSeconds));
										}
									}
									if(vmstatsNode.has("rxQueue")){
										JsonNode rxQueueNode = vmstatsNode.path("rxQueue");
										if(!rxQueueNode.isNull()){
											RxQueue rxQueue= new RxQueue();
											vmstats.setRxQueueObject(rxQueue);
											if(rxQueueNode.has("rdt")){
												double rdt=rxQueueNode.path("rdt").asDouble();
												rxQueue.setRdt(rdt);
											}
											if(rxQueueNode.has("rdh")){
												double rdh=rxQueueNode.path("rdh").asDouble();
												rxQueue.setRdh(rdh);
											}						 
										}
									}
									if(vmstatsNode.has("drvReqIdQueue")){
										JsonNode drvReqIdQueueNode = vmstatsNode.path("drvReqIdQueue");
										if(!drvReqIdQueueNode.isNull()){
											DrvReqIdQueue drvReqIdQueue = new DrvReqIdQueue();
											vmstats.setDrvReqIdQueueObject(drvReqIdQueue);
											if(drvReqIdQueueNode.has("head")){
												double head=drvReqIdQueueNode.path("head").asDouble();
												drvReqIdQueue.setHead(head);
											}
											if(drvReqIdQueueNode.has("tail")){
												double tail=drvReqIdQueueNode.path("tail").asDouble();
												drvReqIdQueue.setTail(tail);
											}						 
										}
									}
									if(vmstatsNode.has("ramStats(mb)")){
										JsonNode ramStatsNode = vmstatsNode.path("ramStats(mb)");
										if(!ramStatsNode.isNull()){
											RamStats ramStats= new RamStats();
											vmstats.setRamStats(ramStats);
											if(ramStatsNode.has("total")){
												double total=ramStatsNode.path("total").asDouble();
												ramStats.setTotal(total);
											}
											if(ramStatsNode.has("free")){
												double free=ramStatsNode.path("free").asDouble();
												ramStats.setFree(free);
											}	
											ramStats.setUsed(ramStats.getTotal()-ramStats.getFree());
											ramStats.setUsedPercentage(CaviumUtil.calculatePercetage(ramStats.getTotal(),ramStats.getUsed()));
										}
									}		
									if(vmstatsNode.has("txQueue")){
										JsonNode txQueueNode = vmstatsNode.path("txQueue");
										if(!txQueueNode.isNull()){
											TxQueue txQueue= new TxQueue();
											vmstats.setTxQueueObject(txQueue);
											if(txQueueNode.has("tdh")){
												double tdh=txQueueNode.path("tdh").asDouble();
												txQueue.setTdh(tdh);
											}
											if(txQueueNode.has("tdt")){
												double tdt=txQueueNode.path("tdt").asDouble();
												txQueue.setTdt(tdt);
											}						 
										}
									}
									if(vmstatsNode.has("fwReqIdQueue")){
										JsonNode fwReqIdQueueNode = vmstatsNode.path("fwReqIdQueue");
										if(!fwReqIdQueueNode.isNull()){
											FwReqIdQueue fwReqIdQueue= new FwReqIdQueue();
											vmstats.setFwReqIdQueueObject(fwReqIdQueue);
											if(fwReqIdQueueNode.has("head")){
												double head=fwReqIdQueueNode.path("head").asDouble();
												fwReqIdQueue.setHead(head);
											}
											if(fwReqIdQueueNode.has("tail")){
												double tail=fwReqIdQueueNode.path("tail").asDouble();
												fwReqIdQueue.setTail(tail);
											}						 
										}
									}
									if(vmstatsNode.has("swapStats(mb)")){
										JsonNode swapStatsNode = vmstatsNode.path("swapStats(mb)");
										if(!swapStatsNode.isNull()){
											SwapStats swapStats= new SwapStats();
											vmstats.setSwapStats(swapStats);
											if(swapStatsNode.has("total")){
												double total=swapStatsNode.path("total").asDouble();
												swapStats.setTotal(total);
											}
											if(swapStatsNode.has("free")){
												double free=swapStatsNode.path("free").asDouble();
												swapStats.setFree(free);
											}

											swapStats.setUsedPercentage(CaviumUtil.calculatePercetage(swapStats.getTotal(),swapStats.getUsed()));
										}
									}							
									if(vmstatsNode.has("linkStatus(eth0)")){
										double linkStatusEth0=vmstatsNode.path("linkStatus(eth0)").asDouble();
										vmstats.setLinkStatusEth0(linkStatusEth0);
									}
									if(vmstatsNode.has("cpuUsage(%)")){
										double cpuUsage=vmstatsNode.path("cpuUsage(%)").asDouble();	
										vmstats.setCpuUsage(cpuUsage);
									}
									if(vmstatsNode.has("linkStatus(eth1)")){
										double linkStatusEth01=vmstatsNode.path("linkStatus(eth1)").asDouble();
										vmstats.setLinkStatusEth1(linkStatusEth01);
									}
									if(vmstatsNode.has("processCount")){
										double processCount=vmstatsNode.path("processCount").asDouble();
										vmstats.setProcessCount(processCount);
									}
									if(vmstatsNode.has("freeSpace(mb)")){
										double freeSpace=vmstatsNode.path("freeSpace(mb)").asDouble();
										vmstats.setFreeSpace(freeSpace);									 
									}
									if(vmstatsNode.has("driverStatus")){
										double driverStatus=vmstatsNode.path("driverStatus").asDouble();
										vmstats.setDriverStatus(driverStatus);		
										if(driverStatus==0){
											vmstats.setDriverStatusStr("down");
										}
										if(driverStatus==1){
											vmstats.setDriverStatusStr("Up");
										}
									}		
								}

							}
						}
					}
				}
			}
		}catch(Exception exp){
			logger.error("Error occured during fetch AdminHostStats Info of class ApplianceServiceImpl ::" + exp.getMessage());
		}
		return hostStats;
	}
	/*
	 * This method is used to get Appliance Information from Cavium REST API 
	 *
	 */
	public ApplianceInfo GetApplianceInfo(ApplianceDetailModel applianceDetailModel ,ApplianceInfo applianceInfo){
		try{
			ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/appliance_info");
			if(response!=null && response.getStatusCode().name().equals("OK")) {
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						String status = root.path("status").asText();
						//JsonNode errors = root.path("errors");
						String operation = root.path("operation").asText();
						long startTime = root.path("startTime").asLong();
						long endTime = root.path("endTime").asLong();
						String startDateTime=CaviumUtil.formatDatefromLong(startTime);
						String endDateTime=CaviumUtil.formatDatefromLong(endTime);
						String message = root.path("message").asText();
						applianceInfo.setStatus(status);
						applianceInfo.setOperation(operation);
						applianceInfo.setStartTime(startDateTime);
						applianceInfo.setEndTime(endDateTime);
						applianceInfo.setErrorMessage(message);
						/*	if(!errors.isNull()){
							Iterator<JsonNode> itr = errors.elements();					         
							while (itr.hasNext()) {
								JsonNode temp = itr.next();    
							}
						}	*/					
						JsonNode dataNode = root.path("data");
						if(!dataNode.isNull()){
							if(dataNode.has("linuxVersion")) {
								String linuxVersion = dataNode.path("linuxVersion").asText();
								applianceInfo.setLinuxVersion(linuxVersion);
							}
							if(dataNode.has("serialNum")) {
								String serialNum = dataNode.path("serialNum").asText();
								applianceInfo.setSerialNum(serialNum);
							}
							if(dataNode.has("firmwareVersion")) {
								String firmwareVersion = dataNode.path("firmwareVersion").asText();
								applianceInfo.setFirmwareVersion(firmwareVersion);
							}
							if(dataNode.has("amiVersion")) {
								String amiVersion = dataNode.path("amiVersion").asText();
								applianceInfo.setAmiVersion(amiVersion);
							}
						}
					}
				}
			}		
		}catch(Exception exp){
			logger.error("Error occured during fetch Appliance Info of class ApplianceServiceImpl ::" + exp.getMessage());	
		}
		return applianceInfo;
	}

	/*
	 * This method is used to get HSM Information from Cavium REST API 
	 *  
	 */

	public HSMInfo getHSMInfo(ApplianceDetailModel applianceDetailModel,HSMInfo objHSMInfo){
		try{

			ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/info");
			if(response!=null && response.getStatusCode().name().equals("OK")) {
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						String status = root.path("status").asText();
						//JsonNode errors = root.path("errors");
						String operation = root.path("operation").asText();
						String partitionName = root.path("partitionName").asText();
						long startTime = root.path("startTime").asLong();
						long endTime = root.path("endTime").asLong();
						String startDateTime=CaviumUtil.formatDatefromLong(startTime);
						String endDateTime=CaviumUtil.formatDatefromLong(endTime);
						String message = root.path("message").asText();
						int jobId = root.path("jobId").asInt();
						JsonNode dataNode = root.path("data");
						objHSMInfo.setStatus(status);
						objHSMInfo.setOperation(operation);
						objHSMInfo.setPartitionName(partitionName);
						objHSMInfo.setStartTime(startDateTime);
						objHSMInfo.setEndTime(endDateTime);
						objHSMInfo.setErrorMessage(message);
						objHSMInfo.setJobId(jobId);
						/*	if(!errors.isNull()){
							Iterator<JsonNode> itr = errors.elements();                                       
							while (itr.hasNext()) {
								JsonNode temp = itr.next();                                              
							}
						}*/
						if(!dataNode.isNull()){
							if(dataNode.has("totalPublicMemory(KB)")) {
								int totalPublicMemory = dataNode.path("totalPublicMemory(KB)").asInt();
								objHSMInfo.setTotalPublicMemory(totalPublicMemory);
							}
							if(dataNode.has("mwVersion")) {
								String mwVersion = dataNode.path("mwVersion").asText();
								objHSMInfo.setMwVersion(mwVersion);
							}
							if(dataNode.has("hardwareMinor")) {
								String hardwareMinor = dataNode.path("hardwareMinor").asText();
								objHSMInfo.setHardwareMinor(hardwareMinor);
							}
							if(dataNode.has("systemVendorId")) {
								String systemVendorId = dataNode.path("systemVendorId").asText();
								objHSMInfo.setSystemVendorId(systemVendorId);
							}
							if(dataNode.has("cuLoginFailure")) {
								int cuLoginFailure = dataNode.path("cuLoginFailure").asInt();
								objHSMInfo.setCuLoginFailure(cuLoginFailure);
							}
							if(dataNode.has("rwSessionCount")) {
								int rwSessionCount = dataNode.path("rwSessionCount").asInt();
								objHSMInfo.setRwSessionCount(rwSessionCount);
							}
							if(dataNode.has("coLoginFailure")) {
								int coLoginFailure = dataNode.path("coLoginFailure").asInt();
								objHSMInfo.setCoLoginFailure(coLoginFailure);
							}
							if(dataNode.has("freePrivateMemory(KB)")) {
								int freePrivateMemory = dataNode.path("freePrivateMemory(KB)").asInt();
								objHSMInfo.setFreePrivateMemory(freePrivateMemory);
							}
							if(dataNode.has("slaveConfig")) {
								String slaveConfig = dataNode.path("slaveConfig").asText();
								objHSMInfo.setSlaveConfig(slaveConfig);
							}
							if(dataNode.has("temperature")) {
								String temperature = dataNode.path("temperature").asText();
								objHSMInfo.setTemperature(temperature);
							}
							if(dataNode.has("firmwareMajor")) {
								String firmwareMajor = dataNode.path("firmwareMajor").asText();
								objHSMInfo.setFirmwareMajor(firmwareMajor);;
							}
							if(dataNode.has("label")) {
								String label = dataNode.path("label").asText();
								objHSMInfo.setLabel(label);
							}
							if(dataNode.has("subSystemId")) {
								String subSystemId = dataNode.path("subSystemId").asText();
								objHSMInfo.setSubSystemId(subSystemId);
							}
							if(dataNode.has("manufacturerId")) {
								String manufacturerId = dataNode.path("manufacturerId").asText();
								objHSMInfo.setManufacturerId(manufacturerId);
							}
							if(dataNode.has("masterConfig")) {
								String masterConfig = dataNode.path("masterConfig").asText();
								objHSMInfo.setMasterConfig(masterConfig);
							}
							if(dataNode.has("authenticationPath")) {
								int authenticationPath = dataNode.path("authenticationPath").asInt();
								objHSMInfo.setAuthenticationPath(authenticationPath);

							}
							if(dataNode.has("classCode")) {
								int classCode = dataNode.path("classCode").asInt();
								objHSMInfo.setClassCode(classCode);
							}
							if(dataNode.has("maxSessionCount")) {
								int maxSessionCount = dataNode.path("maxSessionCount").asInt();
								objHSMInfo.setMaxSessionCount(maxSessionCount);
							}
							if(dataNode.has("manufacturerId")) {
								String manufacturerId = dataNode.path("manufacturerId").asText();
								objHSMInfo.setManufacturerId(manufacturerId);
							}
							if(dataNode.has("sessionCount")) {
								int sessionCount = dataNode.path("sessionCount").asInt();
								objHSMInfo.setSessionCount(sessionCount);
							}
							if(dataNode.has("firmwareId")) {
								String firmwareId = dataNode.path("firmwareId").asText();
								objHSMInfo.setFirmwareId(firmwareId);
							}
							if(dataNode.has("maxRwSessionCount")) {
								int maxRwSessionCount = dataNode.path("maxRwSessionCount").asInt();
								objHSMInfo.setMaxRwSessionCount(maxRwSessionCount);
							}
							if(dataNode.has("buildNumber")) {
								String buildNumber = dataNode.path("buildNumber").asText();
								objHSMInfo.setBuildNumber(buildNumber);
							}
							if(dataNode.has("hardwareMajor")) {
								String hardwareMajor = dataNode.path("hardwareMajor").asText();
								objHSMInfo.setHardwareMajor(hardwareMajor);
							}
							if(dataNode.has("minPswdLen")) {
								int minPswdLen = dataNode.path("minPswdLen").asInt();
								objHSMInfo.setMinPswdLen(minPswdLen);
							}
							if(dataNode.has("maxPswdLen")) {
								int maxPswdLen = dataNode.path("maxPswdLen").asInt();
								objHSMInfo.setMaxPswdLen(maxPswdLen);
							}
							if(dataNode.has("totalPrivateMemory(KB)")) {
								int totalPrivateMemory = dataNode.path("totalPrivateMemory(KB)").asInt();
								objHSMInfo.setTotalPrivateMemory(totalPrivateMemory);
							}
							if(dataNode.has("firmwareMinor")) {
								String firmwareMinor = dataNode.path("firmwareMinor").asText();
								objHSMInfo.setFirmwareMinor(firmwareMinor);
							}
							if(dataNode.has("partNumber")) {
								String partNumber = dataNode.path("partNumber").asText();
								objHSMInfo.setPartNumber(partNumber);
							}
							if(dataNode.has("freePublicMemory(KB)")) {
								int freePublicMemory = dataNode.path("freePublicMemory(KB)").asInt();
								objHSMInfo.setFreePublicMemory(freePublicMemory);
							}
							if(dataNode.has("serialNumber")){
								String serialNumber = dataNode.path("serialNumber").asText();
								objHSMInfo.setSerialNumber(serialNumber);
							}
							if(dataNode.has("fipsState")) {
								String fipsState = dataNode.path("fipsState").asText();
								objHSMInfo.setFipsState(fipsState);                                      
							}
							if(dataNode.has("hsmFlags")) {
								int hsmFlags = dataNode.path("hsmFlags").asInt();
								objHSMInfo.setHsmFlags(hsmFlags);
							}
							if(dataNode.has("model")) {
								String model = dataNode.path("model").asText();
								objHSMInfo.setModel(model);
							}
							if(dataNode.has("deviceId")) {
								String deviceId = dataNode.path("deviceId").asText();
								objHSMInfo.setDeviceId(deviceId);
							}
							if(dataNode.has("mcoFixedKeyFingerprint")) {
								String mcoFixedKeyFingerprint = dataNode.path("mcoFixedKeyFingerprint").asText();
								objHSMInfo.setMcoFixedKeyFingerprint(mcoFixedKeyFingerprint);;
							}
							if(dataNode.has("vendorFixedKeyFingerprint")) {
								String vendorFixedKeyFingerprint = dataNode.path("vendorFixedKeyFingerprint").asText();								
								objHSMInfo.setVendorFixedKeyFingerprint(vendorFixedKeyFingerprint);
							}
							StringBuffer firmwareVersion= new StringBuffer();
							if(objHSMInfo.getFirmwareMajor()!=null){
								firmwareVersion=firmwareVersion.append(objHSMInfo.getFirmwareMajor()+":");
							}
							if(objHSMInfo.getFirmwareMinor()!=null){
								firmwareVersion=firmwareVersion.append(objHSMInfo.getFirmwareMinor()+":");
							}
							if(objHSMInfo.getBuildNumber()!=null){
								firmwareVersion=firmwareVersion.append(objHSMInfo.getBuildNumber());
							}
							objHSMInfo.setFirmwareVersion(firmwareVersion.toString());
						}
					}
				}
			}
		}catch(Exception exp){
			logger.error("Error occured during fetch HSM Info of class ApplianceServiceImpl ::" + exp.getMessage()); 
		}
		return objHSMInfo;
	}


	/*
	 * This method is used to get Admin VM Self Test Report Information from Cavium REST API 
	 *  
	 */

	public AdminVMSelfTestReport getAdminVMSelfTestReport (ApplianceDetailModel applianceDetailModel,AdminVMSelfTestReport objAdminVMSFT){
		try{

			ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/admin_vm_selftest_report");
			if(response!=null && response.getStatusCode().name().equals("OK")) {
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						String status = root.path("status").asText();
						//JsonNode errors = root.path("errors");
						String operation = root.path("operation").asText();
						long startTime = root.path("startTime").asLong();
						String startDateTime=CaviumUtil.formatDatefromLong(startTime);
						String message = root.path("message").asText();
						int jobId = root.path("jobId").asInt();
						JsonNode dataNode = root.path("data");
						objAdminVMSFT.setStatus(status);
						objAdminVMSFT.setOperation(operation);
						objAdminVMSFT.setStartTime(startDateTime);
						objAdminVMSFT.setErrorMessage(message);
						objAdminVMSFT.setJobId(jobId);
						/*	if(!errors.isNull()){
							Iterator<JsonNode> itr = errors.elements();                                       
							while (itr.hasNext()) {
								JsonNode temp = itr.next();                                              
							}
						}*/
						if(!dataNode.isNull()){
							if(dataNode.has("SelfTest")) {
								String SelfTest = dataNode.path("SelfTest").toString();
								objAdminVMSFT.setSelfTest(SelfTest);
							}

						}
					}
				}
			}
		}catch(Exception exp){
			logger.error("Error occured during fetch HSM Info of class ApplianceServiceImpl ::" + exp.getMessage()); 
		}
		return objAdminVMSFT;
	}

	/*
	 * This method is used to get Host Self Test Report Information from Cavium REST API 
	 *  
	 */

	public HostSelfTestReport getHostSelfTestReport (ApplianceDetailModel applianceDetailModel,HostSelfTestReport objHostSFT){
		try{

			ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/admin_vm_selftest_report");
			if(response!=null && response.getStatusCode().name().equals("OK")) {
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						String status = root.path("status").asText();
						//JsonNode errors = root.path("errors");
						String operation = root.path("operation").asText();
						long startTime = root.path("startTime").asLong();
						String startDateTime=CaviumUtil.formatDatefromLong(startTime);
						String message = root.path("message").asText();
						int jobId = root.path("jobId").asInt();
						JsonNode dataNode = root.path("data");
						objHostSFT.setStatus(status);
						objHostSFT.setOperation(operation);
						objHostSFT.setStartTime(startDateTime);
						objHostSFT.setErrorMessage(message);
						objHostSFT.setJobId(jobId);
						/*	if(!errors.isNull()){
							Iterator<JsonNode> itr = errors.elements();                                       
							while (itr.hasNext()) {
								JsonNode temp = itr.next();                                              
							}
						}*/
						if(!dataNode.isNull()){
							if(dataNode.has("SelfTest")) {
								String SelfTest = dataNode.path("SelfTest").toString();
								objHostSFT.setSelfTest(SelfTest);
							}

						}
					}
				}
			}
		}catch(Exception exp){
			logger.error("Error occured during fetch HSM Info of class ApplianceServiceImpl ::" + exp.getMessage()); 
		}
		return objHostSFT;
	}
	/***
	 * This method is used for search operation as normal and advanced search
	 */
	@Override
	public List<ApplianceDetailModel> searchAppliance(ApplianceDetailModel applianceDetailModel) {
		List<ApplianceDetailModel> serachApplianceDetailModel=null;
		try {
			String applianceName = applianceDetailModel.getApplianceName();
			String applianceStatus = applianceDetailModel.getApplianceStatus();
			String ipAddress = applianceDetailModel.getIpAddress();
			String hostName = applianceDetailModel.getHostName();
			String ipmiIp = applianceDetailModel.getIpmiIp();

			if (applianceName == null) {
				applianceName = "";
			}
			if (applianceStatus == null) {
				applianceStatus = "";
			}
			if (ipAddress == null) {
				ipAddress = "";
			}

			if (hostName == null) {
				hostName = "";
			}
			if (ipmiIp == null) {
				ipmiIp = "";
			}
			serachApplianceDetailModel=applianceRepository.serchAppliance(applianceName,applianceStatus,ipAddress,hostName,ipmiIp,StoreType.PERMANENT);

		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Error occured during serach operation on appliance inside method searchAppliance of class ApplianceDetailModel ");
		}
		// TODO Auto-generated method stub
		return serachApplianceDetailModel;
	}

	@Override
	public List<ApplianceDetailModel> getListOfTempAppliances() {
		String loggedInUser = userAttributes.getlogInUserName();
		List<ApplianceDetailModel> applianceTempModel=null;
		try {
			applianceTempModel=applianceRepository.getListOfTempAppliancesByUserId(loggedInUser,StoreType.TEMP);
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Error occured during fetch of the temporary list of appliances");
		}
		// TODO Auto-generated method stub
		return applianceTempModel;
	}


	@Override
	public CaviumResponseModel createApplianceForTesting(List<ApplianceDetailModel> applianceDetailModel) {

		// TODO Auto-generated method stub
		CaviumResponseModel responseModel=getCaviumResponseModel();
		try {
			if (applianceDetailModel != null && applianceDetailModel.size() > 0) {
				String loggedInUser = userAttributes.getlogInUserName();
				for(ApplianceDetailModel app : applianceDetailModel) {
					List<ApplianceDetailModel> tempApplianceDetailmodel=applianceRepository.getApplianceExists(app.getIpAddress());
					if(tempApplianceDetailmodel.size() == 0) {
						app.setCreatedBy(loggedInUser);
						app.setCreatedDate(new Date());
						app.setStoreType(StoreType.PERMANENT);
						app.setApplianceStatus("Active");
						if(StringUtils.isEmpty(app.getAuthId())) {
							app.setAuthId("1234");
						}
						ApplianceDetailModel applianceTemp=applianceRepository.save(app);
						if(applianceTemp!=null) {
							List<UserGroupModel> usg=userGroupRepository.findGroupDetailsForGroupName(env.getProperty("user.defaultusergroup")); 
							if(!usg.isEmpty()) {
								UserGroupModel userGroupModel=(UserGroupModel)usg.get(0);
								DesignationApplianceModel designationApplianceModel=new DesignationApplianceModel();
								designationApplianceModel.setDesignationId(userGroupModel.getId());
								designationApplianceModel.setObjApplianceDetailModel(applianceTemp);
								designationAppliance.save(designationApplianceModel);
							}
						}
						responseModel.setResponseCode("200");
						responseModel.setResponseMessage(env.getProperty("applianceCreation.success"));
						recentActivityServiceImpl.createRecentActivity(loggedInUser, "New device "+app.getApplianceName()+" added by "+loggedInUser+".",CaviumConstant.APPLIANCE_MANAGEMENT);

					}else {
						responseModel.setResponseCode("409");
						responseModel.setResponseMessage("Failed to create as already available");
					}
				}
			} else {
				logger.error("ApplianceDetailModel is empty or null ::");
				responseModel.setResponseCode("204");
				responseModel.setResponseMessage(env.getProperty("applianceCreation.failureEmpty"));
			}
		} catch (Exception e) {
			logger.error("Error occured due to db error inside createAppliance Method of class ApplianceServiceImpl ::" + e.getMessage());
			responseModel.setResponseCode("500");
			responseModel.setResponseMessage(env.getProperty("applianceCreation.failureDB"));
		}
		return responseModel;
	}

	public List<ApplianceCityDetail>listAppliancesDetailCityWise(List<ApplianceDetailModel> listApplianceDetailModels){
		TreeMap<String,ApplianceCityDetail> cityNameMap= new TreeMap<String, ApplianceCityDetail>(String.CASE_INSENSITIVE_ORDER);
		ApplianceCityDetail objApplianceCityDetail= null;	
		List<ApplianceCityDetail> listApplianceToplology=null;
		for (Iterator<ApplianceDetailModel> iterator = listApplianceDetailModels.iterator(); iterator.hasNext();) {
			ApplianceDetailModel applianceDetailModel = (ApplianceDetailModel) iterator.next();
			String cityName=applianceDetailModel.getCityName();
			logger.info("cityName :: Appliance Status "+cityName +"::"+applianceDetailModel.getApplianceStatus());	 
			if("Active".equals(applianceDetailModel.getApplianceStatus())){

				if(!cityNameMap.containsKey(cityName)){
					objApplianceCityDetail= new ApplianceCityDetail();
					objApplianceCityDetail.setCityName(cityName);
					cityNameMap.put(cityName,objApplianceCityDetail);	
				}					 					
				if(cityNameMap.containsKey(cityName)){
					objApplianceCityDetail=cityNameMap.get(cityName);
					objApplianceCityDetail.getApplianceStatus().setActiveStatus((objApplianceCityDetail.getApplianceStatus().getActiveStatus()+1));
				}
			}
			if("Inactive".equals(applianceDetailModel.getApplianceStatus())){
				if(!cityNameMap.containsKey(cityName)){		
					objApplianceCityDetail= new ApplianceCityDetail();
					objApplianceCityDetail.setCityName(cityName);
					cityNameMap.put(cityName,objApplianceCityDetail);
				}					 					
				if(cityNameMap.containsKey(cityName)){
					objApplianceCityDetail=cityNameMap.get(cityName);
					objApplianceCityDetail.getApplianceStatus().setInactiveStatus((objApplianceCityDetail.getApplianceStatus().getInactiveStatus()+1));
				}
			}
			if("Suspended".equals(applianceDetailModel.getApplianceStatus())){
				if(!cityNameMap.containsKey(cityName)){
					objApplianceCityDetail= new ApplianceCityDetail();
					objApplianceCityDetail.setCityName(cityName);
					cityNameMap.put(cityName,objApplianceCityDetail);	
				}					 					
				if(cityNameMap.containsKey(cityName)){
					objApplianceCityDetail=cityNameMap.get(cityName);
					objApplianceCityDetail.getApplianceStatus().setSuspendedStatus((objApplianceCityDetail.getApplianceStatus().getSuspendedStatus()+1));
				}
			}
		}
		listApplianceToplology = new ArrayList<ApplianceCityDetail>(cityNameMap.values());
		return listApplianceToplology;
	}

	public CaviumResponseModel getCertificateURL(String certificateType, String applianceIp) {

		String certificateUrl=null;
		String	errorMessage=null;
		CaviumResponseModel responseModel=getCaviumResponseModel();
		String loggedInUser = userAttributes.getlogInUserName();
		try{
			List<ApplianceDetailModel> applianceDetailmodels=applianceRepository.getApplianceExists(applianceIp);
			if(applianceDetailmodels.size() == 1 ) {	
				ApplianceDetailModel dbAppliance=applianceDetailmodels.get(0);
			ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceIp+"/liquidsa/"+certificateType);
			if(response!=null && response.getBody()!=null && response.getBody().contains("success")) {
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						String status = root.path("status").asText();

						if("success".equalsIgnoreCase(status)){
							JsonNode dataNode = root.path("data");
							if(!dataNode.isNull() && dataNode.size()>0){
								if(dataNode.has("downloadCaviumCertificateUrlAddr")) {
									certificateUrl = dataNode.path("downloadCaviumCertificateUrlAddr").asText();
									responseModel.setResponseCode("200");
									responseModel.setResponseMessage(certificateUrl);
								}	 
							}
						}
				  }
				}
			}else {
				getErrorMessage(response, dbAppliance, loggedInUser, "Download Certificate");	
				responseModel.setResponseMessage(dbAppliance.getErrorMessage());	  
				responseModel.setResponseCode(dbAppliance.getCode());
			}
		}
		}catch (Exception e) {
			logger.error("Error occured in  getCertificateURL Method :: "+e.getMessage());
		}
		return responseModel;
	}

	public CaviumResponseModel uploadCertificate(ManageCertificatesDetails manageCertificatesDetails) {
		DualFactorUsersRelationshipModel dfmodel=null;

		String hsmFileUploadedId=null;
		String signedHsmFileUploadedId=null;
		String username=null;
		String password=null;

		CaviumResponseModel responseModelForhsmFile=getCaviumResponseModel();
		CaviumResponseModel responseModelForhsmSignedFile=getCaviumResponseModel();
		CaviumResponseModel responseModel=getCaviumResponseModel();
		String loggedInUser = userAttributes.getlogInUserName();
		try{
			File hsmFile=null;
			File signedHsmFile=null;
			if(manageCertificatesDetails.getHsmFileContent()!=null && manageCertificatesDetails.getHsmFileExtension()!=null  && manageCertificatesDetails.getHsmFileName()!=null){
				hsmFile = CaviumUtil.createFile(manageCertificatesDetails.getHsmFileName(),manageCertificatesDetails.getHsmFileExtension(),manageCertificatesDetails.getHsmFileContent());
			}
			if(manageCertificatesDetails.getSignedHSMfileName()!=null && manageCertificatesDetails.getSignedHSMfileExtension()!=null && manageCertificatesDetails.getSignedHSMfileContent()!=null){
				signedHsmFile = CaviumUtil.createFile(manageCertificatesDetails.getSignedHSMfileName(),manageCertificatesDetails.getSignedHSMfileExtension(),manageCertificatesDetails.getSignedHSMfileContent());
			}
			ApplianceDetailModel dbAppliance = applianceRepository.findOne(manageCertificatesDetails.getApplianceId());
			List<DualFactorUsersRelationshipModel> dfmodelList=dfUsersRelationshipRepository.getDualFactorDetails(loggedInUser, dbAppliance.getApplianceId());

			if(dfmodelList!=null && dfmodelList.size() > 0) {
				dfmodel=dfmodelList.get(0);	
			}
			InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(manageCertificatesDetails.getApplianceId());
			if(initmodel!=null) {
				InitializeApplianceDetailModel initAppDetailModel = initializeRepository.findOne(initmodel.getInitializeId());
				String operationPerformedPassword=CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword());
				String operationPerformedUserName= initAppDetailModel.getCryptoOfficerName();
				DualFactorAuthDetailModel dualAuthModel=initAppDetailModel.getDualFactorAuthDetailModel();
				username=operationPerformedUserName;
				password=operationPerformedPassword;
				if(initAppDetailModel.getAuthenticationLevel() == 1 && dfmodel==null){
					dfmodel=createDualFile(loggedInUser, manageCertificatesDetails.getApplianceId(),initAppDetailModel.getCryptoOfficerName(),CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()),dualAuthModel);					
				}								
				if(hsmFile!=null){
					responseModelForhsmFile=fileUploadService.uploadFile(hsmFile,operationPerformedUserName,operationPerformedPassword,"StoreHSMOwnerCerts",manageCertificatesDetails.getApplianceIp(),dfmodel);
					hsmFileUploadedId=responseModelForhsmFile.getResponseMessage();
					if(!"200".equals(responseModelForhsmFile.getResponseCode())){
						alertsService.createAlert(loggedInUser,"Upload HSM Owner Certificate performed on device "+dbAppliance.getApplianceName()+" by "+loggedInUser+" did not uploaded due to "+responseModelForhsmFile.getResponseMessage() ,dbAppliance.getApplianceName(),dbAppliance.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
					}
					Files.deleteIfExists(Paths.get(hsmFile.getAbsolutePath()));

				}else {
					responseModelForhsmFile.setResponseCode("200");
					hsmFileUploadedId=manageCertificatesDetails.getHsmFileName();
				}
				if(signedHsmFile!=null && responseModelForhsmFile.getResponseCode().equals("200")){
					responseModelForhsmSignedFile=fileUploadService.uploadFile(signedHsmFile,operationPerformedUserName,operationPerformedPassword,"StoreHSMOwnerCerts",manageCertificatesDetails.getApplianceIp(),dfmodel);
					signedHsmFileUploadedId=responseModelForhsmSignedFile.getResponseMessage();
					if(!"200".equals(responseModelForhsmSignedFile.getResponseCode())){
						alertsService.createAlert(loggedInUser,"Upload Signed HSM Owner Certificate performed on device "+dbAppliance.getApplianceName()+" by "+loggedInUser+" did not uploaded due to "+responseModelForhsmSignedFile.getResponseMessage() ,dbAppliance.getApplianceName(),dbAppliance.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
					}						
					Files.deleteIfExists(Paths.get(signedHsmFile.getAbsolutePath()));
				}else {
					responseModelForhsmFile.setResponseCode("200");
					signedHsmFileUploadedId=manageCertificatesDetails.getSignedHSMfileName();
				}

			}else{
				username=manageCertificatesDetails.getOperationUsername();
				password=manageCertificatesDetails.getOperationPassword();
				if(hsmFile!=null){
					responseModelForhsmFile=fileUploadService.uploadFile(hsmFile,manageCertificatesDetails.getOperationUsername(),manageCertificatesDetails.getOperationPassword(),"StoreHSMOwnerCerts",manageCertificatesDetails.getApplianceIp(),dfmodel);
					hsmFileUploadedId=responseModelForhsmFile.getResponseMessage();
					if(!"200".equals(responseModelForhsmFile.getResponseCode())){
						alertsService.createAlert(loggedInUser,"Upload HSM Owner Certificate performed on device "+dbAppliance.getApplianceName()+" by "+loggedInUser+" did not uploaded due to "+responseModelForhsmFile.getResponseMessage() ,dbAppliance.getApplianceName(),dbAppliance.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
					}
					Files.deleteIfExists(Paths.get(hsmFile.getAbsolutePath()));
				}else {
					responseModelForhsmFile.setResponseCode("200");
					hsmFileUploadedId=manageCertificatesDetails.getHsmFileName();
				}
				if(signedHsmFile!=null && responseModelForhsmFile.getResponseCode().equals("200")){
					responseModelForhsmSignedFile=fileUploadService.uploadFile(signedHsmFile,manageCertificatesDetails.getOperationUsername(),manageCertificatesDetails.getOperationPassword(),"StoreHSMOwnerCerts",manageCertificatesDetails.getApplianceIp(),dfmodel);
					signedHsmFileUploadedId=responseModelForhsmSignedFile.getResponseMessage();
					if(!"200".equals(responseModelForhsmSignedFile.getResponseCode())){
						alertsService.createAlert(loggedInUser,"Device "+dbAppliance.getApplianceName()+"  try to perform upload Signed HSM Owner Certificate by "+loggedInUser+"  not uploaded due to "+responseModelForhsmSignedFile.getResponseMessage() ,dbAppliance.getApplianceName(),dbAppliance.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
					}
					Files.deleteIfExists(Paths.get(signedHsmFile.getAbsolutePath()));
				}else {
					responseModelForhsmSignedFile.setResponseCode("200");
					signedHsmFileUploadedId=manageCertificatesDetails.getSignedHSMfileName();
				}
			}
			if(hsmFileUploadedId!=null && signedHsmFileUploadedId!=null && responseModelForhsmFile.getResponseCode().equals("200") && responseModelForhsmSignedFile.getResponseCode().equals("200")){
				if(username!=null && password!=null)
				{
					JSONObject json = new JSONObject(); 	
					json.put("username",username);
					json.put("password",password);
					if(dfmodel!=null){
						json.put("dualFactorKeyFile", dfmodel.getDualFactorKeyFileId());
						json.put("dualFactorPort", Integer.parseInt(dfmodel.getDualFactorAuthServerPortNo()));
						json.put("dualFactorCertificate", dfmodel.getDualFactorCertificateId());
					}				 
					json.put("hsmOwnerCertFileId",hsmFileUploadedId);
					json.put("hsmOwnerSignedCertFileId",signedHsmFileUploadedId);

					ResponseEntity<String> response=restClient.invokePOSTMethodForOperations("https://"+manageCertificatesDetails.getApplianceIp()+"/liquidsa/import_hsm_owner_certificates", json);
					if(response!=null && response.getBody()!=null && response.getBody().contains("success")) {	
						responseModel.setResponseCode("200");
						responseModel.setResponseMessage("HSM Owner and Signed HSM Owner Certificates uploaded succeessfully.");
						recentActivityServiceImpl.createRecentActivity(loggedInUser, "HSM Owner Certificate and HSM Owner signed Certificate on "+dbAppliance.getApplianceName()+" uploaded by "+loggedInUser,CaviumConstant.APPLIANCE_MANAGEMENT);
					}
					else {
						getErrorMessage(response, dbAppliance, loggedInUser, "Import HSM Owner Certificate");
						applianceRepository.save(dbAppliance);
						responseModel.setResponseCode(dbAppliance.getCode());
						responseModel.setResponseMessage(dbAppliance.getErrorMessage()); 

					}
				}
				else{
					responseModel.setResponseCode("409");
					responseModel.setResponseMessage("Credentials are required."); 
				}
			}
			else{
				if(responseModelForhsmFile.getResponseCode()!=null){
					responseModel.setResponseCode(responseModelForhsmFile.getResponseCode());
					responseModel.setResponseMessage(responseModelForhsmFile.getResponseMessage());
				}
				if(responseModelForhsmSignedFile.getResponseCode()!=null){
					responseModel.setResponseCode(responseModelForhsmSignedFile.getResponseCode());				
					responseModel.setResponseMessage(responseModelForhsmSignedFile.getResponseMessage());
				}
			}
		}catch (Exception e) {
			logger.error("Error occured in  uploadCertificate Method :: "+e.getMessage());
		}
		return responseModel;
	}

	
	public File	downloadFileFromURL(String fileUrl,String applianceName){
		logger.info("Start of downloadFileFromURL Method ::");
		File file=null;
		String fileName=null;
		InputStream inputStream=null;
		OutputStream   outputStream=null;
		try{
			HttpResponse response=restClient.invokeGETMethodForLargeFileDownload(fileUrl);
			if(response!=null) {
				String finalfileName=null;
				String contentDisposition=response.getFirstHeader("Content-Disposition").getValue();
				String fileNameSplit[]=contentDisposition.split("=");
				if(fileNameSplit.length>0){
					fileName=fileNameSplit[1];

				}
				finalfileName = applianceName+"-"+CaviumUtil.getRandomText()+"-"+fileName;
				file = CaviumUtil.createFile(finalfileName,null,"");

				HttpEntity entity=response.getEntity();
				if (entity != null) {
					inputStream = entity.getContent();
					outputStream = new FileOutputStream(file);
					IOUtils.copy(inputStream, outputStream);
				}

			}		 
		}catch (Exception e) {
			try{
				Files.deleteIfExists(Paths.get(file.getAbsolutePath()));
				file=null;
			}catch (Exception exp) {
				logger.error("Error in writting content to file  in downloadFileFromURL method of Appliance ServiceImpl Class :: " + e.getMessage()); 
			}
		}finally{
			try{
				if(inputStream!=null)
				{
					inputStream.close();	
				}
				if(outputStream!=null)
				{
					outputStream.flush();
					outputStream.close();
				}
			}catch (Exception e) {
				logger.error("Error occured in  downloadFileFromURL Method for closing InputStream and OutputStream :: "+e.getMessage());
			}
		}
		logger.info("end of downloadFileFromURL Method ::");
		return file;
	}

	private void updateInProgressActivity(ApplianceDetailModel applianceDetailModel,String loggedInUser, JsonNode root) {
		try {
			InProgressActivity activity = new InProgressActivity();
			activity.setCreatedBy(loggedInUser);
			activity.setModuleName(CaviumConstant.APPLIANCE_MANAGEMENT);
			activity.setIpAddress(applianceDetailModel.getIpAddress());
			Integer jobId = 0;
			if (!root.path("jobId").isNull()) {
				jobId = root.path("jobId").asInt();
			} else {
				jobId = 000;
			}
			activity.setJobId(jobId);
			activity.setOperationName(root.path("operation").asText());
			activity.setStatus("In-Progress");
			activity.setApplianceID(applianceDetailModel.getApplianceId());
			if(applianceDetailModel.getFirmwareUpgradeDetailModel()!=null && applianceDetailModel.getFirmwareUpgradeDetailModel().isZeroize()) {
				activity.setPartitionDeleted(true);
			}
			activity.setApplianceName(applianceDetailModel.getApplianceName());
			inProgressActivityService.createInProgressActivity(activity);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during updateInProgressActivity"+e.getMessage());
		}
	}


	public ApplianceDetailModel getErrorMessage(ResponseEntity<String> response,ApplianceDetailModel applianceDetailModel,String loggedInUser,String type) {
		try {
			if(response==null) {
				applianceDetailModel.setCode("409");
				applianceDetailModel.setErrorMessage(env.getProperty("appliance.applainceinternalerror.cavium"));
				applianceDetailModel.setLastOperationPerformed(type);
				applianceDetailModel.setLastOperationStatus("Failed");
				alertsService.createAlert(loggedInUser,""+type+" performed on device "+applianceDetailModel.getApplianceName()+" by "+loggedInUser+" did not complete due to appliance internal error.",applianceDetailModel.getApplianceName(),applianceDetailModel.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
				return applianceDetailModel;
			}

			if(response!=null && response.getStatusCodeValue()== 401){
				applianceDetailModel.setCode("401");
				applianceDetailModel.setErrorMessage(env.getProperty("unauthorized.cavium"));
				applianceDetailModel.setLastOperationPerformed(type);
				applianceDetailModel.setLastOperationStatus("Failed");
				alertsService.createAlert(loggedInUser,""+type+" performed on device "+applianceDetailModel.getApplianceName()+" by "+loggedInUser+" did not complete due to user is not authorized.",applianceDetailModel.getApplianceName(),applianceDetailModel.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
				return applianceDetailModel;
			}

			if(response!=null && response.getStatusCodeValue()== 408){
				applianceDetailModel.setCode("408");
				applianceDetailModel.setErrorMessage(env.getProperty("appliance.connectionerror.cavium"));
				applianceDetailModel.setLastOperationPerformed(type);
				applianceDetailModel.setLastOperationStatus("Failed");
				alertsService.createAlert(loggedInUser,""+type+" performed on device "+applianceDetailModel.getApplianceName()+" by "+loggedInUser+" did not complete due to connection error.",applianceDetailModel.getApplianceName(),applianceDetailModel.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
				return applianceDetailModel;
			}

			if(response.getBody()!=null) {
				ObjectMapper mapper = new ObjectMapper();
				JsonNode root = mapper.readTree(response.getBody());
				if(root!=null){
					if(!root.isNull()) {
						if(response.getBody().contains("busy")) {
							String operation = root.path("operation").asText();
							applianceDetailModel.setCode("409");
							applianceDetailModel.setLastOperationPerformed(operation);
							applianceDetailModel.setErrorMessage("System is busy due to operation "+operation+" is being performed on appliance "+applianceDetailModel.getApplianceName()+"");
							applianceDetailModel.setLastOperationStatus("Failed");
							alertsService.createAlert(loggedInUser,""+type+" performed on device "+applianceDetailModel.getApplianceName()+" by "+loggedInUser+" did not "+type+"  due to operation "+operation+" is already in progress.",applianceDetailModel.getApplianceName(),applianceDetailModel.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
							return applianceDetailModel;
						}
						if(response.getBody().contains("errors")) {
							JsonNode errors = root.path("errors");
							if(!errors.isNull() && errors.size() > 0){
								logger.info("Error size"+errors.size()+" is Array"+errors.isArray());
								StringBuilder sbmessage=new StringBuilder();
								StringBuilder sbcode=new StringBuilder();
								Iterator<JsonNode> itr = errors.elements();	
								while (itr.hasNext()) {
									JsonNode temp = itr.next();
									sbcode.append(""+temp.asInt()+"");
									if(env.containsProperty(""+temp.asInt()+"")) {
										sbmessage.append(env.getProperty(""+temp.asInt()+""));
									}else {
										String encodeMessage = root.path("message").asText();
										if(!StringUtils.isEmpty(encodeMessage) && encodeMessage.length() < 100) {
											sbmessage.append(CaviumUtil.decodeMessageBase64(encodeMessage));
										}else {
											sbmessage.append("Error message not available");
										}
									}
									sbcode.append(",");
									sbmessage.append(",");
								}
								String message=sbmessage.toString();
								message=message.substring(0, message.length()-1);
								message=message+".";
								String code=sbcode.toString();
								code=code.substring(0, code.length()-1);
								code=code+".";
								applianceDetailModel.setCode(code);
								applianceDetailModel.setErrorMessage(message);
								applianceDetailModel.setLastOperationPerformed(type);
								applianceDetailModel.setLastOperationStatus("Failed");
								applianceDetailModel.setMessage("");
								alertsService.createAlert(loggedInUser,""+type+" failed due to "+message+" on Device "+applianceDetailModel.getApplianceName()+"  by "+loggedInUser+".",applianceDetailModel.getApplianceName(),applianceDetailModel.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
							} else {
								String encodeMessage = "";
								if (errors.size() == 0) {
									encodeMessage = root.path("message").asText();
									encodeMessage = CaviumUtil.decodeMessageBase64(encodeMessage);
									applianceDetailModel.setCode("");
									applianceDetailModel.setErrorMessage(encodeMessage);
									applianceDetailModel.setMessage("");
								}else {
									applianceDetailModel.setCode("");
									applianceDetailModel.setErrorMessage("No message found");
									applianceDetailModel.setMessage("");
								}
							}
						}
					}
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured while setting error code and message..");
		}
		return applianceDetailModel;
	}

	public   CaviumResponseModel  getDownloadlogsURL(LogsDetails logsDetail){
		JSONObject json = new JSONObject(); 
		String loggedInUser = userAttributes.getlogInUserName();
		CaviumResponseModel responseModel=getCaviumResponseModel();
		try{
			Map<String,Object> logs= new HashMap<String,Object>();
			Map<String,Object> admin= new HashMap<String,Object>();
			Map<String,Object> partitions= new HashMap<String,Object>();
			Map<String,Object> host= new HashMap<String,Object>();

			if(logsDetail!=null && logsDetail.getLogs()!=null){
				if(logsDetail.getLogs().getPartitions()!=null){
					if(logsDetail.getLogs().getPartitions().getOptions()!=null && logsDetail.getLogs().getPartitions().getOptions().size()>0){
						partitions.put("options", logsDetail.getLogs().getPartitions().getOptions());
					}
					if(logsDetail.getLogs().getPartitions().getPartitionsNames()!=null && logsDetail.getLogs().getPartitions().getPartitionsNames().size()>0){
						partitions.put("list", logsDetail.getLogs().getPartitions().getPartitionsNames());
						logs.put("partitions",partitions);
					}
				}
				if(logsDetail.getLogs().getHost()!=null && logsDetail.getLogs().getHost().getOptions()!=null && logsDetail.getLogs().getHost().getOptions().size()>0){	
					host.put("options", logsDetail.getLogs().getHost().getOptions());
					logs.put("host", host);
				}
				if(logsDetail.getLogs().getAdmin()!=null && logsDetail.getLogs().getAdmin().getOptions()!=null && logsDetail.getLogs().getAdmin().getOptions().size()>0){
					admin.put("options",logsDetail.getLogs().getAdmin().getOptions());
					logs.put("admin", admin);
				}
				json.put("logs", logs);
			}
			ResponseEntity<String> response=restClient.invokePOSTMethodForOperations("https://"+logsDetail.getApplianceIp()+"/liquidsa/admin_vm_logs", json);
			if(response!=null && response.getStatusCode().name().equals("OK")) {
				String logUrl=null;	 
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						String status = root.path("status").asText();

						if("success".equalsIgnoreCase(status)){
							JsonNode dataNode = root.path("data");
							if(!dataNode.isNull() && dataNode.size()>0){
								if(dataNode.has("liquidSecurityLogsUrlAddr")) {
									logUrl = dataNode.path("liquidSecurityLogsUrlAddr").asText();
									responseModel.setResponseCode("200");
									responseModel.setResponseMessage(logUrl);
								}	 
							}
							recentActivityServiceImpl.createRecentActivity(loggedInUser,"Logs sucessfully download by " +loggedInUser,CaviumConstant.APPLIANCE_MANAGEMENT);
						}
						if("error".equalsIgnoreCase(status)){
							StringBuilder sbmessage=new StringBuilder();
							StringBuilder sbcode=new StringBuilder();
							JsonNode errors = root.path("errors");
							if(!errors.isNull() && errors.size()>0){
								Iterator<JsonNode> itr = errors.elements();                           
								while (itr.hasNext()) {
									JsonNode temp = itr.next();
									sbcode.append(""+temp.asInt()+"");
									if(env.containsProperty(""+temp.asInt()+"")) {
										sbmessage.append(env.getProperty(""+temp.asInt()+""));
									}else {
										sbmessage.append("Error message not available");
									}
									sbcode.append(",");
									sbmessage.append(",");
								}
								String message=sbmessage.toString();
								message=message.substring(0, message.length()-1);
								message=message+".";
								String code=sbcode.toString();
								code=code.substring(0, code.length()-1);
								code=code+".";
								responseModel.setResponseMessage(message);	  
								responseModel.setResponseCode("409");	  

							}
							alertsService.createAlert(loggedInUser,"Credentails not provided by " +loggedInUser +" while trying to download logs for Appliance "+ logsDetail.getApplianceName(),logsDetail.getApplianceName(),logsDetail.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
						}
					}
				}
			}else {
				responseModel.setResponseCode("408");
				responseModel.setResponseMessage("Appliance not reachable.");
			}
		}catch (Exception e) {
			logger.error("Error occured while download Appliance logs in getDownloadlogsURL method of ApplianceServiceImpl ::  "+e.getMessage());
		}
		return responseModel;  
	}


	public CaviumResponseModel deleteAppliancelogs(LogsDetails logsDetail){

		JSONObject json = new JSONObject(); 
		String loggedInUser = userAttributes.getlogInUserName();
		CaviumResponseModel responseModel=getCaviumResponseModel();
		try{
			ApplianceDetailModel app=new ApplianceDetailModel();
			if(!StringUtils.isEmpty(logsDetail.getOperationUsername())) {
				app.setOperationUsername(logsDetail.getOperationUsername());
			}
			if(!StringUtils.isEmpty(logsDetail.getOperationPassword())) {
				app.setOperationPassword(logsDetail.getOperationPassword());
			}
			app.setApplianceId(logsDetail.getApplianceId());
			
			json=getUserNamePassword(app, json, loggedInUser);
			
			Map<String,Object> logs= new HashMap<String,Object>();
			Map<String,Object> admin= new HashMap<String,Object>();
			Map<String,Object> partitions= new HashMap<String,Object>();
			Map<String,Object> host= new HashMap<String,Object>();

			if(logsDetail!=null && logsDetail.getLogs()!=null){
				if(logsDetail.getLogs().getPartitions()!=null){
					if(logsDetail.getLogs().getPartitions().getOptions()!=null && logsDetail.getLogs().getPartitions().getOptions().size()>0){
						partitions.put("options", logsDetail.getLogs().getPartitions().getOptions());
					}
					if(logsDetail.getLogs().getPartitions().getPartitionsNames()!=null && logsDetail.getLogs().getPartitions().getPartitionsNames().size()>0){
						partitions.put("list", logsDetail.getLogs().getPartitions().getPartitionsNames());
						logs.put("partitions",partitions);
					}
				}
				if(logsDetail.getLogs().getHost()!=null && logsDetail.getLogs().getHost().getOptions()!=null && logsDetail.getLogs().getHost().getOptions().size()>0){	
					host.put("options", logsDetail.getLogs().getHost().getOptions());
					logs.put("host", host);
				}
				if(logsDetail.getLogs().getAdmin()!=null && logsDetail.getLogs().getAdmin().getOptions()!=null && logsDetail.getLogs().getAdmin().getOptions().size()>0){
					admin.put("options",logsDetail.getLogs().getAdmin().getOptions());
					logs.put("admin", admin);
				}
				json.put("logs", logs);
			}
			ResponseEntity<String> response=restClient.invokePOSTMethodForOperations("https://"+logsDetail.getApplianceIp()+"/liquidsa/delete_admin_vm_logs", json);
			if(response!=null && response.getStatusCode().name().equals("OK")) { 	 
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						String status = root.path("status").asText();

						if("success".equalsIgnoreCase(status)){
							responseModel.setResponseCode("200");
							responseModel.setResponseMessage("Logs Deleted Suceesfully");	
							recentActivityServiceImpl.createRecentActivity(loggedInUser,"Logs sucessfully deleted by " +loggedInUser,CaviumConstant.APPLIANCE_MANAGEMENT);
						}
						if("error".equalsIgnoreCase(status)){
							StringBuilder sbmessage=new StringBuilder();
							StringBuilder sbcode=new StringBuilder();
							JsonNode errors = root.path("errors");
							if(!errors.isNull() && errors.size()>0){
								Iterator<JsonNode> itr = errors.elements();                           
								while (itr.hasNext()) {
									JsonNode temp = itr.next();
									sbcode.append(""+temp.asInt()+"");
									if(env.containsProperty(""+temp.asInt()+"")) {
										sbmessage.append(env.getProperty(""+temp.asInt()+""));
									}else {
										sbmessage.append("Error message not available");
									}
									sbcode.append(",");
									sbmessage.append(",");
								}
								String message=sbmessage.toString();
								message=message.substring(0, message.length()-1);
								message=message+".";
								String code=sbcode.toString();
								code=code.substring(0, code.length()-1);
								code=code+".";
								responseModel.setResponseMessage(message);	  
								responseModel.setResponseCode("409");	  
							}
							alertsService.createAlert(loggedInUser,"Logs not deleted while trying to delete logs by "+ loggedInUser+".",logsDetail.getApplianceName(),logsDetail.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
						}
					}
				}
			}else {
				ApplianceDetailModel appDB=applianceRepository.getApplianceById(logsDetail.getApplianceId(), StoreType.PERMANENT);
				if(appDB!=null) {
					appDB=getErrorMessage(response, appDB, loggedInUser, "DeleteAdminVMLogs");
					responseModel.setResponseCode("412");
					if(!StringUtils.isEmpty(appDB.getErrorMessage())) {
						responseModel.setResponseMessage(appDB.getErrorMessage());	
					}else {
						responseModel.setResponseMessage("Failed to delete admin vm logs");	
					}
				}
			}
		}catch (Exception e) {
			logger.error("Error occured while delete Appliancelogs in deleteAppliancelogs method of ApplianceServiceImpl");
		}
		return responseModel;  

	}

	public CaviumResponseModel getAlreadyConfiguredLoggerType(LogsDetails logsDetail){

		String loggedInUser = userAttributes.getlogInUserName();
		CaviumResponseModel responseModel=getCaviumResponseModel();
		try{
			ResponseEntity<String> response=restClient.invokeGETMethod("https://"+logsDetail.getApplianceIp()+"/liquidsa/config_logger");
			if(response!=null && response.getStatusCode().name().equals("OK")) { 	 
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						String status = root.path("status").asText();

						if("success".equalsIgnoreCase(status)){
							JsonNode dataNode = root.path("data");
							if(!dataNode.isNull()){
								if(dataNode.has("logger")){
									JsonNode loggerNode = dataNode.path("logger");
									if(!loggerNode.isNull()){
										String  loggerType=loggerNode.path("middleware").asText();
										responseModel.setResponseMessage(loggerType);	  
										responseModel.setResponseCode("200");
									}
								}
							}

						}
						if("error".equalsIgnoreCase(status)){
							StringBuilder sbmessage=new StringBuilder();
							StringBuilder sbcode=new StringBuilder();
							JsonNode errors = root.path("errors");
							if(!errors.isNull() && errors.size()>0){
								Iterator<JsonNode> itr = errors.elements();                           
								while (itr.hasNext()) {
									JsonNode temp = itr.next();
									sbcode.append(""+temp.asInt()+"");
									if(env.containsProperty(""+temp.asInt()+"")) {
										sbmessage.append(env.getProperty(""+temp.asInt()+""));
									}else {
										sbmessage.append("Error message not available");
									}
									sbcode.append(",");
									sbmessage.append(",");
								}
								String message=sbmessage.toString();
								message=message.substring(0, message.length()-1);
								message=message+".";
								String code=sbcode.toString();
								code=code.substring(0, code.length()-1);
								code=code+".";
								responseModel.setResponseMessage(message);	  
								responseModel.setResponseCode("409");	  
							}
						}
					}
				}
			}else {
				ApplianceDetailModel appDB=applianceRepository.getApplianceById(logsDetail.getApplianceId(), StoreType.PERMANENT);
				if(appDB!=null) {
					appDB=getErrorMessage(response, appDB, loggedInUser, "ConfigLoggerType");
					responseModel.setResponseCode("412");
					if(!StringUtils.isEmpty(appDB.getErrorMessage())) {
						responseModel.setResponseMessage(appDB.getErrorMessage());	
					}else {
						responseModel.setResponseMessage("Failed to config logger type");	
					}
					
				}
			}
		}catch (Exception e) {
			logger.error("Error occured in getAlreadyConfiguredLoggerType method of ApplianceServiceImpl class.." +e.getMessage());
		}
		return responseModel;  

	}

	public CaviumResponseModel updateConfigureLoggerType(LogsDetails logsDetail){
		logger.info("start of updateConfigureLoggerType method");
		JSONObject json = new JSONObject(); 
		String loggedInUser = userAttributes.getlogInUserName();
		CaviumResponseModel responseModel=getCaviumResponseModel();
		try{
			InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry
					.getInitializeIdByApplianceId(logsDetail.getApplianceId());

			List<DualFactorUsersRelationshipModel> dfmodelList=dfUsersRelationshipRepository.getDualFactorDetails(loggedInUser, logsDetail.getApplianceId());		
			DualFactorUsersRelationshipModel dfmodel=null;
			if(dfmodelList!=null && dfmodelList.size()>0){
				dfmodel=dfmodelList.get(0);
			}
			if (initmodel != null) {
				InitializeApplianceDetailModel initAppDetailModel = initializeRepository
						.findOne(initmodel.getInitializeId());
				if (!StringUtils.isEmpty(logsDetail.getOperationUsername())
						&& !StringUtils.isEmpty(logsDetail.getOperationPassword())) {
					if (initAppDetailModel.getAuthenticationLevel() == 0) {
						json.put("username", logsDetail.getOperationUsername());
						json.put("password", logsDetail.getOperationPassword());
					}
					if(initAppDetailModel.getAuthenticationLevel() == 1 && dfmodel==null){
						DualFactorAuthDetailModel dualAuthModel = initAppDetailModel.getDualFactorAuthDetailModel();
						dfmodel=createDualFile(loggedInUser, logsDetail.getApplianceId(),initAppDetailModel.getCryptoOfficerName(),CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()),dualAuthModel);
					}
					if (initAppDetailModel.getAuthenticationLevel() == 1 && dfmodel != null) {
						json.put("username", logsDetail.getOperationUsername());
						json.put("password", logsDetail.getOperationPassword());						
						json.put("dualFactorKeyFile", dfmodel.getDualFactorKeyFileId());
						json.put("dualFactorPort", Integer.parseInt(dfmodel.getDualFactorAuthServerPortNo()));
						json.put("dualFactorCertificate", dfmodel.getDualFactorCertificateId());
					}
				} else {
					if (initAppDetailModel.getAuthenticationLevel() == 0) {
						json.put("username", initAppDetailModel.getCryptoOfficerName());
						json.put("password",  CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));
					}
					if(initAppDetailModel.getAuthenticationLevel() == 1 && dfmodel==null){
						DualFactorAuthDetailModel dualAuthModel = initAppDetailModel.getDualFactorAuthDetailModel();
						dfmodel=createDualFile(loggedInUser, logsDetail.getApplianceId(),initAppDetailModel.getCryptoOfficerName(),CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()),dualAuthModel);
					}
					if (initAppDetailModel.getAuthenticationLevel() == 1 && dfmodel != null) {
						json.put("username", initAppDetailModel.getCryptoOfficerName());
						json.put("password", CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));					 
						json.put("dualFactorKeyFile", dfmodel.getDualFactorKeyFileId());
						json.put("dualFactorPort", Integer.parseInt(dfmodel.getDualFactorAuthServerPortNo()));
						json.put("dualFactorCertificate", dfmodel.getDualFactorCertificateId());
					}
				}
			} else {
				if(dfmodel!=null){
					json.put("dualFactorKeyFile", dfmodel.getDualFactorKeyFileId());
					json.put("dualFactorPort", Integer.parseInt(dfmodel.getDualFactorAuthServerPortNo()));
					json.put("dualFactorCertificate", dfmodel.getDualFactorCertificateId());
				}
				if (!StringUtils.isEmpty(logsDetail.getOperationUsername())
						&& !StringUtils.isEmpty(logsDetail.getOperationPassword())) {
					json.put("username", logsDetail.getOperationUsername());
					json.put("password", logsDetail.getOperationPassword());

				} else {
					responseModel.setResponseCode("409");
					responseModel.setResponseMessage("Credentials not provided");
					return responseModel;
				}

			}
			Map<String,Object> logger= new HashMap<String,Object>();
			if(logsDetail.getLoggerType()!=null){
				logger.put("middleware", logsDetail.getLoggerType());
				json.put("logger", logger);
				ResponseEntity<String> response=restClient.invokePOSTMethodForOperations("https://"+logsDetail.getApplianceIp()+"/liquidsa/config_logger", json);
				if(response!=null && response.getStatusCode().name().equals("OK")) { 	 
					ObjectMapper mapper = new ObjectMapper();
					if(response.getBody()!=null){
						JsonNode root = mapper.readTree(response.getBody());
						if(!root.isNull()){
							String status = root.path("status").asText();

							if("success".equalsIgnoreCase(status)){
								responseModel.setResponseCode("200");
								responseModel.setResponseMessage("Logger type updated Suceesfully");	
								recentActivityServiceImpl.createRecentActivity(loggedInUser,"Logger type updated sucessfully by " +loggedInUser+".",CaviumConstant.APPLIANCE_MANAGEMENT);
							}
							if("error".equalsIgnoreCase(status)){
								StringBuilder sbmessage=new StringBuilder();
								StringBuilder sbcode=new StringBuilder();
								JsonNode errors = root.path("errors");
								if(!errors.isNull() && errors.size()>0){
									Iterator<JsonNode> itr = errors.elements();                           
									while (itr.hasNext()) {
										JsonNode temp = itr.next();
										sbcode.append(""+temp.asInt()+"");
										if(env.containsProperty(""+temp.asInt()+"")) {
											sbmessage.append(env.getProperty(""+temp.asInt()+""));
										}else {
											sbmessage.append("Error message not available");
										}
										sbcode.append(",");
										sbmessage.append(",");
									}
									String message=sbmessage.toString();
									message=message.substring(0, message.length()-1);
									message=message+".";
									String code=sbcode.toString();
									code=code.substring(0, code.length()-1);
									code=code+".";
									responseModel.setResponseMessage(message);	  
									responseModel.setResponseCode("409");	  
								}
								alertsService.createAlert(loggedInUser,"Logger type is not updataed while trying to update by "+ loggedInUser,logsDetail.getApplianceName(),logsDetail.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
							}
						}
					}
				}else {
					ApplianceDetailModel appDB=applianceRepository.getApplianceById(logsDetail.getApplianceId(), StoreType.PERMANENT);
					if(appDB!=null) {
						appDB=getErrorMessage(response, appDB, loggedInUser, "ConfigLogger");
						responseModel.setResponseCode("412");
						if(!StringUtils.isEmpty(appDB.getErrorMessage())) {
							responseModel.setResponseMessage(appDB.getErrorMessage());	
						}else {
							responseModel.setResponseMessage("Failed to Config Logger.");	
						}
						
					}
				}
			}else{
				responseModel.setResponseCode("409");
				responseModel.setResponseMessage("logger Type is not  provided");
			}
		}catch (Exception e) {
			logger.error("Error occured in updateConfigureLoggerType method of ApplianceServiceImpl class :: "+e.getMessage());
		}
		logger.info("end of updateConfigureLoggerType method");
		return responseModel;  

	}
	public List<PartitionDetailModel> setPartitionDataInPartitonModel(ApplianceDetailModel app){

		List<PartitionDetailModel> listPartitions = null;
		listPartitions=partitionRepository.getListOfPartitionByApplianceID(app.getApplianceId());
		if(listPartitions!=null && listPartitions.size()>0){
			listPartitions=partitionService.setPartitionDataIntoPartitionModel(listPartitions);
		}
		return listPartitions;

	}


	@Override
	public List<ApplianceDetailModel> validateCredentialsByLoginHSM(List<ApplianceDetailModel> listApplianceDetailModels) {
		// TODO Auto-generated method stub
		ResponseEntity<String> response=null;
		String loggedInUser = userAttributes.getlogInUserName();

		try {

			for(ApplianceDetailModel app: listApplianceDetailModels) {
				try {
					CaviumResponseModel responseModel=getCaviumResponseModel();
					String initializeState=app.getFipsState();
					if(app!=null && !StringUtils.isEmpty(app.getIpAddress())) {
						DualFactorUsersRelationshipModel dualFactorUsersRelationship=null;
						String url="https://"+app.getIpAddress()+"/liquidsa/login";
						JSONObject body=new JSONObject();
						body.put("username", app.getOperationUsername());
						body.put("password", app.getOperationPassword());
						if((app.isApplianceDualFactorInitialized() &&  app.getInitializeDetailModel()!=null) || (app.getFipsState()!=null && app.getFipsState().equals("3"))){
							List<DualFactorUsersRelationshipModel> dfmodelList=null;
							if(app.getInitializeDetailModel()!=null && app.getInitializeDetailModel().getDualFactorAuthDetailModel()!=null && !StringUtils.isEmpty(app.getInitializeDetailModel().getDualFactorAuthDetailModel().getKeyfileContent())){
								dualFactorUsersRelationship=updateDualfactorDetails(app,null,responseModel);
							} else {
								if(app.getApplianceId()==null) {
									 dfmodelList=dfUsersRelationshipRepository.getDualFactorDetailsbyIp(loggedInUser, app.getIpAddress());	
								}else {
									dfmodelList=dfUsersRelationshipRepository.getDualFactorDetails(loggedInUser, app.getApplianceId());	
								}
								if(dfmodelList!=null && dfmodelList.size() > 0 ) {
									if(dfmodelList!=null && dfmodelList.size()>0){
										dualFactorUsersRelationship=dfmodelList.get(0);
									}
								}
							}
							if(dualFactorUsersRelationship!=null && dualFactorUsersRelationship.getDualFactorCertificateId()!=null && dualFactorUsersRelationship.getDualFactorKeyFileId()!=null){
								body.put("dualFactorKeyFile",dualFactorUsersRelationship.getDualFactorKeyFileId());
								body.put("dualFactorPort",Integer.parseInt(dualFactorUsersRelationship.getDualFactorAuthServerPortNo()));
								body.put("dualFactorCertificate",dualFactorUsersRelationship.getDualFactorCertificateId());
							}
							else{
								if(!StringUtils.isEmpty(responseModel.getResponseMessage())) {
									app.setErrorMessage(responseModel.getResponseMessage());
									app.setCode(responseModel.getResponseCode());
								}else {
									app.setErrorMessage("Failed to upload dual factor details.");
									app.setCode("412");
								}
							}
						}
						if(app.getCode()==null || (app.getCode()!=null && !app.getCode().equals("408"))){
							response=restClient.invokePOSTMethodForOperations(url, body);
							if(response != null && response.getBody() != null
									&& response.getBody().contains("success")) {
								app.setMessage("success");
								app.setCode("200");
							}else {
								app=getErrorMessage(response, app, loggedInUser, "loginHSM");
								if(dualFactorUsersRelationship!=null)
								{
									if(app.getApplianceId()!=null){
											dfUsersRelationshipRepository.deleteDfDetailsForUserAgainstAppliance(loggedInUser,app.getApplianceId());
									}
									else{
											dfUsersRelationshipRepository.deleteDfDetailsForUserAgainstApplianceIp(loggedInUser,app.getIpAddress());
									}
								}
								if(app!=null && app.getErrorMessage()!=null && (app.getErrorMessage().contains("connection") || app.getErrorMessage().contains("busy") )) {
									//do nothing
								}else {
									if(app!=null && app.getErrorMessage()!=null && initializeState!=null && !initializeState.equals("3")){
										app.setErrorMessage("Incorrect Username or Password. Try Again");
									}
								}
							}
						}						
					}

				}
				catch (Exception e) {
					// TODO: handle exception
					logger.error("Error occured during validateCredentialsByLoginHSM"+e.getMessage());
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during validateCredentialsByLoginHSM"+e.getMessage());
		}
		return listApplianceDetailModels;
	}

	private void deletePartitionData(PartitionDetailModel partitionDetailModel) {
		try {
			if(partitionDetailModel!=null && partitionDetailModel.getPartitionId()!=0) {
				partitionETHRepository.deletePartitionETH(partitionDetailModel.getPartitionId());
				advanceStaticHostIpsRepository.deletePartitionAdvanceStaticHostIps(partitionDetailModel.getPartitionId());
				advanceDNSServersRepository.deletePartitionAdvanceDNSServers(partitionDetailModel.getPartitionId());
				advanceSearchDomainNamesRepository.deletePartitionAdvanceSearchDomainNames(partitionDetailModel.getPartitionId());
				partitionDataRepository.deletePartitionData(partitionDetailModel.getPartitionId());
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error ocuured during delete partition data"+e.getMessage());
		}finally {
			partitionDetailModel.setApplianceDetailModel(null);
			partitionRepository.delete(partitionDetailModel);
			logger.info("Finally block completed successfully inside deletePartitionData.");
		}
	}


	@Override
	public List<ApplianceDetailModel> getMonitorData(List<ApplianceDetailModel> applianceDetailModellist) {
		// TODO Auto-generated method stub
		String loggedInUser = userAttributes.getlogInUserName();
		List<ApplianceDetailModel> responseList=new ArrayList<ApplianceDetailModel>();
		try {
			if (applianceDetailModellist.size() > 0) {
				for (ApplianceDetailModel app: applianceDetailModellist) {
					ResponseEntity<String> response = null;
					ApplianceDetailModel dbAppliance = applianceRepository.findOne(app.getApplianceId());
					if (dbAppliance != null) {
						response = restClient.invokeGETMethod("https://"+app.getIpAddress()+"/liquidsa/monitor/"+app.getMonitorType()+"");
						if(response!=null && response.getBody()!=null && response.getBody().contains("success")) {
							ObjectMapper mapper = new ObjectMapper();
							JsonNode root = mapper.readTree(response.getBody());
							if(root.has("data")) {
								JsonNode dataNode = root.path("data");
								if(dataNode.size() > 0) {
									String data=dataNode.toString().replaceAll("sample-count", "samplecount");
									data=data.replaceAll("interface-name", "interfacename");
									MonitorData mdata=mapper.readValue(data, MonitorData.class);
									app.setMonitorData(mdata);
								}else {
									PartitionMonitorPMNCData cpu=new PartitionMonitorPMNCData();
									PartitionMonitorCWI info=new PartitionMonitorCWI();
									cpu.setInfo(info);
									cpu.setWarn(info);
									cpu.setCrit(info);
									PartitionMonitorPMNCData pcpu=new PartitionMonitorPMNCData();
									cpu.setInfo(info);
									cpu.setWarn(info);
									cpu.setCrit(info);
									PartitionMonitorPMNCData memory=new PartitionMonitorPMNCData();
									cpu.setInfo(info);
									cpu.setWarn(info);
									cpu.setCrit(info);
									PartitionNetworkMonitorStats network=new PartitionNetworkMonitorStats();
									network.setInterfacename("eth0");
									MonitorData mdata=new MonitorData();
									mdata.setCpu(cpu);
									mdata.setMemory(memory);
									mdata.setNetwork(network);
									mdata.setPcpu(pcpu);
									app.setMonitorData(mdata);
								}
							}else {
								app.setMessage("No data to display");
								app.setCode("200");
							}
						}else {
							String type=null;
							if(app.getMonitorType()==null){
								type="MonitorData";
							}else{
								type=app.getMonitorType();
							}
							app=getErrorMessage(response, app,loggedInUser,type);

						}
						responseList.add(app);
					} else {
						app.setCode("409");
						app.setMessage(env.getProperty("appliance.notexists.cavium"));
						responseList.add(app);
					}
				}
			}
		}catch (Exception e) {
			// TODO: handle exception
			logger.info("Error occured during appliance getMonitorData.. into getMonitorData of class ApplianceServiceIMPL");
		}
		return responseList;
	}

	/**
	 * This method is used to setMonitorData
	 */
	@Override
	public List<ApplianceDetailModel> setMonitorData(List<ApplianceDetailModel> applianceDetailModellist) {
		// TODO Auto-generated method stub
		String loggedInUser = userAttributes.getlogInUserName();
		List<ApplianceDetailModel> responseList=new ArrayList<ApplianceDetailModel>();
		try {
			if (applianceDetailModellist.size() > 0) {
				for (ApplianceDetailModel app: applianceDetailModellist) {
					try {
						ResponseEntity<String> response = null;
						ApplianceDetailModel dbAppliance = applianceRepository.findOne(app.getApplianceId());
						JSONObject jsonRequest=new JSONObject();
						if (dbAppliance != null &&  app.getMonitorType()!=null) {
							JSONObject josnObject=null;
							if(app.getMonitorData()!=null) {
								josnObject=new JSONObject(app.getMonitorData());
								String jsonObj=josnObject.toString();
								jsonObj=jsonObj.toString().replaceAll( "samplecount","sample-count");
								josnObject=new JSONObject(jsonObj);
								if(josnObject.has("network")) {
									josnObject.remove("network");
								}
								jsonRequest.put("config", josnObject);
							}
							long applianceId = app.getApplianceId();
							InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(applianceId);
							List<DualFactorUsersRelationshipModel> dfmodelList=dfUsersRelationshipRepository.getDualFactorDetails(loggedInUser, applianceId);		
							DualFactorUsersRelationshipModel dfmodel=null;
							if(dfmodelList!=null && dfmodelList.size()>0){
								dfmodel=dfmodelList.get(0);
							}
							if (initmodel != null) {
								InitializeApplianceDetailModel initAppDetailModel = initializeRepository.findOne(initmodel.getInitializeId());
								if (!StringUtils.isEmpty(app.getOperationUsername())
										&& !StringUtils.isEmpty(app.getOperationPassword())) {
									if (initAppDetailModel.getAuthenticationLevel() == 0) {
										jsonRequest.put("username", app.getOperationUsername());
										jsonRequest.put("password", app.getOperationPassword());
									}
									if(initAppDetailModel.getAuthenticationLevel() == 1 && dfmodel==null){
										DualFactorAuthDetailModel dualAuthModel = initAppDetailModel.getDualFactorAuthDetailModel();
										dfmodel=createDualFile(loggedInUser, applianceId,initAppDetailModel.getCryptoOfficerName(),CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()),dualAuthModel);
									}
									if (initAppDetailModel.getAuthenticationLevel() == 1 && dfmodel != null) {
										jsonRequest.put("username", app.getOperationUsername());
										jsonRequest.put("password", app.getOperationPassword());
										jsonRequest.put("dualFactorKeyFile", dfmodel.getDualFactorKeyFileId());
										jsonRequest.put("dualFactorPort", Integer.parseInt(dfmodel.getDualFactorAuthServerPortNo()));
										jsonRequest.put("dualFactorCertificate", dfmodel.getDualFactorCertificateId());
									}
								} else {
									if (initAppDetailModel.getAuthenticationLevel() == 0) {
										jsonRequest.put("username", initAppDetailModel.getCryptoOfficerName());
										jsonRequest.put("password",  CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));
									}
									if(initAppDetailModel.getAuthenticationLevel() == 1 && dfmodel==null){
										DualFactorAuthDetailModel dualAuthModel = initAppDetailModel.getDualFactorAuthDetailModel();
										dfmodel=createDualFile(loggedInUser, applianceId,initAppDetailModel.getCryptoOfficerName(),CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()),dualAuthModel);
									}
									if (initAppDetailModel.getAuthenticationLevel() == 1 && dfmodel != null) {
										jsonRequest.put("username", initAppDetailModel.getCryptoOfficerName());
										jsonRequest.put("password",  CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));
										jsonRequest.put("dualFactorKeyFile", dfmodel.getDualFactorKeyFileId());
										jsonRequest.put("dualFactorPort", Integer.parseInt(dfmodel.getDualFactorAuthServerPortNo()));
										jsonRequest.put("dualFactorCertificate", dfmodel.getDualFactorCertificateId());
									}
								}
								response = restClient.invokePOSTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/monitor/"+app.getMonitorType()+"",jsonRequest);
							} else {
								if(dfmodel!=null)
								{
									jsonRequest.put("dualFactorKeyFile", dfmodel.getDualFactorKeyFileId());
									jsonRequest.put("dualFactorPort", Integer.parseInt(dfmodel.getDualFactorAuthServerPortNo()));
									jsonRequest.put("dualFactorCertificate", dfmodel.getDualFactorCertificateId());
								}
								if (!StringUtils.isEmpty(app.getOperationUsername())
										&& !StringUtils.isEmpty(app.getOperationPassword())) {
									jsonRequest.put("username", app.getOperationUsername());
									jsonRequest.put("password", app.getOperationPassword());
									response = restClient.invokePOSTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/monitor/"+app.getMonitorType()+"",jsonRequest);
								} else {
									app.setMessage("Appliance can not set monitor data due to credentials not available");
									alertsService.createAlert(loggedInUser,
											"Device " + app.getApplianceName() + "  try to perform reboot by "
													+ loggedInUser + "  not set monitor data due to credentials not available.",app.getApplianceName(),app.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
								}
							}
							if (response != null && response.getBody() != null) {
								ObjectMapper mapper = new ObjectMapper();
								JsonNode root = mapper.readTree(response.getBody());
								if (response != null && response.getBody() != null
										&& response.getBody().contains("success")) {
									dbAppliance.setLastOperationPerformed("setMonitorData");
									dbAppliance.setLastOperationStatus("In-Progress");
									dbAppliance.setApplianceinitialized(app.isApplianceinitialized());						
									dbAppliance.setCode("200");
									dbAppliance.setMessage("Monitor data configured successfully.");
									dbAppliance.setErrorMessage("");
									applianceRepository.save(dbAppliance);
									updateInProgressActivity(dbAppliance, loggedInUser, root);
								} else {
									dbAppliance = getErrorMessage(response, dbAppliance, loggedInUser, "setMonitorData");
									applianceRepository.save(dbAppliance);
								}
							} else {
								dbAppliance = getErrorMessage(response, dbAppliance, loggedInUser, "setMonitorData");
								applianceRepository.save(dbAppliance);
							}
							dbAppliance.setPartitionDetailModels(null);
							responseList.add(dbAppliance);
						} else {
							if(app.getMonitorType()==null){
								app.setCode("409");
								app.setMessage("Operation cannot perform due to Monitor Type is not provided");	
							}else{
								app.setCode("409");
								app.setMessage(env.getProperty("appliance.notexists.cavium"));
							}
							responseList.add(app);
						}
					} catch (Exception e) {
						// TODO: handle exception
						logger.info("Error occured during appliance setMonitorData.. into setMonitorData of class ApplianceServiceIMPL");
					}
				}
			}
		}catch (Exception e) {
			// TODO: handle exception
			logger.info("Error occured during appliance setMonitorData.. into setMonitorData of class ApplianceServiceIMPL");
		}
		return responseList;
	}


	@Override
	public List<ApplianceDetailModel> getApplianceMonitorStats(List<ApplianceDetailModel> listApplianceDetailModels) {
		// TODO Auto-generated method stub
		String loggedInUser = userAttributes.getlogInUserName();
		List<ApplianceDetailModel> responseList=new ArrayList<ApplianceDetailModel>();
		try {
			if (listApplianceDetailModels.size() > 0) {
				for (ApplianceDetailModel app: listApplianceDetailModels) {
					ResponseEntity<String> response = null;
					ApplianceDetailModel dbAppliance = applianceRepository.findOne(app.getApplianceId());
					if (dbAppliance != null && app.getMonitorType()!=null) {
						response = restClient.invokeGETMethod("https://"+app.getIpAddress()+"/liquidsa/monitor_stats/"+app.getMonitorType()+"");
						if(response!=null && response.getBody()!=null && response.getBody().contains("success")) {
							ObjectMapper mapper = new ObjectMapper();
							JsonNode root = mapper.readTree(response.getBody());
							if(root.has("data")) {
								JsonNode dataNode = root.path("data");
								app.setMessage(dataNode.toString());
							}else {
								app.setMessage("No data to display");
								app.setCode("200");
							}
						}else {
							String type=null;
							if(app.getMonitorType()==null){
								type="MonitorData";
							}else{
								type=app.getMonitorType();
							}
							app=getErrorMessage(response, app,loggedInUser,type);
						}
						responseList.add(app);
					} else {
						if(app.getMonitorType()==null)
						{
							app.setCode("409");
							app.setMessage("Operation cannot perform due to Monitor Type is not provided");	
						}else{
							app.setCode("409");
							app.setMessage(env.getProperty("appliance.notexists.cavium"));
						}
						responseList.add(app);
					}
				}
			}
		}catch (Exception e) {
			// TODO: handle exception
			logger.info("Error occured during appliance getApplianceMonitorStats.. into getApplianceMonitorStats of class ApplianceServiceIMPL");
		}
		return responseList;
	}

	/**
	 * This method is used to changeAppliancePassword by ChangeCOPswd api
	 */
	@Override
	public ApplianceDetailModel changeAppliancePassword(ApplianceDetailModel app) {
		// TODO Auto-generated method stub
		String loggedInUser = userAttributes.getlogInUserName();
		try {
			if (app!=null) {
				ResponseEntity<String> response = null;
				ApplianceDetailModel dbAppliance = applianceRepository.findOne(app.getApplianceId());
				JSONObject jsonRequest=new JSONObject();
				if (dbAppliance != null) {
					if(!StringUtils.isEmpty(app.getNewPassword())) {
						jsonRequest.put("newPassword", app.getNewPassword());
					}
					jsonRequest=getUserNamePassword(app, jsonRequest,loggedInUser);
					response = restClient.invokePOSTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/change_password",jsonRequest);
					if (response != null && response.getBody() != null && response.getBody().contains("success")) {
						dbAppliance.setLastOperationPerformed("ChangeCOPswd");
						dbAppliance.setCode("200");
						dbAppliance.setMessage("Password changed successfully");
						dbAppliance.setErrorMessage("");
						dbAppliance.setLastOperationStatus("Completed");
						applianceRepository.save(dbAppliance);
						recentActivityServiceImpl.createRecentActivity(loggedInUser, "Password changed for "+app.getApplianceName()+" by "+loggedInUser+".",CaviumConstant.APPLIANCE_MANAGEMENT);
						InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(app.getApplianceId());
						if(initmodel!=null) {
							if(app.isCredentialSaved()) {
								initmodel.setOperationPerformPassword(app.getNewPassword());
								initializeAppliancesRelationshipReposiotry.save(initmodel);
							}else {
								initializeAppliancesRelationshipReposiotry.delete(initmodel);
							}
						}
					} else {
						dbAppliance = getErrorMessage(response, dbAppliance, loggedInUser, "ChangeCOPswd");
						applianceRepository.save(dbAppliance);
					}
					dbAppliance.setPartitionDetailModels(null);
					app=dbAppliance;
				} else {
					app.setCode("409");
					app.setMessage(env.getProperty("appliance.notexists.cavium"));
				}
			}
		}catch (Exception e) {
			// TODO: handle exception
			logger.info("Error occured during appliance ChangeCOPswd.. into changeAppliancePassword of class ApplianceServiceIMPL");
		}
		return app;
	}

	@Override
	public CaviumResponseModel downloadMonitorLogsURL(String url, ApplianceDetailModel applianceDetailModel) {

		String	errorMessage=null;
		CaviumResponseModel responseModel=getCaviumResponseModel();
		JSONObject jsonObject=new JSONObject();

		try{
			jsonObject=getUserNamePassword(applianceDetailModel, jsonObject,null);
			ResponseEntity<String> response=restClient.invokePOSTMethodForOperations(url,jsonObject);
			ObjectMapper mapper = new ObjectMapper();
			if(response.getBody()!=null){
				JsonNode root = mapper.readTree(response.getBody());
				if(!root.isNull()){
					String status = root.path("status").asText();
					if("success".equalsIgnoreCase(status)){
						JsonNode dataNode = root.path("data");
						if(!dataNode.isNull() && dataNode.size()>0){
							if(dataNode.has("liquidSecurityMonitorLogsUrlAddr")) {
								String certificateUrl = dataNode.path("liquidSecurityMonitorLogsUrlAddr").asText();
								responseModel.setResponseCode("200");
								responseModel.setResponseMessage(certificateUrl);
							}
						}
					}
					if("error".equalsIgnoreCase(status)){
						JsonNode errors = root.path("errors");
						if(!errors.isNull() && errors.size()>0){
							Iterator<JsonNode> itr = errors.elements();                           
							while (itr.hasNext()) {
								JsonNode temp = itr.next();
								if(temp.asInt()==11095)
								{ 
									errorMessage="HSM owner certificate is not installed."; 
								}
								if(temp.asInt()==11096)
								{ 
									errorMessage="HSM Certificate issued by HO is not installed."; 
								}
								if(temp.asInt()==11097)
								{ 
									errorMessage="HSM owner certificate is not installed.";
								}
							}
							responseModel.setResponseMessage(errorMessage);	  
							responseModel.setResponseCode("409");	  
						}
					}
				}
			}
		}catch (Exception e) {
			logger.error("Error occured in  getCertificateURL Method :: "+e.getMessage());
		}
		return responseModel;
	}

	/**
	 * 
	 * @param pdmobj
	 * @return
	 */
	private JSONObject getUserNamePassword(ApplianceDetailModel app,JSONObject jsonObject,String loggedInUser) {
		try {
			if (app != null) {
				if(loggedInUser==null){
					loggedInUser = userAttributes.getlogInUserName();
				}
				ApplianceDetailModel dbAppliance = applianceRepository.findOne(app.getApplianceId());
				if (dbAppliance != null) {
					long applianceId = app.getApplianceId();
					InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry
							.getInitializeIdByApplianceId(applianceId);
					List<DualFactorUsersRelationshipModel> dfmodelList=dfUsersRelationshipRepository.getDualFactorDetails(loggedInUser, applianceId);		
					DualFactorUsersRelationshipModel dfmodel=null;
					if(dfmodelList!=null && dfmodelList.size()>0){
						dfmodel=dfmodelList.get(0);
					}
					if (initmodel != null) {
						InitializeApplianceDetailModel initAppDetailModel = initializeRepository
								.findOne(initmodel.getInitializeId());
						if (!StringUtils.isEmpty(app.getOperationUsername())	&& !StringUtils.isEmpty(app.getOperationPassword())) {
							if (initAppDetailModel.getAuthenticationLevel() == 0) {
								jsonObject.put("username", app.getOperationUsername());
								jsonObject.put("password", app.getOperationPassword());
							}
							if(initAppDetailModel.getAuthenticationLevel() == 1 && dfmodel==null){
								DualFactorAuthDetailModel dualAuthModel = initAppDetailModel.getDualFactorAuthDetailModel();
								dfmodel=createDualFile(loggedInUser, applianceId,initAppDetailModel.getCryptoOfficerName(),CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()),dualAuthModel);
							}
							if (initAppDetailModel.getAuthenticationLevel() == 1 && dfmodel != null) {
								jsonObject.put("username", app.getOperationUsername());
								jsonObject.put("password", app.getOperationPassword());
								jsonObject.put("dualFactorKeyFile", dfmodel.getDualFactorKeyFileId());
								jsonObject.put("dualFactorPort", Integer.parseInt(dfmodel.getDualFactorAuthServerPortNo()));
								jsonObject.put("dualFactorCertificate", dfmodel.getDualFactorCertificateId());
							}
						} else {
							if (initAppDetailModel.getAuthenticationLevel() == 0) {
								jsonObject.put("username", initAppDetailModel.getCryptoOfficerName());
								jsonObject.put("password", CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));
							}
							if(initAppDetailModel.getAuthenticationLevel() == 1 && dfmodel==null){
								DualFactorAuthDetailModel dualAuthModel = initAppDetailModel.getDualFactorAuthDetailModel();
								dfmodel=createDualFile(loggedInUser, applianceId,initAppDetailModel.getCryptoOfficerName(),CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()),dualAuthModel);
							}
							if (initAppDetailModel.getAuthenticationLevel() == 1 && dfmodel != null) {
								jsonObject.put("username", initAppDetailModel.getCryptoOfficerName());
								jsonObject.put("password", CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));							 
								jsonObject.put("dualFactorKeyFile", dfmodel.getDualFactorKeyFileId());
								jsonObject.put("dualFactorPort", Integer.parseInt(dfmodel.getDualFactorAuthServerPortNo()));
								jsonObject.put("dualFactorCertificate", dfmodel.getDualFactorCertificateId());
							}
						}
					}else {
						if(dfmodel!=null){
							jsonObject.put("dualFactorKeyFile", dfmodel.getDualFactorKeyFileId());
							jsonObject.put("dualFactorPort", Integer.parseInt(dfmodel.getDualFactorAuthServerPortNo()));
							jsonObject.put("dualFactorCertificate", dfmodel.getDualFactorCertificateId());
						}
						jsonObject.put("username", app.getOperationUsername());
						jsonObject.put("password", app.getOperationPassword());
					}
				}
			}else {
				jsonObject.put("Error", "Partition  Not exists");
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getUserNamePassword method in partitionServiceIMPL");
		}
		return jsonObject;
	}
	/**
	 * this method is used to download monitor Logs File
	 */
	@Override
	public File downloadMonitorFile(String certificateUrl, String name) {
		logger.info("Start of downloadMonitorFile Method ::");
		File file=null;
		String fileName=null;
		InputStream inputStream=null;
		OutputStream   outputStream=null;
		try{
			HttpResponse response=restClient.invokeGETMethodForLargeFileDownload(certificateUrl);
			if(response!=null) {
				String finalfileName=null;
				String contentDisposition=response.getFirstHeader("Content-Disposition").getValue();
				String fileNameSplit[]=contentDisposition.split("=");
				if(fileNameSplit.length>0){
					fileName=fileNameSplit[1];

				}
				finalfileName = name+"-"+CaviumUtil.getRandomText()+"-"+fileName;
				file = CaviumUtil.createFile(finalfileName,null,"");

				HttpEntity entity=response.getEntity();
				if (entity != null) {
					inputStream = entity.getContent();
					outputStream = new FileOutputStream(file);
					IOUtils.copy(inputStream, outputStream);
				}

			}		 
		}catch (Exception e) {
			try{
				Files.deleteIfExists(Paths.get(file.getAbsolutePath()));
				file=null;
			}catch (Exception exp) {
				logger.error("Error in writting content to file  in downloadMonitorFile method of ApplianceServiceImpl Class :: " + e.getMessage()); 
			}

		}finally{
			try{
				if(inputStream!=null)
				{
					inputStream.close();	
				}
				if(outputStream!=null)
				{
					outputStream.flush();
					outputStream.close();
				}
			}catch (Exception e) {
				logger.error("Error occured in  downloadMonitorFile Method for closing InputStream and OutputStream :: "+e.getMessage());
			}
		}
		logger.info("end of downloadMonitorFile Method ::");
		return file;
	}


	@Override
	public CaviumResponseModel getSelfReportData(ApplianceDetailModel applianceDetailModel) {
		// TODO Auto-generated method stub
		CaviumResponseModel caviumResponseModel=new CaviumResponseModel();
		String loggedInUser = userAttributes.getlogInUserName();
		ResponseEntity<String> response=null;
		try {
			if(applianceDetailModel!=null && !StringUtils.isEmpty(applianceDetailModel.getIpAddress()) && !(StringUtils.isEmpty(applianceDetailModel.getSelfReportType()))) {
				if (!StringUtils.isEmpty(applianceDetailModel.getSelfReportType())
						&& applianceDetailModel.getSelfReportType().equalsIgnoreCase("admin")) {
					response = restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/admin_vm_selftest_report");
				}
				if (!StringUtils.isEmpty(applianceDetailModel.getSelfReportType())
						&& applianceDetailModel.getSelfReportType().equalsIgnoreCase("host")) {
					response = restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/host_selftest_report");
				}
				if (!StringUtils.isEmpty(applianceDetailModel.getSelfReportType())
						&& applianceDetailModel.getSelfReportType().equalsIgnoreCase("partition")) {
					List<PartitionDetailModel> pdmlist=applianceDetailModel.getPartitionDetailModels();
					if(pdmlist.size() > 0) {
						for(PartitionDetailModel pdm:pdmlist) {
							response = restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/partition_vm_selftest_report/"+pdm.getPartitionName()+"");
						}
					}
				}
				if(response!=null && response.getBody()!=null && response.getBody().contains("success")) {
					ObjectMapper mapper = new ObjectMapper();
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						String status = root.path("status").asText();
						if("success".equalsIgnoreCase(status)){
							if(applianceDetailModel.getAuthId()!=null && "thirdParty".equals(applianceDetailModel.getAuthId())){
								caviumResponseModel.setResponseMessage(response.getBody());
								caviumResponseModel.setResponseCode("200");
							}else{
								JsonNode dataNode = root.path("data");
								if(!dataNode.isNull() && dataNode.size()>0){
									caviumResponseModel.setResponseCode("200");
									caviumResponseModel.setResponseMessage(dataNode.toString());
								}
							}
						}
					}
				}else {
					String type=null;
					if(applianceDetailModel.getSelfReportType()==null){
						type="SelfReport";
					}else{
						type=applianceDetailModel.getSelfReportType();
					}
					applianceDetailModel=getErrorMessage(response, applianceDetailModel,loggedInUser,type);
					if(applianceDetailModel.getCode()!=null && applianceDetailModel.getErrorMessage()!=null) {
						caviumResponseModel.setResponseCode(applianceDetailModel.getCode());
						caviumResponseModel.setResponseMessage(applianceDetailModel.getErrorMessage());
					}else {
						caviumResponseModel.setResponseCode("000");
						caviumResponseModel.setResponseMessage("No error data found");
					}
				}
			}else{
				if(StringUtils.isEmpty(applianceDetailModel.getSelfReportType())){
					caviumResponseModel.setResponseCode("000");
					caviumResponseModel.setResponseMessage("Operation cannot performed due to self Test Report Type is not provided");
				}else{
					caviumResponseModel.setResponseCode("000");
					caviumResponseModel.setResponseMessage(env.getProperty("appliance.notexists.cavium"));
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getSelfReportData"+e.getMessage());
		}
		return caviumResponseModel;
	}


	@Override
	public SNMPDetails getSNMPInfo(SNMPDetails snmpdetails) {
		// TODO Auto-generated method stub
		logger.error("Start of  method getSNMPInfo in class ApplianceServiceImpl class");
		ResponseEntity<String> response = null;
		ApplianceDetailModel applianceDetailModel=applianceRepository.findOne(snmpdetails.getApplianceId());
		String loggedInUser = userAttributes.getlogInUserName();
		try {
			response = restClient
					.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/admin_snmp_config");

			if (response != null && response.getBody() != null && response.getBody().contains("success")) {
				ObjectMapper mapper = new ObjectMapper();
				JsonNode root = mapper.readTree(response.getBody());
				JsonNode data=root.path("data");
				snmpdetails.setCode("200");
				snmpdetails.setMessage(data.toString());
			} else {
				applianceDetailModel=getErrorMessage(response, applianceDetailModel,loggedInUser,applianceDetailModel.getSelfReportType());
				if(applianceDetailModel.getCode()!=null && applianceDetailModel.getErrorMessage()!=null) {
					snmpdetails.setCode(applianceDetailModel.getCode());
					snmpdetails.setMessage(applianceDetailModel.getErrorMessage());
				}else {
					snmpdetails.setCode("000");
					snmpdetails.setMessage("No error data found");
				}
			}
		} catch (Exception e) {
			logger.error("Error occured during method getSNMPInfo in class ApplianceServiceImpl class :: "+e.getMessage());
		}
		logger.error("end of method getSNMPInfo in ApplianceServiceImpl class");
		return snmpdetails;
	}


	@Override
	public SNMPDetails setSNMPInfo(SNMPDetails snmpDetails){
		// TODO Auto-generated method stub
		logger.info("Start of  method setSNMPInfo in class ApplianceServiceImpl class");

		ApplianceDetailModel applianceDetailModel=applianceRepository.findOne(snmpDetails.getApplianceId());
		String loggedInUser = userAttributes.getlogInUserName();

		try {
			JSONObject jsonObject=new JSONObject();
			if (snmpDetails.getApplianceId() != null) {
				ApplianceDetailModel dbAppliance = applianceRepository.findOne(snmpDetails.getApplianceId());
				if (dbAppliance != null) {
					long applianceId = snmpDetails.getApplianceId();
					InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry
							.getInitializeIdByApplianceId(applianceId);
					List<DualFactorUsersRelationshipModel> dfmodelList=dfUsersRelationshipRepository.getDualFactorDetails(loggedInUser, applianceId);		
					DualFactorUsersRelationshipModel dfmodel=null;
					if(dfmodelList!=null && dfmodelList.size()>0){
						dfmodel=dfmodelList.get(0);
					}
					if (initmodel != null) {
						InitializeApplianceDetailModel initAppDetailModel = initializeRepository
								.findOne(initmodel.getInitializeId());		
						if (!StringUtils.isEmpty(snmpDetails.getOperationUsername())	&& !StringUtils.isEmpty(snmpDetails.getOperationPassword())) {
							if (initAppDetailModel.getAuthenticationLevel() == 0) {
								jsonObject.put("username", snmpDetails.getOperationUsername());
								jsonObject.put("password", snmpDetails.getOperationPassword());
							}
							if(initAppDetailModel.getAuthenticationLevel() == 1 && dfmodel==null)
							{
								DualFactorAuthDetailModel dualAuthModel = initAppDetailModel.getDualFactorAuthDetailModel();
								dfmodel=	createDualFile(loggedInUser, applianceId,initAppDetailModel.getCryptoOfficerName(),CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()),dualAuthModel);
							}
							if (initAppDetailModel.getAuthenticationLevel() == 1 && dfmodel!=null) {
								jsonObject.put("username", snmpDetails.getOperationUsername());
								jsonObject.put("password", snmpDetails.getOperationPassword());								 
								jsonObject.put("dualFactorKeyFile", dfmodel.getDualFactorKeyFileId());
								jsonObject.put("dualFactorPort", Integer.parseInt(dfmodel.getDualFactorAuthServerPortNo()));
								jsonObject.put("dualFactorCertificate", dfmodel.getDualFactorCertificateId());
							}
						} else {
							if (initAppDetailModel.getAuthenticationLevel() == 0) {
								jsonObject.put("username", initAppDetailModel.getCryptoOfficerName());
								jsonObject.put("password", CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));
							}
							if(initAppDetailModel.getAuthenticationLevel() == 1 && dfmodel==null){
								DualFactorAuthDetailModel dualAuthModel = initAppDetailModel.getDualFactorAuthDetailModel();
								dfmodel=createDualFile(loggedInUser, applianceId,initAppDetailModel.getCryptoOfficerName(),CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()),dualAuthModel);
							}
							if (initAppDetailModel.getAuthenticationLevel() == 1 && dfmodel!=null) {
								jsonObject.put("username", initAppDetailModel.getCryptoOfficerName());
								jsonObject.put("password", CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));

								jsonObject.put("dualFactorKeyFile", dfmodel.getDualFactorKeyFileId());
								jsonObject.put("dualFactorPort", Integer.parseInt(dfmodel.getDualFactorAuthServerPortNo()));
								jsonObject.put("dualFactorCertificate", dfmodel.getDualFactorCertificateId());
							}
						}
					}else {
						if(dfmodel!=null){
							jsonObject.put("dualFactorKeyFile", dfmodel.getDualFactorKeyFileId());
							jsonObject.put("dualFactorPort", Integer.parseInt(dfmodel.getDualFactorAuthServerPortNo()));
							jsonObject.put("dualFactorCertificate", dfmodel.getDualFactorCertificateId());
						}
						jsonObject.put("username", snmpDetails.getOperationUsername());
						jsonObject.put("password", snmpDetails.getOperationPassword());
					}
				}
				jsonObject.put("enable", snmpDetails.isEnable());
				if(snmpDetails.isEnable()){
					jsonObject.put("enableTrap", snmpDetails.isEnableTrap());
					jsonObject.put("ip", snmpDetails.getSnmpip());
					jsonObject.put("uname", snmpDetails.getUname());
					jsonObject.put("engineId", snmpDetails.getEngineId());
					jsonObject.put("port", snmpDetails.getPort());
					Map<String,String> authMode= new HashMap<String,String>();
					authMode.put("encryption", snmpDetails.getAuthModeEncryption());
					if(snmpDetails.getAuthModeEncryption()!=null && !snmpDetails.getAuthModeEncryption().equalsIgnoreCase("none")){
						authMode.put("password", snmpDetails.getAuthModePassword());
					}
					Map<String,String> privMode= new HashMap<String,String>();
					privMode.put("encryption", snmpDetails.getPrivModeEncryption());
					if(snmpDetails.getPrivModeEncryption()!=null && !snmpDetails.getPrivModeEncryption().equalsIgnoreCase("none")){
						privMode.put("password", snmpDetails.getPrivModePassword());
					}
					jsonObject.put("authMode", authMode);	
					jsonObject.put("privMode", privMode);	
				}
				ResponseEntity<String> response=restClient.invokePOSTMethodForOperations("https://"+snmpDetails.getApplianceIp()+"/liquidsa/admin_snmp_config",jsonObject);
				if (response != null && response.getBody() != null && response.getBody().contains("success")) {			 		 
					snmpDetails.setCode("200");
					snmpDetails.setMessage("SNMP Information saved Sucessfully");
					recentActivityServiceImpl.createRecentActivity(loggedInUser, "SNMP Information on "+dbAppliance.getApplianceName()+" updated by "+loggedInUser+".",CaviumConstant.APPLIANCE_MANAGEMENT);
					if(snmpDetails.isEnableTrap()){
						logger.info("Start of method SNMP Trap Listener in class ApplianceServiceImpl class for Appliance Ip :: "+dbAppliance.getIpAddress());
						snmpTrapReceiver.run(dbAppliance);
						logger.info("End of method SNMP Trap Listener in class ApplianceServiceImpl class for Appliance Ip :: "+dbAppliance.getIpAddress());
					}
				} else {
					applianceDetailModel =getErrorMessage(response, applianceDetailModel, loggedInUser, "SNMP Info");
					snmpDetails.setCode(applianceDetailModel.getCode());
					snmpDetails.setMessage(applianceDetailModel.getErrorMessage());
					alertsService.createAlert(loggedInUser,"Device "+dbAppliance.getApplianceName()+"  try to perform update SNMP Information by "+loggedInUser+" did not update due to "+applianceDetailModel.getErrorMessage() ,dbAppliance.getApplianceName(),dbAppliance.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
				}
				if (response != null && response.getStatusCodeValue() == 404) {
					String error=env.getProperty("partition.notexists.cavium.network");
					snmpDetails.setCode("408");
					snmpDetails.setMessage(error);
					alertsService.createAlert(loggedInUser,"Device "+dbAppliance.getApplianceName()+"  try to perform update SNMP Information by "+loggedInUser+" did not update due to "+error ,dbAppliance.getApplianceName(),dbAppliance.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
				}
			}

		}catch (Exception e) {
			logger.error("Error occured during method getSNMPInfo in class ApplianceServiceImpl class :: "+e.getMessage());
		}
		logger.error("end of method getSNMPInfo in ApplianceServiceImpl class");
		return snmpDetails;
	}


	/*
	 * (non-Javadoc)
	 * @see com.cavium.service.appliance.ApplianceService#uploadMCOKeyCertificate(com.cavium.pojo.MCOKeyCertificateDetails, java.io.File, java.lang.String)
	 * 
	 * Note  :: 
	 *  From our UI uploadedFileId field value coming as a NUll.From ThirdPary rest API value of uploadedFileId Field is not coming as a NULL.
	 *  File Field is coming as NULL from ThirdPary rest API.
	 */
	public CaviumResponseModel uploadMCOKeyCertificate(MCOKeyCertificateDetails mcoKeyCertificateDetails, File convMCOKeyKeyCertificate,String uploadedFileId) {

		logger.info("start of uploadMCOKeyCertificate Method of ApplianceServiceImpl class");
		CaviumResponseModel responseModel=getCaviumResponseModel();
		String fileUploadedId=null;	 
		String username=null;
		String password=null;

		try{
			File file=convMCOKeyKeyCertificate; 
			/*if(mcoKeyCertificateDetails.getFileContent()!=null && mcoKeyCertificateDetails.getFileExtension()!=null  && mcoKeyCertificateDetails.getFileName()!=null){
				file = CaviumUtil.createFile(mcoKeyCertificateDetails.getFileName(),mcoKeyCertificateDetails.getFileExtension(),mcoKeyCertificateDetails.getFileContent());
			}*/
			String loggedInUser = userAttributes.getlogInUserName();
			InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(mcoKeyCertificateDetails.getApplianceId());
			ApplianceDetailModel dbAppliance = applianceRepository.findOne(mcoKeyCertificateDetails.getApplianceId());
			List<DualFactorUsersRelationshipModel> dfmodelList=dfUsersRelationshipRepository.getDualFactorDetails(loggedInUser, mcoKeyCertificateDetails.getApplianceId());		
			DualFactorUsersRelationshipModel dfmodel=null;
			if(dfmodelList!=null && dfmodelList.size()>0){
				dfmodel=dfmodelList.get(0);
			}
			if(initmodel!=null) {
				InitializeApplianceDetailModel initAppDetailModel = initializeRepository.findOne(initmodel.getInitializeId());
				password= CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword());
				username=initAppDetailModel.getCryptoOfficerName();
				DualFactorAuthDetailModel dualAuthModel=initAppDetailModel.getDualFactorAuthDetailModel();
				if(initAppDetailModel.getAuthenticationLevel() == 1 && dfmodel==null){
					dfmodel=createDualFile(loggedInUser, dbAppliance.getApplianceId(),initAppDetailModel.getCryptoOfficerName(),CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()),dualAuthModel);
				}
				if(file!=null){
					responseModel=fileUploadService.uploadFile(file,username,password,"StoreMCOFixedKeyBlob",mcoKeyCertificateDetails.getApplianceIp(),dfmodel);
					fileUploadedId=responseModel.getResponseMessage();
					if(!"200".equals(responseModel.getResponseCode())){
						alertsService.createAlert(loggedInUser,"Device "+dbAppliance.getApplianceName()+"  try to perform upload MCO Keys Certificate by "+loggedInUser+" did not uploaded due to "+responseModel.getResponseMessage() ,dbAppliance.getApplianceName(),dbAppliance.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
					}
				}				
			}else{
				username=mcoKeyCertificateDetails.getOperationUsername();
				password=mcoKeyCertificateDetails.getOperationPassword();
				if(file!=null){
					responseModel=fileUploadService.uploadFile(file,mcoKeyCertificateDetails.getOperationUsername(),mcoKeyCertificateDetails.getOperationPassword(),"StoreMCOFixedKeyBlob",mcoKeyCertificateDetails.getApplianceIp(),dfmodel);
					fileUploadedId=responseModel.getResponseMessage();
					if(!"200".equals(responseModel.getResponseCode())){
						alertsService.createAlert(loggedInUser,"Device "+dbAppliance.getApplianceName()+"  try to perform upload MCO Keys Certificate by "+loggedInUser+" did not uploaded due to "+responseModel.getResponseMessage() ,dbAppliance.getApplianceName(),dbAppliance.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
					}
				}

			}
			// uploadedFileId filed is for third Party Rest API
			if(file!=null || uploadedFileId!=null){
				if(username!=null && password!=null)
				{
					// This if block is for Third Party Rest API.
					if(uploadedFileId!=null){
						fileUploadedId=uploadedFileId;
					}
					JSONObject json = new JSONObject(); 	
					json.put("username",username);
					json.put("password",password);
					if(dfmodel!=null){					
						json.put("dualFactorKeyFile",dfmodel.getDualFactorKeyFileId());
						json.put("dualFactorPort",Integer.parseInt(dfmodel.getDualFactorAuthServerPortNo()));
						json.put("dualFactorCertificate",dfmodel.getDualFactorCertificateId());
					}
					json.put("keyFileId",fileUploadedId);
					ResponseEntity<String> response=restClient.invokePOSTMethodForOperations("https://"+mcoKeyCertificateDetails.getApplianceIp()+"/liquidsa/store_mco_fixed_key", json);
					if(response!=null && response.getStatusCode().name().equals("OK")) {
						ObjectMapper mapper = new ObjectMapper();
						if(response.getBody()!=null){
							JsonNode root = mapper.readTree(response.getBody());
							if(!root.isNull()){			
								String status = root.path("status").asText();

								if("success".equalsIgnoreCase(status)){
									responseModel.setResponseCode("200");
									responseModel.setResponseMessage("MCO key Certificate uploaded succeessfully.");									 
									dbAppliance.setLastOperationPerformed("StoreMCOFixedKeyBlob");
									dbAppliance.setLastOperationStatus("Completed");
									dbAppliance.setCode("200");	
									dbAppliance.setErrorMessage("");
									applianceRepository.save(dbAppliance);
									recentActivityServiceImpl.createRecentActivity(loggedInUser, "MCO Keys Certificate on "+dbAppliance.getApplianceName()+" uploaded by "+loggedInUser+".",CaviumConstant.APPLIANCE_MANAGEMENT);
								}else{
									if(response.getBody().contains("errors")) {
										JsonNode errors = root.path("errors");
										if(!errors.isNull() && errors.size() > 0){
											logger.info("Error size"+errors.size()+" is Array"+errors.isArray());
											StringBuilder sbmessage=new StringBuilder();
											StringBuilder sbcode=new StringBuilder();
											Iterator<JsonNode> itr = errors.elements();	
											while (itr.hasNext()) {
												JsonNode temp = itr.next();
												sbcode.append(""+temp.asInt()+"");
												if(env.containsProperty(""+temp.asInt()+"")) {
													sbmessage.append(env.getProperty(""+temp.asInt()+""));
												}else {
													sbmessage.append("Error message not available");
												}
												sbcode.append(",");
												sbmessage.append(",");
											}
											String errorMessage=sbmessage.toString();
											errorMessage=errorMessage.substring(0, errorMessage.length()-1);
											errorMessage=errorMessage+".";
											String code=sbcode.toString();
											code=code.substring(0, code.length()-1);
											code=code+".";
											responseModel.setResponseCode(code);
											responseModel.setResponseMessage(errorMessage); 
										} else {
											String encodeMessage = "";
											if (errors.size() == 0) {
												encodeMessage = root.path("message").asText();
												encodeMessage = CaviumUtil.decodeMessageBase64(encodeMessage);										 
												responseModel.setResponseMessage(encodeMessage);
											}else {
												responseModel.setResponseMessage("No message found");
											}
										}

										dbAppliance.setLastOperationPerformed("StoreMCOFixedKeyBlob");
										dbAppliance.setLastOperationStatus("Failed");
										dbAppliance.setErrorMessage(responseModel.getResponseMessage());
										dbAppliance.setCode("409");									 
										applianceRepository.save(dbAppliance);
										alertsService.createAlert(loggedInUser,"Device "+dbAppliance.getApplianceName()+" try to perform upload MCO Keys Certificate by "+loggedInUser+" did not uploaded due to "+responseModel.getResponseMessage() ,dbAppliance.getApplianceName(),dbAppliance.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
									}
								}

							}
						}
						else{
							getErrorMessage(response, dbAppliance, loggedInUser, "Upload MCO Keys Certificate");
							responseModel.setResponseCode(dbAppliance.getCode());
							responseModel.setResponseMessage(dbAppliance.getErrorMessage()); 
						}
					}else{
						getErrorMessage(response, dbAppliance, loggedInUser, "Upload MCO Keys Certificate");
						responseModel.setResponseCode(dbAppliance.getCode());
						responseModel.setResponseMessage(dbAppliance.getErrorMessage()); 
					}
				}
				else{
					responseModel.setResponseCode("409");
					responseModel.setResponseMessage("Credentials are required."); 
				}
			}
			else{
				responseModel.setResponseCode("409");
				responseModel.setResponseMessage("FileUploadId is missing"); 
			}
		}catch (Exception e) {
			logger.error("Error occured in  uploadMCOKeyCertificate Method of ApplianceServiceImpl class:: "+e.getMessage());
		}
		logger.info("end of uploadMCOKeyCertificate Method of ApplianceServiceImpl class");
		return responseModel;
	}

	/**
	 * This method is used to validate appliance for delete
	 */
	@Override
	public ApplianceDeleteFailureModel validateDeleteAppliance(List<ApplianceDetailModel> listApplianceDetailModels) {
		// TODO Auto-generated method stub
		ApplianceDeleteFailureModel applianceDeleteFailureModel=new ApplianceDeleteFailureModel();
		try {
			boolean found = false;
			
			List<ApplianceDetailModel> clusterFailureList=new ArrayList<>();
			List<ApplianceDetailModel> fipsStateNonZeroizeList=new ArrayList<>();
			List<ApplianceDetailModel> sucessList=new ArrayList<>();

			for (ApplianceDetailModel app : listApplianceDetailModels) {
				List<PartitionDetailModel> partlist = partitionRepository
						.getListOfPartitionByApplianceID(app.getApplianceId());
				if (partlist != null && partlist.size() > 0) {
					for (PartitionDetailModel partdm : partlist) {
						List<ClusterPartitionsRelationship> clus = clusterPartitionsRelationshipRepository.getListOfClusters(partdm.getPartitionId());
						if (clus != null && clus.size() > 0) {							
							clusterFailureList.add(app);
							break;
						}
					}
				}
			}

			for (ApplianceDetailModel mainList : listApplianceDetailModels) {

				for (ApplianceDetailModel clus : clusterFailureList) {					
					if (mainList.getApplianceId() == clus.getApplianceId()) {
						found = true;
					}
				}
				if (!found) {
					/**
					 * Do logic
					 */
					HSMInfo hsmInfo = getHSMInfo(mainList, getHSMInfo());
					if (hsmInfo != null && !StringUtils.isEmpty(hsmInfo.getFipsState())
							&& hsmInfo.getFipsState().replaceAll(" ","").contains("-1[zeroized]")) {
						sucessList.add(mainList);
					}else {
						fipsStateNonZeroizeList.add(mainList);
					}
				}
				found = false;
			}

			applianceDeleteFailureModel.setDueToCluster(clusterFailureList);
			applianceDeleteFailureModel.setFipsStateNonZeroize(fipsStateNonZeroizeList);
			applianceDeleteFailureModel.setSuccessList(sucessList);


		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured due to validateDeleteAppliance"+e.getMessage());
		}
		return applianceDeleteFailureModel;
	}

	private CaviumResponseModel saveZoneDetails(ApplianceDetailModel applianceDetailModel){
		logger.info("Start of saveZoneDetails Method of ApplianceServiceImpl class");
		String loggedInUser = userAttributes.getlogInUserName();
		CaviumResponseModel responseModel=new CaviumResponseModel();

		String username=null;
		String password=null;
		List<DualFactorUsersRelationshipModel> dfmodelList=dfUsersRelationshipRepository.getDualFactorDetails(loggedInUser, applianceDetailModel.getApplianceId());		
		DualFactorUsersRelationshipModel dfmodel=null;
		if(dfmodelList!=null && dfmodelList.size()>0){
			dfmodel=dfmodelList.get(0);
		}
		InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(applianceDetailModel.getApplianceId());

		if(initmodel!=null) {
			InitializeApplianceDetailModel initAppDetailModel = initializeRepository.findOne(initmodel.getInitializeId());
			if(initAppDetailModel.getAuthenticationLevel() == 1 && dfmodel==null){
				DualFactorAuthDetailModel dualAuthModel = initAppDetailModel.getDualFactorAuthDetailModel();
				dfmodel=createDualFile(loggedInUser, initmodel.getInitializeId(),initAppDetailModel.getCryptoOfficerName(),CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()),dualAuthModel);
			}
			password= CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword());
			username=initAppDetailModel.getCryptoOfficerName();			 
		}else{
			username=applianceDetailModel.getOperationUsername();
			password=applianceDetailModel.getOperationPassword();
		}
		JSONObject json = new JSONObject(); 	
		json.put("username",username);
		json.put("password",password);
		json.put("name",applianceDetailModel.getCityName());
		json.put("zoneId",Integer.parseInt(applianceDetailModel.getZoneId()));
		if(dfmodel!=null){
			json.put("dualFactorKeyFile",dfmodel.getDualFactorKeyFileId());
			json.put("dualFactorPort",Integer.parseInt(dfmodel.getDualFactorAuthServerPortNo()));
			json.put("dualFactorCertificate",dfmodel.getDualFactorCertificateId());
		}
		try{
			ResponseEntity<String> response=restClient.invokePOSTMethodForOperations("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/app_zone", json);
			if(response!=null && response.getBody()!=null) {
				ObjectMapper mapper = new ObjectMapper();
				JsonNode root = mapper.readTree(response.getBody());
				String status = root.path("status").asText();
				if("success".equalsIgnoreCase(status)){
					responseModel.setResponseCode("200");
					responseModel.setResponseMessage("Zone details saved successfully.");
				}else{
					getErrorMessage(response, applianceDetailModel, loggedInUser, "updateZoneDetails");
					responseModel.setResponseCode(applianceDetailModel.getCode());
					responseModel.setResponseMessage(applianceDetailModel.getErrorMessage());
				}
			}else {
				applianceDetailModel=getErrorMessage(response, applianceDetailModel, loggedInUser, "updateZoneDetails");
				responseModel.setResponseCode(applianceDetailModel.getCode());
				responseModel.setResponseMessage(applianceDetailModel.getErrorMessage());
			}
		}catch (Exception e) {
			logger.error("Error occured in  saveZoneDetails Method of ApplianceServiceImpl class:: "+e.getMessage());
		}
		logger.info("end of saveZoneDetails Method of ApplianceServiceImpl class::");
		return  responseModel;
	}


	@Override
	public CaviumResponseModel deleteTemporaryAppliance(ApplianceDetailModel app) {
		CaviumResponseModel caviumResponseModel=getCaviumResponseModel();
		if(app!=null && app.getApplianceId()!=null) {
			try {
				String loggedInUser = userAttributes.getlogInUserName();
				applianceRepository.deleteAppliance(app.getApplianceId());
				 dfUsersRelationshipRepository.deleteDfDetailsForUserAgainstAppliance(loggedInUser, app.getApplianceId());
				caviumResponseModel.setResponseCode("200");
				caviumResponseModel.setResponseMessage("Appliance "+app.getApplianceName()+" removed successfully.");
			}
			catch (Exception e) {
				logger.error("Error occured due to db error inside deleteTemporaryAppliance Method of class ApplianceServiceImpl for "+ app.getApplianceName() +" :: "
						+ e.getMessage());
				caviumResponseModel.setResponseCode("500");
				caviumResponseModel.setResponseMessage("Appliance "+app.getApplianceName()+" failed to remove.");

			}
		}
		else{ 
			if(app!=null){
				caviumResponseModel.setResponseCode("408");
				if(app.getApplianceName()!=null){
					caviumResponseModel.setResponseMessage("Appliance Id is required for "+app.getApplianceName());
				}else{
					caviumResponseModel.setResponseMessage("Appliance Id is required");
				}
			}else{
				caviumResponseModel.setResponseCode("408");
				caviumResponseModel.setResponseMessage("Bad request");
			}
		}
		return caviumResponseModel; 
	}



	@Override
	public ApplianceDetailModel updateApplianceDetails(ApplianceDetailModel applianceDetailModel) {
		logger.info("Start of updateApplianceDetail Method in ApplianceServiceImpl class");   
		try {

			ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/partitions");
			if(response!=null && response.getStatusCode().name().equals("OK")) {
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						JsonNode dataNode = root.path("data");
						if(!dataNode.isNull()){
							if(dataNode.has("totalKeys")) {
								if(dataNode.hasNonNull("totalKeys")){
									int totalKeys = dataNode.path("totalKeys").asInt();
									applianceDetailModel.setTotalKeys(totalKeys);
								}
							}
							if(dataNode.has("occupiedKeys")){
								if(dataNode.hasNonNull("occupiedKeys")){
									int occupiedKeys = dataNode.path("occupiedKeys").asInt();
									applianceDetailModel.setOccupiedKeys(occupiedKeys);
								}
							}
							if(dataNode.has("totalAcclrDev")) {
								if(dataNode.hasNonNull("totalAcclrDev")){
									int totalAcclrDev = dataNode.path("totalAcclrDev").asInt();
									applianceDetailModel.setTotalAcclrDevice(totalAcclrDev);
								}
							}
							if(dataNode.has("occupiedAcclrDev")) {
								if(dataNode.hasNonNull("occupiedAcclrDev")){
									int occupiedAcclrDev = dataNode.path("occupiedAcclrDev").asInt();
									applianceDetailModel.setOccupiedAcclrDev(occupiedAcclrDev);
								}
							}
							if(dataNode.has("totalContexts")){
								if(dataNode.hasNonNull("totalContexts")){
									int totalContexts = dataNode.path("totalContexts").asInt();
									applianceDetailModel.setTotalContexts(totalContexts);
								}
							}
							if(dataNode.has("occupiedContexts")){
								if(dataNode.hasNonNull("occupiedContexts")){
									int occupiedContexts = dataNode.path("occupiedContexts").asInt();
									applianceDetailModel.setOccupiedContexts(occupiedContexts);
								}
							}
							if(dataNode.has("totalPartitions")) {
								if(dataNode.hasNonNull("totalPartitions")){
									int totalPartitions = dataNode.path("totalPartitions").asInt();
									applianceDetailModel.setTotalPartitions(totalPartitions);
								}
							}
							if(dataNode.has("occupiedPartitions")) {
								if(dataNode.hasNonNull("occupiedPartitions")){
									int occupiedPartitions = dataNode.path("occupiedPartitions").asInt();
									applianceDetailModel.setOccupiedPartitions(occupiedPartitions);
								}
							}

						}
					} 
				}
			}
		} catch (Exception e) {
			logger.error("Error occured during update Applaince Details in method updateApplianceDetail  of class ApplianceServiceImpl ::" + e.getMessage());          
		}
		logger.info("End of updateApplianceDetail Method in ApplianceServiceImpl class");     
		return applianceDetailModel;
	}

	/**
	 * Method is used to do firmware upgrade
	 */
	@Override
	public void doApplianceFirmwareUpgrade(ApplianceDetailModel app,
			File imageFileConvertedFile, File signFileConvertedFile, String loggedInUser) {
		try {

			

			/**
			 * Get username and password for API
			 */
			JSONObject jsonObject = new JSONObject();
			jsonObject = getUserNamePassword(app, jsonObject,loggedInUser);
			if(jsonObject!=null && jsonObject.length() > 0) {
				/**
				 * Get Appliance details
				 */
				ApplianceDetailModel appdetail = applianceRepository.findOne(app.getApplianceId());
				/**
				 * Write both the files
				 */


				/**
				 * Call the upload api and do firmware upgrade
				 */

				if (imageFileConvertedFile != null && signFileConvertedFile != null) {

					logger.info("Uploading image file for " + appdetail.getApplianceName() + "..");
					CaviumResponseModel imageFilePath = fileUploadService.uploadFileForFirmwareUpgrade(
							imageFileConvertedFile.getName(), imageFileConvertedFile, "FirmwareUpgrade", appdetail,
							jsonObject, loggedInUser);
					logger.info("Uploading sign file for " + appdetail.getApplianceName() + "..");

					CaviumResponseModel signFilePath = fileUploadService.uploadFileForFirmwareUpgrade(
							signFileConvertedFile.getName(), signFileConvertedFile, "FirmwareUpgrade", appdetail, jsonObject,
							loggedInUser);
					logger.info("FW files uploading completed successfully for " + appdetail.getApplianceName() + "..");

					if (imageFilePath != null && imageFilePath.getResponseCode().equalsIgnoreCase("200")
							&& signFilePath != null && signFilePath.getResponseCode().equalsIgnoreCase("200")) {

						jsonObject.put("imageFilePath",imageFilePath.getResponseMessage());
						jsonObject.put("signFilePath", signFilePath.getResponseMessage());
						applianceFirmwareUpgrade(app,loggedInUser, jsonObject);
					} else {
						appdetail.setLastOperationPerformed("FirmwareUpgrade");
						appdetail.setLastOperationStatus("Completed");
						appdetail.setCode("408");
						appdetail.setMessage("Failed");
						appdetail.setErrorMessage("File Upload failed for firmware upgrade");
						appdetail.setMessage("");
						InProgressActivity inPorgresss = inProgressActivityRepository
								.getInProgressActivity(appdetail.getIpAddress(), "FirmwareUpgradeUpload");
						inProgressActivityRepository.delete(inPorgresss);
						Long applianceId=appdetail.getApplianceId();
						int numberOfpartitions=partitionRepository.getNumberofInprogressPartitions(applianceId);
						if(numberOfpartitions==0){
							boolean grayedOut=false;
							partitionRepository.updateGrayedOut(grayedOut, applianceId);
						}
						if ((imageFilePath != null && imageFilePath.getResponseMessage().contains("connection"))
								|| (signFilePath != null && signFilePath.getResponseMessage().contains("connection"))) {
							alertsService.createAlert(loggedInUser,
									"File upload api failed for " + appdetail.getApplianceName()
									+ " due to appliance not reachable.",
									appdetail.getApplianceName(), appdetail.getApplianceId(),
									CaviumConstant.APPLIANCE_MANAGEMENT);
							appdetail.setErrorMessage(
									"File Upload failed for firmware upgrade due to appliance not reachable.");
						} else {
							alertsService.createAlert(loggedInUser,
									"File upload api failed for " + appdetail.getApplianceName() + ".",
									appdetail.getApplianceName(), appdetail.getApplianceId(),
									CaviumConstant.APPLIANCE_MANAGEMENT);
							appdetail.setErrorMessage("File Upload failed for firmware upgrade");
						}
						applianceRepository.save(appdetail);
					}
				}
			}else {
				Alerts alerts=alertsRepository.getAlertByApplainceId(app.getApplianceId());
				ApplianceDetailModel appdetail = applianceRepository.findOne(app.getApplianceId());
				appdetail.setLastOperationPerformed("FirmwareUpgrade");
				appdetail.setLastOperationStatus("Failed");
				appdetail.setCode("412");
				appdetail.setMessage("Failed");
				if(alerts!=null) {
					appdetail.setErrorMessage(alerts.getMessage());
				}else {
					appdetail.setErrorMessage("Firmware upgrade failed due to credentials not found.");
				}
				applianceRepository.save(appdetail);
				Long applianceId=appdetail.getApplianceId();
				int numberOfpartitions=partitionRepository.getNumberofInprogressPartitions(applianceId);
				if(numberOfpartitions==0){
					boolean grayedOut=false;
					partitionRepository.updateGrayedOut(grayedOut, applianceId);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error(
					"Error occured due to FirmwareUpgrade inside method doFirmwareUpgrade from ApplianceserviceIMPL");
			ApplianceDetailModel appdetail = applianceRepository.findOne(app.getApplianceId());
			appdetail.setLastOperationPerformed("FirmwareUpgrade");
			appdetail.setLastOperationStatus("Completed");
			appdetail.setCode("408");
			appdetail.setMessage("Failed");
			appdetail.setErrorMessage("Firmware upgrade failed due to " + e.getMessage().toString() + "");
			applianceRepository.save(appdetail);
			Long applianceId=appdetail.getApplianceId();
			int numberOfpartitions=partitionRepository.getNumberofInprogressPartitions(applianceId);
			if(numberOfpartitions==0){
				boolean grayedOut=false;
				partitionRepository.updateGrayedOut(grayedOut, applianceId);
			}
		}finally {
			if(signFileConvertedFile!=null && signFileConvertedFile.exists()) {
				signFileConvertedFile.delete();
			}
			if(imageFileConvertedFile!=null && imageFileConvertedFile.exists()) {
				imageFileConvertedFile.delete();
			}
		}
	}

	/***
	 * This method is used to reboot the appliance and update last operation performed column in db
	 */
	@Override
	public ApplianceDetailModel applianceFirmwareUpgrade(ApplianceDetailModel app,String loggedInUser, JSONObject json) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		ApplianceDetailModel dbAppliance = null;
		try {
			logger.info("Firmware started for "+app.getApplianceName()+ "..");
			ResponseEntity<String> response = null;
			dbAppliance = applianceRepository.findOne(app.getApplianceId());
			if (dbAppliance != null) {
				json.put("hsmFirmwareType", app.getFirmwareUpgradeDetailModel().getHsmFirmwareType());
				if (!StringUtils.isEmpty(app.getFirmwareUpgradeDetailModel().getHsmFirmwareType())
						&& app.getFirmwareUpgradeDetailModel().getHsmFirmwareType().equalsIgnoreCase("adapter")) {
					json.put("zeroize", app.getFirmwareUpgradeDetailModel().isZeroize());
				}
				/**
				 * Firmware upgrade api call started 
				 */
				logger.info("Firmware api call started successfully for "+dbAppliance.getApplianceName()+"..");
				response = restClient.invokePOSTMethodForOperations("https://" + dbAppliance.getIpAddress() + "/liquidsa/firmware_upgrade", json);
				logger.info("Firmware api call ended successfully for "+dbAppliance.getApplianceName()+ "..");
				InProgressActivity inPorgresss = inProgressActivityRepository
						.getInProgressActivity(dbAppliance.getIpAddress(), "FirmwareUpgradeUpload");
				if (response != null && response.getBody() != null) {
					ObjectMapper mapper = new ObjectMapper();
					JsonNode root = mapper.readTree(response.getBody());
					if (response != null && response.getBody() != null && response.getBody().contains("success")) {
						
						if(!StringUtils.isEmpty(app.getFirmwareUpgradeDetailModel().getHsmFirmwareType()) && app.getFirmwareUpgradeDetailModel().getHsmFirmwareType().equalsIgnoreCase("adapter")) {
							inPorgresss.setOperationName("AdapterFirmwareUpgrade");
						}else {
							inPorgresss.setOperationName("ApplianceFirmwareUpgrade");
						}
						inProgressActivityRepository.save(inPorgresss);
						if (inPorgresss != null) {
							if (!root.path("jobId").isNull()) {
								Integer jobId = root.path("jobId").asInt();
								logger.info("Jobid: "+jobId+" for appliance "+dbAppliance.getApplianceName()+"");
								/**
								 * Call for Firmware jobID success
								 */
								NotificationRecursion notification=new NotificationRecursion();
								response=notification.getCustomNotificationStatusByJobId(dbAppliance.getIpAddress(), jobId);
								if(response != null && response.getBody() != null && response.getBody().contains("success")) {
									
									/**
									 * Call for reboot notification
									 */
									if(app.getFirmwareUpgradeDetailModel() != null
											&& (app.getFirmwareUpgradeDetailModel().isZeroize() || app.getFirmwareUpgradeDetailModel().getHsmFirmwareType().equalsIgnoreCase("appliance"))) {
										Thread.sleep(120000);
										response=notification.getCustomNotificationStatusByJobId(dbAppliance.getIpAddress(), jobId);
										if(response != null && response.getBody() != null && response.getBody().contains("success")) {
											/**
											 * Mark completed when reboot done
											 */
											dbAppliance.setLastOperationStatus("Completed");
											applianceRepository.updateGrayedOut(false, dbAppliance.getApplianceId());	
											deleteDualFactorDetailsForUser(loggedInUser);
											response=notification.getCustomNotificationStatusByJobId(dbAppliance.getIpAddress(), jobId);
											/**
											 * Once got success from api then remove partitions in case of force zeroize true
											 */
											if (app.getFirmwareUpgradeDetailModel() != null
													&& (app.getFirmwareUpgradeDetailModel().isZeroize())) {
												/**
												 * Deleting all the partitions and initialize object
												 */
												deletePartitionsAndInitializeFromDB(dbAppliance, loggedInUser, inPorgresss.getOperationName());
												
												dbAppliance.setCredentialSaved(false);
												dbAppliance.setApplianceinitialized(false);
												dbAppliance.setInitializedthroughCavium(false);
												dbAppliance.setApplianceDualFactorInitialized(false);
												
											}
										}else {
											dbAppliance.setLastOperationStatus("Failed");
											partitionRepository.updateGrayedOut(false, dbAppliance.getApplianceId());
											applianceRepository.updateGrayedOut(false, dbAppliance.getApplianceId());	
										}
									}else {
										/**
										 * This section works if partition not deleted
										 */
										if (!StringUtils.isEmpty(app.getFirmwareUpgradeDetailModel().getHsmFirmwareType())
												&& app.getFirmwareUpgradeDetailModel().getHsmFirmwareType().equalsIgnoreCase("adapter") && app.getForceReboot()==true) {
											JSONObject jsonReq=new JSONObject();
											if(json.has("username") && json.has("password")) {
												jsonReq.put("username", json.get("username").toString());
												jsonReq.put("password", json.get("password").toString());
												if(json.has("dualFactorKeyFile") && json.has("dualFactorPort") && json.has("dualFactorCertificate")) {
													jsonReq.put("dualFactorKeyFile", json.get("dualFactorKeyFile").toString());
													jsonReq.put("dualFactorPort", json.getInt("dualFactorPort"));
													jsonReq.put("dualFactorCertificate", json.get("dualFactorCertificate").toString());
												}
											}
											response = restClient.invokePOSTMethodForOperations("https://"+dbAppliance.getIpAddress()+"/liquidsa/system_reboot",jsonReq);
											if(response!=null && response.getBody().contains("success")) {
												Thread.sleep(120000);
												response=notification.getCustomNotificationStatusByJobId(dbAppliance.getIpAddress(), jobId);
												if(response != null && response.getBody() != null && response.getBody().contains("success")) {
													dbAppliance.setLastOperationStatus("Completed");
													partitionRepository.updateGrayedOut(false, dbAppliance.getApplianceId());
													applianceRepository.updateGrayedOut(false, dbAppliance.getApplianceId());	
													
												}else {
													dbAppliance.setLastOperationStatus("Failed");
													partitionRepository.updateGrayedOut(false, dbAppliance.getApplianceId());
													applianceRepository.updateGrayedOut(false, dbAppliance.getApplianceId());	
												}
											}else {
												dbAppliance.setLastOperationStatus("Failed");
												partitionRepository.updateGrayedOut(false, dbAppliance.getApplianceId());
												applianceRepository.updateGrayedOut(false, dbAppliance.getApplianceId());	
											}
										}else {
											dbAppliance.setLastOperationStatus("Completed");
											partitionRepository.updateGrayedOut(false, dbAppliance.getApplianceId());
											applianceRepository.updateGrayedOut(false, dbAppliance.getApplianceId());	
										}
									}
									
									if(dbAppliance.getLastOperationStatus().equalsIgnoreCase("Failed")) {
										dbAppliance.setCode("412");
										dbAppliance.setErrorMessage("Reboot failed for adapter firmware upgrdae");
										dbAppliance.setMessage("");
									}else {
										dbAppliance.setCode("200");
										dbAppliance.setErrorMessage("");
										dbAppliance.setMessage(env.getProperty("appliance.firmwareupgrade.success"));
										recentActivityServiceImpl.createRecentActivity(loggedInUser, "Appliance firmware upgrade on device "+dbAppliance.getApplianceName()+" performed by user "+loggedInUser+".",CaviumConstant.APPLIANCE_MANAGEMENT);
									}
									
									/**
									 * update appliance details
									 */
									dbAppliance.setLastOperationPerformed(env.getProperty("appliance.firmware"));
									applianceRepository.save(dbAppliance);
									/**
									 * Remove inprogress activity
									 */
									inProgressActivityRepository.delete(inPorgresss);
									deleteDualFactorDetailsForUser(loggedInUser);
								}else {
									Long applianceId=dbAppliance.getApplianceId();
									int numberOfpartitions=partitionRepository.getNumberofInprogressPartitions(applianceId);
									if(numberOfpartitions==0){
										boolean grayedOut=false;
										partitionRepository.updateGrayedOut(grayedOut, applianceId);
									}
									//Long partitionId=Long.valueOf("-1");				 
									//	partitionRepository.updateInProgressStatusToActualStatus(applianceId,partitionId);
									dbAppliance = getErrorMessage(response, dbAppliance, loggedInUser, "Firmware Upgrade");
									applianceRepository.save(dbAppliance);
									if (inPorgresss != null) {
										inProgressActivityRepository.delete(inPorgresss);
									}
								}
							}
						}
					} else {
						Long applianceId=dbAppliance.getApplianceId();
						int numberOfpartitions=partitionRepository.getNumberofInprogressPartitions(applianceId);
						if(numberOfpartitions==0){
							boolean grayedOut=false;
							partitionRepository.updateGrayedOut(grayedOut, applianceId);
						}
						//Long partitionId=Long.valueOf("-1");				 
						//partitionRepository.updateInProgressStatusToActualStatus(applianceId,partitionId);
						dbAppliance = getErrorMessage(response, dbAppliance, loggedInUser, "Firmware Upgrade");
						applianceRepository.save(dbAppliance);
						if (inPorgresss != null) {
							inProgressActivityRepository.delete(inPorgresss);
						}
					}
				} else {
					Long applianceId=dbAppliance.getApplianceId();
					int numberOfpartitions=partitionRepository.getNumberofInprogressPartitions(applianceId);
					if(numberOfpartitions==0){
						boolean grayedOut=false;
						partitionRepository.updateGrayedOut(grayedOut, applianceId);
					}
					//Long partitionId=Long.valueOf("-1");				 
					//	partitionRepository.updateInProgressStatusToActualStatus(applianceId,partitionId);
					dbAppliance = getErrorMessage(response, dbAppliance, loggedInUser, "Firmware Upgrade");
					applianceRepository.save(dbAppliance);
					if (inPorgresss != null) {
						inProgressActivityRepository.delete(inPorgresss);
					}
				}
			} else {
				app.setCode("408");
				app.setErrorMessage("Appliance not exists into data base");
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.info(
					"Error occured during appliance applianceFirmwareUpgrade.. into applianceFirmwareUpgrade of class ApplianceServiceIMPL");
		}
		return dbAppliance;
	}

	@Override
	@Transactional
	public List<ApplianceDetailModel> getAllPermanentAppliances() {
		List<ApplianceDetailModel>  applianceDetailModels = null;
		CaviumResponseModel responseModel=getCaviumResponseModel();
		try {	
			applianceDetailModels = applianceRepository.getAllListOfAppliances(StoreType.PERMANENT);
		} catch (Exception e) {
			logger.error("Error occured due to db error inside getListOfAppliances Method of class ApplianceServiceImpl ::" + e.getMessage());
			responseModel.setResponseCode("500");
			responseModel.setResponseMessage(env.getProperty("applianceList.failureDB"));
		}
		return applianceDetailModels;
	}

	public void updateApplianceInfo(ApplianceDetailModel app) {
		try {
			HSMInfo	hsmInfo=getHSMInfo();
			hsmInfo=getHSMInfo(app, hsmInfo);
			PartitionsDetails partitionsDetails=null;
			partitionsDetails=partitionService.getPartitionInfo(app,partitionsDetails);	
			if(partitionsDetails!=null){
				int totalAcclrDevice=partitionsDetails.getTotalAcclrDev();
				int occupiedAcclrDev=partitionsDetails.getOccupiedAcclrDev();
				int totalKeys=partitionsDetails.getTotalKeys();
				int occupiedKeys=partitionsDetails.getOccupiedKeys();
				int totalContexts=partitionsDetails.getTotalContexts();
				int occupiedContexts=partitionsDetails.getOccupiedContexts();
				int totalPartitions=partitionsDetails.getTotalPartitions();
				int occupiedPartitions=partitionsDetails.getOccupiedPartitions();
				app.setTotalAcclrDevice(totalAcclrDevice);
				app.setOccupiedAcclrDev(occupiedAcclrDev);
				app.setOccupiedKeys(occupiedKeys);
				app.setTotalKeys(totalKeys);
				app.setOccupiedContexts(occupiedContexts);
				app.setTotalContexts(totalContexts);
				app.setTotalPartitions(totalPartitions);
				app.setOccupiedPartitions(occupiedPartitions);
			}
			app.setMaxPwdLen(hsmInfo.getMaxPswdLen());
			app.setMinPwdLen(hsmInfo.getMinPswdLen());
			app.setCoLoginFailureCount(hsmInfo.getCoLoginFailure());	
			app.setMcoFixedKeyFingerprint(hsmInfo.getMcoFixedKeyFingerprint());
			applianceRepository.save(app);
		} catch (Exception e) {			 
			logger.error("Error occured during updateApplianceInfo task.."+e.getMessage());
		}
	}

	public void deleteDualFactorDetailsForUser(String loggedInUser)
	{
		logger.info("Start of deleteDualFactorDetailsForUser");
		try {		 
			int status=	dfUsersRelationshipRepository.deleteDualFactorDetailsForUser(loggedInUser);
		} catch (Exception e) {
			logger.error("Error occured due to db error inside deleteDualFactorDetailsForUser Method of class ApplianceServiceImpl ::" + e.getMessage());
		}

		logger.info("End of  deleteDualFactorDetailsForUser");

	}


	public DualFactorUsersRelationshipModel updateDualfactorDetails(ApplianceDetailModel appliance, PartitionDetailModel pdm,CaviumResponseModel responseModel)
	{
		DualFactorUsersRelationshipModel dualFactorUsersRelationship= null;
		String loggedInUser = userAttributes.getlogInUserName();
		InitializeApplianceDetailModel initializeApplianceDetailModel=null;
		String ipAddress=null; 
		Long  appId=null;
		String appName=null;
		if(appliance!=null){
			initializeApplianceDetailModel=appliance.getInitializeDetailModel();
			ipAddress=appliance.getIpAddress();
			appId=appliance.getApplianceId();
			appName=appliance.getApplianceName();
		}
		if(pdm!=null)
		{
			initializeApplianceDetailModel=pdm.getInitializeDetailModel();
			ipAddress=pdm.getApplianceDetailModel().getIpAddress();
			appId=pdm.getApplianceDetailModel().getApplianceId();
			appName=pdm.getApplianceDetailModel().getApplianceName();
		}
		try{
			String certificateId=null;
			String keyFileId=null;
			File convertedFile=null;
			String coPassword=initializeApplianceDetailModel.getCryptoOfficerPassword();
			String coUsername=initializeApplianceDetailModel.getCryptoOfficerName();
			String keyfileName=initializeApplianceDetailModel.getDualFactorAuthDetailModel().getKeyfileName();
			String keyfileExtension=initializeApplianceDetailModel.getDualFactorAuthDetailModel().getKeyfileExtension();
			String keyfileContent=initializeApplianceDetailModel.getDualFactorAuthDetailModel().getKeyfileContent();
			String certificateName=initializeApplianceDetailModel.getDualFactorAuthDetailModel().getCertificateName();
			String certificateExtension=initializeApplianceDetailModel.getDualFactorAuthDetailModel().getCertificateExtension();
			String certificateContent=initializeApplianceDetailModel.getDualFactorAuthDetailModel().getCertificateContent();	
			String portNumber=initializeApplianceDetailModel.getDualFactorAuthDetailModel().getDualFactorAuthServerPortNo();
			try{
				convertedFile= CaviumUtil.createFile(keyfileName,keyfileExtension,keyfileContent);
			}catch (IOException e) {
				logger.error("Error while creating Key file in updateDualfactorDetails method :: "+e.getMessage()); 

			}
			responseModel=fileUploadService.uploadFile(convertedFile,coUsername,coPassword,"LoginHSM",ipAddress,null);
			keyFileId=responseModel.getResponseMessage();
			if(convertedFile!=null){
				Files.deleteIfExists(Paths.get(convertedFile.getAbsolutePath()));
			}	
			if(responseModel!=null && "200".equals(responseModel.getResponseCode()))
			{
				try{
					convertedFile= CaviumUtil.createFile(certificateName,certificateExtension,certificateContent);
				}catch (IOException e) {
					logger.error("Error while creating Certificate in updateDualfactorDetails method :: "+e.getMessage()); 

				}
				responseModel=fileUploadService.uploadFile(convertedFile,coUsername,coPassword,"LoginHSM",ipAddress,null);
				certificateId=responseModel.getResponseMessage();
				if(convertedFile!=null){
					Files.deleteIfExists(Paths.get(convertedFile.getAbsolutePath()));
				}
				if(responseModel!=null && "200".equals(responseModel.getResponseCode()))
				{
					List<DualFactorUsersRelationshipModel> dfmodelList=null;
					if(appId!=null){

						dfmodelList=dfUsersRelationshipRepository.getDualFactorDetails(loggedInUser, appId);	
					}
					else{
						dfmodelList=dfUsersRelationshipRepository.getDualFactorDetailsbyIp(loggedInUser, ipAddress);		
					}
					DualFactorUsersRelationshipModel dfmodel=null;
					if(dfmodelList!=null &&  dfmodelList.size()>0){
						dfmodel=dfmodelList.get(0);
					}
					if(dfmodel!=null)
					{
						int status=	dfUsersRelationshipRepository.deleteDfDetailsForUserAgainstAppliance(loggedInUser,appId);
					}
					dualFactorUsersRelationship= new DualFactorUsersRelationshipModel();
					dualFactorUsersRelationship.setUserId(loggedInUser);
					dualFactorUsersRelationship.setApplianceId(appId);
					dualFactorUsersRelationship.setDualFactorCertificateId(certificateId);
					dualFactorUsersRelationship.setDualFactorKeyFileId(keyFileId);
					dualFactorUsersRelationship.setDualFactorAuthServerPortNo(portNumber);
					dualFactorUsersRelationship.setApplianceIp(ipAddress);
					dfUsersRelationshipRepository.save(dualFactorUsersRelationship);
					responseModel.setResponseCode("200");
					responseModel.setResponseMessage("DualFactor details updated successfully for appliance "+appName);
				}else{
					if(!StringUtils.isEmpty(appId)){
						alertsService.createAlert(loggedInUser,"Upload DualFactor Certificate performed on device "+appName+" by "+loggedInUser+" did not uploaded due to "+responseModel.getResponseMessage() ,appName,appId,CaviumConstant.APPLIANCE_MANAGEMENT);
					}
					if(StringUtils.isEmpty(responseModel.getResponseMessage())) {
						responseModel.setResponseCode("408");
						responseModel.setResponseMessage("Failed to upload DualFactor Certificate "+appName);
					}
				}
			}
			else{
				if(!StringUtils.isEmpty(appId)){
					alertsService.createAlert(loggedInUser,"Upload DualFactor Key File performed on device "+appName+" by "+loggedInUser+" did not uploaded due to "+responseModel.getResponseMessage() ,appName,appId,CaviumConstant.APPLIANCE_MANAGEMENT);
				}
				if(StringUtils.isEmpty(responseModel.getResponseMessage())) {
					responseModel.setResponseCode("408");
					responseModel.setResponseMessage("Failed to upload DualFactor Key File "+appName);
				}
			}

		}
		catch(Exception exp)
		{
			if(StringUtils.isEmpty(responseModel.getResponseCode())){
				responseModel.setResponseCode("408");
				responseModel.setResponseMessage("Failed to upload dual Factor Details");
			}
			logger.error("Error in updateDualfactorDetails method :: "+exp.getMessage()); 
		}

		return dualFactorUsersRelationship;
	}


	public DualFactorUsersRelationshipModel  createDualFile(String loggedInUser, Long applianceId,String coUsername,String coPassword,DualFactorAuthDetailModel dualAuthModel)
	{
		DualFactorUsersRelationshipModel dualFactorUsersRelationship=null;
		try{	
			File convertedFile=null;
			String certificateId=null;
			CaviumResponseModel caviumResponseModel=getCaviumResponseModel();
			String keyfileName=dualAuthModel.getKeyfileName();
			String keyfileExtension=dualAuthModel.getKeyfileExtension();
			String keyfileContent=dualAuthModel.getKeyfileContent();
			String certificateName=dualAuthModel.getCertificateName();
			String certificateExtension=dualAuthModel.getCertificateExtension();
			String certificateContent=dualAuthModel.getCertificateContent();
			String portNumber=dualAuthModel.getDualFactorAuthServerPortNo();

			ApplianceDetailModel appliance=applianceRepository.findOne(applianceId);
			try{
				convertedFile= CaviumUtil.createFile(keyfileName,keyfileExtension,keyfileContent);
			}catch (IOException e) {
				logger.error("Error while creating Key file in createDualFile method :: "+e.getMessage());
			}
			caviumResponseModel=fileUploadService.uploadFile(convertedFile,coUsername,coPassword,"LoginHSM",appliance.getIpAddress(),null);
			String	keyFileId=caviumResponseModel.getResponseMessage();
			if(convertedFile!=null){
				Files.deleteIfExists(Paths.get(convertedFile.getAbsolutePath()));
			}	
			if(caviumResponseModel!=null && "200".equals(caviumResponseModel.getResponseCode()))
			{
				try{
					convertedFile= CaviumUtil.createFile(certificateName,certificateExtension,certificateContent);
				}catch (IOException e) {
					logger.error("Error while creating Certificate in createDualFile method :: "+e.getMessage()); 

				}
				caviumResponseModel=fileUploadService.uploadFile(convertedFile,coUsername,coPassword,"LoginHSM",appliance.getIpAddress(),null);
				certificateId=caviumResponseModel.getResponseMessage();
				if(convertedFile!=null){
					Files.deleteIfExists(Paths.get(convertedFile.getAbsolutePath()));
				}
				if(caviumResponseModel!=null && "200".equals(caviumResponseModel.getResponseCode()))
				{
					
					 dfUsersRelationshipRepository.deleteDfDetailsForUserAgainstAppliance(loggedInUser, appliance.getApplianceId());
					if(caviumResponseModel!=null && certificateId!=null &&  keyFileId!=null){	
						String url="https://"+appliance.getIpAddress()+"/liquidsa/login";
						JSONObject body=new JSONObject();
						body.put("username", coUsername);
						body.put("password", coPassword);
						body.put("dualFactorKeyFile",keyFileId);
						body.put("dualFactorPort",Integer.parseInt(portNumber));
						body.put("dualFactorCertificate",certificateId);;
						ResponseEntity<String> response=null;
						response=restClient.invokePOSTMethodForOperations(url, body);
						if(response != null && response.getBody() != null
								&& response.getBody().contains("success")) {						 
							dualFactorUsersRelationship= new DualFactorUsersRelationshipModel();
							dualFactorUsersRelationship.setUserId(loggedInUser);
							dualFactorUsersRelationship.setApplianceId(appliance.getApplianceId());
							dualFactorUsersRelationship.setDualFactorCertificateId(certificateId);
							dualFactorUsersRelationship.setDualFactorKeyFileId(keyFileId);
							dualFactorUsersRelationship.setDualFactorAuthServerPortNo(portNumber);
							dualFactorUsersRelationship.setApplianceIp(appliance.getIpAddress());
							dfUsersRelationshipRepository.save(dualFactorUsersRelationship);
						}else{
							appliance=getErrorMessage(response, appliance, loggedInUser, "loginHSM");
							alertsService.createAlert(loggedInUser,"Upload DualFactor Certificate performed on device "+appliance.getApplianceName()+" by "+loggedInUser+" did not uploaded due to "+appliance.getErrorMessage() ,appliance.getApplianceName(),appliance.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
						}
					}
				}else{
					alertsService.createAlert(loggedInUser,"Upload DualFactor Certificate performed on device "+appliance.getApplianceName()+" by "+loggedInUser+" did not uploaded due to "+caviumResponseModel.getResponseMessage() ,appliance.getApplianceName(),appliance.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);				 
				}
			}else{
				alertsService.createAlert(loggedInUser,"Upload DualFactor Key File performed on device "+appliance.getApplianceName()+" by "+loggedInUser+" did not uploaded due to "+caviumResponseModel.getResponseMessage() ,appliance.getApplianceName(),appliance.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);				 
			}		 
		}catch (Exception e) {
			logger.error("Error in createDualFile method :: "+e.getMessage()); 
		}
		return dualFactorUsersRelationship;
	}


	@Override
	public ApplianceDetailModel editAppliance(ApplianceDetailModel applianceDetailModel) {
		// TODO Auto-generated method stub
		boolean isZoneIdChanged=false;
		boolean isZoneNameChanged=false;
		String oldzoneid="";
		String oldzoneName="";
		try {
			ApplianceDetailModel app = applianceRepository.findOne(applianceDetailModel.getApplianceId());
			if(app.getStoreType().equals(StoreType.TEMP)) {
				oldzoneid=app.getZoneId();
				oldzoneName=app.getCityName();
				app.setAuthId(applianceDetailModel.getAuthId());
				if(!StringUtils.isEmpty(applianceDetailModel.getNetworkTimezone())) {
					app.setNetworkTimezone(applianceDetailModel.getNetworkTimezone());
				}
				if(!StringUtils.isEmpty(applianceDetailModel.getSerialNumber())) {
					app.setSerialNumber(applianceDetailModel.getSerialNumber());
				}
				if(!StringUtils.isEmpty(applianceDetailModel.getIpmiIp())) {
					app.setIpmiIp(applianceDetailModel.getIpmiIp());
				}
				if(!StringUtils.isEmpty(applianceDetailModel.getUserName())) {
					app.setUserName(applianceDetailModel.getUserName());
				}
				if(!StringUtils.isEmpty(applianceDetailModel.getUserPassword())) {
					app.setUserPassword(CaviumUtil.encrypt(applianceDetailModel.getUserPassword()));
				}
				if(!StringUtils.isEmpty(applianceDetailModel.getZoneId()) && !applianceDetailModel.getZoneId().equalsIgnoreCase(app.getZoneId())) {
					isZoneIdChanged=true;
					app.setZoneId(applianceDetailModel.getZoneId());
				}if(!StringUtils.isEmpty(applianceDetailModel.getCityName()) && !applianceDetailModel.getCityName().equalsIgnoreCase(app.getCityName())) {
					isZoneNameChanged=true;
					app.setCityName(applianceDetailModel.getCityName());
				}
				ApplianceDetailModel applianceDetailModeldb=applianceRepository.save(app);
				applianceDetailModeldb.setOperationUsername(app.getCryptoUserName());
				applianceDetailModeldb.setOperationPassword(CaviumUtil.decrypt(app.getCryptoUserPassword()));
				if(isZoneIdChanged || isZoneNameChanged) {
					CaviumResponseModel caviumRes=saveZoneDetails(applianceDetailModeldb);
					if(caviumRes.getResponseCode()!=null && caviumRes.getResponseCode().equalsIgnoreCase("200")) {
						applianceDetailModel.setCode("200");
						applianceDetailModel.setMessage(env.getProperty("applianceModification.success"));
					}else {
						ApplianceDetailModel db=applianceRepository.findOne(applianceDetailModeldb.getApplianceId());
						db.setZoneId(oldzoneid);
						db.setCityName(oldzoneName);
						applianceRepository.save(db);
						if(!StringUtils.isEmpty(caviumRes.getResponseCode()) && !StringUtils.isEmpty(caviumRes.getResponseMessage())) {
							applianceDetailModel.setCode(caviumRes.getResponseCode());
							applianceDetailModel.setMessage("zone details can not save due to "+caviumRes.getResponseMessage());
						}else {
							applianceDetailModel.setCode("409");
							applianceDetailModel.setMessage("Error occured during zoneid update on appliance "+applianceDetailModel.getApplianceName()+"");
						}
					}
				}else {
					applianceDetailModel.setCode("200");
					applianceDetailModel.setMessage(env.getProperty("applianceModification.success"));
				}
			}else {
				applianceDetailModel.setCode("409");
				applianceDetailModel.setMessage("Modification failed as appliance is in permanenet state");
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during edir appliance.");
		}
		return applianceDetailModel;
	}


	@Override
	public void applianceInitialize(String loggedInUser, InitializeApplianceDetailModel initializeApplianceDetailModel) {
		List<ApplianceDetailModel> applianceDetailModels=null;
		String message="";
		try {
			synchronized (initializeApplianceDetailModel) {
				try{
					applianceDetailModels=initilizeAppliance(loggedInUser,initializeApplianceDetailModel);
				}
				catch (RuntimeException e) {
					logger.error("error in Initilize Appliance :" + e.getMessage());
					if("CaviumNetworkError".equals(e.getMessage())){
						message="CaviumNetworkError" ;
					}else{
						message=e.getMessage() ;
					}
				}
			}
			if(applianceDetailModels==null){
				String newmessage="";
				if(initializeApplianceDetailModel.getApplianceDetailModels()!=null && initializeApplianceDetailModel.getApplianceDetailModels().size()>0){
					for (Iterator<ApplianceDetailModel> itr = initializeApplianceDetailModel.getApplianceDetailModels().iterator(); itr.hasNext();) {
						ApplianceDetailModel applianceDetailModel = (ApplianceDetailModel) itr.next();
						if("CaviumNetworkError".equals(message)){
							newmessage="connection error";
						}else{
							if(message.contains(applianceDetailModel.getApplianceName())){
								newmessage = message.replaceAll(applianceDetailModel.getApplianceName(),"");
								applianceDetailModel.setMessage(newmessage);
							}
							else if("keyFileUploadError".equals(message)) {
								newmessage="file upload error";
							}
							else if("certificateFileUploadError".equals(message)) {
								newmessage="file upload error";
							}else
							{
								newmessage="db error";
							}
						}
						ApplianceDetailModel dbAppliance=applianceRepository.findOne(applianceDetailModel.getApplianceId());
						alertsService.createAlert(loggedInUser,"Device "+applianceDetailModel.getApplianceName()+"  try to perofrm initialize by "+loggedInUser+ " did not initialize due to "+newmessage+".",applianceDetailModel.getApplianceName(),applianceDetailModel.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
						applianceRepository.updateGrayedOut(false, applianceDetailModel.getApplianceId());
						partitionRepository.updateGrayedOut(false, applianceDetailModel.getApplianceId());
						dbAppliance.setLastOperationPerformed(env.getProperty("appliance.initialize"));
						dbAppliance.setLastOperationStatus("Failed");
						dbAppliance.setCode("404");
						dbAppliance.setMessage(newmessage);
						dbAppliance.setApplianceinitialized(false);
						applianceRepository.save(dbAppliance);
					}
				}	 
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during initialize appliance inside applianceInitialize");
		}
	}

	private CaviumResponseModel updateSaveDBCredentails(ApplianceDetailModel applianceDetailFromDBModel,ApplianceDetailModel applianceDetailModel)
	{
		CaviumResponseModel responseModel=getCaviumResponseModel();

		try{
			if(applianceDetailFromDBModel.isApplianceinitialized() && !applianceDetailFromDBModel.isInitializedthroughCavium()){
				//	if(applianceDetailFromDBModel.isCredentialSaved()!=applianceDetailModel.isCredentialSaved()){
				//String coPassword=null;
				//String coUsername=null;
				InitializeApplianceDetailModel	initObj=initializeRepository.getInitializeObject(applianceDetailFromDBModel.getApplianceId());	
				InitializeAppliancesRelationshipModel initAppModel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(applianceDetailModel.getApplianceId());
				DualFactorAuthDetailModel dualfactorModel=dfInitializeRepository.getDFDetailsByInitializeId(initObj);
				/*if(applianceDetailModel.isCredentialSaved()){
						if(initAppModel==null){						
							InitializeApplianceDetailModel initializeApplianceDetailModel=applianceDetailModel.getInitializeDetailModel();

							if(applianceDetailFromDBModel.isApplianceDualFactorInitialized() && !StringUtils.isEmpty(initializeApplianceDetailModel)){
								coPassword=initializeApplianceDetailModel.getCryptoOfficerPassword();
								coUsername=initializeApplianceDetailModel.getCryptoOfficerName();
								DualFactorAuthDetailModel dfmodel=new DualFactorAuthDetailModel();
								String keyfileName=initializeApplianceDetailModel.getDualFactorAuthDetailModel().getKeyfileName();
								String keyfileExtension=initializeApplianceDetailModel.getDualFactorAuthDetailModel().getKeyfileExtension();
								String keyfileContent=initializeApplianceDetailModel.getDualFactorAuthDetailModel().getKeyfileContent();
								String certificateName=initializeApplianceDetailModel.getDualFactorAuthDetailModel().getCertificateName();
								String certificateExtension=initializeApplianceDetailModel.getDualFactorAuthDetailModel().getCertificateExtension();
								String certificateContent=initializeApplianceDetailModel.getDualFactorAuthDetailModel().getCertificateContent();	
								String dualFactorAuthServerPortNo=initializeApplianceDetailModel.getDualFactorAuthDetailModel().getDualFactorAuthServerPortNo();
								dfmodel.setCertificateContent(certificateContent);
								dfmodel.setCertificateName(certificateName);
								dfmodel.setCertificateExtension(certificateExtension);
								dfmodel.setDualFactorAuthServerPortNo(dualFactorAuthServerPortNo);
								dfmodel.setInitializeApplianceDetailModel(initializeApplianceDetailModel);
								dfmodel.setKeyfileContent(keyfileContent);
								dfmodel.setKeyfileExtension(keyfileExtension);
								dfmodel.setKeyfileName(keyfileName);
								initObj.setDualFactorAuthDetailModel(dfmodel);
								initializeRepository.save(initObj);
							}							
							if(!StringUtils.isEmpty(applianceDetailModel.getOperationUsername())){
								coUsername=applianceDetailModel.getOperationUsername();
							}
							if(!StringUtils.isEmpty(applianceDetailModel.getOperationPassword())){
								coPassword=CaviumUtil.encrypt(applianceDetailModel.getOperationPassword());
							}
							InitializeAppliancesRelationshipModel initializeAppliancesRelationshipModel=new InitializeAppliancesRelationshipModel();
							initializeAppliancesRelationshipModel.setInitializeId(initObj.getInitialize_id());
							initializeAppliancesRelationshipModel.setApplianceDetailModel(applianceDetailFromDBModel);
							initializeAppliancesRelationshipModel.setOperationPerformUserName(coUsername);
							initializeAppliancesRelationshipModel.setOperationPerformPassword(coPassword);
							initializeAppliancesRelationshipReposiotry.save(initializeAppliancesRelationshipModel); 
						}													
					}*/
				if(!applianceDetailModel.isCredentialSaved()) {
					initializeAppliancesRelationshipReposiotry.delete(initAppModel);	
					dfInitializeRepository.delete(dualfactorModel);
					applianceDetailFromDBModel.setCredentialSaved(applianceDetailModel.isCredentialSaved());
					applianceRepository.save(applianceDetailFromDBModel);
				}
				//	}
				//	applianceDetailFromDBModel.setCredentialSaved(applianceDetailModel.isCredentialSaved());
				//applianceRepository.save(applianceDetailFromDBModel);
			}
			responseModel.setResponseCode("200");
			responseModel.setResponseMessage("Details Update Successfuly");
		}catch (Exception e) {
			// TODO: handle exception
			responseModel.setResponseCode("409");
			responseModel.setResponseMessage("Failed");
			logger.error("Error occured during updateApplianceIp inside class HostAdminVMServiceImpl"+e.getMessage());

		}
		return responseModel;
	}

	private DualFactorUsersRelationshipModel getDualFactorUsersRelationshipViaFileUpload(DualFactorUsersRelationshipModel dualFactorUsersRelationship,InitializeApplianceDetailModel initializeApplianceDetailModel,ApplianceDetailModel appliance,String loggedInUser){
		try {
			CaviumResponseModel caviumResponseModel=getCaviumResponseModel();
			String keyFileId="";
			File convertedFile=null;
			String certificateId="";
			String portNumber=initializeApplianceDetailModel.getDualFactorAuthDetailModel().getDualFactorAuthServerPortNo();
			
			try{
				convertedFile= CaviumUtil.createFile(initializeApplianceDetailModel.getDualFactorAuthDetailModel().getKeyfileName(),initializeApplianceDetailModel.getDualFactorAuthDetailModel().getKeyfileExtension(),initializeApplianceDetailModel.getDualFactorAuthDetailModel().getKeyfileContent());
			}catch (IOException e) {
				logger.error("Error while creating Key file in initilizeAppliance method"); 
				throw new RuntimeException("KeyFileUploadError");
			}
			caviumResponseModel=fileUploadService.uploadFile(convertedFile,initializeApplianceDetailModel.getUserName(),initializeApplianceDetailModel.getPassword(),"InitHSM",appliance.getIpAddress(),null);
			
			keyFileId=caviumResponseModel.getResponseMessage();
			if(convertedFile!=null){
				Files.deleteIfExists(Paths.get(convertedFile.getAbsolutePath()));
			}	
			if(caviumResponseModel!=null && "200".equals(caviumResponseModel.getResponseCode()))
			{
				try{
					convertedFile= CaviumUtil.createFile(initializeApplianceDetailModel.getDualFactorAuthDetailModel().getCertificateName(),initializeApplianceDetailModel.getDualFactorAuthDetailModel().getCertificateExtension(),initializeApplianceDetailModel.getDualFactorAuthDetailModel().getCertificateContent());
				}catch (IOException e) {
					logger.error("Error while creating Certificate in initilizeAppliance method"); 
					throw new RuntimeException("certificateFileUploadError");
				}
				caviumResponseModel=fileUploadService.uploadFile(convertedFile,initializeApplianceDetailModel.getUserName(),initializeApplianceDetailModel.getPassword(),"InitHSM",appliance.getIpAddress(),null);
				certificateId=caviumResponseModel.getResponseMessage();
				
				if(convertedFile!=null){
					Files.deleteIfExists(Paths.get(convertedFile.getAbsolutePath()));
				}
				if(caviumResponseModel!=null && "200".equals(caviumResponseModel.getResponseCode()))
				{

					if(caviumResponseModel!=null && initializeApplianceDetailModel.getDualFactorAuthDetailModel()!=null && (!StringUtils.isEmpty(initializeApplianceDetailModel.getDualFactorAuthDetailModel().getCertificateContent()))){
						List<DualFactorUsersRelationshipModel> dfmodelList=null;
						if(appliance.getApplianceId()!=null){
							dfmodelList=dfUsersRelationshipRepository.getDualFactorDetails(loggedInUser, appliance.getApplianceId());	
						}
						else{
							dfmodelList=dfUsersRelationshipRepository.getDualFactorDetailsbyIp(loggedInUser, appliance.getIpAddress());		
						}
						DualFactorUsersRelationshipModel dfmodel=null;
						if(dfmodelList!=null &&  dfmodelList.size()>0){
							dfmodel=dfmodelList.get(0);
						}
						if(dfmodel!=null)
						{
							int status=	dfUsersRelationshipRepository.deleteDfDetailsForUserAgainstAppliance(loggedInUser,appliance.getApplianceId());
						}
						dualFactorUsersRelationship= new DualFactorUsersRelationshipModel();
						dualFactorUsersRelationship.setUserId(loggedInUser);
						dualFactorUsersRelationship.setApplianceId(appliance.getApplianceId());
						dualFactorUsersRelationship.setDualFactorCertificateId(certificateId);
						dualFactorUsersRelationship.setDualFactorKeyFileId(keyFileId);
						dualFactorUsersRelationship.setDualFactorAuthServerPortNo(portNumber);
						dualFactorUsersRelationship.setApplianceIp(appliance.getIpAddress());
						dualFactorUsersRelationship=dfUsersRelationshipRepository.save(dualFactorUsersRelationship);
					}
				}
			}
		
		} catch (Exception e) {
			// TODO: handle exception
		}
		return dualFactorUsersRelationship;
	}
	
	private void revertInitializeData(ResponseEntity<String> response,ApplianceDetailModel dbAppliance,String loggedInUser, DualFactorUsersRelationshipModel dualFactorUsersRelationship,InitializeApplianceDetailModel initializeApplianceDetailModel) {
		try {
			dbAppliance = getErrorMessage(response, dbAppliance, loggedInUser, "Initialize");
			
			dbAppliance.setApplianceinitialized(false);
			if(dualFactorUsersRelationship!=null){
				dbAppliance.setApplianceDualFactorInitialized(false);
			}
			dbAppliance.setCredentialSaved(false);
			applianceRepository.save(dbAppliance);
			initializeRepository.delete(initializeApplianceDetailModel);
			if(dualFactorUsersRelationship!=null){
				dfUsersRelationshipRepository.delete(dualFactorUsersRelationship);
			}
			applianceRepository.updateGrayedOut(false, dbAppliance.getApplianceId());
			partitionRepository.updateGrayedOut(false, dbAppliance.getApplianceId());
			
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during initialize model revert..");
		}
	}
	
	private JSONObject getJsonForInitializeApi(InitializeApplianceDetailModel initializeApplianceDetailModel,DualFactorUsersRelationshipModel dualFactorUsersRelationship,JSONObject json) {
		
		try {
			
			Map<String,Object> initData= new HashMap<String,Object>();
			
			json.put("username",initializeApplianceDetailModel.getUserName());
			json.put("password",initializeApplianceDetailModel.getPassword());
			initData.put("cryptoOfficerName",initializeApplianceDetailModel.getCryptoOfficerName());
			initData.put("cryptoOfficerPassword",CaviumUtil.decrypt(initializeApplianceDetailModel.getCryptoOfficerPassword()));
			initData.put("authenticationLevel",initializeApplianceDetailModel.getAuthenticationLevel());
			initData.put("fipsState",initializeApplianceDetailModel.getFipsState());
			initData.put("hsmAuditLog",initializeApplianceDetailModel.isHsmAuditLog());
			initData.put("certAuth",initializeApplianceDetailModel.getCertAuthentication());
			initData.put("loginFailCount",initializeApplianceDetailModel.getLoginFailureCount());               
			initData.put("maxPasswordLength",initializeApplianceDetailModel.getMaximumPasswordLength());
			initData.put("minPasswordLength",initializeApplianceDetailModel.getMinimumPasswordLength());                           
			initData.put("label",initializeApplianceDetailModel.getHsmLabel());

			if(dualFactorUsersRelationship!=null){
				initData.put("dfCertificate",dualFactorUsersRelationship.getDualFactorCertificateId());
				initData.put("dfKeyFile",dualFactorUsersRelationship.getDualFactorKeyFileId());				
				initData.put("dfPort",Integer.parseInt(dualFactorUsersRelationship.getDualFactorAuthServerPortNo()));
			}
			
			json.put("initData", initData);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return json;
	}
	
	public boolean getUserDualFactorDetails(String userId,String applianceId){
		boolean userExist=false;
		try{
			if(!StringUtils.isEmpty(userId) && (!StringUtils.isEmpty(applianceId) && org.apache.commons.lang3.StringUtils.isNumeric(applianceId))){
				List<DualFactorUsersRelationshipModel> dfmodelList=dfUsersRelationshipRepository.getDualFactorDetails(userId, Long.valueOf(applianceId));			 
				if(dfmodelList!=null && dfmodelList.size()>0){
					userExist=true; 
				}
			}
		}catch(Exception exp){
			userExist=false;
			logger.error("Error occured during getUserDualFactorDetails"+exp.getMessage());
		}
		return userExist;
	}


	@Override
	public List<ApplianceDetailModel> saveDualFactorDetails(DualFactorUsersRelationshipModel dual,
			List<ApplianceDetailModel> listDualAppModel,ApplianceDetailModel dbApplianceModel,String loggedInUser) {
		// TODO Auto-generated method stub
		ApplianceDetailModel applianceDetailModel=new ApplianceDetailModel();
		try {
			dual.setApplianceId(dbApplianceModel.getApplianceId());
			dual.setUserId(loggedInUser);
			dfUsersRelationshipRepository.save(dual);
			applianceDetailModel.setApplianceId(dbApplianceModel.getApplianceId());
			applianceDetailModel.setFipsState(dbApplianceModel.getFipsState());
			applianceDetailModel.setIpAddress(dbApplianceModel.getIpAddress());
			applianceDetailModel.setApplianceName(dbApplianceModel.getApplianceName());
			if(!StringUtils.isEmpty(dbApplianceModel.getOperationUsername())){
				applianceDetailModel.setOperationUsername(dbApplianceModel.getOperationUsername());
			}
			if(!StringUtils.isEmpty(dbApplianceModel.getOperationPassword())){
					applianceDetailModel.setOperationPassword(dbApplianceModel.getOperationPassword());
			}
			listDualAppModel.add(applianceDetailModel);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during dual factor details save inside saveDualFactorDetails"+e.getMessage());
		}
		return listDualAppModel;
	}
	
	public void deletePartitionsAndInitializeFromDB(ApplianceDetailModel app,String createdBy,String operationName){
		try{
			
			HSMInfo hSMInfo= new HSMInfo();
			HSMInfo hsmInfo=getHSMInfo(app,hSMInfo);
			if(hsmInfo.getFipsState()!=null && hsmInfo.getFipsState().replaceAll(" ","").contains("-1[zeroized]"))
			{
				PartitionsDetails partitionsDetails=null;
				partitionsDetails=partitionService.getPartitionInfo(app,partitionsDetails);	
				if(partitionsDetails!=null){
					if(partitionsDetails.getTotalPartitions()==0 && partitionsDetails.getPartitionDataList().size()==0){
						List<PartitionDetailModel> PartitionDetailModelList = partitionRepository.getListOfPartitionByApplianceID(app.getApplianceId());
						if(PartitionDetailModelList!=null && PartitionDetailModelList.size()>0){
							for(PartitionDetailModel pdm : PartitionDetailModelList){
								Long partitionId=pdm.getPartitionId();
								PartitionDetailModel partitionDetailModel=partitionRepository.findOne(partitionId);								 
								deletePartitionData(partitionDetailModel,createdBy,operationName);
								List<ClusterPartitionsRelationship> clus=clusterPartitionsRelationshipRepository.getListOfClusters(partitionDetailModel.getPartitionId());
								if(clus!=null && clus.size() > 0) {
									clusterPartitionsRelationshipRepository.deletePartitionFromCluster(partitionDetailModel.getPartitionId());
									/*for(ClusterPartitionsRelationship cls: clus) {
										clusterRepository.delete(cls.getClusterId());
									}*/
								}
							 }
						}
					 }
					else{
						List<String>removedpartitionNamesList = new ArrayList<String>();
				 
						List<PartitionDetailModel> PartitionDetailModelList = partitionRepository.getListOfPartitionByApplianceID(app.getApplianceId());
						for(PartitionDetailModel pdm : PartitionDetailModelList){
							removedpartitionNamesList.add(pdm.getPartitionName());
						}
						
						 for (String removedpartitionName:removedpartitionNamesList ) {
							
							for (Iterator<PartitionData> iterator = partitionsDetails.getPartitionDataList().iterator(); iterator.hasNext();) {
								PartitionData partitionData = (PartitionData) iterator.next();
								if(!StringUtils.isEmpty(partitionData.getName())) {
									if(removedpartitionName.equalsIgnoreCase(partitionData.getName()))
									{ 
										removedpartitionNamesList.remove(removedpartitionName);
									}
								}
							}
						}
							Long applianceId=Long.valueOf(app.getApplianceId());
							  List<PartitionDetailModel> pdm=null;	
							  for(String partitionName : removedpartitionNamesList){
								pdm=partitionRepository.getListOfPartitionByPartitionNameAndApplianceId(partitionName,applianceId);
								if(pdm!=null && pdm.size()!=0) {
									PartitionDetailModel pdmodel=pdm.get(0);
									deletePartitionData(pdmodel,createdBy,operationName);
								}
							 }
						 }
					}
				InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(app.getApplianceId());
				if(initmodel!=null){
				InitializeApplianceDetailModel init=initializeRepository.findOne(initmodel.getInitializeId());
				initializeAppliancesRelationshipReposiotry.delete(initmodel);
				initializeRepository.delete(init);		
				int status=	dfUsersRelationshipRepository.deleteDfDetailsAgainstAppliance(app.getApplianceId());
				}
				app.setLastOperationStatus("Completed");
				app.setLastOperationPerformed(operationName);
				app.setErrorMessage("");
				app.setCode("200");
				applianceRepository.save(app);
				}else{
					List<PartitionDetailModel> partlist=partitionRepository.getListOfPartitionByApplianceID(app.getApplianceId());
					for (PartitionDetailModel partitionDetailModel: partlist) {
						Long partitionId=partitionDetailModel.getPartitionId();
						String lastOperationStatus="Failed";
						String lastOperationPerformed=env.getProperty("appliance.zeroize");
						String status="Completed";
						String errorMessage="Appliance not zeroize getting Fips State for Applaince is non Zeroize.";
						partitionRepository.updatePartitionStatus(status,lastOperationStatus,lastOperationPerformed,errorMessage,partitionId);
					}
					app.setLastOperationStatus("failed");
					app.setLastOperationPerformed(operationName);
					if(operationName.contains("Firmware")) {
						app.setErrorMessage("Firmware with zeroize can not complete due to fips state for applaince is non Zeroize.");
					}else {
						app.setErrorMessage("Appliance not zeroize getting Fips State for Applaince is non Zeroize.");
					}
					app.setCode("409");
					applianceRepository.save(app);					 
				}
			
			
		}catch (Exception e) {
			List<PartitionDetailModel> partlist=partitionRepository.getListOfPartitionByApplianceID(app.getApplianceId());
			for (PartitionDetailModel partitionDetailModel: partlist) {
				Long partitionId=partitionDetailModel.getPartitionId();
				String lastOperationStatus="Failed";
				String lastOperationPerformed=env.getProperty("appliance.zeroize");
				String status="Completed";
				String errorMessage="Error occured during partitions deletion.";
				partitionRepository.updatePartitionStatus(status,lastOperationStatus,lastOperationPerformed,errorMessage,partitionId);
			}
			app.setLastOperationStatus("failed");
			app.setLastOperationPerformed(operationName);
			app.setErrorMessage("Error occured during partitions deletion.");
			app.setCode("409");
			applianceRepository.save(app);
			logger.error("Error ocuured during delete partitions and initialize Data from DB :: "+e.getMessage());
		}
	}
	
	public void deletePartitionData(PartitionDetailModel partitionDetailModel, String createdBy,String operationName) {
		boolean issuccess=false;
		try {
			
			if(partitionDetailModel!=null && partitionDetailModel.getPartitionId()!=0) {
				partitionETHRepository.deletePartitionETH(partitionDetailModel.getPartitionId());
				advanceStaticHostIpsRepository.deletePartitionAdvanceStaticHostIps(partitionDetailModel.getPartitionId());
				advanceDNSServersRepository.deletePartitionAdvanceDNSServers(partitionDetailModel.getPartitionId());
				advanceSearchDomainNamesRepository.deletePartitionAdvanceSearchDomainNames(partitionDetailModel.getPartitionId());
				partitionDataRepository.deletePartitionData(partitionDetailModel.getPartitionId());
			}
			issuccess=true;
		} catch (Exception e) {
			issuccess=false;
			// TODO: handle exception
			logger.error("Error ocuured during delete partition data");
			alertsService.createAlert(partitionDetailModel.getCreatedBy(),"Device "+partitionDetailModel.getApplianceDetailModel().getApplianceName()+"  try to perofrm delete partition by "+partitionDetailModel.getCreatedBy()+" did not perfomed delete partition due to db error",partitionDetailModel.getPartitionName(),partitionDetailModel.getPartitionId(),CaviumConstant.PARTITION_MANAGEMENT);
		}finally {
			if(issuccess) {
				partitionDetailModel.setApplianceDetailModel(null);
				partitionRepository.delete(partitionDetailModel);
				recentActivityServiceImpl.createRecentActivity(createdBy, "Partition "+partitionDetailModel.getPartitionName()+" removed by "+createdBy+".",CaviumConstant.PARTITION_MANAGEMENT);
			}else{
				Long partitionId=partitionDetailModel.getPartitionId();
				String lastOperationStatus="Failed";
				String lastOperationPerformed=operationName;
				String status="Completed";
				String errorMessage="Error occured during partition deletion.";
				partitionRepository.updatePartitionStatus(status,lastOperationStatus,lastOperationPerformed,errorMessage,partitionId);
			}
		}
	}

}

