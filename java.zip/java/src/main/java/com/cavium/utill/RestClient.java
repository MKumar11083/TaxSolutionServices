package com.cavium.utill;

import java.io.File;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Arrays;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

@Component
public class RestClient {
	private static Logger logger = Logger.getLogger(RestClient.class);

	/***
	 * This method is used to invoke GET method from cavium hsm rest api
	 * 
	 * @param url
	 * @return
	 * @throws NoSuchAlgorithmException
	 * @throws KeyStoreException
	 * @throws KeyManagementException
	 */
	@SuppressWarnings("static-access")
	public ResponseEntity<String> invokeGETMethod(String url)
			throws KeyManagementException, KeyStoreException, NoSuchAlgorithmException {
		ResponseEntity<String> response = null;
		RestTemplate restTemplate = new RestTemplate();
		try {
			HttpEntity<String> entity = new HttpEntity<String>(getHeaders());
			disable();
			response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
		} catch (Exception e) { 
			// TODO: handle exception
			logger.info("Error occured during rest get method");
			if(e.getMessage()!=null && e.getMessage().contains("ConnectException")) {
				response=new ResponseEntity<>(HttpStatus.REQUEST_TIMEOUT);
			}if(e.getMessage()!=null && (e.getMessage().contains("Unauthorized") || e.getMessage().contains("401"))) {
				response=new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
			}
		}
		return response;
	}


	/***
	 * This method is used to invoke GET method from cavium hsm rest api
	 * 
	 * @param url
	 * @return
	 * @throws NoSuchAlgorithmException
	 * @throws KeyStoreException
	 * @throws KeyManagementException
	 */
	@SuppressWarnings("static-access")
	public ResponseEntity<String> invokePOSTMethodForOperations(String url, JSONObject body)
			throws KeyManagementException, KeyStoreException, NoSuchAlgorithmException {
		ResponseEntity<String> response = null;
		RestTemplate restTemplate = new RestTemplate();
		try {
			/**
			 *  Note the body object as first parameter!
			 */
			//HttpHeaders headers = new HttpHeaders();
			//headers.set("x-app-id", "CaviumLiquidSA");
			HttpHeaders headers=new HttpHeaders();
			// commented for Simulator
			/*	if(url!=null && url.contains("zeroize")) {
				headers.setContentType(MediaType.APPLICATION_JSON);
				headers.set("x-app-id", "CaviumLiquidSA");
			}else {
				headers=getHeaders();
			}*/
			headers=getHeaders();
			// added for simulator
			//headers=getHeaders();
			HttpEntity<?> httpEntity = new HttpEntity<String>(body.toString(), headers);

			/**
			 * used to disable ssl
			 */
			disable();

			/**
			 * 		Used to invoke POST url
			 */
			response = restTemplate.exchange(url, HttpMethod.POST, httpEntity, String.class);
		} 
		catch (Exception e) { 
			if(e.getMessage()!=null && e.getMessage().contains("ConnectException")) {
				response=new ResponseEntity<>(HttpStatus.REQUEST_TIMEOUT);
			}if(e.getMessage()!=null && (e.getMessage().contains("Unauthorized") || e.getMessage().contains("401"))) {
				response=new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
			}
			logger.info(".....error reason...."+e.getCause());
			logger.info("Error occured during rest get method");
			// TODO: handle exception
			logger.info("Error occured during rest get method");
			/*if(e.getCause()!=null && e.getCause().toString().contains("java.net.ConnectException")){
				throw new KeyStoreException();
			}*/

		}
		return response;
	}

	@SuppressWarnings("static-access")
	public ResponseEntity<String> invokePOSTMethodObject(String url, MultiValueMap<String, Object> body)
			throws KeyManagementException, KeyStoreException, NoSuchAlgorithmException {
		ResponseEntity<String> response = null;
		RestTemplate restTemplate = new RestTemplate();
		try {
			/**
			 *  Note the body object as first parameter!
			 */
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.MULTIPART_FORM_DATA);
			headers.set("x-app-id", "CaviumLiquidSA");
			HttpEntity<MultiValueMap<String, Object>> entity = new HttpEntity<>(body, headers);

			/**
			 * used to disable ssl
			 */
			disable();

			/**
			 * 		Used to invoke POST url
			 */
			response = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
		} catch (Exception e) { 
			if(e.getMessage()!=null && e.getMessage().contains("ConnectException")) {
				response=new ResponseEntity<>(HttpStatus.REQUEST_TIMEOUT);
			}if(e.getMessage()!=null && (e.getMessage().contains("Unauthorized") || e.getMessage().contains("401"))) {
				response=new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
			}
			logger.info("Error occured during rest get method"+e.getMessage());
		}
		return response;
	}

	/***
	 * This method is setting up the headres
	 * 
	 * @return
	 */
	private HttpHeaders getHeaders() {
		HttpHeaders headers = new HttpHeaders();
		try {
			headers.setAccept(Arrays.asList(new MediaType[] { MediaType.APPLICATION_JSON }));
			// Request to return JSON format
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set("x-app-id", "CaviumLiquidSA");
			// HttpEntity<String>: To get result as String.
		} catch (Exception e) {
			logger.info("Error occured during header setting");
		}
		return headers;
	}

	public static void disable() {
		try {
			SSLContext sslc = SSLContext.getInstance("TLS");
			TrustManager[] trustManagerArray = { new NullX509TrustManager() };
			sslc.init(null, trustManagerArray, null);
			HttpsURLConnection.setDefaultSSLSocketFactory(sslc.getSocketFactory());
			HttpsURLConnection.setDefaultHostnameVerifier(new NullHostnameVerifier());

		} catch (Exception e) {
			logger.info("Error occured during ssl disable");
		}
	}

	private static class NullX509TrustManager implements X509TrustManager {
		public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
		}

		public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
		}

		public X509Certificate[] getAcceptedIssuers() {
			return new X509Certificate[0];
		}
	}

	private static class NullHostnameVerifier implements HostnameVerifier {
		public boolean verify(String hostname, SSLSession session) {
			return true;
		}
	}

	/***
	 * This method is used to invoke GET method from cavium hsm rest api
	 * 
	 * @param url
	 * @return
	 * @throws NoSuchAlgorithmException
	 * @throws KeyStoreException
	 * @throws KeyManagementException
	 */
	@SuppressWarnings("static-access")
	public ResponseEntity<String> invokeDELETEMethodForOperations(String url, JSONObject body)
			throws KeyManagementException, KeyStoreException, NoSuchAlgorithmException {
		ResponseEntity<String> response = null;
		RestTemplate restTemplate = new RestTemplate();
		try {
			/**
			 *  Note the body object as first parameter!
			 */
			//HttpHeaders headers = new HttpHeaders();
			//headers.set("x-app-id", "CaviumLiquidSA");
			HttpHeaders headers=new HttpHeaders();
			/*	if(url!=null && url.contains("zeroize")) {
				headers.set("x-app-id", "CaviumLiquidSA");
			}else {
				headers=getHeaders();
			}*/
			headers=getHeaders();
			HttpEntity<?> httpEntity = new HttpEntity<String>(body.toString(), headers);

			/**
			 * used to disable ssl
			 */
			disable();

			/**
			 * 		Used to invoke POST url
			 */
			response = restTemplate.exchange(url, HttpMethod.DELETE, httpEntity, String.class);
		} 
		catch (Exception e) { 
			if(e.getMessage()!=null && e.getMessage().contains("ConnectException")) {
				response=new ResponseEntity<>(HttpStatus.REQUEST_TIMEOUT);
			}if(e.getMessage()!=null && (e.getMessage().contains("Unauthorized") || e.getMessage().contains("401"))) {
				response=new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
			}
			logger.info(".....error reason...."+e.getCause());
			logger.info("Error occured during rest get method");
			// TODO: handle exception
			logger.info("Error occured during rest get method");
			/*if(e.getCause()!=null && e.getCause().toString().contains("java.net.ConnectException")){
				throw new KeyStoreException();
			}*/

		}
		return response;
	}

	/***
	 * This method is used to invoke GET method from cavium hsm rest api
	 * 
	 * @param url
	 * @return
	 * @throws NoSuchAlgorithmException
	 * @throws KeyStoreException
	 * @throws KeyManagementException
	 */
	@SuppressWarnings("static-access")
	public ResponseEntity<String> invokePUTMethodForOperations(String url, JSONObject body)
			throws KeyManagementException, KeyStoreException, NoSuchAlgorithmException {
		ResponseEntity<String> response = null;
		RestTemplate restTemplate = new RestTemplate();
		try {
			/**
			 *  Note the body object as first parameter!
			 */
			HttpHeaders headers=new HttpHeaders();
			/*	if(url!=null && url.contains("zeroize")) {
				headers.set("x-app-id", "CaviumLiquidSA");
			}else {
				headers=getHeaders();
			}*/
			headers=getHeaders();
			HttpEntity<?> httpEntity = new HttpEntity<String>(body.toString(), headers);

			/**
			 * used to disable ssl
			 */
			disable();

			/**
			 * 		Used to invoke POST url
			 */
			response = restTemplate.exchange(url, HttpMethod.PUT, httpEntity, String.class);
		} 
		catch (Exception e) { 
			if(e.getMessage()!=null && e.getMessage().contains("ConnectException")) {
				response=new ResponseEntity<>(HttpStatus.REQUEST_TIMEOUT);
			}if(e.getMessage()!=null && (e.getMessage().contains("Unauthorized") || e.getMessage().contains("401"))) {
				response=new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
			}
			logger.info(".....error reason...."+e.getCause());
			logger.info("Error occured during rest get method");
			// TODO: handle exception
			logger.info("Error occured during rest get method");
			/*if(e.getCause()!=null && e.getCause().toString().contains("java.net.ConnectException")){
				throw new KeyStoreException();
			}*/

		}
		return response;
	}

	/***
	 * This method is used to invoke GET method from cavium hsm rest api
	 * 
	 * @param url
	 * @return
	 * @throws NoSuchAlgorithmException
	 * @throws KeyStoreException
	 * @throws KeyManagementException
	 */
	@SuppressWarnings("static-access")
	public ResponseEntity<byte[]> invokeGETMethodForFileDownload(String url)
			throws KeyManagementException, KeyStoreException, NoSuchAlgorithmException {
		ResponseEntity<byte[]> response = null;
		RestTemplate restTemplate = new RestTemplate();
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_OCTET_STREAM));
			HttpEntity<String> entity = new HttpEntity<String>(headers);
			disable();
			response = restTemplate.exchange(url, HttpMethod.GET, entity, byte[].class);
		} catch (Exception e) { 
			// TODO: handle exception
			logger.info("Error occured during rest get method");
			if(e.getMessage()!=null && e.getMessage().contains("ConnectException")) {
				response=new ResponseEntity<>(HttpStatus.REQUEST_TIMEOUT);
			}if(e.getMessage()!=null && (e.getMessage().contains("Unauthorized") || e.getMessage().contains("401"))) {
				response=new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
			}
		}
		return response;
	}

	@SuppressWarnings("static-access")
	public ResponseEntity<byte[]> invokePUTMethodForFileDownload(String url, JSONObject body)
			throws KeyManagementException, KeyStoreException, NoSuchAlgorithmException {
		ResponseEntity<byte[]> response = null;
		RestTemplate restTemplate = new RestTemplate();
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_OCTET_STREAM));
			HttpEntity<?> httpEntity = new HttpEntity<String>(body.toString(), headers);
			disable();
			response = restTemplate.exchange(url, HttpMethod.GET, httpEntity, byte[].class);
		} catch (Exception e) { 
			// TODO: handle exception
			logger.info("Error occured during rest get method");
			if(e.getMessage()!=null && e.getMessage().contains("ConnectException")) {
				response=new ResponseEntity<>(HttpStatus.REQUEST_TIMEOUT);
			}if(e.getMessage()!=null && (e.getMessage().contains("Unauthorized") || e.getMessage().contains("401"))) {
				response=new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
			}
		}
		return response;
	}
	/**
	 * This method is used to upload large files
	 * @param url
	 * @param fileName
	 * @param file
	 * @param builder
	 * @return
	 */
	public String invokeMultiPartRequest(String url, String fileName, File file, MultipartEntityBuilder builder){
		CloseableHttpResponse response=null;
		String responseString=null;
		try {
			CloseableHttpClient httpclient = createAcceptSelfSignedCertificateClient();
			HttpPost uploadFile = new HttpPost(url);
			uploadFile.addHeader("x-app-id", "CaviumLiquidSA");
			FileBody fileBody = new FileBody(file, ContentType.MULTIPART_FORM_DATA,fileName);
			builder.addPart("file", fileBody);
			org.apache.http.HttpEntity multipart = builder.build();
			uploadFile.setEntity(multipart);
			disable();
			response = httpclient.execute(uploadFile);
			org.apache.http.HttpEntity entity = response.getEntity();
			responseString = EntityUtils.toString(entity, "UTF-8");
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during upload file for firmwareUpgrade invokeMultiPartRequest"+e.getMessage());
			if(e.getMessage().contains("Connection")) {
				responseString=e.getMessage();
			}
		}
		return responseString;
	}
	/**
	 * This method is used to disable the ssl for cavium rest
	 * @return
	 * @throws KeyManagementException
	 * @throws NoSuchAlgorithmException
	 * @throws KeyStoreException
	 */
	private static CloseableHttpClient createAcceptSelfSignedCertificateClient()
			throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException {

		// use the TrustSelfSignedStrategy to allow Self Signed Certificates
		SSLContext sslContext = SSLContextBuilder
				.create()
				.loadTrustMaterial(new TrustSelfSignedStrategy())
				.build();

		// we can optionally disable hostname verification. 
		// if you don't want to further weaken the security, you don't have to include this.
		HostnameVerifier allowAllHosts = new NoopHostnameVerifier();

		// create an SSL Socket Factory to use the SSLContext with the trust self signed certificate strategy
		// and allow all hosts verifier.
		SSLConnectionSocketFactory connectionFactory = new SSLConnectionSocketFactory(sslContext, allowAllHosts);

		// finally create the HttpClient using HttpClient factory methods and assign the ssl socket factory
		return HttpClients
				.custom()
				.setSSLSocketFactory(connectionFactory)
				.build();
	}



	@SuppressWarnings("static-access")
	public  HttpResponse invokeGETMethodForLargeFileDownload(String url){
		HttpResponse response =null;
		try {
			CloseableHttpClient httpclient = createAcceptSelfSignedCertificateClient();
			HttpGet httpget = new HttpGet(url);
			httpget.addHeader("x-app-id", "CaviumLiquidSA");
			disable();
			response=httpclient.execute(httpget);

		} catch (Exception e) { 
			logger.error("Error occured during rest get method :: "+e.getMessage());

		}
		return response;
	}
}
