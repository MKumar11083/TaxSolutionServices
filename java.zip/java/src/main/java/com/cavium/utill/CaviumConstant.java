package com.cavium.utill;

public class CaviumConstant {
	
	public static final String APPLIANCE_MANAGEMENT = "applianceManagement";
	public static final String CLUSTER_MANAGEMENT = "clusterManagement";
	public static final String PARTITION_MANAGEMENT = "partitionManagement";
	public static final String USER_MANAGEMENT = "userManagement";
	public static final String CREATE_CLUSTER = "create Cluster";
	public static final String REMOVE_CLUSTER = "remove Cluster";
	public static final String DOT = ".";
	public static final String USER_LOGIN_MANAGEMENT="loginManagement";
	public static final String APPLIANCE_ID="applianceId";
    public static final String DEFAULT_USER_NAME="defaultUsername";
    public static final String DEFAULT_PASSWORD="defaultPassword";
    public static final String CRYPTO_OFFICER_NAME="cryptoOfficerName";
    public static final String CRYPTO_OFFICER_PASSWORD="cryptoOfficerPassword";
    public static final String AUTHENTICATION_LEVEL="authenticationLevel";
    public static final String FIPS_STATE="fipsState";
    public static final String COMMA=",";
    public static final String DF_PORT="dfPort";
    public static final String DF_CERTIFICATE="dfCertificate";
    public static final String DF_KEY_FILE="dfKeyFile";
    public static final String OPERATION_TYPE="type";
    public static final String APPLIANCE_IP="applianceIp";
    public static final String FILE_NAME="filename";
    public static final String HSM_FILE_UPLOADED_ID="HsmFileUploadedId";
    public static final String SIGNED_HSM_FILE_UPLOADED_ID="signedHsmFileUploadedId";
    public static final String HSM_CERTIFICATE_TYPE="hsmCertificateType";
    public static final String LOGGER_TYPE="loggerType";
    public static final String UPLOADED_FILE_ID="uploadedFileId";

	
}

 