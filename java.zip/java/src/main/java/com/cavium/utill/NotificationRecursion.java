package com.cavium.utill;

import org.apache.log4j.Logger;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class NotificationRecursion {

	
	
	private static Logger logger = Logger.getLogger(NotificationRecursion.class);
	
	/*public static void main(String[] args) throws IOException {
		String ip = "10.89.6.40";
		int jobId = 100;
		getStatus(ip, jobId);
	}

	public static void getStatus(String ip, int jobId) {
		NotificationRecursion notification=new NotificationRecursion();
		try {
			for (int i = 0; i < 5; i++) {
					String ss = notification.getNotificationStatusByJobId(ip, jobId);
					if (ss.equalsIgnoreCase("success") || ss.equalsIgnoreCase("failed")) {
						System.out.println(ss);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getStatus from notification api call"+e.getMessage());
		}
	}

	public String getNotificationStatusByJobId(String ip, int jobId) {
		ResponseEntity<String> response = null;
		String responseString = "";
		int count = 0;
		try {
			if (count <= 5) {
				Thread.sleep(15000);
				response = restClient.invokeGETMethod("https://"+ip+"/liquidsa/notification/"+jobId+"");
				if (response != null && response.getBody()!=null && response.getBody().contains("success")) {
					responseString = "success";
					return responseString;
				} else {
					if (response != null && response.getBody().contains("errors")) {
						responseString = "failed";
						return responseString;
					} else {
						count++;
						return getNotificationStatusByJobId(ip, jobId);
					}
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during notification call inside method getNotificationStatusByJobId from class NotificationRecursion"+e.getMessage());
		}
		return responseString;
	}*/
	
	public ResponseEntity<String> getCustomNotificationStatusByJobId(String ip, int jobId) {
		ResponseEntity<String> response = null;
		RestClient restClient=new RestClient();
		try {
				response = restClient.invokeGETMethod("https://"+ip+"/liquidsa/notification/"+jobId+"");
				if (response != null && response.getBody()!=null && response.getBody().contains("success")) {
					return response;
				} else {
					if (response != null && response.getBody()!=null && !response.getBody().contains("busy")) {
						return response;
					} else {
						return getCustomNotificationStatusByJobId(ip, jobId);
					}
				}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during notification call inside method getCustomNotificationStatusByJobId from class NotificationRecursion"+e.getMessage());
		}
		return response;
	}

}
