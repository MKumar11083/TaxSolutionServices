package com.cavium.utill;

import java.io.IOException;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.snmp4j.CommunityTarget;
import org.snmp4j.PDU;
import org.snmp4j.Snmp;
import org.snmp4j.TransportMapping;
import org.snmp4j.event.ResponseEvent;
import org.snmp4j.mp.SnmpConstants;
import org.snmp4j.smi.Integer32;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.UdpAddress;
import org.snmp4j.smi.VariableBinding;
import org.snmp4j.transport.DefaultUdpTransportMapping;

public  class SNMPUtil {


    private static String  port    = "161";
    private static String  oidValue  = ".1.3.6.1.2.1.1.1.0";
  
    public static void main(String[] args)  {
    	try{
    	SNMPUtil.discoverSNMP("10.89.7.150");
    	}catch (Exception e) {
			// TODO: handle exception
		}
	}
  
	private static Logger logger = Logger.getLogger(CaviumUtil.class);

    public static boolean discoverSNMP(String ipAddress) throws IOException {

		logger.info("start of discoverSNMP method  of SNMPUtil class");
      
   // Create TransportMapping and Listen
           TransportMapping transport = new DefaultUdpTransportMapping();
           transport.listen();


           // Create Target Address object
           CommunityTarget comtarget = new CommunityTarget();
           comtarget.setCommunity(new OctetString("public"));
           comtarget.setVersion(SnmpConstants.version2c);
           comtarget.setAddress(new UdpAddress(ipAddress + "/" + port));
           comtarget.setRetries(2);
           comtarget.setTimeout(1000);

           // Create the PDU object
           PDU pdu = new PDU();
           pdu.add(new VariableBinding(new OID(oidValue)));
           pdu.setType(PDU.GET);
           pdu.setRequestID(new Integer32(1));

           // Create Snmp object for sending data to Agent
           Snmp snmp = new Snmp(transport);

       
   		logger.info("Sending Request to Agent...");
           ResponseEvent response = snmp.get(pdu, comtarget);

           // Process Agent Response
           if (response != null)
           {
        	   logger.info("Got Response from Agent");            
                  PDU responsePDU = response.getResponse();

                  if (responsePDU != null)
                  {
                        int errorStatus = responsePDU.getErrorStatus();
                        int errorIndex = responsePDU.getErrorIndex();
                        String errorStatusText = responsePDU.getErrorStatusText();

                        if (errorStatus == PDU.noError)
                        {

                               VariableBinding  responseValue= responsePDU.get(0);
                               String result= responseValue.toValueString();
                               logger.info("PDU response value is " + result);  
                               
                               if (result.contains("Cavium:LiquidSec"))
                               {
                                      return true;
                               }
                        }
                        else
                        {
                        	  logger.error("Error Status = " + errorStatus); 
                        	  logger.error("Error Index = " + errorIndex); 
                        	  logger.error("Error Status Text = " + errorStatusText); 
                       	  
                        }
                  }
                  else
                  {
                	  logger.error("Error: Response PDU is null"); 
                        
                  }
           }
           else
           {
        	   logger.error("Error: Agent Timeout...");                
           }
           snmp.close();
   		logger.info("end of discoverSNMP method  of SNMPUtil class");
           return false;
           
    }
    

		
}

