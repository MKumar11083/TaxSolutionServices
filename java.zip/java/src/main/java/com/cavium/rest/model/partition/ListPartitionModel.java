package com.cavium.rest.model.partition;

import java.io.Serializable;

import javax.persistence.Column;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(value=Include.NON_NULL)

public class ListPartitionModel implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -234363974931473700L;
	
	private Long partitionId;
	private Long applianceId;
	private Integer certAuth;
	private String pcoFixedKeyFingerPrint; 
	private Integer maxKeys;	 
	private String cloningMethod;
	private Integer totalSslCtxs; 
	private Integer mValueCloning; 
	private Integer kekMethod;	 
	private String auditLogStatus;	 
	private Integer blockDeleteUserWithKeys; 
	private Integer cavServerStatus;	 
	private String nodeId; 
	private Integer mValueMiscCO;	 
	private Integer maxAcclrDevCount; 
	private String keyImport;	 
	private String keyExport;	 
	private Integer occupiedSessionKeys;	 
	private String exportWithUserKeysOtherThanKEK; 
	private String status;	 
	private Integer mValueBackupByCO;	 
	private Integer sessionCount;	 
	private Integer twoKeyBackup;	 
	private Integer availableUsers; 
	private Integer maxPswdLen;	 
	private Integer maxUsers; 
	private String groupId;	 
	private Integer vmStatus;	 
	private String name;	 
	private Integer nValue;	 
	private Boolean mcoBackupRestore;	 
	private Integer occupiedSslCtxs;	 
	private String fipsState;	 
	private Integer occupiedTokenKeys;	 
	private Integer mValueUserMgmt;	 
	private Integer minPswdLen; 
	
	/**
	 * @return the certAuth
	 */
	public Integer getCertAuth() {
		return certAuth;
	}
	/**
	 * @param certAuth the certAuth to set
	 */
	public void setCertAuth(Integer certAuth) {
		this.certAuth = certAuth;
	}
	/**
	 * @return the pcoFixedKeyFingerPrint
	 */
	public String getPcoFixedKeyFingerPrint() {
		return pcoFixedKeyFingerPrint;
	}
	/**
	 * @param pcoFixedKeyFingerPrint the pcoFixedKeyFingerPrint to set
	 */
	public void setPcoFixedKeyFingerPrint(String pcoFixedKeyFingerPrint) {
		this.pcoFixedKeyFingerPrint = pcoFixedKeyFingerPrint;
	}
	/**
	 * @return the maxKeys
	 */
	public Integer getMaxKeys() {
		return maxKeys;
	}
	/**
	 * @param maxKeys the maxKeys to set
	 */
	public void setMaxKeys(Integer maxKeys) {
		this.maxKeys = maxKeys;
	}
	/**
	 * @return the cloningMethod
	 */
	public String getCloningMethod() {
		return cloningMethod;
	}
	/**
	 * @param cloningMethod the cloningMethod to set
	 */
	public void setCloningMethod(String cloningMethod) {
		this.cloningMethod = cloningMethod;
	}
	/**
	 * @return the totalSslCtxs
	 */
	public Integer getTotalSslCtxs() {
		return totalSslCtxs;
	}
	/**
	 * @param totalSslCtxs the totalSslCtxs to set
	 */
	public void setTotalSslCtxs(Integer totalSslCtxs) {
		this.totalSslCtxs = totalSslCtxs;
	}
	/**
	 * @return the mValueCloning
	 */
	public Integer getmValueCloning() {
		return mValueCloning;
	}
	/**
	 * @param mValueCloning the mValueCloning to set
	 */
	public void setmValueCloning(Integer mValueCloning) {
		this.mValueCloning = mValueCloning;
	}
	/**
	 * @return the kekMethod
	 */
	public Integer getKekMethod() {
		return kekMethod;
	}
	/**
	 * @param kekMethod the kekMethod to set
	 */
	public void setKekMethod(Integer kekMethod) {
		this.kekMethod = kekMethod;
	}
	/**
	 * @return the auditLogStatus
	 */
	public String getAuditLogStatus() {
		return auditLogStatus;
	}
	/**
	 * @param auditLogStatus the auditLogStatus to set
	 */
	public void setAuditLogStatus(String auditLogStatus) {
		this.auditLogStatus = auditLogStatus;
	}
	/**
	 * @return the blockDeleteUserWithKeys
	 */
	public Integer getBlockDeleteUserWithKeys() {
		return blockDeleteUserWithKeys;
	}
	/**
	 * @param blockDeleteUserWithKeys the blockDeleteUserWithKeys to set
	 */
	public void setBlockDeleteUserWithKeys(Integer blockDeleteUserWithKeys) {
		this.blockDeleteUserWithKeys = blockDeleteUserWithKeys;
	}
	/**
	 * @return the cavServerStatus
	 */
	public Integer getCavServerStatus() {
		return cavServerStatus;
	}
	/**
	 * @param cavServerStatus the cavServerStatus to set
	 */
	public void setCavServerStatus(Integer cavServerStatus) {
		this.cavServerStatus = cavServerStatus;
	}
	/**
	 * @return the nodeId
	 */
	public String getNodeId() {
		return nodeId;
	}
	/**
	 * @param nodeId the nodeId to set
	 */
	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}
	/**
	 * @return the mValueMiscCO
	 */
	public Integer getmValueMiscCO() {
		return mValueMiscCO;
	}
	/**
	 * @param mValueMiscCO the mValueMiscCO to set
	 */
	public void setmValueMiscCO(Integer mValueMiscCO) {
		this.mValueMiscCO = mValueMiscCO;
	}
	/**
	 * @return the maxAcclrDevCount
	 */
	public Integer getMaxAcclrDevCount() {
		return maxAcclrDevCount;
	}
	/**
	 * @param maxAcclrDevCount the maxAcclrDevCount to set
	 */
	public void setMaxAcclrDevCount(Integer maxAcclrDevCount) {
		this.maxAcclrDevCount = maxAcclrDevCount;
	}
	/**
	 * @return the keyImport
	 */
	public String getKeyImport() {
		return keyImport;
	}
	/**
	 * @param keyImport the keyImport to set
	 */
	public void setKeyImport(String keyImport) {
		this.keyImport = keyImport;
	}
	/**
	 * @return the keyExport
	 */
	public String getKeyExport() {
		return keyExport;
	}
	/**
	 * @param keyExport the keyExport to set
	 */
	public void setKeyExport(String keyExport) {
		this.keyExport = keyExport;
	}
	/**
	 * @return the occupiedSessionKeys
	 */
	public Integer getOccupiedSessionKeys() {
		return occupiedSessionKeys;
	}
	/**
	 * @param occupiedSessionKeys the occupiedSessionKeys to set
	 */
	public void setOccupiedSessionKeys(Integer occupiedSessionKeys) {
		this.occupiedSessionKeys = occupiedSessionKeys;
	}
	/**
	 * @return the exportWithUserKeysOtherThanKEK
	 */
	public String getExportWithUserKeysOtherThanKEK() {
		return exportWithUserKeysOtherThanKEK;
	}
	/**
	 * @param exportWithUserKeysOtherThanKEK the exportWithUserKeysOtherThanKEK to set
	 */
	public void setExportWithUserKeysOtherThanKEK(String exportWithUserKeysOtherThanKEK) {
		this.exportWithUserKeysOtherThanKEK = exportWithUserKeysOtherThanKEK;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the mValueBackupByCO
	 */
	public Integer getmValueBackupByCO() {
		return mValueBackupByCO;
	}
	/**
	 * @param mValueBackupByCO the mValueBackupByCO to set
	 */
	public void setmValueBackupByCO(Integer mValueBackupByCO) {
		this.mValueBackupByCO = mValueBackupByCO;
	}
	/**
	 * @return the sessionCount
	 */
	public Integer getSessionCount() {
		return sessionCount;
	}
	/**
	 * @param sessionCount the sessionCount to set
	 */
	public void setSessionCount(Integer sessionCount) {
		this.sessionCount = sessionCount;
	}
	/**
	 * @return the twoKeyBackup
	 */
	public Integer getTwoKeyBackup() {
		return twoKeyBackup;
	}
	/**
	 * @param twoKeyBackup the twoKeyBackup to set
	 */
	public void setTwoKeyBackup(Integer twoKeyBackup) {
		this.twoKeyBackup = twoKeyBackup;
	}
	/**
	 * @return the availableUsers
	 */
	public Integer getAvailableUsers() {
		return availableUsers;
	}
	/**
	 * @param availableUsers the availableUsers to set
	 */
	public void setAvailableUsers(Integer availableUsers) {
		this.availableUsers = availableUsers;
	}
	/**
	 * @return the maxPswdLen
	 */
	public Integer getMaxPswdLen() {
		return maxPswdLen;
	}
	/**
	 * @param maxPswdLen the maxPswdLen to set
	 */
	public void setMaxPswdLen(Integer maxPswdLen) {
		this.maxPswdLen = maxPswdLen;
	}
	/**
	 * @return the maxUsers
	 */
	public Integer getMaxUsers() {
		return maxUsers;
	}
	/**
	 * @param maxUsers the maxUsers to set
	 */
	public void setMaxUsers(Integer maxUsers) {
		this.maxUsers = maxUsers;
	}
	/**
	 * @return the groupId
	 */
	public String getGroupId() {
		return groupId;
	}
	/**
	 * @param groupId the groupId to set
	 */
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	/**
	 * @return the vmStatus
	 */
	public Integer getVmStatus() {
		return vmStatus;
	}
	/**
	 * @param vmStatus the vmStatus to set
	 */
	public void setVmStatus(Integer vmStatus) {
		this.vmStatus = vmStatus;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the nValue
	 */
	public Integer getnValue() {
		return nValue;
	}
	/**
	 * @param nValue the nValue to set
	 */
	public void setnValue(Integer nValue) {
		this.nValue = nValue;
	}
	/**
	 * @return the mcoBackupRestore
	 */
	public Boolean getMcoBackupRestore() {
		return mcoBackupRestore;
	}
	/**
	 * @param mcoBackupRestore the mcoBackupRestore to set
	 */
	public void setMcoBackupRestore(Boolean mcoBackupRestore) {
		this.mcoBackupRestore = mcoBackupRestore;
	}
	/**
	 * @return the occupiedSslCtxs
	 */
	public Integer getOccupiedSslCtxs() {
		return occupiedSslCtxs;
	}
	/**
	 * @param occupiedSslCtxs the occupiedSslCtxs to set
	 */
	public void setOccupiedSslCtxs(Integer occupiedSslCtxs) {
		this.occupiedSslCtxs = occupiedSslCtxs;
	}
	/**
	 * @return the fipsState
	 */
	public String getFipsState() {
		return fipsState;
	}
	/**
	 * @param fipsState the fipsState to set
	 */
	public void setFipsState(String fipsState) {
		this.fipsState = fipsState;
	}
	/**
	 * @return the occupiedTokenKeys
	 */
	public Integer getOccupiedTokenKeys() {
		return occupiedTokenKeys;
	}
	/**
	 * @param occupiedTokenKeys the occupiedTokenKeys to set
	 */
	public void setOccupiedTokenKeys(Integer occupiedTokenKeys) {
		this.occupiedTokenKeys = occupiedTokenKeys;
	}
	/**
	 * @return the mValueUserMgmt
	 */
	public Integer getmValueUserMgmt() {
		return mValueUserMgmt;
	}
	/**
	 * @param mValueUserMgmt the mValueUserMgmt to set
	 */
	public void setmValueUserMgmt(Integer mValueUserMgmt) {
		this.mValueUserMgmt = mValueUserMgmt;
	}
	/**
	 * @return the minPswdLen
	 */
	public Integer getMinPswdLen() {
		return minPswdLen;
	}
	/**
	 * @param minPswdLen the minPswdLen to set
	 */
	public void setMinPswdLen(Integer minPswdLen) {
		this.minPswdLen = minPswdLen;
	}
	 
	 
	/**
	 * @return the partitionId
	 */
	public Long getPartitionId() {
		return partitionId;
	}
	/**
	 * @param partitionId the partitionId to set
	 */
	public void setPartitionId(Long partitionId) {
		this.partitionId = partitionId;
	}
	/**
	 * @return the applianceId
	 */
	public Long getApplianceId() {
		return applianceId;
	}
	/**
	 * @param applianceId the applianceId to set
	 */
	public void setApplianceId(Long applianceId) {
		this.applianceId = applianceId;
	}
 
  
}
