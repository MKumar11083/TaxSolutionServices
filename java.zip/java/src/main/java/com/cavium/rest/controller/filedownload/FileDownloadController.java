package com.cavium.rest.controller.filedownload;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.repository.appliance.ApplianceRepository;
import com.cavium.rest.model.filedownload.FileDownloadDetail;
import com.cavium.service.appliance.ApplianceService;
import com.cavium.utill.CaviumUtil;

@RestController
@RequestMapping("/rest")
public class FileDownloadController {

	@Autowired
	private ApplianceService applianceService;
	
	@Autowired
	private ApplianceRepository applianceRepository;
	
	private Logger logger = Logger.getLogger(this.getClass());

	@RequestMapping(value = "fileDownloads" , method = RequestMethod.POST,produces="application/zip")
	public void fileDownloads(@RequestBody  List<FileDownloadDetail> fileDownloadDetails,HttpServletResponse response ) {
		
		ArrayList<File> files = new ArrayList<>();
		BufferedOutputStream bufferedOutputStream =null;
		ZipOutputStream zipOutputStream=null; 
		try {
		boolean headerSet=false;
		bufferedOutputStream = new BufferedOutputStream(response.getOutputStream());
		zipOutputStream   = new ZipOutputStream(bufferedOutputStream);
		for(FileDownloadDetail fileDownloadDetail: fileDownloadDetails){
			File file=null;
			if(!StringUtils.isEmpty(fileDownloadDetail.getApplianceIp()) && CaviumUtil.validateIPAddress(fileDownloadDetail.getApplianceIp())){	
				List<ApplianceDetailModel>  appModels = applianceRepository.getApplianceExists(fileDownloadDetail.getApplianceIp());
				if(appModels.size() > 0) {			
		file=applianceService.downloadFileFromURL(fileDownloadDetail.getDownloadedUrlAddr(),appModels.get(0).getApplianceName());
		if(file!=null) {
			if(!headerSet){
				response.setContentType("application/zip");
				response.setStatus(HttpServletResponse.SC_OK);
				response.addHeader("Content-Disposition", "attachment; filename=\"downloadedFiles.zip\"");
				headerSet=true;
			}
			files.add(file);
		}
				}
			}
		}
		for (File file : files) {
			//new zip entry and copying inputstream with file to zipOutputStream, after all closing streams
			zipOutputStream.putNextEntry(new ZipEntry(file.getName()));
			FileInputStream fileInputStream = new FileInputStream(file);

			IOUtils.copy(fileInputStream, zipOutputStream);

			fileInputStream.close();
			zipOutputStream.closeEntry();
		}
		try{
			if (zipOutputStream != null) {
				zipOutputStream.finish();
				zipOutputStream.flush();
				IOUtils.closeQuietly(zipOutputStream);
			}
			if(bufferedOutputStream!=null){
				IOUtils.closeQuietly(bufferedOutputStream);
			}
		}catch (Exception e) {
			logger.error("error coming while closing  zipOutputStream in fileDownloads method of FileDownloadController :: "+e.getMessage());	 
		
		}
		 }catch (IOException e) {
				logger.error("error coming while download the certificate in fileDownloads method of FileDownloadController :: "+e.getMessage());
			}
			finally {

				for (File file : files) 
					if(file!=null){
						try{
							Files.deleteIfExists(Paths.get(file.getAbsolutePath()));
						}catch (Exception e) {
							logger.error("Error while deleting certificate file  in fileDownloads method of FileDownloadController :: " + e.getMessage()); 
						}
					}
		 }
	}

	 


}