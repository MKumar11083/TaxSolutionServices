package com.cavium.rest.service.appliance;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.cavium.model.appliance.DualFactorUsersRelationshipModel;
import com.cavium.repository.appliance.DualFactorUsersRelationshipRepository;
import com.cavium.utill.RestClient;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Component
public class ApplianceManagementServiceIMPL implements ApplianceManagementService {

	
	
	@Autowired
	RestClient restClient;
	@Autowired
	private DualFactorUsersRelationshipRepository dfUsersRelationshipRepository;
	
	private Logger logger = Logger.getLogger(this.getClass());
	
	public String getHSMDetail(String applianceIp){
		logger.info("Start of  getHSMDetail Method of  ApplianceManagementServiceIMPL class ::"); 
		String response="";
		try{
		ResponseEntity<String> responseEntity=restClient.invokeGETMethod("https://"+applianceIp+"/liquidsa/info");
		  if(responseEntity!=null && responseEntity.getStatusCode().name().equals("OK")) {
				ObjectMapper mapper = new ObjectMapper();
				if(responseEntity.getBody()!=null){
					JsonNode root = mapper.readTree(responseEntity.getBody());
					  if(!root.isNull()){
						  ((ObjectNode)root).put("applianceIp", applianceIp);
						  response=root.toString();
					  }
				 }
		  }else{
			 JSONObject json= new JSONObject(); 
			 json.put("status","failed");
			 json.put("message","Appliance is not reachable");
			 json.put("code","408");
			 json.put("applianceIp",applianceIp);
			 response=json.toString();
		  }
		}catch(Exception exp){
			logger.error("Error occured during fetch HSM Info of class ApplianceManagementServiceIMPL ::" + exp.getMessage()); 
		}
		logger.info("End of  getHSMDetail Method of  ApplianceManagementServiceIMPL class ::"); 
		 return response;
	}
	
	public DualFactorUsersRelationshipModel saveDualFactorDetails(DualFactorUsersRelationshipModel dualFactorDetails) {
		try {
			dfUsersRelationshipRepository.save(dualFactorDetails);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error(""+e.getMessage());
		}
		return dualFactorDetails;
	}
	

}
