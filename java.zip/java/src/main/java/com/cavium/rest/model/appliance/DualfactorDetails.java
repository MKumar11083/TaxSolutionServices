package com.cavium.rest.model.appliance;

import java.io.Serializable;

public class DualfactorDetails implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String dfPort;
	private String dfCertificate;
	private String dfKeyFile;
	 
	/**
	 * @return the dfCertificate
	 */
	public String getDfCertificate() {
		return dfCertificate;
	}
	/**
	 * @param dfCertificate the dfCertificate to set
	 */
	public void setDfCertificate(String dfCertificate) {
		this.dfCertificate = dfCertificate;
	}
	/**
	 * @return the dfKeyFile
	 */
	public String getDfKeyFile() {
		return dfKeyFile;
	}
	/**
	 * @param dfKeyFile the dfKeyFile to set
	 */
	public void setDfKeyFile(String dfKeyFile) {
		this.dfKeyFile = dfKeyFile;
	}
	/**
	 * @return the dfPort
	 */
	public String getDfPort() {
		return dfPort;
	}
	/**
	 * @param dfPort the dfPort to set
	 */
	public void setDfPort(String dfPort) {
		this.dfPort = dfPort;
	}

}
