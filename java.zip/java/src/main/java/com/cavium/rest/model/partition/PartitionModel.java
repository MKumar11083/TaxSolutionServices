package com.cavium.rest.model.partition;

import java.io.Serializable;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.appliance.DualFactorUsersRelationshipModel;
import com.cavium.model.partition.PartitionInterfaces;
 
public class PartitionModel implements Serializable {

	private static final long serialVersionUID = -3840562434180092945L;
 
	private String partitionName;	 
	private Long partitionId;
	private Long applianceId;	 
	private String csr;	 
	private Integer keys;
	private Integer sslContexts;
	private Integer acclrDev;
	private Boolean wrap;
	private Boolean backup;
	private PartitionInterfaces networkStats;
	private ApplianceDetailModel applianceDetails;
	private String username;
	private String password;
	private DualFactorUsersRelationshipModel dualFactorDetails;	 
	private Boolean sessionClose;
	private Boolean noKey; 
	private ResizePartitionModel resizeDetails;
	
	// Start of restore Operation
	private Integer nodeId;
	private String backupFileId;
	private Boolean checkIntegrity;
	private BackupPartitionDetailsModel backupPartitionDetails;
	// End of Restore
	
	// Start for cavServer Operation
	private Boolean enableCavServer;
	private String configFileId;
	/**
	 * @return the partitionName
	 */
	public String getPartitionName() {
		return partitionName;
	}
	/**
	 * @param partitionName the partitionName to set
	 */
	public void setPartitionName(String partitionName) {
		this.partitionName = partitionName;
	}
	/**
	 * @return the csr
	 */
	public String getCsr() {
		return csr;
	}
	/**
	 * @param csr the csr to set
	 */
	public void setCsr(String csr) {
		this.csr = csr;
	}
	/**
	 * @return the keys
	 */
	public Integer getKeys() {
		return keys;
	}
	/**
	 * @param keys the keys to set
	 */
	public void setKeys(Integer keys) {
		this.keys = keys;
	}
	/**
	 * @return the sslContexts
	 */
	public Integer getSslContexts() {
		return sslContexts;
	}
	/**
	 * @param sslContexts the sslContexts to set
	 */
	public void setSslContexts(Integer sslContexts) {
		this.sslContexts = sslContexts;
	}
	/**
	 * @return the acclrDev
	 */
	public Integer getAcclrDev() {
		return acclrDev;
	}
	/**
	 * @param acclrDev the acclrDev to set
	 */
	public void setAcclrDev(Integer acclrDev) {
		this.acclrDev = acclrDev;
	}
	/**
	 * @return the wrap
	 */
	public Boolean getWrap() {
		return wrap;
	}
	/**
	 * @param wrap the wrap to set
	 */
	public void setWrap(Boolean wrap) {
		this.wrap = wrap;
	}
	/**
	 * @return the backup
	 */
	public Boolean getBackup() {
		return backup;
	}
	/**
	 * @param backup the backup to set
	 */
	public void setBackup(Boolean backup) {
		this.backup = backup;
	}
	/**
	 * @return the networkStats
	 */
	public PartitionInterfaces getNetworkStats() {
		return networkStats;
	}
	/**
	 * @param networkStats the networkStats to set
	 */
	public void setNetworkStats(PartitionInterfaces networkStats) {
		this.networkStats = networkStats;
	}
	 
	/**
	 * @return the dualFactorDetails
	 */
	public DualFactorUsersRelationshipModel getDualFactorDetails() {
		return dualFactorDetails;
	}
	/**
	 * @param dualFactorDetails the dualFactorDetails to set
	 */
	public void setDualFactorDetails(DualFactorUsersRelationshipModel dualFactorDetails) {
		this.dualFactorDetails = dualFactorDetails;
	}
	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}
	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}
	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * @return the applianceId
	 */
	public Long getApplianceId() {
		return applianceId;
	}
	/**
	 * @param applianceId the applianceId to set
	 */
	public void setApplianceId(Long applianceId) {
		this.applianceId = applianceId;
	}
	/**
	 * @return the applianceDetails
	 */
	public ApplianceDetailModel getApplianceDetails() {
		return applianceDetails;
	}
	/**
	 * @param applianceDetails the applianceDetails to set
	 */
	public void setApplianceDetails(ApplianceDetailModel applianceDetails) {
		this.applianceDetails = applianceDetails;
	}
	/**
	 * @return the sessionClose
	 */
	public Boolean getSessionClose() {
		return sessionClose;
	}
	/**
	 * @param sessionClose the sessionClose to set
	 */
	public void setSessionClose(Boolean sessionClose) {
		this.sessionClose = sessionClose;
	}
	/**
	 * @return the partitionId
	 */
	public Long getPartitionId() {
		return partitionId;
	}
	/**
	 * @param partitionId the partitionId to set
	 */
	public void setPartitionId(Long partitionId) {
		this.partitionId = partitionId;
	}
	/**
	 * @return the noKey
	 */
	public Boolean getNoKey() {
		return noKey;
	}
	/**
	 * @param noKey the noKey to set
	 */
	public void setNoKey(Boolean noKey) {
		this.noKey = noKey;
	}
	/**
	 * @return the resizeDetails
	 */
	public ResizePartitionModel getResizeDetails() {
		return resizeDetails;
	}
	/**
	 * @param resizeDetails the resizeDetails to set
	 */
	public void setResizeDetails(ResizePartitionModel resizeDetails) {
		this.resizeDetails = resizeDetails;
	}
	/**
	 * @return the nodeId
	 */
	public Integer getNodeId() {
		return nodeId;
	}
	/**
	 * @param nodeId the nodeId to set
	 */
	public void setNodeId(Integer nodeId) {
		this.nodeId = nodeId;
	}
	/**
	 * @return the backupFileId
	 */
	public String getBackupFileId() {
		return backupFileId;
	}
	/**
	 * @param backupFileId the backupFileId to set
	 */
	public void setBackupFileId(String backupFileId) {
		this.backupFileId = backupFileId;
	}
	/**
	 * @return the checkIntegrity
	 */
	public Boolean getCheckIntegrity() {
		return checkIntegrity;
	}
	/**
	 * @param checkIntegrity the checkIntegrity to set
	 */
	public void setCheckIntegrity(Boolean checkIntegrity) {
		this.checkIntegrity = checkIntegrity;
	}
	/**
	 * @return the backupPartitionDetails
	 */
	public BackupPartitionDetailsModel getBackupPartitionDetails() {
		return backupPartitionDetails;
	}
	/**
	 * @param backupPartitionDetails the backupPartitionDetails to set
	 */
	public void setBackupPartitionDetails(BackupPartitionDetailsModel backupPartitionDetails) {
		this.backupPartitionDetails = backupPartitionDetails;
	}
	/**
	 * @return the enableCavServer
	 */
	public Boolean getEnableCavServer() {
		return enableCavServer;
	}
	/**
	 * @param enableCavServer the enableCavServer to set
	 */
	public void setEnableCavServer(Boolean enableCavServer) {
		this.enableCavServer = enableCavServer;
	}
	/**
	 * @return the configFileId
	 */
	public String getConfigFileId() {
		return configFileId;
	}
	/**
	 * @param configFileId the configFileId to set
	 */
	public void setConfigFileId(String configFileId) {
		this.configFileId = configFileId;
	}
	  
}
