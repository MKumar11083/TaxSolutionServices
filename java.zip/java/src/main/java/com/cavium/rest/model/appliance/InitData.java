package com.cavium.rest.model.appliance;

import java.io.Serializable;

public class InitData implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String cryptoOfficerName;

	private String cryptoOfficerPassword;

	private Integer authenticationLevel;

	private Integer fipsState;
	private Integer certAuth;
	private Integer loginFailureCount;
	private Integer minimumPasswordLength;
	private Integer maximumPasswordLength;
	private String hsmLabel;
	private boolean hsmAuditLog;
	/**
	 * @return the cryptoOfficerName
	 */
	public String getCryptoOfficerName() {
		return cryptoOfficerName;
	}
	/**
	 * @param cryptoOfficerName the cryptoOfficerName to set
	 */
	public void setCryptoOfficerName(String cryptoOfficerName) {
		this.cryptoOfficerName = cryptoOfficerName;
	}
	/**
	 * @return the cryptoOfficerPassword
	 */
	public String getCryptoOfficerPassword() {
		return cryptoOfficerPassword;
	}
	/**
	 * @param cryptoOfficerPassword the cryptoOfficerPassword to set
	 */
	public void setCryptoOfficerPassword(String cryptoOfficerPassword) {
		this.cryptoOfficerPassword = cryptoOfficerPassword;
	}
	/**
	 * @return the authenticationLevel
	 */
	public Integer getAuthenticationLevel() {
		return authenticationLevel;
	}
	/**
	 * @param authenticationLevel the authenticationLevel to set
	 */
	public void setAuthenticationLevel(Integer authenticationLevel) {
		this.authenticationLevel = authenticationLevel;
	}
	/**
	 * @return the fipsState
	 */
	public Integer getFipsState() {
		return fipsState;
	}
	/**
	 * @param fipsState the fipsState to set
	 */
	public void setFipsState(Integer fipsState) {
		this.fipsState = fipsState;
	}
	/**
	 * @return the certAuth
	 */
	public Integer getCertAuth() {
		return certAuth;
	}
	/**
	 * @param certAuth the certAuth to set
	 */
	public void setCertAuth(Integer certAuth) {
		this.certAuth = certAuth;
	}
	/**
	 * @return the loginFailureCount
	 */
	public Integer getLoginFailureCount() {
		return loginFailureCount;
	}
	/**
	 * @param loginFailureCount the loginFailureCount to set
	 */
	public void setLoginFailureCount(Integer loginFailureCount) {
		this.loginFailureCount = loginFailureCount;
	}
	/**
	 * @return the minimumPasswordLength
	 */
	public Integer getMinimumPasswordLength() {
		return minimumPasswordLength;
	}
	/**
	 * @param minimumPasswordLength the minimumPasswordLength to set
	 */
	public void setMinimumPasswordLength(Integer minimumPasswordLength) {
		this.minimumPasswordLength = minimumPasswordLength;
	}
	/**
	 * @return the maximumPasswordLength
	 */
	public Integer getMaximumPasswordLength() {
		return maximumPasswordLength;
	}
	/**
	 * @param maximumPasswordLength the maximumPasswordLength to set
	 */
	public void setMaximumPasswordLength(Integer maximumPasswordLength) {
		this.maximumPasswordLength = maximumPasswordLength;
	}
	/**
	 * @return the hsmLabel
	 */
	public String getHsmLabel() {
		return hsmLabel;
	}
	/**
	 * @param hsmLabel the hsmLabel to set
	 */
	public void setHsmLabel(String hsmLabel) {
		this.hsmLabel = hsmLabel;
	}
	/**
	 * @return the hsmAuditLog
	 */
	public boolean isHsmAuditLog() {
		return hsmAuditLog;
	}
	/**
	 * @param hsmAuditLog the hsmAuditLog to set
	 */
	public void setHsmAuditLog(boolean hsmAuditLog) {
		this.hsmAuditLog = hsmAuditLog;
	}
	
}
