package com.cavium.rest.model.appliance;

import java.io.Serializable;
import java.util.List;

import com.cavium.model.appliance.DualFactorUsersRelationshipModel;
import com.cavium.model.partition.PartitionData;
import com.cavium.model.partition.monitor.MonitorData;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(value=Include.NON_NULL)
@JsonPropertyOrder({
    "applianceId",
    "applianceName",
    "serialNumber",
    "applianceStatus",
    "timezone",
    "network",
    "zone",
    "ipmi"
})
public class ApplianceModel implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6018853080649804082L;
	
	private Long applianceId;
	@JsonProperty(required = true)
	private String applianceName;
	private String serialNumber;
	private String authId;
	private String applianceStatus;
	private String cryptoOfficerName;
	private String cryptoOfficerPassword;
	private String type;
	@JsonProperty(access = Access.WRITE_ONLY)
	private Boolean forceZeroize;
	private Boolean credentialsSaved;
	private List<PartitionData> partitions;
	private Timezone dateTime;
	
	private Network network;
	
	private Ipmi ipmi;
	
	private Zone zone;
	private MonitorData monitorData;
	private DualFactorUsersRelationshipModel dualFactorDetails;
	private String fipsState;
	private Integer occupiedPartitions;
	private Integer totalAcclrDev;
	private Integer totalKeys;
	private Integer occupiedKeys;
	private Integer occupiedAcclrDev;
	private Integer totalPartitions;
	private Integer totalContexts;
	private Integer occupiedContexts;
	private String certificateAuthenticate;
	private String auditLogs;
	
	public Long getApplianceId() {
		return applianceId;
	}
	public void setApplianceId(Long applianceId) {
		this.applianceId = applianceId;
	}
	public String getApplianceName() {
		return applianceName;
	}
	public void setApplianceName(String applianceName) {
		this.applianceName = applianceName;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getApplianceStatus() {
		return applianceStatus;
	}
	public void setApplianceStatus(String applianceStatus) {
		this.applianceStatus = applianceStatus;
	}
	public String getCryptoOfficerName() {
		return cryptoOfficerName;
	}
	public void setCryptoOfficerName(String cryptoOfficerName) {
		this.cryptoOfficerName = cryptoOfficerName;
	}
	public String getCryptoOfficerPassword() {
		return cryptoOfficerPassword;
	}
	public void setCryptoOfficerPassword(String cryptoOfficerPassword) {
		this.cryptoOfficerPassword = cryptoOfficerPassword;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	public Timezone getDateTime() {
		return dateTime;
	}
	public void setDateTime(Timezone dateTime) {
		this.dateTime = dateTime;
	}
	public Network getNetwork() {
		return network;
	}
	public void setNetwork(Network network) {
		this.network = network;
	}
	public Ipmi getIpmi() {
		return ipmi;
	}
	public void setIpmi(Ipmi ipmi) {
		this.ipmi = ipmi;
	}
	public Zone getZone() {
		return zone;
	}
	public void setZone(Zone zone) {
		this.zone = zone;
	}
	public String getAuthId() {
		return authId;
	}
	public void setAuthId(String authId) {
		this.authId = authId;
	}
	 
	public MonitorData getMonitorData() {
		return monitorData;
	}
	public void setMonitorData(MonitorData monitorData) {
		this.monitorData = monitorData;
	}
	public DualFactorUsersRelationshipModel getDualFactorDetails() {
		return dualFactorDetails;
	}
	public void setDualFactorDetails(DualFactorUsersRelationshipModel dualFactorDetails) {
		this.dualFactorDetails = dualFactorDetails;
	}
	 
	public String getFipsState() {
		return fipsState;
	}
	public void setFipsState(String fipsState) {
		this.fipsState = fipsState;
	}
	 
	/**
	 * @return the partitions
	 */
	public List<PartitionData> getPartitions() {
		return partitions;
	}
	/**
	 * @param partitions the partitions to set
	 */
	public void setPartitions(List<PartitionData> partitions) {
		this.partitions = partitions;
	}
	/**
	 * @return the occupiedPartitions
	 */
	public Integer getOccupiedPartitions() {
		return occupiedPartitions;
	}
	/**
	 * @param occupiedPartitions the occupiedPartitions to set
	 */
	public void setOccupiedPartitions(Integer occupiedPartitions) {
		this.occupiedPartitions = occupiedPartitions;
	}
	/**
	 * @return the totalAcclrDev
	 */
	public Integer getTotalAcclrDev() {
		return totalAcclrDev;
	}
	/**
	 * @param totalAcclrDev the totalAcclrDev to set
	 */
	public void setTotalAcclrDev(Integer totalAcclrDev) {
		this.totalAcclrDev = totalAcclrDev;
	}
	/**
	 * @return the totalKeys
	 */
	public Integer getTotalKeys() {
		return totalKeys;
	}
	/**
	 * @param totalKeys the totalKeys to set
	 */
	public void setTotalKeys(Integer totalKeys) {
		this.totalKeys = totalKeys;
	}
	/**
	 * @return the occupiedKeys
	 */
	public Integer getOccupiedKeys() {
		return occupiedKeys;
	}
	/**
	 * @param occupiedKeys the occupiedKeys to set
	 */
	public void setOccupiedKeys(Integer occupiedKeys) {
		this.occupiedKeys = occupiedKeys;
	}
	/**
	 * @return the occupiedAcclrDev
	 */
	public Integer getOccupiedAcclrDev() {
		return occupiedAcclrDev;
	}
	/**
	 * @param occupiedAcclrDev the occupiedAcclrDev to set
	 */
	public void setOccupiedAcclrDev(Integer occupiedAcclrDev) {
		this.occupiedAcclrDev = occupiedAcclrDev;
	}
	/**
	 * @return the totalPartitions
	 */
	public Integer getTotalPartitions() {
		return totalPartitions;
	}
	/**
	 * @param totalPartitions the totalPartitions to set
	 */
	public void setTotalPartitions(Integer totalPartitions) {
		this.totalPartitions = totalPartitions;
	}
	/**
	 * @return the totalContexts
	 */
	public Integer getTotalContexts() {
		return totalContexts;
	}
	/**
	 * @param totalContexts the totalContexts to set
	 */
	public void setTotalContexts(Integer totalContexts) {
		this.totalContexts = totalContexts;
	}
	/**
	 * @return the occupiedContexts
	 */
	public Integer getOccupiedContexts() {
		return occupiedContexts;
	}
	/**
	 * @param occupiedContexts the occupiedContexts to set
	 */
	public void setOccupiedContexts(Integer occupiedContexts) {
		this.occupiedContexts = occupiedContexts;
	}
	/**
	 * @return the certificateAuthenticate
	 */
	public String getCertificateAuthenticate() {
		return certificateAuthenticate;
	}
	/**
	 * @param certificateAuthenticate the certificateAuthenticate to set
	 */
	public void setCertificateAuthenticate(String certificateAuthenticate) {
		this.certificateAuthenticate = certificateAuthenticate;
	}
	/**
	 * @return the auditLogs
	 */
	public String getAuditLogs() {
		return auditLogs;
	}
	/**
	 * @param auditLogs the auditLogs to set
	 */
	public void setAuditLogs(String auditLogs) {
		this.auditLogs = auditLogs;
	}
	/**
	 * @return the forceZeroize
	 */
	public Boolean getForceZeroize() {
		return forceZeroize;
	}
	/**
	 * @param forceZeroize the forceZeroize to set
	 */
	public void setForceZeroize(Boolean forceZeroize) {
		this.forceZeroize = forceZeroize;
	}
	/**
	 * @return the credentialsSaved
	 */
	public Boolean getCredentialsSaved() {
		return credentialsSaved;
	}
	/**
	 * @param credentialsSaved the credentialsSaved to set
	 */
	public void setCredentialsSaved(Boolean credentialsSaved) {
		this.credentialsSaved = credentialsSaved;
	}
	
}
