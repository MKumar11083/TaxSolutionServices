package com.cavium.rest.model.appliance;

import java.io.Serializable;

import com.cavium.model.appliance.DualFactorUsersRelationshipModel;

 
public class InitializeApplianceModel implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer applianceId;
	private String username;	 
	private String password;
	private InitData initData;
	private DualFactorUsersRelationshipModel dualFactorDetails;	
	private boolean credentialSaved;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public InitData getInitData() {
		return initData;
	}
	public void setInitData(InitData initData) {
		this.initData = initData;
	}
	public boolean isCredentialSaved() {
		return credentialSaved;
	}
	public void setCredentialSaved(boolean credentialSaved) {
		this.credentialSaved = credentialSaved;
	}
	public Integer getApplianceId() {
		return applianceId;
	}
	public void setApplianceId(Integer applianceId) {
		this.applianceId = applianceId;
	}
	public DualFactorUsersRelationshipModel getDualFactorDetails() {
		return dualFactorDetails;
	}
	public void setDualFactorDetails(DualFactorUsersRelationshipModel dualFactorDetails) {
		this.dualFactorDetails = dualFactorDetails;
	}
	
}
