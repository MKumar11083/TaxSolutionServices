package com.cavium.rest.service.appliance;

import com.cavium.model.appliance.DualFactorUsersRelationshipModel;

public interface ApplianceManagementService  {

	public String getHSMDetail(String applianceIp);
	public DualFactorUsersRelationshipModel saveDualFactorDetails(DualFactorUsersRelationshipModel dualFactorDetails);
}
