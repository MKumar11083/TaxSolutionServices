package com.cavium.rest.controller.hostadminvm;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.pojo.ApplianceInfo;
import com.cavium.pojo.hostadminvm.HostStats;
import com.cavium.repository.appliance.ApplianceRepository;
import com.cavium.rest.common.utill.Response;
import com.cavium.rest.model.appliance.ApplianceModel;
import com.cavium.service.appliance.ApplianceService;
import com.cavium.service.hostadminvm.HostAdminVMService;
import com.cavium.utill.CaviumResponseModel;
import com.cavium.utill.CaviumUtil;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

@RestController
@RequestMapping("rest")
public class HostManagementController {

	@Autowired
	private HostAdminVMService hostAdminVMService;

	@Lookup
	public CaviumResponseModel getCaviumResponseModel() {
		return null;
	}

	@Autowired
	private ApplianceService applianceService;

	@Lookup
	public HostStats getHostStats() {
		return null;
	}

	@Autowired
	private ApplianceRepository applianceRepository;
	
	@Lookup
	public ApplianceInfo getApplianceInfo() {
		return null;
	}

	private Logger logger = Logger.getLogger(this.getClass());
 
	 
	@RequestMapping(value = "getHostStatsDetails", method = RequestMethod.POST)
	public List<HostStats> getHostStatsDetails(@RequestBody List<ApplianceModel> appModels){
		logger.info("start of getHostSystemInfo Method");
		String apiName="admin_host_stats";
		List<HostStats> reponseList= new ArrayList<HostStats>();
		try{
			for(ApplianceModel appModel:appModels){
			if(appModel.getNetwork()!=null && !StringUtils.isEmpty(appModel.getNetwork().getIpAddress())){
				if(CaviumUtil.validateIPAddress(appModel.getNetwork().getIpAddress())){
					ApplianceDetailModel applianceDetailModel= new ApplianceDetailModel();
					applianceDetailModel.setIpAddress(appModel.getNetwork().getIpAddress());
					 HostStats hostStats=hostAdminVMService.GetHostAdminVMStats(applianceDetailModel,getHostStats(),apiName);
					 hostStats.setApplianceIp(appModel.getNetwork().getIpAddress());
					 hostStats.setCode("200");
					 reponseList.add(hostStats);
				}else{
					HostStats hostStats=getHostStats();
					hostStats.setCode("408");
					hostStats.setStatus("failed");
					hostStats.setMessage("ApplianceIp is  not Valid");
					hostStats.setApplianceIp(appModel.getNetwork().getIpAddress());;
					reponseList.add(hostStats);
				}
			}else{
				HostStats hostStats=getHostStats();
				hostStats.setMessage("ApplianceIp is required");
				hostStats.setCode("408");
				hostStats.setStatus("failed");
				reponseList.add(hostStats);
			}
		}
		}catch (Exception e) {
			logger.error("error while getHostStatsDetails ::"+e.getMessage());
		}
		 return reponseList;
	}

	@RequestMapping(value = "getApplianceInformation", method = RequestMethod.POST)
	public List<ApplianceInfo> getApplianceInformation(@RequestBody List<ApplianceModel> appModels){
		logger.info("start of getApplianceInformation Method");
		List<ApplianceInfo> reponseList= new ArrayList<ApplianceInfo>();
		try{
			for(ApplianceModel appModel:appModels){
			if(appModel.getNetwork()!=null && !StringUtils.isEmpty(appModel.getNetwork().getIpAddress())){
				if(CaviumUtil.validateIPAddress(appModel.getNetwork().getIpAddress())){
					ApplianceDetailModel applianceDetailModel= new ApplianceDetailModel();
					applianceDetailModel.setIpAddress(appModel.getNetwork().getIpAddress());
					ApplianceInfo	applianceInfo=applianceService.GetApplianceInfo(applianceDetailModel,getApplianceInfo());
					applianceInfo.setApplianceIp(appModel.getNetwork().getIpAddress());
					applianceInfo.setCode("200");
					 reponseList.add(applianceInfo);
				}else{
					ApplianceInfo applianceInfo=getApplianceInfo();
					applianceInfo.setCode("408");
					applianceInfo.setStatus("failed");
					applianceInfo.setMessage("ApplianceIp is  not Valid");
					applianceInfo.setApplianceIp(appModel.getNetwork().getIpAddress());;
					reponseList.add(applianceInfo);
				}
			}else{
				ApplianceInfo applianceInfo=getApplianceInfo();
				applianceInfo.setCode("408");
				applianceInfo.setStatus("failed");
				applianceInfo.setMessage("ApplianceIp is required");
				reponseList.add(applianceInfo);
			}
		}
		}catch (Exception e) {
			logger.error("error while getApplianceInformation ::"+e.getMessage());
		}
		logger.info("end of getApplianceInformation Method");
		 return reponseList;
	}

	
	@RequestMapping(value = "getHostMonitorStatsDetails", method = RequestMethod.POST, produces="application/json")
	public String getHostMonitorStatsDetails(@RequestBody List<ApplianceModel> appModels) {
		logger.info("Start of getHostMonitorStatsDetails Method");
		List<String> reponseList= new ArrayList<String>();
		for(ApplianceModel appModel:appModels){
			try{
			if(appModel.getNetwork()!=null && !StringUtils.isEmpty(appModel.getNetwork().getIpAddress())){
				if(CaviumUtil.validateIPAddress(appModel.getNetwork().getIpAddress())){
					ApplianceDetailModel applianceDetailModel= new ApplianceDetailModel();
					CaviumResponseModel	caviumResponse=getCaviumResponseModel();
					applianceDetailModel.setIpAddress(appModel.getNetwork().getIpAddress());
					caviumResponse =hostAdminVMService.hostMonitorStats(applianceDetailModel,"host");
					String response=caviumResponse.getResponseMessage();
					String code=caviumResponse.getResponseCode();
					ObjectMapper mapper = new ObjectMapper();
					if(response!=null && "200".equals(code)){
						JsonNode root = mapper.readTree(response);
						  if(!root.isNull()){
							  ((ObjectNode)root).put("applianceIp", appModel.getNetwork().getIpAddress());
							  response=root.toString();
						  }
							reponseList.add(response);
					 }else{
						 	JSONObject json= new JSONObject(); 
							json.put("status","failed");
							json.put("message",caviumResponse.getResponseMessage());
							json.put("code",caviumResponse.getResponseCode());
							json.put("applianceIp",appModel.getNetwork().getIpAddress());
							String failureResponse=json.toString();	
							reponseList.add(failureResponse); 
					 }
				
				}else{
					JSONObject json= new JSONObject(); 
					json.put("status","failed");
					json.put("message","ApplianceIp is  not Valid");
					json.put("code","408");
					json.put("applianceIp",appModel.getNetwork().getIpAddress());
					String failureResponse=json.toString();	
					reponseList.add(failureResponse);
				}
			}else{
				JSONObject json= new JSONObject(); 
				json.put("status","failed");
				json.put("message","ApplianceIp is required");
				json.put("code","408");
				String failureResponse=json.toString();
				reponseList.add(failureResponse);
			}
		}catch (Exception e) {
			logger.error("error while getHostMonitorStatsDetails :: "+e.getMessage());
		}
		}
		logger.info("end of getHostMonitorStatsDetails Method");
		return reponseList.toString();
	}
	
	@RequestMapping(value = "getHostSelfReportDetails", method = RequestMethod.POST, produces="application/json")
	public String getHostSelfReportDetails(@RequestBody List<ApplianceModel> appModels) {
		logger.info("Start of getHostMonitorStatsDetails Method");
		List<String> reponseList= new ArrayList<String>();
		for(ApplianceModel appModel:appModels){
			try{
			if(appModel.getNetwork()!=null && !StringUtils.isEmpty(appModel.getNetwork().getIpAddress())){
				if(CaviumUtil.validateIPAddress(appModel.getNetwork().getIpAddress())){
					ApplianceDetailModel applianceDetailModel= new ApplianceDetailModel();
					CaviumResponseModel	caviumResponse=getCaviumResponseModel();
					applianceDetailModel.setSelfReportType("host");
					applianceDetailModel.setIpAddress(appModel.getNetwork().getIpAddress());
					caviumResponse=applianceService.getSelfReportData(applianceDetailModel);
					String response=caviumResponse.getResponseMessage();
					String code=caviumResponse.getResponseCode();
					ObjectMapper mapper = new ObjectMapper();
					if(response!=null && "200".equals(code)){
						JsonNode root = mapper.readTree(response);
						  if(!root.isNull()){
							  ((ObjectNode)root).put("applianceIp", appModel.getNetwork().getIpAddress());
							  response=root.toString();
						  }
							reponseList.add(response);
					 }else{
						 	JSONObject json= new JSONObject(); 
							json.put("status","failed");
							json.put("message",caviumResponse.getResponseMessage());
							json.put("code",caviumResponse.getResponseCode());
							json.put("applianceIp",appModel.getNetwork().getIpAddress());
							String failureResponse=json.toString();	
							reponseList.add(failureResponse); 
					 }
				
				}else{
					JSONObject json= new JSONObject(); 
					json.put("status","failed");
					json.put("message","ApplianceIp is  not Valid");
					json.put("code","408");
					json.put("applianceIp",appModel.getNetwork().getIpAddress());
					String failureResponse=json.toString();	
					reponseList.add(failureResponse);
				}
			}else{
				JSONObject json= new JSONObject(); 
				json.put("status","failed");
				json.put("message","ApplianceIp is required");
				json.put("code","408");
				String failureResponse=json.toString();
				reponseList.add(failureResponse);
			}
		}catch (Exception e) {
			logger.error("error while getHostMonitorStatsDetails :: "+e.getMessage());
		}
		}
		logger.info("end of getHostMonitorStatsDetails Method");
		return reponseList.toString();
	}
	
	
	@RequestMapping(value = "getApplianceHostAdminMonitorData", method = RequestMethod.POST)
	public final List<Response> getApplianceHostAdminMonitorData(@RequestBody List<ApplianceModel> models) {
		List<Response> newListOfResponse=new ArrayList<>();
		try {
			
			List<ApplianceDetailModel> listApplianceDetailModels=new ArrayList<>();
			for(ApplianceModel model: models) {
				if(model.getNetwork()!=null && !StringUtils.isEmpty(model.getNetwork().getIpAddress()) && model.getType()!=null) {
					List<ApplianceDetailModel> listApp=applianceRepository.getApplianceExists(model.getNetwork().getIpAddress());
					if(listApp!=null && listApp.size() > 0) {
						ApplianceDetailModel appdb=(ApplianceDetailModel)listApp.get(0);
						ApplianceDetailModel app=new ApplianceDetailModel();
						app.setApplianceId(appdb.getApplianceId());
						app.setMonitorType(model.getType());
						app.setIpAddress(model.getNetwork().getIpAddress());
						listApplianceDetailModels.add(app);
					}else {
						Response response=new Response();
						response.setStatus("Failed");
						response.setCode("400");
						response.setMessage("Appliance does not exists.");
						newListOfResponse.add(response);
					}
				}else {
					Response response=new Response();
					response.setStatus("Failed");
					response.setCode("400");
					StringBuilder sb=new StringBuilder();
					if(model.getNetwork()==null || StringUtils.isEmpty(model.getNetwork().getIpAddress())) {
						sb.append("Ip is required");
					}
					if(model.getType()==null) {
						if(sb.length()!=0) {
							sb.append(",");
						}
						sb.append("Type is required.");
					}
					response.setMessage(sb.toString()+".");
					newListOfResponse.add(response);
				}
			}
			
			if(listApplianceDetailModels!=null && listApplianceDetailModels.size() > 0) {
				listApplianceDetailModels=applianceService.getMonitorData(listApplianceDetailModels);
				
				for(ApplianceDetailModel app: listApplianceDetailModels) {
					Response response=new Response();
					response.setApplianceIp(app.getIpAddress());
					if(app.getMonitorData()!=null) {
						response.setStatus("success");
						response.setCode("200");
						List<Object> monitor=new ArrayList<>();
						monitor.add(app.getMonitorData());
						response.setData(monitor);
					}else {
						response.setStatus("Failed");
						response.setCode(app.getCode());
						response.setMessage(app.getErrorMessage());
					}
					newListOfResponse.add(response);
				}
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during get monitor data"+e.getMessage());
		}
		return newListOfResponse;
	}
	
	
	@RequestMapping(value = "setApplianceHostAdminMonitorData", method = RequestMethod.POST)
	public final List<Response> setApplianceHostAdminMonitorData(@RequestBody List<ApplianceModel> models) {
		List<Response> newList=new ArrayList<>();
		try {
			List<ApplianceDetailModel> listApplianceDetailModels=new ArrayList<>();
			for(ApplianceModel model: models) {
				if(model.getNetwork()!=null && !StringUtils.isEmpty(model.getNetwork().getIpAddress()) && model.getMonitorData()!=null && model.getType()!=null) {
					List<ApplianceDetailModel> listApp=applianceRepository.getApplianceExists(model.getNetwork().getIpAddress());
					if(listApp!=null && listApp.size() > 0) {
						StringBuilder sb=new StringBuilder();
						ApplianceDetailModel appdb=(ApplianceDetailModel)listApp.get(0);
						ApplianceDetailModel app=new ApplianceDetailModel();
						if(!StringUtils.isEmpty(model.getCryptoOfficerName())) {
							app.setOperationUsername(model.getCryptoOfficerName());
						}else {
							sb.append("cryptoOfficerName is required");
						}if(!StringUtils.isEmpty(model.getCryptoOfficerPassword())) {
							app.setOperationPassword(model.getCryptoOfficerPassword());
						}else {
							if(sb.length()!=0) {
								sb.append(",");
							}
							sb.append("cryptoOfficerPassword is required");
						}
						if(sb.length()==0) {
							app.setApplianceId(appdb.getApplianceId());
							app.setMonitorType(model.getType());
							app.setMonitorData(model.getMonitorData());
							app.setIpAddress(model.getNetwork().getIpAddress());
							listApplianceDetailModels.add(app);
						}else {
							Response response=new Response();
							response.setStatus("Failed");
							response.setCode("400");
							response.setMessage(sb.toString()+".");
							newList.add(response);
						}
					}else {
						Response response=new Response();
						response.setStatus("Failed");
						response.setCode("400");
						response.setMessage("Appliance does not exists.");
						newList.add(response);
					}
				}else {
					Response response=new Response();
					response.setStatus("Failed");
					response.setCode("400");
					StringBuilder sb=new StringBuilder();
					if(model.getNetwork()==null || StringUtils.isEmpty(model.getNetwork().getIpAddress())) {
						sb.append("Ip is required");
					}
					
					if(StringUtils.isEmpty(model.getMonitorData())) {
						if(sb.length()!=0) {
							sb.append(",");
						}
						sb.append("MonitorData is required.");
					}
					
					if(model.getType()==null) {
						if(sb.length()!=0) {
							sb.append(",");
						}
						sb.append("Type is required.");
					}
					response.setMessage(sb.toString()+".");
					newList.add(response);
				}
			}
			
			if(listApplianceDetailModels!=null && listApplianceDetailModels.size() > 0) {
				listApplianceDetailModels=applianceService.setMonitorData(listApplianceDetailModels);
				for(ApplianceDetailModel app: listApplianceDetailModels) {
					Response model=new Response();
					model.setId(app.getApplianceId());
					model.setApplianceIp(app.getIpAddress());
					if(!StringUtils.isEmpty(app.getCode()) && app.getCode().equalsIgnoreCase("200")) {
						model.setStatus("success");
						model.setMessage(app.getMessage());
					}else {
						model.setStatus("Failed");
						model.setMessage(app.getErrorMessage());
					}
					newList.add(model);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during set monitor data"+e.getMessage());
		}
		return newList;
	}
}
