package com.cavium.rest.controller.hostadminvm;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.core.env.Environment;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.appliance.InitializeAppliancesRelationshipModel;
import com.cavium.pojo.ApplianceInfo;
import com.cavium.pojo.HSMInfo;
import com.cavium.pojo.HostSelfTestReport;
import com.cavium.pojo.PartitionsDetails;
import com.cavium.pojo.hostadminvm.AdminSNMPConfig;
import com.cavium.pojo.hostadminvm.AdminVMConfig;
import com.cavium.pojo.hostadminvm.AdminVMData;
import com.cavium.pojo.hostadminvm.HostStats;
import com.cavium.pojo.hostadminvm.HostSystemInfo;
import com.cavium.pojo.hostadminvm.StaticIpToHostConfig;
import com.cavium.repository.appliance.ApplianceRepository;
import com.cavium.repository.appliance.InitializeAppliancesRelationshipReposiotry;
import com.cavium.rest.common.utill.Response;
import com.cavium.rest.model.appliance.ApplianceModel;
import com.cavium.service.appliance.ApplianceService;
import com.cavium.service.hostadminvm.HostAdminVMService;
import com.cavium.utill.CaviumResponseModel;
import com.cavium.utill.CaviumUtil;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

@RestController
@RequestMapping("rest")
public class AdminVMManagementController {

	@Autowired
	private ApplianceService applianceService;

	@Autowired
	private HostAdminVMService hostAdminVMService;

	@Autowired
	private ApplianceRepository applianceRepository;
	
	@Autowired
	Environment env;

	@Autowired
	private InitializeAppliancesRelationshipReposiotry initializeAppliancesRelationshipReposiotry;
	@Lookup
	public HostStats getHostStats() {
		return null;
	}
	@Lookup
	public CaviumResponseModel getCaviumResponseModel() {
		return null;
	}

	@Lookup
	public HostSelfTestReport getHostSelfTestReport() {
		return null;
	}

	@Lookup
	public AdminVMConfig getAdminVMConfig() {
		return null;
	}
	private Logger logger = Logger.getLogger(this.getClass());




	@RequestMapping(value = "getAdminStatsDetails", method = RequestMethod.POST)
	public List<HostStats> getAdminStatsDetails(@RequestBody List<ApplianceModel> appModels){
		logger.info("start of getAdminStatsDetails Method");
		String apiName="admin_vm_stats";
		List<HostStats> reponseList= new ArrayList<HostStats>();
		try{
			for(ApplianceModel appModel:appModels){
				if(appModel.getNetwork()!=null && !StringUtils.isEmpty(appModel.getNetwork().getIpAddress())){
					if(CaviumUtil.validateIPAddress(appModel.getNetwork().getIpAddress())){
						ApplianceDetailModel applianceDetailModel= new ApplianceDetailModel();
						applianceDetailModel.setIpAddress(appModel.getNetwork().getIpAddress());
						HostStats hostStats=hostAdminVMService.GetHostAdminVMStats(applianceDetailModel,getHostStats(),apiName);
						hostStats.setApplianceIp(appModel.getNetwork().getIpAddress());
						hostStats.setCode("200");
						reponseList.add(hostStats);
					}else{
						HostStats hostStats=getHostStats();
						hostStats.setCode("408");
						hostStats.setStatus("failed");
						hostStats.setMessage("ApplianceIp is  not Valid");
						hostStats.setApplianceIp(appModel.getNetwork().getIpAddress());;
						reponseList.add(hostStats);
					}
				}else{
					HostStats hostStats=getHostStats();
					hostStats.setMessage("ApplianceIp is required");
					hostStats.setCode("408");
					hostStats.setStatus("failed");
					reponseList.add(hostStats);
				}
			}
		}catch (Exception e) {
			logger.error("error while getAdminStatsDetails ::"+e.getMessage());
		}
		return reponseList;
	}

	@RequestMapping(value = "getAdminMonitorStatsDetails", method = RequestMethod.POST, produces="application/json")
	public String getAdminMonitorStatsDetails(@RequestBody List<ApplianceModel> appModels) {
		logger.info("Start of getAdminMonitorStatsDetails Method");
		List<String> reponseList= new ArrayList<String>();
		for(ApplianceModel appModel:appModels){
			try{
				if(appModel.getNetwork()!=null && !StringUtils.isEmpty(appModel.getNetwork().getIpAddress())){
					if(CaviumUtil.validateIPAddress(appModel.getNetwork().getIpAddress())){
						ApplianceDetailModel applianceDetailModel= new ApplianceDetailModel();
						CaviumResponseModel	caviumResponse=getCaviumResponseModel();
						applianceDetailModel.setIpAddress(appModel.getNetwork().getIpAddress());
						caviumResponse =hostAdminVMService.hostMonitorStats(applianceDetailModel,"admin");
						String response=caviumResponse.getResponseMessage();
						String code=caviumResponse.getResponseCode();
						ObjectMapper mapper = new ObjectMapper();
						if(response!=null && "200".equals(code)){
							JsonNode root = mapper.readTree(response);
							if(!root.isNull()){
								((ObjectNode)root).put("applianceIp", appModel.getNetwork().getIpAddress());
								response=root.toString();
							}
							reponseList.add(response);
						}else{
							JSONObject json= new JSONObject(); 
							json.put("status","failed");
							json.put("message",caviumResponse.getResponseMessage());
							json.put("code",caviumResponse.getResponseCode());
							json.put("applianceIp",appModel.getNetwork().getIpAddress());
							String failureResponse=json.toString();	
							reponseList.add(failureResponse); 
						}

					}else{
						JSONObject json= new JSONObject(); 
						json.put("status","failed");
						json.put("message","ApplianceIp is  not Valid");
						json.put("code","408");
						json.put("applianceIp",appModel.getNetwork().getIpAddress());
						String failureResponse=json.toString();	
						reponseList.add(failureResponse);
					}
				}else{
					JSONObject json= new JSONObject(); 
					json.put("status","failed");
					json.put("message","ApplianceIp is required");
					json.put("code","408");
					String failureResponse=json.toString();
					reponseList.add(failureResponse);
				}
			}catch (Exception e) {
				logger.error("error while getAdminMonitorStatsDetails :: "+e.getMessage());
			}
		}
		logger.info("end of getAdminMonitorStatsDetails Method");
		return reponseList.toString();
	}


	@RequestMapping(value = "getAdminSelfReportDetails", method = RequestMethod.POST, produces="application/json")
	public String getAdminSelfReportDetails(@RequestBody List<ApplianceModel> appModels) {
		logger.info("Start of getAdminSelfReportDetails Method");
		List<String> reponseList= new ArrayList<String>();
		for(ApplianceModel appModel:appModels){
			try{
				if(appModel.getNetwork()!=null && !StringUtils.isEmpty(appModel.getNetwork().getIpAddress())){
					if(CaviumUtil.validateIPAddress(appModel.getNetwork().getIpAddress())){
						ApplianceDetailModel applianceDetailModel= new ApplianceDetailModel();
						CaviumResponseModel	caviumResponse=getCaviumResponseModel();
						applianceDetailModel.setSelfReportType("admin");
						applianceDetailModel.setIpAddress(appModel.getNetwork().getIpAddress());	
						applianceDetailModel.setAuthId("thirdParty");
						caviumResponse=applianceService.getSelfReportData(applianceDetailModel);
						String response=caviumResponse.getResponseMessage();
						String code=caviumResponse.getResponseCode();
						ObjectMapper mapper = new ObjectMapper();
						if(response!=null && "200".equals(code)){
							JsonNode root = mapper.readTree(response);
							if(!root.isNull()){
								((ObjectNode)root).put("applianceIp", appModel.getNetwork().getIpAddress());
								((ObjectNode)root).put("code",code);
								response=root.toString();
							}
							reponseList.add(response);
						}else{
							JSONObject json= new JSONObject(); 
							json.put("status","failed");
							json.put("message",caviumResponse.getResponseMessage());
							json.put("code",caviumResponse.getResponseCode());
							json.put("applianceIp",appModel.getNetwork().getIpAddress());
							String failureResponse=json.toString();	
							reponseList.add(failureResponse); 
						}

					}else{
						JSONObject json= new JSONObject(); 
						json.put("status","failed");
						json.put("message","ApplianceIp is  not Valid");
						json.put("code","408");
						json.put("applianceIp",appModel.getNetwork().getIpAddress());
						String failureResponse=json.toString();	
						reponseList.add(failureResponse);
					}
				}else{
					JSONObject json= new JSONObject(); 
					json.put("status","failed");
					json.put("message","ApplianceIp is required");
					json.put("code","408");
					String failureResponse=json.toString();
					reponseList.add(failureResponse);
				}
			}catch (Exception e) {
				logger.error("error while getAdminSelfReportDetails :: "+e.getMessage());
			}
		}
		logger.info("end of getAdminSelfReportDetails Method");
		return reponseList.toString();
	}



	@RequestMapping(value = "setAdminVMNetworkConfig", method = RequestMethod.POST)
	public final List<Response> setAdminVMNetworkConfig(@RequestBody List<AdminVMData> adminVMDetails) {
		List<Response> responseList= new ArrayList<Response>();
		for(AdminVMData adminVMData : adminVMDetails)
		{
			String errorMessage="";
			Response res = new Response();	
			if(!StringUtils.isEmpty(adminVMData.getApplianceIp()) && CaviumUtil.validateIPAddress(adminVMData.getApplianceIp())){
				List<ApplianceDetailModel>  appModels = applianceRepository.getApplianceExists(adminVMData.getApplianceIp());
				if(appModels.size() > 0) {
					ApplianceDetailModel applianceDetail =appModels.get(0);
					adminVMData.setApplianceId(String.valueOf(applianceDetail.getApplianceId()));
					InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(applianceDetail.getApplianceId());
					if(initmodel!=null && applianceDetail.isCredentialSaved()){
						adminVMData.setUsername(CaviumUtil.decrypt(initmodel.getOperationPerformPassword()));
						adminVMData.setPassword(initmodel.getOperationPerformUserName());
					}
					  errorMessage=validateMandatoryFiledsForNetworkConfig(adminVMData);
					if(StringUtils.isEmpty(errorMessage)){
						CaviumResponseModel caviumResponseModel=getCaviumResponseModel();
						caviumResponseModel=hostAdminVMService.setHostNetorkVmConfig(adminVMData.getApplianceIp(),adminVMData);
						res.setApplianceIp(adminVMData.getApplianceIp());
						res.setCode(caviumResponseModel.getResponseCode());
						if("200".equals(caviumResponseModel.getResponseCode())){
						res.setStatus("success");
						}else{
							res.setStatus("failed");
						}
						res.setMessage(caviumResponseModel.getResponseMessage());
					}
					else{
						res.setStatus("failed");
						res.setCode("400");
						res.setMessage(errorMessage);	
						res.setApplianceIp(adminVMData.getApplianceIp());
					}
				}else{
					res.setStatus("failed");
					res.setCode("400");
					res.setMessage("ApplianceIp not exist");	
					res.setApplianceIp(adminVMData.getApplianceIp());
				}
			}else{
				if(StringUtils.isEmpty(adminVMData.getApplianceIp())){
					res.setMessage("ApplianceIp is required");
				}else{
					res.setMessage("ApplianceIp is not valid");
					res.setApplianceIp(adminVMData.getApplianceIp());
				}
				res.setStatus("failed");
				res.setCode("400");
			}
			responseList.add(res);
		}		
		return responseList;
	}
	
	
	@RequestMapping(value = "getAdminVMNetworkConfig", method = RequestMethod.POST)
	public List<AdminVMConfig> getAdminVMNetworkConfig(@RequestBody List<ApplianceModel> appModels){
		logger.info("start of getAdminNetworkInfo Method");
				 
		List<AdminVMConfig> adminVMConfigList= new ArrayList<AdminVMConfig>();
	  try{	
		for(ApplianceModel appModel:appModels){

			if(appModel.getNetwork()!=null && !StringUtils.isEmpty(appModel.getNetwork().getIpAddress())){
				if(CaviumUtil.validateIPAddress(appModel.getNetwork().getIpAddress())){
					List<ApplianceDetailModel>  applianceModel = applianceRepository.getApplianceExists(appModel.getNetwork().getIpAddress());
					if(applianceModel.size() > 0) {
					ApplianceDetailModel applianceDetailModel = new ApplianceDetailModel() ;
					applianceDetailModel.setIpAddress(appModel.getNetwork().getIpAddress());
					AdminVMConfig adminVMConfig=hostAdminVMService.GetAdminVMConfig(applianceDetailModel,getAdminVMConfig());
					if(adminVMConfig.getStatus()==null){
						adminVMConfig.setStatus("failed");
						adminVMConfig.setCode("408");
						adminVMConfig.setMessage(env.getProperty("appliance.connectionerror.cavium"));	
					 }else{
					adminVMConfig.setCode("200");
					}
					adminVMConfig.setApplianceIp(appModel.getNetwork().getIpAddress());
					adminVMConfigList.add(adminVMConfig);
					}else{
						AdminVMConfig adminVMConfig=getAdminVMConfig();
						adminVMConfig.setStatus("failed");
						adminVMConfig.setCode("408");
						adminVMConfig.setMessage("ApplianceIp not exist");	
						adminVMConfig.setApplianceIp(appModel.getNetwork().getIpAddress());
					}
				}else{
					AdminVMConfig adminVMConfig=getAdminVMConfig();
					adminVMConfig.setStatus("failed");
					adminVMConfig.setMessage("ApplianceIp is not valid.");
					adminVMConfig.setCode("408");
					adminVMConfig.setApplianceIp(appModel.getNetwork().getIpAddress());
					adminVMConfigList.add(adminVMConfig);
				}
			}else{
				AdminVMConfig adminVMConfig=getAdminVMConfig();
				adminVMConfig.setStatus("failed");
				adminVMConfig.setMessage("ApplianceIp is required.");
				adminVMConfig.setCode("408");
				adminVMConfig.setApplianceIp(appModel.getNetwork().getIpAddress());
				adminVMConfigList.add(adminVMConfig);
			}
		}
		}catch(Exception exp){
			logger.error("error while getAdminVMNetworkConfig ::"+exp.getMessage());
		}
	  logger.info("end of getAdminNetworkInfo Method");
		return adminVMConfigList;
	}
	
	private String validateMandatoryFiledsForNetworkConfig(AdminVMData adminVMData){
		String errorMessage="";
		if(adminVMData.getGeneral()==null){
			logger.info("General Tab required attributes are missing.");	
			errorMessage="General Tab required attributes are missing.";
			return errorMessage;
		}
		
		if(adminVMData.getGeneral().getDhcp()==null && adminVMData.getGeneral().getIp()==null)
		{
			logger.info("Both DHCP and IP Address are missing.");	
			errorMessage="Both DHCP and IP Address are missing.";
			return errorMessage;
		}
		else if((adminVMData.getGeneral().getDhcp()!=null && adminVMData.getGeneral().getDhcp()==true)  && (adminVMData.getGeneral().getIp()!=null)){
			logger.info("Enter either DHCP or IP Address");	
			errorMessage="Enter either DHCP or IP Address";
			return errorMessage;
		}
		else if((adminVMData.getGeneral().getDhcp()!=null && adminVMData.getGeneral().getDhcp()==false) && (adminVMData.getGeneral().getIp()==null)){
			logger.info("Both DHCP and IP Address are missing.");
			errorMessage="Both DHCP and IP Address are missing.";
			return errorMessage;
		}
		else if((adminVMData.getGeneral().getDhcp()!=null && adminVMData.getGeneral().getDhcp()==false))
			{
			if(adminVMData.getGeneral().getIp()!=null && !CaviumUtil.validateIPAddress(adminVMData.getGeneral().getIp())){
				logger.info("Ip Address is not Valid.");	
				errorMessage="Ip Address is not Valid.";
				return errorMessage;
			}
			if(adminVMData.getGeneral().getHostname()!=null && !CaviumUtil.validateHostName(adminVMData.getGeneral().getHostname())){
			
				logger.info("HostName is not valid.");	
				errorMessage="HostName is not valid.";
				return errorMessage;
				}
			
			if(adminVMData.getGeneral()!=null && adminVMData.getGeneral().getHostname()!=null && !CaviumUtil.validateIPAddress(adminVMData.getGeneral().getGateway())){
				logger.info("Gateway is not valid.");	
				errorMessage="Gateway is not valid.";
				return errorMessage;
		}
			if(adminVMData.getGeneral()!=null && adminVMData.getGeneral().getHostname()!=null && !CaviumUtil.validateIPAddress(adminVMData.getGeneral().getSubnet())){
				logger.info("SubnetMask  is not valid.");	
				errorMessage="SubnetMask is not valid.";
				return errorMessage;				
			}
		 }
		else if((adminVMData.getGeneral().getMacStatic()!=null && adminVMData.getGeneral().getMacStatic()==true) && (adminVMData.getGeneral().getMacAddress()==null)){
			logger.info("You selected Static MAC. MacAddress is required for Static MAC.");		
			errorMessage="You selected Static MAC. MacAddress is required for Static MAC";
			return errorMessage;
		}
		else if((adminVMData.getGeneral().getMacStatic()!=null && adminVMData.getGeneral().getMacStatic()==true) && (adminVMData.getGeneral().getMacAddress()!=null)){
		 if(!CaviumUtil.validateMACAddress(adminVMData.getGeneral().getMacAddress()))
		 {
			errorMessage="MacAddress is not Valid";
			return errorMessage;
		}
		else if((adminVMData.getGeneral().getMacStatic()!=null && adminVMData.getGeneral().getMacStatic()==false) && (adminVMData.getGeneral().getMacAddress()!=null)){
			logger.info("You don't selected Static MAC so MacAddress is not required.");
			errorMessage="You don't selected Static MAC so MacAddress is not required.";
			return errorMessage;
		}
		else if( adminVMData.getAdvanced()!=null && (adminVMData.getAdvanced().getEnableDNSService()!=null && adminVMData.getAdvanced().getEnableDNSService()==false) && (adminVMData.getAdvanced().getSearchDomainNames()!=null || adminVMData.getAdvanced().getDnsServers()!=null)){
			logger.info("You don't selected DNS Service Enabled so SearchDomain and DNS ServerName is not required.");	
			errorMessage="You don't selected DNS Service Enabled so SearchDomain and DNS ServerName is not required.";
			return errorMessage;
		}else{
			if(adminVMData.getAdvanced()!=null && adminVMData.getAdvanced().getSearchDomainNames()!=null)
			{
				StringBuilder domainNames= new StringBuilder();
				int count=0;
				for( String domainName:adminVMData.getAdvanced().getSearchDomainNames())
				{
					if(!CaviumUtil.validateDomainName(domainName))
					{
						count=count+1;
						domainNames=domainNames.append(domainName);
					}
				}
				if(count==1){
				logger.info("Domain Name is not valid :: "+String.valueOf(domainNames));	
				errorMessage="Domain Name is not valid :: "+String.valueOf(domainNames);
				return errorMessage;
				}
				if(count>1){
					logger.info("Domain Names are not valid :: "+String.valueOf(domainNames));	
					errorMessage="Domain Names are not valid :: "+String.valueOf(domainNames);
					return errorMessage;
				}
		}
				if(adminVMData.getAdvanced()!=null && adminVMData.getAdvanced().getDnsServers()!=null)
				{
					StringBuilder dnsServers= new StringBuilder();
					int count=0;
					for( String dnsServer:adminVMData.getAdvanced().getDnsServers())
					{
						if(!CaviumUtil.validateIPAddress(dnsServer))
						{
							dnsServers=dnsServers.append(dnsServer);
							count=count+1;
						}						
				}
					if(count==1){
						logger.info("DnsServer is not Valid :: "+String.valueOf(dnsServers));	
						errorMessage="DnsServer is not Valid :: "+String.valueOf(dnsServers);
						return errorMessage;
						}
						if(count>1){
							logger.info("DnsServers are not Valid :: "+String.valueOf(dnsServers));	
							errorMessage="DnsServers are not Valid :: "+String.valueOf(dnsServers);
							return errorMessage;
						}
					
			}
				if(adminVMData.getAdvanced()!=null && adminVMData.getAdvanced().getRemovedHostIPs()!=null)
				{
					StringBuilder removedIps= new StringBuilder();
					int count=0;
					for( String removedIp:adminVMData.getAdvanced().getRemovedHostIPs())
					{
						if(!CaviumUtil.validateIPAddress(removedIp))
						{
							removedIps=removedIps.append(removedIp);
							count=count+1;							
						}
					}
					if(count==1){
						logger.info("Removed Ip is not Valid :: "+String.valueOf(removedIps));	
						errorMessage="Removed Ip is not Valid :: "+String.valueOf(removedIps);
						return errorMessage;
						}
						if(count>1){
							logger.info("Removed Ips are not Valid :: "+String.valueOf(removedIps));	
							errorMessage="Removed Ips are not Valid :: "+String.valueOf(removedIps);
							return errorMessage;
						}					
			}
				if(adminVMData.getAdvanced()!=null && adminVMData.getAdvanced().getStaticIpToHostConfig()!=null)
				{
					StringBuilder StatishostIps= new StringBuilder();
					int ipCount=0;
					int hostNamecount=0;
					StringBuilder StatishostNames= new StringBuilder();
					for( StaticIpToHostConfig staticIpToHostConfig:adminVMData.getAdvanced().getStaticIpToHostConfig())
					{
						if(staticIpToHostConfig.getIp()!=null && !CaviumUtil.validateIPAddress(staticIpToHostConfig.getIp()))
						{
							ipCount=ipCount+1;
							StatishostIps.append(staticIpToHostConfig.getIp());
							
						}
						if(staticIpToHostConfig.getHostname()!=null && !CaviumUtil.validateHostName(staticIpToHostConfig.getHostname()))
						{
							hostNamecount=hostNamecount+1;
							StatishostNames.append(staticIpToHostConfig.getHostname());	
						}
				}
					if(ipCount==1){
						logger.info("Static Host IpAddress is not Valid :: "+String.valueOf(StatishostIps));	
						errorMessage="Static Host IpAddress are not Valid :: "+String.valueOf(StatishostIps);
						return errorMessage;
					}
					if(ipCount>1){
							logger.info("Static Host IpAddress are not Valid  :: "+String.valueOf(StatishostIps));	
							errorMessage="Static Host IpAddress are not Valid  :: "+String.valueOf(StatishostIps);
							return errorMessage;
						}
					if(hostNamecount==1){
						logger.info("Static Host Name is not Valid :: "+String.valueOf(StatishostNames));	
						errorMessage="Static Host Name are not Valid :: "+String.valueOf(StatishostNames);
						return errorMessage;
					}
					if(hostNamecount>1){
							logger.info("Static Host Names are not Valid  :: "+String.valueOf(StatishostNames));	
							errorMessage="Static Host Names are not Valid  :: "+String.valueOf(StatishostNames);
							return errorMessage;
						}					 
			}
		}
		}
		return errorMessage;
	}
}
