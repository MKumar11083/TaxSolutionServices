drop table designation_role;

update user_details set acl_id=null;
update user_details set role=null;
delete from acl_role;
delete from acl_details;
delete from permission;
delete from application;
delete from designation;
delete from user_details;

alter table designation drop column oldPermIds;
alter table designation drop column password;
alter table designation drop column permIds;
alter table permission drop column permission_id;

alter table user_details drop column bulk_Max_Active_Session;
alter table user_details drop column max_active_sess;
alter table user_details drop column password_expiry;
alter table user_details drop column last_login;
alter table user_details drop column password_current_age;
alter table user_details drop column password_age_limit;
alter table user_details drop column failed_login_count;
alter table user_details drop column bulkStatus;
alter table user_details drop column bulk_status;

insert into application values('1','UGM','User&Group Management');
insert into application values('2','AM','Appliance Management');
insert into application values('3','PM','Partition Management');
insert into application values('4','CM','Cluster Management');
insert into application values('5','DM','Dashboard Management');

// Initial Data for USerManagement

insert into designation(descr,last_updated,user_id)values("DefaultUserGroup",sysdate(),"SuperAdmin");
insert into designation(descr,last_updated)values("DeletedUserGroup",sysdate());

insert into permission(id,short_permission,permission_description,app_id) values('1','ROLE_UM_CREATE_USER','Add New User','1');
insert into permission(id,short_permission,permission_description,app_id) values('2','ROLE_UM_ADD_GROUP','Create UserGroup','1');
insert into permission(id,short_permission,permission_description,app_id) values('3','ROLE_UM_REMOVE_GROUP','Remove userGroup','1');
insert into permission(id,short_permission,permission_description,app_id) values('4','ROLE_UM_ADD_APPLIANCES','Add Appliances','2');
insert into permission(id,short_permission,permission_description,app_id) values('5','ROLE_UM_LIST_APPLIANCES','LIST APPLIANCES','2');
insert into permission(id,short_permission,permission_description,app_id) values('6','ROLE_UM_EDIT_APPLIANCES','EDIT Appliances','2');
insert into permission(id,short_permission,permission_description,app_id) values('7','ROLE_UM_VIEW_PARTITION_INFO','View Partition Info','3');
insert into permission(id,short_permission,permission_description,app_id) values('8','ROLE_UM_LIST_PARTITION','LIST_PARTITION','3');
insert into permission(id,short_permission,permission_description,app_id) values('9','ROLE_UM_PARTITION_LEVEL_OPEARTION_ACCESS','Partition Level Operation Access','3');
insert into permission(id,short_permission,permission_description,app_id) values('10','ROLE_UM_CREATE_CLUSTER','Create Cluster','4');
insert into permission(id,short_permission,permission_description,app_id) values('11','ROLE_UM_LIST_CLUSTER','List Cluster','4');
insert into permission(id,short_permission,permission_description,app_id) values('12','ROLE_UM_REMOVE_CLUSTER','Remove Cluster','4');
insert into permission(id,short_permission,permission_description,app_id) values('13','ROLE_UM_LIST_USER','List User','1');
insert into permission(id,short_permission,permission_description,app_id) values('14','ROLE_UM_REMOVE_USER','Delete User','1');
insert into permission(id,short_permission,permission_description,app_id) values('15','ROLE_UM_EDIT_USER','Edit User','1');
insert into permission(id,short_permission,permission_description,app_id) values('16','ROLE_UM_EDIT_GROUP','Edit UserGroup','1');
insert into permission(id,short_permission,permission_description,app_id) values('17','ROLE_UM_LIST_GROUP','List UserGroup','1');
insert into permission(id,short_permission,permission_description,app_id) values('18','ROLE_UM_REMOVE_APPLIANCES','Remove Appliances','2');
insert into permission(id,short_permission,permission_description,app_id) values('19','ROLE_UM_REMOVE_CLUSTER','Remove Cluster','2');
insert into permission(id,short_permission,permission_description,app_id) values('20','ROLE_UM_CREATE_PARTITION','Create Partition','3');
insert into permission(id,short_permission,permission_description,app_id) values('21','ROLE_UM_REMOVE_PARTITION','Remove Partition','3');
insert into permission(id,short_permission,permission_description,app_id) values('22','ROLE_UM_APPLIANCE_MANAGEMENT','Show Appliance Management Menu','3');
insert into permission(id,short_permission,permission_description,app_id) values('23','ROLE_UM_USER_MANAGEMENT','Show User and Group Management Menu','1');
insert into permission(id,short_permission,permission_description,app_id) values('24','ROLE_UM_DASHBOARD_GROUP_WISE_APPLIANCE','GROUP WISE APPLIANCES','5');
insert into permission(id,short_permission,permission_description,app_id) values('25','ROLE_UM_DASHBOARD_PARTITION_WISE_APPLIANCE','PARTITION WISE APPLIANCES','5');
insert into permission(id,short_permission,permission_description,app_id) values('26','ROLE_UM_DASHBOARD_USERS_GRAPH','USERS GRAPH','5');
insert into permission(id,short_permission,permission_description,app_id) values('27','ROLE_UM_DASHBOARD_RECENT_ACTIVITY','RECENT ACTIVITIES','5');
insert into permission(id,short_permission,permission_description,app_id) values('28','ROLE_UM_DASHBOARD_SYSTEM_INFO','SYSTEM INFO','5');
insert into permission(id,short_permission,permission_description,app_id) values('29','ROLE_UM_DASHBOARD_ALERTS','ALERTS','5');


insert into acl_details (descr,last_updated,user_id) values("MonitorUser",sysdate(),"SuperAdmin");
insert into acl_details (descr,last_updated,user_id) values("GroupAdmin ",sysdate(),"SuperAdmin");
insert into acl_details (descr,last_updated,user_id) values("SuperAdmin",sysdate(),"SuperAdmin");
insert into acl_details (descr,last_updated,user_id) values("SecondaryUser",sysdate(),"SuperAdmin");

insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SecondaryUser'),'1');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='MonitorUser'),'13');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='MonitorUser'),'8');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='MonitorUser'),'5');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='MonitorUser'),'7');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='GroupAdmin'),'1');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),'13');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),'8');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),'5');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),'7');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),'1');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),'2');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),'3');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),'4');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),'9');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),'6');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),'10');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),'11');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),'12');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),'14');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),'15');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),'16');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),'17');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),'18');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),'19');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),'20');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),'21');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),'22');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),'23');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SecondaryUser'),'22');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SecondaryUser'),'23');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='GroupAdmin'),'22');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='GroupAdmin'),'23');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='MonitorUser'),'22');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),'24');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),'25');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='GroupAdmin'),'25');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='MonitorUser'),'25');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),'26');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='GroupAdmin'),'26');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),'27');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='GroupAdmin'),'27');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='MonitorUser'),'27');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),'28');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='GroupAdmin'),'29');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='MonitorUser'),'29');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),'29');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='GroupAdmin'),'20');



// password for SuperAdmin User is SuperAdmin
insert into user_details (user_id,password,first_name,last_name,phone_number,status,email_id,temporary_password,role,acl_id) 
values('SuperAdmin','$2a$10$jOMmr/tX6FEmbhUVl40G5uwUTq1wHFjHef12fomLjra2.95f5YQg.','SuperAdmin','SuperAdmin','9873309499','ACTIVE','SuperAdmin@cavium.com','N',(select id from designation where descr='DefaultUserGroup'),(select id from acl_details where descr='SuperAdmin'));

delete from user_details where password_expiry=" ";

ALTER TABLE user_details
 ADD acl_id MEDIUMINT UNSIGNED;

 
 create table acl_role (
    ID MEDIUMINT UNSIGNED NOT NULL AUTO_INCREMENT,
	acl_id MEDIUMINT UNSIGNED,
	permission_id MEDIUMINT UNSIGNED,
    PRIMARY KEY (id)
);
 
 create table acl_details(
 id MEDIUMINT UNSIGNED NOT NULL AUTO_INCREMENT,
 descr varchar(255),
 last_updated datetime,
 user_id varchar(50),
 PRIMARY KEY (id)
 );

 
alter table user_details add column login_failure_count MEDIUMINT UNSIGNED default 0;