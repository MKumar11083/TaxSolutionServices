 create TABLE snmp_trap_recvr (
      snmp_id MEDIUMINT UNSIGNED NOT NULL AUTO_INCREMENT,    
      message_recvd MEDIUMTEXT NOT NULL,
      PRIMARY KEY (snmp_id)
      );