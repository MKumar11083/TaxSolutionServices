 alter table alerts add column appliance_id MEDIUMINT UNSIGNED,
 add column appliance_name varchar(100),
 add column appliance_ip varchar(100);
 

delete from user_details;
insert into user_details (user_id,password,first_name,last_name,phone_number,status,email_id,temporary_password,role,acl_id,created_by) 
values('SuperAdmin','$2a$10$jOMmr/tX6FEmbhUVl40G5uwUTq1wHFjHef12fomLjra2.95f5YQg.','SuperAdmin','SuperAdmin','9873309499','ACTIVE','SuperAdmin@cavium.com','N',(select id from designation where descr='DefaultUserGroup'),(select id from acl_details where descr='SuperAdmin'),"SuperAdmin");


alter table cluster_partitions_relationship add column util_channel_port mediumint(8) unsigned;

alter table appliance_details add column  crypto_user_name varchar(100),
add column  crypto_user_password varchar(100);

insert into permission(id,short_permission,permission_description,app_id) values((select max(id+1) from permission as id) ,'ROLE_UM_APPLIANCE_NETWORK_SETTING','Appliance  Network Setting','5');

insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),(select id from permission where short_permission="ROLE_UM_APPLIANCE_NETWORK_SETTING"));
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SecondaryUser'),(select id from permission where short_permission="ROLE_UM_APPLIANCE_NETWORK_SETTING"));
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='GroupAdmin'),(select id from permission where short_permission="ROLE_UM_APPLIANCE_NETWORK_SETTING"));
