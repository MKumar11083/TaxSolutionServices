alter table dualfactor_users_relationship modify  dual_factor_auth_server_port_no varchar(100);
alter table dual_factor_auth modify  dual_factor_auth_server_port_no varchar(100);
--------- From 28Jan Onward-----------
alter table dualfactor_users_relationship add column appliance_ip varchar(200);
alter table appliance_details add column fips_state varchar(200);
---------------------
