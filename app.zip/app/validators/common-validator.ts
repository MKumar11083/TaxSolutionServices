import { Directive } from '@angular/core'; //  Will import the angular core features. Required for all components , modules, etc...
import { NG_VALIDATORS, FormControl, FormGroup, Validator, ValidationErrors, ValidatorFn } from '@angular/forms'; // Will import the angular forms
import { AbstractControl } from '@angular/forms';

@Directive({
    selector: '[common-validate]',
    providers: [{ provide: NG_VALIDATORS, useExisting: CommonValidator, multi: true }]
})
export class CommonValidator {
   static ipAddressValidator(control: AbstractControl) {
        const inputValue = control.value;
        if (inputValue != '' && inputValue != null) {
            const ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
            if (inputValue.match(ipformat)) {
                return null;
            } else {
                return { invalidIp: true };
            }

        }
    }

    static ipAddressValidator1(control: AbstractControl) {
        const inputValue = control.value;
        if (inputValue != '' && inputValue != null) {
            const ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
            if (inputValue.match(ipformat)) {
                if (inputValue === "127.0.0.1") {
                    return { loopbackIp: true };
                } else {
                    return null;
                }

            } else {
                return { invalidIp: true };
            }

        }
    }
    static hostNameValidator(control: AbstractControl) {
        const inputValue = control.value;
        if (inputValue != '' && inputValue != null) {
            //const hostNameformat = "^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9\-]*[A-Za-z0-9])$";
            // const hostNameformat = /^[0-9a-zA-Z][0-9a-zA-Z]*[-]?[a-zA-Z0-9]*[0-9a-zA-Z]$/;
            const hostNameformat= "^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\\-]*[a-zA-Z0-9])\\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9\\-]*[A-Za-z0-9])$";     
            if (inputValue.match(hostNameformat)) {
                return null;
            } else {
                return { invalidHostname: true };
            }

        }
    }
    static hostNameValidator1(control: AbstractControl) {
        const inputValue = control.value;
        if (inputValue != '' && inputValue != null) {
            //const hostNameformat = "^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9\-]*[A-Za-z0-9])$";
            // const hostNameformat= "^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\\-]*[a-zA-Z0-9])\\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9\\-]*[A-Za-z0-9])$";
            const hostNameformat = /^[0-9a-zA-Z][0-9a-zA-Z]*[-]?[0-9a-zA-Z]*[.]?[a-zA-Z0-9]*[.]?[a-zA-Z0-9]*[0-9a-zA-Z]$/;
            if (inputValue.match(hostNameformat)) {
                return null;
            } else {
                return { invalidHostname: true };
            }

        }
    }
    static macAddressValidator(control: AbstractControl) {
        const inputValue = control.value;
        if (inputValue != '' && inputValue != null) {
            const macAddressformat = /^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/;
            if (inputValue.match(macAddressformat)) {
                return null;
            } else {
                return { invalidMacAddress: true };
            }

        }
    }
    static validateAlphaNumeric(control: AbstractControl) {
        const inputValue = control.value;
        if (inputValue != '' && inputValue != null) {
            const alphanumericformat = /^[0-9a-zA-Z.-]+$/;
            if (inputValue.match(alphanumericformat)) {
                return null;
            } else {
                return { invalidAplhaNumeric: true };
            }

        }
    }
    static validateAppName(control: AbstractControl) {
        const inputValue = control.value;
        if (inputValue != '' && inputValue != null) {
            const alphanumericformat = /^[0-9a-zA-Z_]+$/;
            if (inputValue.match(alphanumericformat)) {
                return null;
            } else {
                return { invalidAplhaNumeric: true };
            }

        }
    }

    static validateRestAuthID(control: AbstractControl) {
        const inputValue = control.value;
        if (inputValue != '' && inputValue != null) {
            const alphanumericformat = /^[0-9a-zA-Z_-]+$/;
            if (inputValue.match(alphanumericformat)) {
                return null;
            } else {
                return { invalidRestAuthID: true };
            }

        }
    }

    static validateZoneName(control: AbstractControl) {
        const inputValue = control.value;
        if (inputValue != '' && inputValue != null) {
            const alphanumericformat = /^[0-9a-zA-Z_-]+$/;
            if (inputValue.match(alphanumericformat)) {
                return null;
            } else {
                return { invalidZoneName: true };
            }

        }
    }

    static validateUsername(control: AbstractControl) {
        const inputValue = control.value;
       if (inputValue != '' && inputValue != null) {
            const alphanumericformat = /^[0-9a-zA-Z_]+$/;
            if (inputValue.match(alphanumericformat)) {
                return null;
            } else {
                return { invalidUsername: true };
            }

        }
    }

    static validatePassword(control: AbstractControl) {
        const inputValue = control.value;
        if (inputValue != '' && inputValue != null) {
            const alphanumericformat = /^[0-9a-zA-Z!@#$%^*&]+$/;
            if (inputValue.match(alphanumericformat)) {
                return null;
            } else {
                return { invalidPassword: true };
            }

        }
    }

    static validatelogFailureCount(control: AbstractControl) {
        const inputValue = control.value;
        if (inputValue != null) {
            if (inputValue < 1 || inputValue > 1000) {
                return { isValidZoneID: true };
            } else {
                return null;
            }
        }
    }
    static validatePhoneNumber(control: AbstractControl) {
        const inputValue = control.value;
        if (inputValue != '' && inputValue != null) {
            const phonenoformat = /^[1-9][0-9]{0,14}$/;
            if (inputValue.match(phonenoformat)) {
                return null;
            } else {
                return { invalidPhoneNumber: true };
            }

        }
    }

    static validateEmail(control: AbstractControl) {
        const inputValue = control.value;
        if (inputValue != '' && inputValue != null) {
            const emailPattern = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+(?:[A-Z]{2}|com)\b/;
            if (inputValue.match(emailPattern )) {
                return null;
            } else {
                return { invalidEmail: true };
            }

        }
    }

    static validateAlphaNumeric1(control: AbstractControl) {
        const inputValue = control.value;
        if (inputValue != '' && inputValue != null) {
            const alphanumericformat = /^[0-9a-zA-Z_]*$/;
            if (inputValue.match(alphanumericformat)) {
                return null;
            } else {
                return { invalidAplhaNumeric1: true };
            }

        }
    }

    static validateAlphaNumeric2(control: AbstractControl) {
        const inputValue = control.value;
        if (inputValue != '' && inputValue != null) {
            const alphanumericformat = /^[a-zA-Z][0-9a-zA-Z_]*$/;
            if (inputValue.match(alphanumericformat)) {
                return null;
            } else {
                return { invalidAplhaNumeric1: true };
            }
        }
    }
    static snmpUserName(control: AbstractControl) {
        const inputValue = control.value;
        if (inputValue != '' && inputValue != null) {
            const alphanumericformat = /^[0-9a-zA-Z]+$/;
            if (inputValue.match(alphanumericformat)) {
                return null;
            } else {
                return { invalidAplhaNumeric: true };
            }
        }
    }
    static engineIdValidate(control: AbstractControl) {
        const inputValue = control.value;
        if (inputValue != '' && inputValue != null) {
            const alphanumericformat = /^[0-9a-f]+$/;
            if (inputValue.match(alphanumericformat)) {
                return null;
            } else {
                return { invalidAplhaNumeric: true };
            }
        }
    }

    
    static validateConfirmPassword(control: AbstractControl) {
        const confirmPassword = control.value;
        const group = control.parent;
        if (group) {
            const password = group.controls['password'].value;
            if (confirmPassword != '' && confirmPassword != null) {
                if (password !== confirmPassword) {
                    return { invalidConfirmPassword: true };
                } else {
                    return null;
                }

            }
        }

    }
    static validatePartitionName(control: AbstractControl) {
        const inputValue = control.value;
        if (inputValue != '' && inputValue != null) {
            const alphanumericformat = /^[A-Za-z0-9_:]+$/;
            if (inputValue.match(alphanumericformat)) {
                return null;
            } else {
                return { invalidPartitionName: true };
            }

        }
    }

    static validateDomainName(control: AbstractControl) {
        const inputValue = control.value;
        if (inputValue != '' && inputValue != null) {
            const domainName = /^(?!:\/\/)([a-zA-Z0-9-_]+\.)*[a-zA-Z0-9][a-zA-Z0-9-_]+\.[a-zA-Z]{2,11}?$/;
            if (inputValue.match(domainName)) {
                return null;
            } else {
                return { invalidDomainName: true };
            }

        }
    }

    static validateSerialNumber(control: AbstractControl) {
        const inputValue = control.value;
        if (inputValue != '' && inputValue != null) {
            const serialNumber = /^[0-9a-zA-Z.-]+$/;
            if (inputValue.match(serialNumber)) {
                let splitValue = inputValue.split(".");
                let splitValue1 = inputValue.split("-");
                if(splitValue.length>2){
                    return { invalidAplhaNumeric: true };
                }else if(splitValue1.length>2){
                    return { invalidAplhaNumeric: true };
                }else{
                    return null;
                }
            } else {
                return { invalidAplhaNumeric: true };
            }

        }
    }

    static validateFile(control: FormControl): {[key: string]: any} {
        const fileValue = control.value;
        if( control.value == null || control.value.length == 0 ){
            return { required: true };
        }else{
            return null;
        }
      }

      static isNumberCheck(control: FormControl): {[key: string]: any} {
          const inputValue = control.value;
          if (isNaN(inputValue)) {
            return { isNumberCheck: true };
          }
          return null;
        
      }

      static validateGroupName(control: AbstractControl) {
        const inputValue = control.value;
        if (inputValue != '' && inputValue != null) {
            const alphanumericformat = /^[0-9a-zA-Z_]*$/;
            if (inputValue.match(alphanumericformat)) {
                return null;
            } else {
                return { invalidGroupName: true };
            }

        }
    }

}


