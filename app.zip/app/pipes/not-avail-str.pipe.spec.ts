import { NotAvailStrPipe } from './not-avail-str.pipe';

describe('NotAvailStrPipe', () => {
  it('create an instance', () => {
    const pipe = new NotAvailStrPipe();
    expect(pipe).toBeTruthy();
  });
});
