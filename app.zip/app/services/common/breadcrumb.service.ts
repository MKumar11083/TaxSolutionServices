import { Injectable } from '@angular/core';
import * as breadcrumbData from './../../../assets/data/breadcrumb.json';
import { TranslateService } from '@ngx-translate/core';

@Injectable()
export class BreadcrumbService {
  breadcrumbs = [];
  constructor(private translate:TranslateService) {
   
   }

   getBreadCrumbDetails(key){
     console.log(key);
    this.breadcrumbs = []; 
    let breadDatas = (<any>breadcrumbData)[key];
    breadDatas.forEach(bread => {
      this.translate.get(bread.title).subscribe(res => {
        this.convertTextToLang(bread,res);
      }); 
    });
   }

   convertTextToLang(bread,langRes){
    bread.title=langRes;
    this.breadcrumbs.push(bread);
   }

}
