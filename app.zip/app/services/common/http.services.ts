import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, Headers, ResponseContentType } from '@angular/http';
import { Configuration } from '../../app.constants';
import { Observable } from 'rxjs/Observable';
import { Cookie } from 'ng2-cookies';
import { Router } from '@angular/router';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
// import {} from './../../l/
@Injectable()
export class HttpServices {
    errorMessages = [];
    private apiUrl: string;
    private Server: string;
    private logoutURL: string;
    constructor(private _http: Http,
        private _configuration: Configuration,
        private _router: Router
    ) {
        this.apiUrl  =  window.location.origin + '/' + _configuration.ApiUrl;
        this.Server =  window.location.origin + '/marvell/oauth/token';
        this.logoutURL  =  window.location.origin + '/marvell/logout';
        this.apiUrl  =  this.apiUrl.replace('4200','8080');
        this.Server =  this.Server.replace('4200','8080');
        this.logoutURL  =  this.logoutURL.replace('4200','8080');
        
        this.getAccessToken();
    }
    getAccessToken() {
        return Cookie.get(sessionStorage.getItem('username'));
    }
    options() {
        let headers = new Headers({
            'Content-type': 'application/json',
            'Authorization': 'Bearer ' + this.getAccessToken()
        });
        let options = new RequestOptions({ headers: headers });
        return options;
    }

    httpGet(url: String) {
        return this._http.get(this.apiUrl + url, this.options())
            .map(res => res.json())
            .catch((error: any) => {
                return this.handleError(error);
            })
    }

    httpPost(model, url: String) {
        return this._http.post(this.apiUrl + url, model, this.options())
            .map(res => res.json())
            .catch((error: any) => {
                return this.handleError(error);
            })
    }
    httpPut(model, url: String) {
        return this._http.put(this.apiUrl + url, model, this.options())
            .map(res => res)
            .catch((error: any) => {
                return this.handleError(error);
            })
    }
    httpDelete(url: String) {
        return this._http.delete(this.apiUrl + url, this.options())
            .map(res => res)
            .catch((error: any) => {
                return this.handleError(error);
            })
    }
    httpDeleteOperationWithBody(url: String, model) {
        let headers = new Headers({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + this.getAccessToken()
        });
        let options = new RequestOptions({
            headers: headers,
            body: model
        });
        return this._http.delete(this.apiUrl + url, options)
            .map(res => res)
            .catch((error: any) => {
                return this.handleError(error);
            })
    }

    httpOauthToken(params) {
        params.append('grant_type', this._configuration.GRANT_TYPE);
        params.append('client_id', this._configuration.CLIENT_ID);
        params.append('client_secret', this._configuration.CLIENT_SECRET);
        let headers = new Headers({ 'Content-type': 'application/x-www-form-urlencoded; charset=utf-8', 'Authorization': 'Basic ' + btoa("cavium-client:cavium-secret") });
        let options = new RequestOptions({ headers: headers });
        return this._http.post(this.Server, params.toString(), options)
            .map(res => res.json());
    }

    httpPostWithOutToken(model, url: String) {
        let headers = new Headers({ 'Content-type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        return this._http.post(this.apiUrl + url, model, options)
            .map(res => res.json())

    }

    httpPostForDownloadFile(model, url: String) {
        return this._http.post(this.apiUrl + url, model, this.options())
            .map(res => res)
            .catch((error: any) => {
                return this.handleError(error);
            });
    }
    httpPostForDownloadZipFile(model, url: String) {
        const options = new RequestOptions({
            responseType: ResponseContentType.Blob,
            headers: new Headers({
                'Accept': 'application/zip',
                'Authorization': 'Bearer ' + this.getAccessToken()
            })
        })

        return this._http.post(this.apiUrl + url, model, options)
            .map((response) => { return response })
            .catch((error: any) => {
                return this.handleError(error);
            });
    }

    httpFileUploadPost(files, url) {
        let headers = new Headers({
            'Authorization': 'Bearer ' + this.getAccessToken()
        });
        let options = new RequestOptions({ headers: headers });
        return this._http.post(this.apiUrl + url, files, options)
            .map(response => response.json())
            .catch((error: any) => {
                return this.handleError(error);
            });
    }

    httpDeleteForLogout() {
        let headers = new Headers({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + this.getAccessToken()
        });
        let options = new RequestOptions({
            headers: headers,
        });
        return this._http.delete(this.logoutURL, options)
            .map(res => res.json())
            .catch((error: any) => {
                return this.handleError(error);
            });
    }

    handleError(error: Response) {
        if (error.status == 401 || error.status == 0) {
            sessionStorage.clear();
            localStorage.clear();
            Cookie.delete('refresh_token');
            Cookie.delete(this.getAccessToken());
            this._router.navigate(['/']);
        }
        else {
            return Observable.throw(error);
        }
    }

  
}
