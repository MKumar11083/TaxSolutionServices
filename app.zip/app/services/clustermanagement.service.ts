import { Injectable } from '@angular/core';
import { HttpServices } from './../../../src/app/services/common/http.services';


@Injectable()
export class ClustermanagementService {

  constructor(private _httpServices: HttpServices,) { }

  getClusterDetails(formData) {
    let url = "/partitionsConnectivityDetails/";
    return this._httpServices.httpPost(formData, url);
  }

  getAddNodeDetails() {
  let url = "/listOfNotAssignedPartitions";
  return this._httpServices.httpGet(url);
  }

 deleteNodeDetails(modal) {
  let url = "/removePartitionsFromCluster";
  return this._httpServices.httpDeleteOperationWithBody(url,modal);
  }
  createCluster(modal){
    let url = "/createCluster/";
    return this._httpServices.httpPost(modal, url);
  }
}
