import { Injectable } from '@angular/core';
import { HttpServices } from './../services/common/http.services';
import { AppURL } from '../app.url';


@Injectable()
export class DashboardService {

  constructor(private _httpServices: HttpServices,
    private _restURL: AppURL) { }

  getAlertDetails() {
    let url = "/alertsForDashBoard";
    return this._httpServices.httpGet(url);
  }
  getUserInfo() {
    let url = "/userTrackingSummaryForDashBoard";
    return this._httpServices.httpGet(url);

  }

  getRecentActivityDetails() {
    let url = "/recentActivitiesForDashBoard";
    return this._httpServices.httpGet(url);
  }

  getGroupWiseAppliances() {
    let url = "/groupWiseAppliancesForDashBoard";
    return this._httpServices.httpGet(url);
  }

  getPartitionWiseAppliances() {
    let url = "/partitionWiseAppliancesForDashBoard";
    return this._httpServices.httpGet(url);
  }

  getUsersDetailsForDashBoard() {
    let url = "/usersDetailsForDashBoard";
    return this._httpServices.httpGet(url);
  }
  getSystemInfo() {
    let url = "/systemInformation";
    return this._httpServices.httpGet(url);

  }


}
