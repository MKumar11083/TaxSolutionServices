import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { HttpServices } from './../services/common/http.services';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { AppURL } from '../app.url';
@Injectable()
export class AppliancemanagementService {
  private selectedAppliancesData = new BehaviorSubject('');
  selectedAppliances = this.selectedAppliancesData.asObservable();

  private allAppliancesData = new BehaviorSubject('');
  allAppliancesList = this.allAppliancesData.asObservable()

  constructor(private _httpServices: HttpServices, private _http: Http,
    private _restURL: AppURL) {
  }

  addAppliance(form) {
    let url = "/createUser";
    return this._httpServices.httpPost(form, url);
  }
  getAdminNetworkInfoData(ipaddress) {
    let url = "/getAdminNetworkInfo/" + ipaddress + "/";
    return this._httpServices.httpGet(url);
  }

  getAllListAppliances() {
    let url = "/listAppliance";
    return this._httpServices.httpGet(url);
  }
  getAllSnapshotDetails() {
    let url = "/getSnapshotDetails";
    return this._httpServices.httpGet(url);
  }
  setRebootActivity(form) {
    let url = "/rebootAppliance";
    return this._httpServices.httpPost(form, url);
  }
  firmwareUpgrade(form) {
    let url = "/applianceFirmwareUpgrade";
    return this._httpServices.httpFileUploadPost(form, url);
  }
  setZeroise(form) {
    let url = "/zeroizeAppliance";
    return this._httpServices.httpPost(form, url);
  }
  getHostSystemInfo(ipaddress) {
    let url = "/getHostSystemInfo/" + ipaddress + "/";
    return this._httpServices.httpGet(url);
  }

  searchAppliances(model) {
    let url = "/searchAppliance ";
    return this._httpServices.httpPost(model, url);
  }

  saveInitializedata(form) {
    let url = "/initilizeAppliance";
    return this._httpServices.httpPost(form, url);
  }

  getAdminVMInfo(ipaddress) {
    let url = "/getAdminVMInfo/" + ipaddress + "/";
    return this._httpServices.httpGet(url);
  }

  submitNetworkDetails(formData) {
    let url = "/modifyAppliance";
    return this._httpServices.httpPut(formData, url);
  }

  monitorLoginForm(form) {
    let url = "/hostMonitorStats";
    return this._httpServices.httpPost(form, url);
  }
  networkSettingsDataSubmit(networkData) {

    let url = "/hostNetworkVMConfig";
    return this._httpServices.httpPost(networkData, url);
  }

  setSelectedAppliances(item: any) {
    this.selectedAppliancesData.next(item);
  }
  setAllAppliances(items: any) {
    this.allAppliancesData.next(items);
  }
  getInProgressActivities() {
    return this._httpServices.httpGet(this._restURL.GET_IN_PROGRESS_ACTIVITIES);
  }
  downloadLogs(formData) {
    let url = "/downloadlogsDetails";
    return this._httpServices.httpPostForDownloadZipFile(formData, url);
  }

  deleteLogs(formData) {
    let url = "/deleteLogs";
    return this._httpServices.httpPost(formData, url);
  }
  getPartitionListByAppId(applianceModal) {
    return this._httpServices.httpPost(applianceModal, this._restURL.GET_PARTITIONLIST_BY_APPID);
  }

  saveZeroizedata(formdata) {
    let url = "/zeroizeAppliance";
    return this._httpServices.httpPost(formdata, url);
  }

  uploadCertificate(form) {
    let url = "/uploadCertificates";
    return this._httpServices.httpPost(form, url);
  }
  downloadcertificate(formData) {
    let url = "/downloadCertificate";
    return this._httpServices.httpPostForDownloadFile(formData, url);
  }
  getConfigLogsDetails(formData) {
    let url = "/getConfiguredLoggerType";
    return this._httpServices.httpPost(formData, url);
  }

  updateConfiguredLoggerType(formData) {
    let url = "/updateConfiguredLoggerType";
    return this._httpServices.httpPost(formData, url);
  }
  getAlertDetails() {
    let url = "/alertsForAppliance";
    return this._httpServices.httpGet(url);
  }
  getRecentActivityDetails() {
    let url = "/recentActivitiesForAppliance";
    return this._httpServices.httpGet(url);
  }
  getInProgressActivityDetails() {
    let url = "/inProgressActivityForAppliance";
    return this._httpServices.httpGet(url);
  }
  getAdminMonitorStats(formData) {
    let url = "/adminMonitorStats";
    return this._httpServices.httpPost(formData, url);
  }

  checkAppliancesCredentials(formData) {
    let url = "/validateCredentialsByLoginHSM";
    return this._httpServices.httpPost(formData, url);
  }

  deleteAppliance(formData) {
    let url = "/deleteAppliances";
    return this._httpServices.httpDeleteOperationWithBody(url, formData);
  }

  getApplianceMonitorData(formData) {
    let url = "/getApplianceMonitorData";
    return this._httpServices.httpPost(formData, url);
  }

  setApplianceMonitorData(formData) {
    let url = "/setApplianceMonitorData";
    return this._httpServices.httpPost(formData, url);
  }

  downloadLogsForAppliance(formData) {
    let url = "/downloadMonitorLogsFile";
    return this._httpServices.httpPostForDownloadZipFile(formData, url);
  }
  getSelfTestReport(modal) {
    let url = "/getSelfReportData";
    return this._httpServices.httpPost(modal, url);
  }
  changeAppliancePassword(modal) {
    let url = "/changeAppliancePassword";
    return this._httpServices.httpPost(modal, url);
  }

  getIPaddress(formData) {
    let url = "/discoverIpAddress";
    return this._httpServices.httpPost(formData, url);
  }

  getIPaddressRange(formData) {
    let url = "/discoverIpAddressRange";
    return this._httpServices.httpPost(formData, url);
  }

  getSNMPDetails(formData) {
    let url = "/getSNMPInfo/";
    return this._httpServices.httpPost(formData, url);
  }

  setSNMPDetails(formData) {
    let url = "/setSNMPInfo/";
    return this._httpServices.httpPost(formData, url);
  }
  uploadMcokey(form) {
    let url = "/uploadMCOKeyCertificate";
    return this._httpServices.httpFileUploadPost(form, url);
  }
  validateDeleteAppliance(formData) {
    let url = "/validateDeleteAppliance/";
    return this._httpServices.httpPost(formData, url);
  }
  getEditApplianceDetails(applianceId){
    let url = "/getAppliance/" + applianceId + "/";
    return this._httpServices.httpGet(url);
  }
  modifyAppliance(formValue){
    let url = "/modifyAppliance";
    return this._httpServices.httpPut(formValue,url);
  }

  getSessionCredentialsDetails(applianceId){
    const userId=  sessionStorage.getItem("username");
    let url = "getUserDualFactorDetails/"+applianceId+"/"+userId+"/";
    return this._httpServices.httpGet(url);
  }
}
