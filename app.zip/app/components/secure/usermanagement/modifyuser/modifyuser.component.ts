import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { BreadcrumbService } from './../../../../services/common/breadcrumb.service';
import { UserManagementService } from './../../../../services/usermanagement.service';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, FormControl } from '@angular/forms';
import { ModalDirective } from 'ngx-bootstrap/modal';

import { Observable } from 'rxjs/Observable';
import { AnonymousSubscription } from "rxjs/Subscription";
import { Router } from '@angular/router';
import { I18nService } from '../../../../services/common/i18n/i18n.service';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { CommonValidator} from './../../../../validators/common-validator';
@Component({

  selector: 'app-modifyuser',
  templateUrl: './modifyuser.component.html',
  styleUrls: ['./modifyuser.component.css']
})
export class ModifyuserComponent implements OnInit, OnDestroy {
  @ViewChild('selecterror')
  selecterror: ModalDirective;


  form: FormGroup;
  list : any = [];
  successMsg: string;
  aclList: any = [];
  groupList: any = [];
  modifyusersubsc: AnonymousSubscription;
  displayErrors: any = [];
  successMessage: any = [];
  public selectplaceholder = "Select the Options";
  canClearSelect: boolean = true;
  modifyvalid: boolean = true;
  message1: string;
  firstname1: any;
  lastname1: any;
  email1: any;
  phone1: any;
  usergroup1: any;
  status1: any;
  acl1: any;
  tempACLUser: any = [];
  isAclDisabled : boolean = false;

  constructor(
    // private _breadcrumbService: BreadcrumbService,
    private _userManagementService: UserManagementService,
    private _formBuilder: FormBuilder,
    private _I18nService: I18nService,
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private router: Router) { }

  ngOnInit() {
    // this._breadcrumbService.getBreadCrumbDetails("modify-users");
    this.modifyForm();
    this.list.push("ACTIVE");
    this.list.push("SUSPENDED");
    let userId = this._userManagementService.getuserId();
    this.getUserDetailsByUserId(userId[0]);
    this._userManagementService.clearUserId();
  }

  modifyForm() {
    this.form = this._formBuilder.group({
      userName: ['', Validators.required],
      firstName: ['', Validators.compose([Validators.required,CommonValidator.validateAlphaNumeric1])],
      lastName: ['', Validators.compose([Validators.required,CommonValidator.validateAlphaNumeric1])],
      emailId: ['',Validators.compose([Validators.required,CommonValidator.validateEmail])],
      phoneNumber: [null,Validators.compose([CommonValidator.validatePhoneNumber])],
      userGroupId: [null, Validators.required],
      userACLId: [null, Validators.required],
      status: ['',Validators.required],
      temporaryPassword: "N",
      message: ''
    });
  }

  public formValidationFields = {
    "userName": '',
    "firstName": '',
    "lastName": '',
    "emailId": '',
    "phoneNumber": '',
    "userGroupId": '',
    "userACLId": '',
    "status": '',

  }
  isFieldValid(field: string) {
    // if (this.form.get(field).touched) {
      this.formValidationFields = this._fieldErrorDisplayService.validateField(this.form, field, this.formValidationFields, "modifyuser")
    // }
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  onSubmit(isValid: boolean) {
    if (isValid) {
      this.modifyvalid = true;
      this.message1 = "";
      this.displayErrors = [];
      let status = this.form.get("status").value;
      let firstname2 = this.form.get("firstName").value;
      let lastname2 = this.form.get("lastName").value;
      let email2 = this.form.get("emailId").value;
      let phone2 = this.form.get("phoneNumber").value;
      let usergroup2 = this.form.get("userGroupId").value;
      let acl2 = this.form.get("userACLId").value;
      if (this.firstname1 == firstname2) {
        if (this.lastname1 == lastname2) {
          if (this.email1 == email2) {
            if (this.phone1 == phone2) {
              if (this.usergroup1 == usergroup2) {
                if (this.acl1 == acl2) {
                  if(this.status1==status){
                  this.modifyvalid = false;
                  }
                }
              }
            }
          }
        }
      }
      if (this.modifyvalid == true) {
        let status = this.form.get("status").value;
        this.form.patchValue({ status: status });
        if(this.isValidEmail == true){
        if (this.isValidFirstName == true && this.isValidLastName == true) {
          if (this.phonevalid == true) {
            this.modifyusersubsc = this._userManagementService.modifyUser(this.form.value).subscribe(
              data => {
                //this.form.controls['status'].setValue("ACTIVE");
                this.onSuccessOperation(data)
              },
              err => this.onErrorOperation(err)
            );
          }
          else {
            this.displayErrors.push("You have entered an invalid Phone number");
          }
        }
        else {
          this.displayErrors.push("You have entered an invalid Name");
        }
      }else {
        this.displayErrors.push("You have entered an invalid Email Address");
      }
      }
      else {
        this.message1 = "No fields are modified. Please modify atleast one field";
        this.selecterror.show();
      }
    } else {
      this.formValidationFields = this._fieldErrorDisplayService.validateForm(this.form, this.formValidationFields, "modifyuser", false)
    }
  }

  closeMessage() {
    this.successMessage = [];
    this.displayErrors = [];
  }

  // To display success or error messages on page.
  onSuccessOperation(response) {
    this.successMessage = [];
    this.displayErrors = [];
    let res = response.json();
    if (res.responseCode == "200") {
      //this.successMessage.push(res.responseMessage);
      sessionStorage.setItem("msg", res.responseMessage);
      this.router.navigateByUrl("/manageuserlist");
    } else if (res.responseCode == "204" || res.responseCode == "409" || res.responseCode == "500") {
      this.displayErrors.push(res.responseMessage);
    } else {
      this.displayErrors.push(res.responseMessage);
    }
  }

  // To display error messages on page
  onErrorOperation(error) {
    console.log('OnError' + JSON.stringify(error));
    this.displayErrors = this._I18nService.getI18NMessagesForError(error, "", "");
    console.log('errorMessages -->' + JSON.stringify(this.displayErrors));
  }

  // reset form.
  reset() {
    this.form.controls['firstName'].reset();
    this.form.controls['lastName'].reset();
    this.form.controls['emailId'].reset();
    this.form.controls['phoneNumber'].reset();
    if(!this.isdisabled){
      this.form.controls['userGroupId'].reset();
      this.form.controls['userACLId'].reset();
    }
    this.form.controls['message'].reset();
    this.form.get('status').setValue("ACTIVE");

  }


  getUserDetailsByUserId(userId) {
    this.isdisabled = false;
    this._userManagementService.getUserById(userId).subscribe(
      (res) => {
        this.tempACLUser = res.listUserACLDetailsModel;
        this.groupList = res.listUserGroupModel;

        if (res.userDetailModel != null) {
          if (res.userDetailModel.userName != null) {
            this.form.patchValue({ userName: res.userDetailModel.userName });
          }
          if (res.userDetailModel.firstName != null) {
            this.form.patchValue({ firstName: res.userDetailModel.firstName });
            this.firstname1 = res.userDetailModel.firstName;
          }
        }
        if (res.userDetailModel != null) {
          if (res.userDetailModel.lastName != null) {
            this.form.patchValue({ lastName: res.userDetailModel.lastName });
            this.lastname1 = res.userDetailModel.lastName;
          }
        }
        if (res.userDetailModel != null) {
          if (res.userDetailModel.emailId != null) {
            this.form.patchValue({ emailId: res.userDetailModel.emailId });
            this.email1 = res.userDetailModel.emailId;

          }
        }
        if (res.userDetailModel != null) {
          if (res.userDetailModel.phoneNumber != null) {
            this.form.patchValue({ phoneNumber: res.userDetailModel.phoneNumber });
            this.phone1 = res.userDetailModel.phoneNumber;
          }
        }
        if (res.userDetailModel.objUserGroupModel != null) {
          if (res.userDetailModel.objUserGroupModel.id != null) {
            let value = this.setValueToSelect(res.userDetailModel.objUserGroupModel.id);
            this.form.controls['userGroupId'].setValue(res.userDetailModel.objUserGroupModel.id);
            this.usergroup1 = res.userDetailModel.objUserGroupModel.id;
          } else {
            this.form.controls['userGroupId'].setValue("");
          }
        } else {

          this.form.controls['userGroupId'].setValue("");
        }
        if (res.userDetailModel.status != null) {
          if (res.userDetailModel.status == "ACTIVE") {
            this.form.controls['status'].setValue("ACTIVE");
            this.status1 = "ACTIVE";
          } else if (res.userDetailModel.status == "SUSPENDED") {
            this.form.controls['status'].setValue("SUSPENDED");
            this.status1 = "SUSPENDED";
          }
        }
        if (res.userDetailModel.objUserACLDetailsModel != null) {
          this.form.controls['userACLId'].setValue(res.userDetailModel.objUserACLDetailsModel.id);
          this.acl1 = res.userDetailModel.objUserACLDetailsModel.id;
          //this.form.controls['userACLId'].setValue(this.setValueToSelect(res.userDetailModel.objUserACLDetailsModel.id));
        }
        this.isdisabled = false;
        let isSuperAdmin= false;
        if (userId == "SuperAdmin") {
          this.isdisabled = true;
          isSuperAdmin = true;
          this.isAclDisabled= true;
          
        }
        if(!isSuperAdmin){
          if (this.groupList.length > 1) {
            this.isdisabled = false;
            this.isAclDisabled = false;
          }else{
            this.isdisabled = true;
            this.isAclDisabled = false;
          }
        }

        if (res.userDetailModel != null) {
          if (res.userDetailModel.message != null) {
            this.form.controls['message'].setValue(res.userDetailModel.message);
          }
        }
        if (res.userDetailModel != null) {
          if (res.userDetailModel.objUserGroupModel != null) {
            if (res.userDetailModel.objUserGroupModel.roleName != null) {
              let roleName = res.userDetailModel.objUserGroupModel.roleName;
              this.tempACLUser.forEach(element => {
                if(isSuperAdmin){
                  if (roleName === "DefaultUserGroup") {
                    var aclName = element.aclName;
                    if (aclName.trim() != "GroupAdmin") {
                      this.aclList.push(element);
                    }
                  } else {
                    var aclName = element.aclName;
                    if (aclName.trim() == "GroupAdmin") {
                      this.aclList.push(element);
                    }
                  }
                }else{
                  if (roleName === "DefaultUserGroup") {
                    var aclName = element.aclName;
                    if (aclName.trim() != "GroupAdmin") {
                      this.aclList.push(element);
                    }
                  }else{
                    this.aclList.push(element);
                  }
                 
                }
            
              });
            }
          }
        }

      },
      (err) => {
        this.onErrorOperation(err);
      }
    );
  }
  isdisabled = false;
  public ngOnDestroy(): void {
    if (this.modifyusersubsc) {
      this.modifyusersubsc.unsubscribe();
    }
  }
  setValueToSelect(value) {
    let setValue = [];
    setValue.push(value);
    return setValue;
  }

  isValidEmail = true;
  ValidateEmail(inputText) {
    this.isValidEmail = true;
    var emailPattern = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+(?:[A-Z]{2}|com)\b/;
    if (inputText != '') {
      if (inputText.match(emailPattern)) {
        this.isValidEmail = true;
      }
      else {
        this.isValidEmail = false;
      }
    }
  }

  phonevalid = true;
  ValidatephoneNumber(inputText) {
    this.phonevalid = true;
    var phonenoformat = /^[1-9][0-9]{0,14}$/;
    if (inputText != '') {
      if (inputText.match(phonenoformat)) {
        this.phonevalid = true;
      }
      else {
        this.phonevalid = false;
      }
    }
  }

  isValidFirstName = true;
  ValidateName1(inputText) {
    this.isValidFirstName = true;
    var nameformat = /^[0-9a-zA-Z_]*$/;
    if (inputText != '') {
      if (inputText.match(nameformat)) {
        this.isValidFirstName = true;
      }
      else {
        this.isValidFirstName = false;
      }
    }
  }

  isValidLastName = true;
  ValidateName2(inputText) {
    this.isValidLastName = true;
    var nameformat = /^[0-9a-zA-Z_]*$/;
    if (inputText != '') {
      if (inputText.match(nameformat)) {
        this.isValidLastName = true;
      }
      else {
        this.isValidLastName = false;
      }
    }
  }

  getACLDetails(args) {
    let value = args.target.options[args.target.selectedIndex].text;
    this.aclList = [];
    this.form.get('userACLId').setValue("");
    this.form.get('userACLId').markAsUntouched();
    this.form.get('userGroupId').markAsUntouched();
    this.tempACLUser.forEach(element => {
      if(value === "Choose a UserGroup"){
        this.aclList=[];
      }else if (value === "DefaultUserGroup") {
        var aclName = element.aclName;
        if (aclName.trim() != "GroupAdmin") {
          this.aclList.push(element);
        }
      } else {
        var aclName = element.aclName;
        if (aclName.trim() == "GroupAdmin") {
          this.aclList.push(element);
        }
      }
    });
  }
}
export function setOption(value, label) {
  let option = new Option();
  option.value = value;
  option.label = label;
  return option;
}
