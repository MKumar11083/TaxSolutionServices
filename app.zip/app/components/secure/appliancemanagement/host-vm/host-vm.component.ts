import { Component, OnInit, ViewChild, AfterViewInit, AfterViewChecked, OnChanges } from '@angular/core';
import { ChartsModule, Color } from 'ng2-charts';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { AdminVmComponent } from './../admin-vm/admin-vm.component';
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, FormControl } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { MonitorComponent } from './../../appliancemanagement/monitor/monitor.component';
import { ChangepassApplianceComponent } from './../changepass-appliance/changepass-appliance.component';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { AnonymousSubscription } from "rxjs/Subscription";
import { Observable } from "rxjs/Observable";
import { DataTableResource } from './../../data-table/index';

declare var $: any;
declare var bootbox: any;
import { BaseChartDirective } from 'ng2-charts/ng2-charts';
@Component({
  selector: 'app-host-vm',
  templateUrl: './host-vm.component.html',
  styleUrls: ['./host-vm.component.css']
})
export class HostVmComponent implements OnInit {
  @ViewChild('pcpu')
  public pcpu: BaseChartDirective;
  @ViewChild('processMemory')
  public processMemory: BaseChartDirective;

  @ViewChild('cpu')
  public cpu: BaseChartDirective;
  @ViewChild('monitorComponent')
  monitorComponent: MonitorComponent;
  @ViewChild('changePass')
  private ChangePassword: ChangepassApplianceComponent;
  @ViewChild('adminVmComponent')
  private adminVmComponent: AdminVmComponent;
  @ViewChild('selecterror')
  selecterror: ModalDirective;
  @ViewChild('messageModal') messageModal: ModalDirective;
  successMessage = '';
  errorMessages = [];
  monitorLoginForm: FormGroup;
  selfTestReport: string = '';
  selfTestRep: any = [];
  applianceip: string;
  itemResource: any;
  itemCount;
  itemResource1: any;
  itemCount1;
  itemResource2: any;
  itemCount2;
  //network and snmp
  network: any = [];
  snmp: any = [];
  status: any = [];
  trapStatus: any = [];
  username: any = [];
  managerIp: any = [];
  obj: any = [];
  obj1: any = [];
  objMemoryDetails: any = [];
  objPCPU: any = [];
  networkObj: any = [];



  resourceUsage: any = [];
  hostInfo: any = [];
  adapterInfo: any = [];
  stats: any = [];
  message: string;
  showlist: boolean = true;
  showlist1: boolean = true;
  showlist2: boolean = true;
  gaugeType = "arch";
  gaugeThickness = 25;
  staticIpToHostConfigUpdated: object[] = [];
  submitApplianceNewtorkData = {};
  applianceModel: any = [];
  ipAddressAdd: any;
  HostnameAdd: any;
  AliasAdd: any;
  showPopUp = false;
  public loading = false;


  gaugeThresholdConfig = {
    '0': { color: 'rgb(0,179,30' },
    '60': { color: 'rgb(230,191,0' },
    '80': { color: 'rgb(204,0,0' }
  };
  gaugeAppendText = "%";

  // hostVM gauge
  gaugeColor: any;
  gaugeColor2: any;
  gaugeColor3: any;
  gaugeColor4: any;
  gaugeValue :number;
  gaugeValue2:number;
  gaugeValue3 :number;
  gaugeValue4 :number;
  eth0LinkStatus: any;
  public temp: any[] = [[25, 22]];

  applianceId: string;
  applianceName: string;
  applianceObj: any;
  applianceObjAdvanced: object[] = [];
  applianceObjAdvancedDup: object[] = [];
  appAdd: object[] = [];
  getApplianceAdvancedData: any;
  saveModalFlag = false;
  errorMessage = '';

  monitorStatList: any = [];
  cpuDataList: any = [];
  pcpuDataList: any = [];
  monitorStatMap = new Map<string, Array<string>>();
  cpuDataMap = new Map<string, Array<string>>();
  pcpuDataMap = new Map<string, Array<string>>();
  public lineChartData: Array<any> = [];
  public pcpuChartData: Array<any> = [];
  public cpuChartData2: Array<any> = [];
  public processMemoryLabel: Array<any> = [];
  public cpuLabel: Array<any> = [];
  public pcpuLabel: Array<any> = [];
  public hoursMinutes: Array<any> = [];
  public memoryUsageChartData: Array<any> = [];
  public memoryUsageTableData: Array<any> = [];
  originalProcessMemoryData = [];
  originalPcpuData = [];
  originalCpuData = [];
  memoryLabelList = [
    'buffers', 'cache', 'free', 'shared', 'used'
  ]
  hostSysTimer: AnonymousSubscription;
  constructor(private _applianceManagementService: AppliancemanagementService,
    private _route: ActivatedRoute, private builder: FormBuilder,
    private _fieldErrorDisplayService: FieldErrorDisplayService) { }
  ngOnInit() {
    this.applianceId = "";

    this._route.params.subscribe(params => {
      this.applianceId = params['applianceId'];
      this.applianceName = params['applianceName'];
      // this.applianceip = params['ip'];
    });
    this.loading = true;

    this.hostSysTimer= this._applianceManagementService.getHostSystemInfo(this.applianceId).subscribe(
      res => {
        this.loading = false;
        this.errorMessage = '';
        this.adapterInfo = [];
        this.adapterInfo = res.hsmInfo;
        if (this.adapterInfo.status != "Failed") {
          this.reloadHostVmInfo();

          this.resourceUsage = res.partitionsDetails;
          this.hostInfo = res.applianceInfo;

          this.stats = res.hostStats;
          this.applianceObj = res.adminVMConfig;
          this.applianceModel = res.applianceDetailModel;
          this.applianceModel["partitionDetailModels"] = null;
          if (res["adminVMConfig"] != null) {
            if (res["adminVMConfig"]["adminVMData"] != null) {
              if (res["adminVMConfig"]["adminVMData"]["advanced"] != null) {
                if (res["adminVMConfig"]["adminVMData"]["advanced"]["staticIpToHostConfig"] != null) {
                  this.getApplianceAdvancedData = res["adminVMConfig"]["adminVMData"]["advanced"]["staticIpToHostConfig"];
                }
              }
            }
          }
          if (this.getApplianceAdvancedData != null) {
            if (this.getApplianceAdvancedData.length > 0) {
              for (var i = 0; i < this.getApplianceAdvancedData.length; i++) {
                this.applianceObjAdvanced.push(this.getApplianceAdvancedData[i]);
                this.applianceObjAdvancedDup.push(this.getApplianceAdvancedData[i]);
              }
              for (var i = 0; i < this.applianceObjAdvancedDup.length; i++) {
                this.applianceObjAdvancedDup[i]["color"] = "Green";

              }
            }
          }
          if (this.applianceObj.adminVMData != null) {
            // this.form.get("dhcp").setValue(this.applianceObj.adminVMData.general.dhcp);
            // this.form.get("ipAddress").setValue(this.applianceObj.adminVMData.general.ip);
            // this.form.get("gatewayIp").setValue(this.applianceObj.adminVMData.general.gateway);
            // this.form.get("subnetMask").setValue(this.applianceObj.adminVMData.general.subnet);
            // this.form.get("hostName").setValue(this.applianceObj.adminVMData.general.hostname ? this.applianceObj.adminVMData.general.hostname : '');
            // this.form.get("vLanId").setValue(this.applianceObj.adminVMData.general.vlan);
            // this.form.get("macAddress").setValue(this.applianceObj.adminVMData.general.macAddress);
            // this.form.get("staticMac").setValue(this.applianceObj.adminVMData.general.macStatic);
            // this.form.get("dnsService").setValue(this.applianceObj.adminVMData.advanced.enableDNSService);
          }
          if (this.stats != null) {
            if (this.stats.dataObject != null) {
              if (this.stats.dataObject.vmstatsObject != null) {
                if (this.stats.dataObject.vmstatsObject.linkStatusEth0 != null) {
                  if (this.stats.dataObject.vmstatsObject.linkStatusEth0 == 1) {
                    this.eth0LinkStatus = "Up";
                  } else if (this.stats.dataObject.vmstatsObject.linkStatusEth0 == 0) {
                    this.eth0LinkStatus = "Down";
                  }
                }
              }
            }
          }

          if (this.stats != null) {
            if (this.stats.dataObject != null) {
              if (this.stats.dataObject.vmstatsObject != null) {
                this.gaugeValue = this.stats.dataObject.vmstatsObject.cpuUsage;
              }
            }
          }

          if(this.gaugeValue <= 30){
            this.gaugeColor = 'rgb(0,179,30)';
            }
          else if(this.gaugeValue > 30 && this.gaugeValue <= 60)  {
            this.gaugeColor = 'rgb(230,191,0)';
          }
          else if(this.gaugeValue > 60)  {
            this.gaugeColor = 'rgb(204,0,0)';
          }
          
          if (this.stats != null) {
            if (this.stats.dataObject != null) {
              if (this.stats.dataObject.vmstatsObject != null) {
                if (this.stats.dataObject.vmstatsObject.ramStats != null) {
                  this.gaugeValue2 = this.stats.dataObject.vmstatsObject.ramStats.usedPercentage;
                }
              }
            }
          }

          if(this.gaugeValue2 <= 30){
            this.gaugeColor2 = 'rgb(0,179,30)';
            }
          else if(this.gaugeValue2 > 30 && this.gaugeValue2 <= 60)  {
            this.gaugeColor2 = 'rgb(230,191,0)';
          }
          else if(this.gaugeValue2 > 60)  {
            this.gaugeColor2 = 'rgb(204,0,0)';
          }

          if (this.stats != null) {
            if (this.stats.dataObject != null) {
              if (this.stats.dataObject.vmstatsObject != null) {
                if (this.stats.dataObject.vmstatsObject.diskSpace != null) {
                  this.gaugeValue4 = this.stats.dataObject.vmstatsObject.diskSpace.usedPercentage;
                }
              }
            }
          }

          if(this.gaugeValue4 <= 30){
            this.gaugeColor4 = 'rgb(0,179,30)';
            }
          else if(this.gaugeValue4 > 30 && this.gaugeValue4 <= 60)  {
            this.gaugeColor4 = 'rgb(230,191,0)';
          }
          else if(this.gaugeValue4 > 60)  {
            this.gaugeColor4 = 'rgb(204,0,0)';
          }

          if (this.stats != null) {
            if (this.stats.dataObject != null) {
              if (this.stats.dataObject.vmstatsObject != null) {
                if (this.stats.dataObject.vmstatsObject.swapStats != null) {
                  this.gaugeValue3 = this.stats.dataObject.vmstatsObject.swapStats.usedPercentage;
                }
              }
            }
          }

          if(this.gaugeValue3 <= 30){
            this.gaugeColor3 = 'rgb(0,179,30)';
            }
          else if(this.gaugeValue3 > 30 && this.gaugeValue3 <= 60)  {
            this.gaugeColor3 = 'rgb(230,191,0)';
          }
          else if(this.gaugeValue3 > 60)  {
            this.gaugeColor3 = 'rgb(204,0,0)';
          }

          this.doughnutChartData.push(this.resourceUsage.occupiedKeys);
          this.doughnutChartData.push(this.resourceUsage.freeKeys);

          this.doughnutChartData1.push(this.resourceUsage.occupiedAcclrDev);
          this.doughnutChartData1.push(this.resourceUsage.freeAcclrDev);

          this.doughnutChartData2.push(this.resourceUsage.occupiedContexts);
          this.doughnutChartData2.push(this.resourceUsage.freeContexts);

          this.getMonitorStatDetails();
        } else {
          this.errorMessage = this.adapterInfo.errorMessage;
          this.messageModal.show();
        }
      },
      error => {
        this.loading = false;
        console.log(error);
      },
    );

  }


  getMonitorStatDetails() {
    this.monitorStatList = [];
    this.monitorStatMap = new Map<string, Array<string>>();
    this.cpuDataList = [];
    this.pcpuDataList = [];
    this.cpuDataMap = new Map<string, Array<string>>();
    this.pcpuDataMap = new Map<string, Array<string>>();
    this.lineChartData = [];
    this.pcpuChartData = [];
    this.cpuChartData2 = [];
    this.originalProcessMemoryData = [];
    this. originalPcpuData = [];
    this.originalCpuData = [];
    this.processMemoryLabel = [];
    this.cpuLabel = [];
    this.pcpuLabel = [];
    this.hoursMinutes = [];
    this.hostvmTimer1Subs = this._applianceManagementService.monitorLoginForm(this.applianceModel).subscribe((res) => {
      let timeLabel = res.map(item => item["hoursminutes"]);
      timeLabel.sort((a, b) => { a-b
      });
      setTimeout( () => {
        this.hoursMinutes =timeLabel;
      });
      this.getProcessMemoryStats(res);
      this.getMemoryUsage(res);
      this.getCPUDetaills(res);
      this.getPCPUDetails(res);
      this.reloadHostVmMonitorStats();
    },
      error => {
        console.log(error);
      });
  }

  hostvmTimer1: AnonymousSubscription;
  hostvmTimer1Subs: AnonymousSubscription;
  reloadHostVmMonitorStats() {
    this.hostvmTimer1 = Observable.timer(10000).first().subscribe(() => this.getMonitorStatDetails());
  }

  getProcessMemoryStats(res) {
    let memoryStatDetails = res.map(item => item["details"]);
    this.processMemoryLabel = this.hoursMinutes;
    memoryStatDetails.forEach(element => {
      if (element != null) {
        element.forEach(processMemory => {
          if (this.monitorStatMap.get(processMemory.pid)) {
            let processMemoryArray = this.monitorStatMap.get(processMemory.pid);
            processMemoryArray.push(processMemory);
            this.monitorStatMap.set(processMemory.pid, processMemoryArray);
          } else {
            let processMemoryArray = [];
            processMemoryArray.push(processMemory);
            this.monitorStatMap.set(processMemory.pid, processMemoryArray);
          }
        });
      }
    });

    let pids = Array.from(this.monitorStatMap.keys());
    pids.forEach(pid => {
      if (this.monitorStatMap.has(pid)) {
        let memory = {};
        let memoryStatArray: Array<any> = [];
        memoryStatArray = this.monitorStatMap.get(pid);
        let memoryArray: Array<any> = [];
        memoryStatArray.forEach(element => {
          memoryArray.push(element['mem']);
        });
        this.monitorStatList.push(memoryStatArray[memoryStatArray.length - 1]);
        this.itemResource1 = new DataTableResource(this.monitorStatList);
        this.itemResource1.count().then(count => { this.itemCount1 = count });
        memory['data'] = memoryArray;
        memory['label'] = pid;
        memory['fill'] = false;
        memory['backgroundColor'] = this.dynamicColors();
        memory['borderColor'] = this.dynamicColors();
        memory['pointBackgroundColor'] = memory['borderColor'],
          memory['pointBorderColor'] = '#fff',
          memory['pointHoverBackgroundColor'] = '#fff',
          memory['pointHoverBorderColor'] = this.dynamicColors(),
          this.lineChartData.push(memory);
        this.originalProcessMemoryData.push(memory);
      }
    });
  }

  getPCPUDetails(res) {
    let PCPUDetaills = res.map(item => item["info"]);
    this.pcpuLabel = this.hoursMinutes;
    PCPUDetaills.forEach(element => {
      if (element != null) {
        element.forEach(pcpuData => {
          if (this.pcpuDataMap.get(pcpuData.cpu)) {
            let pcpuDataArray = this.pcpuDataMap.get(pcpuData.cpu);
            pcpuDataArray.push(pcpuData);
            this.pcpuDataMap.set(pcpuData.cpu, pcpuDataArray);
          } else {
            let pcpuDataArray = [];
            pcpuDataArray.push(pcpuData);
            this.pcpuDataMap.set(pcpuData.cpu, pcpuDataArray);
          }
        });
      }
    });

    let cpus = Array.from(this.pcpuDataMap.keys());
    cpus.forEach(cpu => {
      if (this.pcpuDataMap.has(cpu)) {
        let pcpu = {};
        let pcpuDetailsArray: Array<any> = [];
        pcpuDetailsArray = this.pcpuDataMap.get(cpu);
        let pcpuArray: Array<any> = [];
        pcpuDetailsArray.forEach(element => {
          pcpuArray.push(element['cpuPercent']);
        });
        this.pcpuDataList.push(pcpuDetailsArray[pcpuDetailsArray.length - 1]);
        this.itemResource = new DataTableResource(this.pcpuDataList);
        this.itemCount = this.pcpuDataList.length;
        pcpu['data'] = pcpuArray;
        pcpu['label'] = cpu;
        pcpu['fill'] = false;
        pcpu['backgroundColor'] = this.dynamicColors();
        pcpu['borderColor'] = this.dynamicColors();
        pcpu['pointBackgroundColor'] = pcpu['borderColor'],
          pcpu['pointBorderColor'] = '#fff',
          pcpu['pointHoverBackgroundColor'] = '#fff',
          pcpu['pointHoverBorderColor'] = pcpu['borderColor'],
          this.pcpuChartData.push(pcpu);
        this.originalPcpuData.push(pcpu);
      }
    });
  }

  dynamicColors = function () {
    var r = Math.floor(Math.random() * 255);
    var g = Math.floor(Math.random() * 255);
    var b = Math.floor(Math.random() * 255);
    return "rgb(" + r + "," + g + "," + b + ")";
  }
  getMemoryUsage(response) {
    this.memoryUsageChartData = new Array<any>();
    this.memoryUsageTableData = new Array<any>();
    let memoryUsage = response.map(item => {
      if (item["usage"] != null) {
        return item["usage"];
      }
    }
    );
    if (memoryUsage.length > 0) {
      for (var i = 0; i < this.memoryLabelList.length; i++) {
        if (memoryUsage[i] != null) {
          let memoryUsageModel = {};
          memoryUsageModel['data'] = memoryUsage.map(item => item[0][this.memoryLabelList[i]]);
          memoryUsageModel['label'] = this.memoryLabelList[i];
          this.memoryUsageChartData.push(memoryUsageModel);
        }
      }
      if (memoryUsage[memoryUsage.length - 1] != null) {
        this.memoryUsageTableData.push(memoryUsage[memoryUsage.length - 1][0]);
        this.memoryUsageTableData.push(memoryUsage[memoryUsage.length - 1][1]);
      }
    }
  }

  getCPUDetaills(res) {
    let CPUDetaills = res.map(item => item["usageInfo"]);
    this.cpuLabel = this.hoursMinutes;
    CPUDetaills.forEach(element => {
      if (element != null) {
        element.forEach(cpuData => {
          if (this.cpuDataMap.get(cpuData.pid)) {
            let cpuDataArray = this.cpuDataMap.get(cpuData.pid);
            cpuDataArray.push(cpuData);
            this.cpuDataMap.set(cpuData.pid, cpuDataArray);
          } else {
            let cpuDataArray = [];
            cpuDataArray.push(cpuData);
            this.cpuDataMap.set(cpuData.pid, cpuDataArray);
          }
        });
      }

    });

    let pids = Array.from(this.cpuDataMap.keys());
    pids.forEach(pid => {
      if (this.cpuDataMap.has(pid)) {
        let cpu = {};
        let cpuDetailsArray: Array<any> = [];
        cpuDetailsArray = this.cpuDataMap.get(pid);
        let cpuArray: Array<any> = [];
        cpuDetailsArray.forEach(element => {
          cpuArray.push(element['usage']);
        });
        this.cpuDataList.push(cpuDetailsArray[cpuDetailsArray.length - 1]);
        this.itemResource2 = new DataTableResource(this.cpuDataList);
        this.itemCount2 = this.cpuDataList.length;
        cpu['data'] = cpuArray;
        cpu['label'] = pid;
        cpu['fill'] = false;
        cpu['backgroundColor'] = this.dynamicColors();
        cpu['borderColor'] = this.dynamicColors();
        cpu['pointBackgroundColor'] = cpu['borderColor'],
          cpu['pointBorderColor'] = '#fff',
          cpu['pointHoverBackgroundColor'] = '#fff',
          cpu['pointHoverBorderColor'] = cpu['borderColor'],
          this.cpuChartData2.push(cpu);
        this.originalCpuData.push(cpu)
      }
    });
  }

  // update process memory
  updateProcessMemory(event, pid) {
    let tempData = this.lineChartData;
    if (event.checked) {
      for (let i = 0; i < this.originalProcessMemoryData.length; i++) {
        if (this.originalProcessMemoryData[i].label == pid) {
          tempData.push(this.originalProcessMemoryData[i]);
        }
      }
    } else {
      const index = tempData.findIndex(data => data.label === pid);
      tempData.splice(index, 1);
    }

    let _processMemoryChartData: Array<any> = new Array(tempData.length);
    for (let i = 0; i < tempData.length; i++) {
      _processMemoryChartData[i] = {
        data: new Array(tempData[i].data.length),
        label: tempData[i].label,
        fill: false,
        backgroundColor: tempData[i].backgroundColor,
        borderColor: tempData[i].borderColor,
        pointBackgroundColor: tempData[i].borderColor,
        pointBorderColor: '#fff',
        pointHoverBackgroundColor: '#fff',
        pointHoverBorderColor: tempData[i].borderColor,
      };
      for (let j = 0; j < tempData[i].data.length; j++) {
        _processMemoryChartData[i].data[j] = tempData[i].data[j];;
      }
    }
    if (this.processMemory !== undefined) {
      this.processMemory.chart.destroy();
      this.processMemory.chart = 0;
      this.processMemory.datasets = _processMemoryChartData;
      this.processMemory.labels = this.processMemoryLabel;
      this.processMemory.ngOnInit();
    }
  }
  // update pcpu data
  updatePCPUData(event, cpu) {
    let tempData = this.pcpuChartData;
    if (event.checked) {
      for (let i = 0; i < this.originalPcpuData.length; i++) {
        if (this.originalPcpuData[i].label == cpu) {
          tempData.push(this.originalPcpuData[i]);
        }
      }
    } else {
      const index = tempData.findIndex(data => data.label === cpu);
      tempData.splice(index, 1);
    }
    let _pcpuChartData: Array<any> = new Array(tempData.length);
    for (let i = 0; i < tempData.length; i++) {
      _pcpuChartData[i] = {
        data: new Array(tempData[i].data.length),
        label: tempData[i].label,
        fill: false,
        backgroundColor: tempData[i].backgroundColor,
        borderColor: tempData[i].borderColor,
        pointBackgroundColor: tempData[i].borderColor,
        pointBorderColor: '#fff',
        pointHoverBackgroundColor: '#fff',
        pointHoverBorderColor: tempData[i].borderColor,
      };
      for (let j = 0; j < tempData[i].data.length; j++) {
        _pcpuChartData[i].data[j] = tempData[i].data[j];;
      }
    }
    if (this.pcpu !== undefined) {
      this.pcpu.chart.destroy();
      this.pcpu.chart = 0;
      this.pcpu.datasets = _pcpuChartData;
      this.pcpu.labels = this.pcpuLabel;
      this.pcpu.ngOnInit();
    }
  }

  // update cpu data
  updateCPUData(event, pid) {
    let tempData = this.cpuChartData2;
    if (event.checked) {
      for (let i = 0; i < this.originalCpuData.length; i++) {
        if (this.originalCpuData[i].label == pid) {
          tempData.push(this.originalCpuData[i]);
        }
      }
    } else {
      const index = tempData.findIndex(data => data.label === pid);
      tempData.splice(index, 1);
    }
    let _cpuChartData: Array<any> = new Array(tempData.length);
    for (let i = 0; i < tempData.length; i++) {
      _cpuChartData[i] = {
        data: new Array(tempData[i].data.length),
        label: tempData[i].label,
        fill: false,
        backgroundColor: tempData[i].backgroundColor,
        borderColor: tempData[i].borderColor,
        pointBackgroundColor: tempData[i].borderColor,
        pointBorderColor: '#fff',
        pointHoverBackgroundColor: '#fff',
        pointHoverBorderColor: tempData[i].borderColor,
      };
      for (let j = 0; j < tempData[i].data.length; j++) {
        _cpuChartData[i].data[j] = tempData[i].data[j];;
      }
    }
    this.cpuChartData2 = _cpuChartData;
    if (this.cpuChartData2.length == 1) {
      let data = this.cpuDataList;
      for (let j = 0; j < this.cpuDataList[j].length; j++) {
        if (this.cpuDataList[j].pid == this.cpuChartData2[0].label) {
          this.cpuDataList[j]['checked'] = false;
        }
      }


    }
    if (this.cpu !== undefined) {
      this.cpu.chart.destroy();
      this.cpu.chart = 0;
      this.cpu.datasets = _cpuChartData;
      this.cpu.labels = this.pcpuLabel;
      this.cpu.ngOnInit();
    }
  }

  reloadItems(params) {
    if (this.itemResource) {
      this.itemResource.query(params).then(items => this.pcpuDataList = items);
    }
  }

  reloadItems1(params) {
    if (this.itemResource1) {
      this.itemResource1.query(params).then(items => this.monitorStatList = items);
    }
  }
  reloadItems2(params) {
    if (this.itemResource2) {
      this.itemResource2.query(params).then(items => this.cpuDataList = items);
    }
  }


  hostToggle() {
    // if (this.hostvmTimer) {
    //   this.hostvmTimer.unsubscribe();
    // }
    // if (this.hostvmTimer1) {
    //   this.hostvmTimer1.unsubscribe();
    // }
    this.getReloadInfo();
    this.showlist = true;
    this.showlist1 = true;
  }
  adminToggle() {
    // if (this.hostvmTimer) {
    //   this.hostvmTimer.unsubscribe();
    // }
    // if (this.hostvmTimer1) {
    //   this.hostvmTimer1.unsubscribe();
    // }
    //this.getReloadInfo();
    this.showlist = false;
    this.showlist1 = false;
  }

  systemToggle() {
    this.showlist1 = true;
  }
  monitorToggle() {
    this.showlist1 = false;
  }

  //Doughnut
  public doughnutChartData: number[] = [];
  public doughnutChartData1: number[] = [];
  public doughnutChartData2: number[] = [];
  public doughnutChartType: string = 'doughnut';
  public doughnutChartLabels: string[] = ['Used', 'Available'];
  public chartOptions = {
    responsive: true,
    legend: {
      display: true,
      position: 'bottom',
      labels: {
        boxWidth: 10
      }
    }
  };
  public mycolors: Array<Color> = [
    {
      backgroundColor: [
        'rgb(247, 113, 131)',
        'rgb(84, 198, 233)'],
      hoverBackgroundColor: ['rgb(247, 113, 131)', 'rgb(84, 198, 233)'],
    }
  ];

  public lineChartOptions: any = {
    responsive: true,
    legend: {
      display: true,
      position: 'bottom',
      fill: false
    },
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true,
        },
        scaleLabel: {
          display: true,
          labelString: 'Memory',
          fontStyle: 'bold'
        }
      }],
      xAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'Time Interval',
          fontStyle: 'bold'
        }
      }],
    }
  };

  public lineChartOptions1: any = {
    responsive: true,
    legend: {
      display: true,
      position: 'bottom',
      fill: false
    },
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true,
        },
        scaleLabel: {
          display: true,
          labelString: 'Percentage',
          fontStyle: 'bold'
        }
      }],
      xAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'Time Interval',
          fontStyle: 'bold'
        }
      }],
    }
  };

  public lineChartOptions2: any = {
    responsive: true,
    legend: {
      display: true,
      position: 'bottom',
      fill: false
    },
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true,
        },
        scaleLabel: {
          display: true,
          labelString: 'Usage ',
          fontStyle: 'bold'
        }
      }],
      xAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'Time Interval',
          fontStyle: 'bold'
        }
      }],
    }
  };
  public lineChartColors1: Array<any> = [
    { // light green
      backgroundColor: 'rgba(102,204,0,0.2)',
      borderColor: 'rgba(102,204,0,1)',
      pointBackgroundColor: 'rgba(102,204,0,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(102,204,0,0.8)'
    },
    // blue
    {
      backgroundColor: 'rgba(0,149,179,0.2)',
      borderColor: 'rgba(0,149,179,1)',
      pointBackgroundColor: 'rgba(0,149,179,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(0,149,179,0.8)'
    },
    { // orange
      backgroundColor: 'rgba(255,166,77,0.2)',
      borderColor: 'rgba(255,166,77,1)',
      pointBackgroundColor: 'rgba(255,166,77,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,166,77,0.8)'
    },
    { // purple
      backgroundColor: 'rgba(136,77,255,0.2)',
      borderColor: 'rgba(136,77,255,1)',
      pointBackgroundColor: 'rgba(136,77,255,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(136,77,255,0.8)'
    },
    { // blue
      backgroundColor: 'rgba(51,119,255,0.2)',
      borderColor: 'rgba(51,119,255,1)',
      pointBackgroundColor: 'rgba(51,119,255,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(51,119,255,0.8)'
    }
  ];
  public lineChartColors: Array<any> = [
    { // light green
      backgroundColor: this.dynamicColors(),
      borderColor: this.dynamicColors(),

    },
  ];
  public lineChartLegend: boolean = false;
  public lineChartType: string = 'line';

  showSelfTest() {

    if (this.hostvmTimer) {
      this.hostvmTimer.unsubscribe();
    }
    this.getReloadInfo();
    this.loading = true;
    this.selfTestRep = [];
    $("#SelfTestModal").modal("show");
    let Modal = {};
    this.message = "";
    Modal["applianceId"] = this.applianceId;
    Modal["applianceName"] = this.applianceName;
    Modal["ipAddress"] = this.applianceModel.ipAddress;
    Modal["selfReportType"] = 'host';
    this._applianceManagementService.getSelfTestReport(Modal).subscribe(
      res => {
        let res1 = JSON.stringify(res);
        let res2 = JSON.parse(res1);
        this.selfTestRep = res2.responseMessage.split("\\n");
        // this.selfTestRep=res2.responseMessage.split("\\n");

        this.selfTestReport = res2.responseMessage;

        if (res2.responseCode == 408) {
          this.loading = false;
          this.hostvmTimer.unsubscribe();
          this.selfTestRep = [];
          this.message = res2.responseMessage;
          res2.responseCode = 1;
          this.selecterror.show();


        }

        this.loading = false;
        console.log(res2.responseMessage.split("\\n"));
        //var array = JSON.parse(res2.responseMessage[" + selfTest + "]);
        console.log(this.selfTestReport);
        // this.selfTestReport=res;
        // this.selfTestReport =JSON.parse(res.responseMessage);
        //  console.log(this.selfTestReport);

      },
      error => {
        this.loading = false;
        console.log(error);
      },
    );
  }
  closeModalst() {
    $("#SelfTestModal").modal("hide");
  }
  hostvmTimer: AnonymousSubscription;
  hostvmTimerSubs: AnonymousSubscription;
  reloadHostVmInfo() {
    this.hostvmTimer = Observable.timer(10000).first().subscribe(() => this.getReloadInfo());
  }
  getReloadInfo() {

    this.hostvmTimerSubs =this._applianceManagementService.getHostSystemInfo(this.applianceId).subscribe(
      res => {
        this.loading = false;
        this.errorMessage = '';
        this.adapterInfo = [];
        this.adapterInfo = res.hsmInfo;
        if (this.adapterInfo.status != "Failed") {
          this.loading = false;
          this.reloadHostVmInfo();
        }
        else {
          this.loading = false;
          this.hostvmTimer.unsubscribe();
          this.hostvmTimerSubs.unsubscribe();
          this.errorMessage = this.adapterInfo.errorMessage;
          this.selecterror.hide();
          $("#SelfTestModal").modal("hide");
          this.messageModal.show();

        }

      },
      error => {
        this.loading = false;
        console.log(error);
      },
    );

  }
  ngOnDestroy() {
    if (this.hostvmTimer) {
      this.hostvmTimer.unsubscribe();
    }
    if(this.hostvmTimer1){
      this.hostvmTimer1.unsubscribe();
    }
    if(this.hostvmTimerSubs){
      this.hostvmTimerSubs.unsubscribe();
    }
    if(this.hostvmTimer1Subs){
      this.hostvmTimer1Subs.unsubscribe();
    }
    if(this.hostSysTimer){
      this.hostSysTimer.unsubscribe();
    }
  }
}












