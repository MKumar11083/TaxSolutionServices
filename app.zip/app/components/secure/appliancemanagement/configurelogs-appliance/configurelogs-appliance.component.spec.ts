import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigurelogsApplianceComponent } from './configurelogs-appliance.component';

describe('ConfigurelogsApplianceComponent', () => {
  let component: ConfigurelogsApplianceComponent;
  let fixture: ComponentFixture<ConfigurelogsApplianceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigurelogsApplianceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigurelogsApplianceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
