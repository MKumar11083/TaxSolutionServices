import { Component, OnInit, ViewChild, Input, Output, EventEmitter, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { InitializeApplianceComponent } from './../../appliancemanagement/initialize-appliance/initialize-appliance.component';
import { ApplianceOperationsComponent } from './../../appliancemanagement/appliance-operations/appliance-operations.component';
import { FirmwareUpgradeApplianceComponent } from './../../appliancemanagement/firmware-upgrade-appliance/firmware-upgrade-appliance.component';
import { ZeroizeApplianceComponent } from './../../appliancemanagement/zeroize-appliance/zeroize-appliance.component';
import { UploadcertificateComponent } from './../../appliancemanagement/uploadcertificate/uploadcertificate.component';
import { DownloadcertificateComponent } from './../../appliancemanagement/downloadcertificate/downloadcertificate.component';
import { LslogsApplianceComponent } from './../../appliancemanagement/lslogs-appliance/lslogs-appliance.component';
import { ConfigurelogsApplianceComponent } from './../../appliancemanagement/configurelogs-appliance/configurelogs-appliance.component';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { UploadMcokeyComponent } from './../../appliancemanagement/upload-mcokey/upload-mcokey.component';
import { Configuration } from './../../../../app.constants';
import { CommonValidator } from './../../../../validators/common-validator';
@Component({
  selector: 'app-appliance-login',
  templateUrl: './appliance-login.component.html',
  styleUrls: ['./appliance-login.component.css']
})
export class ApplianceLoginComponent implements OnInit {
  @ViewChild('certificate') certificateVariable: ElementRef;
  @ViewChild('key') keyVariable: ElementRef;
  @Input() selectedAppliances;
  @ViewChild('loginModal') loginModal: ModalDirective;
  @ViewChild('confirmModal')
  confirmModal: ModalDirective;
  @ViewChild('initializeAppliance')
  private initializeAppliance: InitializeApplianceComponent;
  @ViewChild('firmwareUpgradeAppliance')
  private firmwareUpgradeAppliance: FirmwareUpgradeApplianceComponent;
  @ViewChild('applianceOperations')
  private applianceOperationsComponent: ApplianceOperationsComponent;
  @ViewChild('zeroizeAppliance')
  private zeroizeAppliance: ZeroizeApplianceComponent;
  @ViewChild('uploadCertificate')
  private uploadCertificate: UploadcertificateComponent;
  @ViewChild('downloadCertificate')
  private downloadCertificate: DownloadcertificateComponent;
  @ViewChild('lslogsAppliance')
  private lslogsAppliance: LslogsApplianceComponent;
  @ViewChild('configureLogs')
  private configureLogs: ConfigurelogsApplianceComponent;
  @ViewChild('uploadMcokey')
  private uploadMcokey: UploadMcokeyComponent;

  @ViewChild("username") userNameField: ElementRef;
  loginForm: FormGroup;
  applianceOperation: string;
  listAppliances = [];
  applianceCount = 1;
  totalApplianceCount = 0;
  applianceName: string;
  message: string;
  isLastAppliance: boolean = false;
  autoLoginApplianceList: any = [];
  loading: boolean = false;
  autenticationDetailsArray: any = [];
  saveCredentialsToSessionArray: any = [];
  initializedApplianceList: any = [];
  applianceDualFactorInitialized: boolean = false;
  notReachableList: any = [];
  @Output() loginEvent = new EventEmitter<any>();
  constructor(private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _formBuilder: FormBuilder,
    private _service: AppliancemanagementService,
    private _configuration: Configuration) { }

  ngOnInit() {
    this.createLoginForm();
    this.clearDetails();
  }
  createLoginForm() {
    this.loginForm = this._formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      credentialSaved: [''],
      dualFactorAuthServerPortNo: [''],
      certificateFile: [""],
      keyFile: [""],
      certificateName: [''],
      certificateExtension: [''],
      certificateContent: [''],
      keyfileName: [''],
      keyfileExtension: [''],
      keyfileContent: ['']
    });
  }

  credentialsSavedMap: Map<string, boolean>;
  showloginModal(operation) {
    let count: number = 0;
    this.credentialsSavedMap = new Map<string, boolean>();
    if (this.selectedAppliances.length != 0) {
      this.notReachableList = this.selectedAppliances.filter(appliance => {
        if (appliance['applianceStatus'] == 'Inactive') {
          return appliance;
        }
      }
      );
      if (this.notReachableList <= 0) {
        this.selectedAppliances.forEach(appliance => {
          if (appliance.applianceDualFactorInitialized) {
            this._service.getSessionCredentialsDetails(appliance.applianceId).subscribe(
              res => {
                count++;
                this.credentialsSavedMap.set(appliance.applianceId, res);
                if (this.selectedAppliances.length == count) {
                  this.setApplianceLoginDetails(operation);
                }
              },
              error => {
                count++;
                console.log(error);
                if (this.selectedAppliances.length == count) {
                  this.setApplianceLoginDetails(operation);
                }
              }
            )
          } else {
            count++;
            if (this.selectedAppliances.length == count) {
              this.setApplianceLoginDetails(operation);
            }
          }
        })
      } else {
        this.confirmModal.show();
      }
    }
  }
  setApplianceLoginDetails(operation) {
    this.clearDetails();
    if (this.selectedAppliances.length != 0) {
      if (this.selectedAppliances.length <= this._configuration.SELECT_MAX_APPLIANCE) {
        this.applianceOperation = operation;
        // if credentialSaved="true" means autologin and if it false , show login popup
        if (operation == "Initialize") {
          this.selectedAppliances.forEach(appliance => {
            if (!appliance['applianceinitialized']) {
              this.setApplianceData(appliance);
            } else {
              this.initializedApplianceList.push(appliance);
            }
          })
        } else if (operation == "uploadcertificate") {
          this.selectedAppliances.forEach(appliance => {
            if (appliance['applianceinitialized']) {
              this.setApplianceData(appliance);
            } else {
              this.initializedApplianceList.push(appliance);
            }
          })
        }
        else {
          this.selectedAppliances.forEach(appliance => {
            this.setApplianceData(appliance);
          })
        }
        if (this.initializedApplianceList.length <= 0) {
          this.applianceOperation = operation;
          if (this.listAppliances.length > 0) {
            this.applianceName = this.listAppliances[this.applianceCount - 1]['applianceName'];
            this.applianceDualFactorInitialized = this.listAppliances[this.applianceCount - 1]['applianceDualFactorInitialized'];
            this.setValidationDualFactorAuthentication();
            this.totalApplianceCount = this.listAppliances.length;
            if (this.applianceCount == this.totalApplianceCount) {
              this.isLastAppliance = true;
            }
            if (this.applianceOperation == 'downloadcertificate') {
              this.redirectToSelectedOperation();
            } else {
              this.loginModal.show();
            }

          } else {
            this.redirectToSelectedOperation();
          }
        } else {
          this.confirmModal.show();
        }

      } else {
        this.loginModal.show();
        this.message = "Sorry!Operation cannot be performed on more than 20 appliances";
      }
    } else {
      this.loginModal.show();
      this.message = "Please select any appliance to perform the activity!";
    }
  }
  setApplianceData(appliance) {
    if (appliance['credentialSaved']) {
      this.autoLoginApplianceList.push(appliance);
    } else {
      this.checkApplianceStored(appliance);
      // check appliance credentials are available in localsession.
      // if available in localsession , skips the login for appliance.
      let loginCredentials = JSON.parse(localStorage.getItem(appliance.ipAddress));
      if (loginCredentials != null) {
        appliance['operationUsername'] = loginCredentials.username;
        appliance['operationPassword'] = loginCredentials.password;
        appliance['userName'] = loginCredentials.username;
        appliance['userPassword'] = loginCredentials.password;
        this.saveCredentialsToSessionArray.push(appliance);
      } else {
        this.listAppliances.push(appliance);
      }
    }
  }
  checkApplianceStored(appliance) {
    if (this.credentialsSavedMap.has(appliance.applianceId)) {
      let isSaved = this.credentialsSavedMap.get(appliance.applianceId);
      if (!isSaved) {
        localStorage.removeItem(appliance.ipAddress);
      }
    }
  }
  goToNextLoginForm() {
    this.userNameField.nativeElement.focus();
    let applianceData = this.listAppliances[this.applianceCount - 1]
    let loginDetailsModal = {};
    loginDetailsModal['applianceId'] = applianceData.applianceId;
    loginDetailsModal['applianceName'] = applianceData.applianceName;
    loginDetailsModal['ipAddress'] = applianceData.ipAddress;
    loginDetailsModal['applianceDualFactorInitialized'] = applianceData.applianceDualFactorInitialized;
    loginDetailsModal['operationUsername'] = this.loginForm.get('username').value;
    loginDetailsModal['operationPassword'] = this.loginForm.get('password').value;
    let dualFactorCheck = applianceData.applianceDualFactorInitialized;
    if (dualFactorCheck) {
      loginDetailsModal = this.setDualFactorData(loginDetailsModal);
    }
    this.autenticationDetailsArray.push(loginDetailsModal);
    this.listAppliances[this.applianceCount - 1]["userName"] = this.loginForm.get('username').value;
    this.listAppliances[this.applianceCount - 1]["userPassword"] = this.loginForm.get('password').value;
    this.listAppliances[this.applianceCount - 1]["operationUsername"] = this.loginForm.get('username').value;
    this.listAppliances[this.applianceCount - 1]["operationPassword"] = this.loginForm.get('password').value;
    if (this.loginForm.get('credentialSaved').value == true) {
      this.listAppliances[this.applianceCount - 1]["credentialSaved"] = true;
    } else {
      this.listAppliances[this.applianceCount - 1]["credentialSaved"] = false;
    }
    // Storing appliance login credentials in local session
    let ipAddress = this.listAppliances[this.applianceCount - 1]["ipAddress"]
    let loginCredentials = {
      username: this.loginForm.get('username').value,
      password: this.loginForm.get('password').value
    };
    localStorage.setItem(ipAddress, JSON.stringify(loginCredentials));
    // local session code ends here
    if (this.applianceCount < this.listAppliances.length) {
      this.applianceName = this.listAppliances[this.applianceCount]['applianceName'];
      this.applianceDualFactorInitialized = this.listAppliances[this.applianceCount]['applianceDualFactorInitialized'];
      this.setValidationDualFactorAuthentication();
      this.applianceCount++;
      if (this.applianceCount == this.totalApplianceCount) {
        this.isLastAppliance = true;
      }
    } else {

      this.loginModal.hide();
      //this.redirectToSelectedOperation();
      this.checkAppliancesCredentials();
    }
    if (dualFactorCheck) {
      this.certificateVariable.nativeElement.value = '';
      this.keyVariable.nativeElement.value = "";
    }
    this.loginForm.reset();

  }
  setDualFactorData(loginDetailsModal) {
    loginDetailsModal['initializeDetailModel'] = {};
    loginDetailsModal['initializeDetailModel']['cryptoOfficerName'] = this.loginForm.get('username').value;
    loginDetailsModal['initializeDetailModel']['cryptoOfficerPassword'] = this.loginForm.get('password').value;
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel'] = {};

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['dualFactorAuthServerPortNo'] = this.loginForm.get('dualFactorAuthServerPortNo').value;
    // certificate file details
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateContent'] = this.loginForm.get('certificateContent').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateName'] = this.loginForm.get('certificateName').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateExtension'] = this.loginForm.get('certificateExtension').value;
    // key file details
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileContent'] = this.loginForm.get('keyfileContent').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileName'] = this.loginForm.get('keyfileName').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileExtension'] = this.loginForm.get('keyfileExtension').value;
    return loginDetailsModal;
  }
  setValidationDualFactorAuthentication() {
    // set validations for dual factor properties 
    //this.applianceDualFactorInitialized = true;
    if (this.applianceDualFactorInitialized) {
      this.loginForm.get('dualFactorAuthServerPortNo').setValidators([Validators.required, CommonValidator.isNumberCheck]);
      this.loginForm.get('certificateFile').setValidators(Validators.required);
      this.loginForm.get('keyFile').setValidators(Validators.required);
    } else {
      this.loginForm.get('dualFactorAuthServerPortNo').setValidators(null);
      this.loginForm.get('certificateFile').setValidators(null);
      this.loginForm.get('keyFile').setValidators(null);
    }
    this.loginForm.get('dualFactorAuthServerPortNo').updateValueAndValidity();
    this.loginForm.get('certificateFile').updateValueAndValidity();
    this.loginForm.get('keyFile').updateValueAndValidity();
  }
  checkAppliancesCredentials() {
    this.loading = true;
    this._service.checkAppliancesCredentials(this.autenticationDetailsArray).subscribe(
      (response) => {
        this.loading = false;
        let isSuccess: boolean = true;
        this.autenticationDetailsArray = [];
        response.forEach(obj => {
          if (obj.code != "200") {
            this.autenticationDetailsArray.push(obj);
            localStorage.removeItem(obj.ipAddress);
            isSuccess = false;
          }
        });
        if (isSuccess) {
          this.redirectToSelectedOperation();
        } else {
          this.confirmModal.show();
        }
      },
      (error) => {
        this.loading = false;
        console.log(error);
      })
  }
  redirectToSelectedOperation() {
    // added the "credentialSaved=true" records to fill the initialize form.
    this.autoLoginApplianceList.forEach(applianceObj => {
      this.listAppliances.push(applianceObj);
    });
    // get the appliance Credentails saved in localSession.
    this.saveCredentialsToSessionArray.forEach(applianceObj => {
      this.listAppliances.push(applianceObj);
    });

    if (this.applianceOperation == "Initialize") {
      this.initializeAppliance.showInitializeModal(this.listAppliances);
    }
    else if (this.applianceOperation == "firmwareUpgrade") {
      this.firmwareUpgradeAppliance.showFirmwareUpgradeModal(this.listAppliances);
    }
    else if (this.applianceOperation == "Zeroize") {
      this.zeroizeAppliance.showZeroizeModal(this.listAppliances);
    }
    else if (this.applianceOperation == "uploadcertificate") {
      this.uploadCertificate.showUploadCertificateModal(this.listAppliances);
    }
    else if (this.applianceOperation == "downloadcertificate") {
      this.downloadCertificate.showDownloadcertificateModal(this.listAppliances);
    }
    else if (this.applianceOperation == "Lslogs") {
      this.lslogsAppliance.showLslogsModal(this.listAppliances);
    }
    else if (this.applianceOperation == "Configurelogs") {
      this.configureLogs.showConfigurelogsModal(this.listAppliances);
    }
    else if (this.applianceOperation == "uploadMcokey") {
      this.uploadMcokey.showuploadMcokeyModal(this.listAppliances);
    }
    else {
      this.applianceOperationsComponent.submitApplianceOperations(this.listAppliances, this.applianceOperation)
    }
  }
  closeLoginModal() {
    console.log("Close ----> Login Modal");
    this.loginModal.hide();
    this.clearDetails();
  }

  callback() {
    console.log("Call back ----> Appliance Login Form");
    this.clearDetails();
    this.loginEvent.emit();
  }
  clearDetails() {
    this.loginForm.reset();
    this.applianceOperation = "";
    this.listAppliances = [];
    this.applianceCount = 1;
    this.totalApplianceCount = 0;
    this.applianceName = "";
    this.message = "";
    this.isLastAppliance = false;
    this.autoLoginApplianceList = [];
    this.autenticationDetailsArray = [];
    this.saveCredentialsToSessionArray = [];
    this.initializedApplianceList = [];
    this.applianceDualFactorInitialized = false;
    this.notReachableList = [];
  }

  public formValidationFields1 = {
    "username": '',
    "password": '',
    "dualFactorAuthServerPortNo": '',


  }
  isFieldValid1(field: string) {
    // if (this.loginForm.get(field).touched) {
    this.formValidationFields1 = this._fieldErrorDisplayService.validateField(this.loginForm, field, this.formValidationFields1, "login")
    // }
    return !this.loginForm.get(field).valid && this.loginForm.get(field).touched;
  }

  displayFieldCss1(field: string) {
    return {
      'has-error': this.isFieldValid1(field),
      'has-feedback': this.isFieldValid1(field)
    };
  }

  onCertificateFileChange($event) {
    this.loginForm.get('certificateFile').markAsTouched({ onlySelf: true });
    let file = $event.target.files[0];
    this.loginForm.controls['certificateFile'].setValue(file ? file.name : ''); // <-- Set Value for Validation
    const filePicked = (event.target as HTMLInputElement).files[0];
    if (filePicked != undefined) {
      const fileName = filePicked.name;
      const extension = filePicked.name.split('.').pop() || '';
      const reader = new FileReader();
      reader.onload = () => {
        if (extension == 'crt') {
          this.loginForm.get('certificateContent').setValue(reader.result);
          this.loginForm.get('certificateName').setValue(fileName.substring(0, fileName.indexOf('.')));
          this.loginForm.get('certificateExtension').setValue(extension);
        } else {
          this.loginForm.get('certificateFile').setErrors({ "invalidExt": true })

        }
      };
      reader.readAsText(filePicked);
    } else {
      this.loginForm.get('certificateFile').setValue("");
      this.loginForm.get('certificateContent').setValue("");
      this.loginForm.get('certificateName').setValue("");
      this.loginForm.get('certificateExtension').setValue("");
      return false;
    }
  }

  onKeyFileChange($event) {
    this.loginForm.controls['keyFile'].markAsTouched({ onlySelf: true });
    let file = $event.target.files[0];
    this.loginForm.controls['keyFile'].setValue(file ? file.name : ''); // <-- Set Value for Validation
    const filePicked = (event.target as HTMLInputElement).files[0];
    if (filePicked != undefined) {
      const fileName = filePicked.name;
      let ext = filePicked.name.split('.');
      const extension = ext[1];
      const reader = new FileReader();
      reader.onload = () => {
        if (extension == 'key') {
          this.loginForm.get('keyfileContent').setValue(reader.result);
          this.loginForm.get('keyfileName').setValue(fileName.substring(0, fileName.indexOf('.')));
          this.loginForm.get('keyfileExtension').setValue(extension);
        } else {
          this.loginForm.get('keyFile').setErrors({ "invalidExt": true })

        }
      };
      reader.readAsText(filePicked);
    } else {
      this.loginForm.get('keyFile').setValue("");
      this.loginForm.get('keyfileContent').setValue("");
      this.loginForm.get('keyfileName').setValue("");
      this.loginForm.get('keyfileExtension').setValue("");
      return false;
    }
  }
}
