import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminVmComponent } from './admin-vm.component';

describe('AdminVmComponent', () => {
  let component: AdminVmComponent;
  let fixture: ComponentFixture<AdminVmComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminVmComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminVmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
