import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminVmnetworkSettingsComponent } from './admin-vmnetwork-settings.component';

describe('AdminVmnetworkSettingsComponent', () => {
  let component: AdminVmnetworkSettingsComponent;
  let fixture: ComponentFixture<AdminVmnetworkSettingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminVmnetworkSettingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminVmnetworkSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
