import { Component, OnInit, Input, ChangeDetectionStrategy,ElementRef,ViewChild } from '@angular/core';
import { AppliancemanagementService } from './../../../../../services/appliancemanagement.service';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, FormControl, FormArray, AbstractControl } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../../services/common/field-error-display.service';
import { Router } from '@angular/router';
import { CommonValidator } from './../../../../../validators/common-validator';
declare var $: any;
declare var bootbox: any;
@Component({
  // changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-admin-vmnetwork-settings',
  templateUrl: './admin-vmnetwork-settings.component.html',
  styleUrls: ['./admin-vmnetwork-settings.component.css']
})
export class AdminVmnetworkSettingsComponent implements OnInit {
  @ViewChild('certificate') certificateVariable : ElementRef;
  @ViewChild('key') keyVariable: ElementRef;
  @Input() applianceModel;
  dnsServerArray: any = [];
  domainNameArray: any = [];
  classStatic: string;
  classServer: string;
  classDomain: string;
  form: FormGroup;
  appAdd: any = [];
  loginForm: FormGroup;
  submitApplianceNewtorkData = {};
  submitApplianceLoginData: Array<any> = [];
  applianceObj: any;
  applianceObjAdvanced: object[] = [];
  applianceObjAdvancedDup: object[] = [];
  getApplianceAdvancedData: any = [];
  staticIpToHostConfigUpdated: object[] = [];
  saveModalFlag = false;
  temp = [];
  isValidHostname3: boolean = true;
  temLocalStorage = [];
  noLoginPop: boolean = false;
  successMessage = '';
  errorMessages = [];
  public loading = false;
  loginCredentials: object[] = [];
  IpValidator = '^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$';
  macaddressValidator = "^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$";
  hostnameValidator = /^[.0-9a-zA-Z-]+$/;
  displayError: string = '';
  staticHostIpLength: number = 0;
  dnsServerLength: number = 0;
  domainNameLength: number = 0;
  removeStaticIps: any = [];
  isValidIp3: boolean = true;
  applianceDualFactorInitialized : boolean = false;
  constructor(private _applianceManagementService: AppliancemanagementService,
    private builder: FormBuilder,
    private _router: Router,
    private _fieldErrorDisplayService: FieldErrorDisplayService) { }

  ngOnInit() {

    this.createForm();
    this.createLoginForm();
    this.form.get('ipAddress').valueChanges.subscribe((data) => {
      this.formerrors = this._fieldErrorDisplayService.validateField(this.form, "ipAddress", this.formerrors, "networkSettings");
    });
    this.form.get('gatewayIp').valueChanges.subscribe((data) => {
      this.formerrors = this._fieldErrorDisplayService.validateField(this.form, "gatewayIp", this.formerrors, "networkSettings");
    });
    this.form.get('subnetMask').valueChanges.subscribe((data) => {
      this.formerrors = this._fieldErrorDisplayService.validateField(this.form, "subnetMask", this.formerrors, "networkSettings");
    });

    this.form.get('macAddress').valueChanges.subscribe((data) => {
      this.formerrors = this._fieldErrorDisplayService.validateField(this.form, "macAddress", this.formerrors, "networkSettings");
    });
    this.form.get('hostName').valueChanges.subscribe((data) => {
      this.formerrors = this._fieldErrorDisplayService.validateField(this.form, "hostName", this.formerrors, "networkSettings");
    });
  }

  createForm() {
    this.form = this.builder.group({
      applianceId: [''],
      ipAddress: [''],
      gatewayIp: [''],
      subnetMask: [''],
      macAddress: [''],
      hostName: [''],
      vLanId: [0, Validators.compose([Validators.min(0), Validators.max(4094)])],
      dnsService: [''],
      dhcp: [''],
      staticMac: [''],
      ip: [''],
      hostname: [''],
      alias: [''],
      dnsServer: [''],
      searchDomainName: [''],
    });
  }
  public formerrors = {
    "ipAddress": '',
    "gatewayIp": '',
    "subnetMask": '',
    "macAddress": '',
    "hostName": ''
  }
  createLoginForm() {
    this.loginForm = this.builder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      dualFactorAuthServerPortNo:[''],
      certificateFile: [""],
      keyFile: [""],
      certificateName: [''],
      certificateExtension: [''],
      certificateContent: [''],
      keyfileName: [''],
      keyfileExtension: [''],
      keyfileContent: ['']
    });
  }
  public formValidationFields1 = {
    "username": '',
    "password": '',
    "dualFactorAuthServerPortNo":''
  }
  isFieldValid1(field: string) {
   // if (this.loginForm.get(field).touched) {
      this.formValidationFields1 = this._fieldErrorDisplayService.validateField(this.loginForm, field, this.formValidationFields1, "login")
  //  }
    return !this.loginForm.get(field).valid && this.loginForm.get(field).touched;
  }

  displayFieldCss1(field: string) {
    return {
      'has-error': this.isFieldValid1(field),
      'has-feedback': this.isFieldValid1(field)
    };
  }
  initialClear() {

    this.form.reset();
    this.loginForm.reset();
    this.tab = "1";

    this.classStatic = "btn-primary";
    this.classServer = "btn-default";
    this.classDomain = "btn-default";
    this.applianceObjAdvancedDup = [];
    this.appAdd = [];
    this.domainNameArray = [];
    this.dnsServerArray = [];
    this.applianceObjAdvanced = [];
    this.isDNSserverChecked = true;
    this.staticHostIpLength = 0;
    this.dnsServerLength = 0;
    this.domainNameLength = 0;
    this.setRequiredFields();
    this.staticIpToHostConfigUpdated = [];
    this.removeStaticIps = [];
  }
  // network settings 
  getNetworkDetails() {
    this.initialClear();
    let loginCredentials = JSON.parse(localStorage.getItem(this.applianceModel.ipAddress));
    if (this.applianceModel.credentialSaved == true) {
      this.loading = true;
      this._applianceManagementService.getAdminNetworkInfoData(this.applianceModel.applianceId).subscribe(
        res => {
          this.loading = false;
          this.applianceObj = res.adminVMConfig;
          this.applianceModel = res.applianceDetailModel;
          this.getApplianceAdvancedData = res["adminVMConfig"]["adminVMData"]["advanced"]["staticIpToHostConfig"];
          for (var i = 0; i < this.getApplianceAdvancedData.length; i++) {
            this.applianceObjAdvanced.push(this.getApplianceAdvancedData[i]);
            this.applianceObjAdvancedDup.push(this.getApplianceAdvancedData[i]);
            // this.appAdd.push(this.getApplianceAdvancedData[i]);
          }
          // for (var i = 0; i < this.applianceObjAdvancedDup.length; i++) {
          //   this.applianceObjAdvancedDup[i]["color"] = "Green";
          // }
          if (this.applianceObj.adminVMData.advanced != null) {
            if (this.applianceObj.adminVMData.advanced.dnsServers != null) {
              let dnsServers = this.applianceObj.adminVMData.advanced.dnsServers;
              if (dnsServers.length > 0) {
                dnsServers.forEach(obj => {
                  this.dnsServerArray.push(obj);
                });
              } else {
                this.dnsServerArray = [];
              }
            }
            if (this.applianceObj.adminVMData.advanced.searchDomainNames != null) {
              let domainNames = this.applianceObj.adminVMData.advanced.searchDomainNames;
              if (domainNames.length > 0) {
                domainNames.forEach(obj => {
                  this.domainNameArray.push(obj);
                });
              } else {
                this.domainNameArray = [];
              }
            }
            if (this.applianceObj.adminVMData.advanced.enableDNSService) {
              this.isDNSserverChecked = false;
            }
            if (this.applianceObj.adminVMData.advanced.enableDNSService) {
              this.form.get("dnsService").setValue(true);
            } else {
              this.form.get("dnsService").setValue(false);
            }

          }
          this.staticHostIpLength = this.appAdd.length;
          this.dnsServerLength = this.dnsServerArray.length;
          this.domainNameLength = this.domainNameArray.length;
          this.form.get("ipAddress").setValue(this.applianceObj.adminVMData.general.ip);
          this.form.get("gatewayIp").setValue(this.applianceObj.adminVMData.general.gateway);
          this.form.get("subnetMask").setValue(this.applianceObj.adminVMData.general.subnet);
          if (this.applianceObj.adminVMData.general.hostname == "null") {
            this.form.get("hostName").setValue('');
          }
          else {
            this.form.get("hostName").setValue(this.applianceObj.adminVMData.general.hostname ? this.applianceObj.adminVMData.general.hostname : '');
          }
          this.form.get("vLanId").setValue(this.applianceObj.adminVMData.general.vlan);
          this.form.get("macAddress").setValue(this.applianceObj.adminVMData.general.macAddress);
          this.form.get("dhcp").setValue(this.applianceObj.adminVMData.general.dhcp);

          this.form.get("staticMac").setValue(true);
        },
        error => {
          console.log(error);
        },
      );

      setTimeout(function () { $("#NetworkModal").modal("show"); }, 500);
    }
    if (this.applianceModel.credentialSaved == false) {
      if (loginCredentials != null) {
        this.loginForm.get('username').setValue(loginCredentials.username);
        this.loginForm.get('password').setValue(loginCredentials.password);
        this.noLoginPop = true;
      }
      if (this.noLoginPop) {
        this.loading = true;
        this._applianceManagementService.getAdminNetworkInfoData(this.applianceModel.applianceId).subscribe(
          res => {
            this.loading = false;
            $("#myModal").modal("hide");
            this.applianceObj = res.adminVMConfig;
            this.applianceModel = res.applianceDetailModel;
            if (res["adminVMConfig"] != null || res["adminVMConfig"] != undefined) {
              if (res["adminVMConfig"]["adminVMData"] != null || res["adminVMConfig"]["adminVMData"] != undefined) {
                this.getApplianceAdvancedData = res["adminVMConfig"]["adminVMData"]["advanced"]["staticIpToHostConfig"];
              }
            }
            // this.applianceObj.adminVMData["advanced"]["staticIpToHostConfig"][0]
            for (var i = 0; i < this.getApplianceAdvancedData.length; i++) {
              this.applianceObjAdvanced.push(this.getApplianceAdvancedData[i]);
              this.applianceObjAdvancedDup.push(this.getApplianceAdvancedData[i]);
              //this.appAdd.push(this.getApplianceAdvancedData[i]);
            }
            // for (var i = 0; i < this.applianceObjAdvancedDup.length; i++) {
            //   this.applianceObjAdvancedDup[i]["color"] = "Green";
            // }
            if (this.applianceObj.adminVMData.advanced != null) {
              if (this.applianceObj.adminVMData.advanced.dnsServers != null) {
                let dnsServers = this.applianceObj.adminVMData.advanced.dnsServers;
                if (dnsServers.length > 0) {
                  dnsServers.forEach(obj => {
                    this.dnsServerArray.push(obj);
                  });
                } else {
                  this.dnsServerArray = [];
                }
              }
              if (this.applianceObj.adminVMData.advanced.searchDomainNames != null) {
                let domainNames = this.applianceObj.adminVMData.advanced.searchDomainNames;
                if (domainNames.length > 0) {
                  domainNames.forEach(obj => {
                    this.domainNameArray.push(obj);
                  });
                } else {
                  this.domainNameArray = [];
                }
              }
              if (this.applianceObj.adminVMData.advanced.enableDNSService) {
                this.isDNSserverChecked = false;
              }
              if (this.applianceObj.adminVMData.advanced.enableDNSService) {
                this.form.get("dnsService").setValue(true);
              } else {
                this.form.get("dnsService").setValue(false);
              }
            }
            this.staticHostIpLength = this.appAdd.length;
            this.dnsServerLength = this.dnsServerArray.length;
            this.domainNameLength = this.domainNameArray.length;
            this.form.get("ipAddress").setValue(this.applianceObj.adminVMData.general.ip);
            this.form.get("gatewayIp").setValue(this.applianceObj.adminVMData.general.gateway);
            this.form.get("subnetMask").setValue(this.applianceObj.adminVMData.general.subnet);
            if (this.applianceObj.adminVMData.general.hostname == "null") {
              this.form.get("hostName").setValue('');
            }
            else {
              this.form.get("hostName").setValue(this.applianceObj.adminVMData.general.hostname ? this.applianceObj.adminVMData.general.hostname : '');
            }
            this.form.get("vLanId").setValue(this.applianceObj.adminVMData.general.vlan);
            this.form.get("macAddress").setValue(this.applianceObj.adminVMData.general.macAddress);
            this.form.get("dhcp").setValue(this.applianceObj.adminVMData.general.dhcp);
            this.form.get("staticMac").setValue(true);
            setTimeout(function () { $("#NetworkModal").modal("show"); }, 500);
          },
          error => {
            console.log(error);
          },
        );

      }
      else {
        this.applianceDualFactorInitialized=this.applianceModel['applianceDualFactorInitialized'];
        this.setValidationDualFactorAuthentication();
        $("#myModal").modal("show");
      }
    }
  }

  setDualFactorData(loginDetailsModal) {
    loginDetailsModal['initializeDetailModel'] = {};
    loginDetailsModal['initializeDetailModel']['cryptoOfficerName'] = this.loginForm.get('username').value;
    loginDetailsModal['initializeDetailModel']['cryptoOfficerPassword'] = this.loginForm.get('password').value;
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel'] = {};

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['dualFactorAuthServerPortNo'] = this.loginForm.get('dualFactorAuthServerPortNo').value;
    // certificate file details
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateContent'] = this.loginForm.get('certificateContent').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateName'] = this.loginForm.get('certificateName').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateExtension'] = this.loginForm.get('certificateExtension').value;
    // key file details
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileContent'] = this.loginForm.get('keyfileContent').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileName'] = this.loginForm.get('keyfileName').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileExtension'] = this.loginForm.get('keyfileExtension').value;
    return loginDetailsModal;
  }

  setValidationDualFactorAuthentication() {
    // set validations for dual factor properties 
    if (this.applianceDualFactorInitialized) {
      this.loginForm.get('dualFactorAuthServerPortNo').setValidators([Validators.required,CommonValidator.isNumberCheck]);
      this.loginForm.get('certificateFile').setValidators(Validators.required);
      this.loginForm.get('keyFile').setValidators(Validators.required);
    } else {
      this.loginForm.get('dualFactorAuthServerPortNo').setValidators(null);
      this.loginForm.get('certificateFile').setValidators(null);
      this.loginForm.get('keyFile').setValidators(null);
    }
    this.loginForm.get('dualFactorAuthServerPortNo').updateValueAndValidity();
    this.loginForm.get('certificateFile').updateValueAndValidity();
    this.loginForm.get('keyFile').updateValueAndValidity();
  }

  setRequiredFields() {
    this.form.get("ipAddress").enable();
    this.form.get("gatewayIp").enable();
    this.form.get("subnetMask").enable();
    this.form.get("ipAddress").clearValidators();
    this.form.get("gatewayIp").clearValidators();
    this.form.get("subnetMask").clearValidators();
    this.form.get("ipAddress").setValidators([Validators.required, Validators.compose([CommonValidator.ipAddressValidator])]);
    this.form.get("gatewayIp").setValidators([Validators.compose([CommonValidator.ipAddressValidator])]);
    this.form.get("subnetMask").setValidators([Validators.compose([CommonValidator.ipAddressValidator])]);
    this.form.get("macAddress").setValidators([Validators.required, Validators.compose([CommonValidator.macAddressValidator])]);
    this.form.get("hostName").setValidators([Validators.compose([CommonValidator.hostNameValidator])]);
    this.form.get('ipAddress').updateValueAndValidity();
    this.form.get('gatewayIp').updateValueAndValidity();
    this.form.get('subnetMask').updateValueAndValidity();
    this.form.get('macAddress').updateValueAndValidity();
  }

  submitData() {
    if (this.form.valid) {
      if (this.applianceModel != null && this.applianceObj.adminVMData != null) {
        for (var i = 0; i < this.appAdd.length; i++) {
          this.staticIpToHostConfigUpdated.push(this.appAdd[i]);
        }
        this.submitApplianceNewtorkData = {
          "general": {},
        }
        this.submitApplianceNewtorkData['username'] = this.loginForm.get("username").value;
        this.submitApplianceNewtorkData['password'] = this.loginForm.get("password").value;
        this.submitApplianceNewtorkData['applianceId'] = this.applianceModel.applianceId;
        this.submitApplianceNewtorkData['applianceIp'] = this.applianceModel.ipAddress;
        this.submitApplianceNewtorkData['general']['ip'] = this.form.get("ipAddress").value;
        this.submitApplianceNewtorkData['general']['dhcp'] = this.form.get("dhcp").value;
        this.submitApplianceNewtorkData['general']['gateway'] = this.form.get("gatewayIp").value;
        this.submitApplianceNewtorkData['general']['subnet'] = this.form.get("subnetMask").value;
        this.submitApplianceNewtorkData['general']['hostname'] = this.form.get("hostName").value;
        this.submitApplianceNewtorkData['general']['vlan'] = this.form.get("vLanId").value;
        this.submitApplianceNewtorkData['general']['macAddress'] = this.form.get("macAddress").value;
        this.submitApplianceNewtorkData['general']['macStatic'] = this.form.get("staticMac").value;
        let advanced = {};
        let showAdvanced: boolean = false;
        if (this.staticIpToHostConfigUpdated.length > this.staticHostIpLength) {
          showAdvanced = true;
          advanced['staticIpToHostConfig'] = this.staticIpToHostConfigUpdated;
        }
        if (this.dnsServerArray.length !== this.dnsServerLength) {
          showAdvanced = true;
          advanced['dnsServers'] = this.dnsServerArray;
        }
        if (this.domainNameArray.length !== this.domainNameLength) {
          showAdvanced = true;
          advanced['searchDomainNames'] = this.domainNameArray;
        }
        if (this.removeStaticIps.length > 0) {
          showAdvanced = true;
          advanced['removedHostIPs'] = this.removeStaticIps;
        }

        if (showAdvanced) {
          advanced['enableDNSService'] = this.form.get("dnsService").value;
          this.submitApplianceNewtorkData['advanced'] = advanced;
        }
        // this.submitApplianceNewtorkData = {
        //   "username": this.loginForm.get("username").value,
        //   "applianceId": this.applianceModel.applianceId,
        //   "password": this.loginForm.get("password").value,
        //   "applianceIp": this.applianceModel.ipAddress,
        //   "advanced": {
        //     "searchDomainNames": this.domainNameArray,
        //     "dnsServers": this.dnsServerArray,
        //     "removedHostIPs": this.applianceObj.adminVMData.advanced.removedHostIPs,
        //     "staticIpToHostConfig": this.staticIpToHostConfigUpdated,
        //     "enableDNSService": this.form.get("dnsService").value
        //   },
        //   "general": {
        //     "ip": this.form.get("ipAddress").value, "dhcp": this.form.get("dhcp").value,
        //     "gateway": this.form.get("gatewayIp").value, "subnet": this.form.get("subnetMask").value,
        //     "hostname": this.form.get("hostName").value, "vlan": parseInt(this.form.get("vLanId").value),
        //     "macAddress": this.form.get("macAddress").value, "macStatic": this.form.get("staticMac").value,
        //   }
        // }

        this.loading = true;
        this._applianceManagementService.networkSettingsDataSubmit(this.submitApplianceNewtorkData).subscribe(
          data => this.onSuccessOperation(data),
          err => this.onErrorOperation(err)
        )

         
      }
      else {
        this.loading = false;
        $("#NetworkModal").modal("hide");
        bootbox.alert("Device is Unreachable ! Please try again sometime.");
      }
    } else {
      this.loading = false;
      this.formerrors = this._fieldErrorDisplayService.validateForm(this.form, this.formerrors, "networkSettings", false);
      // console.log(this.formerrors);
    }

  }
  addAdvancedData() {
    this.displayError = '';
    let ip = this.form.get('ip').value;
    let hostname = this.form.get('hostname').value;
    let alias = this.form.get('alias').value;
    if (this.appAdd.length < 16) {
      if (ip != null && ip != '' && hostname != null && hostname != '') {
        let flag = this.appAdd.some(e => e.ip == ip)
        if (!flag) {
          let staticIpmodel =
            {
              "ip": ip,
              "hostname": hostname,
              "alias": alias,
            };
          this.appAdd.push(staticIpmodel);
          this.applianceObjAdvanced.push(staticIpmodel);
          this.form.get('ip').reset();
          this.form.get('hostname').reset();
          this.form.get('alias').reset();
        } else {
          this.displayError = "Ip address is already exists"
        }
      } else {
        this.displayError = "Please enter the required fields"
      }
    } else {
      this.displayError = "Exceeds Maximum limit 16"
    }
  }
  delAddData(id) {
    for (var i = 0; i < this.applianceObjAdvanced.length; i++) {
      if (this.applianceObjAdvanced[i]["ip"] == id) {
        //this.appAdd.splice(i, 1);

        this.removeStaticIps.push(this.applianceObjAdvanced[i]["ip"]);
        this.applianceObjAdvanced.splice(i, 1);
      }
    }
  }
  addDnsServer() {
    if (this.isValidIp3 == true) {

      this.displayError = '';
      if (this.dnsServerArray.length < 4) {
        let dnsServer = this.form.get('dnsServer').value;
        if (dnsServer != null && dnsServer != '') {
          let flag = this.dnsServerArray.some(e => e == dnsServer);
          if (!flag) {
            this.dnsServerArray.push(dnsServer);
            this.form.get('dnsServer').reset();
          } else {
            this.displayError = "DNS Server is already exists"
          }
        } else {
          this.displayError = "Please enter the required fields"
        }
      } else {
        this.displayError = "Exceeds Maximum limit 4"
      }
    }
    else {
      let message = "Please enter correct DNS Server"
      bootbox.dialog({
        message: message,
        buttons: {
          Ok: {
            label: "Close",
            className: 'btn btn-primary btn-flat',

          }
        }
      });
    }

 }

  removeDnsServers(index) {
    this.dnsServerArray.splice(index, 1);
  }

  addDomainName() {
    this.displayError = '';
    if (this.isValidHostname3 == true) {
      if (this.domainNameArray.length < 4) {
        let domainName = this.form.get('searchDomainName').value;
        if (domainName != null && domainName != '') {
          let flag = this.domainNameArray.some(e => e == domainName);
          if (!flag) {
            this.domainNameArray.push(domainName);
            this.form.get('searchDomainName').reset();
          } else {
            this.displayError = "Domain Name is already exists"
          }
        } else {
          this.displayError = "Please enter the required fields"
        }
      } else {
        this.displayError = "Exceeds Maximum limit 4"
      }
    }
    else {
      let message = "Please enter correct Domain Name"
      bootbox.dialog({
        message: message,
        buttons: {
          Ok: {
            label: "Close",
            className: 'btn btn-primary btn-flat',

          }
        }
      });
    }

  }

  removeSearchDomain(index) {
    this.domainNameArray.splice(index, 1);
  }
  onSuccessOperation(response) {
    this.loading = false;
    $("#myModal").modal("hide");
    if (this.saveModalFlag == false) {
      $("#NetworkModal").modal("hide");
    }
    // this.loading = false;
    this.successMessage = response.responseMessage;
    this.errorMessages = [];
    this.staticIpToHostConfigUpdated = [];
    this.submitApplianceNewtorkData = {};
    this.appAdd = [];
    let res = response;

    bootbox.dialog({
      message: this.successMessage,
      buttons: {

        Ok: {
          label: "Close",
          className: 'btn btn-primary btn-flat',
          callback: () => this.redirectToListAppliance()

        }
      }
    });
    this.saveModalFlag = false;
    this.staticIpToHostConfigUpdated = [];
    this.successMessage = '';
  }
  redirectToListAppliance() {
    this._router.navigate(['/listAppliance']);
  }
  submitNetworkSaveToDB() {
    this.tab = "1";
    this.classStatic = "btn-primary";
    this.classServer = "btn-default";
    this.classDomain = "btn-default";
    // this.submitApplianceLoginData = [{
    //   "operationUsername": this.loginForm.get("username").value,
    //   "operationPassword": this.loginForm.get("password").value,
    //   "ipAddress": this.applianceModel["ipAddress"]
    // }];
    let loginDetailsModal = {};
    loginDetailsModal['ipAddress'] = this.applianceModel.ipAddress;
    loginDetailsModal['applianceDualFactorInitialized'] = this.applianceModel.applianceDualFactorInitialized;
    loginDetailsModal['operationUsername'] = this.loginForm.get('username').value;
    loginDetailsModal['operationPassword'] = this.loginForm.get('password').value;
    let dualFactorCheck = this.applianceModel.applianceDualFactorInitialized;
    if(dualFactorCheck){
      loginDetailsModal=this.setDualFactorData(loginDetailsModal);
    }
    this.submitApplianceLoginData.push(loginDetailsModal);
    $("#myModal").modal("hide");
    if(this.applianceDualFactorInitialized){
      this.certificateVariable.nativeElement.value = '';
      this.keyVariable.nativeElement.value = "";
    }
    this.loading = true;
    this._applianceManagementService.checkAppliancesCredentials(this.submitApplianceLoginData).subscribe(
      res => {
        this.loading = false;
        let respData = res;
        if (respData != null) {
          if (res[0]["code"] == 200) {
            // Storing appliance login credentials in local session
            let ipAddress = res[0].ipAddress;
            let loginCredentials = {
              username: this.loginForm.get('username').value,
              password: this.loginForm.get('password').value
            };
            localStorage.setItem(ipAddress, JSON.stringify(loginCredentials));
            // local session code ends here
            this.loading = true;
            this._applianceManagementService.getAdminNetworkInfoData(this.applianceModel.applianceId).subscribe(
              res => {
                this.loading = false;
                this.applianceObj = res.adminVMConfig;
                this.applianceModel = res.applianceDetailModel;
                this.getApplianceAdvancedData = res["adminVMConfig"]["adminVMData"]["advanced"]["staticIpToHostConfig"];
                // this.applianceObj.adminVMData["advanced"]["staticIpToHostConfig"][0]
                for (var i = 0; i < this.getApplianceAdvancedData.length; i++) {
                  this.applianceObjAdvanced.push(this.getApplianceAdvancedData[i]);
                  this.applianceObjAdvancedDup.push(this.getApplianceAdvancedData[i]);
                  // this.appAdd.push(this.getApplianceAdvancedData[i]);
                }
                // for (var i = 0; i < this.applianceObjAdvancedDup.length; i++) {
                //   this.applianceObjAdvancedDup[i]["color"] = "Green";
                // }
                if (this.applianceObj.adminVMData.advanced != null) {
                  if (this.applianceObj.adminVMData.advanced.dnsServers != null) {
                    let dnsServers = this.applianceObj.adminVMData.advanced.dnsServers;
                    if (dnsServers.length > 0) {
                      dnsServers.forEach(obj => {
                        this.dnsServerArray.push(obj);
                      });
                    } else {
                      this.dnsServerArray = [];
                    }
                  }
                  if (this.applianceObj.adminVMData.advanced.searchDomainNames != null) {
                    let domainNames = this.applianceObj.adminVMData.advanced.searchDomainNames;
                    if (domainNames.length > 0) {
                      domainNames.forEach(obj => {
                        this.domainNameArray.push(obj);
                      });
                    } else {
                      this.domainNameArray = [];
                    }
                  }
                  if (this.applianceObj.adminVMData.advanced.enableDNSService) {
                    this.isDNSserverChecked = false;
                  }
                  if (this.applianceObj.adminVMData.advanced.enableDNSService) {
                    this.form.get("dnsService").setValue(true);
                  } else {
                    this.form.get("dnsService").setValue(false);
                  }
                }
                this.staticHostIpLength = this.appAdd.length;
                this.dnsServerLength = this.dnsServerArray.length;
                this.domainNameLength = this.domainNameArray.length;
                this.form.get("ipAddress").setValue(this.applianceObj.adminVMData.general.ip);
                this.form.get("gatewayIp").setValue(this.applianceObj.adminVMData.general.gateway);
                this.form.get("subnetMask").setValue(this.applianceObj.adminVMData.general.subnet);
                if (this.applianceObj.adminVMData.general.hostname == "null") {
                  this.form.get("hostName").setValue('');
                }
                else {
                  this.form.get("hostName").setValue(this.applianceObj.adminVMData.general.hostname ? this.applianceObj.adminVMData.general.hostname : '');
                }
                this.form.get("vLanId").setValue(this.applianceObj.adminVMData.general.vlan);
                this.form.get("macAddress").setValue(this.applianceObj.adminVMData.general.macAddress);
                this.form.get("dhcp").setValue(this.applianceObj.adminVMData.general.dhcp);
                this.form.get("staticMac").setValue(true);
                setTimeout(function () { $("#NetworkModal").modal("show"); }, 500);
              },
              error => {
                this.loading = false;
                console.log(error);
              },
            );
          }
          else {
            this.loginForm.reset();
            this.loading = false;
            let message = res[0]["errorMessage"];
            $("#myModal").modal("hide");
            bootbox.alert({
              message: message,
              callback: function () {
                message = "";
              }
            })
          }
        }
        else {
          this.loading = false;
          this.loginForm.reset();
          bootbox.alert("Please enter valid credentials");
        }
      }
    )
  }
  onErrorOperation(errResp) {
    this.loading = false;
    $("#myModal").modal("hide");
  }

  closeLoginModal() {
    this.loginForm.reset();
    $("#myModal").modal("hide");
  }

  closeModal() {
    $("#NetworkModal").modal("hide");
    this.loginForm.reset();
    this.successMessage = '';
    this.errorMessages = [];
    this.applianceObjAdvancedDup = [];
    this.appAdd = [];
    this.noLoginPop = false;
    this.form.reset();
    this.isValidIp3 = true;
    this.isValidHostname3 = true;
    this.isValidIp = true;
    this.isValidgatewayIp = true;
    this.isValidsubnetmaskIP = true;
    this.isValidmacAddress = true;
    this.applianceObjAdvancedDup = [];
    this.appAdd = [];
    this.domainNameArray = [];
    this.dnsServerArray = [];
    this.displayError = '';
    this.submitApplianceNewtorkData = {};
  }

  toggleMacAddressEth0(event) {
    if (event.checked) {
      this.form.get("macAddress").setValidators([Validators.required, Validators.pattern(this.macaddressValidator)]);
      this.form.get('macAddress').enable();
    } else {
      this.form.get("macAddress").clearValidators();
      this.form.get('macAddress').disable();
    }
    this.form.get("macAddress").updateValueAndValidity();
  }

  setValueReset(event, value) {
    if (event.checked) {
      this.form.get("ipAddress").clearValidators();
      this.form.get("gatewayIp").clearValidators();
      this.form.get("subnetMask").clearValidators();
      this.form.get("ipAddress").disable();
      this.form.get("gatewayIp").disable();
      this.form.get("subnetMask").disable();

    } else {
      this.form.get("ipAddress").enable();
      this.form.get("gatewayIp").enable();
      this.form.get("subnetMask").enable();
      this.form.get("ipAddress").setValidators([Validators.required, Validators.pattern(this.IpValidator)]);
      this.form.get("gatewayIp").setValidators([Validators.pattern(this.IpValidator)]);
      this.form.get("subnetMask").setValidators([Validators.pattern(this.IpValidator)]);
    }
    this.form.get("ipAddress").updateValueAndValidity();
    this.form.get("gatewayIp").updateValueAndValidity();
    this.form.get("subnetMask").updateValueAndValidity();

  }

  isValidIp = true;
  ValidateIPaddress(inputText) {
    this.isValidIp = true;
    var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    if (inputText != '') {
      if (inputText.match(ipformat)) {
        this.isValidIp = true;
      }
      else {
        this.isValidIp = false;
      }
    }
  }

  isValidgatewayIp = true;
  ValidategatewayIP(inputText) {
    this.isValidgatewayIp = true;
    var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    if (inputText != '') {
      if (inputText.match(ipformat)) {
        this.isValidgatewayIp = true;
      }
      else {
        this.isValidgatewayIp = false;
      }
    }
  }

  isValidsubnetmaskIP = true;
  ValidateSubnetMaskIp(inputText) {
    this.isValidsubnetmaskIP = true;
    var subnetIp = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    if (inputText != '') {
      if (inputText.match(subnetIp)) {
        this.isValidsubnetmaskIP = true;
      }
      else {
        this.isValidsubnetmaskIP = false;
      }
    }
  }

  isValidmacAddress = true;
  ValidatMacAddress(inputText) {
    this.isValidmacAddress = true;
    var macaddress = /^[a-fA-F0-9:]{17}|[a-fA-F0-9]{12}$/;
    var form = document.getElementById('form1');
    if (inputText != '') {
      if (inputText.match(macaddress)) {
        this.isValidmacAddress = true;
      }
      else {
        this.isValidmacAddress = false;
      }
    }
  }
  // isValidmacAddress1=true;
  // ValidatMacAddress1(inputText){
  //   this.isValidmacAddress1 = true;
  //   var macaddress= /^[a-fA-F0-9:]{17}|[a-fA-F0-9]{12}$/;
  //   var form = document.getElementById('form1');
  //   if (inputText != '') {
  //     if (inputText.match(macaddress)) {
  //       this.isValidmacAddress1 = true;
  //     }
  //     else {
  //       this.isValidmacAddress1 = false;    
  //     }
  //   }
  // }

  isValidHostname = true;
  ValidateHostname(inputText) {
    this.isValidHostname = true;
    var hostname = /^[0-9a-zA-Z-]+$/;
    var form = document.getElementById('form1');
    if (inputText != '') {
      if (inputText.match(hostname)) {
        this.isValidHostname = true;
      }
      else {
        this.isValidHostname = false;
      }
    }
 }

  isValidHostname1 = true;
  ValidateHostname1(inputText) {
    this.isValidHostname1 = true;
    var ipformat = "^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\\-]*[a-zA-Z0-9])\\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9\\-]*[A-Za-z0-9])$";
    var form = document.getElementById('form1');
    var x;
    x = (<HTMLInputElement>document.getElementById("hostName1")).value;
    if (x.match("^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\\-]*[a-zA-Z0-9])\\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9\\-]*[A-Za-z0-9])$")) {
      this.isValidHostname1 = true;
    }
    else {
      this.isValidHostname1 = false;
    }
  }
  ValidateHostname3(inputText) {
    this.isValidHostname3 = true;
    var hostname = /^(?!:\/\/)([a-zA-Z0-9-_]+\.)*[a-zA-Z0-9][a-zA-Z0-9-_]+\.[a-zA-Z]{2,11}?$/;
    var form = document.getElementById('form1');
    if (inputText != '') {
      if (inputText.match(hostname)) {
        this.isValidHostname3 = true;
      }
      else {
        this.isValidHostname3 = false;
      }
    }
  }

  isValidIp1 = true;
  ValidateIPaddress1(inputText) {
    var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    var form = document.getElementById('form1');
    var x;
    x = (<HTMLInputElement>document.getElementById("ip1")).value;
    if (x.match(/^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/)) {
      this.isValidIp1 = true;
    }
    else {
      this.isValidIp1 = false;
    }
  }

  public OnlyNumericValues(e) {
    let input;
    if (e.metaKey || e.ctrlKey) {
      return true;
    }
    if (e.which === 32) {
      return false;
    }
    if (e.which === 0) {
      return true;
    }
    if (e.which < 33) {
      return true;
    }
    input = String.fromCharCode(e.which);
    return !!/[\d\s]/.test(input);
  }
  tab: string;
  selectTab(tab_id: string) {
    this.displayError = '';
    if (tab_id == "1") {
      this.classStatic = "btn-primary";
      this.classServer = "btn-default";
      this.classDomain = "btn-default";
    } else if (tab_id == "2") {
      this.classStatic = "btn-default";
      this.classServer = "btn-primary";
      this.classDomain = "btn-default";
    } else if (tab_id == "3") {
      this.classStatic = "btn-default";
      this.classServer = "btn-default";
      this.classDomain = "btn-primary";
    }
    this.tab = tab_id;
    //this.displayError = "";
  }
  isDNSserverChecked: boolean = false;
  disableDNSserver(event) {
    if (event.checked) {
      this.isDNSserverChecked = false;
    } else {
      this.isDNSserverChecked = true;
    }

  }
  validateIPaddress3(inputText) {

    this.isValidIp3 = true;
    var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    // var form = document.getElementById('form1');
    // var x;
    // x = (<HTMLInputElement>document.getElementById("ip")).value;
    if (inputText != '') {
      if (inputText.match(ipformat)) {
        this.isValidIp3 = true;
      }
      else {
        this.isValidIp3 = false;
      }
    }
  }

  onCertificateFileChange($event) {
    this.loginForm.get('certificateFile').markAsTouched({ onlySelf: true });
    let file = $event.target.files[0]; 
    this.loginForm.controls['certificateFile'].setValue(file ? file.name : ''); // <-- Set Value for Validation
    const filePicked = (event.target as HTMLInputElement).files[0];
    if (filePicked != undefined) {
      const fileName = filePicked.name;
      const extension = filePicked.name.split('.').pop() || '';
      const reader = new FileReader();
      reader.onload = () => {
        if (extension == 'crt') {
          this.loginForm.get('certificateContent').setValue(reader.result);
          this.loginForm.get('certificateName').setValue(fileName.substring(0, fileName.indexOf('.')));
          this.loginForm.get('certificateExtension').setValue(extension);
        } else {
          this.loginForm.get('certificateFile').setErrors({"invalidExt":true})
         
        }
      };
      reader.readAsText(filePicked);
    } else {
      this.loginForm.get('certificateFile').setValue("");
      this.loginForm.get('certificateContent').setValue("");
      this.loginForm.get('certificateName').setValue("");
      this.loginForm.get('certificateExtension').setValue("");
      return false;
    }
  } 

  onKeyFileChange($event) {
    this.loginForm.controls['keyFile'].markAsTouched({ onlySelf: true });
    let file = $event.target.files[0]; 
    this.loginForm.controls['keyFile'].setValue(file ? file.name : ''); // <-- Set Value for Validation
    const filePicked = (event.target as HTMLInputElement).files[0];
    if (filePicked != undefined) {
      const fileName = filePicked.name;
      let ext  = filePicked.name.split('.');
      const extension =  ext[1];
      const reader = new FileReader();
      reader.onload = () => {
        if (extension == 'key') {
          this.loginForm.get('keyfileContent').setValue(reader.result);
          this.loginForm.get('keyfileName').setValue(fileName.substring(0, fileName.indexOf('.')));
          this.loginForm.get('keyfileExtension').setValue(extension);
        } else {
          this.loginForm.get('keyFile').setErrors({"invalidExt":true})
         
        }
      };
      reader.readAsText(filePicked);
    } else {
      this.loginForm.get('keyFile').setValue("");
      this.loginForm.get('keyfileContent').setValue("");
      this.loginForm.get('keyfileName').setValue("");
      this.loginForm.get('keyfileExtension').setValue("");
      return false;
    }
  } 
    
}


