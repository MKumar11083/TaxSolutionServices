import { Component, OnInit, Input, ViewChild, OnDestroy } from '@angular/core';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { forkJoin } from "rxjs/observable/forkJoin";
import { AdminvmmonitorComponent } from './../../appliancemanagement/adminvmmonitor/adminvmmonitor.component';
import { SnmpConfigureComponent } from './../../appliancemanagement/snmp-configure/snmp-configure.component';
import { ActivatedRoute } from '@angular/router';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, FormControl, FormArray, AbstractControl } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { AdminVmnetworkSettingsComponent } from './../../appliancemanagement/admin-vm/admin-vmnetwork-settings/admin-vmnetwork-settings.component';
import { AnonymousSubscription } from "rxjs/Subscription";
import { Observable } from "rxjs/Observable";
import { BaseChartDirective } from 'ng2-charts/ng2-charts';
import { DataTableResource } from './../../data-table/index';
declare var $: any;
declare var bootbox: any;
@Component({
  selector: 'app-admin-vm',
  templateUrl: './admin-vm.component.html',
  styleUrls: ['./admin-vm.component.css']
})
export class AdminVmComponent implements OnInit, OnDestroy {
  @ViewChild('processMemory')
  public processMemory: BaseChartDirective;
  @ViewChild('pcpu')
  public pcpu: BaseChartDirective;
  @ViewChild('cpu')
  public cpu: BaseChartDirective;
  @Input() applianceId;
  @Input() ip;

  @Input() applianceModel;
  @ViewChild('monitorComponent1')
  monitorComponent1: AdminvmmonitorComponent;
  @ViewChild('snmpConfigure')
  snmpConfigure: SnmpConfigureComponent;
  @ViewChild('selecterror')
  selecterror: ModalDirective;
  @ViewChild('networkSettings')
  networkSettings: AdminVmnetworkSettingsComponent
  successMessage = '';
  errorMessages = [];
  form: FormGroup;
  appAdd: object[] = [];
  loginForm: FormGroup;
  submitApplianceNewtorkData = {};
  submitApplianceLoginData: Array<any> = [];
  applianceObj: any;
  applianceObjAdvanced: object[] = [];
  applianceObjAdvancedDup: object[] = [];
  getApplianceAdvancedData: any = [];
  staticIpToHostConfigUpdated: object[] = [];
  saveModalFlag = false;
  ipAddressAdd: any;
  HostnameAdd: any;
  AliasAdd: any;
  stats: any = [];
  network: any = [];
  snmp: any = [];
  message: string;
  authMode:any;
  privMode:any;
  status: any = [];
  trapStatus: any = [];
  username: any = [];
  hostname: any = [];
  managerIp: any = [];
  applianceName: string;
  showlist: boolean = true;
  selfTestReport: string = '';
  selfTestRep: any = [];
  dnsServers: any = [];
  stringblank: string = "";
  stringblank1: string = "";
  searchDomainNames: any = [];
  staticIpToHostConfig: any = [];
  public loading = false;
  // adminVM gauge
  // gaugeLabe = 4;
  // gaugeLabe1 = 7;
  // gaugeLabel = 67;
  noLoginPop: boolean = false;
  logonCredentialsSavetoDb: Array<any> = [];
  loginCredentials: object[] = [];
  temp = [];
  temLocalStorage = [];
  driverStatus: string;
  gaugeColor4: any;
  gaugeColor5: any;
  gaugeColor6: any;
  gaugeColor7: any;
  gaugeValue4:number;
  gaugeValue5:number;
  gaugeValue6:number;
  gaugeValue7:number;
  gaugeType = "arch";
  gaugeThickness = 25;
  gaugeThresholdConfig = {
    '0': { color: 'rgb(0,179,30' },
    '60': { color: 'rgb(230,191,0' },
    '80': { color: 'rgb(204,0,0' }
  };
  gaugeAppendText = "%";
  originalProcessMemoryData = [];
  originalPcpuData = [];
  originalCpuData = [];
  itemResource: any;
  itemCount;
  itemResource1: any;
  itemCount1;
  itemResource2: any;
  itemCount2;
  constructor(private _applianceManagementService: AppliancemanagementService, private _route: ActivatedRoute, private builder: FormBuilder
    , private _fieldErrorDisplayService: FieldErrorDisplayService) { }

  ngOnInit() {
    //this.loading = true;

    if ("loginCredentials" in localStorage) {
      this.temLocalStorage.push(JSON.parse(localStorage.getItem("loginCredentials")));
      for (var i = 0; i < this.temLocalStorage.length; i++) {
        for (var j = 0; j < this.temLocalStorage[i].length; j++) {
          this.temp.push(this.temLocalStorage[i][j]);
        }
      }

    }
    this.applianceId = "";
    this._route.params.subscribe(params => {
      this.applianceId = params['applianceId'];
      this.applianceName = params['applianceName'];
    });
    this._applianceManagementService.getHostSystemInfo(this.applianceId).subscribe(
      res => {
        this.stats = res.hostStats;
        this.applianceModel = res.applianceDetailModel;
        if (this.applianceModel != null || this.applianceModel != undefined) {
          this.applianceModel["partitionDetailModels"] = null;
        }
      },
      error => {
        console.log(error);
      },
    );
    let adminVMInfo = this._applianceManagementService.getAdminVMInfo(this.applianceId);
    let adminMonitorStats = this._applianceManagementService.getAdminMonitorStats(this.applianceModel);
    forkJoin([adminVMInfo, adminMonitorStats]).subscribe(result => {
      this.setAdminVMInfo(result[0]);
      this.setAdminMonitorStats(result[1]);
    });

  }

  setAdminVMInfo(res) {
    this.stats = res.hostStats;
    if (this.stats != null) {
      if (this.stats.dataObject != null) {
        if (this.stats.dataObject.vmstatsObject != null) {
          this.gaugeValue4 = this.stats.dataObject.vmstatsObject.cpuUsage;
        }
      }
    }

    if(this.gaugeValue4 <= 30){
      this.gaugeColor4 = 'rgb(0,179,30)';
      }
    else if(this.gaugeValue4 > 30 && this.gaugeValue4 <= 60)  {
      this.gaugeColor4 = 'rgb(230,191,0)';
    }
    else if(this.gaugeValue4 > 60)  {
      this.gaugeColor4 = 'rgb(204,0,0)';
    }

    if (this.stats != null) {
      if (this.stats.dataObject != null) {
        if (this.stats.dataObject.vmstatsObject != null) {
          if (this.stats.dataObject.vmstatsObject.ramStats != null) {
            this.gaugeValue6 = this.stats.dataObject.vmstatsObject.ramStats.usedPercentage;
          }
        }
      }
    }

    if(this.gaugeValue6 <= 30){
      this.gaugeColor6 = 'rgb(0,179,30)';
      }
    else if(this.gaugeValue6 > 30 && this.gaugeValue6 <= 60)  {
      this.gaugeColor6 = 'rgb(230,191,0)';
    }
    else if(this.gaugeValue6 > 60)  {
      this.gaugeColor6 = 'rgb(204,0,0)';
    }

    if (this.stats != null) {
      if (this.stats.dataObject != null) {
        if (this.stats.dataObject.vmstatsObject != null) {
          if (this.stats.dataObject.vmstatsObject.diskSpace != null) {
            this.gaugeValue5 = this.stats.dataObject.vmstatsObject.diskSpace.usedPercentage;
          }
        }
      }
    }

    if(this.gaugeValue5 <= 30){
      this.gaugeColor5 = 'rgb(0,179,30)';
      }
    else if(this.gaugeValue5 > 30 && this.gaugeValue5 <= 60)  {
      this.gaugeColor5 = 'rgb(230,191,0)';
    }
    else if(this.gaugeValue5 > 60)  {
      this.gaugeColor5 = 'rgb(204,0,0)';
    }

    if (this.stats != null) {
      if (this.stats.dataObject != null) {
        if (this.stats.dataObject.vmstatsObject != null) {
          if (this.stats.dataObject.vmstatsObject.swapStats != null) {
            this.gaugeValue7 = this.stats.dataObject.vmstatsObject.swapStats.usedPercentage;
          }
        }
      }
    }

    if(this.gaugeValue7 <= 30){
      this.gaugeColor7 = 'rgb(0,179,30)';
      }
    else if(this.gaugeValue7 > 30 && this.gaugeValue7 <= 60)  {
      this.gaugeColor7 = 'rgb(230,191,0)';
    }
    else if(this.gaugeValue7 > 60)  {
      this.gaugeColor7 = 'rgb(204,0,0)';
    }

    if (this.stats != null) {
      if (this.stats.dataObject != null) {
        if (this.stats.dataObject.vmstatsObject != null) {
          if (this.stats.dataObject.vmstatsObject.driverStatusStr == "Up") {
            this.driverStatus = "Secure State";
          } else if (this.stats.dataObject.vmstatsObject.driverStatusStr == "Down") {
            this.driverStatus = "Insecure State";
          }
        }
      }
    }

    // network and snmp pane start
    this.network = res.adminVMConfig;
    if (this.network != null) {
      if (this.network.adminVMData != null) {
        if (this.network.adminVMData.general != null) {
          if (this.network.adminVMData.general.hostname == 'null') {
            this.hostname = '';
          }
          else {
            this.hostname = this.network.adminVMData.general.hostname;
          }
        }
        if (this.network.adminVMData.advanced != null) {
          if (this.network.adminVMData.advanced.dnsServers != null) {
            this.dnsServers = this.network.adminVMData.advanced.dnsServers;
          } if (this.dnsServers.length == 0) {
            this.stringblank = '--';
          }
          if (this.network.adminVMData.advanced.searchDomainNames != null) {
            this.searchDomainNames = this.network.adminVMData.advanced.searchDomainNames;
          } if (this.searchDomainNames.length == 0) {
            this.stringblank1 = '--';
          }
          if (this.network.adminVMData.advanced.staticIpToHostConfig != null) {
            this.staticIpToHostConfig = this.network.adminVMData.advanced.staticIpToHostConfig;
          }
        }
      }
    }

    this.snmp = res.adminSNMPConfig;

    if (this.snmp != null) {
      if (this.snmp.adminSNMPData != null) {
        if (this.snmp.adminSNMPData.uname == 'null') {
          this.username = '';
        }
        else {
          this.username = this.snmp.adminSNMPData.uname;
        }
      }
    }
    if (this.snmp != null) {
      if (this.snmp.adminSNMPData != null) {
        if (this.snmp.adminSNMPData.ip == 'null') {
          this.managerIp = '';
        }
        else {
          this.managerIp = this.snmp.adminSNMPData.ip;
        }
      }
    }

    if (this.snmp != null) {
      if (this.snmp.adminSNMPData != null) {
        if (this.snmp.adminSNMPData.enabled == false) {
          this.status = "Disabled";
        }
        else if (this.snmp.adminSNMPData.enabled == true) {
          this.status = "Enabled";
        }
      }
    }

    if (this.snmp != null) {
      if (this.snmp.adminSNMPData != null) {
        if (this.snmp.adminSNMPData.enableTrap == false) {
          this.trapStatus = "Disabled";
        }
        else if (this.snmp.adminSNMPData.enableTrap == true) {
          this.trapStatus = "Enabled";
        }
      }
    }

    if (this.snmp != null) {
      if (this.snmp.adminSNMPData != null) {
        if (this.snmp.adminSNMPData.authMode != null) {
        if (this.snmp.adminSNMPData.authMode.encryption != "null") {
          this.authMode = this.snmp.adminSNMPData.authMode.encryption;
        }
        else if (this.snmp.adminSNMPData.authMode.encryption == "null") {
          this.authMode = '';
        }
      }
     }
    }

    if (this.snmp != null) {
      if (this.snmp.adminSNMPData != null) {
        if (this.snmp.adminSNMPData.privMode != null) {
        if (this.snmp.adminSNMPData.privMode.encryption != "null") {
          this.privMode = this.snmp.adminSNMPData.privMode.encryption;
        }
        else if (this.snmp.adminSNMPData.privMode.encryption == "null") {
          this.privMode = '';
        }
      }
     }
    }
    this.reloadAdminVMInfo();
  }

  timer: AnonymousSubscription;
  timerSubs: AnonymousSubscription;
  reloadAdminVMInfo() {
    this.timer = Observable.timer(10000).first().subscribe(() => this.getAdminVMInfoDetails());
  }
  getAdminVMInfoDetails() {
    this.timerSubs= this._applianceManagementService.getAdminVMInfo(this.applianceId).subscribe(
      res => {
        this.setAdminVMInfo(res);
      }, error => {
        console.error(error);
      })
  }


  public processUsageTableList: any = [];
  public monitorStatMap = new Map<string, Array<string>>();
  public processUsageChartData: Array<any> = [];
  public processMemoryLabel: Array<any> = [];
  public hoursMinutes: Array<any> = [];
  public memoryUsageChartData: Array<any> = [];
  public memoryUsageTableData: Array<any> = [];
  public networkEth0ChartData: Array<any> = [];
  public networkEth1ChartData: Array<any> = [];
  public networkEth0TableData: Array<any> = [];
  public memoryLabelList = ['buffers', 'cache', 'free', 'shared', 'used']
  public networkLableList = ["incoming", "outgoing"];
  cpuDataMap = new Map<string, Array<string>>();
  pcpuDataMap = new Map<string, Array<string>>();
  public cpuLabel: Array<any> = [];
  public pcpuLabel: Array<any> = [];
  cpuDataList: any = [];
  pcpuDataList: any = [];
  public pcpuChartData: Array<any> = [];
  public cpuChartData: Array<any> = [];
  setAdminMonitorStats(response: any) {
    this.processUsageTableList = [];
    this.monitorStatMap = new Map<string, Array<string>>();
    this.processUsageChartData = [];
    this.processMemoryLabel = [];
    this.originalProcessMemoryData=[];
    this.originalPcpuData=[];
    this.originalCpuData = [];
    // this.hoursMinutes = [];
    this.hoursMinutes.length = 0;
    this.memoryUsageChartData = [];
    this.memoryUsageTableData = [];
    this.networkEth0ChartData = [];
    this.networkEth1ChartData = [];
    this.cpuDataList = [];
    this.pcpuDataList = [];
    this.cpuChartData = [];
    this.pcpuChartData = [];
    let timeLabel = response.map(item => item["hoursminutes"]);
    timeLabel.sort((a, b) => { 
      a-b
    });
    setTimeout( () => {
      this.hoursMinutes =timeLabel;
    });
    
    this.getMemoryUsageDetails(response);
    this.getProcessMemoryStats(response);
    this.getNetworkEth0(response);
    this.getNetworkEth1(response);
    this.getCPUDetaills(response);
    this.getPCPUDetails(response);
    this.reloadAdminMonitorStats();
  }

  timerAdminMonitorStats: AnonymousSubscription;
  timerAdminMonitorStatsSubs: AnonymousSubscription;
  reloadAdminMonitorStats() {
    this.timerAdminMonitorStats = Observable.timer(10000).first().subscribe(() => this.getTimerAdminMonitorStats());
  }

  getTimerAdminMonitorStats() {
    this.timerAdminMonitorStatsSubs = this._applianceManagementService.getAdminMonitorStats(this.applianceModel).subscribe(
      res => {
        this.setAdminMonitorStats(res);
      }, error => {
        console.error(error);
      })
  }

  // Memory Usage
  getMemoryUsageDetails(response) {
    this.memoryUsageChartData = new Array<any>();
    this.memoryUsageTableData = new Array<any>();
    let memoryUsage = response.map(item => {
      if (item["usage"] != null) {
        return item["usage"];
      }
    });
    if (memoryUsage.length > 0) {

      for (var i = 0; i < this.memoryLabelList.length; i++) {
        if (memoryUsage[i] != undefined) {
          let memoryUsageModel = {};
          memoryUsageModel['data'] = memoryUsage.map(item => item[0][this.memoryLabelList[i]]);
          memoryUsageModel['label'] = this.memoryLabelList[i];
          this.memoryUsageChartData.push(memoryUsageModel);
        }
      }
      if (memoryUsage[memoryUsage.length - 1] != undefined) {
        this.memoryUsageTableData.push(memoryUsage[memoryUsage.length - 1][0])
        this.memoryUsageTableData.push(memoryUsage[memoryUsage.length - 1][1])
      }
    }
  }
  //  Process Memory Usage
  getProcessMemoryStats(res) {
    let memoryStatDetails = res.map(item => item["details"]);
    memoryStatDetails.forEach(element => {
      if (element != null) {
        element.forEach(processMemory => {
          if (this.monitorStatMap.get(processMemory.pid)) {
            let processMemoryArray = this.monitorStatMap.get(processMemory.pid);
            processMemoryArray.push(processMemory);
            this.monitorStatMap.set(processMemory.pid, processMemoryArray);
          } else {
            let processMemoryArray = [];
            processMemoryArray.push(processMemory);
            this.monitorStatMap.set(processMemory.pid, processMemoryArray);
          }
        });
      }

    });
    if (this.monitorStatMap.size > 0) {
      let pids = Array.from(this.monitorStatMap.keys());
      // this.processMemoryLabel = this.hoursMinutes;
      pids.forEach(pid => {
        if (this.monitorStatMap.has(pid)) {
          let memory = {};
          let memoryStatArray: Array<any> = [];
          memoryStatArray = this.monitorStatMap.get(pid);
          let memoryArray: Array<any> = [];
          memoryStatArray.forEach(element => {
            memoryArray.push(element['mem']);
          });
          this.processUsageTableList.push(memoryStatArray[memoryStatArray.length - 1]);
          this.itemResource1 = new DataTableResource(this.processUsageTableList);
          this.itemCount1 = this.processUsageTableList.length;
          memory['data'] = memoryArray;
          memory['label'] = pid;
          memory['fill'] = false;
          memory['backgroundColor'] = this.dynamicColors();
          memory['borderColor'] = this.dynamicColors();
          memory['pointBackgroundColor'] = memory['borderColor'],
            memory['pointBorderColor'] = '#fff',
            memory['pointHoverBackgroundColor'] = '#fff',
            memory['pointHoverBorderColor'] = memory['borderColor'],
            this.processUsageChartData.push(memory);
          this.originalProcessMemoryData.push(memory);
        }
      });
    
    }
  }


  getNetworkEth0(response) {
    this.networkEth0ChartData = new Array<any>();
    this.networkEth0TableData = new Array<any>();
    let networkData = response.map(item => item["eth0"]);
    this.getNetworkData(networkData, 'eth0');
  }

  getNetworkEth1(response) {
    this.networkEth1ChartData = new Array<any>();
    let networkData = response.map(item => item["eth1"]);
    this.getNetworkData(networkData, 'eth1');

  }

  getNetworkData(networkData, value) {
    for (var i = 0; i < this.networkLableList.length; i++) {
      let networkModel = {};
      let dataList = [];
      let finalDataList = [];
      dataList = networkData.map(item => {
        if (item != null && item != undefined) {
          if (item[this.networkLableList[i]] != null) {
            return item[this.networkLableList[i]]
          }
        }
      });
      dataList.forEach(element => {
        if (element != undefined && element != null) {
          let split = element.split(",");
          let split1 = split[1].split("=");
          finalDataList.push(split1[1]);
        }
      })
      if (finalDataList.length > 0) {
        networkModel['data'] = finalDataList;
        networkModel['label'] = this.networkLableList[i];
        if (value == 'eth0') {
          this.networkEth0ChartData.push(networkModel);
        } else if (value == 'eth1') {
          this.networkEth1ChartData.push(networkModel);
        }
      }
    }
  }

  getPCPUDetails(res) {
    let PCPUDetaills = res.map(item => item["info"]);
    this.pcpuLabel = this.hoursMinutes;
    PCPUDetaills.forEach(element => {
      if (element != null) {
        element.forEach(pcpuData => {
          if (this.pcpuDataMap.get(pcpuData.cpu)) {
            let pcpuDataArray = this.pcpuDataMap.get(pcpuData.cpu);
            pcpuDataArray.push(pcpuData);
            this.pcpuDataMap.set(pcpuData.cpu, pcpuDataArray);
          } else {
            let pcpuDataArray = [];
            pcpuDataArray.push(pcpuData);
            this.pcpuDataMap.set(pcpuData.cpu, pcpuDataArray);
          }
        });
      }
    });
    if (this.pcpuDataMap.size > 0) {
      let cpus = Array.from(this.pcpuDataMap.keys());
      cpus.forEach(cpu => {
        if (this.pcpuDataMap.has(cpu)) {
          let pcpu = {};
          let pcpuDetailsArray: Array<any> = [];
          pcpuDetailsArray = this.pcpuDataMap.get(cpu);
          let pcpuArray: Array<any> = [];
          pcpuDetailsArray.forEach(element => {
            pcpuArray.push(element['cpuPercent']);
          });
          this.pcpuDataList.push(pcpuDetailsArray[pcpuDetailsArray.length - 1]);
          this.itemResource = new DataTableResource(this.pcpuDataList);
          this.itemCount = this.pcpuDataList.length;
          pcpu['data'] = pcpuArray;
          pcpu['label'] = cpu;
          pcpu['fill'] = false;
          pcpu['backgroundColor'] = this.dynamicColors();
          pcpu['borderColor'] = this.dynamicColors();
          pcpu['pointBackgroundColor'] = pcpu['borderColor'],
            pcpu['pointBorderColor'] = '#fff',
            pcpu['pointHoverBackgroundColor'] = '#fff',
            pcpu['pointHoverBorderColor'] = pcpu['borderColor'],
            this.pcpuChartData.push(pcpu);
          this.originalPcpuData.push(pcpu);
        }
      });
    }
  }

  getCPUDetaills(res) {
    let CPUDetaills = res.map(item => item["usageInfo"]);
    this.cpuLabel = this.hoursMinutes;
    CPUDetaills.forEach(element => {
      if (element != null) {
        element.forEach(cpuData => {
          if (this.cpuDataMap.get(cpuData.pid)) {
            let cpuDataArray = this.cpuDataMap.get(cpuData.pid);
            cpuDataArray.push(cpuData);
            this.cpuDataMap.set(cpuData.pid, cpuDataArray);
          } else {
            let cpuDataArray = [];
            cpuDataArray.push(cpuData);
            this.cpuDataMap.set(cpuData.pid, cpuDataArray);
          }
        });
      }
    });
    if (this.cpuDataMap.size > 0) {
      let pids = Array.from(this.cpuDataMap.keys());
      pids.forEach(pid => {
        if (this.cpuDataMap.has(pid)) {
          let cpu = {};
          let cpuDetailsArray: Array<any> = [];
          cpuDetailsArray = this.cpuDataMap.get(pid);
          let cpuArray: Array<any> = [];
          cpuDetailsArray.forEach(element => {
            cpuArray.push(element['usage']);
          });
          this.cpuDataList.push(cpuDetailsArray[cpuDetailsArray.length - 1]);
          this.itemResource2 = new DataTableResource(this.cpuDataList);
          this.itemCount2 = this.cpuDataList.length;
          cpu['data'] = cpuArray;
          cpu['label'] = pid;
          cpu['fill'] = false;
          cpu['backgroundColor'] = this.dynamicColors();
          cpu['borderColor'] = this.dynamicColors();
          cpu['pointBackgroundColor'] = cpu['borderColor'],
            cpu['pointBorderColor'] = '#fff',
            cpu['pointHoverBackgroundColor'] = '#fff',
            cpu['pointHoverBorderColor'] = cpu['borderColor'],
            this.cpuChartData.push(cpu);
          this.originalCpuData.push(cpu);
        }
      });
    }
  }

  // update process memory
  updateProcessMemory(event, pid) {
    let tempData = this.processUsageChartData;
    if (event.checked) {
      for (let i = 0; i < this.originalProcessMemoryData.length; i++) {
        if (this.originalProcessMemoryData[i].label == pid) {
          tempData.push(this.originalProcessMemoryData[i]);
        }
      }
    } else {
      const index = tempData.findIndex(data => data.label === pid);
      tempData.splice(index, 1);
    }

    let _processMemoryChartData: Array<any> = new Array(tempData.length);
    for (let i = 0; i < tempData.length; i++) {
      _processMemoryChartData[i] = {
        data: new Array(tempData[i].data.length),
        label: tempData[i].label,
        fill: false,
        backgroundColor: tempData[i].backgroundColor,
        borderColor: tempData[i].borderColor,
        pointBackgroundColor: tempData[i].borderColor,
        pointBorderColor: '#fff',
        pointHoverBackgroundColor: '#fff',
        pointHoverBorderColor: tempData[i].borderColor,
      };
      for (let j = 0; j < tempData[i].data.length; j++) {
        _processMemoryChartData[i].data[j] = tempData[i].data[j];;
      }
    }
    if (this.processMemory !== undefined) {
      this.processMemory.chart.destroy();
      this.processMemory.chart = 0;
      this.processMemory.datasets = _processMemoryChartData;
      this.processMemory.labels = this.processMemoryLabel;
      this.processMemory.ngOnInit();
    }
  }

  // update pcpu data
  updatePCPUData(event, cpu) {
    let tempData = this.pcpuChartData;
    if (event.checked) {
      for (let i = 0; i < this.originalPcpuData.length; i++) {
        if (this.originalPcpuData[i].label == cpu) {
          tempData.push(this.originalPcpuData[i]);
        }
      }
    } else {
      const index = tempData.findIndex(data => data.label === cpu);
      tempData.splice(index, 1);
    }
    let _pcpuChartData: Array<any> = new Array(tempData.length);
    for (let i = 0; i < tempData.length; i++) {
      _pcpuChartData[i] = {
        data: new Array(tempData[i].data.length),
        label: tempData[i].label,
        fill: false,
        backgroundColor: tempData[i].backgroundColor,
        borderColor: tempData[i].borderColor,
        pointBackgroundColor: tempData[i].borderColor,
        pointBorderColor: '#fff',
        pointHoverBackgroundColor: '#fff',
        pointHoverBorderColor: tempData[i].borderColor,
      };
      for (let j = 0; j < tempData[i].data.length; j++) {
        _pcpuChartData[i].data[j] = tempData[i].data[j];;
      }
    }
    if (this.pcpu !== undefined) {
      this.pcpu.chart.destroy();
      this.pcpu.chart = 0;
      this.pcpu.datasets = _pcpuChartData;
      this.pcpu.labels = this.pcpuLabel;
      this.pcpu.ngOnInit();
    }
  }

  // update cpu data
  updateCPUData(event, pid) {
    let tempData = this.cpuChartData;
    if (event.checked) {
      for (let i = 0; i < this.originalCpuData.length; i++) {
        if (this.originalCpuData[i].label == pid) {
          tempData.push(this.originalCpuData[i]);
        }
      }
    } else {
      const index = tempData.findIndex(data => data.label === pid);
      tempData.splice(index, 1);
    }
    let _cpuChartData: Array<any> = new Array(tempData.length);
    for (let i = 0; i < tempData.length; i++) {
      _cpuChartData[i] = {
        data: new Array(tempData[i].data.length),
        label: tempData[i].label,
        fill: false,
        backgroundColor: tempData[i].backgroundColor,
        borderColor: tempData[i].borderColor,
        pointBackgroundColor: tempData[i].borderColor,
        pointBorderColor: '#fff',
        pointHoverBackgroundColor: '#fff',
        pointHoverBorderColor: tempData[i].borderColor,
      };
      for (let j = 0; j < tempData[i].data.length; j++) {
        _cpuChartData[i].data[j] = tempData[i].data[j];;
      }
    }
    this.cpuChartData = _cpuChartData;
    if (this.cpuChartData.length == 1) {
      let data = this.cpuDataList;
      for (let j = 0; j < this.cpuDataList[j].length; j++) {
        if (this.cpuDataList[j].pid == this.cpuChartData[0].label) {
          this.cpuDataList[j]['checked'] = false;
        }
      }


    }
    if (this.cpu !== undefined) {
      this.cpu.chart.destroy();
      this.cpu.chart = 0;
      this.cpu.datasets = _cpuChartData;
      this.cpu.labels = this.pcpuLabel;
      this.cpu.ngOnInit();
    }
  }


  
  reloadItems(params) {
    if (this.itemResource) {
      this.itemResource.query(params).then(items => this.pcpuDataList = items);
    }
  }

  reloadItems1(params) {
    if (this.itemResource1) {
      this.itemResource1.query(params).then(items => this.processUsageTableList = items);
    }
  }
  reloadItems2(params) {
    if (this.itemResource2) {
      this.itemResource2.query(params).then(items => this.cpuDataList = items);
    }
  }

  toggle4() {
    this.showlist = true;
  }
  toggle5() {
    this.showlist = false;
  }

  public lineChartOptions: any = {
    responsive: true,
    legend: {
      display: true,
      position: 'bottom',
      fill: false
    },
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true,
        },
        scaleLabel: {
          display: true,
          labelString: 'Memory',
          fontStyle: 'bold'
        }
      }],    
      xAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'Time Interval',
          fontStyle: 'bold'
        }
      }],
    }
  };

  public lineChartOptions1: any = {
    responsive: true,
    legend: {
      display: true,
      position: 'bottom',
      fill: false
    },
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true,
        },
        scaleLabel: {
          display: true,
          labelString: 'Percentage',
          fontStyle: 'bold'
        }
      }],    
      xAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'Time Interval',
          fontStyle: 'bold'
        }
      }],
    }
  };
  public lineChartOptions2: any = {
    responsive: true,
    legend: {
      display: true,
      position: 'bottom',
      fill: false
    },
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true,
        },
        scaleLabel: {
          display: true,
          labelString: 'Usage',
          fontStyle: 'bold'
        }
      }],    
      xAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'Time Interval',
          fontStyle: 'bold'
        }
      }],
    }
  };
  public lineChartOptions3: any = {
    responsive: true,
    legend: {
      display: true,
      position: 'bottom',
      fill: false
    },
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true,
        },
        scaleLabel: {
          display: true,
          labelString: 'Packets',
          fontStyle: 'bold'
        }
      }],    
      xAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'Time Interval',
          fontStyle: 'bold'
        }
      }],
    }
  };
  public lineChartColors: Array<any> = [
    { // light green
      backgroundColor: 'rgba(102,204,0,0.2)',
      borderColor: 'rgba(102,204,0,1)',
      pointBackgroundColor: 'rgba(102,204,0,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(102,204,0,0.8)'
    },
    // blue3
    {
      backgroundColor: 'rgba(0,149,179,0.2)',
      borderColor: 'rgba(0,149,179,1)',
      pointBackgroundColor: 'rgba(0,149,179,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(0,149,179,0.8)'
    },
    { // orange
      backgroundColor: 'rgba(255,166,77,0.2)',
      borderColor: 'rgba(255,166,77,1)',
      pointBackgroundColor: 'rgba(255,166,77,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,166,77,0.8)'
    },
    { // purple
      backgroundColor: 'rgba(136,77,255,0.2)',
      borderColor: 'rgba(136,77,255,1)',
      pointBackgroundColor: 'rgba(136,77,255,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(136,77,255,0.8)'
    },
    { // blue
      backgroundColor: 'rgba(51,119,255,0.2)',
      borderColor: 'rgba(51,119,255,1)',
      pointBackgroundColor: 'rgba(51,119,255,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(51,119,255,0.8)'
    }
  ];

  dynamicColors() {
    var r = Math.floor(Math.random() * 255);
    var g = Math.floor(Math.random() * 255);
    var b = Math.floor(Math.random() * 255);
    return "rgb(" + r + "," + g + "," + b + ")";
  }
  public lineChartLegend: boolean = false;
  public lineChartType: string = 'line';
  public lineChartColors1: Array<any> = [
    { // light green
      backgroundColor: this.dynamicColors(),
      borderColor: this.dynamicColors(),
    },

  ];



  showSelfTest() {
    this.loading = true;
    this.selfTestRep = [];
    $("#SelfTestModal").modal("show");
    this.message = "";
    let Modal = {};
    Modal["applianceId"] = this.applianceId;
    Modal["applianceName"] = this.applianceName;
    Modal["ipAddress"] = this.applianceModel.ipAddress;
    Modal["selfReportType"] = 'admin';
    this._applianceManagementService.getSelfTestReport(Modal).subscribe(
      res => {
        console.log(res);
        console.log("Self Test Report" + JSON.stringify(res));
        let res1 = JSON.stringify(res);
        let res2 = JSON.parse(res1);
        this.selfTestRep = res2.responseMessage.split("\\n");
        // this.selfTestRep=res2.responseMessage.split("\\n");

        console.log(res2);
        this.selfTestReport = res2.responseMessage;

        if (res2.responseCode == 408) {
          this.selfTestRep = [];


          this.message = res2.responseMessage;
          this.loading = false;

          this.selecterror.show();
          res2.responseCode = 1;

        }

        console.log(res2.responseMessage.split("\\n"));
        //var array = JSON.parse(res2.responseMessage[" + selfTest + "]);
        console.log(this.selfTestReport);
        // this.selfTestReport=res;
        // this.selfTestReport =JSON.parse(res.responseMessage);
        //  console.log(this.selfTestReport);
        this.loading = false;
      },
      error => {
        this.loading = false;
        console.log(error);
      },
    );
  }
  closeModalst() {

    $("#SelfTestModal").modal("hide");

  }

  ngOnDestroy() {
    if (this.timer) {
      this.timer.unsubscribe();
    }
    if (this.timerAdminMonitorStats) {
      this.timerAdminMonitorStats.unsubscribe();
    }
    if (this.timerSubs) {
      this.timerSubs.unsubscribe();
    }

    if (this.timerAdminMonitorStatsSubs) {
      this.timerAdminMonitorStatsSubs.unsubscribe();
    }
  }

}

function validateIp(control: AbstractControl) {
  console.log(control);
  // let value = control.value;
  // var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;

  // if (value.match(ipformat)) {
  //   this.isValidIp1 = true;
  // }
  // else {
  //   this.isValidIp1 = false;
  // }

  return this.isValidIp1;
}


