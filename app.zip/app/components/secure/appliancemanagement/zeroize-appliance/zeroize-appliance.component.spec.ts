import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ZeroizeApplianceComponent } from './zeroize-appliance.component';

describe('ZeroizeApplianceComponent', () => {
  let component: ZeroizeApplianceComponent;
  let fixture: ComponentFixture<ZeroizeApplianceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ZeroizeApplianceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ZeroizeApplianceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
