import { Component, OnInit, ViewChild, Output, EventEmitter, TemplateRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { FormBuilder, FormGroup, Validators, ValidatorFn, AbstractControl } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { TabDirective } from 'ngx-bootstrap/tabs';
import { TabsetComponent } from 'ngx-bootstrap';
import { BsModalService } from 'ngx-bootstrap/modal';
declare var bootbox: any;

@Component({
  selector: 'app-zeroize-appliance',
  templateUrl: './zeroize-appliance.component.html',
  styleUrls: ['./zeroize-appliance.component.css']
})
export class ZeroizeApplianceComponent implements OnInit {
  @ViewChild('zeroizeModal') zeroizeModal: ModalDirective;
  @Output() zeroizeCallBackEvent = new EventEmitter<any>();
  form: FormGroup;
  selectedAppliances = [];
  applianceName: string;
  totalAppliance = 0;
  applianceCount = 1;
  showBackButton = false;
  isFactory: boolean;
  forceZeroizeChecked: boolean = false;
  showForceZeroizecheck: boolean = false;
  showFinalZeroizeList: boolean = false;
  zeroizeDataList = [];
  loading = false;
  removeZeroizeArray : any = [];
  constructor(private _formBuilder: FormBuilder, private _applianceManagementService: AppliancemanagementService,
    private modalService: BsModalService) { }

  ngOnInit() {
    this.createZeroizeForm();
  }
  createZeroizeForm() {
    this.form = this._formBuilder.group({
      forceZeroize: [false],
      adapter: [true],
      factory: [false]
    });
  }

  showZeroizeModal(listAppliances) {
    console.log("List of selected appliance --->" + listAppliances);
    this.clearData();
    this.isFactory = false;
    this.selectedAppliances = listAppliances;
    this.applianceName = this.selectedAppliances[this.applianceCount - 1]['applianceName'];
    this.totalAppliance = this.selectedAppliances.length;
    this.zeroizeModal.show();

  }

  toggleFactory() {
    this.isFactory = !this.isFactory;
    this.forceZeroizeChecked = false;
    this.form.get('forceZeroize').setValue(false);
    if (this.isFactory == true) {
      this.showForceZeroizecheck = false;
    }
    else {
      this.showForceZeroizecheck = true;
    }
  }

  toggleForceZeroize($event) {
    if ($event.checked) {
      this.forceZeroizeChecked = true;
    } else {
      this.forceZeroizeChecked = false;
    }

  }
  backToPreviousAppliance() {
    this.form.reset();
    this.applianceName = this.selectedAppliances[this.applianceCount - 2]['applianceName'];
    let backOperationCount = this.applianceCount - 2;
    this.setValuesToForm(backOperationCount);
    this.applianceCount = this.applianceCount - 1;
    if (this.applianceCount == 1) {
      this.showBackButton = false;
    }

  }
  setValuesToForm(backOperationCount) {
    if (this.zeroizeDataList[backOperationCount]['forceZeroize'] == 1) {
      this.form.get('forceZeroize').setValue(true);
    } else {
      this.form.get('forceZeroize').setValue(false);
    }

    if (this.zeroizeDataList[backOperationCount]['type'] == "factory") {
      this.isFactory = true;
      this.showForceZeroizecheck = false;
    } else {
      this.isFactory = false;
      this.showForceZeroizecheck = true;
    }

  }
  clearData() {
    this.form.reset();
    this.applianceName = "";
    this.applianceCount = 1;
    this.selectedAppliances = [];
    this.showBackButton = false;
    this.showFinalZeroizeList = false;
    this.showForceZeroizecheck = true;
    this.loading = false;
    this.isFactory = false;
    this.zeroizeDataList = [];
    this.removeZeroizeArray = [];
  }
  closeZeroizeModal() {
    this.zeroizeModal.hide();
    this.clearData();

  }
  saveZeroizeAppliance(isvalid, template: TemplateRef<any>) {
    if (typeof this.zeroizeDataList[this.applianceCount - 1] === 'undefined') {
      let zeroizeModal = {};
      zeroizeModal['operationUsername'] = this.selectedAppliances[this.applianceCount - 1]["operationUsername"];
      zeroizeModal['operationPassword'] = this.selectedAppliances[this.applianceCount - 1]["operationPassword"];
      zeroizeModal['applianceId'] = this.selectedAppliances[this.applianceCount - 1]["applianceId"];
      zeroizeModal['applianceName'] = this.selectedAppliances[this.applianceCount - 1]["applianceName"];
      zeroizeModal['ipAddress'] = this.selectedAppliances[this.applianceCount - 1]["ipAddress"];
      zeroizeModal['credentialSaved'] = this.selectedAppliances[this.applianceCount - 1]["credentialSaved"];
      if (this.form.get('forceZeroize').value == true) {
        zeroizeModal['forceZeroize'] = true;
      } else {
        zeroizeModal['forceZeroize'] = false;
      }
      if (this.isFactory) {
        zeroizeModal['type'] = "factory";
      } else {
        zeroizeModal['type'] = "adapter";
      }
      this.zeroizeDataList.push(zeroizeModal);
    } else {
      if (this.form.get('forceZeroize').value == true) {
        this.zeroizeDataList[this.applianceCount - 1]['forceZeroize'] = true;
      } else {
        this.zeroizeDataList[this.applianceCount - 1]['forceZeroize'] = false;
      }
      if (this.isFactory) {
        this.zeroizeDataList[this.applianceCount - 1]['type'] = "factory";
      } else {
        this.zeroizeDataList[this.applianceCount - 1]['type'] = "adapter";
      }
    }

    if (this.applianceCount < this.selectedAppliances.length) {
      this.applianceName = this.selectedAppliances[this.applianceCount]['applianceName'];
      this.form.reset();
      if (typeof this.zeroizeDataList[this.applianceCount] != 'undefined') {
        this.setValuesToForm(this.applianceCount);
      } else {
        // this.isFactory = false;              
        if (this.isFactory == false) {
          this.showForceZeroizecheck = true;
        } else {
          this.showForceZeroizecheck = false;
        }
      }

      this.applianceCount++;
      this.showBackButton = true;
    } else {
      this.form.reset();
      //this.applianceCount++;
      this.showFinalZeroizeList = true;
    }
  }
  submitZeroize() {
    this.loading = true;
    this._applianceManagementService.saveZeroizedata(this.zeroizeDataList).subscribe((res) => {
      if (res.length > 0) {
        this.loading = false;
        let displaymsg: string = '';
        this.zeroizeModal.hide();
        res.forEach(obj => {
          if (obj.code == "200") {
            localStorage.removeItem(obj.ipAddress);
            displaymsg = displaymsg + "<b>" + obj.applianceName + "</b>&nbsp;:-- " + obj["message"] + "<br>";
          } else {
            displaymsg = displaymsg + "<b>" + obj.applianceName + "&nbsp;</b>:-- " + obj["errorMessage"] + "<br>";
          }
        });
        this.clearData();
        bootbox.dialog({
          message: displaymsg,
          buttons: {
            Ok: {
              label: "Close",
              className: 'btn btn-primary btn-flat',
              callback: () => this.callBack()
            }
          }
        });
      }
    }, (err) => {
      this.loading = false;
      console.log(err);
    })
  }
  callBack() {
    this.zeroizeCallBackEvent.emit();
  }
  backOperationFromFinalList() {
    this.form.reset();
    this.applianceName = this.selectedAppliances[this.applianceCount - 1]['applianceName'];
    this.setValuesToForm(this.applianceCount - 1);
    if (this.applianceCount == 1) {
      this.showBackButton = false;
    } else {
      //this.applianceCount = this.applianceCount - 1;
      this.showBackButton = true;
    }
    this.showFinalZeroizeList = false;
    //this.initializeTabs.tabs[0].active = true;
  }


  /* Remove appliance from the final list */
  removeAppliance(event,applianceId) {
    if (event.checked) {
      const index = this.removeZeroizeArray.findIndex(val => val.applianceId==applianceId);
      if(index != -1){
        this.zeroizeDataList.push(this.removeZeroizeArray[index]);
        this.removeZeroizeArray.splice(index,1);
      }
    }else{
      let selectedIds = [];
      selectedIds.push(applianceId);
      const index = this.zeroizeDataList.findIndex(val => val.applianceId==applianceId);
      if(index != -1){
        this.removeZeroizeArray.push(this.zeroizeDataList[index]);
      }
      this.zeroizeDataList = this.zeroizeDataList.filter(
        val => !selectedIds.includes(val.applianceId));
    }
    // let selectedIds = [];
    // selectedIds.push(applianceId);
    // this.zeroizeDataList = this.zeroizeDataList.filter(
    //   val => !selectedIds.includes(val.applianceId));
    // this.selectedAppliances = this.selectedAppliances.filter(
    //   val => !selectedIds.includes(val.applianceId));
    // this.applianceCount = this.applianceCount - 1;
    // this.totalAppliance = this.zeroizeDataList.length;
  }
}
