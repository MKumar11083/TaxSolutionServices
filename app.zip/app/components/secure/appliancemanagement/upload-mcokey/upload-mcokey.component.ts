import { Component, OnInit, ViewChild, Output, EventEmitter, TemplateRef, ElementRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { FormBuilder, FormGroup, Validators, ValidatorFn, AbstractControl } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { FileUploader } from 'ng2-file-upload';

const URL = '';
declare var bootbox: any;
declare var $: any;
@Component({
  selector: 'app-upload-mcokey',
  templateUrl: './upload-mcokey.component.html',
  styleUrls: ['./upload-mcokey.component.css']
})

export class UploadMcokeyComponent implements OnInit {
  @ViewChild('uploadMcokeyModal') uploadMcokeyModal: ModalDirective;
  @Output() messageEvent = new EventEmitter<any>();
  @ViewChild('myInputVariable')
  myInputVariable: ElementRef;
  modalRef: BsModalRef;
  form: FormGroup;
  showFinalUploadMcokeyList: boolean = false;
  applianceCount = 1;
  applianceName: string;
  totalAppliance = 0;
  selectedAppliances = [];
  applianceChecked: boolean = false;
  uploadMcokeyList = [];
  showBackButton = false;
  shownextbutton = false;
  loading = false;
  checked: boolean = true;
  uploadMcokeyData = {};
  errorMessage = '';
  // formData : FormData = new FormData();
  public uploader: FileUploader = new FileUploader({ url: URL });
  constructor(private _formBuilder: FormBuilder, private _applianceManagementService: AppliancemanagementService) { }

  ngOnInit() {
    this.createMcokeyForm();
    this.form.reset();
  }

  createMcokeyForm(){
    this.form = this._formBuilder.group({
      fileContent: [''],
      fileName: [''],
      fullName: [''],
      fileExtension: [''],
      fileValidate: [false],
     })
  }

  showuploadMcokeyModal(listAppliances){
    console.log("List of selected appliance --->" + listAppliances);
    this.clearData();
    this.selectedAppliances = listAppliances;
    this.applianceName = this.selectedAppliances[this.applianceCount - 1]['applianceName'];
    this.totalAppliance = this.selectedAppliances.length;
    this.uploadMcokeyModal.show();
    if (this.applianceCount < this.selectedAppliances.length) {
      this.shownextbutton = true;
    }
    else {
      this.shownextbutton = false;
    }
  }

  saveUploadMcokey() {
    this.errorMessage = '';
    this.myInputVariable.nativeElement.value = "";
    if (this.applianceCount < this.selectedAppliances.length) {
      /* get the next appliance coLoginFailureCount, min & max password length values */
      this.applianceName = this.selectedAppliances[this.applianceCount]['applianceName'];
      this.form.reset();

      this.applianceCount++;
      this.showBackButton = true;
      this.shownextbutton = true;
    }
    if (this.applianceCount == this.selectedAppliances.length) {
      this.shownextbutton = false;
    }
  }
  files : File;
  onFileSelected1(event){
    this.files = event.target.files;

  }

  onFileSelected(event) {
    const filePicked = (event.target as HTMLInputElement).files[0];
    if (filePicked != undefined) {
      const fileName = filePicked.name;
      this.form.get('fullName').setValue(fileName);
      this.form.get('fileName').setValue(fileName.substring(0, fileName.indexOf('.')));
      this.form.get('fileExtension').setValue(filePicked.name.split('.').pop() || filePicked.name);
      const reader = new FileReader();
      reader.onload = () => {
        this.form.get('fileContent').setValue(reader.result);
        if (this.form.get('fileContent').value != null) {
          this.form.get('fileValidate').setValue(true);
        } else {
          this.form.get('fileValidate').setValue(false);
        }
      };
      reader.readAsText(filePicked);
    } else {
      this.form.get('fullName').setValue(null);
      this.form.get('fileName').setValue("");
      this.form.get('fileExtension').setValue("");
      this.form.get('fileContent').setValue("");
      this.form.get('fileValidate').setValue(false);
      return false;
    }
  }

  uploadMcokey(){
    this.errorMessage = '';
    //if(this.form.get('fileValidate').value){
      this.uploadMcokeyData = {};
      let count: number;
      count = this.applianceCount - 1;
      this.uploadMcokeyData['operationUsername'] = this.selectedAppliances[count]['operationUsername'];
      this.uploadMcokeyData['operationPassword'] = this.selectedAppliances[count]['operationPassword'];
      this.uploadMcokeyData['applianceId'] = this.selectedAppliances[count]['applianceId'];
      this.uploadMcokeyData['applianceIp'] = this.selectedAppliances[count]['ipAddress'];
       const formData  = new FormData();
        // for (var j = 0; j < this.files.size; j++) {
          formData.append("mcoKeyCertificate", this.files[0], this.files[0].name);
          formData.append("details",JSON.stringify(this.uploadMcokeyData));
        // }
     // }
     this.loading = true;

      this._applianceManagementService.uploadMcokey(formData).subscribe((res) => {
  
          this.loading = false;
          let displaymsg: string = '';
          if (this.applianceCount == this.selectedAppliances.length) {
            this.uploadMcokeyModal.hide();
            this.clearData();
            } 
          this.myInputVariable.nativeElement.value = "";
          displaymsg =  res.responseMessage;
        
          bootbox.dialog({
            message: displaymsg,
            buttons: {
              Ok: {
                label: "Close",
                className: 'btn btn-primary btn-flat',
                callback: () => this.callBack()
              }
            }
          });
        
      }, (err) => {
        console.log(err);
      })
    // } else {
    //   this.errorMessage = "Please upload the files"
    // }
  }

  callBack() {
    this.messageEvent.emit();
  }

  backToPreviousAppliance() {
    this.form.reset();
    this.applianceName = this.selectedAppliances[this.applianceCount - 2]['applianceName'];
    this.applianceCount = this.applianceCount - 1;
    if (this.applianceCount == 1) {
      this.showBackButton = false;
    }
    this.shownextbutton = true;
  }

  closeuploadMcokey() {
    this.uploadMcokeyModal.hide();
    this.clearData();
  }

  clearData() {
    this.form.reset();
    this.files = null;
    this.applianceName = "";
    this.applianceCount = 1;
    this.selectedAppliances = [];
    this.showFinalUploadMcokeyList = false;
    this.uploadMcokeyList = [];
    // this.showBackButton = false;
    this.loading = false;
    this.uploader = new FileUploader({ url: URL });
  }
}


