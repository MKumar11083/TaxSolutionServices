import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UploadMcokeyComponent } from './upload-mcokey.component';

describe('UploadMcokeyComponent', () => {
  let component: UploadMcokeyComponent;
  let fixture: ComponentFixture<UploadMcokeyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UploadMcokeyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadMcokeyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
