import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InitializeApplianceComponent } from './initialize-appliance.component';

describe('InitializeApplianceComponent', () => {
  let component: InitializeApplianceComponent;
  let fixture: ComponentFixture<InitializeApplianceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InitializeApplianceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InitializeApplianceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
