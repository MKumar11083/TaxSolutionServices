import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangepassApplianceComponent } from './changepass-appliance.component';

describe('ChangepassApplianceComponent', () => {
  let component: ChangepassApplianceComponent;
  let fixture: ComponentFixture<ChangepassApplianceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChangepassApplianceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangepassApplianceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
