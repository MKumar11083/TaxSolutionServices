import { ViewChild, Component, OnInit, TemplateRef, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FileUploader, FileItem } from 'ng2-file-upload';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BsModalService } from 'ngx-bootstrap/modal';
const URL = '';

declare var bootbox: any;
declare var $: any;
@Component({
  // changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-firmware-upgrade-appliance',
  templateUrl: './firmware-upgrade-appliance.component.html',
  styleUrls: ['./firmware-upgrade-appliance.component.css']
})
export class FirmwareUpgradeApplianceComponent implements OnInit {
  modalRef: BsModalRef;
  @ViewChild('firmwareUpgradeModal') firmwareUpgradeModal: ModalDirective;
  @Output() firmwareCallBackEvent = new EventEmitter<any>();
  form: FormGroup;
  applianceName: string;
  applianceCount = 1;
  selectedAppliances: any = [];
  firmwareDataList = [];
  totalAppliance = 0;
  performZeroizeChecked: boolean = false;
  applianceChecked: boolean = false;
  fipsAdapterChecked: boolean = false;
  showPerformFIPS: boolean = false;
  showFinalFirmwareList: boolean = false;
  showBackButton = false;
  loading: boolean = false;
  toggleRadioOperation: boolean;
  public uploader: FileUploader = new FileUploader({ url: URL });
  public hasBaseDropZoneOver: boolean = false;
  public hasAnotherDropZoneOver: boolean = false;
  checked: boolean = true;
  errorMessage: string = '';
  finalDataList: any = [];
  removeFirmWareList: any = [];
  showConfirm : boolean = false;
  imageFile: File;
  signFile: File;
  isZerozie: boolean = false;
  public fileOverBase(e: any): void {
    this.hasBaseDropZoneOver = e;
  }

  public fileOverAnother(e: any): void {
    this.hasAnotherDropZoneOver = e;
  }
  constructor(private _formBuilder: FormBuilder,
    private _applianceManagementService: AppliancemanagementService, private modalService: BsModalService) { }

  ngOnInit() {
    // this.toggleRadioOperation = true;
    // this.isZerozie = false;
  
    this.createFirmwareUpgradeForm();
  }

  createFirmwareUpgradeForm() {
    this.form = this._formBuilder.group({
      hsmFirmwareType: [true],
      zeroize: [false],

    });
  }

  setApplianceDetails(firmwareData) {
    if (this.selectedAppliances[this.applianceCount]['applianceId'] != null && this.selectedAppliances[this.applianceCount]['applianceId'] != "") {
      firmwareData['applianceId'] = this.selectedAppliances[this.applianceCount - 1]['applianceId'];
    }
    if (this.selectedAppliances[this.applianceCount]['applianceName'] != null && this.selectedAppliances[this.applianceCount]['applianceName'] != "") {
      firmwareData['applianceName'] = this.selectedAppliances[this.applianceCount - 1]['applianceName'];
    }
    if (this.selectedAppliances[this.applianceCount]['applianceStatus'] != null && this.selectedAppliances[this.applianceCount]['applianceStatus'] != "") {
      firmwareData['applianceStatus'] = this.selectedAppliances[this.applianceCount - 1]['applianceStatus'];
    }
  }
  showFirmwareUpgradeModal(listAppliances) {
    console.log("List of selected appliance --->" + listAppliances);
    this.clearData();
    this.imageFile = null;
    this.signFile = null;
    this.selectedAppliances = [];
    this.finalDataList = [];
    this.removeFirmWareList = [];
    this.selectedAppliances = listAppliances;
    this.finalDataList = listAppliances;
    this.showFinalFirmwareList = false;
    this.showConfirm = false;
    this.toggleRadioOperation = true;
    this.isZerozie = false;
    this.firmwareUpgradeModal.show();
  }

  // saveFirmwareAppliance(isvalid, template: TemplateRef<any>) {
  //   if (isvalid) {
  //     /* begins, pushing each appliance into list*/
  //     if (typeof this.firmwareDataList[this.applianceCount - 1] === 'undefined') {
  //       this.pushApplianceDataIntoList();
  //     } else {
  //       // if (this.form.get('hsmFirmwareType').value == true) {
  //       //   this.firmwareDataList[this.applianceCount - 1]['hsmFirmwareType'] = 1;
  //       // } else {
  //       //   this.firmwareDataList[this.applianceCount - 1]['hsmFirmwareType'] = 0;
  //       // }
  //       this.firmwareDataList[this.applianceCount - 1]['firmwareUpgradeDetailModel']['hsmFirmwareType'] = this.form.get('hsmFirmwareType').value;
  //       if (this.form.get('zeroize').value == true) {
  //         this.firmwareDataList[this.applianceCount - 1]['firmwareUpgradeDetailModel']['zeroize'] = 1;
  //       } else {
  //         this.firmwareDataList[this.applianceCount - 1]['firmwareUpgradeDetailModel']['zeroize'] = 0;
  //       }
  //       this.firmwareDataList[this.applianceCount - 1]['firmwareUpgradeDetailModel']['imageFileDeatils']['fileContent'] = this.form.get('fileContent').value;
  //       this.firmwareDataList[this.applianceCount - 1]['firmwareUpgradeDetailModel']['imageFileDeatils']['fileName'] = this.form.get('fileName').value;
  //       this.firmwareDataList[this.applianceCount - 1]['firmwareUpgradeDetailModel']['imageFileDeatils']['fileExtension'] = this.form.get('fileExtension').value;
  //       this.firmwareDataList[this.applianceCount - 1]['firmwareUpgradeDetailModel']['signFileDeatils']['fileContentSign'] = this.form.get('fileContentSign').value;
  //       this.firmwareDataList[this.applianceCount - 1]['firmwareUpgradeDetailModel']['signFileDeatils']['fileNameSign'] = this.form.get('fileNameSign').value;
  //       this.firmwareDataList[this.applianceCount - 1]['firmwareUpgradeDetailModel']['signFileDeatils']['fileExtensionSign'] = this.form.get('fileExtensionSign').value;
  //     }

  //     /* ends, pushing each appliance into list*/
  //     if (this.applianceCount < this.selectedAppliances.length) {
  //       /* get the next appliance coLoginFailureCount, min & max password length values */
  //       this.applianceName = this.selectedAppliances[this.applianceCount]['applianceName'];
  //       this.form.reset();
  //       this.uploader.queue = [];
  //       if (typeof this.firmwareDataList[this.applianceCount] != 'undefined') {
  //         this.setValuesToForm(this.applianceCount);
  //       }
  //       this.applianceCount++;
  //       this.showBackButton = true;

  //     } else {

  //       this.form.reset();
  //       this.showFinalFirmwareList = true;
  //     }

  //   }
  // }


  // setValuesToForm(backOperationCount) {
  //   // if (this.firmwareDataList[backOperationCount]['firmwareUpgradeDetailModel']['hsmFirmwareType'] == 1) {
  //   //   this.form.get('hsmFirmwareType').setValue(true);
  //   // } else {
  //   //   this.form.get('hsmFirmwareType').setValue(false);
  //   // }
  //   this.form.get('hsmFirmwareType').setValue(this.firmwareDataList[backOperationCount]['firmwareUpgradeDetailModel']['hsmFirmwareType']);
  //   if (this.firmwareDataList[backOperationCount]['firmwareUpgradeDetailModel']['zeroize']) {
  //     this.form.get('zeroize').setValue(true);
  //   } else {
  //     this.form.get('zeroize').setValue(false);
  //   }
  //   this.form.get('fileContent').setValue(this.firmwareDataList[backOperationCount]['firmwareUpgradeDetailModel']['imageFileDeatils']['fileContent']);
  //   this.form.get('fileName').setValue(this.firmwareDataList[backOperationCount]['firmwareUpgradeDetailModel']['imageFileDeatils']['fileName']);
  //   this.form.get('fileExtension').setValue(this.firmwareDataList[backOperationCount]['firmwareUpgradeDetailModel']['imageFileDeatils']['fileExtension']);
  //   this.form.get('fileContentSign').setValue(this.firmwareDataList[backOperationCount]['firmwareUpgradeDetailModel']['signFileDeatils']['fileContentSign']);
  //   this.form.get('fileNameSign').setValue(this.firmwareDataList[backOperationCount]['firmwareUpgradeDetailModel']['signFileDeatils']['fileNameSign']);
  //   this.form.get('fileExtensionSign').setValue(this.firmwareDataList[backOperationCount]['firmwareUpgradeDetailModel']['signFileDeatils']['fileExtensionSign']);
  //   this.form.get('fileValidate').setValue("true");
  //   this.form.get('fileValidateSign').setValue("true");
  //   this.uploadFile(this.form.get('fileName').value, this.form.get('fileNameSign').value);
  // }

  // uploadFile(fileName, fileNameSign) {
  //   let date: number = new Date().getTime();
  //   let file = new File([""], fileName, { type: "text/plain", lastModified: date });
  //   let fileItem = new FileItem(this.uploader, file, {});
  //   this.uploader.queue.push(fileItem);
  //   let file1 = new File([""], fileNameSign, { type: "text/plain", lastModified: date });
  //   let fileItem1 = new FileItem(this.uploader, file1, {});
  //   this.uploader.queue.push(fileItem1);
  //   fileItem.upload();
  // }


  // pushApplianceDataIntoList() {
  //   let imageFileDeatils = {}
  //   let signFileDeatils = {};
  //   let firmwareUpgradeDetailModel = {
  //     "imageFileDeatils": imageFileDeatils,
  //     "signFileDeatils": signFileDeatils
  //   };
  //   let firmwareData = {
  //     "firmwareUpgradeDetailModel": firmwareUpgradeDetailModel
  //   };
  //   if (this.form.get('hsmFirmwareType').value != null) {
  //     firmwareData['firmwareUpgradeDetailModel']['hsmFirmwareType'] = this.form.get('hsmFirmwareType').value;
  //   }
  //   //else {
  //   //   firmwareData['firmwareUpgradeDetailModel']['hsmFirmwareType'] = 0;
  //   // }

  //   if (this.form.get('zeroize').value == true) {
  //     firmwareData['firmwareUpgradeDetailModel']['zeroize'] = 1;
  //   } else {
  //     firmwareData['firmwareUpgradeDetailModel']['zeroize'] = 0;
  //   }


  //   firmwareData['firmwareUpgradeDetailModel']['imageFileDeatils']['fileContent'] = this.form.get('fileContent').value;
  //   firmwareData['firmwareUpgradeDetailModel']['imageFileDeatils']['fileName'] = this.form.get('fileName').value;
  //   firmwareData['firmwareUpgradeDetailModel']['imageFileDeatils']['fileExtension'] = this.form.get('fileExtension').value;
  //   firmwareData['firmwareUpgradeDetailModel']['signFileDeatils']['fileContentSign'] = this.form.get('fileContentSign').value;
  //   firmwareData['firmwareUpgradeDetailModel']['signFileDeatils']['fileNameSign'] = this.form.get('fileNameSign').value;
  //   firmwareData['firmwareUpgradeDetailModel']['signFileDeatils']['fileExtensionSign'] = this.form.get('fileExtensionSign').value;
  //   firmwareData['applianceName'] = this.selectedAppliances[this.applianceCount - 1]['applianceName'];
  //   firmwareData['applianceId'] = this.selectedAppliances[this.applianceCount - 1]['applianceId'];
  //   firmwareData['applianceStatus'] = this.selectedAppliances[this.applianceCount - 1]['applianceStatus'];
  //   firmwareData['serialNumber'] = this.selectedAppliances[this.applianceCount - 1]['serialNumber'];
  //   firmwareData['networkTimezone'] = this.selectedAppliances[this.applianceCount - 1]['networkTimezone'];
  //   firmwareData['gatewayIp'] = this.selectedAppliances[this.applianceCount - 1]['gatewayIp'];
  //   firmwareData['ipAddress'] = this.selectedAppliances[this.applianceCount - 1]['ipAddress'];
  //   firmwareData['networkId'] = this.selectedAppliances[this.applianceCount - 1]['networkId'];
  //   firmwareData['subnetMask'] = this.selectedAppliances[this.applianceCount - 1]['subnetMask'];
  //   //this.setApplianceDetails(firmwareData);
  //   this.firmwareDataList.push(firmwareData);
  // }

  // backToPreviousAppliance() {
  //   this.form.reset();
  //   this.uploader.queue = [];
  //   this.applianceName = this.selectedAppliances[this.applianceCount - 2]['applianceName'];
  //   let backOperationCount = this.applianceCount - 2;
  //   this.setValuesToForm(backOperationCount);
  //   this.applianceCount = this.applianceCount - 1;
  //   if (this.applianceCount == 1) {
  //     this.showBackButton = false;
  //   }
  //   //this.initializeTabs.tabs[0].active = true;
  //   //this.tabName ="Initialize";
  // }

  // // Back Operation in Final list of appliance.
  // backOperationFromFinalList() {
  //   this.form.reset();
  //   this.uploader.queue = [];
  //   this.applianceName = this.firmwareDataList[this.applianceCount - 1]['applianceName'];
  //   this.setValuesToForm(this.applianceCount - 1);
  //   if (this.applianceCount == 1) {
  //     this.showBackButton = false;
  //   } else {
  //     this.showBackButton = true;
  //   }
  //   this.showFinalFirmwareList = false;
  // }

  /* Remove appliance from the final list */
  removeAppliance(event, applianceId) {
    if (event.checked) {
      const index = this.removeFirmWareList.findIndex(val => val.applianceId == applianceId);
      if (index != -1) {
        this.finalDataList.push(this.removeFirmWareList[index]);
        this.removeFirmWareList.splice(index, 1);
      }
    } else {
      let selectedIds = [];
      selectedIds.push(applianceId);
      const index = this.finalDataList.findIndex(val => val.applianceId == applianceId);
      if (index != -1) {
        this.removeFirmWareList.push(this.finalDataList[index]);
      }
      this.finalDataList = this.finalDataList.filter(
        val => !selectedIds.includes(val.applianceId));
    }
  }
  closeFirwareUpgradeModal() {
    this.isZerozie = false;
    this.toggleRadioOperation = true;
    this.firmwareUpgradeModal.hide();
    this.clearData();
  }

  clearData() {
    this.form.reset();
    this.form.get('hsmFirmwareType').setValue('appliance');
    this.applianceName = "";
    this.performZeroizeChecked = false;
    this.applianceChecked = false;
    this.fipsAdapterChecked = false;
    this.showFinalFirmwareList = false;
    this.firmwareDataList = [];
    this.uploader = new FileUploader({ url: URL });
    this.applianceCount = 1;
  }

  togglePerformZeroize($event) {
    if ($event.checked) {
      this.performZeroizeChecked = true;
    } else {
      this.performZeroizeChecked = false;
    }
  }

  toggleAppliance($event) {
    if ($event.checked) {
      this.applianceChecked = true;
    } else {
      this.applianceChecked = false;
    }
  }

  toggleFIPSAdapter($event) {
    if ($event.checked) {
      this.fipsAdapterChecked = true;
    } else {
      this.fipsAdapterChecked = false;

    }
  }

  showPerformFips() {
    this.showPerformFIPS = true;
  }

  hidePerformFips() {
    this.showPerformFIPS = false;
    this.form.get('zeroize').setValue(false);
  }

  fileCount = 0;
  onFileSelected(event) {
    // if(this.fileCount>2){
    //   return false;
    // }
    if (this.uploader.queue.length > 2) {
      this.uploader.queue.splice(0, 1); // clear old file & replace it with the new one
    }
    const filePicked = (event.target as HTMLInputElement).files[0];
    if (filePicked != undefined) {
      const fileName = filePicked.name;
      //this.form.get('fullName').setValue(fileName);
      const extension = filePicked.name.split('.').pop() || filePicked.name;

      const reader = new FileReader();
      reader.onload = () => {
        // this.fileCount++;
        if (extension == 'sign') {
          this.form.get('fileContentSign').setValue(reader.result);
          if (this.form.get('fileContentSign').value != null) {
            this.form.get('fileValidateSign').setValue("true");
          } else {
            this.form.get('fileValidateSign').setValue("false");
          }
          this.form.get('fileNameSign').setValue(fileName.substring(0, fileName.indexOf('.')));
          this.form.get('fileExtensionSign').setValue(filePicked.name.split('.').pop() || filePicked.name);
        } else {
          this.form.get('fileContent').setValue(reader.result);
          if (this.form.get('fileContent').value != null) {
            this.form.get('fileValidate').setValue("true");
          } else {
            this.form.get('fileValidate').setValue("false");
          }
          this.form.get('fileName').setValue(fileName.substring(0, fileName.indexOf('.')));
          this.form.get('fileExtension').setValue(filePicked.name.split('.').pop() || filePicked.name);
        }
      };
      reader.readAsText(filePicked);
    } else {
      // this.form.get('fullName').setValue(null);
      this.form.get('fileName').setValue("");
      this.form.get('fileExtension').setValue("");
      this.form.get('fileContent').setValue("");
      this.form.get('fileValidate').setValue("false");
      this.form.get('fileNameSign').setValue("");
      this.form.get('fileExtensionSign').setValue("");
      this.form.get('fileContentSign').setValue("");
      this.form.get('fileValidateSign').setValue("false");
      return false;
    }
  }


  callBack() {
    this.firmwareCallBackEvent.emit();
  }


  toggleRadioButton(event) {
    this.toggleRadioOperation = !this.toggleRadioOperation;
  }


  onFileUpload(event) {
    if (this.uploader.queue.length > 2) {
      this.uploader.queue.splice(0, 1); // clear old file & replace it with the new one
    }
    let newFileList: any = []
    newFileList = Array.from(this.uploader.queue);
    for (var i = 0; i < newFileList.length; i++) {
      if (newFileList[i] != undefined) {
        const extension = newFileList[i].file.name.split('.').pop() || newFileList[i].file.name;
        if (extension == 'sign') {
          this.signFile = newFileList[i].file.rawFile;
        } else {
          this.imageFile = newFileList[i].file.rawFile;
        }
      }
    }
  }

  onSubmit() {
    let hsmFirmwareType = '';
    if (this.toggleRadioOperation) {
      hsmFirmwareType = "appliance";
    } else {
      hsmFirmwareType = "adapter";
    }
    let applianceModelList = [];
    this.finalDataList.forEach(obj => {
      let applianceModel = {};
      applianceModel['applianceId'] = obj.applianceId;
      applianceModel['username'] = obj.operationUsername;
      applianceModel['password'] = obj.operationPassword;
      applianceModel['hsmFirmwareType'] = hsmFirmwareType;
      applianceModel['zeroize'] = this.isZerozie;
      if (!this.toggleRadioOperation && !this.isZerozie) {
        applianceModel['forceReboot'] = true;
      }else{
        applianceModel['forceReboot'] = false;
      }
      applianceModelList.push(applianceModel);
    });
    const formData = new FormData();
    formData.append("sign", this.signFile, this.signFile.name);
    formData.append("image", this.imageFile, this.imageFile.name);
    formData.append("appliances", JSON.stringify(applianceModelList));

    this.loading = true;
    this._applianceManagementService.firmwareUpgrade(formData).subscribe((res) => {
      this.loading = false;

      this.firmwareUpgradeModal.hide();
      this.responseOperation(res);
    }, (err) => {
      this.loading = false;
      console.log(err);
    })

  }

  responseOperation(res) {
    let displaymsg: string = '';
    this.clearData();
    res.forEach(obj => {
      if (obj.code == "200") {
        displaymsg = displaymsg + " " + "<b>" + obj.applianceName + "</b> :-- " + obj["message"] + "<br>";
      } else {
        displaymsg = displaymsg + " " + "<b>" + obj.applianceName + "</b> :-- " + obj["errorMessage"] + "<br>";
      }

    });
    bootbox.dialog({
      message: displaymsg,
      buttons: {
        Ok: {
          label: "Close",
          className: 'btn btn-primary btn-flat',
          callback: () => this.callBack()
        }
      }
    });
  }

  showListAppliance(template: TemplateRef<any>) {
    this.removeFirmWareList = [];
    if (this.signFile != undefined && this.signFile != null) {
      if (this.imageFile != undefined && this.imageFile != null) {
        if (!this.toggleRadioOperation && !this.isZerozie) {
          this.showConfirm = true;
          this.errorMessage = "";
          this.errorMessage = "The appliance may reboot , and will be unusable for a few minutes. Do you still wish to proceed?";
          this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
        }else{
          this.showFinalFirmwareList = true;
        }
      } else {
        this.errorMessage = "";
        this.errorMessage = "Please upload valid files";
        this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
      }
    } else {
      this.errorMessage = "";
      this.errorMessage = "Please upload one sign extension file";
      this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
    }

  }
  confirmOperation(){
    this.modalRef.hide();
    this.showFinalFirmwareList = true;
  }
}
