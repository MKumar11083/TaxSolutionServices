import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, FormControl } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { Router } from '@angular/router';
import { CommonValidator} from './../../../../validators/common-validator';
declare var $: any;
declare var bootbox: any;
declare var jQuery: any;
@Component({
  selector: 'app-add-by-discovery',
  templateUrl: './add-by-discovery.component.html',
  styleUrls: ['./add-by-discovery.component.css']
})
export class AddByDiscoveryComponent implements OnInit {
  displayErrors: any = [];
  ipDiscoveryResults = new Map<string, string>();
  errorMessage: string;
  showIPAddress: boolean = true;
  isvalid: boolean;
  buttontrue:boolean=true;
  buttontrue1:boolean=true;
  form: FormGroup;
  public loading = false;
  constructor(private builder: FormBuilder,
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _addApplianceService: AppliancemanagementService,
    private _router: Router) { }

  ngOnInit() {
    this.selectedIp='';
    this.isSelectIp = true;
    this.createForm();
  }

  createForm() {
    this.form = this.builder.group({
      ipAddress: ['',Validators.compose([Validators.required,CommonValidator.ipAddressValidator])],
      ipAddressStartingRange: [''],
      ipAddressEndRange: ['']
    });
  }

  // create a form errors
  public formValidationFields = {
    "ipAddress": '',
    "ipAddressStartingRange": '',
    "ipAddressEndRange": '',
  }

  isFieldValid(field: string) {

    // if (this.form.get(field).touched) {
      this.formValidationFields = this._fieldErrorDisplayService.validateField(this.form, field, this.formValidationFields, "add-by-discovery")
    // }
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  result = [];
  validIpList = [];
  InvalidIpList = [];
  isValid: boolean = true;
  searchAppliance() {
    this.loading = true;
    this.result = [];
    this.validIpList = [];
    this.InvalidIpList = [];
    this.isValid=true;
    this.selectedIp = '';
    this.errorMessage= '';
    if (this.showIPAddress) {
      this._addApplianceService.getIPaddress(this.form.value).subscribe((res) => {
        this.loading = false;
        this.errorMessage = res.errorMessage;
        this.ipDiscoveryResults = res.ipDiscoveryResults;
        const result = Object.keys(res.ipDiscoveryResults).map(key => {
          let ip = {};
          res.ipDiscoveryResults[key];
          ip['ip'] = key;
          ip['result'] = res.ipDiscoveryResults[key];
          this.result.push(ip);
         
        });
        this.result.forEach(element => {
          if (element.result) {
            if(element.result == 'Ip already Exist in our DB'){
              element['disabled'] =  true;
            }else{
              element['disabled'] =  false;
            }
            this.isValid = true;
            element['deviceName'] = "Liquid Security";
            this.validIpList.push(element);
          } else {
            this.isValid = false;
            this.InvalidIpList.push(element.ip);
          }
        })
        
      });
    } else {
      this._addApplianceService.getIPaddressRange(this.form.value).subscribe((res) => {
        this.loading = false;
        this.errorMessage = res.errorMessage;
        this.ipDiscoveryResults = res.ipDiscoveryResults;
        const result = Object.keys(res.ipDiscoveryResults).map(key => {
          let ip = {};
          res.ipDiscoveryResults[key];
          ip['ip'] = key;
          ip['result'] = res.ipDiscoveryResults[key];
          this.result.push(ip);
        });
        this.result.forEach(element => {
          if (element.result) {
            if(element.result == 'Ip already Exist in our DB'){
              element['disabled'] =  true;
            }else{
              element['disabled'] =  false;
            }
            this.isValid = true;
            element['deviceName'] = "Liquid Security";
            this.validIpList.push(element);
          } else {
            this.isValid = false;
            this.InvalidIpList.push(element.ip);
          }
        })
       
      });

    }

  }
  isSelectIp = true;
  showIpAddress(ip) {
    this.validIpList= [];
    this.InvalidIpList = [];
    this.errorMessage = '';
    this.isValid = true;
    this.form.get('ipAddress').reset();
    this.form.get('ipAddressStartingRange').reset();
    this.form.get('ipAddressEndRange').reset();
    this.showIPAddress  =  !this.showIPAddress ;
    if (ip  ==  "ip") {
      this.isSelectIp = true;
      this.form.get('ipAddress').setValidators(Validators.compose([Validators.required,CommonValidator.ipAddressValidator]));
      this.form.get('ipAddressStartingRange').setValidators(null);
      this.form.get('ipAddressEndRange').setValidators(null);
      this.form.get('ipAddress').updateValueAndValidity();
      this.form.get('ipAddressStartingRange').updateValueAndValidity();
      this.form.get('ipAddressEndRange').updateValueAndValidity();
    } else  if (ip  ==  "iprange") {
      this.isSelectIp = false;
      this.form.get('ipAddressStartingRange').setValidators(Validators.compose([Validators.required,CommonValidator.ipAddressValidator]));
      this.form.get('ipAddressEndRange').setValidators(Validators.compose([Validators.required,CommonValidator.ipAddressValidator]));
      this.form.get('ipAddress').setValidators(null);
      this.form.get('ipAddress').updateValueAndValidity();
      this.form.get('ipAddressStartingRange').updateValueAndValidity();
      this.form.get('ipAddressEndRange').updateValueAndValidity();
    }
  }


  public OnlyNumericValues(e) {
    let input;
    if (e.metaKey || e.ctrlKey) {
      return true;
    }
    if (e.which === 32) {
      return false;
    }
    if (e.which === 0) {
      return true;
    }
    if (e.which < 33) {
      return true;
    }
    input = String.fromCharCode(e.which);
    return !!/[\d\s]/.test(input);
  }
  selectedIp = '';
  selectIpAddress(ip) {
    this.selectedIp = '';
    this.selectedIp = ip;
  }
  onSubmit() {
    if(this.selectedIp!=''){
      this._router.navigate(['/addAppliance', this.selectedIp]);
    }else{
      bootbox.dialog({
        message: "<b>Please select one Ipaddress to perform operation</b>",
        buttons: {
          Ok: {
            label: "Close",
            className: 'btn btn-primary btn-flat',
          }
        }
      });
    }
    
  }

  isValidIp = true;
  validateIPaddress(inputText) {
    this.isValidIp = true;
    var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    // var form = document.getElementById('form1');
    // var x;
    // x = (<HTMLInputElement>document.getElementById("ip")).value;
    if (inputText != '') {
      if (inputText.match(ipformat)) {
        this.isValidIp = true;
        this.buttontrue=false;
      }
      else {
        this.isValidIp = false;
        this.buttontrue=true;
      }
    }
  }

  isValidIp1 = true;
  validateIPaddress1(inputText) {
    this.isValidIp1 = true;
    this.buttontrue1=true;
    var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    // var form = document.getElementById('form1');
    // var x;
    // x = (<HTMLInputElement>document.getElementById("ip")).value;
    if (inputText != '') {
      if (inputText.match(ipformat)) {
        this.isValidIp1 = true;
        this.buttontrue1=false;
      }
      else {
        this.isValidIp1 = false;
        this.buttontrue1=true;
      }
    }
  }

  isValidIp2 = true;
  validateIPaddress2(inputText) {
    this.isValidIp2 = true;
    this.buttontrue=true;
    var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    // var form = document.getElementById('form1');
    // var x;
    // x = (<HTMLInputElement>document.getElementById("ip")).value;
    if (inputText != '') {
      if (inputText.match(ipformat)) {
        this.isValidIp2 = true;
        this.buttontrue=false;
      }
      else {
        this.isValidIp2 = false;
        this.buttontrue=true;
      }
    }
  }
}
