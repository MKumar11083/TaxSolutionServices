import { Component, OnInit, ViewChild, Input, ElementRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';

import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { CommonValidator } from './../../../../validators/common-validator';
@Component({
  selector: 'app-snmp-configure',
  templateUrl: './snmp-configure.component.html',
  styleUrls: ['./snmp-configure.component.css']
})
export class SnmpConfigureComponent implements OnInit {
  @ViewChild('certificate') certificateVariable: ElementRef;
  @ViewChild('key') keyVariable: ElementRef;
  @ViewChild('snmpModal') snmpModal: ModalDirective;
  @ViewChild('messageModal') messageModal: ModalDirective;
  @ViewChild('monitorLogin') monitorLogin: ModalDirective;
  name: string;
  @Input() applianceId;
  @Input() applianceData;
  monitorModel: any = {};
  operation: string = '';
  loading: boolean = false;
  responseArray: any = [];
  message: string = '';
  applianceName: string = '';
  downloadError: string = '';
  // snmpData: any;
  form: FormGroup;
  loginForm: FormGroup;
  autenticationDetailsArray: any = [];
  applianceDualFactorInitialized: boolean = false;
  constructor(private _service: AppliancemanagementService,
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _formBuilder: FormBuilder) { }

  ngOnInit() {
    this.createSNMPForm();
    this.createLoginForm();
    this.form.get("authModeEncryption").setValue("MD5");
    this.form.get("privModeEncryption").setValue("DES");
  }
  createSNMPForm() {
    this.form = this._formBuilder.group({
      enable: [''],
      enableTrap: [''],
      snmpip: ['', Validators.required],
      uname: ['', Validators.required],
      port: ['', Validators.required],
      engineId: ['', Validators.required],
      authMode: [true],
      privMode: [true],
      authModeEncryption: [''],
      authModePassword: [''],
      privModeEncryption: [''],
      privModePassword: ['']
    });
  }

  public formValidationFields2 = {
    "uname": '',
    "snmpip": '',
    "port": '',
    "engineId": '',
    "password": '',
  }

  isFieldValid2(field: string) {
    if (this.form.get(field).touched) {
      this.formValidationFields2 = this._fieldErrorDisplayService.validateField(this.form, field, this.formValidationFields2, "snmpvalid")
    }
    return !this.form.get(field).valid && this.form.get(field).touched;
  }
  displayFieldCss2(field: string) {
    return {
      'has-error': this.isFieldValid2(field),
      'has-feedback': this.isFieldValid2(field)
    };
  }

  showSNMPLogin(value) {
    this.clearDetails();
    this.name = value;
    this.loginForm.reset();
    this.form.reset();
    if (this.applianceData.credentialSaved == true) {
      this.getSNMPDetails();
    } else {
      let loginCredentials = JSON.parse(localStorage.getItem(this.applianceData.ipAddress));
      if (loginCredentials != null) {
        this.loginForm.get('username').setValue(loginCredentials.username);
        this.loginForm.get('password').setValue(loginCredentials.password);
        this.getSNMPDetails();
      } else {
        this.applianceDualFactorInitialized = this.applianceData['applianceDualFactorInitialized'];
        this.setValidationDualFactorAuthentication();
        this.monitorLogin.show();
      }
    }
  }

  setDualFactorData(loginDetailsModal) {
    loginDetailsModal['initializeDetailModel'] = {};
    loginDetailsModal['initializeDetailModel']['cryptoOfficerName'] = this.loginForm.get('username').value;
    loginDetailsModal['initializeDetailModel']['cryptoOfficerPassword'] = this.loginForm.get('password').value;
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel'] = {};

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['dualFactorAuthServerPortNo'] = this.loginForm.get('dualFactorAuthServerPortNo').value;
    // certificate file details
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateContent'] = this.loginForm.get('certificateContent').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateName'] = this.loginForm.get('certificateName').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateExtension'] = this.loginForm.get('certificateExtension').value;
    // key file details
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileContent'] = this.loginForm.get('keyfileContent').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileName'] = this.loginForm.get('keyfileName').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileExtension'] = this.loginForm.get('keyfileExtension').value;
    return loginDetailsModal;
  }

  setValidationDualFactorAuthentication() {
    // set validations for dual factor properties 
    if (this.applianceDualFactorInitialized) {
      this.loginForm.get('dualFactorAuthServerPortNo').setValidators(Validators.required);
      this.loginForm.get('certificateFile').setValidators(Validators.required);
      this.loginForm.get('keyFile').setValidators(Validators.required);
    } else {
      this.loginForm.get('dualFactorAuthServerPortNo').setValidators(null);
      this.loginForm.get('certificateFile').setValidators(null);
      this.loginForm.get('keyFile').setValidators(null);
    }
    this.loginForm.get('dualFactorAuthServerPortNo').updateValueAndValidity();
    this.loginForm.get('certificateFile').updateValueAndValidity();
    this.loginForm.get('keyFile').updateValueAndValidity();
  }

  submitLoginDetails() {
    let loginDetailsModal = {};
    loginDetailsModal['applianceId'] = this.applianceData.applianceId;
    loginDetailsModal['applianceName'] = this.applianceData.applianceName;
    loginDetailsModal['ipAddress'] = this.applianceData.ipAddress;
    loginDetailsModal['operationUsername'] = this.loginForm.get('username').value;
    loginDetailsModal['operationPassword'] = this.loginForm.get('password').value;
    let dualFactorCheck = this.applianceData.applianceDualFactorInitialized;
    if (dualFactorCheck) {
      loginDetailsModal = this.setDualFactorData(loginDetailsModal);
    }
    this.autenticationDetailsArray.push(loginDetailsModal);
    this.checkAppliancesCredentials();
  }

  checkAppliancesCredentials() {
    if (this.applianceDualFactorInitialized) {
      this.certificateVariable.nativeElement.value = '';
      this.keyVariable.nativeElement.value = "";
    }
    this.loading = true;
    this.responseArray = [];
    this.monitorLogin.hide();
    this._service.checkAppliancesCredentials(this.autenticationDetailsArray).subscribe(
      (response) => {
        this.loading = false;
        let isSuccess: boolean = true;
        this.autenticationDetailsArray = [];
        response.forEach(obj => {
          if (obj.code != "200") {
            this.responseArray.push(obj);
            isSuccess = false;
          } else {
            // Storing appliance login credentials in local session
            let ipAddress = obj.ipAddress;
            let loginCredentials = {
              username: this.loginForm.get('username').value,
              password: this.loginForm.get('password').value
            };
            localStorage.setItem(ipAddress, JSON.stringify(loginCredentials));
            // local session code ends here
          }
        });
        if (isSuccess) {
          this.getSNMPDetails();
        } else {
          this.messageModal.show();
        }
      },
      (error) => {
        console.log(error);
      })
  }

  getSNMPDetails() {
    this.snmpModal.show();
    let applianceData = {};
    applianceData['applianceId'] = this.applianceData.applianceId;
    this._service.getSNMPDetails(applianceData).subscribe(
      (response) => {

        let snmpData = JSON.parse(response.message);
        if (snmpData.enabled == "yes") {
          this.form.get("enable").setValue(true);
          this.form.get("uname").setValidators([Validators.required, CommonValidator.snmpUserName]);
          this.form.get("snmpip").setValidators([Validators.required, CommonValidator.ipAddressValidator]);
          this.form.get("port").setValidators([Validators.required]);
          this.form.get("engineId").setValidators([Validators.required, CommonValidator.engineIdValidate]);
          this.form.get("uname").updateValueAndValidity();
          this.form.get("snmpip").updateValueAndValidity();
          this.form.get("port").updateValueAndValidity();
          this.form.get("engineId").updateValueAndValidity();
        } else {
          this.form.get("enable").setValue(false);
          this.form.get("uname").disable();
          this.form.get("snmpip").disable();
          this.form.get("uname").setValidators(null);
          this.form.get("snmpip").setValidators(null);
          this.form.get("port").setValidators(null);
          this.form.get("engineId").setValidators(null);
          this.form.get("uname").updateValueAndValidity();
          this.form.get("snmpip").updateValueAndValidity();
          this.form.get("port").updateValueAndValidity();
          this.form.get("engineId").updateValueAndValidity();
          this.form.get("authMode").disable();
          this.form.get("privMode").disable();
          this.form.get("port").disable();
          this.form.get("engineId").disable();
          this.form.get("enableTrap").disable();
          this.form.get("authModeEncryption").disable();
          this.form.get("authModePassword").disable();
          this.form.get("privModeEncryption").disable();
          this.form.get("privModePassword").disable();
        }
        if (snmpData.trapEnabled == "yes") {
          this.form.get("enableTrap").setValue(true);
        } else {
          this.form.get("enableTrap").setValue(false);
        }
        this.form.get("uname").setValue(snmpData.uname);
        this.form.get("snmpip").setValue(snmpData.ip);
        this.form.get("port").setValue(snmpData.port);
        this.form.get("engineId").setValue(snmpData.engineId);
        if (snmpData.auth == "None" || snmpData.auth == null) {
          this.form.get("authMode").setValue(false);
          this.form.get("authModeEncryption").setValue("md5");
          this.form.get("privMode").disable();
          this.form.get("authModeEncryption").disable();
          this.form.get("authModePassword").disable();
          this.form.get("privModeEncryption").disable();
          this.form.get("privModePassword").disable();
          this.form.get("authModePassword").setValidators(null);
          this.form.get("privModePassword").setValidators(null);
          this.form.get("authModePassword").updateValueAndValidity();
          this.form.get("privModePassword").updateValueAndValidity();
        } else {
          this.form.get("authModePassword").setValidators([Validators.required]);
          this.form.get("authModePassword").updateValueAndValidity();
          let value = '';
          if (snmpData.auth == "MD5") {
            value = "md5";
          } else if (snmpData.auth == "SHA") {
            value = "sha";
          } else if (snmpData.auth == "SHA128") {
            value = "sha128";
          } else if (snmpData.auth == "SHA192") {
            value = "sha192";
          } else if (snmpData.auth == "SHA256") {
            value = "sha256";
          } else if (snmpData.auth == "SHA384") {
            value = "sha384";
          } else {
            value = "md5"
          }
          this.form.get("authMode").setValue(true);
          this.form.get("authModeEncryption").setValue(value);
        }
        if (snmpData.authPwd == "none") {
          this.form.get("authModePassword").setValue('');
        } else {
          this.form.get("authModePassword").setValue(snmpData.authPwd);
        }
        if (snmpData.priv == "None" || snmpData.priv == null) {
          this.form.get("privMode").setValue(false);
          this.form.get("privModeEncryption").setValue("des");
          this.form.get("privModeEncryption").disable();
          this.form.get("privModePassword").disable();
          this.form.get("privModePassword").setValidators(null);
          this.form.get("privModePassword").updateValueAndValidity();
        }
        else {
          this.form.get("privModePassword").setValidators([Validators.required]);
          this.form.get("privModePassword").updateValueAndValidity();
          let value = '';
          if (snmpData.priv == "DES") {
            value = "des";
          } else if (snmpData.priv == "3DES") {
            value = "3des";
          } else if (snmpData.priv == "AES128") {
            value = "aes128";
          } else if (snmpData.priv == "AES192") {
            value = "aes192";
          } else if (snmpData.priv == "AES256") {
            value = "aes256";
          } else {
            value = "des"
          }
          this.form.get("privMode").setValue(true);
          this.form.get("privModeEncryption").setValue(value);
        }
        if (snmpData.privPwd == "none") {
          this.form.get("privModePassword").setValue('');
        } else {
          this.form.get("privModePassword").setValue(snmpData.privPwd);
        }
      }
    )
  }

  clearDetails() {
    this.message = '';
    this.applianceName = '';
    this.responseArray = [];
  }


  submitSNMPDetails() {
    // if (this.isValidAlphaNumeric == true && this.isValidIp == true && this.isValidAlphaNumeric1 == true
    //   && this.form.get("uname").value != '' && this.form.get("snmpip").value != '' && this.form.get("port").value != ''
    //   && this.form.get("engineId").value != '') {
    if (this.form.valid) {
      this.responseArray = [];
      this.message = '';
      this.applianceName = '';
      this.loading = true;
      let applianceData = {};
      if (this.form.get('enable').value == false) {
        applianceData['enable'] = this.form.get("enable").value;
        applianceData['applianceId'] = this.applianceData.applianceId;
        applianceData['operationUsername'] = this.loginForm.get('username').value;
        applianceData['operationPassword'] = this.loginForm.get('password').value;
        applianceData['applianceIp'] = this.applianceData.ipAddress;
      } else {
        if (this.form.get('authMode').value == false) {
          this.form.get("authModeEncryption").setValue("none");
        }
        if (this.form.get('privMode').value == false) {
          this.form.get("privModeEncryption").setValue("none");
        }
        applianceData['applianceId'] = this.applianceData.applianceId;
        applianceData['operationUsername'] = this.loginForm.get('username').value;
        applianceData['operationPassword'] = this.loginForm.get('password').value;
        applianceData['applianceIp'] = this.applianceData.ipAddress;
        applianceData['uname'] = this.form.get("uname").value;
        applianceData['snmpip'] = this.form.get("snmpip").value;
        applianceData['port'] = this.form.get("port").value;
        applianceData['engineId'] = this.form.get("engineId").value;
        applianceData['enable'] = this.form.get("enable").value;
        applianceData['enableTrap'] = this.form.get("enableTrap").value;
        applianceData['snmpip'] = this.form.get("snmpip").value;
        applianceData['authModeEncryption'] = this.form.get("authModeEncryption").value;
        applianceData['authModePassword'] = this.form.get("authModePassword").value;
        applianceData['privModeEncryption'] = this.form.get("privModeEncryption").value;
        applianceData['privModePassword'] = this.form.get("privModePassword").value;
      }

      this._service.setSNMPDetails(applianceData).subscribe(
        (response) => {
          this.loading = false;
          this.snmpModal.hide();
          this.messageModal.show();
          this.applianceName = this.applianceData.applianceName;
          this.message = response.message;
        },
        (error) => {
          this.loading = false;
          console.log(error);
        }
      )
    } else {
      const uname = this.form.get('uname');
      if (uname.errors != null) {
        if (uname.hasError('required')) {
          uname.markAsTouched({ onlySelf: true });
        }else if(uname.hasError('invalidAplhaNumeric')){
          uname.markAsTouched({ onlySelf: true });
        }
      }

      const snmpip = this.form.get('snmpip');
      if (snmpip.errors != null) {
        if (snmpip.hasError('required')) {
          snmpip.markAsTouched({ onlySelf: true });
        }else if(snmpip.hasError('invalidIp')){
          snmpip.markAsTouched({ onlySelf: true });
        }
      }

      const port = this.form.get('port');
      if (port.errors != null) {
        if (port.hasError('required')) {
          port.markAsTouched({ onlySelf: true });
        }
      }

      const engineId = this.form.get('engineId');
      if (engineId.errors != null) {
        if (engineId.hasError('required')) {
          engineId.markAsTouched({ onlySelf: true });
        }else if(engineId.hasError('invalidAplhaNumeric')){
          engineId.markAsTouched({ onlySelf: true });
        }
      }
      if(this.form.get('privMode').value){
        const privModePassword = this.form.get('privModePassword');
        if (privModePassword.errors != null) {
          if (privModePassword.hasError('required')) {
            privModePassword.markAsTouched({ onlySelf: true });
          }
        }
      }

      if(this.form.get('authMode').value){
        const authModePassword = this.form.get('authModePassword');
        if (authModePassword.errors != null) {
          if (authModePassword.hasError('required')) {
            authModePassword.markAsTouched({ onlySelf: true });
          }
        }
      }
    }
  }


  createLoginForm() {
    this.loginForm = this._formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      dualFactorAuthServerPortNo: [''],
      certificateFile: [""],
      keyFile: [""],
      certificateName: [''],
      certificateExtension: [''],
      certificateContent: [''],
      keyfileName: [''],
      keyfileExtension: [''],
      keyfileContent: ['']
    });
  }

  public formValidationFields1 = {
    "username": '',
    "password": '',
    "dualFactorAuthServerPortNo": ''

  }
  isFieldValid1(field: string) {
    if (this.loginForm.get(field).touched) {
      this.formValidationFields1 = this._fieldErrorDisplayService.validateField(this.loginForm, field, this.formValidationFields1, "login")
    }
    return !this.loginForm.get(field).valid && this.loginForm.get(field).touched;
  }

  displayFieldCss1(field: string) {
    return {
      'has-error': this.isFieldValid1(field),
      'has-feedback': this.isFieldValid1(field)
    };
  }

  toggleEnable(event) {
    if (event.checked) {
      this.form.get("uname").enable();
      this.form.get("snmpip").enable();
      this.form.get("authMode").enable();
      this.form.get("port").enable();
      this.form.get("engineId").enable();
      this.form.get("enableTrap").enable();
      this.form.get("privMode").disable();
      this.form.get("authModeEncryption").disable();
      this.form.get("authModePassword").disable();
      this.form.get("privModeEncryption").disable();
      this.form.get("privModePassword").disable();
      this.form.get("uname").setValidators([Validators.required, CommonValidator.snmpUserName]);
      this.form.get("snmpip").setValidators([Validators.required, CommonValidator.ipAddressValidator]);
      this.form.get("port").setValidators([Validators.required]);
      this.form.get("engineId").setValidators([Validators.required, CommonValidator.engineIdValidate]);
      this.form.get("uname").updateValueAndValidity();
      this.form.get("snmpip").updateValueAndValidity();
      this.form.get("port").updateValueAndValidity();
      this.form.get("engineId").updateValueAndValidity();
    } else {
      this.form.get("authMode").setValue(false);
      this.form.get("privMode").setValue(false);
      this.form.get("uname").disable();
      this.form.get("snmpip").disable();
      this.form.get("authMode").disable();
      this.form.get("privMode").disable();
      this.form.get("port").disable();
      this.form.get("engineId").disable();
      this.form.get("enableTrap").disable();
      this.form.get("authModeEncryption").disable();
      this.form.get("authModePassword").disable();
      this.form.get("privModeEncryption").disable();
      this.form.get("privModePassword").disable();
      this.form.get("uname").setValidators(null);
      this.form.get("snmpip").setValidators(null);
      this.form.get("port").setValidators(null);
      this.form.get("engineId").setValidators(null);
      this.form.get("uname").updateValueAndValidity();
      this.form.get("snmpip").updateValueAndValidity();
      this.form.get("port").updateValueAndValidity();
      this.form.get("engineId").updateValueAndValidity();
    }
  }

  toggleAuthMode(event) {
    if (event.checked) {
      this.form.get("privMode").enable();
      this.form.get("authModeEncryption").enable();
      this.form.get("authModePassword").enable();
      this.form.get("authModePassword").setValidators([Validators.required]);
      this.form.get("authModePassword").updateValueAndValidity();
      this.form.get("privModeEncryption").disable();
      this.form.get("privModePassword").disable();
      
    } else {
      this.form.get("privMode").disable();
      this.form.get("authModeEncryption").disable();
      this.form.get("authModePassword").disable();
      this.form.get("privModeEncryption").disable();
      this.form.get("privModePassword").disable();
      this.form.get("authModePassword").setValidators(null);
      this.form.get("authModePassword").updateValueAndValidity();
     
    }
  }

  togglePrivMode(event) {
    if (event.checked) {
      this.form.get("privModeEncryption").enable();
      this.form.get("privModePassword").enable();
      this.form.get("privModePassword").setValidators(null);
      this.form.get("privModePassword").updateValueAndValidity();
    } else {
      this.form.get("privModeEncryption").disable();
      this.form.get("privModePassword").disable();
      this.form.get("privModePassword").setValidators([Validators.required]);
      this.form.get("privModePassword").updateValueAndValidity();
    }
  }

  isValidIp = true;
  validateIPaddress(inputText) {
    this.isValidIp = true;
    var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    if (inputText != '') {
      if (inputText.match(ipformat)) {
        this.isValidIp = true;
      }
      else {
        this.isValidIp = false;
      }
    }
  }

  isValidAlphaNumeric = true;
  validateAlphanumeric(inputText) {
    this.isValidAlphaNumeric = true;
    var alphanumericformat = /^[0-9a-zA-Z]+$/;
    if (inputText != '') {
      if (inputText.match(alphanumericformat)) {
        this.isValidAlphaNumeric = true;
      }
      else {
        this.isValidAlphaNumeric = false;
      }
    }
  }

  isValidAlphaNumeric1 = true;
  validateAlphanumeric1(inputText) {
    this.isValidAlphaNumeric1 = true;
    var alphanumericformat = /^[0-9a-f]+$/;
    if (inputText != '') {
      if (inputText.match(alphanumericformat)) {
        this.isValidAlphaNumeric1 = true;
      }
      else {
        this.isValidAlphaNumeric1 = false;
      }
    }
    if (inputText.length < 10 ) {
      this.isValidAlphaNumeric1 = false;
    }
  }

  public OnlyNumericValues(e) {
    let input;
    if (e.metaKey || e.ctrlKey) {
      return true;
    }
    if (e.which === 32) {
      return false;
    }
    if (e.which === 0) {
      return true;
    }
    if (e.which < 33) {
      return true;
    }
    input = String.fromCharCode(e.which);
    return !!/[\d\s]/.test(input);
  }

  onCertificateFileChange($event) {
    this.loginForm.get('certificateFile').markAsTouched({ onlySelf: true });
    let file = $event.target.files[0];
    this.loginForm.controls['certificateFile'].setValue(file ? file.name : ''); // <-- Set Value for Validation
    const filePicked = (event.target as HTMLInputElement).files[0];
    if (filePicked != undefined) {
      const fileName = filePicked.name;
      const extension = filePicked.name.split('.').pop() || '';
      const reader = new FileReader();
      reader.onload = () => {
        if (extension == 'crt') {
          this.loginForm.get('certificateContent').setValue(reader.result);
          this.loginForm.get('certificateName').setValue(fileName.substring(0, fileName.indexOf('.')));
          this.loginForm.get('certificateExtension').setValue(extension);
        } else {
          this.loginForm.get('certificateFile').setErrors({ "invalidExt": true })

        }
      };
      reader.readAsText(filePicked);
    } else {
      this.loginForm.get('certificateFile').setValue("");
      this.loginForm.get('certificateContent').setValue("");
      this.loginForm.get('certificateName').setValue("");
      this.loginForm.get('certificateExtension').setValue("");
      return false;
    }
  }

  onKeyFileChange($event) {
    this.loginForm.controls['keyFile'].markAsTouched({ onlySelf: true });
    let file = $event.target.files[0];
    this.loginForm.controls['keyFile'].setValue(file ? file.name : ''); // <-- Set Value for Validation
    const filePicked = (event.target as HTMLInputElement).files[0];
    if (filePicked != undefined) {
      const fileName = filePicked.name;
      let ext = filePicked.name.split('.');
      const extension = ext[1];
      const reader = new FileReader();
      reader.onload = () => {
        if (extension == 'key') {
          this.loginForm.get('keyfileContent').setValue(reader.result);
          this.loginForm.get('keyfileName').setValue(fileName.substring(0, fileName.indexOf('.')));
          this.loginForm.get('keyfileExtension').setValue(extension);
        } else {
          this.loginForm.get('keyFile').setErrors({ "invalidExt": true })

        }
      };
      reader.readAsText(filePicked);
    } else {
      this.loginForm.get('keyFile').setValue("");
      this.loginForm.get('keyfileContent').setValue("");
      this.loginForm.get('keyfileName').setValue("");
      this.loginForm.get('keyfileExtension').setValue("");
      return false;
    }
  }
}  
