import { Component, OnInit, OnDestroy } from '@angular/core';
import { ChartsModule, Color } from 'ng2-charts';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { LoadingModule } from 'ngx-loading';
import { AnonymousSubscription } from "rxjs/Subscription";
import { Observable } from "rxjs/Observable";
declare var Chart: any;
declare var Morris: any;
@Component({
  selector: 'app-snapshot',
  templateUrl: './snapshot.component.html',
  styleUrls: ['./snapshot.component.css']
})
export class SnapshotComponent implements OnInit, OnDestroy {
  recentActivityList: any = [];
  alertsList: any = [];
  resourceUsage: any = [];
  alertDetails: any = [];
  private details: string;
  public loading = false;
  public timer: AnonymousSubscription;
  public getProgressActivities: AnonymousSubscription;
  constructor(private _applianceManagementService: AppliancemanagementService) { }
  public topologyDoughnutChartLabel: string[] = ['Active', 'Inactive'];
  public topologyDoughnutChartData: number[] = [];
  public topologyDoughnutChartType: string = 'doughnut';
  inProgressActivityList = [];
  myBarChart: any;
  isNoKeysAvailable: boolean = false;
  isNoAccelerationAvailable: boolean = false;
  isNoSSLContextAvailable: boolean = false;
  ngOnInit() {
    this.loadData('');
    this.getAlerts();
    this.getInProgressActivity();
    this.getRecentActivity();
  }
  loadData(chartName) {
    // this.loading=true;
    this.clearChartsData(chartName);
    this._applianceManagementService.getAllSnapshotDetails().subscribe(
      res => {
        this.resourceUsage = res.partitionsDetails;
        if (this.resourceUsage != null) {
          if (chartName == 'keys') {
            let availableKeys = this.resourceUsage.totalKeys - this.resourceUsage.occupiedKeys;
            if (this.resourceUsage.occupiedKeys != 0) {
              this.doughnutChartData.push(this.resourceUsage.occupiedKeys);
              this.doughnutChartData.push(availableKeys);
            }
            if (this.doughnutChartData.length <= 0) {
              this.isNoKeysAvailable = true;
            }
          } else if (chartName == 'acceleration') {
            let availableDevices = this.resourceUsage.totalAcclrDev - this.resourceUsage.occupiedAcclrDev;
            if (this.resourceUsage.occupiedAcclrDev != 0) {
              this.doughnutChartData1.push(this.resourceUsage.occupiedAcclrDev);
              this.doughnutChartData1.push(availableDevices);
            }
            if (this.doughnutChartData1.length <= 0) {
              this.isNoAccelerationAvailable = true;
            }
          } else if (chartName == 'sslContext') {
            let availableContexts = this.resourceUsage.totalContexts - this.resourceUsage.occupiedContexts;
            if (this.resourceUsage.occupiedContexts != 0) {
              this.doughnutChartData2.push(this.resourceUsage.occupiedContexts);
              this.doughnutChartData2.push(availableContexts);
            }
            if (this.doughnutChartData2.length <= 0) {
              this.isNoSSLContextAvailable = true;
            }
          } else if (chartName == 'topology') {
            this.listApplianceToplology = res.listApplianceToplology;
            this.createTopologyBarChart();
            this.createTopologyDonutChart();
          }
          else {
            this.setGraphData(res);
          }
        } else {
          this.isNoKeysAvailable = true;
          this.isNoAccelerationAvailable = true;
          this.isNoSSLContextAvailable = true;
        }


        // this.loading=false;

      },
      error => {
        this.loading = false;
        console.log(error);
      },
    );
  }
  setGraphData(res) {
    // keys
    let availableKeys = this.resourceUsage.totalKeys - this.resourceUsage.occupiedKeys;
    if (this.resourceUsage.occupiedKeys != 0) {
      this.doughnutChartData.push(this.resourceUsage.occupiedKeys);
      this.doughnutChartData.push(availableKeys);
    }
    if (this.doughnutChartData.length <= 0) {
      this.isNoKeysAvailable = true;
    }
    // acceleration
    let availableDevices = this.resourceUsage.totalAcclrDev - this.resourceUsage.occupiedAcclrDev;
    if (this.resourceUsage.occupiedAcclrDev != 0) {
      this.doughnutChartData1.push(this.resourceUsage.occupiedAcclrDev);
      this.doughnutChartData1.push(availableDevices);
    }
    if (this.doughnutChartData1.length <= 0) {
      this.isNoAccelerationAvailable = true;
    }
    // sslcontext
    let availableContexts = this.resourceUsage.totalContexts - this.resourceUsage.occupiedContexts;
    if (this.resourceUsage.occupiedContexts != 0) {
      this.doughnutChartData2.push(this.resourceUsage.occupiedContexts);
      this.doughnutChartData2.push(availableContexts);
    }
    if (this.doughnutChartData2.length <= 0) {
      this.isNoSSLContextAvailable = true;
    }

    // topology

    this.listApplianceToplology = res.listApplianceToplology;
    this.createTopologyBarChart();
    this.createTopologyDonutChart();
  }
  clearChartsData(chartName) {
    if (chartName == 'keys') {
      this.doughnutChartData = [];
      this.isNoKeysAvailable = false;
    } else if (chartName == 'acceleration') {
      this.doughnutChartData1 = [];
      this.isNoAccelerationAvailable = false;
    } else if (chartName == 'sslContext') {
      this.doughnutChartData2 = [];
      this.isNoSSLContextAvailable = false;
    } else if (chartName == 'topology') {
      this.topologyDoughnutChartData = [];
    }
    else {
      this.doughnutChartData = [];
      this.isNoKeysAvailable = false;
      this.doughnutChartData1 = [];
      this.isNoAccelerationAvailable = false;
      this.doughnutChartData2 = [];
      this.isNoSSLContextAvailable = false;
    }
  }
  getAlerts() {
    //this.loading = true;
    this._applianceManagementService.getAlertDetails().subscribe(
      res => {
        //this.loading = false;
        this.alertsList = [];
        res.forEach(element => {
          let alerts = {};
          // alerts['timezone'] = element.timezone;
          alerts['createdDate'] = element.createdDate;
          alerts['message'] = element.message;
          alerts['moduleId'] = element.moduleId;
          alerts['moduleName'] = element.moduleName;
          this.alertsList.push(alerts);
        });
      },
      error => {
        console.log(error);
      },
    );
  }

  getRecentActivity() {
    this.loading = true;
    this._applianceManagementService.getRecentActivityDetails().subscribe(
      res => {
        this.loading = false;
        this.recentActivityList = [];
        let colors = ["red", "green", "blue"];
        let count = 0;
        res.forEach(element => {
          let recentActivity = {};
          if (count == 3) {
            count = 0;
          }
          // recentActivity['timezone'] = element.timezone;
          recentActivity['message'] = element.message;
          recentActivity['createdDate'] = element.createdDate;
          recentActivity['color'] = colors[count];
          this.recentActivityList.push(recentActivity);
          count++;
        });
      },
      error => {
        console.log(error);
      },
    );
  }





  listApplianceToplology = []
  createTopologyBarChart() {

    var barlabels = this.listApplianceToplology.map(item => item.cityName)
    var d0 = this.listApplianceToplology.map(item => item.applianceStatus.activeStatus);
    var d1 = this.listApplianceToplology.map(item => item.applianceStatus.inactiveStatus);
    // var d2 = this.listApplianceToplology.map(item => item.applianceStatus.suspendedStatus);

    this.myBarChart = new Chart(document.getElementById("topology-bar"), {
      type: 'bar',
      data: {
        labels: barlabels,
        datasets: [
          {
            label: "Active",
            backgroundColor: "rgb(64, 197, 64)",
            data: d0
          }, {
            label: "Inactive",
            backgroundColor: "rgba(235, 109, 107, 0.911)",
            data: d1
          },
          // {
          //   label: "Suspend",
          //   backgroundColor: "rgba(247, 220, 67, 0.911)",
          //   data: d2
          // }
        ]
      },
      options: {

        title: {
          display: true,
          text: ''
        },
        legend: {
          display: true,
          position: 'bottom',
          labels: {
            boxWidth: 10
          }
        },
        scales: {
          xAxes: [{
            stacked: true, // this should be set to make the bars stacked
            barPercentage: 0.4
          }],
          yAxes: [{
            scaleLabel: {
              display: true,
              labelString: 'No. of Appliances',
              fontStyle: 'normal'
            },
            ticks: {
              beginAtZero: true,
              callback: function (value, index, values) {
                if (Math.floor(value) === value) {
                  return value;
                }
              }
            },
            stacked: true // this also..
          }]
        }
        // scales: {
        //   yAxes: [{
        //     scaleLabel: {
        //       display: true,
        //       labelString: "",
        //       gridLines: {
        //         drawBorder: true,
        //       },
        //     }
        //   }],
        //   xAxes: [{
        //     barPercentage: 0.9,
        //     scaleLabel: {
        //       display: true,
        //       labelString: ""
        //     }
        //   }]
        // }
      }
    });
  }
  createTopologyDonutChart() {
    let activeStatus: number = 0;
    let inactiveStatus: number = 0;
    let suspendedStatus: number = 0;
    this.topologyDoughnutChartData = [];
    //var barlabels = this.listApplianceToplology.map(item => item.cityName)
    this.listApplianceToplology.forEach(obj => {
      activeStatus = activeStatus + parseInt(obj.applianceStatus.activeStatus);
      inactiveStatus = inactiveStatus + parseInt(obj.applianceStatus.inactiveStatus);
      // suspendedStatus = suspendedStatus + parseInt(obj.applianceStatus.suspendedStatus);
    });
    this.topologyDoughnutChartData.push(activeStatus);
    this.topologyDoughnutChartData.push(inactiveStatus);
    // this.topologyDoughnutChartData.push(suspendedStatus);
  }

  public barChartOptions: any = {
    scaleShowVerticalLines: false,
    responsive: true,
    legend: {
      display: true,
      position: 'bottom',
      labels: {
        boxWidth: 10
      }
    }
  };
  public barChartType: string = 'bar';
  public barChartLegend: boolean = false;




  //Doughnut
  public doughnutChartData: number[] = [];
  public doughnutChartData1: number[] = [];
  public doughnutChartData2: number[] = [];
  public doughnutChartType: string = 'doughnut';
  public doughnutChartLabels: string[] = ['Used', 'Available'];
  public chartOptions = {
    responsive: true,
    legend: {
      display: true,
      position: 'right',
      labels: {
        boxWidth: 10
      }
    }
  };
  public donutcolors: Array<Color> = [
    {
      backgroundColor: [
        'rgb(64, 197, 64)',
        'rgba(235, 109, 107, 0.911)',
        'rgba(247, 220, 67, 0.911)'
      ]
    }
  ];
  public mycolors: Array<Color> = [
    {
      backgroundColor: [
        //'rgba(244, 99, 132, 0.8)',
        //'rgba(64, 162, 235, 0.8)',
        // 'rgba(255, 206, 86, 0.8)',
        // 'rgba(70, 192, 192, 0.8)',
        // 'rgba(287, 159, 64, 0.8)',
        // 'rgba(153, 102, 255, 0.8)',
        'rgb(247, 113, 131)',
        'rgb(84, 198, 233)'],
      hoverBackgroundColor: ['rgb(247, 113, 131)', 'rgb(84, 198, 233)'],
    }
  ];

  // events
  public chartClicked1(e: any): void {
    console.log(e);
  }

  public chartHovered1(e: any): void {
    console.log(e);
  }

  showBarChart: boolean = true;
  toggleCharts() {
    this.showBarChart = false;
  }

  toggleCharts1() {
    this.showBarChart = true;
  }
  getInProgressActivity() {
    //   this.inProgressActivityList = [{
    //     "key" : "FirmWare Upgrade",
    //     "value" : "20",
    //     "type" : "success"
    //   },
    //   {
    //     "key" : "Device Discovery",
    //     "value" : "30",
    //     "type" : "info"
    //   },
    //   {
    //     "key" : "Appliance Reboot",
    //     "value" : "40",
    //     "type" : "warning"
    //   }
    // ]
    this.getProgressActivities = this._applianceManagementService.getInProgressActivities().subscribe(
      res => {
        this.inProgressActivityList = res
      }
    );
    this.getTimeIntervalData();
  }

  private getTimeIntervalData(): void {
    this.timer = Observable.timer(15000).first().subscribe(() => this.getInProgressActivity());

  }
  public ngOnDestroy(): void {
    if (this.timer) {
      this.timer.unsubscribe();
    }
  }
}
