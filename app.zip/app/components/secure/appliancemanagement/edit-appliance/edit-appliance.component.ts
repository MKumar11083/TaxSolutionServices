import { Component, OnInit, ViewChild,Output,EventEmitter} from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { Configuration } from './../../../../app.constants';
import { CommonValidator } from '../../../../validators/common-validator';
@Component({
  selector: 'app-edit-appliance',
  templateUrl: './edit-appliance.component.html',
  styleUrls: ['./edit-appliance.component.css']
})
export class EditApplianceComponent implements OnInit {
  @ViewChild('editApplianceModal')
  editApplianceModal: ModalDirective;
  @ViewChild('editAppMessageModal')
  editAppMessageModal: ModalDirective;
  @ViewChild('messageModal') messageModal: ModalDirective;
  
  @Output() callBackEvent = new EventEmitter<any>();
  editApplianceForm: FormGroup;
  loading: boolean = false;
  applianceCount: number = 1;
  totalapplianceCount: number = 0;
  applianceName: string = '';
  selectedAppliances: any = [];
  isLastAppliance: boolean = false;
  displayErrors: string = '';
  successMessage: string = '';
  oldIpAddress: string = '';
  oldcredentialSaved: boolean = false;
  showBackButton : boolean = false;
  isDisabled:boolean=false;
  stayButton:boolean=true;
  stayButtonSuccess:boolean=true;
  closeButton:boolean=false;
  
  constructor(
    private applianceService: AppliancemanagementService,
    private _formBuilder: FormBuilder,
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _configuration: Configuration) { }

  ngOnInit() {
    this.selectedAppliances = [];
    this.createEditApplianceForm();
  }
  createEditApplianceForm() {
    this.editApplianceForm = this._formBuilder.group({
      ipAddress: ['', Validators.compose([Validators.required, CommonValidator.ipAddressValidator])],
      credentialSaved: [''],
      applianceId: [''],

    });
  }
  showEditApplianceModal(applianceArray) {
    this.selectedAppliances = applianceArray;
    this.editApplianceForm.reset();
    this.clearData();
    this.applianceCount = 1;
    this.totalapplianceCount = 0;
    if (this.selectedAppliances.length != 0) {
      if (this.selectedAppliances.length <= this._configuration.SELECT_MAX_APPLIANCE) {
        this.editApplianceModal.show();
        this.totalapplianceCount = this.selectedAppliances.length;
        let applianceId = this.selectedAppliances[this.applianceCount - 1]['applianceId'];
        this.getEditApplianceDetails(applianceId);
        if (this.applianceCount == this.totalapplianceCount) {
          this.isLastAppliance = true;
        } else {
          this.isLastAppliance = false;
        }
      }else{
        this.editAppMessageModal.show();
        this.displayErrors = "Sorry! Operation cannot be performed on more than 20 appliances"
      }
    }else{
      this.editAppMessageModal.show();
      this.displayErrors = "Please select any appliance to perform the activity!"
    }


  }
  getEditApplianceDetails(applianceId) {
    this.loading = true;
    this.applianceService.getEditApplianceDetails(applianceId).subscribe(
      (response) => {
        this.loading = false;
        if (response.ipAddress != null && response.ipAddress != '') {
          this.editApplianceForm.get('ipAddress').setValue(response.ipAddress);
          this.oldIpAddress = response.ipAddress;
        }
        this.editApplianceForm.get('credentialSaved').setValue(response.credentialSaved);
        this.oldcredentialSaved = response.credentialSaved;
        if(!response.credentialSaved){
          this.isDisabled= true;
        }else{
          this.isDisabled= false;
        }
        if (response.applianceId != null && response.applianceId != '') {
          this.editApplianceForm.get('applianceId').setValue(response.applianceId);
        }
        if (response.applianceName != null && response.applianceName != '') {
          this.applianceName = response.applianceName;
        } else {
          this.applianceName = '';
        }
      },
      (error) => {
        this.loading = false;
        console.log(error);
      }
    )
  }
  modifyAppliance() {
    this.showBackButton=false;
    this.stayButton=true;
    this.closeButton=false;
    this.stayButtonSuccess=true;
    this.successMessage = '';
    this.displayErrors = '';
    if (this.editApplianceForm.valid) {
      if (this.oldIpAddress != this.editApplianceForm.get('ipAddress').value
        || this.oldcredentialSaved != this.editApplianceForm.get('credentialSaved').value) {
        this.loading = true;
        this.applianceService.modifyAppliance(this.editApplianceForm.value).subscribe(
          (response) => {
            this.loading = false;
            let body = JSON.parse(response['_body']);
            let obj = body;
            if (obj) {
              if (obj.responseCode == "200") {
                this.messageModal.show();
                this.stayButtonSuccess=false;
                this.successMessage = obj.responseMessage;
                this.closeButton=true;
                this.oldIpAddress =  this.editApplianceForm.get('ipAddress').value;
                this.oldcredentialSaved = this.editApplianceForm.get('credentialSaved').value;
                if(!this.oldcredentialSaved){
                  this.isDisabled = true;
                }
              } else {
                
                this.displayErrors = obj.responseMessage;
              }
            }
          },
          (error) => {
            console.log(error);
          })
      } else {
        this.messageModal.show();
        this.stayButton=false;
        this.displayErrors = "No modifications made on the selected appliance";
      }
    }
  }

  getNextAppliance() {
    this.messageModal.hide();
    this.clearData();
    this.showBackButton = true;
    this.editApplianceForm.reset();
    if (this.applianceCount < this.totalapplianceCount) {
      this.applianceCount = this.applianceCount + 1;
      let applianceId = this.selectedAppliances[this.applianceCount - 1]['applianceId'];
      this.getEditApplianceDetails(applianceId);
      if (this.applianceCount == this.totalapplianceCount) {
        this.isLastAppliance = true;
      } else {
        this.isLastAppliance = false;
      }
    }
  }
  backOperation(){
    this.clearData();
    this.editApplianceForm.reset();
    this.applianceName = this.selectedAppliances[this.applianceCount - 2]['applianceName'];
    let backOperationCount = this.applianceCount - 2;
    let applianceId = this.selectedAppliances[backOperationCount]['applianceId'];
    this.getEditApplianceDetails(applianceId);
    this.applianceCount = this.applianceCount - 1;
    if (this.applianceCount == 1) {
      this.showBackButton = false;
    }

  }
  closeModal(){
    this.clearData();
    this.applianceCount = 1;
    this.totalapplianceCount = 0;
    this.selectedAppliances = [];
    this.editApplianceModal.hide();
    this.callBackEvent.emit();
  }

  clearData() {
    this.successMessage = '';
    this.displayErrors = '';
    this.loading = false;
    //this.applianceCount = 1;
    //this.totalapplianceCount = 0;
    this.applianceName = '';
    // this.selectedAppliances = [];
    this.isLastAppliance = false;
    this.isDisabled= false;
  }
  closeAll(){
    if(this.isLastAppliance){
      this.messageModal.hide();
    this.closeModal();
    }
    else{
      this.messageModal.hide();
    }    
  
  }
}
