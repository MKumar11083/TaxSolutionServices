import { Component, OnInit, ViewChild, Input,ElementRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import * as Hammer from 'hammerjs';
import { saveAs } from 'file-saver';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
declare var $: any;
declare var jQuery: any;
import { CommonValidator} from './../../../../validators/common-validator';

@Component({
  selector: 'app-adminvmmonitor',
  templateUrl: './adminvmmonitor.component.html',
  styleUrls: ['./adminvmmonitor.component.css']
})
export class AdminvmmonitorComponent implements OnInit {
  @ViewChild('certificate') certificateVariable : ElementRef;
  @ViewChild('key') keyVariable: ElementRef;
  @ViewChild('monitorModal1') monitorModal1: ModalDirective;
  @ViewChild('messageModal1') messageModal1: ModalDirective;
  @ViewChild('monitorLogin1') monitorLogin1: ModalDirective;
  name: string;
  @Input() applianceData;
  monitorModel: any = {};
  operation: string = '';
  info: string = '';
  warning: string = '';
  critical: string = '';
  isInfo: boolean = true;
  isWarning: boolean = false;
  isCritical: boolean = false;
  loading: boolean = false;
  responseArray: any = [];
  downloadError: string = '';
  loginForm: FormGroup;
  autenticationDetailsArray: any = [];
  savedLoginCredentails: any = {};
  applianceDualFactorInitialized: boolean = false;
  constructor(private _service: AppliancemanagementService,
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _formBuilder: FormBuilder) { }

  ngOnInit() {
    this.monitorModel = this.createMonitorDataJSON();
    this.createLoginForm();
    $(document).ready(function () {
      $("div.bhoechie-tab-menu>div.list-group>a").click(function (e) {
        e.preventDefault();
        $(this).siblings('a.active').removeClass("active");
        $(this).addClass("active");
        var index = $(this).index();
        $("div.bhoechie-tab>div.bhoechie-tab-content").removeClass("active");
        $("div.bhoechie-tab>div.bhoechie-tab-content").eq(index).addClass("active");
      });
      $("div.bhoechie-tab-menu>div.list-group1>a").click(function (e) {
        e.preventDefault();
        $(this).siblings('a.active').removeClass("active");
        $(this).addClass("active");
        var index = $(this).index();
        $("div.bhoechie-tab>div.bhoechie-tab-content1").removeClass("active");
        $("div.bhoechie-tab>div.bhoechie-tab-content1").eq(index).addClass("active");
      });
      $("div.bhoechie-tab-menu>div.list-group2>a").click(function (e) {
        e.preventDefault();
        $(this).siblings('a.active').removeClass("active");
        $(this).addClass("active");
        var index = $(this).index();
        $("div.bhoechie-tab>div.bhoechie-tab-content2").removeClass("active");
        $("div.bhoechie-tab>div.bhoechie-tab-content2").eq(index).addClass("active");
      });
    });
  }
  createMonitorDataJSON() {
    let modal = {
      "applianceId": "",
      "applianceName": "",
      "applianceStatus": "",
      "serialNumber": "",
      "networkTimezone": "",
      "gatewayIp": "",
      "ipAddress": "",
      "networkId": "",
      "subnetMask": "",
      "monitorType": "admin",
      "operationUsername": "",
      "operationPassword": "",
      "monitorData": {
        "cpu": {
          "info": this.getFields(),
          "warn": this.getFields(),
          "crit": this.getFields()
        },
        "pcpu": {
          "info": this.getFields(),
          "warn": this.getFields(),
          "crit": this.getFields()
        },
        "memory": {
          "info": this.getFields(),
          "warn": this.getFields(),
          "crit": this.getFields()
        },
        "network": {
          "interfacename": ""
        }
      }
    }
    return modal;
  }

  getFields() {
    let fields = {
      'start': 'no',
      'threshold': '1',
      'samplecount': '1',
      'isDisabled': true,
      'isChecked': false
    }
    return fields;
  }

  showMonitorLogin(value) {
    this.savedLoginCredentails = null;
    this.clearDetails();
    this.name = value;
    this.loginForm.reset();
    if (this.applianceData.credentialSaved == true) {
      this.getMonitorDetails();
    }else{
    let loginCredentials = JSON.parse(localStorage.getItem(this.applianceData.ipAddress));
    if (loginCredentials != null) {
      this.savedLoginCredentails = {};
      this.savedLoginCredentails['operationUsername'] = loginCredentials.username;
      this.savedLoginCredentails['operationPassword'] = loginCredentials.password;
      this.getMonitorDetails();
    } else {
      this.applianceDualFactorInitialized = this.applianceData['applianceDualFactorInitialized'];
      this.setValidationDualFactorAuthentication();
      this.monitorLogin1.show();
    }
  }
  }

  setDualFactorData(loginDetailsModal) {
    loginDetailsModal['initializeDetailModel'] = {};
    loginDetailsModal['initializeDetailModel']['cryptoOfficerName'] = this.loginForm.get('username').value;
    loginDetailsModal['initializeDetailModel']['cryptoOfficerPassword'] = this.loginForm.get('password').value;
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel'] = {};

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['dualFactorAuthServerPortNo'] = this.loginForm.get('dualFactorAuthServerPortNo').value;
    // certificate file details
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateContent'] = this.loginForm.get('certificateContent').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateName'] = this.loginForm.get('certificateName').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateExtension'] = this.loginForm.get('certificateExtension').value;
    // key file details
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileContent'] = this.loginForm.get('keyfileContent').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileName'] = this.loginForm.get('keyfileName').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileExtension'] = this.loginForm.get('keyfileExtension').value;
    return loginDetailsModal;
  }

  setValidationDualFactorAuthentication() {
    // set validations for dual factor properties 
    if (this.applianceDualFactorInitialized) {
      this.loginForm.get('dualFactorAuthServerPortNo').setValidators([Validators.required,CommonValidator.isNumberCheck]);
      this.loginForm.get('certificateFile').setValidators(Validators.required);
      this.loginForm.get('keyFile').setValidators(Validators.required);
    } else {
      this.loginForm.get('dualFactorAuthServerPortNo').setValidators(null);
      this.loginForm.get('certificateFile').setValidators(null);
      this.loginForm.get('keyFile').setValidators(null);
    }
    this.loginForm.get('dualFactorAuthServerPortNo').updateValueAndValidity();
    this.loginForm.get('certificateFile').updateValueAndValidity();
    this.loginForm.get('keyFile').updateValueAndValidity();
  }

  submitLoginDetails() {
    let loginDetailsModal = {};
    loginDetailsModal['applianceId'] = this.applianceData.applianceId;
    loginDetailsModal['applianceName'] = this.applianceData.applianceName;
    loginDetailsModal['ipAddress'] = this.applianceData.ipAddress;
    loginDetailsModal['operationUsername'] = this.loginForm.get('username').value;
    loginDetailsModal['operationPassword'] = this.loginForm.get('password').value;
    loginDetailsModal['applianceDualFactorInitialized'] = this.applianceData.applianceDualFactorInitialized;
    let dualFactorCheck = this.applianceData.applianceDualFactorInitialized;
    if (dualFactorCheck) {
      loginDetailsModal = this.setDualFactorData(loginDetailsModal);
    }
    this.autenticationDetailsArray.push(loginDetailsModal);
    this.checkAppliancesCredentials();
  }

  checkAppliancesCredentials() {
    if(this.applianceDualFactorInitialized){
      this.certificateVariable.nativeElement.value = '';
      this.keyVariable.nativeElement.value = "";
    }
    this.loading = true;
    this.responseArray = [];
    this.monitorLogin1.hide();
    this._service.checkAppliancesCredentials(this.autenticationDetailsArray).subscribe(
      (response) => {
        this.loading = false;
        let isSuccess: boolean = true;
        this.autenticationDetailsArray = [];
        response.forEach(obj => {
          if (obj.code != null) {
            if (obj.code != "200") {
              if (obj.code == "408") {
                this.downloadError = obj.errorMessage;
              } else {
                this.responseArray.push(obj);
              }
              isSuccess = false;
            } else {
              // Storing appliance login credentials in local session
              let ipAddress = obj.ipAddress;
              let loginCredentials = {
                username: this.loginForm.get('username').value,
                password: this.loginForm.get('password').value
              };
              localStorage.setItem(ipAddress, JSON.stringify(loginCredentials));
              // local session code ends here
            }
          } else {
            isSuccess = false;
            this.downloadError = "Operation can not perform due to connection error";
          }
        });
        if (isSuccess) {
          this.getMonitorDetails();
        } else {
          this.messageModal1.show();
        }
      },
      (error) => {
        this.loading = false;
        console.log(error);
      })
  }
  getMonitorDetails() {
    let applianceArray = this.setValuesToGetData();
    this._service.getApplianceMonitorData(applianceArray).subscribe(
      (response) => {
        this.setMonitorDataToModel(response);
        this.monitorModal1.show();
      },
      (error) => {
        console.log(error);
      }
    )
  }

  clearDetails() {
    this.name = '';
    this.monitorModel = this.createMonitorDataJSON();
    this.operation = '';
    this.info = '';
    this.warning = '';
    this.critical = '';
    this.isInfo = true;
    this.isWarning = false;
    this.isCritical = false;
    // this.isNetwork = false;
    this.loading = false;
    this.responseArray = [];
    this.downloadError = '';
  }

  setValuesToGetData() {
    let applianceData = {};
    let applianceArray: any = [];
    applianceData['applianceId'] = this.applianceData.applianceId;
    applianceData['applianceName'] = this.applianceData.applianceName;
    applianceData['applianceStatus'] = this.applianceData.applianceStatus;
    applianceData['serialNumber'] = this.applianceData.serialNumber;
    applianceData['networkTimezone'] = this.applianceData.networkTimezone;
    applianceData['gatewayIp'] = this.applianceData.gatewayIp;
    applianceData['ipAddress'] = this.applianceData.ipAddress;
    applianceData['networkId'] = this.applianceData.networkId;
    applianceData['subnetMask'] = this.applianceData.subnetMask;
    applianceData['monitorType'] = "admin";
    // applianceData['operationUsername'] = this.loginForm.get('username').value;
    // applianceData['operationPassword'] = this.loginForm.get('password').value;
    if (this.savedLoginCredentails != null) {
      applianceData['operationUsername'] = this.savedLoginCredentails.operationUsername;
      applianceData['operationPassword'] = this.savedLoginCredentails.operationPassword;
    } else {
      applianceData['operationUsername'] = this.loginForm.get('username').value;
      applianceData['operationPassword'] = this.loginForm.get('password').value;
    }
    applianceArray.push(applianceData);
    return applianceArray;
  }

  setMonitorDataToModel(response) {
    this.setApplianceDetailsToModel();
    response.forEach(obj => {
      if (obj.monitorData != null) {
        this.setMemoryDetailsToModel(obj);
        this.setCpuDetailsToModel(obj);
        this.setPcpuDetailsToModel(obj);
        this.setNetworkDetailsToModel(obj);
      }
    });
  }

  setApplianceDetailsToModel() {
    // appliance data

    this.monitorModel['applianceId'] = this.applianceData.applianceId;
    this.monitorModel['applianceName'] = this.applianceData.applianceName;
    this.monitorModel['applianceStatus'] = this.applianceData.applianceStatus;
    this.monitorModel['serialNumber'] = this.applianceData.serialNumber;
    this.monitorModel['networkTimezone'] = this.applianceData.networkTimezone;
    this.monitorModel['gatewayIp'] = this.applianceData.gatewayIp;
    this.monitorModel['ipAddress'] = this.applianceData.ipAddress;
    this.monitorModel['networkId'] = this.applianceData.networkId;
    this.monitorModel['subnetMask'] = this.applianceData.subnetMask;
    this.monitorModel['monitorType'] = "admin";
    if (this.savedLoginCredentails != null) {
      this.monitorModel['operationUsername'] = this.savedLoginCredentails.operationUsername;
      this.monitorModel['operationPassword'] = this.savedLoginCredentails.operationPassword;
    } else {
      this.monitorModel['operationUsername'] = this.loginForm.get('username').value;
      this.monitorModel['operationPassword'] = this.loginForm.get('password').value;
    }
  }

  setMemoryDetailsToModel(obj) {
    // memory
    if (obj.monitorData.memory != null) {
      if (obj.monitorData.memory.crit != null) {
        if (obj.monitorData.memory.crit.samplecount != null) {
          this.monitorModel['monitorData']['memory']['crit']['samplecount'] = obj.monitorData.memory.crit.samplecount;
        }
        if (obj.monitorData.memory.crit.threshold != null) {
          this.monitorModel['monitorData']['memory']['crit']['threshold'] = obj.monitorData.memory.crit.threshold;
        }
        if (obj.monitorData.memory.crit.start != null) {
          this.monitorModel['monitorData']['memory']['crit']['start'] = obj.monitorData.memory.crit.start;
        }
        if (obj.monitorData.memory.crit.start == "yes") {
          this.monitorModel['monitorData']['memory']['crit']['isChecked'] = true;
          this.monitorModel['monitorData']['memory']['crit']['isDisabled'] = false;
        }
      }
      if (obj.monitorData.memory.warn != null) {
        if (obj.monitorData.memory.warn.samplecount != null) {
          this.monitorModel['monitorData']['memory']['warn']['samplecount'] = obj.monitorData.memory.warn.samplecount;
        }
        if (obj.monitorData.memory.warn.threshold != null) {
          this.monitorModel['monitorData']['memory']['warn']['threshold'] = obj.monitorData.memory.warn.threshold;
        }
        if (obj.monitorData.memory.warn.start != null) {
          this.monitorModel['monitorData']['memory']['warn']['start'] = obj.monitorData.memory.warn.start;
        }
        if (obj.monitorData.memory.warn.start == "yes") {
          this.monitorModel['monitorData']['memory']['warn']['isChecked'] = true;
          this.monitorModel['monitorData']['memory']['warn']['isDisabled'] = false;
        }
      }
      if (obj.monitorData.memory.info != null) {
        if (obj.monitorData.memory.info.samplecount != null) {
          this.monitorModel['monitorData']['memory']['info']['samplecount'] = obj.monitorData.memory.info.samplecount;
        }
        if (obj.monitorData.memory.info.threshold != null) {
          this.monitorModel['monitorData']['memory']['info']['threshold'] = obj.monitorData.memory.info.threshold;
        }
        if (obj.monitorData.memory.info.start != null) {
          this.monitorModel['monitorData']['memory']['info']['start'] = obj.monitorData.memory.info.start;
        }
        if (obj.monitorData.memory.info.start == "yes") {
          this.monitorModel['monitorData']['memory']['info']['isChecked'] = true;
          this.monitorModel['monitorData']['memory']['info']['isDisabled'] = false;
        }
      }
    }
  }

  setCpuDetailsToModel(obj) {
    // cpu
    if (obj.monitorData.cpu != null) {
      if (obj.monitorData.cpu.crit != null) {
        if (obj.monitorData.cpu.crit.samplecount != null) {
          this.monitorModel['monitorData']['cpu']['crit']['samplecount'] = obj.monitorData.cpu.crit.samplecount;
        }
        if (obj.monitorData.cpu.crit.threshold != null) {
          this.monitorModel['monitorData']['cpu']['crit']['threshold'] = obj.monitorData.cpu.crit.threshold;
        }
        if (obj.monitorData.cpu.crit.start != null) {
          this.monitorModel['monitorData']['cpu']['crit']['start'] = obj.monitorData.cpu.crit.start;
        }
        if (obj.monitorData.cpu.crit.start == "yes") {
          this.monitorModel['monitorData']['cpu']['crit']['isChecked'] = true;
          this.monitorModel['monitorData']['cpu']['crit']['isDisabled'] = false;
        }
      }
      if (obj.monitorData.cpu.warn != null) {
        if (obj.monitorData.cpu.warn.samplecount != null) {
          this.monitorModel['monitorData']['cpu']['warn']['samplecount'] = obj.monitorData.cpu.warn.samplecount;
        }
        if (obj.monitorData.cpu.warn.threshold != null) {
          this.monitorModel['monitorData']['cpu']['warn']['threshold'] = obj.monitorData.cpu.warn.threshold;
        }
        if (obj.monitorData.cpu.warn.start != null) {
          this.monitorModel['monitorData']['cpu']['warn']['start'] = obj.monitorData.cpu.warn.start;
        }
        if (obj.monitorData.cpu.warn.start == "yes") {
          this.monitorModel['monitorData']['cpu']['warn']['isChecked'] = true;
          this.monitorModel['monitorData']['cpu']['warn']['isDisabled'] = false;
        }
      }
      if (obj.monitorData.cpu.info != null) {
        if (obj.monitorData.cpu.info.samplecount != null) {
          this.monitorModel['monitorData']['cpu']['info']['samplecount'] = obj.monitorData.cpu.info.samplecount;
        }
        if (obj.monitorData.cpu.info.threshold != null) {
          this.monitorModel['monitorData']['cpu']['info']['threshold'] = obj.monitorData.cpu.info.threshold;
        }
        if (obj.monitorData.cpu.info.start != null) {
          this.monitorModel['monitorData']['cpu']['info']['start'] = obj.monitorData.cpu.info.start;
        }
        if (obj.monitorData.cpu.info.start == "yes") {
          this.monitorModel['monitorData']['cpu']['info']['isChecked'] = true;
          this.monitorModel['monitorData']['cpu']['info']['isDisabled'] = false;
        }
      }
    }
  }

  setPcpuDetailsToModel(obj) {
    // pcpu
    if (obj.monitorData.pcpu != null) {
      if (obj.monitorData.pcpu.crit != null) {
        if (obj.monitorData.pcpu.crit.samplecount != null) {
          this.monitorModel['monitorData']['pcpu']['crit']['samplecount'] = obj.monitorData.pcpu.crit.samplecount;
        }
        if (obj.monitorData.pcpu.crit.threshold != null) {
          this.monitorModel['monitorData']['pcpu']['crit']['threshold'] = obj.monitorData.pcpu.crit.threshold;
        }
        if (obj.monitorData.pcpu.crit.start != null) {
          this.monitorModel['monitorData']['pcpu']['crit']['start'] = obj.monitorData.pcpu.crit.start;
        }
        if (obj.monitorData.pcpu.crit.start == "yes") {
          this.monitorModel['monitorData']['pcpu']['crit']['isChecked'] = true;
          this.monitorModel['monitorData']['pcpu']['crit']['isDisabled'] = false;
        }
      }
      if (obj.monitorData.pcpu.warn != null) {
        if (obj.monitorData.pcpu.warn.samplecount != null) {
          this.monitorModel['monitorData']['pcpu']['warn']['samplecount'] = obj.monitorData.pcpu.warn.samplecount;
        }
        if (obj.monitorData.pcpu.warn.threshold != null) {
          this.monitorModel['monitorData']['pcpu']['warn']['threshold'] = obj.monitorData.pcpu.warn.threshold;
        }
        if (obj.monitorData.pcpu.warn.start != null) {
          this.monitorModel['monitorData']['pcpu']['warn']['start'] = obj.monitorData.pcpu.warn.start;
        }
        if (obj.monitorData.pcpu.warn.start == "yes") {
          this.monitorModel['monitorData']['pcpu']['warn']['isChecked'] = true;
          this.monitorModel['monitorData']['pcpu']['warn']['isDisabled'] = false;
        }
      }
      if (obj.monitorData.pcpu.info != null) {
        if (obj.monitorData.pcpu.info.samplecount != null) {
          this.monitorModel['monitorData']['pcpu']['info']['samplecount'] = obj.monitorData.pcpu.info.samplecount;
        }
        if (obj.monitorData.pcpu.info.threshold != null) {
          this.monitorModel['monitorData']['pcpu']['info']['threshold'] = obj.monitorData.pcpu.info.threshold;
        }
        if (obj.monitorData.pcpu.info.start != null) {
          this.monitorModel['monitorData']['pcpu']['info']['start'] = obj.monitorData.pcpu.info.start;
        }
        if (obj.monitorData.pcpu.info.start == "yes") {
          this.monitorModel['monitorData']['pcpu']['info']['isChecked'] = true;
          this.monitorModel['monitorData']['pcpu']['info']['isDisabled'] = false;
        }
      }
    }
  }

  setNetworkDetailsToModel(obj) {
    if (obj.monitorData.network != null) {
      if (obj.monitorData.network.interfacename != null) {
        this.monitorModel['monitorData']['network']['interfacename'] = obj.monitorData.network.interfacename;
      }
    }
  }

  changeOperation(operation) {
    if (operation == "info") {
      this.info = "btn-primary";
      this.warning = "btn-default";
      this.critical = "btn-default";
      this.isInfo = true;
      this.isWarning = false;
      this.isCritical = false;
    } else if (operation == "warning") {
      this.info = "btn-default";
      this.warning = "btn-primary";
      this.critical = "btn-default";
      this.isInfo = false;
      this.isWarning = true;
      this.isCritical = false;
    } else if (operation == "critical") {
      this.info = "btn-default";
      this.warning = "btn-default";
      this.critical = "btn-primary";
      this.isInfo = false;
      this.isWarning = false;
      this.isCritical = true;
    }
  }

  enableSlider(event, value, value1) {
    if (event.checked) {
      this.monitorModel['monitorData'][value1][value]['isDisabled'] = false;
      this.monitorModel['monitorData'][value1][value]['start'] = "yes";
    } else {
      this.monitorModel['monitorData'][value1][value]['isDisabled'] = true;
      this.monitorModel['monitorData'][value1][value]['start'] = "no";
    }

  }

  submitMonitorDetails() {
    this.downloadError = '';
    this.responseArray = [];
    let applianceModelArray = [];
    if (this.monitorModel['monitorData']['network']['interfacename'] == "None") {
      this.downloadError = "Monitor: Input values are out of range for a parameter";
      this.monitorModal1.hide();
      this.messageModal1.show();
    } else {
      applianceModelArray.push(this.monitorModel);
      this.loading = true;
      this._service.setApplianceMonitorData(applianceModelArray).subscribe(
        (response) => {
          this.loading = false;
          this.monitorModal1.hide();
          this.messageModal1.show();
          this.responseArray = response;
        },
        (error) => {
          this.loading = false;
          console.log(error);
        }
      )

    }

  }


  formatLabel(value: number | null) {
    if (!value) {
      return 0;
    }

    if (value >= 100) {
      return Math.round(value / 100) + 'k';
    }

    return value;
  }

  downloadLogs() {
    this.loading = true;
    this.downloadError = '';
    this.responseArray = [];
    let applianceData = this.setValuesToGetData();
    this._service.downloadLogsForAppliance(applianceData[0]).subscribe(
      (response) => {
        this.loading = false;
        this.downloadFile(response);
      },
      (error) => {
        this.loading = false;
        console.log(error);
      }

    )
  }

  downloadFile(response) {
    const contentType = response.headers.get('Content-Type');
    if (contentType != 'text/html;charset=ISO-8859-1' && contentType != null) {
      const contentDispositionHeader: string = response.headers.get('Content-Disposition');
      if (contentDispositionHeader != null) {
        this.loading = false;
        const parts: string[] = contentDispositionHeader.split(';');
        const filename = parts[1].split('=')[1];
        const blob = new Blob([response._body], { type: response.headers.get('Content-Type') });
        saveAs(blob, filename);
      }
    } else {
      let res = JSON.stringify(response);
      let res1 = JSON.parse(res);
      this.downloadError = res1._body;
      this.messageModal1.show();
    }
  }

  createLoginForm() {
    this.loginForm = this._formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      dualFactorAuthServerPortNo:[''],
      certificateFile: [""],
      keyFile: [""],
      certificateName: [''],
      certificateExtension: [''],
      certificateContent: [''],
      keyfileName: [''],
      keyfileExtension: [''],
      keyfileContent: ['']
    });
  }

  public formValidationFields1 = {
    "username": '',
    "password": '',
    "dualFactorAuthServerPortNo" :''

  }
  isFieldValid1(field: string) {
    if (this.loginForm.get(field).touched) {
      this.formValidationFields1 = this._fieldErrorDisplayService.validateField(this.loginForm, field, this.formValidationFields1, "login")
    }
    return !this.loginForm.get(field).valid && this.loginForm.get(field).touched;
  }

  displayFieldCss1(field: string) {
    return {
      'has-error': this.isFieldValid1(field),
      'has-feedback': this.isFieldValid1(field)
    };
  }

  onCertificateFileChange($event) {
    this.loginForm.get('certificateFile').markAsTouched({ onlySelf: true });
    let file = $event.target.files[0];
    this.loginForm.controls['certificateFile'].setValue(file ? file.name : ''); // <-- Set Value for Validation
    const filePicked = (event.target as HTMLInputElement).files[0];
    if (filePicked != undefined) {
      const fileName = filePicked.name;
      const extension = filePicked.name.split('.').pop() || '';
      const reader = new FileReader();
      reader.onload = () => {
        if (extension == 'crt') {
          this.loginForm.get('certificateContent').setValue(reader.result);
          this.loginForm.get('certificateName').setValue(fileName.substring(0, fileName.indexOf('.')));
          this.loginForm.get('certificateExtension').setValue(extension);
        } else {
          this.loginForm.get('certificateFile').setErrors({ "invalidExt": true })

        }
      };
      reader.readAsText(filePicked);
    } else {
      this.loginForm.get('certificateFile').setValue("");
      this.loginForm.get('certificateContent').setValue("");
      this.loginForm.get('certificateName').setValue("");
      this.loginForm.get('certificateExtension').setValue("");
      return false;
    }
  }

  onKeyFileChange($event) {
    this.loginForm.controls['keyFile'].markAsTouched({ onlySelf: true });
    let file = $event.target.files[0];
    this.loginForm.controls['keyFile'].setValue(file ? file.name : ''); // <-- Set Value for Validation
    const filePicked = (event.target as HTMLInputElement).files[0];
    if (filePicked != undefined) {
      const fileName = filePicked.name;
      let ext = filePicked.name.split('.');
      const extension = ext[1];
      const reader = new FileReader();
      reader.onload = () => {
        if (extension == 'key') {
          this.loginForm.get('keyfileContent').setValue(reader.result);
          this.loginForm.get('keyfileName').setValue(fileName.substring(0, fileName.indexOf('.')));
          this.loginForm.get('keyfileExtension').setValue(extension);
        } else {
          this.loginForm.get('keyFile').setErrors({ "invalidExt": true })

        }
      };
      reader.readAsText(filePicked);
    } else {
      this.loginForm.get('keyFile').setValue("");
      this.loginForm.get('keyfileContent').setValue("");
      this.loginForm.get('keyfileName').setValue("");
      this.loginForm.get('keyfileExtension').setValue("");
      return false;
    }
  }
}
