import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PartitionSelftestreportComponent } from './partition-selftestreport.component';

describe('PartitionSelftestreportComponent', () => {
  let component: PartitionSelftestreportComponent;
  let fixture: ComponentFixture<PartitionSelftestreportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PartitionSelftestreportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PartitionSelftestreportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
