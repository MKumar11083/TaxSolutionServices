import { Component, OnInit, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
declare var $: any;
@Component({
  selector: 'app-partition-selftestreport',
  templateUrl: './partition-selftestreport.component.html',
  styleUrls: ['./partition-selftestreport.component.css']
})
export class PartitionSelftestreportComponent implements OnInit {
  @ViewChild('SelfTestModal')
  SelfTestModal: ModalDirective;
  @ViewChild('selecterror')
  selecterror: ModalDirective;
  @Input() selectedPartitionList;
  partitionCount = 1;
  valid=0;
  totalpartitionCount = 0;
  partitionName: string;
  applianceName: string;
  message: string;
  showBackButton = false;
  showNextButton = false;
  partitionList: any = [];
  ipAddress:any;
  selfTestReport:string='';
  selfTestRep: any = [];
  applianceId: string;
  partitionId:any;
  public loading = false;
  constructor(private _applianceManagementService: AppliancemanagementService) { }

  ngOnInit() {
    this.loading = true;
  }
  closeModalst(){
   
    this.SelfTestModal.hide();
    this.clearData();
    
  }
  showSelfTest() {
    let Modal={};
    let partitionDetailModels : any =[];
    Modal["applianceId"]=this.applianceId;
    Modal["applianceName"]=this.applianceName;
    Modal["ipAddress"]=this.ipAddress;
    let partitionModel = {};
    partitionModel["partitionName"]=this.partitionName;   
    partitionDetailModels.push(partitionModel);
    Modal['partitionDetailModels']=partitionDetailModels;
    Modal["selfReportType"]="partition";
      this._applianceManagementService.getSelfTestReport(Modal).subscribe(
      res => {
        console.log("Self Test Report"+JSON.stringify(res));
        let res1= JSON.stringify(res);
        let res2 =JSON.parse(res1);
        this.selfTestRep=res2.responseMessage.split("\\n") ;
        // this.selfTestRep=res2.responseMessage.split("\\n");


        this.selfTestReport = res2.responseMessage;
        if(res2.responseCode==11010){
          this.message =  res2.responseMessage;
          //this.selecterror.show();
          
          res2.responseCode=1;       


        }
        if(res2.responseCode==408){
          this.selfTestRep=[];
          
          
          this.message =  res2.responseMessage;
          this.selecterror.show();
          res2.responseCode=1;       

        }

        this.loading=false;
      },
      error => {
        this.loading=false;
        console.log(error);
      },
    );
  }
  showSelfTestReportModal(){
    $("#str").fadeOut(20);
    this.clearData();
    this.partitionList=this.selectedPartitionList;
    if(this.partitionList.length==0){
      this.message = "Please select any partition to perform the activity!";
      this.selecterror.show();
    }
    let partitionData = this.partitionList[this.partitionCount - 1];
    this.applianceName = partitionData.applianceName
    this.applianceId = partitionData.applianceId;
    this.ipAddress=partitionData.ipAddress;
    this.partitionId=partitionData.partitionData.partitionId;

    if (this.selectedPartitionList.length > 0) {
      if (this.selectedPartitionList.length <= 5) {
  
    //this.createPartitionList(partitionList);
    this.totalpartitionCount = this.partitionList.length;
    this.partitionName = partitionData.partitionName;
    this.SelfTestModal.show();
    this.showSelfTest();
    if (this.partitionCount < this.partitionList.length) {
      this.showNextButton = true;
         }
    else {
      this.showNextButton = false;

    }
  }
    else {
      this.SelfTestModal.show();
      this.message = "Sorry!Operation cannot be performed on more than five partitions";
    }
  }else {
    this.SelfTestModal.show();
      this.message = "Please select any partition to perform the activity!";
    
  }
    console.log(this.partitionList);

    $("#str").fadeIn("slow");
  }
  nextPartitionstr(){
    $("#str").fadeOut(20);
    this.loading = true;
    this.message =  "";
    
  if (this.partitionCount <= this.partitionList.length) {
      
      this.partitionCount++;
      let partitionData = this.partitionList[this.partitionCount - 1];
      this.partitionName = partitionData['partitionName'];
      this.applianceName = partitionData.applianceName
      this.applianceId = partitionData.applianceId;
      this.ipAddress=partitionData.ipAddress;
      this.showSelfTest();
      this.showBackButton = true;
      this.showNextButton = true;
      if (this.partitionCount == this.partitionList.length){
        this.showNextButton = false;
      }
      
       }
    else {
      
      //this.showNextButton = false;
      // this.applianceCount++;
    }
    this.loading = false;
    $("#str").fadeIn("slow");
  }
  backpartitionstr(){
    $("#str").fadeOut(20);
    this.loading = true;
    this.message =  "";
    let partitionData = this.partitionList[this.partitionCount - 2];
    this.applianceName = partitionData.applianceName
    this.applianceId = partitionData.applianceId;
    this.ipAddress=partitionData.ipAddress;
    this.partitionName = partitionData['partitionName'];
    this.partitionCount = this.partitionCount - 1;  
    this.showSelfTest(); 
    this.showBackButton = true;
    this.showNextButton = true;
    if (this.partitionCount == 1) {
      this.showBackButton = false;
     
      
    }
    this.loading = false;
    $("#str").fadeIn("slow");
  }

  clearData() {
    
    this.partitionCount = 1;
    this.totalpartitionCount = 0;
    this.showNextButton = true;
    this.partitionName = '';
    this.message = '';
    
  }

}
