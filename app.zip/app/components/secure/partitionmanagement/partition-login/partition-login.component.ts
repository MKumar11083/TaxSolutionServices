import { Component, OnInit, ViewChild, Input, Output, EventEmitter, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { PartitionOperationsComponent } from './../partition-operations/partition-operations.component';
import { ConfigureNetworkComponent } from './../configure-network/configure-network.component';
import { UploadConfigComponent } from './../cavserver/upload-config/upload-config.component';
import { BackupRestoreComponent } from './../backup-restore/backup-restore.component';
import { PartitionBackupComponent } from './../partition-backup/partition-backup.component';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { PartitionResizeComponent } from './../partition-resize/partition-resize.component';
import { Configuration } from './../../../../app.constants';
import { CommonValidator } from './../../../../validators/common-validator';
@Component({
  selector: 'app-partition-login',
  templateUrl: './partition-login.component.html',
  styleUrls: ['./partition-login.component.css']
})
export class PartitionLoginComponent implements OnInit {
  @ViewChild('certificate') certificateVariable: ElementRef;
  @ViewChild('key')
  keyVariable: ElementRef;
  @ViewChild('partitionLoginModal')
  partitionLoginModal: ModalDirective;
  @ViewChild('confirmModal')
  confirmModal: ModalDirective;
  @ViewChild('messageModal')
  messageModal: ModalDirective;
  @ViewChild('partitionOperationsComponent')
  private partitionOperationsComponent: PartitionOperationsComponent;
  @ViewChild('configureNetwork')
  private configureNetwork: ConfigureNetworkComponent;
  @ViewChild('uploadConfig')
  private uploadConfig: UploadConfigComponent;
  @ViewChild('backupRestore')
  private backupRestore: BackupRestoreComponent;
  @ViewChild('partitionBackup')
  private partitionBackup: PartitionBackupComponent;
  @ViewChild('partitionResize')
  private partitionResize: PartitionResizeComponent;
  @ViewChild("username") userNameField: ElementRef;

  @Input() selectedPartitionList;
  @Output() loginEvent = new EventEmitter<any>();
  loginForm: FormGroup;
  partitionOperation: string;
  nonCredentialSavedParitionList = [];
  credentialsSavedPartitionList = []
  partitionCount = 1;
  totalpartitionCount = 0;
  partitionName: string;
  message: string;
  isLastPartition: boolean = false;
  finalPartitionList = [];
  partitionMap: Map<string, Array<any>>;
  checkCloseSession: boolean = false;
  loginCredentialsArray: any = [];
  saveCredentialsToSessionArray: any = [];
  loading: boolean = false;
  backupDisabledList: any = [];
  applianceDualFactorInitialized: boolean = false;
  notReachableList: any = [];
  isDuplicatePartitionForResize: boolean = false;
  constructor(private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _formBuilder: FormBuilder,
    private _service: AppliancemanagementService,
    private _configuration: Configuration) { }

  ngOnInit() {
    this.createLoginForm();
  }

  createLoginForm() {
    this.loginForm = this._formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      dualFactorAuthServerPortNo: [''],
      certificateFile: [""],
      keyFile: [""],
      certificateName: [''],
      certificateExtension: [''],
      certificateContent: [''],
      keyfileName: [''],
      keyfileExtension: [''],
      keyfileContent: ['']
    });
  }
  credentialsSavedMap: Map<string, boolean>;
  showLoginModal(operation) {
    let count: number = 0;
    this.isDuplicatePartitionForResize = false;
    this.credentialsSavedMap = new Map<string, boolean>();
    if (this.selectedPartitionList.length != 0) {
      if (this.selectedPartitionList.length <= this._configuration.SELECT_MAX_PARTITION) {
        // checking condition for resize operation ,
        //  restricting if user select multiple partitions from same appliance.
        if (operation == "Resize") {
          let applianceIds = this.selectedPartitionList.map(partition => {
            return partition.applianceId;
          });
          this.isDuplicatePartitionForResize = applianceIds.some((val, i) => {
            return applianceIds.indexOf(val) != i
          });
        }
        // code ends here for resize .
        if (!this.isDuplicatePartitionForResize) {
          // checking the status of partition , if it is unreachable than showing message to user.
          this.selectedPartitionList.forEach(partition => {
            this.notReachableList = this.selectedPartitionList.filter(partition => {
              if (partition['tempFipsStatus'] == "Inactive") {
                return partition;
              }
            });
            // ends here
            if (this.notReachableList <= 0) {
              if (partition.applianceDualFactorInitialized) {
                this._service.getSessionCredentialsDetails(partition.applianceId).subscribe(
                  res => {
                    count++;
                    this.credentialsSavedMap.set(partition.applianceId, res);
                    if (this.selectedPartitionList.length == count) {
                      this.setPartitionLoginDetails(operation);
                    }
                  },
                  error => {
                    count++;
                    console.log(error);
                    if (this.selectedPartitionList.length == count) {
                      this.setPartitionLoginDetails(operation);
                    }
                  })
              } else {
                count++;
                if (this.selectedPartitionList.length == count) {
                  this.setPartitionLoginDetails(operation);
                }
              }
            } else {
              this.messageModal.show();
            }
          })
        } else {

          this.messageModal.show();
        }
      } else {
        this.partitionLoginModal.show();
        this.message = "Sorry!Operation cannot be performed on more than 32 partitions";
      }
    } else {
      this.partitionLoginModal.show();
      this.message = "Please select any partition to perform the activity!";
    }
  }
  // initial method to execute for login form.
  setPartitionLoginDetails(operation) {
    this.clearData();
    this.partitionMap = new Map<string, Array<any>>();
    this.partitionOperation = operation;
    // construct map based on applianceId for selected PartitionList
    this.selectedPartitionList.forEach(partitionObj => {
      let tempMap: Array<any> = [];
      if (this.partitionMap.has(partitionObj['applianceId'])) {
        tempMap = this.partitionMap.get(partitionObj['applianceId']);
      }
      tempMap.push(partitionObj);
      this.partitionMap.set(partitionObj['applianceId'], tempMap);
    });
    //construct map code ends here
    // get all the applianceIds form the map and iterate each applianceId , to 
    // identity the credentialSaved or not 
    let applianceIds = Array.from(this.partitionMap.keys());
    applianceIds.forEach(appId => {
      if (this.partitionMap.has(appId)) {
        let partitionObj = this.partitionMap.get(appId)[0];
        if (partitionObj['credentialSaved']) {
          this.credentialsSavedPartitionList.push(partitionObj);
        } else {
          this.checkApplianceStored(partitionObj);
          // check appliance credentials are available in localsession.
          // if available in localsession , skips the login for appliance.
          let loginCredentials = JSON.parse(localStorage.getItem(partitionObj.ipAddress));
          if (loginCredentials != null) {
            partitionObj['username'] = loginCredentials.username;
            partitionObj['password'] = loginCredentials.password;
            this.saveCredentialsToSessionArray.push(partitionObj);
          } else {
            this.nonCredentialSavedParitionList.push(partitionObj);
          }
        }
      }
    });
    //  check the length of non credentialsaved Partition List to show the login pop.
    // if length is 0 , then show the confirm modal,whether to continue the selected Operation or not.
    if (this.nonCredentialSavedParitionList.length > 0) {
      this.partitionName = this.nonCredentialSavedParitionList[this.partitionCount - 1]['applianceName'];
      // dual factor authentication
      this.applianceDualFactorInitialized = this.nonCredentialSavedParitionList[this.partitionCount - 1]['applianceDualFactorInitialized'];
      this.setValidationDualFactorAuthentication();
      // ends here 
      this.totalpartitionCount = this.nonCredentialSavedParitionList.length;
      if (this.partitionCount == this.totalpartitionCount) {
        this.isLastPartition = true;
      }
      this.partitionLoginModal.show();
    } else {
      this.confirmModal.show();
    }
  }
  checkApplianceStored(appliance) {
    if (this.credentialsSavedMap.has(appliance.applianceId)) {
      let isSaved = this.credentialsSavedMap.get(appliance.applianceId);
      if (!isSaved) {
        localStorage.removeItem(appliance.ipAddress);
      }
    }
  }
  goToNextPartition() {
    this.userNameField.nativeElement.focus();
    let applianceData = this.nonCredentialSavedParitionList[this.partitionCount - 1];
    this.createListOfPartitions(applianceData, "login");
    let loginDetailsModal = {};
    loginDetailsModal['applianceId'] = applianceData.applianceId;
    loginDetailsModal['applianceName'] = applianceData.applianceName;
    loginDetailsModal['ipAddress'] = applianceData.ipAddress;
    loginDetailsModal['operationUsername'] = this.loginForm.get('username').value;
    loginDetailsModal['operationPassword'] = this.loginForm.get('password').value;
    loginDetailsModal['applianceDualFactorInitialized'] = applianceData.applianceDualFactorInitialized;
    let dualFactorCheck = applianceData.applianceDualFactorInitialized;
    if (dualFactorCheck) {
      loginDetailsModal = this.setDualFactorData(loginDetailsModal);
    }
    this.loginCredentialsArray.push(loginDetailsModal);
    // Storing appliance login credentials in local session
    let ipAddress = applianceData.ipAddress;
    let loginCredentials = {
      username: this.loginForm.get('username').value,
      password: this.loginForm.get('password').value
    };
    localStorage.setItem(ipAddress, JSON.stringify(loginCredentials));
    // local session code ends here
    if (this.partitionCount < this.nonCredentialSavedParitionList.length) {
      this.partitionName = this.nonCredentialSavedParitionList[this.partitionCount]['applianceName'];
      this.applianceDualFactorInitialized = this.nonCredentialSavedParitionList[this.partitionCount]['applianceDualFactorInitialized'];
      this.setValidationDualFactorAuthentication();
      this.partitionCount++;
      if (this.partitionCount == this.totalpartitionCount) {
        this.isLastPartition = true;
      }
    } else {
      this.partitionLoginModal.hide();
      this.checkAppliancesCredentials();
    }
    if (dualFactorCheck) {
      this.certificateVariable.nativeElement.value = '';
      this.keyVariable.nativeElement.value = "";
    }
    this.loginForm.reset();

  }

  checkAppliancesCredentials() {
    this.loading = true;
    this._service.checkAppliancesCredentials(this.loginCredentialsArray).subscribe(
      (response) => {
        this.loading = false;
        let isSuccess: boolean = true;
        this.partitionLoginModal.hide();
        this.loginCredentialsArray = [];
        response.forEach(obj => {
          if (obj.code != "200") {
            this.loginCredentialsArray.push(obj);
            localStorage.removeItem(obj.ipAddress);
            isSuccess = false;
          }
        });
        if (isSuccess) {
          this.confirmModal.show();
        } else {
          this.messageModal.show();
        }
      },
      (error) => {
        this.loading = false;
        console.log(error);
      })
  }
  // create the list of partitions .
  createListOfPartitions(partitionData, value) {
    if (this.partitionMap.has(partitionData.applianceId)) {
      let partitionList = this.partitionMap.get(partitionData.applianceId);
      partitionList.forEach(obj => {
        let partitionModel = {
          applianceDetailModel: {}
        };
        if (value == "login") {
          partitionModel['username'] = this.loginForm.get('username').value;
          partitionModel['password'] = this.loginForm.get('password').value;
        } else {
          partitionModel['username'] = partitionData.username;
          partitionModel['password'] = partitionData.password;
        }

        if (this.checkCloseSession) {
          partitionModel['sessionClose'] = true;
        } else {
          partitionModel['sessionClose'] = false;
        }
        if (this.partitionOperation == "Start") {
          partitionModel['enableCavServer'] = true;
        } else {
          partitionModel['enableCavServer'] = false;
        }
        partitionModel['partitionId'] = obj['partitionId'];
        partitionModel['partitionName'] = obj['partitionName'];
        partitionModel['csr'] = obj['csr'];
        partitionModel['keys'] = obj['keys'];
        partitionModel['sslContexts'] = obj['sslContexts'];
        partitionModel['acclrDev'] = obj['acclrDev'];
        partitionModel['wrap'] = obj['wrap'];
        partitionModel['backup'] = obj['backup'];
        partitionModel['cityName'] = obj['cityName'];
        partitionModel['networkStats'] = obj['networkStats'];
        partitionModel.applianceDetailModel['applianceId'] = obj['applianceId'];
        partitionModel.applianceDetailModel['applianceName'] = obj['applianceName'];
        partitionModel.applianceDetailModel['ipAddress'] = obj['ipAddress'];
        this.finalPartitionList.push(partitionModel);
      });
    }
  }
  // forward the control to the operation component
  performSelectedOperationForPartition() {
    this.confirmModal.hide();
    let count: number = 0;
    this.finalPartitionList.forEach(partitionObj => {
      if (this.checkCloseSession) {
        this.finalPartitionList[count]['sessionClose'] = true;
      } else {
        this.finalPartitionList[count]['sessionClose'] = false;
      }
      count = count + 1;
    });
    this.credentialsSavedPartitionList.forEach(partitionObj => {
      this.createListOfPartitions(partitionObj, "");
    });

    this.saveCredentialsToSessionArray.forEach(partitionObj => {
      this.createListOfPartitions(partitionObj, "");
    });
    if (this.partitionOperation == 'Configure Network') {
      this.configureNetwork.showConfigureNetworkModal(this.finalPartitionList);
    } else if (this.partitionOperation == 'Upload') {
      this.uploadConfig.showUploadConfig(this.finalPartitionList, this.partitionOperation);
    } else if (this.partitionOperation == 'Restore') {
      this.backupDisabledList = [];
      let backupFalsePartitionName = '';
      this.finalPartitionList.forEach(obj => {
        if (!obj.backup) {
          this.backupDisabledList.push(obj);
        }
      });
      if (this.backupDisabledList.length > 0) {
        this.finalPartitionList = [];
        this.messageModal.show();
      } else {
        this.backupRestore.showBackUpRestore(this.finalPartitionList, this.partitionOperation);
      }
    } else if (this.partitionOperation == 'Backup') {
      this.backupDisabledList = [];
      let backupFalsePartitionName = '';
      this.finalPartitionList.forEach(obj => {
        if (!obj.backup) {
          this.backupDisabledList.push(obj);
        }
      });
      if (this.backupDisabledList.length > 0) {
        this.finalPartitionList = [];
        this.messageModal.show();
      } else {
        this.partitionBackup.showPartitionBackupModal(this.finalPartitionList, this.partitionOperation);
      }
    } else if (this.partitionOperation == 'Resize') {
      this.partitionResize.showPartitionResizeModal(this.finalPartitionList);
    }
    else {
      this.partitionOperationsComponent.performSelectedOperation(this.finalPartitionList, this.partitionOperation);
    }
  }

  closeLoginModal() {
    console.log("Close ----> Partition Login Modal");
    this.partitionLoginModal.hide();
    this.clearData();
  }

  closeConfirmModal() {
    console.log("Close ----> Confirm  Modal");
    this.confirmModal.hide();
    this.clearData();
  }
  // reset method
  clearData() {
    this.loginForm.reset();
    this.partitionOperation = '';
    this.nonCredentialSavedParitionList = [];
    this.credentialsSavedPartitionList = []
    this.partitionCount = 1;
    this.totalpartitionCount = 0;
    this.partitionName = '';
    this.message = '';
    this.isLastPartition = false;
    this.finalPartitionList = [];
    this.checkCloseSession = false;
    this.loginCredentialsArray = [];
    this.saveCredentialsToSessionArray = [];
    this.backupDisabledList = [];
    this.applianceDualFactorInitialized = false;
  }
  // call back to partition list page
  callBackToPartitionList() {
    console.log("Partition Login  --> Call back to partition list");
    this.clearData();
    this.selectedPartitionList = [];
    this.loginEvent.emit();
  }
  public formValidationFields1 = {
    "username": '',
    "password": ''

  }
  isFieldValid1(field: string) {
    if (this.loginForm.get(field).touched) {
      this.formValidationFields1 = this._fieldErrorDisplayService.validateField(this.loginForm, field, this.formValidationFields1, "login")
    }
    return !this.loginForm.get(field).valid && this.loginForm.get(field).touched;
  }

  displayFieldCss1(field: string) {
    return {
      'has-error': this.isFieldValid1(field),
      'has-feedback': this.isFieldValid1(field)
    };
  }

  setDualFactorData(loginDetailsModal) {
    loginDetailsModal['initializeDetailModel'] = {};
    loginDetailsModal['initializeDetailModel']['cryptoOfficerName'] = this.loginForm.get('username').value;
    loginDetailsModal['initializeDetailModel']['cryptoOfficerPassword'] = this.loginForm.get('password').value;
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel'] = {};

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['dualFactorAuthServerPortNo'] = this.loginForm.get('dualFactorAuthServerPortNo').value;
    // certificate file details
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateContent'] = this.loginForm.get('certificateContent').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateName'] = this.loginForm.get('certificateName').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateExtension'] = this.loginForm.get('certificateExtension').value;
    // key file details
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileContent'] = this.loginForm.get('keyfileContent').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileName'] = this.loginForm.get('keyfileName').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileExtension'] = this.loginForm.get('keyfileExtension').value;
    return loginDetailsModal;
  }

  setValidationDualFactorAuthentication() {
    // set validations for dual factor properties 
    if (this.applianceDualFactorInitialized) {
      this.loginForm.get('dualFactorAuthServerPortNo').setValidators([Validators.required, CommonValidator.isNumberCheck]);
      this.loginForm.get('certificateFile').setValidators(Validators.required);
      this.loginForm.get('keyFile').setValidators(Validators.required);
    } else {
      this.loginForm.get('dualFactorAuthServerPortNo').setValidators(null);
      this.loginForm.get('certificateFile').setValidators(null);
      this.loginForm.get('keyFile').setValidators(null);
    }
    this.loginForm.get('dualFactorAuthServerPortNo').updateValueAndValidity();
    this.loginForm.get('certificateFile').updateValueAndValidity();
    this.loginForm.get('keyFile').updateValueAndValidity();
  }

  onCertificateFileChange($event) {
    this.loginForm.get('certificateFile').markAsTouched({ onlySelf: true });
    let file = $event.target.files[0];
    this.loginForm.controls['certificateFile'].setValue(file ? file.name : ''); // <-- Set Value for Validation
    const filePicked = (event.target as HTMLInputElement).files[0];
    if (filePicked != undefined) {
      const fileName = filePicked.name;
      const extension = filePicked.name.split('.').pop() || '';
      const reader = new FileReader();
      reader.onload = () => {
        if (extension == 'crt') {
          this.loginForm.get('certificateContent').setValue(reader.result);
          this.loginForm.get('certificateName').setValue(fileName.substring(0, fileName.indexOf('.')));
          this.loginForm.get('certificateExtension').setValue(extension);
        } else {
          this.loginForm.get('certificateFile').setErrors({ "invalidExt": true })

        }
      };
      reader.readAsText(filePicked);
    } else {
      this.loginForm.get('certificateFile').setValue("");
      this.loginForm.get('certificateContent').setValue("");
      this.loginForm.get('certificateName').setValue("");
      this.loginForm.get('certificateExtension').setValue("");
      return false;
    }
  }

  onKeyFileChange($event) {
    this.loginForm.controls['keyFile'].markAsTouched({ onlySelf: true });
    let file = $event.target.files[0];
    this.loginForm.controls['keyFile'].setValue(file ? file.name : ''); // <-- Set Value for Validation
    const filePicked = (event.target as HTMLInputElement).files[0];
    if (filePicked != undefined) {
      const fileName = filePicked.name;
      let ext = filePicked.name.split('.');
      const extension = ext[1];
      const reader = new FileReader();
      reader.onload = () => {
        if (extension == 'key') {
          this.loginForm.get('keyfileContent').setValue(reader.result);
          this.loginForm.get('keyfileName').setValue(fileName.substring(0, fileName.indexOf('.')));
          this.loginForm.get('keyfileExtension').setValue(extension);
        } else {
          this.loginForm.get('keyFile').setErrors({ "invalidExt": true })

        }
      };
      reader.readAsText(filePicked);
    } else {
      this.loginForm.get('keyFile').setValue("");
      this.loginForm.get('keyfileContent').setValue("");
      this.loginForm.get('keyfileName').setValue("");
      this.loginForm.get('keyfileExtension').setValue("");
      return false;
    }
  }

}
