import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { PartitionManagementService } from './../../../services/partitionmanagement/partitionmanagement.service';
import { AnonymousSubscription } from "rxjs/Subscription";
import { DataTableResource } from './../data-table/index';
import { I18nService } from '../../../services/common/i18n/i18n.service';
import { BreadcrumbService } from './../../../services/common/breadcrumb.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../services/common/field-error-display.service';
import { PartitionLoginComponent } from './partition-login/partition-login.component'
import { Observable } from "rxjs/Observable";
import { PartitionSelftestreportComponent } from './partition-selftestreport/partition-selftestreport.component';
declare var $: any;
@Component({
  selector: 'app-partitionmanagement',
  templateUrl: './partitionmanagement.component.html',
  styleUrls: ['./partitionmanagement.component.css'],

})
export class PartitionmanagementComponent implements OnInit, OnDestroy {

  @ViewChild('partitionLoginComponent')
  private partitionLoginComponent: PartitionLoginComponent;
  @ViewChild('PartitionSelftestreportComponent')
  private PartitionSelftestreportComponent: PartitionSelftestreportComponent;

  title = "Partition Details";
  partitionList: any = [];
  finalPartitionList: any = [];
  showList: boolean = false;
  selectedPartitionList = [];
  toolTipData: string;
  KekStatus: string;
  checkInProgressStatus: boolean = false;
  loading: boolean = false;
  private timer: AnonymousSubscription;
  private partitionListSubscription: AnonymousSubscription;
  valid: boolean = false;
  itemResource: any;
  itemCount;
  listtrue: boolean = true;
  reloadTimer: number = 10000;
  selectedHeader: string = '';
  sortAsc: boolean = true;
  sortName: boolean = true;
  sortFipstatus: boolean = true;
  sortSSLContext: boolean = true;
  sortKeys: boolean = true;
  constructor(private _service: PartitionManagementService,
    private _I18nService: I18nService,
    private _formBuilder: FormBuilder,
    private _fieldErrorDisplayService: FieldErrorDisplayService) {

  }

  ngOnInit() {
    this.getPartitionList("");

  }
  getOperations(operation): void {
    this.partitionLoginComponent.showLoginModal(operation);
  }
  getPartitionList(value) {
    this._service.getListOfPartition().subscribe(
      res => {
        this.partitionList = [];
        this.loading = false;
        this.checkInProgressStatus = false;
        if (res.length > 0) {
          this.listtrue = true;
        } else {
          this.listtrue = false;
        }
        this.finalPartitionList = res;
        res.forEach(partitionObj => {
          let fipsState = '';
          let checkFipsState = '';
          let vmStatus: number = 0;
          let cavServerStatus: number = 0;
          let partitionData: any;
          if (partitionObj.partitionData != null) {
            partitionData = partitionObj.partitionData;
            if (partitionData.fipsState != null) {
              let checkFIPState = partitionData.fipsState;
              if (checkFIPState.includes('zeroized')) {
                fipsState = "zeroized";
              } else if (checkFIPState.includes('FIPS')) {
                fipsState = "nonzeroized";
              }else if(checkFIPState.includes('5[Inactive]')){
                fipsState = "Inactive"
              }
              //fipsState = partitionData.fipsState.split(" ", 2)[1].replace(/[\[\]']+/g, '');
            }
            if (partitionData.vmStatus != null) {
              vmStatus = partitionData.vmStatus;
            }
            if (partitionData.cavServerStatus != null) {
              cavServerStatus = partitionData.cavServerStatus;
            }
            partitionObj['partitionStatus'] = "";
            if(fipsState == "Inactive"){
              partitionObj['tempFipsStatus'] = fipsState;
            }else{
              partitionObj['tempFipsStatus'] = partitionData.fipsState;
            }
            if (partitionData.totalSslCtxs != null) {
              partitionObj['tempTotalSslCtxs'] = partitionData.totalSslCtxs;
            }
            if (fipsState == "zeroized" && vmStatus == 0 && cavServerStatus == 0) {
              partitionObj['statusColor'] = "lightgrey";
            } else if (fipsState == "zeroized" && vmStatus == 0 && cavServerStatus == 1) {
              partitionObj['statusColor'] = "lightgrey";
            } else if (fipsState == "zeroized" && vmStatus == 0 && cavServerStatus == -1) {
              partitionObj['statusColor'] = "orange";
            } else if (fipsState == "zeroized" && vmStatus == 1 && cavServerStatus == 1) {
              partitionObj['statusColor'] = "green";
            }
            else if (fipsState == "zeroized" && vmStatus == 1 && cavServerStatus == 0) {
              partitionObj['statusColor'] = "yellow";
            }
            else if (fipsState == "nonzeroized" && vmStatus == 1 && cavServerStatus == 0) {
              partitionObj['statusColor'] = "yellow";
            } else if (fipsState == "nonzeroized" && vmStatus == 1 && cavServerStatus == 1) {
              partitionObj['statusColor'] = "green";
            } else if (fipsState == "nonzeroized" && vmStatus == 1 && cavServerStatus == -1) {
              partitionObj['statusColor'] = "red";
            } else if (fipsState == "nonzeroized" && vmStatus == -1 && cavServerStatus == 0) {
              partitionObj['statusColor'] = "red";
            } else if (fipsState == "nonzeroized" && vmStatus == -1 && cavServerStatus == 1) {
              partitionObj['statusColor'] = "red";
            } else if (fipsState == "nonzeroized" && vmStatus == -1 && cavServerStatus == -1) {
              partitionObj['statusColor'] = "red";
            } else if (fipsState == "zeroized" && vmStatus == -1 && cavServerStatus == 0) {
              partitionObj['statusColor'] = "red";
            } else if (fipsState == "zeroized" && vmStatus == -1 && cavServerStatus == 1) {
              partitionObj['statusColor'] = "red";
            } else if (fipsState == "zeroized" && vmStatus == -1 && cavServerStatus == -1) {
              partitionObj['statusColor'] = "red";
            } else if (fipsState == "Inactive") {
              partitionObj['partitionStatus'] = partitionObj.partitionName+" is not reachable";
              partitionObj['statusColor'] = "maroon";
            }
          }
          if (partitionObj['lastOperationStatus'] === 'In-Progress') {
            partitionObj['InProgress'] = true;
            partitionObj['statusColor'] = "grey";
          } else if (partitionObj['lastOperationStatus'] === 'In-Progress'
            && partitionObj['grayedOut'] == true) {
            partitionObj['InProgress'] = true;
            partitionObj['statusColor'] = "grey";
          } else if (partitionObj['lastOperationStatus'] != 'In-Progress'
            && partitionObj['grayedOut'] == true) {
            partitionObj['InProgress'] = false;
            partitionObj['statusColor'] = "grey";
          } else {
            partitionObj['InProgress'] = false;
          }
          //count = count + 1;
          // checking for selected partition 
          for (var i = 0; i < this.selectedPartitionList.length; i++) {
            if (this.selectedPartitionList[i].partitionId == partitionObj.partitionId) {
              partitionObj['checked'] = true;
            }
          }
          partitionObj['partName'] = partitionObj.applianceName + ":" + partitionObj.partitionName;
           if(partitionData!=null){
            partitionObj['keys'] = partitionData.maxKeys;
          }
          this.partitionList.push(partitionObj)
        });
        // if selected any filters 
        if (this.filterLabel != '' && this.subFilterLabel != '') {
          let subFilterValue = this.subFilterLabel;
          this.getSubFilterList(this.filterLabel)
          this.getFilterDetails(subFilterValue);
        }
        // set timer for every 10 sec to refresh the page
        if (value != "callback") {
          this.getTimeIntervalData();
        }
        // 
        this.itemResource = new DataTableResource(this.partitionList);
        this.itemCount = this.partitionList.length;
        this.reloadItems({ "sortBy": this.selectedHeader, "sortAsc": !this.sortAsc });
      },
      error => {
        this.loading = false;
        console.log(error);
      },
    );
  }

  reloadItems(params) {
    if (this.itemResource) {
      this.itemResource.query(params).then(items => this.partitionList = items);
    }
  }

  headerClick1(params) {
    this.selectedHeader = '';
    this.selectedHeader = params.column.property;
    if (this.selectedHeader == "partName") {
      this.sortAsc = !this.sortName;
      this.sortName = !this.sortName;
    }
    if (this.selectedHeader == "tempFipsStatus") {
      this.sortAsc = !this.sortFipstatus;
      this.sortFipstatus = !this.sortFipstatus;
    }
    if (this.selectedHeader == "tempTotalSslCtxs") {
      this.sortAsc = !this.sortSSLContext;
      this.sortSSLContext = !this.sortSSLContext;
    }
    if (this.selectedHeader == "keys") {
      this.sortAsc = !this.sortKeys;
      this.sortKeys = !this.sortKeys;
    }
    this.reloadItems({ "sortBy": this.selectedHeader, "sortAsc": !this.sortAsc });
  }

  private getTimeIntervalData(): void {
    this.timer = Observable.timer(this.reloadTimer).first().subscribe(() => this.getPartitionList(""));
  }

  toggle() {
    this.showList = true;
  }
  toggle1() {
    this.showList = false;
  }

  selectPartitionItems(event, partitionId: string) {
    if (event.target.checked) {
      event.currentTarget.style.visibility = "visible";
      for (var i = 0; i < this.partitionList.length; i++) {
        if (this.partitionList[i].partitionId == partitionId) {
          this.partitionList[i]['checked'] = true;
          this.selectedPartitionList.push(this.partitionList[i]);
        }
      }

    } else {
      for (var i = 0; i < this.partitionList.length; i++) {
        if (this.partitionList[i].partitionId == partitionId) {
          this.partitionList[i]['checked'] = false;
        }
      }

      const index = this.selectedPartitionList.findIndex(
        partition => partition.partitionId === partitionId);
      this.selectedPartitionList.splice(index, 1);
    }
    if ((this.selectedPartitionList.length == null) || (this.selectedPartitionList.length == 0)) {
      $(".floatactionbtn").css("opacity", "0.3");
      $(".floatactionbtn").css("cursor", "not-allowed");
    } else {
      $(".floatactionbtn").css("opacity", "1");
      $(".floatactionbtn").css("cursor", "pointer");
    }
  }

  getPartitionToolTipData(partitionId) {
    this.toolTipData = "";
    this.KekStatus="";
    this.partitionList.find
      (partition => {
        if (partition.partitionId == partitionId) {
          if (partition != null) {
            this.toolTipData = partition.partitionData;
            if (this.toolTipData != null) {
              if (partition.lastOperationPerformed != null) {
                this.toolTipData['lastPerformedOperation'] = partition.lastOperationPerformed;
              } else {
                this.toolTipData['lastPerformedOperation'] = '';
              }
              if (partition.errorMessage != null) {
                this.toolTipData['errorMsg'] = partition.errorMessage;
              } else {
                this.toolTipData['errorMsg'] = '';
              }
              if (partition.lastOperationStatus != null) {
                this.toolTipData['lastOperationStatus'] = partition.lastOperationStatus;
              } else {
                this.toolTipData['lastOperationStatus'] = '';
              }
              if (this.toolTipData['kekMethod'] == 0) {
                this.KekStatus = "ECC";
              }
              else if (this.toolTipData['kekMethod'] == 1) {
                this.KekStatus = "RSA";
              }
             



            }
          }
        }
      })
  }


  callBackToPartitionList() {
    console.log("Callback ----> List of Partitions");
    this.selectedPartitionList = [];
    this.getPartitionList("callback");
  }

  ngOnDestroy() {
    if (this.timer) {
      this.timer.unsubscribe();
    }
    if (this.partitionListSubscription) {
      this.partitionListSubscription.unsubscribe();
    }
  }

  subFilterOptions: any = [];
  filterLabel: string = '';
  getSubFilterList(value) {
    this.filterLabel = '';
    this.subFilterLabel = '';
    this.subFilterOptions = [];
    if (value != "") {
      this.filterLabel = value;
      this.subFilterOptions = this.getSubFilterOptions().filter((item) => {
        return item.level_id === Number(value)
      });
    } else {
      this.partitionList = this.finalPartitionList;
      this.itemResource = new DataTableResource(this.partitionList);
      this.itemCount = this.partitionList.length;
    }

  }

  getSubFilterOptions() {
    return [
      { id: 1, level_id: 1, name: 'Active' },
      { id: 0, level_id: 1, name: 'In-Active' },
      { id: 1, level_id: 2, name: 'Active' },
      { id: 0, level_id: 2, name: 'In-Active' },
      { id: 1, level_id: 4, name: 'In' },
      { id: 0, level_id: 4, name: 'None' }
    ];
  }
  subFilterLabel: string = '';
  getFilterDetails(value) {
    this.subFilterLabel = '';
    this.partitionList = [];
    // this.templist = [];
    if (value != "") {
      this.subFilterLabel = value;
      if (this.filterLabel === "1") { // cav-server status
        this.partitionList = this.finalPartitionList.filter((item) => {
          if (item.partitionData != null) {
            return item.partitionData.cavServerStatus === Number(value)
          } else {
            return false;
          }
        });

      } else if (this.filterLabel === "2") { // vm status
        this.partitionList = this.finalPartitionList.filter((item) => {
          if (item.partitionData != null) {
            return item.partitionData.vmStatus === Number(value)
          } else {
            return false;
          }
        });
      } else if (this.filterLabel === "4") { // cluster partitions
        let isPartOfCluster: boolean = false;
        if (value === "1") {
          isPartOfCluster = true;
        } else if (value === "0") {
          isPartOfCluster = false;
        }
        this.partitionList = this.finalPartitionList.filter((item) => {
          return item.partOfCluster === isPartOfCluster;
        });

      }
    } else {
      this.partitionList = this.finalPartitionList;
    }
    this.itemResource = new DataTableResource(this.partitionList);
    this.itemCount = this.partitionList.length;
  }

  showSelfTestReport() {
    this.PartitionSelftestreportComponent.showSelfTestReportModal();
  }

}
