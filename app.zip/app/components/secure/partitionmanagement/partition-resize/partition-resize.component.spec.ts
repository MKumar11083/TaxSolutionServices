import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PartitionResizeComponent } from './partition-resize.component';

describe('PartitionResizeComponent', () => {
  let component: PartitionResizeComponent;
  let fixture: ComponentFixture<PartitionResizeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PartitionResizeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PartitionResizeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
