import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PartitionOperationsComponent } from './partition-operations.component';

describe('PartitionOperationsComponent', () => {
  let component: PartitionOperationsComponent;
  let fixture: ComponentFixture<PartitionOperationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PartitionOperationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PartitionOperationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
