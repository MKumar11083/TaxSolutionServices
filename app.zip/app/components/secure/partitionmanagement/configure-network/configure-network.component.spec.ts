import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigureNetworkComponent } from './configure-network.component';

describe('ConfigureNetworkComponent', () => {
  let component: ConfigureNetworkComponent;
  let fixture: ComponentFixture<ConfigureNetworkComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigureNetworkComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigureNetworkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
