import { Component, OnInit, ViewChild, Output, EventEmitter, TemplateRef, ChangeDetectionStrategy } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, FormControl, FormArray } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { TabDirective } from 'ngx-bootstrap/tabs';
import { TabsetComponent } from 'ngx-bootstrap';
import { Router } from '@angular/router';
import { PartitionOperationsComponent } from './../partition-operations/partition-operations.component';
import { PartitionManagementService } from './../../../../services/partitionmanagement/partitionmanagement.service';
import { CommonValidator } from '../../../../validators/common-validator';
declare var $: any;
declare var bootbox: any;
declare var jQuery: any;
@Component({
  selector: 'app-configure-network',
  templateUrl: './configure-network.component.html',
  styleUrls: ['./configure-network.component.css']

})
export class ConfigureNetworkComponent implements OnInit {
  @ViewChild('configureNetworkModal') configureNetworkModal: ModalDirective;
  @ViewChild('staticTabs') staticTabs: TabsetComponent;
  @ViewChild('displayMsgModal') displayMsgModal: ModalDirective;
  @ViewChild('partitionOperationsComponent')
  private partitionOperationsComponent: PartitionOperationsComponent;
  @Output() messageEvent1 = new EventEmitter<any>();
  form: FormGroup;
  addAdvanced: FormGroup;
  tab: string;
  staticHostIp = [];
  dnsServers = [];
  domainNames = [];
  tempStaticHostIp: any = [];
  oldStaticHostIp: any = [];
  displayError: string;
  displayError1: string;
  classStatic: string;
  classServer: string;
  classDomain: string;
  partitionCount: number = 1;
  totalPartitionCount: number = 0;
  selectedPartitionList = [];
  partitionName: string;
  applianceName: string;
  showEth0: boolean = true;
  showEth1: boolean = true;
  finalPartitionList = [];
  isDNSserverChecked: boolean = false;
  showBackButton = false;
  tabName: string = "";
  showFinalPartitionList: boolean = false;
  errorMessage: string = '';
  networkData: any;
  loading: boolean = false;
  removeIpsArray: any = [];
  constructor(private _fieldErrorDisplayService: FieldErrorDisplayService,
    private router: Router,
    private builder: FormBuilder,
    private _service: PartitionManagementService
  ) {
  }
  ngOnInit() {
    this.createForm();
    this.initItemRows(null, null, null);
    this.tab = "1";
  }
  createForm() {
    this.form = this.builder.group({
      partitionId: [''],
      partitionName: [''],
      csr: [null],
      keys: [],
      sslContexts: [],
      acclrDev: [],
      wrap: ['', Validators.required],
      backup: ['', Validators.required],
      sessionClose: [''],
      applianceDetailModel: this.builder.group({
        applianceId: [null],
        applianceName: [null],
        applianceStatus: [null],
        serialNumber: [null],
        networkTimezone: [null],
        gatewayIp: [null],
        ipAddress: [null],
        networkId: [null],
        subnetMask: [null],
      }),
      networkStats: this.builder.group({
        general: this.builder.group({
          partitionName: ['', Validators.required],
          dnsService: [false],
          selectInterface: [''],
          eth0: this.builder.group({
            ethName: ['eth0'],
            dhcp: [true],
            ip: [null],
            gateway: [null],
            subnet: [null],
            hostname: [null, Validators.compose([CommonValidator.hostNameValidator])],
            staticMac: [true],
            address: [null],
            vlan: [0, Validators.compose([Validators.min(0), Validators.max(4094)])],
          }),
          eth1: this.builder.group({
            ethName: ['eth1'],
            dhcp: [true],
            disableEth1: [true],
            ip: [null],
            gateway: [null],
            subnet: [null],
            staticMac: [true],
            address: [null],
            vlan: [0, Validators.compose([Validators.min(0), Validators.max(4094)])],
            id: [null],
          })
        }),
        advanced: this.builder.group({
          staticIpToHostConfig: this.builder.group({
            add: new FormArray([]),

          }),
          dnsConfig: this.builder.group({
            dnsServers: new FormArray([]),
            searchDomainNames: new FormArray([]),
            enableService: [false]
          }),
          ip: ['null', CommonValidator.ipAddressValidator],
          hostname: ['null', CommonValidator.hostNameValidator1],
          alias: [''],
          id: [''],
          dnsServer: [null, CommonValidator.ipAddressValidator],
          searchDomainName: [null, CommonValidator.validateDomainName]
        })
      }),
      partitionCertificate: [null],
      errorMessage: [null],
      username: [null],
      password: [null]
    });
  }

  initItemRows(ip, hostname, alias) {
    return this.addAdvanced = this.builder.group({
      ip: ip,
      hostname: hostname,
      alias: alias,
      id: [null]
    });

  }

  selectTab(tab_id: string) {
    if (tab_id == "1") {
      this.classStatic = "btn-primary";
      this.classServer = "btn-default";
      this.classDomain = "btn-default";
    } else if (tab_id == "2") {
      this.classStatic = "btn-default";
      this.classServer = "btn-primary";
      this.classDomain = "btn-default";
    } else if (tab_id == "3") {
      this.classStatic = "btn-default";
      this.classServer = "btn-default";
      this.classDomain = "btn-primary";
    }
    this.tab = tab_id;
    this.displayError = "";
  }

  showConfigureNetworkModal(partitionList) {

    this.clearData();
    this.tab = "1";
    this.classStatic = "btn-primary";
    this.classServer = "btn-default";
    this.classDomain = "btn-default";
    this.selectedPartitionList = partitionList;
    this.totalPartitionCount = this.selectedPartitionList.length;
    this.isDNSserverChecked = true;
    this.errorMessage = '';
    this.form.get('networkStats.general.selectInterface').patchValue('all');
    // take the first record from the partitionlist to preload the data in modal.
    let count = this.partitionCount - 1;
    let partitionData = this.selectedPartitionList[count];
    // get Network stats details
    this.loading = true;
    this._service.getPartitionNetworkStats(partitionData.partitionId).subscribe(
      response => {
        this.loading = false;
        this.networkData = null;
        if (response.code == "200") {
          this.networkData = JSON.parse(response.message);
          this.setPartitionDataToForm(partitionData, this.networkData);
          this.partitionName = partitionData['partitionName'];
          this.applianceName = partitionData.applianceDetailModel.applianceName;
          this.configureNetworkModal.show();
        } else {
          this.errorMessage = response.errorMessage;
          this.displayMsgModal.show();
        }
      },
      error => {
        this.loading = false;
        console.log(error);
      }
    )
  }

  nextConfigureNetwork(isValid) {
    if (isValid) {
      $("#network").fadeOut(20);
      if (typeof this.finalPartitionList[this.partitionCount - 1] === 'undefined') {
        this.finalPartitionList.push(this.pushConfigNetworkDetails(this.form.value));
      } else {
        this.finalPartitionList[this.partitionCount - 1] = this.pushConfigNetworkDetails(this.form.value);
      }
      if (this.partitionCount < this.selectedPartitionList.length) {
        this.isDNSserverChecked = true;
        this.form.reset();
        //this.partitionName = this.selectedPartitionList[this.partitionCount]['partitionName'];
        let partitionData = this.selectedPartitionList[this.partitionCount];
        // get Network stats details
        let existingPartition = this.finalPartitionList.find(
          t => t.partitionId == partitionData.partitionId);
        if (existingPartition == null) {
          this._service.getPartitionNetworkStats(partitionData.partitionId).subscribe(
            response => {
              this.setPartitionDataToForm(partitionData, JSON.parse(response.message));
              this.partitionName = partitionData['partitionName'];
              this.applianceName = partitionData.applianceDetailModel.applianceName;
              this.partitionCount = this.partitionCount + 1;
              //this.isDNSserverChecked = false;
              this.showBackButton = true;
            },
            error => {
              console.log(error);
            }
          )
        } else {
          this.setPartitionDataToFormForBackOperation(existingPartition);
          this.partitionName = partitionData['partitionName'];
          this.partitionCount = this.partitionCount + 1;
          //this.isDNSserverChecked = false;
          this.showBackButton = true;
        }

      } else {
        this.form.reset();
        this.displayError = '';
        this.submitConfigurationNetworkDetails();
      }
      $("#network").fadeIn("slow");


    } else {
      // Check errors 
      const eth0IpControl = this.form.get('networkStats.general.eth0.ip');
      if (eth0IpControl.errors != null) {
        if (eth0IpControl.hasError('required')) {
          eth0IpControl.markAsTouched({ onlySelf: true });
        }
      }
      const eth0AddressControl = this.form.get('networkStats.general.eth0.address');
      if (eth0AddressControl.errors != null) {
        if (eth0AddressControl.hasError('required')) {
          eth0AddressControl.markAsTouched({ onlySelf: true });
        }
      }

      const eth1IpControl = this.form.get('networkStats.general.eth1.ip');
      if (eth1IpControl.errors != null) {
        if (eth1IpControl.hasError('required')) {
          eth1IpControl.markAsTouched({ onlySelf: true });
        }
      }

      const eth1AddressControl = this.form.get('networkStats.general.eth1.address');
      if (eth1AddressControl.errors != null) {
        if (eth1AddressControl.hasError('required')) {
          eth1AddressControl.markAsTouched({ onlySelf: true });
        }
      }
    }

  }
  pushConfigNetworkDetails(obj) {
    let networkObj = {
      'general': {
        'selectInterface': '',
        'eth0': { "ethName": "eth0", },
        'eth1': { "ethName": "eth1", }
      },
      'advanced': {

      }
    }
    let networkStatsData = obj.networkStats;
    networkObj.general.selectInterface = networkStatsData.general.selectInterface;
    // eth0
    networkObj.general.eth0['dhcp'] = networkStatsData.general.eth0.dhcp;
    networkObj.general.eth0['staticMac'] = networkStatsData.general.eth0.staticMac;
    if (networkStatsData.general.eth0.hostname != null) {
      networkObj.general.eth0['hostname'] = networkStatsData.general.eth0.hostname;
    } else {
      networkObj.general.eth0['hostname'] = "";
    }
    if (networkStatsData.general.eth0.vlan != null && networkStatsData.general.eth0.vlan != '') {
      networkObj.general.eth0['vlan'] = networkStatsData.general.eth0.vlan;
    } else {
      networkObj.general.eth0['vlan'] = 0;
    }

    // eth1
    if(this.form.get('networkStats.general.eth1.dhcp').value == undefined){
      networkObj.general.eth1['dhcp'] = false;
    }else{
      networkObj.general.eth1['dhcp'] = this.form.get('networkStats.general.eth1.dhcp').value;
    }
    if(this.form.get('networkStats.general.eth1.staticMac').value ==  undefined){
      networkObj.general.eth1['staticMac'] = false;
    }else{
      networkObj.general.eth1['staticMac'] = this.form.get('networkStats.general.eth1.staticMac').value ;
    }
    if (networkStatsData.general.eth1.vlan != null && networkStatsData.general.eth1.vlan != '') {
      networkObj.general.eth1['vlan'] = networkStatsData.general.eth1.vlan;
    } else {
      networkObj.general.eth1['vlan'] = 0;
    }
    if (!networkStatsData.general.eth0.dhcp) {
      networkObj.general.eth0['ip'] = networkStatsData.general.eth0.ip;
      networkObj.general.eth0['gateway'] = networkStatsData.general.eth0.gateway;
      networkObj.general.eth0['subnet'] = networkStatsData.general.eth0.subnet;
    }
    // this.form.get('networkStats.general.eth1.dhcp').reset();
    if (!networkStatsData.general.eth1.dhcp) {
      networkObj.general.eth1['ip'] = this.form.get('networkStats.general.eth1.ip').value;
      networkObj.general.eth1['subnet'] = this.form.get('networkStats.general.eth1.subnet').value;

    }
    if (networkStatsData.general.eth0.staticMac) {
      networkObj.general.eth0['address'] = networkStatsData.general.eth0.address;
    }
    if (networkStatsData.general.eth1.staticMac) {
      networkObj.general.eth1['address'] = networkStatsData.general.eth1.address;
    } else {
      networkObj.general.eth1['address'] = this.form.get('networkStats.general.eth1.address').value;
    }
    if (networkStatsData.general.eth1.disableEth1) {
      networkObj.general.eth1['disableEth1'] = false;
    } else {
      networkObj.general.eth1['disableEth1'] = true;
    }

    let advanced = {
      'dnsConfig': {
        'enableService': false
      }
    };
    if (this.tempStaticHostIp.length > 0) {
      advanced['staticIpToHostConfig'] = {};
      advanced['staticIpToHostConfig']['add'] = this.tempStaticHostIp;
    }
    if (this.removeIpsArray.length > 0) {
      if (advanced['staticIpToHostConfig'] != null && advanced['staticIpToHostConfig'] != '') {
        advanced['staticIpToHostConfig']['remove'] = this.removeIpsArray;
      } else {
        advanced['staticIpToHostConfig'] = {};
        advanced['staticIpToHostConfig']['remove'] = this.removeIpsArray;
      }
    }
    advanced['dnsConfig']['dnsServers'] = this.dnsServers;
    advanced['dnsConfig']['searchDomainNames'] = this.domainNames;
    advanced['dnsConfig']['enableService'] = this.form.get('networkStats').get('advanced').
      get('dnsConfig').get('enableService').value;
    networkObj['advanced'] = advanced;
    obj['networkStats'] = networkObj;
    return obj;
  }
  // resetFieldsBasedOnValidation() {
  //   if (this.form.get('networkStats.general.eth0.dhcp').value) {
  //     this.form.get('networkStats.general.eth0.ip').reset();
  //     this.form.get('networkStats.general.eth0.gateway').reset();
  //     this.form.get('networkStats.general.eth0.subnet').reset();
  //   }
  //   if (this.form.get('networkStats.general.eth1.dhcp').value) {
  //     this.form.get('networkStats.general.eth1.ip').reset();
  //     this.form.get('networkStats.general.eth1.subnet').reset();
  //   }
  //   if (this.form.get('networkStats.general.eth0.staticMac').value == false) {
  //     this.form.get('networkStats.general.eth0.address').reset();
  //   }
  //   if (this.form.get('networkStats.general.eth1.staticMac').value == false) {
  //     this.form.get('networkStats.general.eth1.address').reset();
  //   }
  //   if (!this.form.get('networkStats.general.eth1.disableEth1').value) {
  //     this.form.get('networkStats.general.eth1.dhcp').reset();
  //     this.form.get('networkStats.general.eth1.ip').reset();
  //     this.form.get('networkStats.general.eth1.subnet').reset();
  //     this.form.get('networkStats.general.eth1.staticMac').reset();
  //     this.form.get('networkStats.general.eth1.address').reset();
  //     this.form.get('networkStats.general.eth1.disableEth1').setValue(true);
  //   } else {
  //     this.form.get('networkStats.general.eth1.disableEth1').setValue(false);
  //   }

  // }


  setPartitionDataToForm(partitionData, networkData) {
    this.form.get('networkStats.general.eth0.dhcp').enable();
    this.form.get('networkStats.general.eth1.dhcp').enable();
    this.form.get('networkStats.general.eth0.staticMac').enable();
    this.form.get('networkStats.general.eth1.staticMac').enable();
    this.form.get('username').patchValue(partitionData.username);
    this.form.get('password').patchValue(partitionData.password);
    this.form.get('partitionId').patchValue(partitionData.partitionId);
    this.form.get('networkStats.general.partitionName').patchValue(partitionData.partitionName);
    this.form.get('partitionName').patchValue(partitionData.partitionName);
    this.form.get('csr').patchValue(partitionData.csr);
    this.form.get('keys').patchValue(partitionData.keys);
    this.form.get('sslContexts').patchValue(partitionData.sslContexts);
    this.form.get('acclrDev').patchValue(partitionData.acclrDev);
    this.form.get('wrap').patchValue(partitionData.wrap);
    this.form.get('backup').patchValue(partitionData.backup);
    this.form.get('sessionClose').patchValue(partitionData.sessionClose);
    this.form.get('applianceDetailModel.applianceId').patchValue(partitionData.applianceDetailModel.applianceId);
    this.form.get('applianceDetailModel.applianceName').patchValue(partitionData.applianceDetailModel.applianceName);
    this.form.get('applianceDetailModel.ipAddress').patchValue(partitionData.applianceDetailModel.ipAddress);
    this.form.get('networkStats.general.selectInterface').patchValue('all');
    const control = <FormControl>this.form.get('networkStats').get('advanced').
      get('dnsConfig').get('enableService');
    control.setValue(false);
    // setting network details 
    if (networkData != null) {
      if (networkData.general != null) {
        this.form.get('networkStats.general.eth0.ethName').patchValue('eth0');
        this.form.get('networkStats.general.eth1.ethName').patchValue('eth1');
        if (networkData.general.eth0 != null) {
          //if (networkData.general.eth0.dhcp != null) {
          if (networkData.general.eth0.dhcp) {
            this.form.get('networkStats.general.eth0.ip').disable();
            this.form.get('networkStats.general.eth0.gateway').disable();
            this.form.get('networkStats.general.eth0.subnet').disable();
            this.form.get('networkStats.general.eth0.ip').clearValidators();
            this.form.get('networkStats.general.eth0.gateway').clearValidators();
            this.form.get('networkStats.general.eth0.subnet').clearValidators();
          } else {
            this.form.get('networkStats.general.eth0.ip').enable();
            this.form.get('networkStats.general.eth0.gateway').enable();
            this.form.get('networkStats.general.eth0.subnet').enable();
            this.form.get('networkStats.general.eth0.ip').setValidators([Validators.required, CommonValidator.ipAddressValidator1]);
            this.form.get('networkStats.general.eth0.gateway').setValidators(CommonValidator.ipAddressValidator);
            this.form.get('networkStats.general.eth0.subnet').setValidators(CommonValidator.ipAddressValidator);
          }
          this.form.get('networkStats.general.eth0.ip').updateValueAndValidity();
          this.form.get('networkStats.general.eth0.gateway').updateValueAndValidity();
          this.form.get('networkStats.general.eth0.subnet').updateValueAndValidity();
          this.form.get('networkStats.general.eth0.dhcp').patchValue(networkData.general.eth0.dhcp);
          //}

          if (networkData.general.eth0.ip != null) {
            this.form.get('networkStats.general.eth0.ip').patchValue(networkData.general.eth0.ip);
          }
          if (networkData.general.eth0.gateway != null) {
            this.form.get('networkStats.general.eth0.gateway').patchValue(networkData.general.eth0.gateway);
          }
          if (networkData.general.eth0.subnet != null) {
            this.form.get('networkStats.general.eth0.subnet').patchValue(networkData.general.eth0.subnet);
          }
          if (networkData.general.eth0.hostname != null) {
            this.form.get('networkStats.general.eth0.hostname').patchValue(networkData.general.eth0.hostname);
          }
          if (networkData.general.eth0.macStatic != null) {
            if (networkData.general.eth0.macStatic) {
              this.form.get('networkStats.general.eth0.staticMac').patchValue(networkData.general.eth0.macStatic);
              this.form.get('networkStats.general.eth0.address').enable();
              this.form.get('networkStats.general.eth0.address').setValidators([CommonValidator.macAddressValidator]);
              this.form.get('networkStats.general.eth0.address').updateValueAndValidity();
            } else {
              this.form.get('networkStats.general.eth0.staticMac').patchValue(networkData.general.eth0.macStatic);
              this.form.get('networkStats.general.eth0.address').disable();
              this.form.get('networkStats.general.eth0.address').clearValidators();
              this.form.get('networkStats.general.eth0.address').updateValueAndValidity();
            }
          } else {
            this.form.get('networkStats.general.eth0.address').clearValidators();
            this.form.get('networkStats.general.eth0.address').updateValueAndValidity();
          }
          if (networkData.general.eth0.mac != null) {
            this.form.get('networkStats.general.eth0.address').patchValue(networkData.general.eth0.mac);
          }
          this.form.get('networkStats.general.eth0.vlan').patchValue(networkData.general.eth0.vlan);
        }
        this.form.get('networkStats.general.eth1.disableEth1').setValue(true);
        if (networkData.general.eth1 != null) {
          if (networkData.general.eth1.dhcp) {
            this.form.get('networkStats.general.eth1.ip').disable();
            this.form.get('networkStats.general.eth1.subnet').disable();
            this.form.get('networkStats.general.eth1.ip').clearValidators();
            this.form.get('networkStats.general.eth1.subnet').clearValidators();
            this.form.get('networkStats.general.eth1.ip').updateValueAndValidity();
            this.form.get('networkStats.general.eth1.subnet').updateValueAndValidity();
            this.form.get('networkStats.general.eth1.dhcp').patchValue(networkData.general.eth1.dhcp);
          } else {
            this.form.get('networkStats.general.eth1.ip').enable();
            this.form.get('networkStats.general.eth1.subnet').enable();
            this.form.get('networkStats.general.eth1.ip').setValidators([Validators.required, CommonValidator.ipAddressValidator1]);
            this.form.get('networkStats.general.eth1.subnet').setValidators(CommonValidator.ipAddressValidator);
            this.form.get('networkStats.general.eth1.ip').updateValueAndValidity();
            this.form.get('networkStats.general.eth1.subnet').updateValueAndValidity();
            this.form.get('networkStats.general.eth1.dhcp').patchValue(networkData.general.eth1.dhcp);
          }

          if (networkData.general.eth1.ip != null && networkData.general.eth1.ip != '') {
            if (networkData.general.eth1.ip == "127.0.0.1") {
              this.form.get('networkStats.general.eth1.ip').patchValue(networkData.general.eth1.ip);
              this.form.get('networkStats.general.eth1.disableEth1').setValue(false);
              this.form.get('networkStats.general.eth1.dhcp').setValue(false);
              this.form.get('networkStats.general.eth1.dhcp').disable();
              this.form.get('networkStats.general.eth1.staticMac').disable();
              this.form.get('networkStats.general.eth1.address').disable();
              this.form.get('networkStats.general.eth1.vlan').disable();
              this.form.get('networkStats.general.eth1.ip').disable();
              this.form.get('networkStats.general.eth1.subnet').disable();
            } else {
              this.form.get('networkStats.general.eth1.ip').patchValue(networkData.general.eth1.ip);
            }
          } else {
            this.form.get('networkStats.general.eth1.dhcp').setValue(true);
            this.form.get('networkStats.general.eth1.ip').disable();
            this.form.get('networkStats.general.eth1.subnet').disable();
          }
          if (networkData.general.eth1.subnet != null) {
            this.form.get('networkStats.general.eth1.subnet').patchValue(networkData.general.eth1.subnet);
          }
          if (networkData.general.eth1.macStatic != null && networkData.general.eth1.macStatic != null) {
            if (networkData.general.eth1.macStatic) {
              this.form.get('networkStats.general.eth1.staticMac').patchValue(networkData.general.eth1.macStatic);
              this.form.get('networkStats.general.eth1.address').enable();
              this.form.get('networkStats.general.eth1.address').setValidators([CommonValidator.macAddressValidator]);
              this.form.get('networkStats.general.eth1.address').updateValueAndValidity();
            } else {
              this.form.get('networkStats.general.eth1.staticMac').patchValue(networkData.general.eth1.macStatic);
              this.form.get('networkStats.general.eth1.address').disable();
              this.form.get('networkStats.general.eth1.address').clearValidators();
              this.form.get('networkStats.general.eth1.address').updateValueAndValidity();
            }
          }
          if (networkData.general.eth1.mac != null && networkData.general.eth1.mac != '') {
            this.form.get('networkStats.general.eth1.address').setValue(networkData.general.eth1.mac);
          }
          this.form.get('networkStats.general.eth1.vlan').patchValue(networkData.general.eth1.vlan);
        }
      }
      const control = <FormArray>this.form.get('networkStats').get('advanced').get('staticIpToHostConfig').get('add');
      const control1 = <FormArray>this.form.get('networkStats').get('advanced').
        get('dnsConfig').get('dnsServers');
      const control2 = <FormArray>this.form.get('networkStats').get('advanced').
        get('dnsConfig').get('searchDomainNames');
      control.controls = [];
      control1.controls = [];
      control2.controls = [];
      this.staticHostIp = [];
      this.dnsServers = [];
      this.domainNames = [];
      this.tempStaticHostIp = [];
      this.removeIpsArray = [];
      this.oldStaticHostIp = [];
      if (networkData.advanced != null) {
        if (networkData.advanced.staticIpToHostConfig.length > 0) {
          if (networkData.advanced.staticIpToHostConfig != null) {
            let staticIpHost = networkData.advanced.staticIpToHostConfig;

            staticIpHost.forEach(staticIpObj => {
              let ip = staticIpObj.ip;
              let hostname = staticIpObj.hostname;
              let alias = staticIpObj.alias;
              const control = <FormArray>this.form.get('networkStats').get('advanced').get('staticIpToHostConfig').get('add');
              let staticHostIpData = {};
              staticHostIpData['ip'] = ip;
              staticHostIpData['hostname'] = hostname;
              staticHostIpData['alias'] = alias;
              control.push(this.initItemRows(ip, hostname, alias));
              this.staticHostIp.push(staticHostIpData);
            });
          }
        }

        if (networkData.advanced.dnsServers != null && networkData.advanced.dnsServers.length > 0) {
          this.form.get('networkStats.general.dnsService').setValue(true);
          this.isDNSserverChecked = false;
          const control = <FormControl>this.form.get('networkStats').get('advanced').
            get('dnsConfig').get('enableService');
          control.setValue(true);

          let tempDnsServers = networkData.advanced.dnsServers;
          tempDnsServers.forEach(dnsServer => {
            if (dnsServer != null && dnsServer != '') {
              this.dnsServers.push(dnsServer);
              const control1 = <FormArray>this.form.get('networkStats').get('advanced').
                get('dnsConfig').get('dnsServers');
              control1.push(new FormControl(dnsServer));
            }
          });

        }
        if (networkData.advanced.searchDomainNames != null
          && networkData.advanced.searchDomainNames.length > 0) {
          this.form.get('networkStats.general.dnsService').setValue(true);
          this.isDNSserverChecked = false;
          const control = <FormControl>this.form.get('networkStats').get('advanced').
            get('dnsConfig').get('enableService');
          control.setValue(true);
          let tempDomainNames = networkData.advanced.searchDomainNames;
          tempDomainNames.forEach(domainName => {
            if (domainName != null && domainName != '') {
              this.domainNames.push(domainName);
              const control2 = <FormArray>this.form.get('networkStats').get('advanced').
                get('dnsConfig').get('searchDomainNames');
              control2.push(new FormControl(domainName));
            }

          });
        }

      }
    }
  }

  // back Operation fetchs previous appliance data.
  backToPreviousPartition() {
    $("#network").fadeOut(20);
    this.form.reset();
    this.displayError = '';
    this.displayError1 = '';
    this.partitionName = this.selectedPartitionList[this.partitionCount - 2]['partitionName'];
    let backOperationCount = this.partitionCount - 2;
    let partitionData = this.finalPartitionList[backOperationCount];
    this.applianceName = partitionData.applianceDetailModel.applianceName;
    this.setPartitionDataToFormForBackOperation(partitionData);
    this.partitionCount = this.partitionCount - 1;

    if (this.partitionCount == 1) {
      this.showBackButton = false;
    }
    this.staticTabs.tabs[0].active = true;
    this.tabName = "General";
    $("#network").fadeIn("slow");
  }
  // Back Operation in Final list of appliance.
  backOperationFromFinalList() {
    $("#network").fadeOut(20);
    this.form.reset();
    this.displayError = '';
    this.displayError1 = '';
    this.partitionName = this.finalPartitionList[this.partitionCount - 1]['partitionName'];
    let partitionData = this.finalPartitionList[this.partitionCount - 1];
    this.applianceName = partitionData.applianceDetailModel.applianceName;
    this.setPartitionDataToFormForBackOperation(partitionData);
    if (this.partitionCount == 1) {
      this.showBackButton = false;
    } else {
      //this.applianceCount = this.applianceCount - 1;
      this.showBackButton = true;
    }
    this.showFinalPartitionList = false;
    this.tabName = "General";
    $("#network").fadeIn("slow");
  }
  // set data for back operation
  setPartitionDataToFormForBackOperation(partitionData) {
    this.form.get('networkStats.general.eth0.dhcp').enable();
    this.form.get('networkStats.general.eth1.dhcp').enable();
    this.form.get('networkStats.general.eth0.staticMac').enable();
    this.form.get('networkStats.general.eth1.staticMac').enable();
    this.form.get('username').patchValue(partitionData.username);
    this.form.get('password').patchValue(partitionData.password);
    this.form.get('partitionId').patchValue(partitionData.partitionId);
    this.form.get('networkStats.general.partitionName').patchValue(partitionData.partitionName);
    this.form.get('partitionName').patchValue(partitionData.partitionName);
    this.form.get('csr').patchValue(partitionData.csr);
    this.form.get('keys').patchValue(partitionData.keys);
    this.form.get('sslContexts').patchValue(partitionData.sslContexts);
    this.form.get('acclrDev').patchValue(partitionData.acclrDev);
    this.form.get('wrap').patchValue(partitionData.wrap);
    this.form.get('backup').patchValue(partitionData.backup);
    this.form.get('sessionClose').patchValue(partitionData.sessionClose);
    this.form.get('applianceDetailModel.applianceId').patchValue(partitionData.applianceDetailModel.applianceId);
    this.form.get('applianceDetailModel.applianceName').patchValue(partitionData.applianceDetailModel.applianceName);
    this.form.get('applianceDetailModel.ipAddress').patchValue(partitionData.applianceDetailModel.ipAddress);
    this.form.get('networkStats.general.selectInterface').patchValue(partitionData.networkStats.general.selectInterface);
    this.form.get('networkStats.general.dnsService').patchValue(partitionData.networkStats.advanced.dnsConfig.enableService);

    // setting network details 
    if (partitionData.networkStats != null) {
      if (partitionData.networkStats.general != null) {

        this.form.get('networkStats.general.eth0.ethName').patchValue('eth0');
        this.form.get('networkStats.general.eth1.ethName').patchValue('eth1');
        if (partitionData.networkStats.general.eth0 != null) {
          if (partitionData.networkStats.general.eth0.dhcp) {
            this.form.get('networkStats.general.eth0.ip').disable();
            this.form.get('networkStats.general.eth0.gateway').disable();
            this.form.get('networkStats.general.eth0.subnet').disable();
            this.form.get('networkStats.general.eth0.ip').clearValidators();
            this.form.get('networkStats.general.eth0.gateway').clearValidators();
            this.form.get('networkStats.general.eth0.subnet').clearValidators();
          } else {
            this.form.get('networkStats.general.eth0.ip').enable();
            this.form.get('networkStats.general.eth0.gateway').enable();
            this.form.get('networkStats.general.eth0.subnet').enable();
            this.form.get('networkStats.general.eth0.ip').setValidators([Validators.required, CommonValidator.ipAddressValidator1]);
            this.form.get('networkStats.general.eth0.gateway').setValidators(CommonValidator.ipAddressValidator);
            this.form.get('networkStats.general.eth0.subnet').setValidators(CommonValidator.ipAddressValidator);
          }
          this.form.get('networkStats.general.eth0.ip').updateValueAndValidity();
          this.form.get('networkStats.general.eth0.gateway').updateValueAndValidity();
          this.form.get('networkStats.general.eth0.subnet').updateValueAndValidity();
          this.form.get('networkStats.general.eth0.dhcp').patchValue(partitionData.networkStats.general.eth0.dhcp);
          if (partitionData.networkStats.general.eth0.ip != "null") {
            this.form.get('networkStats.general.eth0.ip').patchValue(partitionData.networkStats.general.eth0.ip);
          }
          if (partitionData.networkStats.general.eth0.gateway != "null") {
            this.form.get('networkStats.general.eth0.gateway').patchValue(partitionData.networkStats.general.eth0.gateway);
          }
          if (partitionData.networkStats.general.eth0.subnet != "null") {
            this.form.get('networkStats.general.eth0.subnet').patchValue(partitionData.networkStats.general.eth0.subnet);
          }
          if (partitionData.networkStats.general.eth0.hostname != "null") {
            this.form.get('networkStats.general.eth0.hostname').patchValue(partitionData.networkStats.general.eth0.hostname);
          }
          if (partitionData.networkStats.general.eth0.staticMac != null) {
            if (partitionData.networkStats.general.eth0.staticMac) {
              this.form.get('networkStats.general.eth0.staticMac').patchValue(partitionData.networkStats.general.eth0.staticMac);
              this.form.get('networkStats.general.eth0.address').enable();
              this.form.get('networkStats.general.eth0.address').setValidators([CommonValidator.macAddressValidator]);
              this.form.get('networkStats.general.eth0.address').updateValueAndValidity();
            } else {
              this.form.get('networkStats.general.eth0.staticMac').patchValue(partitionData.networkStats.general.eth0.staticMac);
              this.form.get('networkStats.general.eth0.address').disable();
              this.form.get('networkStats.general.eth0.address').clearValidators();
              this.form.get('networkStats.general.eth0.address').updateValueAndValidity();
            }
          } else {
            this.form.get('networkStats.general.eth0.address').clearValidators();
            this.form.get('networkStats.general.eth0.address').updateValueAndValidity();
          }
          if (partitionData.networkStats.general.eth0.address != null) {
            this.form.get('networkStats.general.eth0.address').patchValue(partitionData.networkStats.general.eth0.address);
          }
          this.form.get('networkStats.general.eth0.vlan').patchValue(partitionData.networkStats.general.eth0.vlan);
        }
        if (partitionData.networkStats.general.eth1.disableEth1) {
          this.form.get('networkStats.general.eth1.disableEth1').patchValue(false);
        } else {
          this.form.get('networkStats.general.eth1.disableEth1').patchValue(true);
        }

        if (partitionData.networkStats.general.eth1 != null) {
          if (partitionData.networkStats.general.eth1.dhcp) {
            this.form.get('networkStats.general.eth1.ip').disable();
            this.form.get('networkStats.general.eth1.subnet').disable();
            this.form.get('networkStats.general.eth1.ip').clearValidators();
            this.form.get('networkStats.general.eth1.subnet').clearValidators();
            this.form.get('networkStats.general.eth1.ip').updateValueAndValidity();
            this.form.get('networkStats.general.eth1.subnet').updateValueAndValidity();
          } else {
            this.form.get('networkStats.general.eth1.ip').enable();
            this.form.get('networkStats.general.eth1.subnet').enable();
            this.form.get('networkStats.general.eth1.ip').setValidators([Validators.required, CommonValidator.ipAddressValidator1]);
            this.form.get('networkStats.general.eth1.subnet').setValidators(CommonValidator.ipAddressValidator);
            this.form.get('networkStats.general.eth1.ip').updateValueAndValidity();
            this.form.get('networkStats.general.eth1.subnet').updateValueAndValidity();
          }
        
          this.form.get('networkStats.general.eth1.dhcp').patchValue(partitionData.networkStats.general.eth1.dhcp);
          if (partitionData.networkStats.general.eth1.ip != null) {
            if (partitionData.networkStats.general.eth1.ip == "127.0.0.1") {
              this.form.get('networkStats.general.eth1.disableEth1').setValue(false);
              this.form.get('networkStats.general.eth1.dhcp').setValue(false);
              this.form.get('networkStats.general.eth1.dhcp').disable();
              this.form.get('networkStats.general.eth1.staticMac').disable();
              this.form.get('networkStats.general.eth1.address').disable();
              this.form.get('networkStats.general.eth1.vlan').disable();
              this.form.get('networkStats.general.eth1.ip').disable();
              this.form.get('networkStats.general.eth1.subnet').disable();
            }
            this.form.get('networkStats.general.eth1.ip').patchValue(partitionData.networkStats.general.eth1.ip);
          }
          if (!this.form.get('networkStats.general.eth1.disableEth1').value) {
            this.form.get('networkStats.general.eth1.disableEth1').setValue(false);
            // this.form.get('networkStats.general.eth1.dhcp').setValue(false);
            this.form.get('networkStats.general.eth1.dhcp').disable();
            this.form.get('networkStats.general.eth1.staticMac').disable();
            this.form.get('networkStats.general.eth1.address').disable();
            this.form.get('networkStats.general.eth1.vlan').disable();
            this.form.get('networkStats.general.eth1.ip').disable();
            this.form.get('networkStats.general.eth1.subnet').disable();
          }
          if (partitionData.networkStats.general.eth1.subnet != null) {
            this.form.get('networkStats.general.eth1.subnet').patchValue(partitionData.networkStats.general.eth1.subnet);
          }
          if (partitionData.networkStats.general.eth1.staticMac != null) {
            if (partitionData.networkStats.general.eth1.staticMac && partitionData.networkStats.general.eth1.disableEth1) {
              this.form.get('networkStats.general.eth1.staticMac').patchValue(partitionData.networkStats.general.eth1.staticMac);
              this.form.get('networkStats.general.eth1.address').enable();
              this.form.get('networkStats.general.eth1.address').setValidators([CommonValidator.macAddressValidator]);
              this.form.get('networkStats.general.eth1.address').updateValueAndValidity();
            } else {
              this.form.get('networkStats.general.eth1.staticMac').patchValue(partitionData.networkStats.general.eth1.staticMac);
              this.form.get('networkStats.general.eth1.address').disable();
              this.form.get('networkStats.general.eth1.address').clearValidators();
              this.form.get('networkStats.general.eth1.address').updateValueAndValidity();
            }
          }
          if (partitionData.networkStats.general.eth1.address != null && partitionData.networkStats.general.eth1.address != null && partitionData.networkStats.general.eth1.address != '') {
            this.form.get('networkStats.general.eth1.address').setValue(partitionData.networkStats.general.eth1.address);
          }
          this.form.get('networkStats.general.eth1.vlan').patchValue(partitionData.networkStats.general.eth1.vlan);
        }
      }
      const control = <FormArray>this.form.get('networkStats').get('advanced').get('staticIpToHostConfig').get('add');
      const control1 = <FormArray>this.form.get('networkStats').get('advanced').get('dnsConfig').get('dnsServers');
      const control2 = <FormArray>this.form.get('networkStats').get('advanced').get('dnsConfig').get('searchDomainNames');
      control.controls = [];
      control2.controls = [];
      control1.controls = [];
      this.staticHostIp = [];
      this.dnsServers = [];
      this.domainNames = [];
      this.tempStaticHostIp = [];
      this.removeIpsArray = [];
      if (partitionData.networkStats.advanced != null) {
        if (partitionData.networkStats.advanced.staticIpToHostConfig != null) {
          if (partitionData.networkStats.advanced.staticIpToHostConfig.add != null) {
            let staticIpHost = partitionData.networkStats.advanced.staticIpToHostConfig.add;
            if (staticIpHost.length > 0) {
              staticIpHost.forEach(staticIpObj => {
                let ip = staticIpObj.ip;
                let hostname = staticIpObj.hostname;
                let alias = staticIpObj.alias;
                const control = <FormArray>this.form.get('networkStats').get('advanced').get('staticIpToHostConfig').get('add');
                let staticHostIpData = {};
                staticHostIpData['ip'] = ip;
                staticHostIpData['hostname'] = hostname;
                staticHostIpData['alias'] = alias;
                control.push(this.initItemRows(ip, hostname, alias));
                this.staticHostIp.push(staticHostIpData);
                this.tempStaticHostIp.push(staticHostIpData);
              });
            }
          }
        }
        // if(this.oldStaticHostIp.length>0){
        //   this.oldStaticHostIp.forEach(element => {
        //     this.staticHostIp.push(element);
        //   });
        //   this.oldStaticHostIp = [];
        // }
        if (partitionData.networkStats.advanced.dnsConfig != null) {
          this.isDNSserverChecked = false;
          const control = <FormControl>this.form.get('networkStats').get('advanced').
            get('dnsConfig').get('enableService');
          control.setValue(true);
          if (partitionData.networkStats.advanced.dnsConfig.dnsServers != null && partitionData.networkStats.advanced.dnsConfig.dnsServers != '') {
            let tempDnsServers = partitionData.networkStats.advanced.dnsConfig.dnsServers;
            if (tempDnsServers.length > 0) {
              tempDnsServers.forEach(dnsServer => {
                if (dnsServer != null && dnsServer != '') {
                  this.dnsServers.push(dnsServer);
                  const control = <FormArray>this.form.get('networkStats').get('advanced').
                    get('dnsConfig').get('dnsServers');
                  control.push(new FormControl(dnsServer));
                }

              });
            }
          }
          if (partitionData.networkStats.advanced.dnsConfig.searchDomainNames != null && partitionData.networkStats.advanced.dnsConfig.searchDomainNames != '') {
            let tempDomainNames = partitionData.networkStats.advanced.dnsConfig.searchDomainNames;
            if (tempDomainNames.length > 0) {
              tempDomainNames.forEach(domainName => {
                if (domainName != null && domainName != '') {
                  this.domainNames.push(domainName);
                  const control = <FormArray>this.form.get('networkStats').get('advanced').
                    get('dnsConfig').get('searchDomainNames');
                  control.push(new FormControl(domainName));
                }
              });
            }
          }
        } else {
          this.isDNSserverChecked = true;
          const control = <FormControl>this.form.get('networkStats').get('advanced').
            get('dnsConfig').get('enableService');
          control.setValue(false);
        }
      }
    }
  }

  changeInterfaces(value) {
    if (value == "all") {
      this.showEth0 = true;
      this.showEth1 = true;
      if (this.form.get('networkStats.general.eth0.dhcp')) {
        this.form.get('networkStats.general.eth0.ip').disable();
        this.form.get('networkStats.general.eth0.gateway').disable();
        this.form.get('networkStats.general.eth0.subnet').disable();
        this.form.get('networkStats.general.eth0.ip').clearValidators();
        this.form.get('networkStats.general.eth0.gateway').clearValidators();
        this.form.get('networkStats.general.eth0.subnet').clearValidators();
      } else {
        this.form.get('networkStats.general.eth0.ip').enable();
        this.form.get('networkStats.general.eth0.gateway').enable();
        this.form.get('networkStats.general.eth0.subnet').enable();
        this.form.get('networkStats.general.eth0.ip').setValidators([Validators.required, CommonValidator.ipAddressValidator1]);
        this.form.get('networkStats.general.eth0.gateway').setValidators(CommonValidator.ipAddressValidator);
        this.form.get('networkStats.general.eth0.subnet').setValidators(CommonValidator.ipAddressValidator);
      }
      if (this.form.get('networkStats.general.eth0.staticMac').value) {
        this.form.get('networkStats.general.eth0.address').enable();
        this.form.get('networkStats.general.eth0.address').setValidators([CommonValidator.macAddressValidator]);
      } else {
        this.form.get('networkStats.general.eth0.address').disable();
        this.form.get('networkStats.general.eth0.address').clearValidators();
      }
      // eth1
      if (this.form.get('networkStats.general.eth1.dhcp')) {
        this.form.get('networkStats.general.eth1.ip').disable();
        this.form.get('networkStats.general.eth1.subnet').disable();
        this.form.get('networkStats.general.eth1.ip').clearValidators();
        this.form.get('networkStats.general.eth1.subnet').clearValidators();
      } else {
        this.form.get('networkStats.general.eth1.ip').enable();
        this.form.get('networkStats.general.eth1.subnet').enable();
        this.form.get('networkStats.general.eth1.ip').setValidators([Validators.required, CommonValidator.ipAddressValidator1]);
        this.form.get('networkStats.general.eth1.subnet').setValidators(CommonValidator.ipAddressValidator);
      }
      if (this.form.get('networkStats.general.eth1.staticMac').value) {
        this.form.get('networkStats.general.eth1.address').enable();
        this.form.get('networkStats.general.eth1.address').setValidators([CommonValidator.macAddressValidator]);
      } else {
        this.form.get('networkStats.general.eth1.address').disable();
        this.form.get('networkStats.general.eth1.address').clearValidators();
      }
      this.form.get('networkStats.general.eth0.ip').updateValueAndValidity();
      this.form.get('networkStats.general.eth0.gateway').updateValueAndValidity();
      this.form.get('networkStats.general.eth0.subnet').updateValueAndValidity();
      this.form.get('networkStats.general.eth0.address').updateValueAndValidity();

      this.form.get('networkStats.general.eth1.ip').updateValueAndValidity();
      this.form.get('networkStats.general.eth1.subnet').updateValueAndValidity();
      this.form.get('networkStats.general.eth1.address').updateValueAndValidity();
    } else if (value == "eth0") {
      this.showEth0 = true;
      this.showEth1 = false;
      this.form.get('networkStats.general.eth0.ip').setValidators([Validators.required, CommonValidator.ipAddressValidator1]);
      this.form.get('networkStats.general.eth0.gateway').setValidators(CommonValidator.ipAddressValidator);
      this.form.get('networkStats.general.eth0.subnet').setValidators(CommonValidator.ipAddressValidator);
      this.form.get('networkStats.general.eth0.address').setValidators([CommonValidator.macAddressValidator]);
      this.form.get('networkStats.general.eth0.hostname').setValidators([CommonValidator.hostNameValidator]);
      this.form.get('networkStats.general.eth0.ip').updateValueAndValidity();
      this.form.get('networkStats.general.eth0.gateway').updateValueAndValidity();
      this.form.get('networkStats.general.eth0.subnet').updateValueAndValidity();
      this.form.get('networkStats.general.eth0.address').updateValueAndValidity();
      this.form.get('networkStats.general.eth0.hostname').updateValueAndValidity();
      this.form.get('networkStats.general.eth1.ip').clearValidators();
      this.form.get('networkStats.general.eth1.subnet').clearValidators();
      this.form.get('networkStats.general.eth1.ip').updateValueAndValidity();
      this.form.get('networkStats.general.eth1.subnet').updateValueAndValidity();
      this.form.get('networkStats.general.eth1.address').clearValidators();
      this.form.get('networkStats.general.eth1.address').updateValueAndValidity();

    } else if (value == "eth1") {
      this.showEth0 = false;
      this.showEth1 = true;
      this.form.get('networkStats.general.eth0.ip').clearValidators();
      this.form.get('networkStats.general.eth0.gateway').clearValidators();
      this.form.get('networkStats.general.eth0.subnet').clearValidators();
      this.form.get('networkStats.general.eth0.address').clearValidators();
      this.form.get('networkStats.general.eth0.hostname').clearValidators();
      this.form.get('networkStats.general.eth0.ip').updateValueAndValidity();
      this.form.get('networkStats.general.eth0.gateway').updateValueAndValidity();
      this.form.get('networkStats.general.eth0.subnet').updateValueAndValidity();
      this.form.get('networkStats.general.eth0.address').updateValueAndValidity();
      this.form.get('networkStats.general.eth0.hostname').updateValueAndValidity();
      this.form.get('networkStats.general.eth1.ip').setValidators([Validators.required, CommonValidator.ipAddressValidator1]);
      this.form.get('networkStats.general.eth1.subnet').setValidators([Validators.required, CommonValidator.ipAddressValidator]);
      this.form.get('networkStats.general.eth1.ip').updateValueAndValidity();
      this.form.get('networkStats.general.eth1.subnet').updateValueAndValidity();
      this.form.get('networkStats.general.eth1.address').setValidators([CommonValidator.macAddressValidator]);
      this.form.get('networkStats.general.eth1.address').updateValueAndValidity();
    }

  }
  closeConfigureNetworkModel() {
    this.configureNetworkModal.hide();
    this.clearData();
  }
  addStaticHostIp() {
    this.displayError = "";
    if (this.form.get('networkStats.advanced.ip').value != null && this.form.get('networkStats.advanced.ip').value != ''
      && this.form.get('networkStats.advanced.hostname').value != null && this.form.get('networkStats.advanced.hostname').value != '') {
      if (this.form.get('networkStats.advanced.ip').errors == null
        && this.form.get('networkStats.advanced.hostname').errors == null) {
        if (this.staticHostIp.length < 16) {
          let ip = this.form.get('networkStats.advanced.ip').value;
          let hostname = this.form.get('networkStats.advanced.hostname').value;
          let alias = this.form.get('networkStats.advanced.alias').value;
          let flag = this.staticHostIp.some(e => e.ip == ip);
          if (!flag) {
            flag = this.staticHostIp.some(e => e.hostname == hostname);
          }
          if (!flag) {
            const control = <FormArray>this.form.get('networkStats').get('advanced').get('staticIpToHostConfig').get('add');
            let staticHostIpData = {};
            staticHostIpData['ip'] = ip;
            staticHostIpData['hostname'] = hostname;
            staticHostIpData['alias'] = alias;
            control.push(this.initItemRows(ip, hostname, alias));
            this.tempStaticHostIp.push(staticHostIpData);
            this.staticHostIp.push(staticHostIpData);

            this.form.get('networkStats.advanced.ip').setValue("");
            this.form.get('networkStats.advanced.hostname').setValue("");
            this.form.get('networkStats.advanced.alias').setValue("");
          } else {
            this.displayError = "Entered IP address and hostname should be unique. "
          }
        } else {
          this.displayError = "You can enter maximum 16 static Ip's"
        }
      }
    } else {
      this.displayError = "Please enter the required fields"
    }
  }

  removeStaticHostIp(index, ip) {
    const control = <FormArray>this.form.get('networkStats').get('advanced').get('staticIpToHostConfig').get('add');
    // remove the chosen row
    control.removeAt(index);
    let indexAt = this.staticHostIp.findIndex(staticIp => staticIp.ip === ip);
    this.staticHostIp.splice(indexAt, 1);
    let flag = this.removeIpsArray.some(e => e.ip == ip);
    if (!flag) {
      this.removeIpsArray.push(ip);
    }
    const index1 = this.tempStaticHostIp.findIndex(staticIp => staticIp.ip === ip);
    if (index1 != -1) {
      this.tempStaticHostIp.splice(index1, 1);
    }
  }

  addDnsServer() {
    this.displayError = "";
    if (this.dnsServers.length < 4) {
      if (this.form.get('networkStats.advanced.dnsServer').value != "") {
        if (this.form.get('networkStats.advanced.dnsServer').errors == null) {
          let flag = this.dnsServers.some(e => e ==
            this.form.get('networkStats.advanced.dnsServer').value);
          if (!flag) {
            const control = <FormArray>this.form.get('networkStats').get('advanced').
              get('dnsConfig').get('dnsServers');
            control.push(new FormControl(this.form.get('networkStats.advanced.dnsServer').value));
            this.dnsServers.push(this.form.get('networkStats.advanced.dnsServer').value);
            this.form.get('networkStats.advanced.dnsServer').setValue("");
          } else {
            this.displayError = "Entered DNS address already exists."
          }
        }
      } else {
        this.displayError = "Please enter the required field";
      }
    } else {
      this.displayError = "You can enter maximum 4 DNS Servers"
    }


  }


  removeDnsServers(index) {
    const control = <FormArray>this.form.get('networkStats').get('advanced')
      .get('dnsConfig').get('dnsServers');
    // remove the chosen row
    control.removeAt(index);
    let indexAt = this.dnsServers.indexOf(index);
    this.dnsServers.splice(indexAt);
  }

  addDomainName() {
    this.displayError = "";
    if (this.domainNames.length < 4) {
      if (this.form.get('networkStats.advanced.searchDomainName').value != "") {
        if (this.form.get('networkStats.advanced.searchDomainName').errors == null) {
          let flag = this.domainNames.some(e => e ==
            this.form.get('networkStats.advanced.searchDomainName').value);
          if (!flag) {
            const control = <FormArray>this.form.get('networkStats').get('advanced').
              get('dnsConfig').get('searchDomainNames');
            // control.push(this.form.get('networkStats.advanced.dnsServer').value);
            control.push(new FormControl(this.form.get('networkStats.advanced.searchDomainName').value));
            this.domainNames.push(this.form.get('networkStats.advanced.searchDomainName').value);
            this.form.get('networkStats.advanced.searchDomainName').setValue("");
          } else {
            this.displayError = "Domain Name is already exists";
          }
        }
      } else {
        this.displayError = " Please enter the required field"
      }
    } else {
      this.displayError = " You can enter maximum 4 Domain Names"
    }
  }

  removeSearchDomain(index) {
    const control = <FormArray>this.form.get('networkStats').get('advanced')
      .get('dnsConfig').get('searchDomainNames');
    // remove the chosen row
    control.removeAt(index);
    let indexAt = this.domainNames.indexOf(index);
    this.domainNames.splice(indexAt);
  }

  toggleDhcpEth0(event) {
    if (event.checked) {
      this.form.get('networkStats.general.eth0.ip').disable();
      this.form.get('networkStats.general.eth0.gateway').disable();
      this.form.get('networkStats.general.eth0.subnet').disable();
      this.form.get('networkStats.general.eth0.ip').clearValidators();
      this.form.get('networkStats.general.eth0.gateway').clearValidators();
      this.form.get('networkStats.general.eth0.subnet').clearValidators();
    } else {
      this.form.get('networkStats.general.eth0.ip').setValidators([Validators.required, CommonValidator.ipAddressValidator1]);
      this.form.get('networkStats.general.eth0.gateway').setValidators(CommonValidator.ipAddressValidator);
      this.form.get('networkStats.general.eth0.subnet').setValidators(CommonValidator.ipAddressValidator);
      this.form.get('networkStats.general.eth0.ip').enable();
      this.form.get('networkStats.general.eth0.gateway').enable();
      this.form.get('networkStats.general.eth0.subnet').enable();
      this.form.get('networkStats.general.eth0.ip').markAsUntouched();
    }
    this.form.get('networkStats.general.eth0.ip').updateValueAndValidity();
    this.form.get('networkStats.general.eth0.gateway').updateValueAndValidity();
    this.form.get('networkStats.general.eth0.subnet').updateValueAndValidity();
  }

  toggleMacAddressEth0(event) {
    //this.eth0MacAddress = false;
    // this.form.get('networkStats.general.eth0.address').reset();
    if (event.checked) {
      this.form.get('networkStats.general.eth0.address').enable();
      this.form.get('networkStats.general.eth0.address').markAsUntouched();
      this.form.get('networkStats.general.eth0.address').setValidators([Validators.required, CommonValidator.macAddressValidator]);
    } else {
      this.form.get('networkStats.general.eth0.address').disable();
      this.form.get('networkStats.general.eth0.address').clearValidators();
      // this.form.get('networkStats.general.eth0.address').setValue(this.networkData.general.eth0.mac);
    }
    this.form.get('networkStats.general.eth0.address').updateValueAndValidity();
  }

  toggleDhcpEth1(event) {
    // this.isEth1IpValidate = false;
    // this.form.get("networkStats.general.eth1.ip").reset();
    // this.form.get("networkStats.general.eth1.gateway").reset();
    if (event.checked) {
      this.form.get('networkStats.general.eth1.ip').disable();
      this.form.get('networkStats.general.eth1.subnet').disable();
      this.form.get('networkStats.general.eth1.ip').clearValidators();
      this.form.get('networkStats.general.eth1.subnet').clearValidators();
    } else {
      // this.form.get("networkStats.general.eth1.ip").setValue(this.networkData.general.eth1.ip);
      // this.form.get("networkStats.general.eth1.gateway").setValue(this.networkData.general.eth1.gateway);
      this.form.get('networkStats.general.eth1.ip').enable();
      this.form.get('networkStats.general.eth1.subnet').enable();
      this.form.get('networkStats.general.eth1.ip').markAsUntouched();
      this.form.get('networkStats.general.eth1.subnet').markAsUntouched();
      this.form.get('networkStats.general.eth1.ip').setValidators([Validators.required, CommonValidator.ipAddressValidator1]);
      this.form.get('networkStats.general.eth1.subnet').setValidators(CommonValidator.ipAddressValidator);
    }
    this.form.get('networkStats.general.eth1.ip').updateValueAndValidity();
    this.form.get('networkStats.general.eth1.subnet').updateValueAndValidity();
  }

  disableEth1Fields(event) {

    if (event.checked) {
      this.form.get('networkStats.general.eth1.dhcp').enable();
      if (this.form.get('networkStats.general.eth1.dhcp').value) {
        this.form.get('networkStats.general.eth1.ip').disable();
        this.form.get('networkStats.general.eth1.subnet').disable();
        this.form.get('networkStats.general.eth1.ip').clearValidators();
        this.form.get('networkStats.general.eth1.subnet').clearValidators();
      } else {
        this.form.get('networkStats.general.eth1.ip').enable();
        this.form.get('networkStats.general.eth1.subnet').enable();
        this.form.get('networkStats.general.eth1.ip').markAsUntouched();
        this.form.get('networkStats.general.eth1.subnet').markAsUntouched();
        this.form.get('networkStats.general.eth1.ip').setValidators([Validators.required, CommonValidator.ipAddressValidator1]);
        this.form.get('networkStats.general.eth1.subnet').setValidators(CommonValidator.ipAddressValidator);
      }
      this.form.get('networkStats.general.eth1.ip').updateValueAndValidity();
      this.form.get('networkStats.general.eth1.subnet').updateValueAndValidity();

      this.form.get('networkStats.general.eth1.staticMac').enable();
      if (this.form.get('networkStats.general.eth1.staticMac').value) {
        this.form.get('networkStats.general.eth1.address').enable();
        this.form.get('networkStats.general.eth1.address').markAsUntouched();
        this.form.get('networkStats.general.eth1.address').setValidators([Validators.required, CommonValidator.macAddressValidator]);
      } else {
        this.form.get('networkStats.general.eth1.address').disable();
        this.form.get('networkStats.general.eth1.address').clearValidators();
      }
      this.form.get('networkStats.general.eth1.address').updateValueAndValidity();
      this.form.get('networkStats.general.eth1.vlan').enable();
    } else {
      this.form.get('networkStats.general.eth1.dhcp').disable();
      this.form.get('networkStats.general.eth1.staticMac').disable();
      this.form.get('networkStats.general.eth1.address').disable();
      this.form.get('networkStats.general.eth1.vlan').disable();
      this.form.get('networkStats.general.eth1.ip').disable();
      this.form.get('networkStats.general.eth1.subnet').disable();
      this.form.get('networkStats.general.eth1.ip').clearValidators();
      this.form.get('networkStats.general.eth1.subnet').clearValidators();
      this.form.get('networkStats.general.eth1.address').clearValidators();
      this.form.get('networkStats.general.eth1.ip').updateValueAndValidity();
      this.form.get('networkStats.general.eth1.subnet').updateValueAndValidity();
      this.form.get('networkStats.general.eth1.address').updateValueAndValidity();
    }
  }



  toggleMacAddressEth1(event) {
    // this.form.get('networkStats.general.eth1.address').reset();
    if (event.checked) {
      this.form.get('networkStats.general.eth1.address').enable();
      this.form.get('networkStats.general.eth1.address').markAsUntouched();
      this.form.get('networkStats.general.eth1.address').setValidators([Validators.required, CommonValidator.macAddressValidator]);
    } else {
      this.form.get('networkStats.general.eth1.address').disable();
      this.form.get('networkStats.general.eth1.address').clearValidators();
      // this.form.get('networkStats.general.eth1.address').setValue(this.networkData.general.eth1.mac);
    }
    this.form.get('networkStats.general.eth1.address').updateValueAndValidity();
  }
  disableDNSserver(event) {
    if (event.checked) {
      this.isDNSserverChecked = false;
      const control = <FormControl>this.form.get('networkStats').get('advanced').
        get('dnsConfig').get('enableService');
      control.setValue(true);
    } else {
      this.isDNSserverChecked = true;
      const control = <FormControl>this.form.get('networkStats').get('advanced').
        get('dnsConfig').get('enableService');
      control.setValue(false);
    }
  }
  public OnlyNumericValues(e) {
    let input;
    if (e.metaKey || e.ctrlKey) {
      return true;
    }
    if (e.which === 32) {
      return false;
    }
    if (e.which === 0) {
      return true;
    }
    if (e.which < 33) {
      return true;
    }
    input = String.fromCharCode(e.which);
    return !!/[\d\s]/.test(input);
  }
  clearData() {
    this.form.reset();
    this.tab = ''
    this.staticHostIp = [];
    this.dnsServers = [];
    this.domainNames = [];
    this.displayError = '';
    this.displayError1 = '';
    this.classStatic = '';
    this.classServer = '';
    this.classDomain = '';
    this.partitionCount = 1;
    this.totalPartitionCount = 0;
    this.selectedPartitionList = [];
    this.partitionName = '';
    this.showEth0 = true;
    this.showEth1 = true;
    this.finalPartitionList = []
    this.isDNSserverChecked = false;
    this.showBackButton = false;
    this.tabName = "";
    this.showFinalPartitionList = false;
    this.tempStaticHostIp = [];
    this.removeIpsArray = [];
  }

  submitConfigurationNetworkDetails() {
    this.configureNetworkModal.hide();
    let partitionList = [];
    this.finalPartitionList.forEach(obj => {
      // eth1
      if(obj.networkStats.general.eth1.disableEth1){
        obj.networkStats.general.eth1.dhcp = false
        obj.networkStats.general.eth1.ip=null;
        obj.networkStats.general.eth1.subnet=null;
      }
      partitionList.push(obj);
    })
    this.partitionOperationsComponent.performSelectedOperation(partitionList, "Configure Network");
  }

  callBackToPartitionLogin() {
    this.displayMsgModal.hide();
    console.log("Configure Network  --> Call back to partition login page");
    this.clearData();
    this.messageEvent1.emit();
  }

  /* Remove appliance from the final list */
  removePartition(partitionId, template: TemplateRef<any>) {
    let selectedId = [];
    this.displayError = '';
    selectedId.push(partitionId);
    if (this.finalPartitionList.length == 1) {
      this.displayError = "Please maintain atleast one partition to continue the operation, otherwise you can click on close button to exit.";
      return false;
    } else {
      this.finalPartitionList = this.finalPartitionList.filter(
        val => !selectedId.includes(val.partitionId));
      this.selectedPartitionList = this.selectedPartitionList.filter(
        val => !selectedId.includes(val.partitionId));
      this.partitionCount = this.partitionCount - 1;
      this.totalPartitionCount = this.finalPartitionList.length;
    }
  }
}
