import { Component, OnInit } from '@angular/core';
import { ChartsModule, Color } from 'ng2-charts';
import { PartitionManagementService } from './../../../../services/partitionmanagement/partitionmanagement.service'
import { AnonymousSubscription } from "rxjs/Subscription";
import { Observable } from "rxjs/Observable";
declare var Chart: any;

@Component({
  selector: 'app-partition-snapshot',
  templateUrl: './partition-snapshot.component.html',
  styleUrls: ['./partition-snapshot.component.css']
})
export class PartitionSnapshotComponent implements OnInit {
  myBarChart: any;
  alertDetails: any = [];
  recentActivityList: any = [];
  inProgressActivityList = [];
  alertsList: any = [];
  availablePartition: any;
  occupiedPartition: any;

  functionalPartition: any;
  nonFunctionalPartition: any;

  zeroizedState: any;
  fipMode: any;
  fipModeWithDualfactor: any;
  nonFipMode: any;

  keyDetailsData: any = [];
  acclrDeviceDetailsData: any = [];
  contextDetailsData: any = [];

  public loading = false;

  public getProgressActivities: AnonymousSubscription;
  public getGraphData: AnonymousSubscription;
  public timer: AnonymousSubscription;
  graphTotalDetails: any = [];
  // keys variables 
  firstKeysList: any = [];
  secondKeysList: any = [];
  thirdKeysList: any = [];
  fourthKeysList: any = [];
  fifthKeysList: any = [];

  // Acceleration Device variables 
  firstAccDevList: any = [];
  secondAccDevList: any = [];
  thirdAccDevList: any = [];
  fourthAccDevList: any = [];
  fifthAccDevList: any = [];

  // SSL Contexts variables 
  firstSSLCtxtList: any = [];
  seconSSLCtxtList: any = [];
  thirdSSLCtxtList: any = [];
  fourthSSLCtxtList: any = [];
  fifthSSLCtxtList: any = [];
  isNoUsageDataAvailable: boolean = false;
  isNoStatusDataAvailable: boolean = false;
  isNoFipsStatusDataAvailable: boolean = false;
  isNoKeysAvailable: boolean = false;
  isNoAccelerationAvailable: boolean = false;
  isNoSSLContextAvailable: boolean = false;

  constructor(private _partitionManagementService: PartitionManagementService) { }

  ngOnInit() {
    this.getAlerts();
    this.getGraphDetails('');
    this.getRecentActivity();
    this.getInProgressActivity();
    this.createBarChart('');
  }

  getAlerts() {
    this.loading = true;
    this._partitionManagementService.getAlertDetails().subscribe(
      res => {
        this.loading = false;
        this.alertsList = [];
        res.forEach(element => {
          let alerts = {};
          // alerts['timezone'] = element.timezone;
          alerts['createdDate'] = element.createdDate;
          alerts['message'] = element.message;
          alerts['moduleId'] = element.moduleId;
          alerts['moduleName'] = element.moduleName;
          alerts['applianceId'] = element.applianceId;
          alerts['applianceIp'] = element.applianceIp;
          alerts['applianceName'] = element.applianceName;
          this.alertsList.push(alerts);
        });
      },
      error => {
        this.loading = false;
        console.log(error);
      },
    );
  }
  // graphSubsTimer: AnonymousSubscription;
  // graphTimer: AnonymousSubscription;
  getGraphDetails(graphName) {
    // this.loading = true;
    if (graphName == "usage") {
      this.mycolors = [{ 'backgroundColor': [], 'hoverBackgroundColor': [] }];
      this.doughnutChartData = [];
      this.doughnutChartLabels = [];
      this.isNoUsageDataAvailable = false;
    } else if (graphName == "status") {
      this.mycolorsDC1 = [{ 'backgroundColor': [], 'hoverBackgroundColor': [] }];
      this.doughnutChartData1 = [];
      this.doughnutChartLabels1 = [];
      this.isNoStatusDataAvailable = false;
    } else if (graphName == "fipsStatus") {
      this.mycolorsDC2 = [{ 'backgroundColor': [], 'hoverBackgroundColor': [] }];
      this.doughnutChartData2 = [];
      this.doughnutChartLabels2 = [];
      this.isNoFipsStatusDataAvailable = false;
    } else {
      this.isNoUsageDataAvailable = false;
      this.isNoStatusDataAvailable = false;
      this.isNoFipsStatusDataAvailable = false;
      this.mycolors = [{ 'backgroundColor': [], 'hoverBackgroundColor': [] }];
      this.doughnutChartData = [];
      this.doughnutChartLabels = [];
      this.mycolorsDC1 = [{ 'backgroundColor': [], 'hoverBackgroundColor': [] }];
      this.doughnutChartData1 = [];
      this.doughnutChartLabels1 = [];
      this.mycolorsDC2 = [{ 'backgroundColor': [], 'hoverBackgroundColor': [] }];
      this.doughnutChartData2 = [];
      this.doughnutChartLabels2 = [];
    }


    this._partitionManagementService.getBarGraphData().subscribe(
      res => {
        //this.loading = false;
        //usage
        if (graphName == "usage") {
          this.setUsageData(res);
        } else if (graphName == "status") {
          this.setStatusData(res);
        } else if (graphName == "fipsStatus") {
          this.setFipsStatus(res);
        } else {
          this.setUsageData(res);
          this.setStatusData(res);
          this.setFipsStatus(res);
        }
        // this.reloadGraphsData();
      },
      error => {
        this.loading = false;
        console.log(error);
      },
    );
  }

  setUsageData(res) {
    this.availablePartition = res.avaliablePartitionSlots;
    this.occupiedPartition = res.occupiedPartitionSlots;
    if (this.occupiedPartition != 0) {
      this.doughnutChartData.push(this.occupiedPartition);
      this.doughnutChartLabels.push("Used");
      this.mycolors[0].backgroundColor.push('rgb(247, 113, 131)');
      this.mycolors[0].hoverBackgroundColor.push('rgb(247, 113, 131)');
    }
    if (this.availablePartition != 0) {
      this.doughnutChartData.push(this.availablePartition);
      this.doughnutChartLabels.push("Available");
      this.mycolors[0].backgroundColor.push('rgb(84, 198, 233)');
      this.mycolors[0].hoverBackgroundColor.push('rgb(84, 198, 233)');
    }
    if (this.doughnutChartData.length <= 0) {
      this.isNoUsageDataAvailable = true;
    }
  }

  setStatusData(res) {
    this.functionalPartition = res.partitionFunctionalStatus;
    this.nonFunctionalPartition = res.partitionNonFunctionalStatus;
    if (this.functionalPartition != 0) {
      this.doughnutChartData1.push(this.functionalPartition);
      this.doughnutChartLabels1.push("Functional Partition");
      this.mycolorsDC1[0].backgroundColor.push('rgb(0,179,30)');
      this.mycolorsDC1[0].hoverBackgroundColor.push('rgb(0,179,30)');
    }
    if (this.nonFunctionalPartition != 0) {
      this.doughnutChartData1.push(this.nonFunctionalPartition);
      this.doughnutChartLabels1.push("Non-Functional Partition");
      this.mycolorsDC1[0].backgroundColor.push('rgb(247, 113, 131)');
      this.mycolorsDC1[0].hoverBackgroundColor.push('rgb(247, 113, 131)');
    }
    if (this.doughnutChartData1.length <= 0) {
      this.isNoStatusDataAvailable = true;
    }
  }

  setFipsStatus(res) {
    this.zeroizedState = res.zeroizedState;
    this.fipMode = res.fipMode;
    this.fipModeWithDualfactor = res.fipModeWithDualfactor;
    this.nonFipMode = res.nonFipMode;
    if (this.zeroizedState != 0) {
      this.doughnutChartData2.push(this.zeroizedState);
      this.doughnutChartLabels2.push("Zeroized State");
      this.mycolorsDC2[0].backgroundColor.push('rgb(247, 113, 131)');
      this.mycolorsDC2[0].hoverBackgroundColor.push('rgb(247, 113, 131)');
    }
    if (this.fipMode != 0) {
      this.doughnutChartData2.push(this.fipMode);
      this.doughnutChartLabels2.push("FIPS mode");
      this.mycolorsDC2[0].backgroundColor.push('rgb(0,179,30)');
      this.mycolorsDC2[0].hoverBackgroundColor.push('rgb(0,179,30)');
    }
    if (this.fipModeWithDualfactor != 0) {
      this.doughnutChartData2.push(this.fipModeWithDualfactor);
      this.doughnutChartLabels2.push("FIPS mode with 2 F-Auth");
      this.mycolorsDC2[0].backgroundColor.push('rgb(84, 198, 233)');
      this.mycolorsDC2[0].hoverBackgroundColor.push('rgb(84, 198, 233)');
    }
    if (this.nonFipMode != 0) {
      this.doughnutChartData2.push(this.nonFipMode);
      this.doughnutChartLabels2.push("Non-FIPS mode");
      this.mycolorsDC2[0].backgroundColor.push('rgb(0, 0, 204)');
      this.mycolorsDC2[0].hoverBackgroundColor.push('rgb(0, 0, 204)');
    }
    if (this.doughnutChartData2.length <= 0) {
      this.isNoFipsStatusDataAvailable = true;
    }
  }
  // reloadGraphsData(){
  //     this.graphSubsTimer = Observable.timer(30000).first().subscribe(() => this.getGraphDetails());
  // }

  getRecentActivity() {
    this.loading = true;
    this._partitionManagementService.getRecentActivityDetails().subscribe(
      res => {
        this.loading = false;
        this.recentActivityList = [];
        let colors = ["red", "green", "blue"];
        let count = 0;
        res.forEach(element => {
          let recentActivity = {};
          if (count == 3) {
            count = 0;
          }
          // recentActivity['timezone'] = element.timezone;
          recentActivity['message'] = element.message;
          recentActivity['createdDate'] = element.createdDate;
          recentActivity['color'] = colors[count];
          this.recentActivityList.push(recentActivity);
          count++;
        });
      },
      error => {
        this.loading = false;
        console.log(error);
      },
    );
  }
  //Usage Donut chart 
  public doughnutChartData: number[] = [];
  public doughnutChartLabels: string[] = [];
  public doughnutChartType: string = 'doughnut';
  public chartOptions = {
    responsive: true,
    legend: {
      display: true,
      position: 'right',
      labels: {
        boxWidth: 10
      }
    }
  };
  public mycolors = [
    {
      backgroundColor: [],
      hoverBackgroundColor: [],
    }
  ];


  // create keys , acceleration & context data bar graph.
  createBarChart(chartName) {
    this.clearBarGraphData(chartName);
    // this.loading = true;
    this.getGraphData = this._partitionManagementService.getBarGraphData().subscribe(
      res => {
        // debugger
        // this.loading = false;
        this.keyDetailsData = res.keyDetailsWithPercentage;
        this.acclrDeviceDetailsData = res.acclrDeviceDetailsWithPercentage;
        this.contextDetailsData = res.contextDetailsWithPercentage;
        // keys bar graph
        if (chartName == 'keys') {
          this.createKeysBarGraph();
        } else if (chartName == 'acceleration') {
          this.createAccDevBarGraph();
        } else if (chartName == 'sslcontext') {
          this.createSSLContextsBarGraph();
        } else {
          this.createKeysBarGraph();
          this.createAccDevBarGraph();
          this.createSSLContextsBarGraph();
        }
      }
    );
  }
  clearBarGraphData(chartName) {
    if (chartName == 'keys') {
      // keys variables 
      this.firstKeysList = [];
      this.secondKeysList = [];
      this.thirdKeysList = [];
      this.fourthKeysList = [];
      this.fifthKeysList = [];
      this.isNoKeysAvailable = false;
      this.barChartData1 = [];
    } else if (chartName == 'acceleration') {
      // Acceleration Device variables 
      this.firstAccDevList = [];
      this.secondAccDevList = [];
      this.thirdAccDevList = [];
      this.fourthAccDevList = [];
      this.fifthAccDevList = [];
      this.isNoAccelerationAvailable = false;
      this.barChartData2 = [];
    } else if (chartName == 'sslcontext') {
      // SSL Contexts variables 
      this.firstSSLCtxtList = [];
      this.seconSSLCtxtList = [];
      this.thirdSSLCtxtList = [];
      this.fourthSSLCtxtList = [];
      this.fifthSSLCtxtList = [];
      this.isNoSSLContextAvailable = false;
      this.barChartData3 = [];
    } else {
      // keys variables 
      this.firstKeysList = [];
      this.secondKeysList = [];
      this.thirdKeysList = [];
      this.fourthKeysList = [];
      this.fifthKeysList = [];
      this.barChartData1 = [];
      this.isNoKeysAvailable = false;
      // Acceleration Device variables 
      this.firstAccDevList = [];
      this.secondAccDevList = [];
      this.thirdAccDevList = [];
      this.fourthAccDevList = [];
      this.fifthAccDevList = [];
      this.barChartData2 = [];
      this.isNoAccelerationAvailable = false;
      // SSL Contexts variables 
      this.firstSSLCtxtList = [];
      this.seconSSLCtxtList = [];
      this.thirdSSLCtxtList = [];
      this.fourthSSLCtxtList = [];
      this.fifthSSLCtxtList = [];
      this.barChartData3 = [];
      this.isNoSSLContextAvailable = false;
    }


  }

  createKeysBarGraph() {
    if (this.keyDetailsData != null) {

      // keys - 0 to 20 percentage data with appliance names.
      if (this.keyDetailsData.tenPercentList.length > 0 || this.keyDetailsData.twentyPercentList.length > 0) {
        let d1 = 0, d2 = 0;
        if (this.keyDetailsData.tenPercentList.length > 0) {
          let percentageList = this.keyDetailsData.tenPercentList.map(item => item.percentage);
          let applianceList = this.keyDetailsData.tenPercentList.map(item => item.applianceName);
          d1 = (applianceList.length);
          applianceList.forEach((item, index) => {
            this.firstKeysList.push(item + " : " + percentageList[index] + " % ");
          });
        }
        if (this.keyDetailsData.twentyPercentList.length > 0) {
          let percentageList = this.keyDetailsData.twentyPercentList.map(item => item.percentage);
          let applianceList = this.keyDetailsData.twentyPercentList.map(item => item.applianceName);
          d2 = (applianceList.length);
          applianceList.forEach((item, index) => {
            this.firstKeysList.push(item + " : " + percentageList[index] + " % ");
          });
        }
        this.barChartData1.push(String(d1 + d2));
      } else {
        this.barChartData1.push(String(0));
      }

      // keys - 20 to 40 percentage data with appliance names.
      if (this.keyDetailsData.thirtyPercentList.length > 0 || this.keyDetailsData.fortyPercentList.length > 0) {
        let d1 = 0, d2 = 0;
        if (this.keyDetailsData.thirtyPercentList.length > 0) {
          let percentageList = this.keyDetailsData.thirtyPercentList.map(item => item.percentage);
          let applianceList = this.keyDetailsData.thirtyPercentList.map(item => item.applianceName);
          d1 = (applianceList.length);
          applianceList.forEach((item, index) => {
            this.secondKeysList.push(item + " : " + percentageList[index] + " % ");
          });
        }
        if (this.keyDetailsData.fortyPercentList.length > 0) {
          let percentageList = this.keyDetailsData.fortyPercentList.map(item => item.percentage);
          let applianceList = this.keyDetailsData.fortyPercentList.map(item => item.applianceName);
          d2 = (applianceList.length);
          applianceList.forEach((item, index) => {
            this.secondKeysList.push(item + " : " + percentageList[index] + " % ");
          });
        }
        this.barChartData1.push(String(d1 + d2));
      } else {
        this.barChartData1.push(String(0));
      }

      // keys - 40 to 60 percentage data with appliance names.
      if (this.keyDetailsData.fiftyPercentList.length > 0 || this.keyDetailsData.sixtyPercentList.length > 0) {
        let d1 = 0, d2 = 0;
        if (this.keyDetailsData.fiftyPercentList.length > 0) {
          let percentageList = this.keyDetailsData.fiftyPercentList.map(item => item.percentage);
          let applianceList = this.keyDetailsData.fiftyPercentList.map(item => item.applianceName);
          d1 = (applianceList.length);
          applianceList.forEach((item, index) => {
            this.thirdKeysList.push(item + " : " + percentageList[index] + " % ");
          });
        }
        if (this.keyDetailsData.sixtyPercentList.length > 0) {
          let percentageList = this.keyDetailsData.sixtyPercentList.map(item => item.percentage);
          let applianceList = this.keyDetailsData.sixtyPercentList.map(item => item.applianceName);
          d2 = (applianceList.length);
          applianceList.forEach((item, index) => {
            this.thirdKeysList.push(item + " : " + percentageList[index] + " % ");
          });
        }
        this.barChartData1.push(String(d1 + d2));
      } else {
        this.barChartData1.push(String(0));
      }

      // keys - 60 to 80 percentage data with appliance names.
      if (this.keyDetailsData.seventyPercentList.length > 0 || this.keyDetailsData.eightyPercentList.length > 0) {
        let d1 = 0, d2 = 0;
        if (this.keyDetailsData.seventyPercentList.length > 0) {
          let percentageList = this.keyDetailsData.seventyPercentList.map(item => item.percentage);
          let applianceList = this.keyDetailsData.seventyPercentList.map(item => item.applianceName);
          d1 = (applianceList.length);
          applianceList.forEach((item, index) => {
            this.fourthKeysList.push(item + " : " + percentageList[index] + " % ");
          });
        }
        if (this.keyDetailsData.eightyPercentList.length > 0) {
          let percentageList = this.keyDetailsData.eightyPercentList.map(item => item.percentage);
          let applianceList = this.keyDetailsData.eightyPercentList.map(item => item.applianceName);
          d2 = (applianceList.length);
          applianceList.forEach((item, index) => {
            this.fourthKeysList.push(item + " : " + percentageList[index] + " % ");
          });
        }
        this.barChartData1.push(String(d1 + d2));
      } else {
        this.barChartData1.push(String(0));
      }

      // keys - 80 to 100 percentage data with appliance names.
      if (this.keyDetailsData.ninetyPercentList.length > 0 || this.keyDetailsData.hundredPercentList.length > 0) {
        let d1 = 0, d2 = 0;
        if (this.keyDetailsData.ninetyPercentList.length > 0) {
          let percentageList = this.keyDetailsData.ninetyPercentList.map(item => item.percentage);
          let applianceList = this.keyDetailsData.ninetyPercentList.map(item => item.applianceName);
          d1 = (applianceList.length);
          applianceList.forEach((item, index) => {
            this.fifthKeysList.push(item + " : " + percentageList[index] + " % ");
          });
        }
        if (this.keyDetailsData.hundredPercentList.length > 0) {
          let percentageList = this.keyDetailsData.hundredPercentList.map(item => item.percentage);
          let applianceList = this.keyDetailsData.hundredPercentList.map(item => item.applianceName);
          d2 = (applianceList.length);
          applianceList.forEach((item, index) => {
            this.fifthKeysList.push(item + " : " + percentageList[index] + " % ");
          });
        }
        this.barChartData1.push(String(d1 + d2));
      } else {
        this.barChartData1.push(String(0));
      }
    }
    if (this.keyDetailsData.tenPercentList.length <= 0 &&
      this.keyDetailsData.twentyPercentList.length <= 0 &&
      this.keyDetailsData.thirtyPercentList.length <= 0 &&
      this.keyDetailsData.fortyPercentList.length <= 0 &&
      this.keyDetailsData.fiftyPercentList.length <= 0 &&
      this.keyDetailsData.sixtyPercentList.length <= 0 &&
      this.keyDetailsData.seventyPercentList.length <= 0 &&
      this.keyDetailsData.eightyPercentList.length <= 0 &&
      this.keyDetailsData.ninetyPercentList.length <= 0 &&
      this.keyDetailsData.hundredPercentList.length <= 0) {
      this.isNoKeysAvailable = true;
    }
  }

  //keys bar chart options.
  public barChartOptionsKeys: any = {
    scaleShowVerticalLines: false,
    responsive: true,
    legend: {
      display: true,
      position: 'left',
    },
    scales: {
      yAxes: [{
        ticks: {
          min: 0, // it is for ignoring negative step.
          beginAtZero: true,
          callback: function (value, index, values) {
            if (Math.floor(value) === value) {
              return value;
            }
          }
        },
        scaleLabel: {
          display: true,
          labelString: 'No. of Appliances',
          fontStyle: 'normal'
        }
      }],
      xAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'Keys Percentage',
          fontStyle: 'normal'
        }
      }],
    },
    tooltips: {
      callbacks: {
        label: (tooltipItem, data) => {
          return '';
        },
        title: (items, data) => {
          let graphData: any;
          if (items[0].index == 0) {
            if (this.firstKeysList.length > 0) {
              graphData = this.firstKeysList;
            }
          }
          else if (items[0].index == 1) {
            if (this.secondKeysList.length > 0) {
              graphData = this.secondKeysList;
            }
          }
          else if (items[0].index == 2) {
            if (this.thirdKeysList.length > 0) {
              graphData = this.thirdKeysList;
            }
          }
          else if (items[0].index == 3) {
            if (this.fourthKeysList.length > 0) {
              graphData = this.fourthKeysList;
            }
          }
          else if (items[0].index == 4) {
            if (this.fifthKeysList.length > 0) {
              graphData = this.fifthKeysList;
            }
          }
          return graphData;
        }
      }
    }
  };

  createAccDevBarGraph() {
    if (this.acclrDeviceDetailsData != null) {

      // keys - 0 to 20 percentage data with appliance names.
      if (this.acclrDeviceDetailsData.tenPercentList.length > 0 || this.acclrDeviceDetailsData.twentyPercentList.length > 0) {
        let d1 = 0, d2 = 0;
        if (this.acclrDeviceDetailsData.tenPercentList.length > 0) {
          let percentageList = this.acclrDeviceDetailsData.tenPercentList.map(item => item.percentage);
          let applianceList = this.acclrDeviceDetailsData.tenPercentList.map(item => item.applianceName);
          d1 = (applianceList.length);
          applianceList.forEach((item, index) => {
            this.firstAccDevList.push(item + " : " + percentageList[index] + " % ");
          });
        }
        if (this.acclrDeviceDetailsData.twentyPercentList.length > 0) {
          let percentageList = this.acclrDeviceDetailsData.twentyPercentList.map(item => item.percentage);
          let applianceList = this.acclrDeviceDetailsData.twentyPercentList.map(item => item.applianceName);
          d2 = (applianceList.length);
          applianceList.forEach((item, index) => {
            this.firstAccDevList.push(item + " : " + percentageList[index] + " % ");
          });
        }
        this.barChartData2.push(String(d1 + d2));
      } else {
        this.barChartData2.push(String(0));
      }

      // keys - 20 to 40 percentage data with appliance names.
      if (this.acclrDeviceDetailsData.thirtyPercentList.length > 0 || this.acclrDeviceDetailsData.fortyPercentList.length > 0) {
        let d1 = 0, d2 = 0;
        if (this.acclrDeviceDetailsData.thirtyPercentList.length > 0) {
          let percentageList = this.acclrDeviceDetailsData.thirtyPercentList.map(item => item.percentage);
          let applianceList = this.acclrDeviceDetailsData.thirtyPercentList.map(item => item.applianceName);
          d1 = (applianceList.length);
          applianceList.forEach((item, index) => {
            this.secondAccDevList.push(item + " : " + percentageList[index] + " % ");
          });
        }
        if (this.acclrDeviceDetailsData.fortyPercentList.length > 0) {
          let percentageList = this.acclrDeviceDetailsData.fortyPercentList.map(item => item.percentage);
          let applianceList = this.acclrDeviceDetailsData.fortyPercentList.map(item => item.applianceName);
          d2 = (applianceList.length);
          applianceList.forEach((item, index) => {
            this.secondAccDevList.push(item + " : " + percentageList[index] + " % ");
          });
        }
        this.barChartData2.push(String(d1 + d2));
      } else {
        this.barChartData2.push(String(0));
      }

      // keys - 40 to 60 percentage data with appliance names.
      if (this.acclrDeviceDetailsData.fiftyPercentList.length > 0 || this.acclrDeviceDetailsData.sixtyPercentList.length > 0) {
        let d1 = 0, d2 = 0;
        if (this.acclrDeviceDetailsData.fiftyPercentList.length > 0) {
          let percentageList = this.acclrDeviceDetailsData.fiftyPercentList.map(item => item.percentage);
          let applianceList = this.acclrDeviceDetailsData.fiftyPercentList.map(item => item.applianceName);
          d1 = (applianceList.length);
          applianceList.forEach((item, index) => {
            this.thirdAccDevList.push(item + " : " + percentageList[index] + " % ");
          });
        }
        if (this.acclrDeviceDetailsData.sixtyPercentList.length > 0) {
          let percentageList = this.acclrDeviceDetailsData.sixtyPercentList.map(item => item.percentage);
          let applianceList = this.acclrDeviceDetailsData.sixtyPercentList.map(item => item.applianceName);
          d2 = (applianceList.length);
          applianceList.forEach((item, index) => {
            this.thirdAccDevList.push(item + " : " + percentageList[index] + " % ");
          });
        }
        this.barChartData2.push(String(d1 + d2));
      } else {
        this.barChartData2.push(String(0));
      }

      // keys - 60 to 80 percentage data with appliance names.
      if (this.acclrDeviceDetailsData.seventyPercentList.length > 0 || this.acclrDeviceDetailsData.eightyPercentList.length > 0) {
        let d1 = 0, d2 = 0;
        if (this.acclrDeviceDetailsData.seventyPercentList.length > 0) {
          let percentageList = this.acclrDeviceDetailsData.seventyPercentList.map(item => item.percentage);
          let applianceList = this.acclrDeviceDetailsData.seventyPercentList.map(item => item.applianceName);
          d1 = (applianceList.length);
          applianceList.forEach((item, index) => {
            this.fourthAccDevList.push(item + " : " + percentageList[index] + " % ");
          });
        }
        if (this.acclrDeviceDetailsData.eightyPercentList.length > 0) {
          let percentageList = this.acclrDeviceDetailsData.eightyPercentList.map(item => item.percentage);
          let applianceList = this.acclrDeviceDetailsData.eightyPercentList.map(item => item.applianceName);
          d2 = (applianceList.length);
          applianceList.forEach((item, index) => {
            this.fourthAccDevList.push(item + " : " + percentageList[index] + " % ");
          });
        }
        this.barChartData2.push(String(d1 + d2));
      } else {
        this.barChartData2.push(String(0));
      }

      // keys - 80 to 100 percentage data with appliance names.
      if (this.acclrDeviceDetailsData.ninetyPercentList.length > 0 || this.acclrDeviceDetailsData.hundredPercentList.length > 0) {
        let d1 = 0, d2 = 0;
        if (this.acclrDeviceDetailsData.ninetyPercentList.length > 0) {
          let percentageList = this.acclrDeviceDetailsData.ninetyPercentList.map(item => item.percentage);
          let applianceList = this.acclrDeviceDetailsData.ninetyPercentList.map(item => item.applianceName);
          d1 = (applianceList.length);
          applianceList.forEach((item, index) => {
            this.fifthAccDevList.push(item + " : " + percentageList[index] + " % ");
          });
        }
        if (this.acclrDeviceDetailsData.hundredPercentList.length > 0) {
          let percentageList = this.acclrDeviceDetailsData.hundredPercentList.map(item => item.percentage);
          let applianceList = this.acclrDeviceDetailsData.hundredPercentList.map(item => item.applianceName);
          d2 = (applianceList.length);
          applianceList.forEach((item, index) => {
            this.fifthAccDevList.push(item + " : " + percentageList[index] + " % ");
          });
        }
        this.barChartData2.push(String(d1 + d2));
      } else {
        this.barChartData2.push(String(0));
      }
    }
    if (this.acclrDeviceDetailsData.tenPercentList.length <= 0 &&
      this.acclrDeviceDetailsData.twentyPercentList.length <= 0 &&
      this.acclrDeviceDetailsData.thirtyPercentList.length <= 0 &&
      this.acclrDeviceDetailsData.fortyPercentList.length <= 0 &&
      this.acclrDeviceDetailsData.fiftyPercentList.length <= 0 &&
      this.acclrDeviceDetailsData.sixtyPercentList.length <= 0 &&
      this.acclrDeviceDetailsData.seventyPercentList.length <= 0 &&
      this.acclrDeviceDetailsData.eightyPercentList.length <= 0 &&
      this.acclrDeviceDetailsData.ninetyPercentList.length <= 0 &&
      this.acclrDeviceDetailsData.hundredPercentList.length <= 0) {
      this.isNoAccelerationAvailable = true;
    }
  }
  //Acceleration Device bar chart options.
  public barChartOptionsAccDev: any = {
    scaleShowVerticalLines: false,
    responsive: true,
    legend: {
      display: true,
    },
    scales: {
      yAxes: [{
        ticks: {
          min: 0, // it is for ignoring negative step.
          beginAtZero: true,
          callback: function (value, index, values) {
            if (Math.floor(value) === value) {
              return value;
            }
          }
        },
        scaleLabel: {
          display: true,
          labelString: 'No. of Appliances',
          fontStyle: 'normal'
        }
      }],
      xAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'Acceleration Devices Percentage',
          fontStyle: 'normal'
        }
      }],
    },
    tooltips: {
      callbacks: {
        label: (tooltipItem, data) => {
          return '';
        },
        title: (items, data) => {
          let graphData: any;
          if (items[0].index == 0) {
            if (this.firstAccDevList.length > 0) {
              graphData = this.firstAccDevList;
            }
          }
          else if (items[0].index == 1) {
            if (this.secondAccDevList.length > 0) {
              graphData = this.secondAccDevList;
            }
          }
          else if (items[0].index == 2) {
            if (this.thirdAccDevList.length > 0) {
              graphData = this.thirdAccDevList;
            }
          }
          else if (items[0].index == 3) {
            if (this.fourthAccDevList.length > 0) {
              graphData = this.fourthAccDevList;
            }
          }
          else if (items[0].index == 4) {
            if (this.fifthAccDevList.length > 0) {
              graphData = this.fifthAccDevList;
            }
          }
          return graphData;
        }
      }
    }
  };


  createSSLContextsBarGraph() {
    if (this.contextDetailsData != null) {

      // keys - 0 to 20 percentage data with appliance names.
      if (this.contextDetailsData.tenPercentList.length > 0 || this.contextDetailsData.twentyPercentList.length > 0) {
        let d1 = 0, d2 = 0;
        if (this.contextDetailsData.tenPercentList.length > 0) {
          let percentageList = this.contextDetailsData.tenPercentList.map(item => item.percentage);
          let applianceList = this.contextDetailsData.tenPercentList.map(item => item.applianceName);
          d1 = (applianceList.length);
          applianceList.forEach((item, index) => {
            this.firstSSLCtxtList.push(item + " : " + percentageList[index] + " % ");
          });
        }
        if (this.contextDetailsData.twentyPercentList.length > 0) {
          let percentageList = this.contextDetailsData.twentyPercentList.map(item => item.percentage);
          let applianceList = this.contextDetailsData.twentyPercentList.map(item => item.applianceName);
          d2 = (applianceList.length);
          applianceList.forEach((item, index) => {
            this.firstSSLCtxtList.push(item + " : " + percentageList[index] + " % ");
          });
        }
        this.barChartData3.push(String(d1 + d2));
      } else {
        this.barChartData3.push(String(0));
      }

      // keys - 20 to 40 percentage data with appliance names.
      if (this.contextDetailsData.thirtyPercentList.length > 0 || this.contextDetailsData.fortyPercentList.length > 0) {
        let d1 = 0, d2 = 0;
        if (this.contextDetailsData.thirtyPercentList.length > 0) {
          let percentageList = this.contextDetailsData.thirtyPercentList.map(item => item.percentage);
          let applianceList = this.contextDetailsData.thirtyPercentList.map(item => item.applianceName);
          d1 = (applianceList.length);
          applianceList.forEach((item, index) => {
            this.seconSSLCtxtList.push(item + " : " + percentageList[index] + " % ");
          });
        }
        if (this.contextDetailsData.fortyPercentList.length > 0) {
          let percentageList = this.contextDetailsData.fortyPercentList.map(item => item.percentage);
          let applianceList = this.contextDetailsData.fortyPercentList.map(item => item.applianceName);
          d2 = (applianceList.length);
          applianceList.forEach((item, index) => {
            this.seconSSLCtxtList.push(item + " : " + percentageList[index] + " % ");
          });
        }
        this.barChartData3.push(String(d1 + d2));
      } else {
        this.barChartData3.push(String(0));
      }

      // keys - 40 to 60 percentage data with appliance names.
      if (this.contextDetailsData.fiftyPercentList.length > 0 || this.contextDetailsData.sixtyPercentList.length > 0) {
        let d1 = 0, d2 = 0;
        if (this.contextDetailsData.fiftyPercentList.length > 0) {
          let percentageList = this.contextDetailsData.fiftyPercentList.map(item => item.percentage);
          let applianceList = this.contextDetailsData.fiftyPercentList.map(item => item.applianceName);
          d1 = (applianceList.length);
          applianceList.forEach((item, index) => {
            this.thirdSSLCtxtList.push(item + " : " + percentageList[index] + " % ");
          });
        }
        if (this.contextDetailsData.sixtyPercentList.length > 0) {
          let percentageList = this.contextDetailsData.sixtyPercentList.map(item => item.percentage);
          let applianceList = this.contextDetailsData.sixtyPercentList.map(item => item.applianceName);
          d2 = (applianceList.length);
          applianceList.forEach((item, index) => {
            this.thirdSSLCtxtList.push(item + " : " + percentageList[index] + " % ");
          });
        }
        this.barChartData3.push(String(d1 + d2));
      } else {
        this.barChartData3.push(String(0));
      }

      // keys - 60 to 80 percentage data with appliance names.
      if (this.contextDetailsData.seventyPercentList.length > 0 || this.contextDetailsData.eightyPercentList.length > 0) {
        let d1 = 0, d2 = 0;
        if (this.contextDetailsData.seventyPercentList.length > 0) {
          let percentageList = this.contextDetailsData.seventyPercentList.map(item => item.percentage);
          let applianceList = this.contextDetailsData.seventyPercentList.map(item => item.applianceName);
          d1 = (applianceList.length);
          applianceList.forEach((item, index) => {
            this.fourthSSLCtxtList.push(item + " : " + percentageList[index] + " % ");
          });
        }
        if (this.contextDetailsData.eightyPercentList.length > 0) {
          let percentageList = this.contextDetailsData.eightyPercentList.map(item => item.percentage);
          let applianceList = this.contextDetailsData.eightyPercentList.map(item => item.applianceName);
          d2 = (applianceList.length);
          applianceList.forEach((item, index) => {
            this.fourthSSLCtxtList.push(item + " : " + percentageList[index] + " % ");
          });
        }
        this.barChartData3.push(String(d1 + d2));
      } else {
        this.barChartData3.push(String(0));
      }

      // keys - 80 to 100 percentage data with appliance names.
      if (this.contextDetailsData.ninetyPercentList.length > 0 || this.contextDetailsData.hundredPercentList.length > 0) {
        let d1 = 0, d2 = 0;
        if (this.contextDetailsData.ninetyPercentList.length > 0) {
          let percentageList = this.contextDetailsData.ninetyPercentList.map(item => item.percentage);
          let applianceList = this.contextDetailsData.ninetyPercentList.map(item => item.applianceName);
          d1 = (applianceList.length);
          applianceList.forEach((item, index) => {
            this.fifthSSLCtxtList.push(item + " : " + percentageList[index] + " % ");
          });
        }
        if (this.contextDetailsData.hundredPercentList.length > 0) {
          let percentageList = this.contextDetailsData.hundredPercentList.map(item => item.percentage);
          let applianceList = this.contextDetailsData.hundredPercentList.map(item => item.applianceName);
          d2 = (applianceList.length);
          applianceList.forEach((item, index) => {
            this.fifthSSLCtxtList.push(item + " : " + percentageList[index] + " % ");
          });
        }
        this.barChartData3.push(String(d1 + d2));
      } else {
        this.barChartData3.push(String(0));
      }
    }
    if (this.contextDetailsData.tenPercentList.length <= 0 &&
      this.contextDetailsData.twentyPercentList.length <= 0 &&
      this.contextDetailsData.thirtyPercentList.length <= 0 &&
      this.contextDetailsData.fortyPercentList.length <= 0 &&
      this.contextDetailsData.fiftyPercentList.length <= 0 &&
      this.contextDetailsData.sixtyPercentList.length <= 0 &&
      this.contextDetailsData.seventyPercentList.length <= 0 &&
      this.contextDetailsData.eightyPercentList.length <= 0 &&
      this.contextDetailsData.ninetyPercentList.length <= 0 &&
      this.contextDetailsData.hundredPercentList.length <= 0
    ) {
      this.isNoSSLContextAvailable = true;
    }
  }

  //SSL Contexts bar chart options.
  public barChartOptionsSSLContexts: any = {
    scaleShowVerticalLines: false,
    responsive: true,
    legend: {
      display: true,
    },
    scales: {
      yAxes: [{
        ticks: {
          min: 0, // it is for ignoring negative step.
          beginAtZero: true,
          callback: function (value, index, values) {
            if (Math.floor(value) === value) {
              return value;
            }
          }
        },
        scaleLabel: {
          display: true,
          labelString: 'No. of Appliances',
          fontStyle: 'normal'
        }
      }],
      xAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'SSL Contexts Percentage',
          fontStyle: 'normal'
        }
      }],
    },
    tooltips: {
      callbacks: {
        label: (tooltipItem, data) => {
          return '';
        },
        title: (items, data) => {
          let graphData: any;
          if (items[0].index == 0) {
            if (this.firstSSLCtxtList.length > 0) {
              graphData = this.firstSSLCtxtList;
            }
          }
          else if (items[0].index == 1) {
            if (this.seconSSLCtxtList.length > 0) {
              graphData = this.seconSSLCtxtList;
            }
          }
          else if (items[0].index == 2) {
            if (this.thirdSSLCtxtList.length > 0) {
              graphData = this.thirdSSLCtxtList;
            }
          }
          else if (items[0].index == 3) {
            if (this.fourthSSLCtxtList.length > 0) {
              graphData = this.fourthSSLCtxtList;
            }
          }
          else if (items[0].index == 4) {
            if (this.fifthSSLCtxtList.length > 0) {
              graphData = this.fifthSSLCtxtList;
            }
          }
          return graphData;
        }
      }
    }
  };

  public barChartType1: string = 'bar';
  public barChartLegend1: boolean = false;
  public barChartLabels1: string[] = ['0-20', '20-40', '40-60', '60-80', '80-100'];
  public mycolors1: Array<Color> = [
    {
      backgroundColor: ['rgb(0 , 179, 30)', 'rgb(84, 198, 233)', 'rgb(229, 229, 157)', 'rgb(237, 123, 56)', 'rgb(247, 113, 131)'],
    }
  ];
  public barChartData1: any[] = [];
  public barChartData2: any[] = [];
  public barChartData3: any[] = [];

  //Status Donut chart 
  public doughnutChartData1: number[] = [];
  public doughnutChartLabels1: string[] = [];
  public mycolorsDC1 = [
    {
      backgroundColor: [],
      hoverBackgroundColor: [],
    }
  ];


  //FIPS Status Donut chart 
  public doughnutChartData2: number[] = [];
  public doughnutChartLabels2: string[] = []
  public mycolorsDC2 = [
    {
      'backgroundColor': [],
      'hoverBackgroundColor': []
    }];


  getInProgressActivity() {
    this.getProgressActivities = this._partitionManagementService.getInProgressActivities().subscribe(
      res => {
        this.inProgressActivityList = res
      }
    );
    this.getTimeIntervalData();
  }

  private getTimeIntervalData(): void {
    this.timer = Observable.timer(15000).first().subscribe(() => this.getInProgressActivity());

  }
  public ngOnDestroy(): void {
    if (this.timer) {
      this.timer.unsubscribe();
    }
    // if (this.graphTimer) {
    //   this.graphTimer.unsubscribe();
    // }
    // if (this.graphSubsTimer) {
    //   this.graphSubsTimer.unsubscribe();
    // }
  }
}



