import { Component, OnInit, ViewChild } from '@angular/core';
import { PartitionManagementService } from './../../../../services/partitionmanagement/partitionmanagement.service';
import { ActivatedRoute } from '@angular/router';
import { MonitorConfigComponent } from './../../partitionmanagement/monitor-config/monitor-config.component'
import { MonitorStatsComponent } from './../../partitionmanagement/monitor-stats/monitor-stats.component';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { AnonymousSubscription } from "rxjs/Subscription";
import { Observable } from "rxjs/Observable";
import { forkJoin } from "rxjs/observable/forkJoin";

var moment = require("moment");
var momentDurationFormatSetup = require("moment-duration-format");
declare var $;
@Component({
  selector: 'app-partitionhostvm',
  templateUrl: './partitionhostvm.component.html',
  styleUrls: ['./partitionhostvm.component.css']
})
export class PartitionhostvmComponent implements OnInit {
  @ViewChild('monitorConfig')
  monitorConfig: MonitorConfigComponent;
  @ViewChild('monitorStats')
  monitorStats: MonitorStatsComponent;
  @ViewChild('partitionMsgModel') partitionMsgModel: ModalDirective;
  partitionId: string;
  partitionName: string;
  appId: string;
  appName: string;
  ip: string;
  tab: string;
  classStatic: string;
  classServer: string;
  showtime: any;
  time: any;
  maxKeys: any;
  fipsState: any;
  totalSSLContexts: any;
  sessionCount: any;
  availUsers: any;
  minPasswordLength: any;
  occTokenKeys: any;
  keyExport: any;
  exportWithUserKeys: any;
  mValue: any;
  occSslCtxs: any;
  occSessionKeys: any;
  maximumUsers: any;
  maxPswdLength: any;
  maximumAcclrDevCount: any;
  certAuth: any;
  mcoBackupRestore: any;
  twoKeyBackup: any;
  nodeId: any;
  cloningMethod: any;
  kekMethod: any;
  blockDeleteUserWithKeys: any;
  keyImport: any;
  pcoFixedKeyFingerPrint: any;
  auditLogStatus: any;
  status: any;
  nValue: any;
  mValuebackupByCO: any;
  mValuecloning: any;
  mValueuserMgmt: any;

  backChannelPort: any;
  mainChannelPort: any;
  channelVersion: any;
  utilChannelPort: any;

  partitionModel: any = [];   //Partition Info Tab

  eth0LinkStatus: any;
  eth1LinkStatus: any;
  partitionInfo: any;
  partitionStats: any;
  partitionCavServerConfig: any;
  partitionCavServerStats: any;
  partitionNetworkStats: any;
  vmStatus: any;
  diskFreeSpace: any;
  diskTotalSpace: any;
  cavServerStatus: any;
  driverStatus: any;
  hoursTime: any;
  minTime: any;
  secTime: any;
  processCount: any;
  ramStatsTotal: any;
  ramStatsFree: any;
  ramStatsUsed: any;
  swapStatsTotal: any;
  swapStatsFree: any;
  swapStatsUsed: any;
  txQueueHead: any;
  txQueueTail: any;
  rxQueueHead: any;
  rxQueueTail: any;
  firmwareHead: any;
  firmwareTail: any;
  driverHead: any;
  driverTail: any;

  majorVersion: any;
  minorVersion: any;
  connectedServers: any;
  reconnectAttempts: any;
  numWorkers: any;
  activeConns: any;
  numClients: any;
  numMgmtUtils: any;
  heartbeatDisconnection: any;
  activeKeys: any;
  tombstoneKeys: any;
  keysReloadCnt: any;
  uptimeInSecs: any;
  serverList: any = [];

  dhcp: any;
  dhcpStatus: any;
  hostname: any;
  ipAddress: any;
  ipStatus: any;
  subnetAddress: any;
  subnetStatus: any;
  macStatic: any;
  macAddress: any;
  macStatus: any;
  gateway: any;
  gatewayStatus: any;
  vlan: any;
  dhcp1: any;
  dhcpStatus1: any;
  hostname1: any;
  ipAddress1: any;
  ipStatus1: any;
  subnetAddress1: any;
  subnetStatus1: any;
  macStatic1: any;
  macAddress1: any;
  macStatus1: any;
  gateway1: any;
  gatewayStatus1: any;
  vlan1: any;

  dnsServers: any = [];
  searchDomainNames: any = [];
  staticIpToHostConfig: any = [];
  applianceId: any = '';
  applianceName: any = '';
  applianceIp: any = '';
  partitionDetails: any = {};
  errorMessage: string = '';
  loading: boolean = true;
  gaugeColor: any;
  gaugeColor2: any;
  gaugeColor3: any;
  authenticationDualFactor
  constructor(
    private _activatedRoute: ActivatedRoute,
    private _partitionManagementService: PartitionManagementService) { } //Partition Info Tab

  ngOnInit() {
    this.partitionId = "";
    this.applianceId = "";
    this.applianceName = '';
    this.applianceIp = '';
    this._activatedRoute.params.subscribe(params => {
      this.partitionId = params['partitionId'];
      this.partitionName = params['partitionName'];
      this.applianceId = params['appId'];
      this.applianceName = params['appName'];
      this.applianceIp = params['ip'];
    });
    this.partitionDetails['partitionId'] = this.partitionId;
    this.partitionDetails['partitionName'] = this.partitionName;
    this.partitionDetails['applianceId'] = this.applianceId;
    this.partitionDetails['applianceName'] = this.applianceName;
    this.partitionDetails['ipAddress'] = this.applianceIp;
    // this.loading = true;

    let partitionInfoData = this._partitionManagementService.getPartitionInfoData(this.partitionId);
    let partitionCavServerConfigData = this._partitionManagementService.getPartitionCavServerConfigData(this.partitionId);
    let partitionStats = this._partitionManagementService.getPartitionStats(this.partitionId);
    let partitionCavServerStatsData = this._partitionManagementService.getPartitionCavServerStatsData(this.partitionId);
    let partitionNetworkStats = this._partitionManagementService.getPartitionNetworkStats(this.partitionId);
    forkJoin([partitionInfoData, partitionCavServerConfigData, partitionStats, partitionCavServerStatsData, partitionNetworkStats]).subscribe(result => {
      this.setPartitionInfoData(result[0]);
      this.setPartitionCavServerConfigData(result[1]);
      this.setPartitionStats(result[2]);
      this.setPartitionCavServerStatsData(result[3]);
      this.setPartitionNetworkStats(result[4]);
    });
  }

  setPartitionInfoData(res) {
    this.loading = false;
    if (res.code == "200") {
      if (res.message != '') {
        this.partitionDetails['credentialSaved'] = res.credentialSaved;
        this.partitionInfo = JSON.parse(res.message);
        // check dual factor authentication
        if(res.applianceDualFactorInitialized){
          this.authenticationDualFactor =  true;
        }else{
          this.authenticationDualFactor =  false
        }
        if (this.partitionInfo != null) {

          if (this.partitionInfo.mcoBackupRestore != null) {
            if (this.partitionInfo.mcoBackupRestore == false) {
              this.mcoBackupRestore = "Disabled";
            } else if (this.partitionInfo.mcoBackupRestore == true) {
              this.mcoBackupRestore = "Enabled";
            }
          }

          if (this.partitionInfo.twoKeyBackup != null) {
            this.twoKeyBackup = this.partitionInfo.twoKeyBackup;
          }

          if (this.partitionInfo.nodeId != null) {
            this.nodeId = this.partitionInfo.nodeId;
          }

          if (this.partitionInfo.cloningMethod != null) {
            this.cloningMethod = this.partitionInfo.cloningMethod;
          }

          if (this.partitionInfo.kekMethod != null) {
            if (this.partitionInfo.kekMethod == 0) {
              this.kekMethod = "ECC";
            } else if (this.partitionInfo.kekMethod == 1) {
              this.kekMethod = "RSA";
            }
          }

          if (this.partitionInfo.blockDeleteUserWithKeys != null) {
            this.blockDeleteUserWithKeys = this.partitionInfo.blockDeleteUserWithKeys;
          }

          if (this.partitionInfo.keyImport != null) {
            this.keyImport = this.partitionInfo.keyImport;
          }

          if (this.partitionInfo.pcoFixedKeyFingerPrint != null) {
            this.pcoFixedKeyFingerPrint = this.partitionInfo.pcoFixedKeyFingerPrint;
          }

          if (this.partitionInfo.auditLogStatus != null) {
            this.auditLogStatus = this.partitionInfo.auditLogStatus;
          }

          if (this.partitionInfo.status != null) {
            this.status = this.partitionInfo.status;
          }

          if (this.partitionInfo.nValue != null) {
            this.nValue = this.partitionInfo.nValue;
          }

          if (this.partitionInfo.maxKeys != null) {
            this.maxKeys = this.partitionInfo.maxKeys;
          }

          if (this.partitionInfo.fipsState != null) {
            this.fipsState = this.partitionInfo.fipsState;
          }

          if (this.partitionInfo.totalSslCtxs != null) {
            this.totalSSLContexts = this.partitionInfo.totalSslCtxs;
          }

          if (this.partitionInfo.sessionCount != null) {
            this.sessionCount = this.partitionInfo.sessionCount;
          }

          if (this.partitionInfo.availableUsers != null) {
            this.availUsers = this.partitionInfo.availableUsers;
          }

          if (this.partitionInfo.minPswdLen != null) {
            this.minPasswordLength = this.partitionInfo.minPswdLen;
          }

          if (this.partitionInfo.occupiedTokenKeys != null) {
            this.occTokenKeys = this.partitionInfo.occupiedTokenKeys;
          }

          if (this.partitionInfo.keyExport != null) {
            this.keyExport = this.partitionInfo.keyExport;
          }

          if (this.partitionInfo["exportWithUserKeys(OtherThanKEK)"] != null) {
            this.exportWithUserKeys = this.partitionInfo["exportWithUserKeys(OtherThanKEK)"];
          }

          if (this.partitionInfo["mValue[backupByCO]"] != null) {
            this.mValuebackupByCO = this.partitionInfo["mValue[backupByCO]"];
          }

          if (this.partitionInfo["mValue[cloning]"] != null) {
            this.mValuecloning = this.partitionInfo["mValue[cloning]"];
          }

          if (this.partitionInfo["mValue[userMgmt]"] != null) {
            this.mValueuserMgmt = this.partitionInfo["mValue[userMgmt]"];
          }

          if (this.partitionInfo["mValue[miscCO]"] != null) {
            this.mValue = this.partitionInfo["mValue[miscCO]"];
          }

          if (this.partitionInfo.occupiedSslCtxs != null) {
            this.occSslCtxs = this.partitionInfo.occupiedSslCtxs;
          }

          if (this.partitionInfo.occupiedSessionKeys != null) {
            this.occSessionKeys = this.partitionInfo.occupiedSessionKeys;
          }

          if (this.partitionInfo.maxUsers != null) {
            this.maximumUsers = this.partitionInfo.maxUsers;
          }

          if (this.partitionInfo.maxPswdLen != null) {
            this.maxPswdLength = this.partitionInfo.maxPswdLen;
          }

          if (this.partitionInfo.maxAcclrDevCount != null) {
            this.maximumAcclrDevCount = this.partitionInfo.maxAcclrDevCount;
          }

          if (this.partitionInfo.certAuth != null) {
            this.certAuth = this.partitionInfo.certAuth;
          }
        }
      }
    } else {
      this.errorMessage = res.errorMessage;
      this.partitionMsgModel.show();
    }
  }

  setPartitionCavServerConfigData(res) {
    if (res.responseCode == "200") {
      if (res.responseMessage != null && res.responseMessage != '') {
        this.partitionCavServerConfig = JSON.parse(res.responseMessage);
        if (this.partitionCavServerConfig != null) {

          if (this.partitionCavServerConfig.backChannelPort != null) {
            this.backChannelPort = this.partitionCavServerConfig.backChannelPort;
          }

          if (this.partitionCavServerConfig.mainChannelPort != null) {
            this.mainChannelPort = this.partitionCavServerConfig.mainChannelPort;
          }

          if (this.partitionCavServerConfig.channelVersion != null) {
            this.channelVersion = this.partitionCavServerConfig.channelVersion;
          }

          if (this.partitionCavServerConfig.utilChannelPort != null) {
            this.utilChannelPort = this.partitionCavServerConfig.utilChannelPort;
          }

        }
      }
    }
  }

  setPartitionStats(res) {
    if (res.message != null && res.message != '') {
      this.partitionStats = JSON.parse(res.message);
      if (this.partitionStats != null) {

        if (this.partitionStats.vmstats != null) {

          if (this.partitionStats.vmstats["linkStatus(eth0)"] != null) {
            if (this.partitionStats.vmstats["linkStatus(eth0)"] == 1) {
              this.eth0LinkStatus = "Up";
            } else if (this.partitionStats.vmstats["linkStatus(eth0)"] == 0) {
              this.eth0LinkStatus = "Down";
            }
          }

          if (this.partitionStats.vmstats["linkStatus(eth1)"] != null) {
            if (this.partitionStats.vmstats["linkStatus(eth1)"] == 1) {
              this.eth1LinkStatus = "Up";
            } else if (this.partitionStats.vmstats["linkStatus(eth1)"] == 0) {
              this.eth1LinkStatus = "Down";
            }
          }
          if (this.partitionStats.vmstats["diskSpace(mb)"] != null
            && this.partitionStats.vmstats["diskSpace(mb)"] != undefined) {
            if (this.partitionStats.vmstats["diskSpace(mb)"].total != null) {
              this.diskTotalSpace = this.partitionStats.vmstats["diskSpace(mb)"].total;
            }

            if (this.partitionStats.vmstats["diskSpace(mb)"].free != null) {
              this.diskFreeSpace = this.partitionStats.vmstats["diskSpace(mb)"].free;
            }
          }

          if (this.partitionStats.vmstats.cavServerStatus != null) {
            if (this.partitionStats.vmstats.cavServerStatus == 1) {
              this.cavServerStatus = "Up";
            } else if (this.partitionStats.vmstats.cavServerStatus == 0) {
              this.cavServerStatus = "Down";
            }
          }

          if (this.partitionStats.vmstats.driverStatus != null) {
            if (this.partitionStats.vmstats.driverStatus == 1) {
              this.driverStatus = "Secure State";
            } else if (this.partitionStats.vmstats.driverStatus == 0) {
              this.driverStatus = "Insecure State";
            }
          }
         
          if (this.partitionStats.vmstats.systemUpTime != null) {
            if (this.partitionStats.vmstats.systemUpTime.hours != null) {
              this.hoursTime = this.partitionStats.vmstats.systemUpTime.hours;
            }
          }

          if (this.partitionStats.vmstats.systemUpTime != null) {
            if (this.partitionStats.vmstats.systemUpTime.minutes != null) {
              this.minTime = this.partitionStats.vmstats.systemUpTime.minutes;
            }
          }

          if (this.partitionStats.vmstats.systemUpTime != null) {
            if (this.partitionStats.vmstats.systemUpTime.seconds != null) {
              this.secTime = this.partitionStats.vmstats.systemUpTime.seconds;
            }
            this.time = ((this.minTime * 60) + ((this.hoursTime * 3600)) + this.secTime);
            this.showtime = moment.duration(this.time, "seconds").format("d [days] h [hours] m [minutes] s [seconds]");
          }

          if (this.partitionStats.vmstats.txQueue != null) {
            if (this.partitionStats.vmstats.txQueue.tdh != null) {
              this.txQueueHead = this.partitionStats.vmstats.txQueue.tdh;
            }
            if (this.partitionStats.vmstats.txQueue.tdt != null) {
              this.txQueueTail = this.partitionStats.vmstats.txQueue.tdt;
            }
          }

          if (this.partitionStats.vmstats.rxQueue != null) {
            if (this.partitionStats.vmstats.rxQueue.rdh != null) {
              this.rxQueueHead = this.partitionStats.vmstats.rxQueue.rdh;
            }
            if (this.partitionStats.vmstats.rxQueue.rdt != null) {
              this.rxQueueTail = this.partitionStats.vmstats.rxQueue.rdt;
            }
          }

          if (this.partitionStats.vmstats.fwReqIdQueue != null) {
            if (this.partitionStats.vmstats.fwReqIdQueue.head != null) {
              this.firmwareHead = this.partitionStats.vmstats.fwReqIdQueue.head;
            }
            if (this.partitionStats.vmstats.fwReqIdQueue.tail != null) {
              this.firmwareTail = this.partitionStats.vmstats.fwReqIdQueue.tail;
            }
          }

          if (this.partitionStats.vmstats.drvReqIdQueue != null) {
            if (this.partitionStats.vmstats.drvReqIdQueue.head != null) {
              this.driverHead = this.partitionStats.vmstats.drvReqIdQueue.head;
            }
            if (this.partitionStats.vmstats.drvReqIdQueue.tail != null) {
              this.driverTail = this.partitionStats.vmstats.drvReqIdQueue.tail;
            }
          }

          if (this.partitionStats.vmstats.processCount != null) {
            this.processCount = this.partitionStats.vmstats.processCount;
          }

          if (this.partitionStats.vmstats["ramStats(mb)"] != null) {
            if (this.partitionStats.vmstats["ramStats(mb)"].total != null) {
              this.ramStatsTotal = this.partitionStats.vmstats["ramStats(mb)"].total;
            }
          }

          if (this.partitionStats.vmstats["ramStats(mb)"] != null) {
            if (this.partitionStats.vmstats["ramStats(mb)"].free != null) {
              this.ramStatsFree = this.partitionStats.vmstats["ramStats(mb)"].free;
            }
          }

          if (this.ramStatsTotal != null && this.ramStatsFree != null) {
            this.ramStatsUsed = this.ramStatsTotal - this.ramStatsFree;
          }

          if (this.ramStatsTotal != null && this.ramStatsUsed != null) {
            this.data2 = (parseInt(this.ramStatsUsed) / parseInt(this.ramStatsTotal)) * 100;
            this.gaugeValue2= Math.round(this.data2 * 100) / 100;
            } 

            if(this.gaugeValue2 <= 30){
              this.gaugeColor2 = 'rgb(0,179,30)';
              }
            else if(this.gaugeValue2 > 30 && this.gaugeValue2 <= 60)  {
              this.gaugeColor2 = 'rgb(230,191,0)';
            }
            else if(this.gaugeValue2 > 60)  {
              this.gaugeColor2 = 'rgb(204,0,0)';
            }

          if (this.partitionStats.vmstats["swapStats(mb)"] != null) {
            if (this.partitionStats.vmstats["swapStats(mb)"].total != null) {
              this.swapStatsTotal = this.partitionStats.vmstats["swapStats(mb)"].total;
            }
          }

          if (this.partitionStats.vmstats["swapStats(mb)"] != null) {
            if (this.partitionStats.vmstats["swapStats(mb)"].free != null) {
              this.swapStatsFree = this.partitionStats.vmstats["swapStats(mb)"].free;
            }
          }

          if (this.swapStatsTotal != null && this.swapStatsFree != null) {
            this.swapStatsUsed = this.swapStatsTotal - this.swapStatsFree;
          }

          if (this.swapStatsTotal != null && this.swapStatsUsed != null) {
            this.data3  = (parseInt(this.swapStatsUsed) / parseInt(this.swapStatsTotal)) * 100;
            if(isNaN(this.data3 )){
              this.gaugeValue3=0;
            }else{
              this.gaugeValue3= Math.round(this.data3 * 100) / 100;
            }   
          }

          if(this.gaugeValue3 <= 30){
            this.gaugeColor3 = 'rgb(0,179,30)';
            }
          else if(this.gaugeValue3 > 30 && this.gaugeValue3 <= 60)  {
            this.gaugeColor3 = 'rgb(230,191,0)';
          }
          else if(this.gaugeValue3 > 60)  {
            this.gaugeColor3 = 'rgb(204,0,0)';
          }

          if (this.partitionStats.vmstats["cpuUsage(%)"] != null) {
            this.data = this.partitionStats.vmstats["cpuUsage(%)"];
            this.gaugeValue= Math.round(this.data * 100) / 100;
          }

          if(this.gaugeValue <= 30){
            this.gaugeColor = 'rgb(0,179,30)';
            }
          else if(this.gaugeValue > 30 && this.gaugeValue <= 60)  {
            this.gaugeColor = 'rgb(230,191,0)';
          }
          else if(this.gaugeValue > 60)  {
            this.gaugeColor = 'rgb(204,0,0)';
          }
        }

        if (this.partitionStats.vmStatus != null) {
          if (this.partitionStats.vmStatus == 1) {
            this.vmStatus = "Up";
          } else if (this.partitionStats.vmStatus == 0) {
            this.vmStatus = "Down";
          }
        }
      }
    }
  }

  setPartitionCavServerStatsData(res) {
    if (res.responseCode == "200") {
      if (res.responseMessage != null && res.responseMessage != '') {
        this.partitionCavServerStats = JSON.parse(res.responseMessage);
        if (this.partitionCavServerStats != null) {

          if (this.partitionCavServerStats.majorVersion != null) {
            this.majorVersion = this.partitionCavServerStats.majorVersion;
          }

          if (this.partitionCavServerStats.minorVersion != null) {
            this.minorVersion = this.partitionCavServerStats.minorVersion;
          }

          if (this.partitionCavServerStats.connectedServers != null) {
            this.connectedServers = this.partitionCavServerStats.connectedServers;
          }

          if (this.partitionCavServerStats.reconnectAttempts != null) {
            this.reconnectAttempts = this.partitionCavServerStats.reconnectAttempts;
          }

          if (this.partitionCavServerStats.numWorkers != null) {
            this.numWorkers = this.partitionCavServerStats.numWorkers;
          }

          if (this.partitionCavServerStats.activeConns != null) {
            this.activeConns = this.partitionCavServerStats.activeConns;
          }

          if (this.partitionCavServerStats.numClients != null) {
            this.numClients = this.partitionCavServerStats.numClients;
          }

          if (this.partitionCavServerStats.numMgmtUtils != null) {
            this.numMgmtUtils = this.partitionCavServerStats.numMgmtUtils;
          }

          if (this.partitionCavServerStats.heartbeatDisconnection != null) {
            this.heartbeatDisconnection = this.partitionCavServerStats.heartbeatDisconnection;
          }

          if (this.partitionCavServerStats.activeKeys != null) {
            this.activeKeys = this.partitionCavServerStats.activeKeys;
          }

          if (this.partitionCavServerStats.tombstoneKeys != null) {
            this.tombstoneKeys = this.partitionCavServerStats.tombstoneKeys;
          }

          if (this.partitionCavServerStats.keysReloadCnt != null) {
            this.keysReloadCnt = this.partitionCavServerStats.keysReloadCnt;
          }

          if (this.partitionCavServerStats.uptimeInSecs != null) {
            this.uptimeInSecs = this.partitionCavServerStats.uptimeInSecs;
          }

          if (this.partitionCavServerStats.serverList != null) {
            this.serverList = this.partitionCavServerStats.serverList;
          }
        }
      }
    }
  }

  setPartitionNetworkStats(res) {
    // this.tab = "1";
    if (res.message != null && res.message != '') {
      this.partitionNetworkStats = JSON.parse(res.message);

      if (this.partitionNetworkStats != null) {

        if (this.partitionNetworkStats.general != null) {

          if (this.partitionNetworkStats.general.eth0 != null) {

            if (this.partitionNetworkStats.general.eth0.dhcp != null) {
              this.dhcp = this.partitionNetworkStats.general.eth0.dhcp;
            } else {
              this.dhcp = false
            }

            if (this.partitionNetworkStats.general.eth0.dhcpStatus != null) {
              this.dhcpStatus = this.partitionNetworkStats.general.eth0.dhcpStatus;
            }

            if (this.partitionNetworkStats.general.eth0.hostname != null) {
              this.hostname = this.partitionNetworkStats.general.eth0.hostname;
            }

            if (this.partitionNetworkStats.general.eth0.ip != null) {
              this.ipAddress = this.partitionNetworkStats.general.eth0.ip;
            }

            if (this.partitionNetworkStats.general.eth0.ipStatus != null) {
              this.ipStatus = this.partitionNetworkStats.general.eth0.ipStatus;
            }

            if (this.partitionNetworkStats.general.eth0.subnet != null) {
              this.subnetAddress = this.partitionNetworkStats.general.eth0.subnet;
            }

            if (this.partitionNetworkStats.general.eth0.subnetStatus != null) {
              this.subnetStatus = this.partitionNetworkStats.general.eth0.subnetStatus;
            }

            if (this.partitionNetworkStats.general.eth0.macStatic != null) {
              if (this.partitionNetworkStats.general.eth0.macStatic == false) {
                this.macStatic = "Disabled";
              } else if (this.partitionNetworkStats.general.eth0.macStatic == true) {
                this.macStatic = "Enabled";
              }
            }

            if (this.partitionNetworkStats.general.eth0.mac != null) {
              this.macAddress = this.partitionNetworkStats.general.eth0.mac;
            }

            if (this.partitionNetworkStats.general.eth0.macStatus != null) {
              this.macStatus = this.partitionNetworkStats.general.eth0.macStatus;
            }

            if (this.partitionNetworkStats.general.eth0.gateway != null) {
              this.gateway = this.partitionNetworkStats.general.eth0.gateway;
            }

            if (this.partitionNetworkStats.general.eth0.gatewayStatus != null) {
              this.gatewayStatus = this.partitionNetworkStats.general.eth0.gatewayStatus;
            }

            if (this.partitionNetworkStats.general.eth0.vlan != null) {
              this.vlan = this.partitionNetworkStats.general.eth0.vlan;
            }
          }

          if (this.partitionNetworkStats.general.eth1 != null) {

            if (this.partitionNetworkStats.general.eth1.dhcp != null) {
              this.dhcp1 = this.partitionNetworkStats.general.eth1.dhcp;
            } else {
              this.dhcp1 = false
            }

            if (this.partitionNetworkStats.general.eth1.dhcpStatus != null) {
              this.dhcpStatus1 = this.partitionNetworkStats.general.eth1.dhcpStatus;
            }

            if (this.partitionNetworkStats.general.eth1.hostname != null) {
              this.hostname1 = this.partitionNetworkStats.general.eth1.hostname;
            }

            if (this.partitionNetworkStats.general.eth1.ip != null) {
              this.ipAddress1 = this.partitionNetworkStats.general.eth1.ip;
            }

            if (this.partitionNetworkStats.general.eth1.ipStatus != null) {
              this.ipStatus1 = this.partitionNetworkStats.general.eth1.ipStatus;
            }

            if (this.partitionNetworkStats.general.eth1.subnet != null) {
              this.subnetAddress1 = this.partitionNetworkStats.general.eth1.subnet;
            }

            if (this.partitionNetworkStats.general.eth1.subnetStatus != null) {
              this.subnetStatus1 = this.partitionNetworkStats.general.eth1.subnetStatus;
            }

            if (this.partitionNetworkStats.general.eth1.macStatic != null) {
              if (this.partitionNetworkStats.general.eth1.macStatic == false) {
                this.macStatic1 = "Disabled";
              } else if (this.partitionNetworkStats.general.eth1.macStatic == true) {
                this.macStatic1 = "Enabled";
              }
            }

            if (this.partitionNetworkStats.general.eth1.mac != null) {
              this.macAddress1 = this.partitionNetworkStats.general.eth1.mac;
            }

            if (this.partitionNetworkStats.general.eth1.macStatus != null) {
              this.macStatus1 = this.partitionNetworkStats.general.eth1.macStatus;
            }

            // if (this.partitionNetworkStats.general.eth1.gateway != null) {
            //   this.gateway1 = this.partitionNetworkStats.general.eth1.gateway;
            // }

            // if (this.partitionNetworkStats.general.eth1.gatewayStatus != null) {
            //   this.gatewayStatus1 = this.partitionNetworkStats.general.eth1.gatewayStatus;
            // }

            if (this.partitionNetworkStats.general.eth1.vlan != null) {
              this.vlan1 = this.partitionNetworkStats.general.eth1.vlan;
            }
          }
        }

        if (this.partitionNetworkStats.advanced != null) {

          if (this.partitionNetworkStats.advanced.dnsServers != null) {
            this.dnsServers = this.partitionNetworkStats.advanced.dnsServers;
          }

          if (this.partitionNetworkStats.advanced.searchDomainNames != null) {
            this.searchDomainNames = this.partitionNetworkStats.advanced.searchDomainNames;
          }

          if (this.partitionNetworkStats.advanced.staticIpToHostConfig != null) {
            this.staticIpToHostConfig = this.partitionNetworkStats.advanced.staticIpToHostConfig;
          }
        }
      }
    }
    // let modal = {
    //   "ip": this.ipAddress,
    //   partitionDetailModel: {
    //     "partitionId": this.partitionId
    //   }
    // }
    // this._partitionManagementService.updateEth01IpDetail(modal).subscribe(
    //   res => {
    //     console.log(res);
    //   },
    //   error => {
    //     console.log(error);
    //   },
    // )
    this.reloadPartitionInfo();
  }

  timer: AnonymousSubscription;
  reloadPartitionInfo(){
    this.timer = Observable.timer(10000).first().subscribe(() => this.getPartitionInfo());
  }

  getPartitionInfo(){
    let partitionInfoData = this._partitionManagementService.getPartitionInfoData(this.partitionId);
    let partitionCavServerConfigData = this._partitionManagementService.getPartitionCavServerConfigData(this.partitionId);
    let partitionStats = this._partitionManagementService.getPartitionStats(this.partitionId);
    let partitionCavServerStatsData = this._partitionManagementService.getPartitionCavServerStatsData(this.partitionId);
    let partitionNetworkStats = this._partitionManagementService.getPartitionNetworkStats(this.partitionId);
    forkJoin([partitionInfoData, partitionCavServerConfigData, partitionStats, partitionCavServerStatsData, partitionNetworkStats]).subscribe(result => {
      this.setPartitionInfoData(result[0]);
      this.setPartitionCavServerConfigData(result[1]);
      this.setPartitionStats(result[2]);
      this.setPartitionCavServerStatsData(result[3]);
      this.setPartitionNetworkStats(result[4]);   
    });
  }

  ngOnDestroy() {
    if (this.timer) {
      this.timer.unsubscribe();
    }
  }

  selectTab(tab_id: string) {
    if (tab_id == "1") {
      this.classStatic = "btn-primary";
      this.classServer = "btn-default";
    } else if (tab_id == "2") {
      this.classStatic = "btn-default";
      this.classServer = "btn-primary";
    }
    this.tab = tab_id;
  }

  gaugeType = "arch";
  gaugeThickness = 25;
  gaugeThresholdConfig = {
    '0': { color: 'rgb(0,179,30' },
    '60': { color: 'rgb(230,191,0' },
    '80': { color: 'rgb(204,0,0' }
  };
  gaugeAppendText = "%";

  // hostVM gauge
  gaugeValue:number;
  data:number;
  gaugeValue2: number;
  data2:number;
  gaugeValue3: number;
  data3:number;


  // lineChart10
  public lineChartData010: Array<any> = [
    { data: [70, 59, 83, 81, 60, 87, 83], label: 'Head' },
    { data: [65, 48, 55, 50, 56, 60, 78], label: 'Tail' },
    { data: [45, 35, 45, 65, 47, 52, 40], label: 'Head' },
    { data: [27, 22, 33, 30, 38, 27, 32], label: 'Tail' },

  ];
  public lineChartLabels10: Array<any> = ['18:10', '18:20', '18:30', '18:40', '18:50', '19:00', '19:10'];
  public lineChartOptions10: any = {
    responsive: true,
    legend: {
      display: true,
      position: 'bottom'
    }
  };
  public lineChartColors10: Array<any> = [
    { // blue
      backgroundColor: 'rgba(0,102,204,0)',
      borderColor: 'rgba(0,102,204,1)',
      pointBackgroundColor: 'rgba(0,102,204,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(0,102,204,0.8)'
    },
    { //green
      backgroundColor: 'rgba(89,179,0,0)',
      borderColor: 'rgba(89,179,0,1)',
      pointBackgroundColor: 'rgba(89,179,0,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(89,179,0,0.8)'
    },

    { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
    },

    { // purple
      backgroundColor: 'rgba(102,0,153,0)',
      borderColor: 'rgba(102,0,153,1)',
      pointBackgroundColor: 'rgba(102,0,153,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(102,0,153,1)'
    },

  ];
  public lineChartLegend10: boolean = true;
  public lineChartType10: string = 'line';


  // events
  public chartClicked10(e: any): void {
    console.log(e);
  }

  public chartHovered10(e: any): void {
    console.log(e);
  }

  // lineChart11
  public lineChartData011: Array<any> = [
    { data: [70, 59, 83, 81, 60, 87, 83], label: 'Head' },
    { data: [65, 48, 55, 50, 56, 60, 78], label: 'Tail' },
    { data: [45, 35, 45, 65, 47, 52, 40], label: 'Head' },
    { data: [27, 22, 33, 30, 38, 27, 32], label: 'Tail' },
  ];
  public lineChartLabels11: Array<any> = ['18:10', '18:20', '18:30', '18:40', '18:50', '19:00', '19:10'];
  public lineChartOptions11: any = {
    responsive: true,
    legend: {
      display: true,
      position: 'bottom'
    }
  };
  public lineChartColors11: Array<any> = [
    { // blue
      backgroundColor: 'rgba(0,102,204,0)',
      borderColor: 'rgba(0,102,204,1)',
      pointBackgroundColor: 'rgba(0,102,204,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(0,102,204,0.8)'
    },
    { //green
      backgroundColor: 'rgba(89,179,0,0)',
      borderColor: 'rgba(89,179,0,1)',
      pointBackgroundColor: 'rgba(89,179,0,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(89,179,0,0.8)'
    },

    { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
    },

    { // purple
      backgroundColor: 'rgba(102,0,153,0)',
      borderColor: 'rgba(102,0,153,1)',
      pointBackgroundColor: 'rgba(102,0,153,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(102,0,153,1)'
    },

  ];
  public lineChartLegend11: boolean = true;
  public lineChartType11: string = 'line';


  // events
  public chartClicked11(e: any): void {
    console.log(e);
  }

  public chartHovered11(e: any): void {
    console.log(e);
  }
  
  ngAfterViewInit() {
    $("tabset ul").css("background-color", "#ddd");
    $("tabset ul").css("padding-top", "5px");
    $("tabset .nav-tabs").css("border-color", "#fff");
    $("tabset ul li:first-child").css("margin-left", "5px");
  }
  onSelect(){
    this.tab = "1";
    this.classStatic = "btn-primary";
    this.classServer = "btn-default";
    } 
}













