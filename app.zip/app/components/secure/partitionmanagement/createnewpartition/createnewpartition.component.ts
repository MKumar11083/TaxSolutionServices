
import { Component, OnInit, ViewChild, Input, TemplateRef } from '@angular/core';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, FormControl, FormArray } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { Router } from '@angular/router';
import { TabsetComponent } from 'ngx-bootstrap';
import { PartitionManagementService } from './../../../../services/partitionmanagement/partitionmanagement.service';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { CommonValidator } from './../../../../validators/common-validator';


declare var jquery: any;
declare var $: any;
declare var bootbox: any;
@Component({
  selector: 'app-createnewpartition',
  templateUrl: './createnewpartition.component.html',
  styleUrls: ['./createnewpartition.component.css']
})
export class CreatenewpartitionComponent implements OnInit {
  @ViewChild('staticTabs') staticTabs: TabsetComponent;
  @ViewChild('insideTabs') insideTabs: TabsetComponent;
  @Input() selectedApplianceList;
  form: FormGroup;
  addAdvanced: FormGroup;
  tab: string;
  staticHostIp = [];
  dnsServers = [];
  domainNames = [];
  displayError: string;
  displayError1: string;
  successMessage: string;
  message: string;
  modalRef: BsModalRef;
  classStatic: string;
  classServer: string;
  classDomain: string;
  public loading = false;
  availableKeys: number = 0;
  availableAcceleration: number = 0;
  ApplianceName1: any;
  ApplianceIP1: any;
  isValidIp3: boolean = true;
  isValidHostname3: boolean = true;
  availableSSLContext: number = 0;
  constructor(
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private router: Router,
    private builder: FormBuilder,
    private _service: PartitionManagementService,
    private modalService: BsModalService, ) { }


  ngOnInit() {
    this.availableAcceleration = 0;
    this.availableKeys = 0;
    this.availableSSLContext = 0;
    let totalKeys = this.selectedApplianceList[0]['totalKeys'];
    let occupiedKeys = this.selectedApplianceList[0]['occupiedKeys'];
    let totalAcclr = this.selectedApplianceList[0]['totalAcclrDevice'];
    let occupiedAcclr = this.selectedApplianceList[0]['occupiedAcclrDev'];
    let totalsslContext = this.selectedApplianceList[0]['totalContexts'];
    let occupiedsslContext = this.selectedApplianceList[0]['occupiedContexts']
    this.availableKeys = parseInt(totalKeys) - parseInt(occupiedKeys);
    this.availableAcceleration = parseInt(totalAcclr) - parseInt(occupiedAcclr);
    this.availableSSLContext = parseInt(totalsslContext) - parseInt(occupiedsslContext);
    this.ApplianceName1 = this.selectedApplianceList[0]['applianceName'];
    this.ApplianceIP1 = this.selectedApplianceList[0]['ipAddress'];
    this.createForm();
    this.initItemRows(null, null, null);
    if (this.availableKeys === 0) {
      this.form.get('keys').setValue(0);
      this.form.get('keys').disable();
    }
    if (this.availableAcceleration === 0) {
      this.form.get('acclrDev').setValue(0);
      this.form.get('acclrDev').disable();
    }
    if (this.availableSSLContext === 0) {
      this.form.get('sslContexts').setValue(0);
      this.form.get('sslContexts').disable();
    }
    this.tab = "1";
    // set the appliance details to the form.
    this.classStatic = "btn-primary";
    this.classServer = "btn-default";
    this.classDomain = "btn-default";
    this.form.get('networkStats.general.eth0.ip').disable();
    this.form.get('networkStats.general.eth0.gateway').disable();
    this.form.get('networkStats.general.eth0.subnet').disable();
    this.form.get('networkStats.general.eth0.address').disable();
    this.form.get('networkStats.general.eth1.ip').disable();
    this.form.get('networkStats.general.eth1.subnet').disable();
    this.form.get('networkStats.general.eth1.address').disable();
    this.form.get('partitionName').valueChanges.subscribe((data) => {
      this.formValidationFields = this._fieldErrorDisplayService.validateField(this.form, "partitionName", this.formValidationFields, "createPartition");
    });
    this.form.get('keys').valueChanges.subscribe((data) => {
      this.formValidationFields = this._fieldErrorDisplayService.validateField(this.form, "keys", this.formValidationFields, "createPartition");
    });
    this.form.get('sslContexts').valueChanges.subscribe((data) => {
      this.formValidationFields = this._fieldErrorDisplayService.validateField(this.form, "sslContexts", this.formValidationFields, "createPartition");
    });
    this.form.get('acclrDev').valueChanges.subscribe((data) => {
      this.formValidationFields = this._fieldErrorDisplayService.validateField(this.form, "acclrDev", this.formValidationFields, "createPartition");
    });

    this.form.get('csr').valueChanges.subscribe((data) => {
      this.formValidationFields = this._fieldErrorDisplayService.validateField(this.form, "csr", this.formValidationFields, "createPartition");
    });
  }
  // create form for createpartition .
  createForm() {
    this.form = this.builder.group({
      partitionName: ['', Validators.compose([Validators.required,CommonValidator.validateAppName])],
      csr: [null, Validators.compose([CommonValidator.validateAlphaNumeric1])],
      keys: [1, Validators.compose([Validators.required, Validators.max(this.availableKeys)])],
      sslContexts: [1, Validators.compose([Validators.required, Validators.max(this.availableSSLContext)])],
      acclrDev: [1, Validators.compose([Validators.required, Validators.max(this.availableAcceleration)])],
      wrap: [''],
      backup: [''],
      applianceDetailModel: this.builder.group({
        applianceId: [null],
        applianceName: [null],
        applianceStatus: [null],
        serialNumber: [null],
        networkTimezone: [null],
        gatewayIp: [null],
        ipAddress: [null],
        networkId: [null],
        subnetMask: [null],
      }),
      networkStats: this.builder.group({
        general: this.builder.group({
          eth0: this.builder.group({
            ethName: ['eth0'],
            dhcp: [true],
            ip: [null],
            gateway: [null],
            subnet: [null],
            hostname: [null, Validators.compose([CommonValidator.hostNameValidator])],
            staticMac: [null],
            address: [null],
            vlan: [0, Validators.compose([Validators.min(0), Validators.max(4094)])],
          }),
          eth1: this.builder.group({
            ethName: ['eth1'],
            dhcp: [true],
            disableEth1: [true],
            ip: [null],
            gateway: [null],
            subnet: [null],
            hostname: [null, Validators.compose([CommonValidator.hostNameValidator])],
            staticMac: [null],
            address: [null],
            vlan: [0, Validators.compose([Validators.min(0), Validators.max(4094)])],
            id: [null],
          })
        }),
        advanced: this.builder.group({
          staticIpToHostConfig: this.builder.group({
            add: new FormArray([]),

          }),
          dnsConfig: this.builder.group({
            dnsServers: new FormArray([]),
            searchDomainNames: new FormArray([]),
            enableService: [true]
          }),
          ip: ['', CommonValidator.ipAddressValidator],
          hostname: ['', CommonValidator.hostNameValidator1],
          alias: [''],
          id: [''],
          dnsServer: [null, CommonValidator.ipAddressValidator],
          searchDomainName: [null, CommonValidator.validateDomainName]
        })
      }),
      partitionCertificate: [null],
      errorMessage: [null],
      username: [null],
      password: [null]
    });
  }

  initItemRows(ip, hostname, alias) {
    return this.addAdvanced = this.builder.group({
      ip: ip,
      hostname: hostname,
      alias: alias,
      id: [null]
    });

  }

  setApplianceDataToForm() {
    if (this.selectedApplianceList[0]['applianceId'] != null && this.selectedApplianceList[0]['applianceId'] != "") {
      this.form.get('applianceDetailModel.applianceId').setValue(this.selectedApplianceList[0]['applianceId']);

    }
    if (this.selectedApplianceList[0]['applianceName'] != null && this.selectedApplianceList[0]['applianceName'] != "") {
      this.form.get('applianceDetailModel.applianceName').setValue(this.selectedApplianceList[0]['applianceName']);

    }
    if (this.selectedApplianceList[0]['applianceStatus'] != null && this.selectedApplianceList[0]['applianceStatus'] != "") {
      this.form.get('applianceDetailModel.applianceStatus').setValue(this.selectedApplianceList[0]['applianceStatus']);
    }
    if (this.selectedApplianceList[0]['serialNumber'] != null && this.selectedApplianceList[0]['serialNumber'] != "") {
      this.form.get('applianceDetailModel.serialNumber').setValue(this.selectedApplianceList[0]['serialNumber']);
    }
    if (this.selectedApplianceList[0]['networkTimezone'] != null && this.selectedApplianceList[0]['networkTimezone'] != "") {
      this.form.get('applianceDetailModel.networkTimezone').setValue(this.selectedApplianceList[0]['networkTimezone']);
    }
    if (this.selectedApplianceList[0]['gatewayIp'] != null && this.selectedApplianceList[0]['gatewayIp'] != "") {
      this.form.get('applianceDetailModel.gatewayIp').setValue(this.selectedApplianceList[0]['gatewayIp']);
    }
    if (this.selectedApplianceList[0]['ipAddress'] != null && this.selectedApplianceList[0]['ipAddress'] != "") {
      this.form.get('applianceDetailModel.ipAddress').setValue(this.selectedApplianceList[0]['ipAddress']);

    }
    if (this.selectedApplianceList[0]['networkId'] != null && this.selectedApplianceList[0]['networkId'] != "") {
      this.form.get('applianceDetailModel.networkId').setValue(this.selectedApplianceList[0]['networkId']);
    }
    if (this.selectedApplianceList[0]['subnetMask'] != null && this.selectedApplianceList[0]['subnetMask'] != "") {
      this.form.get('applianceDetailModel.subnetMask').setValue(this.selectedApplianceList[0]['subnetMask']);
    }
    if (this.selectedApplianceList[0]['userName'] != null && this.selectedApplianceList[0]['userName'] != "") {
      this.form.get('username').setValue(this.selectedApplianceList[0]['userName']);
    }
    if (this.selectedApplianceList[0]['userPassword'] != null && this.selectedApplianceList[0]['userPassword'] != "") {
      this.form.get('password').setValue(this.selectedApplianceList[0]['userPassword']);
    }
  }

  onErrorOperation(errResp) {

  }

  // create a form errors
  public formValidationFields = {
    "partitionName": '',
    "csr": '',
    "keys": '',
    "sslContexts": '',
    "acclrDev": '',
    "wrap": '',
    "backup": '',

  }


  selectTab(tab_id: string) {
    if (tab_id == "1") {
      this.classStatic = "btn-primary";
      this.classServer = "btn-default";
      this.classDomain = "btn-default";
    } else if (tab_id == "2") {
      this.classStatic = "btn-default";
      this.classServer = "btn-primary";
      this.classDomain = "btn-default";
    } else if (tab_id == "3") {
      this.classStatic = "btn-default";
      this.classServer = "btn-default";
      this.classDomain = "btn-primary";
    }
    this.tab = tab_id;
    this.displayError = "";
  }

  onSubmit(isValid, template: TemplateRef<any>) {
    if (isValid) {
      if (this.form.get('keys').value > 0 && this.form.get('acclrDev').value > 0 && this.form.get('sslContexts').value > 0) {
        let disableEth1 = this.form.get('networkStats.general.eth1.disableEth1').value;

        this.setApplianceDataToForm();
        this.loading = true;
        // this.resetFieldsBasedOnValidation();

        this._service.createPartition(this.pushConfigNetworkDetails(this.form.value)).subscribe(
          res => {
            this.loading = false;
            if (res.code == "200") {
              let message = "<b>" + res.message + "</b>"
              bootbox.dialog({
                message: message,
                buttons: {
                  Ok: {
                    label: "Close",
                    className: 'btn btn-primary btn-flat',
                    callback: () => this.redirectToPartitionList()
                  }
                }
              });
            } else {
              let message = "<b>" + res.errorMessage + "</b>"
              bootbox.dialog({
                message: message,
                buttons: {
                  cancel: {
                    label: "Close",
                    className: 'btn btn-primary btn-flat'
                  }

                }
              });
            }
          },
          error => {
            this.loading = false;
            console.log(error);
          },
        );
      }
      else {
        let message = "Please enter valid data in keys, sslcontext & accleration device field(s)."
        bootbox.dialog({
          message: message,
          buttons: {
            cancel: {
              label: "Close",
              className: 'btn btn-primary btn-flat'
            }

          }
        });
      }
    }

    else {
      this.formValidationFields = this._fieldErrorDisplayService.validateForm(this.form, this.formValidationFields, "createPartition", false)
      if (this.formValidationFields.partitionName != "" || this.formValidationFields.csr != ""
        || this.formValidationFields.keys != "" || this.formValidationFields.sslContexts != ""
        || this.formValidationFields.acclrDev != "") {
        this.staticTabs.tabs[0].active = true;
      } else {
        const eth0IpControl = this.form.get('networkStats.general.eth0.ip');
        if (eth0IpControl.errors != null) {
          if (eth0IpControl.hasError('required')) {
            eth0IpControl.markAsTouched({ onlySelf: true });
          }
        }
        const eth0AddressControl = this.form.get('networkStats.general.eth0.address');
        if (eth0AddressControl.errors != null) {
          if (eth0AddressControl.hasError('required')) {
            eth0AddressControl.markAsTouched({ onlySelf: true });
          }
        }

        const eth1IpControl = this.form.get('networkStats.general.eth1.ip');
        if (eth1IpControl.errors != null) {
          if (eth1IpControl.hasError('required')) {
            eth1IpControl.markAsTouched({ onlySelf: true });
          }
        }

        const eth1AddressControl = this.form.get('networkStats.general.eth1.address');
        if (eth1AddressControl.errors != null) {
          if (eth1AddressControl.hasError('required')) {
            eth1AddressControl.markAsTouched({ onlySelf: true });
          }
        }
        this.staticTabs.tabs[1].active = true;
      }
    }
  }
  pushConfigNetworkDetails(obj) {
    let networkObj = {
      'general': {
        'eth0': { "ethName": "eth0", },
        'eth1': { "ethName": "eth1", }
      },

    }
    let networkStatsData = obj.networkStats;
    // eth0
    networkObj.general.eth0['dhcp'] = networkStatsData.general.eth0.dhcp;
    networkObj.general.eth0['staticMac'] = networkStatsData.general.eth0.staticMac;
    if (!networkStatsData.general.eth0.dhcp) {
      networkObj.general.eth0['ip'] = networkStatsData.general.eth0.ip;
      networkObj.general.eth0['gateway'] = networkStatsData.general.eth0.gateway;
      networkObj.general.eth0['subnet'] = networkStatsData.general.eth0.subnet;
    }
    if (!networkStatsData.general.eth1.dhcp && networkStatsData.general.eth1.dhcp != undefined) {
      networkObj.general.eth1['ip'] = networkStatsData.general.eth1.ip;
      networkObj.general.eth1['subnet'] = networkStatsData.general.eth1.subnet;

    }
    if (networkStatsData.general.eth0.staticMac) {
      networkObj.general.eth0['address'] = networkStatsData.general.eth0.address;
    }
    if (networkStatsData.general.eth0.hostname != null) {
      networkObj.general.eth0['hostname'] = networkStatsData.general.eth0.hostname;
    } else {
      networkObj.general.eth0['hostname'] = "";
    }
    if (networkStatsData.general.eth0.vlan != null && networkStatsData.general.eth0.vlan != '') {
      networkObj.general.eth0['vlan'] = networkStatsData.general.eth0.vlan;
    } else {
      networkObj.general.eth0['vlan'] = 0;
    }
    // eth1
    networkObj.general.eth1['dhcp'] = networkStatsData.general.eth1.dhcp;
    networkObj.general.eth1['staticMac'] = networkStatsData.general.eth1.staticMac;

    if (networkStatsData.general.eth1.vlan != null && networkStatsData.general.eth1.vlan != '') {
      networkObj.general.eth1['vlan'] = networkStatsData.general.eth1.vlan;
    } else {
      networkObj.general.eth1['vlan'] = 0;
    }

    if (networkStatsData.general.eth1.staticMac) {
      networkObj.general.eth1['address'] = networkStatsData.general.eth1.address;
    }
    if (networkStatsData.general.eth1.disableEth1) {
      networkObj.general.eth1['disableEth1'] = false;
    } else {
      networkObj.general.eth1['disableEth1'] = true;
    }

    let advanced = {
      'dnsConfig': {
        'enableService': false
      }
    };
    let showAdvanced = false;
    let staticIps = networkStatsData.advanced.staticIpToHostConfig.add;
    if (staticIps.length > 0) {
      showAdvanced = true;
      advanced['staticIpToHostConfig'] = {};
      advanced['staticIpToHostConfig']['add'] = staticIps;
    }

    let dnsServer = networkStatsData.advanced.dnsConfig.dnsServers;
    let searchDomain = networkStatsData.advanced.dnsConfig.searchDomainNames;
    if (dnsServer.length > 0 && dnsServer != null) {
      showAdvanced = true;
      advanced['dnsConfig']['dnsServers'] = dnsServer;
    }
    if (searchDomain.length > 0 && searchDomain != null) {
      showAdvanced = true;
      advanced['dnsConfig']['searchDomainNames'] = this.domainNames;
    }
    if (showAdvanced) {
      networkObj['advanced'] = {};
      advanced['dnsConfig']['enableService'] = true;
      networkObj['advanced'] = advanced;
    }
    obj['networkStats'] = networkObj;
    return obj;
  }
  resetFieldsBasedOnValidation() {
    if (this.form.get('networkStats.general.eth0.dhcp').value) {
      this.form.get('networkStats.general.eth0.ip').reset();
      this.form.get('networkStats.general.eth0.gateway').reset();
      this.form.get('networkStats.general.eth0.subnet').reset();
    }
    if (this.form.get('networkStats.general.eth1.dhcp').value) {
      this.form.get('networkStats.general.eth1.ip').reset();
      this.form.get('networkStats.general.eth1.subnet').reset();
    }
    if (this.form.get('networkStats.general.eth0.staticMac').value == false) {
      this.form.get('networkStats.general.eth0.address').reset();
    }
    if (this.form.get('networkStats.general.eth1.staticMac').value == false) {
      this.form.get('networkStats.general.eth1.address').reset();
    }
    let eth1hostname = this.form.get('networkStats.general.eth1.hostname').value;
    if (eth1hostname == null || eth1hostname == "") {
      this.form.get('networkStats.general.eth1.hostname').setValue(null);
    }
    if (!this.form.get('networkStats.general.eth1.disableEth1').value) {
      this.form.get('networkStats.general.eth1.dhcp').reset();
      this.form.get('networkStats.general.eth1.ip').reset();
      this.form.get('networkStats.general.eth1.subnet').reset();
      this.form.get('networkStats.general.eth1.staticMac').reset();
      this.form.get('networkStats.general.eth1.address').reset();
      this.form.get('networkStats.general.eth1.disableEth1').setValue(true);
    } else {
      this.form.get('networkStats.general.eth1.disableEth1').setValue(false);
    }
    // const control = <FormControl>this.form.get('networkStats').get('advanced').
    //   get('dnsConfig').get('enableService');
    // control.setValue(true);
  }

  redirectToPartitionList() {
    this.router.navigateByUrl("/listPartition");
  }

  addStaticHostIp() {
    this.displayError = "";
    if (this.form.get('networkStats.advanced.ip').value != "" && this.form.get('networkStats.advanced.hostname').value != "") {
      if (this.staticHostIp.length < 16) {
        if (this.form.get('networkStats.advanced.ip').errors == null
          && this.form.get('networkStats.advanced.hostname').errors == null) {
          let ip = this.form.get('networkStats.advanced.ip').value;
          let hostname = this.form.get('networkStats.advanced.hostname').value;
          let alias = this.form.get('networkStats.advanced.alias').value;
          let flag = this.staticHostIp.some(e => e.ip == ip);
          if (!flag) {
            flag = this.staticHostIp.some(e => e.hostname == hostname);
          }
          if (!flag) {
            const control = <FormArray>this.form.get('networkStats').get('advanced').get('staticIpToHostConfig').get('add');
            let staticHostIpData = {};
            staticHostIpData['ip'] = ip;
            staticHostIpData['hostname'] = hostname;
            staticHostIpData['alias'] = alias;
            control.push(this.initItemRows(ip, hostname, alias));
            this.staticHostIp.push(staticHostIpData);
            this.form.get('networkStats.advanced.ip').setValue("");
            this.form.get('networkStats.advanced.hostname').setValue("");
            this.form.get('networkStats.advanced.alias').setValue("");
          } else {
            this.displayError = "Entered IP address and hostname should be unique. "
          }
        }
      } else {
        this.displayError = "You can enter maximum 16 static Ip's"
      }
    } else {
      this.displayError = "Please enter the required fields"
    }
  }

  removeStaticHostIp(index) {
    const control = <FormArray>this.form.get('networkStats').get('advanced').get('staticIpToHostConfig').get('add');
    // remove the chosen row
    control.removeAt(index);
    let indexAt = this.staticHostIp.indexOf(index);
    this.staticHostIp.splice(indexAt);
  }

  addDnsServer() {
    this.displayError = "";
    if (this.dnsServers.length < 4) {
      if (this.form.get('networkStats.advanced.dnsServer').value != "") {
        if (this.form.get('networkStats.advanced.dnsServer').errors == null) {
          let flag = this.dnsServers.some(e => e ==
            this.form.get('networkStats.advanced.dnsServer').value);
          if (!flag) {
            const control = <FormArray>this.form.get('networkStats').get('advanced').
              get('dnsConfig').get('dnsServers');
            control.push(new FormControl(this.form.get('networkStats.advanced.dnsServer').value));
            this.dnsServers.push(this.form.get('networkStats.advanced.dnsServer').value);
            this.form.get('networkStats.advanced.dnsServer').setValue("");
          } else {
            this.displayError = "Entered DNS address already exists."
          }
        }
      } else {
        this.displayError = "Please enter the required field";

      }
    } else {
      this.displayError = "You can enter maximum 4 DNS Servers"
    }
    // else {
    //   let message = "Please enter correct DNS Server"
    //   bootbox.dialog({
    //     message: message,
    //     buttons: {
    //       Ok: {
    //         label: "Close",
    //         className: 'btn btn-primary btn-flat',

    //       }
    //     }
    //   });
    // }
  }


  removeDnsServers(index) {
    const control = <FormArray>this.form.get('networkStats').get('advanced')
      .get('dnsConfig').get('dnsServers');
    // remove the chosen row
    control.removeAt(index);
    let indexAt = this.dnsServers.indexOf(index);
    this.dnsServers.splice(indexAt);
  }

  addDomainName() {
    this.displayError = "";
    if (this.domainNames.length < 4) {
      if (this.form.get('networkStats.advanced.searchDomainName').value != "") {
        if (this.form.get('networkStats.advanced.searchDomainName').errors == null) {
          let flag = this.domainNames.some(e => e ==
            this.form.get('networkStats.advanced.searchDomainName').value);
          if (!flag) {
            const control = <FormArray>this.form.get('networkStats').get('advanced').
              get('dnsConfig').get('searchDomainNames');
            // control.push(this.form.get('networkStats.advanced.dnsServer').value);
            control.push(new FormControl(this.form.get('networkStats.advanced.searchDomainName').value));
            this.domainNames.push(this.form.get('networkStats.advanced.searchDomainName').value);
            this.form.get('networkStats.advanced.searchDomainName').setValue("");
          } else {
            this.displayError = "Domain Name is already exists";
          }
        }
      } else {
        this.displayError = " Please enter the required field"
      }
    } else {
      this.displayError = "You can enter maximum 4 Domain Names"
    }
    // else {
    //   let message = "Please enter correct Domain Name"
    //   bootbox.dialog({
    //     message: message,
    //     buttons: {
    //       Ok: {
    //         label: "Close",
    //         className: 'btn btn-primary btn-flat',

    //       }
    //     }
    //   });
    // }
  }

  removeSearchDomain(index) {
    const control = <FormArray>this.form.get('networkStats').get('advanced')
      .get('dnsConfig').get('searchDomainNames');
    // remove the chosen row
    control.removeAt(index);
    let indexAt = this.domainNames.indexOf(index);
    this.domainNames.splice(indexAt);
  }



  toggleDhcpEth0(event) {
    this.form.get('networkStats.general.eth0.ip').reset();
    this.form.get('networkStats.general.eth0.gateway').reset();
    this.form.get('networkStats.general.eth0.subnet').reset();
    if (event.checked) {
      this.form.get('networkStats.general.eth0.ip').disable();
      this.form.get('networkStats.general.eth0.gateway').disable();
      this.form.get('networkStats.general.eth0.subnet').disable();
      this.form.get('networkStats.general.eth0.ip').clearValidators();
      this.form.get('networkStats.general.eth0.gateway').clearValidators();
      this.form.get('networkStats.general.eth0.subnet').clearValidators();
    } else {
      this.form.get('networkStats.general.eth0.ip').setValidators([Validators.required, CommonValidator.ipAddressValidator1]);
      this.form.get('networkStats.general.eth0.gateway').setValidators(CommonValidator.ipAddressValidator);
      this.form.get('networkStats.general.eth0.subnet').setValidators(CommonValidator.ipAddressValidator);
      this.form.get('networkStats.general.eth0.ip').enable();
      this.form.get('networkStats.general.eth0.gateway').enable();
      this.form.get('networkStats.general.eth0.subnet').enable();
      this.form.get('networkStats.general.eth0.ip').markAsUntouched();
    }
    this.form.get('networkStats.general.eth0.ip').updateValueAndValidity();
    this.form.get('networkStats.general.eth0.gateway').updateValueAndValidity();
    this.form.get('networkStats.general.eth0.subnet').updateValueAndValidity();
  }


  toggleDhcpEth1(event) {
    this.form.get('networkStats.general.eth1.ip').reset();
    this.form.get('networkStats.general.eth1.subnet').reset();
    if (event.checked) {
      this.form.get('networkStats.general.eth1.ip').disable();
      this.form.get('networkStats.general.eth1.subnet').disable();
      this.form.get('networkStats.general.eth1.ip').clearValidators();
      this.form.get('networkStats.general.eth1.subnet').clearValidators();
    } else {
      this.form.get('networkStats.general.eth1.ip').enable();
      this.form.get('networkStats.general.eth1.subnet').enable();
      this.form.get('networkStats.general.eth1.ip').markAsUntouched();
      this.form.get('networkStats.general.eth1.subnet').markAsUntouched();
      this.form.get('networkStats.general.eth1.ip').setValidators([Validators.required, CommonValidator.ipAddressValidator1]);
      this.form.get('networkStats.general.eth1.subnet').setValidators(CommonValidator.ipAddressValidator);
    }
    this.form.get('networkStats.general.eth1.ip').updateValueAndValidity();
    this.form.get('networkStats.general.eth1.subnet').updateValueAndValidity();
  }

  disableEth1Fields(event) {
    this.form.get('networkStats.general.eth1.dhcp').reset();
    this.form.get('networkStats.general.eth1.staticMac').reset();
    this.form.get('networkStats.general.eth1.address').reset();
    this.form.get('networkStats.general.eth1.vlan').reset();
    this.form.get('networkStats.general.eth1.ip').reset();
    this.form.get('networkStats.general.eth1.subnet').reset();
    if (event.checked) {
      this.form.get('networkStats.general.eth1.dhcp').enable();
      if (this.form.get('networkStats.general.eth1.dhcp').value) {
        this.form.get('networkStats.general.eth1.ip').disable();
        this.form.get('networkStats.general.eth1.subnet').disable();
        this.form.get('networkStats.general.eth1.ip').clearValidators();
        this.form.get('networkStats.general.eth1.subnet').clearValidators();
      } else {
        this.form.get('networkStats.general.eth1.ip').enable();
        this.form.get('networkStats.general.eth1.subnet').enable();
        this.form.get('networkStats.general.eth1.ip').markAsUntouched();
        this.form.get('networkStats.general.eth1.subnet').markAsUntouched();
        this.form.get('networkStats.general.eth1.ip').setValidators([Validators.required, CommonValidator.ipAddressValidator1]);
        this.form.get('networkStats.general.eth1.subnet').setValidators(CommonValidator.ipAddressValidator);
      }
      this.form.get('networkStats.general.eth1.ip').updateValueAndValidity();
      this.form.get('networkStats.general.eth1.subnet').updateValueAndValidity();

      this.form.get('networkStats.general.eth1.staticMac').enable();
      if (this.form.get('networkStats.general.eth1.staticMac').value) {
        this.form.get('networkStats.general.eth1.address').enable();
        this.form.get('networkStats.general.eth1.address').markAsUntouched();
        this.form.get('networkStats.general.eth1.address').setValidators([Validators.required, CommonValidator.macAddressValidator]);
      } else {
        this.form.get('networkStats.general.eth1.address').disable();
        this.form.get('networkStats.general.eth1.address').clearValidators();
      }
      this.form.get('networkStats.general.eth1.address').updateValueAndValidity();
      this.form.get('networkStats.general.eth1.vlan').enable();
    } else {
      this.form.get('networkStats.general.eth1.dhcp').disable();
      this.form.get('networkStats.general.eth1.staticMac').disable();
      this.form.get('networkStats.general.eth1.address').disable();
      this.form.get('networkStats.general.eth1.vlan').disable();
      this.form.get('networkStats.general.eth1.ip').disable();
      this.form.get('networkStats.general.eth1.subnet').disable();
      this.form.get('networkStats.general.eth1.ip').clearValidators();
      this.form.get('networkStats.general.eth1.subnet').clearValidators();
      this.form.get('networkStats.general.eth1.address').clearValidators();
      this.form.get('networkStats.general.eth1.ip').updateValueAndValidity();
      this.form.get('networkStats.general.eth1.subnet').updateValueAndValidity();
      this.form.get('networkStats.general.eth1.address').updateValueAndValidity();
    }
  }

  toggleMacAddressEth0(event) {
    this.form.get('networkStats.general.eth0.address').reset();
    if (event.checked) {
      this.form.get('networkStats.general.eth0.address').enable();
      this.form.get('networkStats.general.eth0.address').markAsUntouched();
      this.form.get('networkStats.general.eth0.address').setValidators([Validators.required, CommonValidator.macAddressValidator]);
    } else {
      this.form.get('networkStats.general.eth0.address').disable();
      this.form.get('networkStats.general.eth0.address').clearValidators();
    }
    this.form.get('networkStats.general.eth0.address').updateValueAndValidity();
  }

  toggleMacAddressEth1(event) {
    this.form.get('networkStats.general.eth1.address').reset();
    if (event.checked) {
      this.form.get('networkStats.general.eth1.address').enable();
      this.form.get('networkStats.general.eth1.address').markAsUntouched();
      this.form.get('networkStats.general.eth1.address').setValidators([Validators.required, CommonValidator.macAddressValidator]);
    } else {
      this.form.get('networkStats.general.eth1.address').disable();
      this.form.get('networkStats.general.eth1.address').clearValidators();
    }
    this.form.get('networkStats.general.eth1.address').updateValueAndValidity();
  }


  public OnlyNumericValues(e) {
    let input;
    if (e.metaKey || e.ctrlKey) {
      return true;
    }
    if (e.which === 32) {
      return false;
    }
    if (e.which === 0) {
      return true;
    }
    if (e.which < 33) {
      return true;
    }
    input = String.fromCharCode(e.which);
    return !!/[\d\s]/.test(input);
  }


}





