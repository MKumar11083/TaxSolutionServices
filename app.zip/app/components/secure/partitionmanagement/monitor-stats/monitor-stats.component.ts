import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { PartitionManagementService } from './../../../../services/partitionmanagement/partitionmanagement.service';
import { TabDirective } from 'ngx-bootstrap/tabs';
import { TabsetComponent } from 'ngx-bootstrap';

declare var $: any;
declare var jQuery: any;
@Component({
  selector: 'app-monitor-stats',
  templateUrl: './monitor-stats.component.html',
  styleUrls: ['./monitor-stats.component.css']
})
export class MonitorStatsComponent implements OnInit {
  @ViewChild('monitorModal3') monitorModal3: ModalDirective;
  @ViewChild('monitorLogin3') monitorLogin3: ModalDirective;
  @ViewChild('messageModal3') messageModal3: ModalDirective;
  @ViewChild('monitorTabs') monitorTabs: TabsetComponent;
  @ViewChild('memoryTab') memoryTab: TabsetComponent;
  @Input() applianceData;
  @Input() dualFactor;
  loginForm: FormGroup;
  autenticationDetailsArray: any = [];
  loading: boolean = false;
  responseArray: any = [];
  cpuList: any = [];
  memoryList: any = [];
  pcpuList: any = [];
  isMemoryUsage: boolean = true;
  savedLoginCredentails: any = {};
  downloadError: string = '';
  constructor(private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _formBuilder: FormBuilder,
    private _service: AppliancemanagementService,
    private _service1: PartitionManagementService) { }

  ngOnInit() {
    this.cpuList = [];
    this.memoryList = [];
    this.pcpuList = [];
    this.createLoginForm();
  }
  createLoginForm() {
    this.loginForm = this._formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      dualFactorAuthServerPortNo:[''],
      certificateFile: [""],
      keyFile: [""],
      certificateName: [''],
      certificateExtension: [''],
      certificateContent: [''],
      keyfileName: [''],
      keyfileExtension: [''],
      keyfileContent: ['']
    });
  }

  public formValidationFields1 = {
    "username": '',
    "password": '',
    "dualFactorAuthServerPortNo":''
  }
  isFieldValid1(field: string) {
    if (this.loginForm.get(field).touched) {
      this.formValidationFields1 = this._fieldErrorDisplayService.validateField(this.loginForm, field, this.formValidationFields1, "login")
    }
    return !this.loginForm.get(field).valid && this.loginForm.get(field).touched;
  }

  displayFieldCss1(field: string) {
    return {
      'has-error': this.isFieldValid1(field),
      'has-feedback': this.isFieldValid1(field)
    };
  }

  showMonitorStats() {
    this.isMemoryUsage = true;
    this.savedLoginCredentails = null;
    this.cpuList = [];
    this.memoryList = [];
    this.pcpuList = [];
    this.loginForm.reset();
    this.getMonitorStatsDetails();
    // let loginCredentials = JSON.parse(localStorage.getItem(this.applianceData.ipAddress));
    // if (loginCredentials != null) {
    //   this.savedLoginCredentails = {};
    //   this.savedLoginCredentails['operationUsername'] = loginCredentials.username;
    //   this.savedLoginCredentails['operationPassword'] = loginCredentials.password;
    //   this.getMonitorStatsDetails();
    // } else {
    //   this.setValidationDualFactorAuthentication();
    //   this.monitorLogin3.show();
    // }
  }

  submitLoginDetails() {
    let loginDetailsModal = {};
    loginDetailsModal['applianceId'] = this.applianceData.applianceId;
    loginDetailsModal['applianceName'] = this.applianceData.applianceName;
    loginDetailsModal['ipAddress'] = this.applianceData.ipAddress;
    loginDetailsModal['operationUsername'] = this.loginForm.get('username').value;
    loginDetailsModal['operationPassword'] = this.loginForm.get('password').value;
    loginDetailsModal['applianceDualFactorInitialized'] = this.dualFactor;
    let dualFactorCheck = this.dualFactor;
    if(dualFactorCheck){
      loginDetailsModal=this.setDualFactorData(loginDetailsModal);
    }
    this.autenticationDetailsArray.push(loginDetailsModal);
    this.checkAppliancesCredentials();
  }

  checkAppliancesCredentials() {
    this.loading = true;
    this.responseArray = [];
    this.monitorLogin3.hide();
    this._service.checkAppliancesCredentials(this.autenticationDetailsArray).subscribe(
      (response) => {
        this.loading = false;
        let isSuccess: boolean = true;
        this.autenticationDetailsArray = [];
        response.forEach(obj => {
          if (obj.code != null) {
            if (obj.code != "200") {
              if (obj.code == "408") {
                this.downloadError = obj.errorMessage;
              } else {
                this.responseArray.push(obj);
              }
              isSuccess = false;
            } else {
              // Storing appliance login credentials in local session
              let ipAddress = obj.ipAddress;
              let loginCredentials = {
                username: this.loginForm.get('username').value,
                password: this.loginForm.get('password').value
              };
              localStorage.setItem(ipAddress, JSON.stringify(loginCredentials));
              // local session code ends here
            }
          } else {
            isSuccess = false;
            this.downloadError = "Operation can not perform due to connection error";
          }
        });
        if (isSuccess) {
          this.getMonitorStatsDetails();
        } else {
          this.messageModal3.show();
        }
      },
      (error) => {
        console.log(error);
      })
  }

  getMonitorStatsDetails() {
    let applianceArray = this.setValuesToGetData();
    this._service1.getPartitionMonitorStatsDetails(applianceArray).subscribe(
      (response) => {
        response.forEach(resp => {
          if (resp.code == "200") {
            this.downloadError = '';
            let res1 = JSON.parse(resp.message);
            if (res1.cpu != null && res1.cpu != '') {
              this.cpuList = res1.cpu;
            }
            if (res1.memory != null && res1.memory != '') {
              this.memoryList = res1.memory;
            }
            if (res1.pcpu != null && res1.pcpu != '') {
              this.pcpuList = res1.pcpu;
            }
            this.monitorModal3.show();
          } else {
            this.responseArray = [];
            this.downloadError = resp.errorMessage;
            this.messageModal3.show();
          }

        });

      },
      (error) => {
        console.log(error);
      }
    )
  }

  setValuesToGetData() {
    let applianceData = {
      'partitionName': this.applianceData.partitionName,
      'partitionId': this.applianceData.partitionId,
      'sessionClose': 0,
      'username': '',
      'password': '',
      'applianceDetailModel': {
        'applianceId': this.applianceData.applianceId,
        'applianceName': this.applianceData.applianceName,
        'ipAddress': this.applianceData.ipAddress
      }
    };
    if (this.savedLoginCredentails != null) {
      applianceData['username'] = this.savedLoginCredentails.operationUsername;
      applianceData['password'] = this.savedLoginCredentails.operationPassword;
    } else {
      applianceData['username'] = this.loginForm.get('username').value;
      applianceData['password'] = this.loginForm.get('password').value;
    }
    let applianceArray: any = [];
    applianceArray.push(applianceData);
    return applianceArray;
  }

  showUsage() {
    this.isMemoryUsage = true;
  }
  showDetails() {
    this.isMemoryUsage = false;
  }

  setDualFactorData(loginDetailsModal) {
    loginDetailsModal['initializeDetailModel'] = {};
    loginDetailsModal['initializeDetailModel']['cryptoOfficerName'] = this.loginForm.get('username').value;
    loginDetailsModal['initializeDetailModel']['cryptoOfficerPassword'] = this.loginForm.get('password').value;
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel'] = {};

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['dualFactorAuthServerPortNo'] = this.loginForm.get('dualFactorAuthServerPortNo').value;
    // certificate file details
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateContent'] = this.loginForm.get('certificateContent').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateName'] = this.loginForm.get('certificateName').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateExtension'] = this.loginForm.get('certificateExtension').value;
    // key file details
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileContent'] = this.loginForm.get('keyfileContent').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileName'] = this.loginForm.get('keyfileName').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileExtension'] = this.loginForm.get('keyfileExtension').value;
    return loginDetailsModal;
  }

  setValidationDualFactorAuthentication() {
    // set validations for dual factor properties 
    if (this.dualFactor) {
      this.loginForm.get('dualFactorAuthServerPortNo').setValidators(Validators.required);
      this.loginForm.get('certificateFile').setValidators(Validators.required);
      this.loginForm.get('keyFile').setValidators(Validators.required);
    } else {
      this.loginForm.get('dualFactorAuthServerPortNo').setValidators(null);
      this.loginForm.get('certificateFile').setValidators(null);
      this.loginForm.get('keyFile').setValidators(null);
    }
    this.loginForm.get('dualFactorAuthServerPortNo').updateValueAndValidity();
    this.loginForm.get('certificateFile').updateValueAndValidity();
    this.loginForm.get('keyFile').updateValueAndValidity();
  }

  onCertificateFileChange($event) {
    this.loginForm.get('certificateFile').markAsTouched({ onlySelf: true });
    let file = $event.target.files[0]; 
    this.loginForm.controls['certificateFile'].setValue(file ? file.name : ''); // <-- Set Value for Validation
    const filePicked = (event.target as HTMLInputElement).files[0];
    if (filePicked != undefined) {
      const fileName = filePicked.name;
      const extension = filePicked.name.split('.').pop() || '';
      const reader = new FileReader();
      reader.onload = () => {
        if (extension == 'crt') {
          this.loginForm.get('certificateContent').setValue(reader.result);
          this.loginForm.get('certificateName').setValue(fileName.substring(0, fileName.indexOf('.')));
          this.loginForm.get('certificateExtension').setValue(extension);
        } else {
          this.loginForm.get('certificateFile').setErrors({"invalidExt":true})
         
        }
      };
      reader.readAsText(filePicked);
    } else {
      this.loginForm.get('certificateFile').setValue("");
      this.loginForm.get('certificateContent').setValue("");
      this.loginForm.get('certificateName').setValue("");
      this.loginForm.get('certificateExtension').setValue("");
      return false;
    }
  } 

  onKeyFileChange($event) {
    this.loginForm.controls['keyFile'].markAsTouched({ onlySelf: true });
    let file = $event.target.files[0]; 
    this.loginForm.controls['keyFile'].setValue(file ? file.name : ''); // <-- Set Value for Validation
    const filePicked = (event.target as HTMLInputElement).files[0];
    if (filePicked != undefined) {
      const fileName = filePicked.name;
      let ext  = filePicked.name.split('.');
      const extension =  ext[1];
      const reader = new FileReader();
      reader.onload = () => {
        if (extension == 'key') {
          this.loginForm.get('keyfileContent').setValue(reader.result);
          this.loginForm.get('keyfileName').setValue(fileName.substring(0, fileName.indexOf('.')));
          this.loginForm.get('keyfileExtension').setValue(extension);
        } else {
          this.loginForm.get('keyFile').setErrors({"invalidExt":true})
         
        }
      };
      reader.readAsText(filePicked);
    } else {
      this.loginForm.get('keyFile').setValue("");
      this.loginForm.get('keyfileContent').setValue("");
      this.loginForm.get('keyfileName').setValue("");
      this.loginForm.get('keyfileExtension').setValue("");
      return false;
    }
  } 
	  
}
