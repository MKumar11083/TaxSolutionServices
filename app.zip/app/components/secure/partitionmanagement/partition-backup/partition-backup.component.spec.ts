import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PartitionBackupComponent } from './partition-backup.component';

describe('PartitionBackupComponent', () => {
  let component: PartitionBackupComponent;
  let fixture: ComponentFixture<PartitionBackupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PartitionBackupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PartitionBackupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
