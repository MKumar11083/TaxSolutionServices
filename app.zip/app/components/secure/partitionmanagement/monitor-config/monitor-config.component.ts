import { Component, OnInit, ViewChild, Input,ElementRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { PartitionManagementService } from './../../../../services/partitionmanagement/partitionmanagement.service';
import * as Hammer from 'hammerjs';
import { saveAs } from 'file-saver';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
declare var $: any;
declare var jQuery: any;
@Component({
  selector: 'app-monitor-config',
  templateUrl: './monitor-config.component.html',
  styleUrls: ['./monitor-config.component.css']
})
export class MonitorConfigComponent implements OnInit {
  @ViewChild('certificate') certificateVariable : ElementRef;
  @ViewChild('key') keyVariable: ElementRef;
  @ViewChild('monitorModal2') monitorModal2: ModalDirective;
  @ViewChild('messageModal2') messageModal2: ModalDirective;
  @ViewChild('monitorLogin2') monitorLogin2: ModalDirective;
  name: string;
  @Input() applianceData;
  @Input() dualFactor;
  monitorModel: any = {};
  operation: string = '';
  info: string = '';
  warning: string = '';
  applianceDualFactorInitialized:any;
  critical: string = '';
  isInfo: boolean = true;
  isWarning: boolean = false;
  isCritical: boolean = false;
  loading: boolean = false;
  responseArray: any = [];
  downloadError: string = '';
  loginForm: FormGroup;
  autenticationDetailsArray: any = [];
  savedLoginCredentails :any ={};
  constructor(private _service: AppliancemanagementService,
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _formBuilder: FormBuilder,
    private _serivce1: PartitionManagementService) { }

  ngOnInit() {
    this.monitorModel = this.createMonitorDataJSON();
    this.createLoginForm();
    $(document).ready(function () {
      $("div.bhoechie-tab-menu>div.list-group>a").click(function (e) {
        e.preventDefault();
        $(this).siblings('a.active').removeClass("active");
        $(this).addClass("active");
        var index = $(this).index();
        $("div.bhoechie-tab>div.bhoechie-tab-content").removeClass("active");
        $("div.bhoechie-tab>div.bhoechie-tab-content").eq(index).addClass("active");
      });
      $("div.bhoechie-tab-menu>div.list-group1>a").click(function (e) {
        e.preventDefault();
        $(this).siblings('a.active').removeClass("active");
        $(this).addClass("active");
        var index = $(this).index();
        $("div.bhoechie-tab>div.bhoechie-tab-content1").removeClass("active");
        $("div.bhoechie-tab>div.bhoechie-tab-content1").eq(index).addClass("active");
      });
      $("div.bhoechie-tab-menu>div.list-group2>a").click(function (e) {
        e.preventDefault();
        $(this).siblings('a.active').removeClass("active");
        $(this).addClass("active");
        var index = $(this).index();
        $("div.bhoechie-tab>div.bhoechie-tab-content2").removeClass("active");
        $("div.bhoechie-tab>div.bhoechie-tab-content2").eq(index).addClass("active");
      });
    });
  }
  createMonitorDataJSON() {
    let modal = {
      "partitionId": "",
      "partitionName": "",
      "username": "",
      "password": "",
      "credentialSaved": false,
      "sessionClose": false,
      "enableCavServer": false,
      "applianceDetailModel": {
        "applianceId": "",
        "applianceName": "",
        "ipAddress": ""

      },
      "partitionMonitorData": {
        "cpu": {
          "info": this.getFields(),
          "warn": this.getFields(),
          "crit": this.getFields()
        },
        "pcpu": {
          "info": this.getFields(),
          "warn": this.getFields(),
          "crit": this.getFields()
        },
        "memory": {
          "info": this.getFields(),
          "warn": this.getFields(),
          "crit": this.getFields()
        },
        "network": {
          "interfacename": ''
        }
      }
    }
    return modal;
  }

  getFields() {
    let fields = {
      'start': 'no',
      'threshold': '1',
      'samplecount': '1',
      'isDisabled': true,
      'isChecked': false
    }
    return fields;
  }

  showMonitorLogin() {
    this.savedLoginCredentails = null;
    this.clearDetails();
    this.loginForm.reset();
    if (this.applianceData.credentialSaved == true) {
      this.getMonitorDetails();
    }else{
      let loginCredentials = JSON.parse(localStorage.getItem(this.applianceData.ipAddress));
      if (loginCredentials != null) {
        this.savedLoginCredentails = {};
        this.savedLoginCredentails['operationUsername'] = loginCredentials.username;
        this.savedLoginCredentails['operationPassword'] = loginCredentials.password;
        this.getMonitorDetails();
      } else{
        this.setValidationDualFactorAuthentication();
        this.monitorLogin2.show();
      }
    }
  }
  submitLoginDetails() {
    let loginDetailsModal = {};
    loginDetailsModal['applianceId'] = this.applianceData.applianceId;
    loginDetailsModal['applianceName'] = this.applianceData.applianceName;
    loginDetailsModal['ipAddress'] = this.applianceData.ipAddress;
    loginDetailsModal['operationUsername'] = this.loginForm.get('username').value;
    loginDetailsModal['operationPassword'] = this.loginForm.get('password').value;
    loginDetailsModal['applianceDualFactorInitialized'] = this.dualFactor;
    let dualFactorCheck = this.dualFactor;
    if(dualFactorCheck){
      loginDetailsModal=this.setDualFactorData(loginDetailsModal);
    }
    this.autenticationDetailsArray.push(loginDetailsModal);
    this.checkAppliancesCredentials();
  }

  checkAppliancesCredentials() {
    if(this.dualFactor){
      this.certificateVariable.nativeElement.value = '';
      this.keyVariable.nativeElement.value = "";
    }
    this.loading = true;
    this.responseArray = [];
    this.monitorLogin2.hide();
    this._service.checkAppliancesCredentials(this.autenticationDetailsArray).subscribe(
      (response) => {
        this.loading = false;
        let isSuccess: boolean = true;
        this.autenticationDetailsArray = [];
        response.forEach(obj => {
          if(obj.code!=null){
            if (obj.code != "200") {
              if(obj.code == "408"){
                this.downloadError = obj.errorMessage;
              }else{
                this.responseArray.push(obj);
              }
              isSuccess = false;
            } else {
              // Storing appliance login credentials in local session
              let ipAddress = obj.ipAddress;
              let loginCredentials = {
                username: this.loginForm.get('username').value,
                password: this.loginForm.get('password').value
              };
              localStorage.setItem(ipAddress, JSON.stringify(loginCredentials));
              // local session code ends here
            }
          }else{
            isSuccess = false;
            this.downloadError = "Operation can not perform due to connection error";
          }
        });
        if (isSuccess) {
          this.getMonitorDetails();
        } else {
          this.messageModal2.show();
        }
      },
      (error) => {
        console.log(error);
      })
  }
  getMonitorDetails() {
    this.isInfo = true;
    this.info = "btn-primary";
    this.warning = "btn-default";
    this.critical = "btn-default";
    //this.name = value;
    let applianceArray = this.setValuesToGetData();
    this._serivce1.getPartitionMonitorDetails(applianceArray).subscribe(
      (response) => {
        this.setMonitorDataToModel(response);
        
      }
    )
  }

  clearDetails() {
    this.name = '';
    this.monitorModel = this.createMonitorDataJSON();
    this.operation = '';
    this.info = '';
    this.warning = '';
    this.critical = '';
    this.isInfo = true;
    this.isWarning = false;
    this.isCritical = false;
    // this.isNetwork = false;
    this.loading = false;
    this.responseArray = [];
    this.downloadError = '';
  }

  setValuesToGetData() {
    let applianceData = {
      'partitionName': this.applianceData.partitionName,
      'partitionId': this.applianceData.partitionId,
      'sessionClose': 0,
      'username': '',
      'password': '',
      'applianceDetailModel': {
        'applianceId': this.applianceData.applianceId,
        'applianceName': this.applianceData.applianceName,
        'ipAddress': this.applianceData.ipAddress
      }
    };
    if(this.savedLoginCredentails!=null){
      applianceData['username'] = this.savedLoginCredentails.operationUsername;
      applianceData['password'] = this.savedLoginCredentails.operationPassword;
    }else{
      applianceData['username'] = this.loginForm.get('username').value;
      applianceData['password'] = this.loginForm.get('password').value;
    }
    let applianceArray: any = [];
    applianceArray.push(applianceData);
    return applianceArray;
  }

  setMonitorDataToModel(response) {
    this.setApplianceDetailsToModel();
    response.forEach(obj => {
      if(obj.code=="200"){
        if(obj.partitionMonitorData!=null){
          this.setMemoryDetailsToModel(obj);
          this.setCpuDetailsToModel(obj);
          this.setPcpuDetailsToModel(obj);
          this.setNetworkDetailsToModel(obj);
          this.monitorModal2.show();
        }
      }else{
        this.responseArray= [];
        this.downloadError = '';
        this.downloadError = obj.errorMessage;
        this.messageModal2.show();
      }
    
    });
  }

  setApplianceDetailsToModel() {
    // appliance data
    this.monitorModel['partitionName'] = this.applianceData.partitionName;
    this.monitorModel['partitionId'] = this.applianceData.partitionId;
    this.monitorModel['sessionClose'] = 0;
    this.monitorModel['credentialSaved'] = 0;
    this.monitorModel['enableCavServer'] = 0;
    this.monitorModel['applianceDetailModel']['applianceId'] = this.applianceData.applianceId;
    this.monitorModel['applianceDetailModel']['applianceName'] = this.applianceData.applianceName;
    this.monitorModel['applianceDetailModel']['ipAddress'] = this.applianceData.ipAddress;
    if(this.savedLoginCredentails!=null){
      this.monitorModel['username'] = this.savedLoginCredentails.operationUsername;
      this.monitorModel['password'] = this.savedLoginCredentails.operationPassword;
    }else{
      this.monitorModel['username'] = this.loginForm.get('username').value;
      this.monitorModel['password'] = this.loginForm.get('password').value;
    }
  }

  setMemoryDetailsToModel(obj) {
    // memory
    if (obj.partitionMonitorData.memory != null) {
      if (obj.partitionMonitorData.memory.crit != null) {
        if(obj.partitionMonitorData.memory.crit.samplecount!=null){
          this.monitorModel['partitionMonitorData']['memory']['crit']['samplecount'] = obj.partitionMonitorData.memory.crit.samplecount;
        }
        if(obj.partitionMonitorData.memory.crit.threshold!=null){
          this.monitorModel['partitionMonitorData']['memory']['crit']['threshold'] = obj.partitionMonitorData.memory.crit.threshold;
        }
        if(obj.partitionMonitorData.memory.crit.start!=null){
          this.monitorModel['partitionMonitorData']['memory']['crit']['start'] = obj.partitionMonitorData.memory.crit.start;
        }
        if (obj.partitionMonitorData.memory.crit.start == "yes") {
          this.monitorModel['partitionMonitorData']['memory']['crit']['isChecked'] = true;
          this.monitorModel['partitionMonitorData']['memory']['crit']['isDisabled'] = false;
        }
      }
      if (obj.partitionMonitorData.memory.warn != null) {
        if(obj.partitionMonitorData.memory.warn.samplecount!=null){
          this.monitorModel['partitionMonitorData']['memory']['warn']['samplecount'] = obj.partitionMonitorData.memory.warn.samplecount;
        }
        if(obj.partitionMonitorData.memory.warn.threshold!=null){
          this.monitorModel['partitionMonitorData']['memory']['warn']['threshold'] = obj.partitionMonitorData.memory.warn.threshold;
        }
        if(obj.partitionMonitorData.memory.warn.start!=null){
          this.monitorModel['partitionMonitorData']['memory']['warn']['start'] = obj.partitionMonitorData.memory.warn.start;
        }
        if (obj.partitionMonitorData.memory.warn.start == "yes") {
          this.monitorModel['partitionMonitorData']['memory']['warn']['isChecked'] = true;
          this.monitorModel['partitionMonitorData']['memory']['warn']['isDisabled'] = false;
        }
      }
      if (obj.partitionMonitorData.memory.info != null) {
        if(obj.partitionMonitorData.memory.info.samplecount!=null){
          this.monitorModel['partitionMonitorData']['memory']['info']['samplecount'] = obj.partitionMonitorData.memory.info.samplecount;
        }
        if(obj.partitionMonitorData.memory.info.threshold!=null){
          this.monitorModel['partitionMonitorData']['memory']['info']['threshold'] = obj.partitionMonitorData.memory.info.threshold;
        }
        if(obj.partitionMonitorData.memory.info.start!=null){
          this.monitorModel['partitionMonitorData']['memory']['info']['start'] = obj.partitionMonitorData.memory.info.start;
        }
        if (obj.partitionMonitorData.memory.info.start == "yes") {
          this.monitorModel['partitionMonitorData']['memory']['info']['isChecked'] = true;
          this.monitorModel['partitionMonitorData']['memory']['info']['isDisabled'] = false;
        }
      }
    }
  }

  setCpuDetailsToModel(obj) {
    // cpu
    if (obj.partitionMonitorData.cpu != null) {
      if (obj.partitionMonitorData.cpu.crit != null) {
        if(obj.partitionMonitorData.cpu.crit.samplecount!=null){
          this.monitorModel['partitionMonitorData']['cpu']['crit']['samplecount'] = obj.partitionMonitorData.cpu.crit.samplecount;
        }
        if(obj.partitionMonitorData.cpu.crit.threshold!=null){
          this.monitorModel['partitionMonitorData']['cpu']['crit']['threshold'] = obj.partitionMonitorData.cpu.crit.threshold;
        }
        if(obj.partitionMonitorData.cpu.crit.start!=null){
          this.monitorModel['partitionMonitorData']['cpu']['crit']['start'] = obj.partitionMonitorData.cpu.crit.start;
        }
        if (obj.partitionMonitorData.cpu.crit.start == "yes") {
          this.monitorModel['partitionMonitorData']['cpu']['crit']['isChecked'] = true;
          this.monitorModel['partitionMonitorData']['cpu']['crit']['isDisabled'] = false;
        }
      }
      if (obj.partitionMonitorData.cpu.warn != null) {
        if(obj.partitionMonitorData.cpu.warn.samplecount!=null){
          this.monitorModel['partitionMonitorData']['cpu']['warn']['samplecount'] = obj.partitionMonitorData.cpu.warn.samplecount;
        }
        if(obj.partitionMonitorData.cpu.warn.threshold!=null){
          this.monitorModel['partitionMonitorData']['cpu']['warn']['threshold'] = obj.partitionMonitorData.cpu.warn.threshold;
        }
        if(obj.partitionMonitorData.cpu.warn.start!=null){
          this.monitorModel['partitionMonitorData']['cpu']['warn']['start'] = obj.partitionMonitorData.cpu.warn.start;
        }
        if (obj.partitionMonitorData.cpu.warn.start == "yes") {
          this.monitorModel['partitionMonitorData']['cpu']['warn']['isChecked'] = true;
          this.monitorModel['partitionMonitorData']['cpu']['warn']['isDisabled'] = false;
        }
      }
      if (obj.partitionMonitorData.cpu.info != null) {
        if(obj.partitionMonitorData.cpu.info.samplecount!=null){
          this.monitorModel['partitionMonitorData']['cpu']['info']['samplecount'] = obj.partitionMonitorData.cpu.info.samplecount;
        }
        if(obj.partitionMonitorData.cpu.info.threshold!=null){
          this.monitorModel['partitionMonitorData']['cpu']['info']['threshold'] = obj.partitionMonitorData.cpu.info.threshold;
        }
        if(obj.partitionMonitorData.cpu.info.start!=null){
          this.monitorModel['partitionMonitorData']['cpu']['info']['start'] = obj.partitionMonitorData.cpu.info.start;
        }
        if (obj.partitionMonitorData.cpu.info.start == "yes") {
          this.monitorModel['partitionMonitorData']['cpu']['info']['isChecked'] = true;
          this.monitorModel['partitionMonitorData']['cpu']['info']['isDisabled'] = false;
        }
      }
    }
  }

  setPcpuDetailsToModel(obj) {
    // pcpu
    if (obj.partitionMonitorData.pcpu != null) {
      if (obj.partitionMonitorData.pcpu.crit != null) {
        if(obj.partitionMonitorData.pcpu.crit.samplecount!=null){
          this.monitorModel['partitionMonitorData']['pcpu']['crit']['samplecount'] = obj.partitionMonitorData.pcpu.crit.samplecount;
        }
        if(obj.partitionMonitorData.pcpu.crit.threshold!=null){
          this.monitorModel['partitionMonitorData']['pcpu']['crit']['threshold'] = obj.partitionMonitorData.pcpu.crit.threshold;
        }
        if(obj.partitionMonitorData.pcpu.crit.start!=null){
          this.monitorModel['partitionMonitorData']['pcpu']['crit']['start'] = obj.partitionMonitorData.pcpu.crit.start;
        }
        if (obj.partitionMonitorData.pcpu.crit.start == "yes") {
          this.monitorModel['partitionMonitorData']['pcpu']['crit']['isChecked'] = true;
          this.monitorModel['partitionMonitorData']['pcpu']['crit']['isDisabled'] = false;
        }
      }
      if (obj.partitionMonitorData.pcpu.warn != null) {
        if(obj.partitionMonitorData.pcpu.warn.samplecount!=null){
          this.monitorModel['partitionMonitorData']['pcpu']['warn']['samplecount'] = obj.partitionMonitorData.pcpu.warn.samplecount;
        }
        if(obj.partitionMonitorData.pcpu.warn.threshold!=null){
          this.monitorModel['partitionMonitorData']['pcpu']['warn']['threshold'] = obj.partitionMonitorData.pcpu.warn.threshold;
        }
        if(obj.partitionMonitorData.pcpu.warn.start!=null){
          this.monitorModel['partitionMonitorData']['pcpu']['warn']['start'] = obj.partitionMonitorData.pcpu.warn.start;
        }
        if (obj.partitionMonitorData.pcpu.warn.start == "yes") {
          this.monitorModel['partitionMonitorData']['pcpu']['warn']['isChecked'] = true;
          this.monitorModel['partitionMonitorData']['pcpu']['warn']['isDisabled'] = false;
        }
      }
      if (obj.partitionMonitorData.pcpu.info != null) {
        if(obj.partitionMonitorData.pcpu.info.samplecount!=null){
          this.monitorModel['partitionMonitorData']['pcpu']['info']['samplecount'] = obj.partitionMonitorData.pcpu.info.samplecount;
        }
        if(obj.partitionMonitorData.pcpu.info.threshold!=null){
          this.monitorModel['partitionMonitorData']['pcpu']['info']['threshold'] = obj.partitionMonitorData.pcpu.info.threshold;
        }
        if(obj.partitionMonitorData.pcpu.info.start!=null){
          this.monitorModel['partitionMonitorData']['pcpu']['info']['start'] = obj.partitionMonitorData.pcpu.info.start;
        }
        if (obj.partitionMonitorData.pcpu.info.start == "yes") {
          this.monitorModel['partitionMonitorData']['pcpu']['info']['isChecked'] = true;
          this.monitorModel['partitionMonitorData']['pcpu']['info']['isDisabled'] = false;
        }
      }
    }
  }

  setNetworkDetailsToModel(obj) {
    if (obj.partitionMonitorData.network != null) {
      if (obj.partitionMonitorData.network.interfacename != null) {
        this.monitorModel['partitionMonitorData']['network']['interfacename'] = obj.partitionMonitorData.network.interfacename;
      }
    }
  }

  changeOperation(operation) {
    if (operation == "info") {
      this.info = "btn-primary";
      this.warning = "btn-default";
      this.critical = "btn-default";
      this.isInfo = true;
      this.isWarning = false;
      this.isCritical = false;
    } else if (operation == "warning") {
      this.info = "btn-default";
      this.warning = "btn-primary";
      this.critical = "btn-default";
      this.isInfo = false;
      this.isWarning = true;
      this.isCritical = false;
    } else if (operation == "critical") {
      this.info = "btn-default";
      this.warning = "btn-default";
      this.critical = "btn-primary";
      this.isInfo = false;
      this.isWarning = false;
      this.isCritical = true;
    }
  }

  enableSlider(event, value, value1) {
    if (event.checked) {
      this.monitorModel['partitionMonitorData'][value1][value]['isDisabled'] = false;
      this.monitorModel['partitionMonitorData'][value1][value]['start'] = "yes";
    } else {
      this.monitorModel['partitionMonitorData'][value1][value]['isDisabled'] = true;
      this.monitorModel['partitionMonitorData'][value1][value]['start'] = "no";
    }

  }

  submitMonitorDetails() {
    this.downloadError = '';
    this.responseArray = [];
    let applianceModelArray = [];
    applianceModelArray.push(this.monitorModel);
    this.loading = true;
    this._serivce1.setPartitionMonitorData(applianceModelArray).subscribe(
      (response) => {
        this.loading = false;
        this.monitorModal2.hide();
        this.messageModal2.show();
        this.responseArray = response;
      },
      (error) => {
        this.loading = false;
        console.log(error);
      }
    )

  }


  formatLabel(value: number | null) {
    if (!value) {
      return 0;
    }

    if (value >= 100) {
      return Math.round(value / 100) + 'k';
    }

    return value;
  }

  downloadLogs() {
    this.loading = true;
    this.downloadError = '';
    this.responseArray = [];
    let applianceData = this.setValuesToGetDownloadLogs();
    this._service.downloadLogsForAppliance(applianceData).subscribe(
      (response) => {
        this.loading = false;
        this.downloadFile(response);
      },
      (error) => {
        this.loading = false;
        console.log(error);
      }

    )
  }
  setValuesToGetDownloadLogs() {
    let data = {
      "applianceId": this.applianceData.applianceId,
      "applianceName": this.applianceData.applianceName,
      "ipAddress": this.applianceData.ipAddress,
      "monitorType": "partition",
      "operationUsername": '',
      "operationPassword": '',
      "partitionDetailModels": [
        {
          "partitionId": this.applianceData.partitionId,
          "partitionName": this.applianceData.partitionName,

        }]
    }
    if(this.savedLoginCredentails!=null){
      data['operationUsername'] = this.savedLoginCredentails.operationUsername;
      data['operationPassword'] = this.savedLoginCredentails.operationPassword;
    }else{
      data['operationUsername'] = this.loginForm.get('username').value;
      data['operationPassword'] = this.loginForm.get('password').value;
    }
    return data;
  }
  downloadFile(response) {
    const contentType = response.headers.get('Content-Type');
    if (contentType != 'text/html;charset=ISO-8859-1' && contentType != null) {
      const contentDispositionHeader: string = response.headers.get('Content-Disposition');
      if (contentDispositionHeader != null) {
        this.loading = false;
        const parts: string[] = contentDispositionHeader.split(';');
        const filename = parts[1].split('=')[1];
        const blob = new Blob([response._body], { type: response.headers.get('Content-Type') });
        saveAs(blob, filename);
      }
    } else {
      let res = JSON.stringify(response);
      let res1 = JSON.parse(res);
      this.downloadError = res1._body;
      this.messageModal2.show();
    }
  }

  createLoginForm() {
    this.loginForm = this._formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      dualFactorAuthServerPortNo:[''],
      certificateFile: [""],
      keyFile: [""],
      certificateName: [''],
      certificateExtension: [''],
      certificateContent: [''],
      keyfileName: [''],
      keyfileExtension: [''],
      keyfileContent: ['']
    });
  }

  public formValidationFields1 = {
    "username": '',
    "password": '',
    "dualFactorAuthServerPortNo":''
  }
  isFieldValid1(field: string) {
    if (this.loginForm.get(field).touched) {
      this.formValidationFields1 = this._fieldErrorDisplayService.validateField(this.loginForm, field, this.formValidationFields1, "login")
    }
    return !this.loginForm.get(field).valid && this.loginForm.get(field).touched;
  }

  displayFieldCss1(field: string) {
    return {
      'has-error': this.isFieldValid1(field),
      'has-feedback': this.isFieldValid1(field)
    };
  }
  setDualFactorData(loginDetailsModal) {
    loginDetailsModal['initializeDetailModel'] = {};
    loginDetailsModal['initializeDetailModel']['cryptoOfficerName'] = this.loginForm.get('username').value;
    loginDetailsModal['initializeDetailModel']['cryptoOfficerPassword'] = this.loginForm.get('password').value;
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel'] = {};

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['dualFactorAuthServerPortNo'] = this.loginForm.get('dualFactorAuthServerPortNo').value;
    // certificate file details
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateContent'] = this.loginForm.get('certificateContent').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateName'] = this.loginForm.get('certificateName').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateExtension'] = this.loginForm.get('certificateExtension').value;
    // key file details
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileContent'] = this.loginForm.get('keyfileContent').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileName'] = this.loginForm.get('keyfileName').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileExtension'] = this.loginForm.get('keyfileExtension').value;
    return loginDetailsModal;
  }

  setValidationDualFactorAuthentication() {
    // set validations for dual factor properties 
    if (this.dualFactor) {
      this.loginForm.get('dualFactorAuthServerPortNo').setValidators(Validators.required);
      this.loginForm.get('certificateFile').setValidators(Validators.required);
      this.loginForm.get('keyFile').setValidators(Validators.required);
    } else {
      this.loginForm.get('dualFactorAuthServerPortNo').setValidators(null);
      this.loginForm.get('certificateFile').setValidators(null);
      this.loginForm.get('keyFile').setValidators(null);
    }
    this.loginForm.get('dualFactorAuthServerPortNo').updateValueAndValidity();
    this.loginForm.get('certificateFile').updateValueAndValidity();
    this.loginForm.get('keyFile').updateValueAndValidity();
  }

  onCertificateFileChange($event) {
    this.loginForm.get('certificateFile').markAsTouched({ onlySelf: true });
    let file = $event.target.files[0]; 
    this.loginForm.controls['certificateFile'].setValue(file ? file.name : ''); // <-- Set Value for Validation
    const filePicked = (event.target as HTMLInputElement).files[0];
    if (filePicked != undefined) {
      const fileName = filePicked.name;
      const extension = filePicked.name.split('.').pop() || '';
      const reader = new FileReader();
      reader.onload = () => {
        if (extension == 'crt') {
          this.loginForm.get('certificateContent').setValue(reader.result);
          this.loginForm.get('certificateName').setValue(fileName.substring(0, fileName.indexOf('.')));
          this.loginForm.get('certificateExtension').setValue(extension);
        } else {
          this.loginForm.get('certificateFile').setErrors({"invalidExt":true})
         
        }
      };
      reader.readAsText(filePicked);
    } else {
      this.loginForm.get('certificateFile').setValue("");
      this.loginForm.get('certificateContent').setValue("");
      this.loginForm.get('certificateName').setValue("");
      this.loginForm.get('certificateExtension').setValue("");
      return false;
    }
  } 

  onKeyFileChange($event) {
    this.loginForm.controls['keyFile'].markAsTouched({ onlySelf: true });
    let file = $event.target.files[0]; 
    this.loginForm.controls['keyFile'].setValue(file ? file.name : ''); // <-- Set Value for Validation
    const filePicked = (event.target as HTMLInputElement).files[0];
    if (filePicked != undefined) {
      const fileName = filePicked.name;
      let ext  = filePicked.name.split('.');
      const extension =  ext[1];
      const reader = new FileReader();
      reader.onload = () => {
        if (extension == 'key') {
          this.loginForm.get('keyfileContent').setValue(reader.result);
          this.loginForm.get('keyfileName').setValue(fileName.substring(0, fileName.indexOf('.')));
          this.loginForm.get('keyfileExtension').setValue(extension);
        } else {
          this.loginForm.get('keyFile').setErrors({"invalidExt":true})
         
        }
      };
      reader.readAsText(filePicked);
    } else {
      this.loginForm.get('keyFile').setValue("");
      this.loginForm.get('keyfileContent').setValue("");
      this.loginForm.get('keyfileName').setValue("");
      this.loginForm.get('keyfileExtension').setValue("");
      return false;
    }
  } 
	  
}
