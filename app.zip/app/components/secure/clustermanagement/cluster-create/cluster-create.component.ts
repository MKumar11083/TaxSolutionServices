import { Component, OnInit, Output, EventEmitter, Input, ViewChild, ElementRef } from '@angular/core';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { Router } from '@angular/router';
import { ApplianceLoginComponent } from './../../appliancemanagement/appliance-login/appliance-login.component';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { ifError } from 'assert';
import { AnonymousSubscription } from "rxjs/Subscription";
import { PartitionManagementService } from './../../../../services/partitionmanagement/partitionmanagement.service';
import { CreateClusterComponent } from './../../clustermanagement/create-cluster/create-cluster.component';

declare var $: any;
declare var jQuery: any;
declare var bootbox: any;

@Component({
  selector: 'app-cluster-create',
  templateUrl: './cluster-create.component.html',
  styleUrls: ['./cluster-create.component.css']
})
export class ClusterCreateComponent implements OnInit {
  @ViewChild('partitionLoginModal')
  partitionLoginModal: ModalDirective;
  @ViewChild('confirmModal')
  confirmModal: ModalDirective;
  @ViewChild('messageModal')
  messageModal: ModalDirective;
  @ViewChild('createClusterComponent')
  private createClusterComponent: CreateClusterComponent;
  @ViewChild("username") userNameField: ElementRef;
  listofAppliancesSubscription: AnonymousSubscription;
  selectedAppliances: any = [];
  selectedPartitions: any = [];
  allAppliances: any = [];
  loginForm: FormGroup;
  @Output() messageEvent = new EventEmitter<String>();
  unselectedAppliancesList: any = [];

  partitionList: any = [];
  message: string;
  partOfClusterPartitions: string;
  partitionMap: Map<string, Array<any>>;
  credentialsSavedPartitionList = [];
  nonCredentialSavedParitionList = [];
  partitionName: string;
  partitionCount = 1;
  totalpartitionCount = 0;
  isLastPartition: boolean = false;
  finalPartitionList = [];
  partitionOperation: string;
  isCreateClusterShow: boolean = false;
  errorMessage: string = '';
  errorMessage1: string = '';
  isPartOfCluster = false;
  loading = false;
  loginCredentialsArray: any = [];
  appliancesList: any = [];
  checkLoginCredentialsResultArray: any = [];
  saveCredentialsToSessionArray: any = [];
  isNoAppliance: boolean = false;
  applianceDualFactorInitialized: boolean = false;
  dualFactorMap = new Map<string, boolean>();
  @ViewChild('certificate') certificateVariable: ElementRef;
  @ViewChild('key') keyVariable: ElementRef;
  constructor(private _applianceManagementService: AppliancemanagementService,
    private _router: Router, private _formBuilder: FormBuilder,
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _partitionManagementService: PartitionManagementService) { }

  ngOnInit() {
    this.loadingListAppliances();
    // this.unselectedAppliancesList = this.allAppliances;
    this.isNoAppliance = false;
    this.createLoginForm();
    this.isCreateClusterShow = false;
  }
  createSelectedAppliancesList(res) {
    this.appliancesList = [];
    if (res.length > 0) {
      res.forEach(obj => {
        if (obj.applianceStatus != 'Inactive') {
          let applianceObj = {
            "partitionList": []
          };
          applianceObj["appName"] = obj.applianceName;
          applianceObj["appId"] = obj.applianceId;
          applianceObj["status"] = obj.applianceStatus;
          applianceObj["ipAddress"] = obj.ipAddress;
          applianceObj["zoneId"] = obj.zoneId;
          applianceObj['applianceDualFactorInitialized'] = obj.applianceDualFactorInitialized;
          let usedSize: number = 0;
          let availableSize: number = 0;
          let partitionSize: number = 0;
          let partitionTotalKeys: number = 0;
          let partitionTotalSSLCtxt: number = 0;
          let partitionTotalAccDev: number = 0;
          if (obj.partitionDetailModels != null && obj.partitionDetailModels != "undefined") {
            obj.partitionDetailModels.forEach(partitionObj => {
              let partition = {};
              if (partitionObj.partitionName != null) {
                partition["name"] = partitionObj.partitionName;
              }
              if (partitionObj.partitionData != null) {
                partition['noPartitionData'] = false;
                if (partitionObj.partitionData.maxKeys != null) {
                  partition["key"] = partitionObj.partitionData.maxKeys;
                }
                if (partitionObj.partitionData.totalSslCtxs != null) {
                  partition["sslContexts"] = partitionObj.partitionData.totalSslCtxs;
                }
                if (partitionObj.partitionData.maxAcclrDevCount != null) {
                  partition["acclrDev"] = partitionObj.partitionData.maxAcclrDevCount;
                }
                if (partitionObj.partitionData.nodeId != null) {
                  partition['nodeID'] = partitionObj.partitionData.nodeId;
                }
                if (partitionObj.partitionData.fipsState != null) {
                  partition['fipsState'] = partitionObj.partitionData.fipsState;
                  if (partitionObj.partitionData.fipsState == "2 [FIPS mode with single factor authentication]") {
                    partition['fipsState'] = "Initialized"
                  }
                  else if (partitionObj.partitionData.fipsState == "3 [FIPS mode with two factor authentication]") {
                    partition['fipsState'] = "2F Initialized"
                  }

                  else if (partitionObj.partitionData.fipsState == "-1 [zeroized]") {
                    partition['fipsState'] = "Zeroized"
                  }
                  else {
                    partition['fipsState'] = "---"
                  }
                }
                partitionTotalKeys = partitionTotalKeys + partitionObj.partitionData.maxKeys;
                partitionTotalSSLCtxt = partitionTotalSSLCtxt + partitionObj.partitionData.totalSslCtxs;
                partitionTotalAccDev = partitionTotalAccDev + partitionObj.partitionData.maxAcclrDevCount;
              } else {
                partition['noPartitionData'] = true;
              }
              if (partitionObj.partitionId != null) {
                partition["partitionID"] = partitionObj.partitionId;
              }
              if (obj.applianceId != null) {
                partition['applianceId'] = obj.applianceId;
              }
              if (partitionObj.partOfCluster != null) {
                partition['partOfCluster'] = partitionObj.partOfCluster;
                if (partition['partOfCluster'] == true) {
                  partition['clusterLink'] = "Connected";
                }
                else if (partition['partOfCluster'] == false) {
                  partition['clusterLink'] = "Available";
                }
              }
              if (partitionObj.networkStats.general.eth0.ip != null) {
                partition['ip'] = partitionObj.networkStats.general.eth0.ip;
              }
              if (partitionObj.networkStats.general.eth1.ip != null) {
                partition['ip1'] = partitionObj.networkStats.general.eth1.ip;
              }

              applianceObj.partitionList.push(partition);
            });
          }
          applianceObj["partitionTotalKeys"] = partitionTotalKeys;
          applianceObj["partitionTotalSSLCtxt"] = partitionTotalSSLCtxt;
          applianceObj["partitionTotalAccDev"] = partitionTotalAccDev;
          this.appliancesList.push(applianceObj);
        }
      });
    } else {
      this.isNoAppliance = true;
    }

  }

  loadingListAppliances() {
    this.listofAppliancesSubscription = this._applianceManagementService.getAllListAppliances().subscribe(
      res => {
        this.createSelectedAppliancesList(res);
      },
      error => {
        console.log(error);
      },
    );
  }

  createLoginForm() {
    this.loginForm = this._formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      dualFactorAuthServerPortNo: [''],
      certificateFile: [""],
      keyFile: [""],
      certificateName: [''],
      certificateExtension: [''],
      certificateContent: [''],
      keyfileName: [''],
      keyfileExtension: [''],
      keyfileContent: ['']
    });
  }
  public formValidationFields1 = {
    "username": '',
    "password": '',
    "dualFactorAuthServerPortNo": ''

  }
  closeModal() {
    $("#listappliances").modal("hide");
  }
  selectPartitionItems(event, applianceId, partitionId: string) {
    if (event.checked) {
      for (var i = 0; i < this.appliancesList.length; i++) {
        if (this.appliancesList[i].appId == applianceId) {
          let partitionList = this.appliancesList[i].partitionList;
          partitionList.forEach(obj => {

            if (obj.partitionID == partitionId) {
              let partitionModal = {};
              partitionModal['applianceId'] = this.appliancesList[i].appId;
              partitionModal['applianceName'] = this.appliancesList[i].appName;
              partitionModal['ipAddress'] = this.appliancesList[i].ipAddress;
              partitionModal['partitionId'] = obj.partitionID;
              partitionModal['partitionName'] = obj.name;
              partitionModal['partOfCluster'] = obj.partOfCluster;
              partitionModal['nodeId'] = obj.nodeID;
              partitionModal['remoteEth0Addr'] = obj.ip;
              partitionModal['remoteEth1Addr'] = obj.ip1;
              partitionModal['zoneId'] = this.appliancesList[i].zoneId;
              let dualfactor = this.appliancesList[i].applianceDualFactorInitialized;
              this.dualFactorMap.set(partitionModal['partitionId'], dualfactor);
              this.selectedPartitions.push(partitionModal); this.appliancesList[i];

            }
          });
        }
      }
    } else {
      this.dualFactorMap.delete(partitionId);
      const index = this.selectedPartitions.findIndex(partition => partition.partitionId === partitionId);
      if (index != -1) {
        this.selectedPartitions.splice(index, 1);
      }

    }
  }
  goToLoginModal(operation) {
    this.applianceDualFactorInitialized = false;
    this.confirmModal.hide();
    // this.partitionLoginModal.show();
    this.clearData();

    this.partitionMap = new Map<string, Array<any>>();
    //this.partitionOperation = operation;
    // construct map based on applianceId for selected PartitionList
    this.selectedPartitions.forEach(partitionObj => {
      let tempMap: Array<any> = [];
      if (this.partitionMap.has(partitionObj['applianceId'])) {
        tempMap = this.partitionMap.get(partitionObj['applianceId']);
      }
      tempMap.push(partitionObj);
      this.partitionMap.set(partitionObj['applianceId'], tempMap);
    });
    //construct map code ends here
    // get all the applianceIds form the map and iterate each applianceId , to 
    // identity the credentialSaved or not 
    let applianceIds = Array.from(this.partitionMap.keys());
    applianceIds.forEach(appId => {
      if (this.partitionMap.has(appId)) {
        let partitionObj = this.partitionMap.get(appId)[0];
        if (partitionObj['credentialSaved']) {
          this.credentialsSavedPartitionList.push(partitionObj);
        } else {
          // check appliance credentials are available in localsession.
          // if available in localsession , skips the login for appliance.
          let loginCredentials = JSON.parse(localStorage.getItem(partitionObj.ipAddress));
          if (loginCredentials != null) {
            partitionObj['username'] = loginCredentials.username;
            partitionObj['password'] = loginCredentials.password;
            this.saveCredentialsToSessionArray.push(partitionObj);
          } else {
            this.nonCredentialSavedParitionList.push(partitionObj);
          }
        }
        // this.credentialsSavedPartitionList.push(partitionObj);
      }
    });
    //  check the length of non credentialsaved Partition List to show the login pop.
    // if length is 0 , then show the confirm modal,whether to continue the selected Operation or not.
    if (this.nonCredentialSavedParitionList.length > 0) {
      this.partitionName = this.nonCredentialSavedParitionList[this.partitionCount - 1]['applianceName'];
      this.totalpartitionCount = this.nonCredentialSavedParitionList.length;
      // dual factor authentication
      this.applianceDualFactorInitialized = false;
      this.applianceDualFactorInitialized = this.dualFactorMap.get(this.nonCredentialSavedParitionList[this.partitionCount - 1]['partitionId']);
      this.setValidationDualFactorAuthentication();
      // ends here 
      if (this.partitionCount == this.totalpartitionCount) {
        this.isLastPartition = true;
      }
      this.partitionLoginModal.show();
    } else {
      this.goToCreateCluster();
    }

  }
  goToNextPartition() {
    this.userNameField.nativeElement.focus();
    // let applianceId = this.nonCredentialSavedParitionList[this.partitionCount - 1]['applianceId'];
    // this.createListOfPartitions(applianceId);
    let applianceObj = this.nonCredentialSavedParitionList[this.partitionCount - 1];
    this.createListOfPartitions(applianceObj, "login");
    let loginDetailsModal = {};
    loginDetailsModal['applianceId'] = applianceObj.applianceId;
    loginDetailsModal['applianceName'] = applianceObj.applianceName;
    loginDetailsModal['ipAddress'] = applianceObj.ipAddress;
    loginDetailsModal['operationUsername'] = this.loginForm.get('username').value;
    loginDetailsModal['operationPassword'] = this.loginForm.get('password').value;
    let dualFactorCheck = this.dualFactorMap.get(applianceObj.partitionId);
    loginDetailsModal['applianceDualFactorInitialized'] = dualFactorCheck;
    if (dualFactorCheck) {
      this.certificateVariable.nativeElement.value = '';
      this.keyVariable.nativeElement.value = "";
      loginDetailsModal = this.setDualFactorData(loginDetailsModal);
    }
    this.loginCredentialsArray.push(loginDetailsModal);
    // Storing appliance login credentials in local session
    let ipAddress = applianceObj.ipAddress;
    let loginCredentials = {
      username: this.loginForm.get('username').value,
      password: this.loginForm.get('password').value
    };
    localStorage.setItem(ipAddress, JSON.stringify(loginCredentials));
    if (this.partitionCount < this.nonCredentialSavedParitionList.length) {
      this.partitionName = this.nonCredentialSavedParitionList[this.partitionCount]['applianceName'];
      this.applianceDualFactorInitialized = this.dualFactorMap.get(this.nonCredentialSavedParitionList[this.partitionCount]['partitionId']);
      this.setValidationDualFactorAuthentication();
      this.partitionCount++;
      if (this.partitionCount == this.totalpartitionCount) {
        this.isLastPartition = true;
      }
    } else {
      this.partitionLoginModal.hide();
      //this.goToCreateCluster();
      this.checkAppliancesCredentials();
    }
    this.loginForm.reset();
  }
  checkAppliancesCredentials() {
    this.loading = true;
    this.message = '';
    this.errorMessage = '';
    this.errorMessage1 = '';
    this.checkLoginCredentialsResultArray = [];
    this._applianceManagementService.checkAppliancesCredentials(this.loginCredentialsArray).subscribe(
      (response) => {
        let isSuccess: boolean = true;
        this.loading = false;
        response.forEach(obj => {
          this.loginCredentialsArray = [];
          if (obj.code != "200") {
            localStorage.removeItem(obj.ipAddress);
            this.checkLoginCredentialsResultArray.push(obj);
            isSuccess = false;
          }

        });
        if (isSuccess) {

          this.partitionLoginModal.hide();
          this.goToCreateCluster();

        } else {
          this.finalPartitionList = [];
          //this.selectedPartitions = [];
          this.messageModal.show();
        }
      },
      (error) => {
        console.log(error);
      })
  }
  goToCreateCluster() {
    this.confirmModal.hide();
    let count: number = 0;
    this.credentialsSavedPartitionList.forEach(applianceObj => {
      this.createListOfPartitions(applianceObj, '');
    });
    this.saveCredentialsToSessionArray.forEach(applianceObj => {
      this.createListOfPartitions(applianceObj, "");
    });
    this.isCreateClusterShow = true;
    this.createClusterComponent.performSelectedOperation(this.finalPartitionList, this.partitionOperation);

  }
  createListOfPartitions(applianceObj, value) {
    if (this.partitionMap.has(applianceObj.applianceId)) {
      let partitionList = this.partitionMap.get(applianceObj.applianceId);
      partitionList.forEach(obj => {
        if (value == "login") {
          obj['operationPerformedUserName'] = this.loginForm.get('username').value;
          obj['operationPerformedPassword'] = this.loginForm.get('password').value;
        } else {
          obj['operationPerformedUserName'] = applianceObj.username;
          obj['operationPerformedPassword'] = applianceObj.password;
        }
        this.finalPartitionList.push(obj);
      });
    }
  }

  isFieldValid1(field: string) {
    if (this.loginForm.get(field).touched) {
      this.formValidationFields1 = this._fieldErrorDisplayService.validateField(this.loginForm, field, this.formValidationFields1, "login")
    }
    return !this.loginForm.get(field).valid && this.loginForm.get(field).touched;
  }
  displayFieldCss1(field: string) {
    return {
      'has-error': this.isFieldValid1(field),
      'has-feedback': this.isFieldValid1(field)
    };
  }
  closeLoginModal() {
    console.log("Close ----> Partition Login Modal");
    this.partitionLoginModal.hide();
    this.clearData();
  }
  goToConfirmModal() {
    this.errorMessage = '';
    this.errorMessage1 = '';
    this.partOfClusterPartitions = '';
    this.isPartOfCluster = false;
    if (this.selectedPartitions.length >= 2) {
      if (this.selectedPartitions.length <= 32) {
        this.selectedPartitions.forEach(obj => {
          if (obj.partOfCluster) {
            if (this.partOfClusterPartitions != '') {
              this.partOfClusterPartitions = this.partOfClusterPartitions + "," + obj.partitionName;
            } else {
              this.partOfClusterPartitions = obj.partitionName;
            }
            this.isPartOfCluster = true;
          }
        });

        if (!this.isPartOfCluster) {
          let modal = {
            "clusterPartitionsRelationships": this.selectedPartitions
          }
          this.loading = true;
          this._partitionManagementService.getComparePartitionsDetails(modal).subscribe(
            res => {
              this.loading = false;
              this.errorMessage = '';
              this.errorMessage1 = '';
              this.selectedPartitions = [];
              let detailsList = res.clusterPartitionsRelationships;
              if (res.code == '409') {
                this.errorMessage1 = res.errorMessage;
              }
              else if (res.code == '415') {
                let setError = res.errorMessage.split(".");
                this.errorMessage = setError[0] + ".Create cluster is not allowed";
              }
              this.clearData();

              detailsList.forEach(obj => {
                this.selectedPartitions.push(obj);
                if (this.isPartOfCluster || (this.errorMessage != null && this.errorMessage != '')
                  || (this.errorMessage1 != null && this.errorMessage1 != '')) {
                  this.confirmModal.show();
                } else {
                  this.goToLoginModal(this.selectedPartitions);
                }
              });
            },
            error => {
              this.loading = false;
              console.log(error);
            },
          )
        } else {
          this.confirmModal.show();
        }

      }
      else {
        this.partitionLoginModal.show();
        this.message = "Sorry!Operation cannot be performed on more than 32 partitions";
      }
    }
    else {
      this.partitionLoginModal.show();
      this.message = "Please select at least two partition to perform the activity!";
    }
  }
  closeConfirmModal() {
    console.log("Close ----> Confirm  Modal");
    this.confirmModal.hide();
    this.selectedPartitions = [];
    this.appliancesList = [];
    this.loadingListAppliances();
    this.clearData();
  }
  clearData() {
    this.loginForm.reset();
    this.partitionOperation = '';
    this.nonCredentialSavedParitionList = [];
    this.credentialsSavedPartitionList = []
    this.partitionCount = 1;
    this.totalpartitionCount = 0;
    this.partitionName = '';
    this.message = '';
    this.isLastPartition = false;
    this.finalPartitionList = [];
    this.saveCredentialsToSessionArray = [];
  }
  showCreateCluster(isShow: boolean) {
    this.isCreateClusterShow = isShow
  }

  hideCluster() {
    this.isCreateClusterShow = false;
  }
  closeAppliance() {
    // this.applianceList = []
    // this.selectedAppliances = [];
    // this.messageEvent.emit("false");
    this._router.navigate(['/listCluster']);
  }

  setDualFactorData(loginDetailsModal) {
    loginDetailsModal['initializeDetailModel'] = {};
    loginDetailsModal['initializeDetailModel']['cryptoOfficerName'] = this.loginForm.get('username').value;
    loginDetailsModal['initializeDetailModel']['cryptoOfficerPassword'] = this.loginForm.get('password').value;
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel'] = {};

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['dualFactorAuthServerPortNo'] = this.loginForm.get('dualFactorAuthServerPortNo').value;
    // certificate file details
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateContent'] = this.loginForm.get('certificateContent').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateName'] = this.loginForm.get('certificateName').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['certificateExtension'] = this.loginForm.get('certificateExtension').value;
    // key file details
    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileContent'] = this.loginForm.get('keyfileContent').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileName'] = this.loginForm.get('keyfileName').value;

    loginDetailsModal['initializeDetailModel']['dualFactorAuthDetailModel']
    ['keyfileExtension'] = this.loginForm.get('keyfileExtension').value;
    return loginDetailsModal;
  }

  setValidationDualFactorAuthentication() {
    // set validations for dual factor properties 
    if (this.applianceDualFactorInitialized) {
      this.loginForm.get('dualFactorAuthServerPortNo').setValidators(Validators.required);
      this.loginForm.get('certificateFile').setValidators(Validators.required);
      this.loginForm.get('keyFile').setValidators(Validators.required);
    } else {
      this.loginForm.get('dualFactorAuthServerPortNo').setValidators(null);
      this.loginForm.get('certificateFile').setValidators(null);
      this.loginForm.get('keyFile').setValidators(null);
    }
    this.loginForm.get('dualFactorAuthServerPortNo').updateValueAndValidity();
    this.loginForm.get('certificateFile').updateValueAndValidity();
    this.loginForm.get('keyFile').updateValueAndValidity();
  }


  onCertificateFileChange($event) {
    this.loginForm.get('certificateFile').markAsTouched({ onlySelf: true });
    let file = $event.target.files[0];
    this.loginForm.controls['certificateFile'].setValue(file ? file.name : ''); // <-- Set Value for Validation
    const filePicked = (event.target as HTMLInputElement).files[0];
    if (filePicked != undefined) {
      const fileName = filePicked.name;
      const extension = filePicked.name.split('.').pop() || '';
      const reader = new FileReader();
      reader.onload = () => {
        if (extension == 'crt') {
          this.loginForm.get('certificateContent').setValue(reader.result);
          this.loginForm.get('certificateName').setValue(fileName.substring(0, fileName.indexOf('.')));
          this.loginForm.get('certificateExtension').setValue(extension);
        } else {
          this.loginForm.get('certificateFile').setErrors({ "invalidExt": true })

        }
      };
      reader.readAsText(filePicked);
    } else {
      this.loginForm.get('certificateFile').setValue("");
      this.loginForm.get('certificateContent').setValue("");
      this.loginForm.get('certificateName').setValue("");
      this.loginForm.get('certificateExtension').setValue("");
      return false;
    }
  }

  onKeyFileChange($event) {
    this.loginForm.controls['keyFile'].markAsTouched({ onlySelf: true });
    let file = $event.target.files[0];
    this.loginForm.controls['keyFile'].setValue(file ? file.name : ''); // <-- Set Value for Validation
    const filePicked = (event.target as HTMLInputElement).files[0];
    if (filePicked != undefined) {
      const fileName = filePicked.name;
      let ext = filePicked.name.split('.');
      const extension = ext[1];
      const reader = new FileReader();
      reader.onload = () => {
        if (extension == 'key') {
          this.loginForm.get('keyfileContent').setValue(reader.result);
          this.loginForm.get('keyfileName').setValue(fileName.substring(0, fileName.indexOf('.')));
          this.loginForm.get('keyfileExtension').setValue(extension);
        } else {
          this.loginForm.get('keyFile').setErrors({ "invalidExt": true })

        }
      };
      reader.readAsText(filePicked);
    } else {
      this.loginForm.get('keyFile').setValue("");
      this.loginForm.get('keyfileContent').setValue("");
      this.loginForm.get('keyfileName').setValue("");
      this.loginForm.get('keyfileExtension').setValue("");
      return false;
    }
  }
}


