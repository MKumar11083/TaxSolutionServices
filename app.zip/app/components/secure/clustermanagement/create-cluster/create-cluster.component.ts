import { Component, OnInit, Output, EventEmitter, TemplateRef, ViewChild } from '@angular/core';
import { PartitionManagementService } from './../../../../services/partitionmanagement/partitionmanagement.service';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, FormControl } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { element } from 'protractor';
import { ModalDirective } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-create-cluster',
  templateUrl: './create-cluster.component.html',
  styleUrls: ['./create-cluster.component.css']
})
export class CreateClusterComponent implements OnInit {
  @ViewChild('confirmModal')
  confirmModal: ModalDirective;
  tempPartitionList: any = [];
  selectedPartitions: any = [];
  clusterName: string = '';
  form: FormGroup;
  message: any=[];
  errorMessage:any=[];
  loading: boolean = false;
  @Output() backOperation =new EventEmitter();
  constructor(private _services: PartitionManagementService,
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private builder: FormBuilder) { }

  ngOnInit() {
    this.createForm();
  }
  partitionListLength: number = 0;
  performSelectedOperation(partitionList, partitionOperation) {
    this.tempPartitionList = partitionList;
    this.partitionListLength = this.tempPartitionList.length;
  }

  createForm() {

    this.form = this.builder.group({
      clusterName: ['', Validators.required],

    });
  }

  public formValidationFields = {
    "clusterName": '',
  }

  isFieldValid(field: string) {

    if (this.form.get(field).touched) {
      this.formValidationFields = this._fieldErrorDisplayService.validateField(this.form, field, this.formValidationFields, "createCluster")
    }
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  onSubmit(isValid) {
    if (!isValid) {
      this.formValidationFields = this._fieldErrorDisplayService.validateForm(this.form, this.formValidationFields, "createCluster", false);
    }
    else {
      if (this.partitionListLength == this.tempPartitionList.length) {
        let clusterModal = {
          'clusterName': '',
          'clusterPartitionsRelationships': []
        };
        // let clusterPartitionRelationshipArray= [];
        // this.tempPartitionList.forEach(cluster => {
        //   // let ip = cluster.partitionDetailModel.networkStats.general.eth0.ip;
        //   // let ip1 = cluster.partitionDetailModel.networkStats.general.eth1.ip;
        //   // cluster['remoteEth0Addr']=ip;
        //   // cluster['remoteEth1Addr']=ip1;
        //   clusterPartitionRelationshipArray.push(cluster);
        // });
        clusterModal['clusterName'] = this.form.get('clusterName').value;
        clusterModal['clusterPartitionsRelationships'] = this.tempPartitionList;
        this.loading = true;
        this._services.createCluster(clusterModal).subscribe((res) => {
          this.loading = false;
          this.message = [];
          this.errorMessage = [];
          this.confirmModal.show();
          if (res.code == "200") {
            this.message = res.message.split("@#");

          } else {
            this.errorMessage = res.errorMessage.split("@#");;
          }
        })
      }
      else {
        let clusterModal = {
          'clusterName': '',
          'clusterPartitionsRelationships': []
        };
        // let clusterPartitionRelationshipArray= [];
        // this.tempPartitionList.forEach(cluster => {
        //   // let ip = cluster.partitionDetailModel.networkStats.general.eth0.ip;
        //   // let ip1 = cluster.partitionDetailModel.networkStats.general.eth1.ip;
        //   // cluster['remoteEth0Addr']=ip;
        //   // cluster['remoteEth1Addr']=ip1;
        //   clusterPartitionRelationshipArray.push(cluster);
        // });
        clusterModal['clusterName'] = this.form.get('clusterName').value;
        clusterModal['clusterPartitionsRelationships'] = this.tempPartitionList;
        this.loading = true;
        this._services.comparePartitionsAndCreateCluster(clusterModal).subscribe((res) => {
          this.loading = false;
          this.message = [];
          this.errorMessage = [];
          this.confirmModal.show();
          if (res.code == "200") {
            this.message = res.message.split("@#");
          } else {
            this.errorMessage = res.errorMessage.split("@#");;
          }
        })
      }

    }
  }
  clearData() {
    this.form.reset();
  }

  removeAppliance(partitionId) {
    if(this.tempPartitionList.length>2){
      let selectedIds = [];
      selectedIds.push(partitionId);
      this.tempPartitionList = this.tempPartitionList.filter(
        val => !selectedIds.includes(val.partitionId));
    }else{
      this.errorMessage=[];
      this.confirmModal.show();
      this.errorMessage[0] = "At least two partitions are required to perform create cluster";
    }
  }

  closeConfirmModal() {
    console.log("Close ----> Confirm  Modal");
    this.confirmModal.hide();
    this.clearData();
  }

  goBack(){
    this.backOperation.emit();
  }
}
