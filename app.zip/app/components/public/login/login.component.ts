import { Component, ViewChild, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { HttpErrorResponse } from '@angular/common/http';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { Router } from '@angular/router';
import { LoginService } from './../../../services/login.service';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { NgxPermissionsService } from 'ngx-permissions';
import { CommonServices } from './../../../services/common/common.services';

declare var $: any;

import { Cookie } from 'ng2-cookies';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  @ViewChild('selecterror')
  selecterror: ModalDirective;
  loginForm: FormGroup;
  errorMsg: string;
  message: string;
  errormessage: string = "";
  constructor(private _router: Router, private _formBuilder:
    FormBuilder, private _loginService: LoginService,
    private permissionsService: NgxPermissionsService,
    private _service: CommonServices) { }

  ngOnInit() {
    this.errorMsg = "";
    this.message = "";
    this.loginForm = this._formBuilder.group({
      userName: '',
      Password: ''
    });
    this.errorMsg = sessionStorage.getItem("errorMsg");
  }

  login() {
    this._service.clearSession();
    this.errorMsg = "";
    this.errormessage = "";
    this._loginService.obtainAccessToken(this.loginForm).subscribe(
      data => {
        this.saveToken(data);
       
      },
      err => {
        //let error = JSON.stringify(err);
        let error1 = JSON.parse(err['_body']);
        // console.log(error);
        console.log(error1);
        if (error1['error'] == "unauthorized" || error1['error'] == "invalid_grant") {
          this.errorMsg = "Invalid Credentials";
          if (error1['error'] == "invalid_grant") {
            this.errorMsg = "Invalid Credentials";
            if (error1['error_description'] == "User Account got locked due to five consecutive wrong attempts.") {
              this.errormessage = "User Account got locked due to five consecutive wrong attempts. Please click Forgot Password link and follow the instructions to recover your account";
              this.errorMsg = error1['error_description'];
              this.selecterror.show();
            }
          }
        }
        else {
          this.errorMsg = error1['error_description'];
        }
        //  this.errorMsg = error1['error_description'];
        if (this.errorMsg == "User Account got locked due to five consecutive wrong attempts.") {
          this.errormessage = "User Account got locked due to five consecutive wrong attempts. Please click Forgot Password link and follow the instructions to recover your account";
          this.selecterror.show();

        }
      }
    );
  }
  /* save the OAuth token into Cookie*/
  saveToken(token) {
    var expireDate = new Date().getTime() + (1000 * token.expires_in);
    // Cookie.set("access_token", token.access_token, expireDate);
    Cookie.set(this.loginForm.get('userName').value, token.access_token, expireDate);
    Cookie.set("refresh_token", token.refresh_token, expireDate);
    console.log('Obtained Access token');
    sessionStorage.setItem("username", this.loginForm.get('userName').value);
    this._router.navigate(['/dashboard']);
  }
}
