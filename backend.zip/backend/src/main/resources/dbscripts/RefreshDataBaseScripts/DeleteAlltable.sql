delete from cluster_partitions_relationship;
delete from cluster_details; 
  
delete from dual_factor_auth;
delete from initialize_appliances;
delete from initialize;	
    
delete from  recent_activites;
delete from   inprogress_activity;
delete from   alerts;
  
delete from partition_interface_general_eth;
delete from partition_interface_advance_static_host_ip;
delete from partition_interface_advance_dns_servers;
delete from partition_interface_advance_serach_domain_names;
delete from partition_client_certificates;
delete from partition_data;
delete from partition_configuration;
delete from partition_info;
delete from designation_appliance;
delete from  appliance_details ;


delete from  monitor_stats_details;
delete from  monitor_stats_data_details;
delete from monitor_stats_network_details;
delete from monitor_stats_pcpu_details;
delete from monitor_stats_cpu_details;
delete from monitor_stats_memory_details;
delete from  monitor_stats_usage_details;
delete from monitor_stats_info_details;
delete from monitor_stats_usage_info_details;
delete from monitor_stats_lo_details;
delete from monitor_stats_Sit_details;
delete from monitor_stats_Eth1_details;
delete from monitor_stats_ETH0_details;
    
delete from user_details where user_id !="SuperAdmin";
delete from designation where descr not in ('DefaultUserGroup','DeletedUserGroup');


delete from  partition_stats_ram_details;
delete from partition_stats_rx_queue_details;
delete from partition_stats_swap_details;
delete from partition_stats_system_up_time_details;
delete from partition_stats_fw_req_id_queue_details;
delete from partition_stats_diskspace_details;
delete from partition_stats_drv_req_id_queue_details;
delete from partition_stats_tx_queue_details;
delete from partition_stats_vm_details;
delete from partition_stats_data_details;
delete from partition_stats_details;