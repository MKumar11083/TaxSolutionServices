CREATE TABLE cluster_details (
      cluster_id MEDIUMINT UNSIGNED NOT NULL auto_increment,
      cluster_name varchar(255),
      last_operation_status varchar(100),
      last_operation_performed varchar(100),
      error_message varchar(500),
      status varchar(500),
     group_id MEDIUMINT UNSIGNED, 
     created_by varchar(250),
     cluster_version MEDIUMINT UNSIGNED,  
    PRIMARY KEY (cluster_id)
      );
      
      
 CREATE TABLE cluster_partitions_relationship (
 id MEDIUMINT UNSIGNED NOT NULL auto_increment,
 cluster_id MEDIUMINT UNSIGNED,
 partition_id MEDIUMINT UNSIGNED,
 node_id  MEDIUMINT UNSIGNED,
 zone_id  MEDIUMINT UNSIGNED,
 main_Channel_port MEDIUMINT UNSIGNED,
 back_channel_port MEDIUMINT UNSIGNED,  
 remote_eth1_addr varchar(250),
 remote_eth0_addr varchar(250),
 PRIMARY KEY (id)
)


alter table inprogress_activity add column cluster_id MEDIUMINT; 



  alter table cluster_partitions_relationship add column ip_address varchar(250);
 alter table cluster_partitions_relationship add column partition_name varchar(200);
 
   alter table cluster_partitions_relationship add column  appliance_name varchar(255);