CREATE TABLE appliance_details (
      appliance_id MEDIUMINT UNSIGNED NOT NULL auto_increment,
      appliance_name varchar(255),
      appliance_status varchar(50),
      serial_number varchar(100),
      network_timezone varchar(100),
      network_id varchar(100),
      gateway_ip varchar(100),
      ip_address varchar(100),
      subnet_mask varchar(100),
      network_mode varchar(100),
      hostname varchar(100),
      device_added_by_user varchar(255),
      operation_performed varchar(100),
      ipmi_ip varchar(100),
      user_name varchar(100) not null,
      user_password varchar(100) not null,
      PRIMARY KEY (appliance_id)
      );


create table partition_details(
partition_id MEDIUMINT UNSIGNED NOT NULL auto_increment,
appliance_id MEDIUMINT UNSIGNED NOT NULL,
partition_type varchar(50),
partition_total_space varchar(100),
partition_availble_space varchar(50),
partition_used_space varchar(50),
PRIMARY KEY (partition_id),
 KEY `fk_appliance_idx` (`appliance_id`),
CONSTRAINT FK_appliance FOREIGN KEY (appliance_id) REFERENCES appliance_details(appliance_id)ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE designation_appliance (
    ID MEDIUMINT UNSIGNED NOT NULL AUTO_INCREMENT,
    appliance_id MEDIUMINT UNSIGNED,
    design_id MEDIUMINT UNSIGNED,
    PRIMARY KEY (ID),
	FOREIGN KEY (appliance_id) REFERENCES appliance_details(appliance_id)
);


ALTER TABLE appliance_details 
ADD created_date DATETIME,
ADD created_by varchar(250),
ADD modified_by varchar(250),
ADD modified_date DATETIME;


ALTER TABLE appliance_details 
ADD authid varchar(100);


create table recent_activites
(ID MEDIUMINT UNSIGNED NOT NULL AUTO_INCREMENT key,user_groupid varchar(50),
 message varchar(500),created_date DATETIME);
 
ALTER TABLE appliance_details ADD city_name varchar(100) not null;


create table initialize(initialize_id MEDIUMINT UNSIGNED NOT NULL AUTO_INCREMENT,crypto_officer_name varchar(100),crypto_officer_password varchar(100), confirm_crypto_officer_password varchar(100),
authentication_level int(10),fips_state int(10),cert_authentication int(10),login_failure_count int(10),
minimum_password_length int(10),maximum_password_length int(10),hsm_label varchar(100),hsm_audit_log int(10),
PRIMARY KEY (initialize_id));

create table dual_factor_auth(ID MEDIUMINT UNSIGNED NOT NULL AUTO_INCREMENT,initialize_id MEDIUMINT UNSIGNED NOT NULL, dual_factor_auth_server_address varchar(100),dual_factor_auth_server_port_no varchar(100),
dual_factor_auth_server_certificate blob,PRIMARY KEY (ID),
	FOREIGN KEY (initialize_id) REFERENCES initialize(initialize_id));
    
	
alter table partition_details add partition_name varchar(100) after appliance_id;	


 

create table network_stats(
network_stat_id varchar(255) NOT NULL,
initialize_id MEDIUMINT UNSIGNED NOT NULL,
dhcp bit,
ip_address varchar(100),
gateway varchar(100),
subnet varchar(100),
disable_eth1 bit,
vlan_id int(10),
PRIMARY KEY (network_stat_id,initialize_id),
KEY `fk_initialize_idx` (`initialize_id`),
CONSTRAINT FK_initialize FOREIGN KEY (initialize_id) REFERENCES initialize(initialize_id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



create table initialize_appliances (
    ID MEDIUMINT UNSIGNED NOT NULL AUTO_INCREMENT,
	initialize_id MEDIUMINT UNSIGNED,
	appliance_id MEDIUMINT UNSIGNED,
    PRIMARY KEY (id)
);

ALTER TABLE appliance_details ADD appliance_store_type enum('TEMP','PERMANENT');

alter table appliance_details add column credential_saved bit default 0;
alter table appliance_details add column appliance_initialized bit default 0;

 
ALTER TABLE initialize_appliances 
add  operation_perform_password varchar(250),
add operation_perform_username varchar(250);



create table alerts
(ID MEDIUMINT UNSIGNED NOT NULL AUTO_INCREMENT key,user_groupid varchar(50),
 message varchar(500),created_date DATETIME);
 
 
ALTER TABLE appliance_details add column min_pasword_length MEDIUMINT UNSIGNED, 
column max_pasword_length MEDIUMINT UNSIGNED,
column co_login_failure_count MEDIUMINT UNSIGNED;

================================================
Partitions tables 
================================================


/////// To drop//
 
 drop table partition_details;
 drop table partition_configuration;
 drop table partition_interface_general_eth;
 drop table partition_interface_advance_static_host_ip;
 drop table partition_interface_advance_dns_servers;
 drop table partition_interface_advance_serach_domain_names;
 drop table partition_client_certificates;

///////


  create table partition_configuration(partition_id MEDIUMINT UNSIGNED NOT NULL auto_increment,appliance_id MEDIUMINT UNSIGNED NOT NULL,
 partition_name varchar(200),csr varchar(100),partition_keys MEDIUMINT UNSIGNED,ssl_context MEDIUMINT UNSIGNED,
 acceleration_devices MEDIUMINT UNSIGNED,wrap bit default 0,backup bit default 0, created_date DATETIME,
 created_by varchar(250),modified_by varchar(250),modified_date DATETIME,status varchar(100),
 PRIMARY KEY (partition_id),
 KEY `fk_appliance_idx` (`appliance_id`),
CONSTRAINT FK_appliance FOREIGN KEY (appliance_id) REFERENCES appliance_details(appliance_id)ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



 create table partition_interface_general_eth(ID MEDIUMINT UNSIGNED NOT NULL AUTO_INCREMENT,
 partition_id MEDIUMINT UNSIGNED NOT NULL,eth_name varchar(100),dhcp bit default 0,enable bit default 0,
 ip_address varchar(100),gateway varchar(100),
 subnet_mask varchar(100),hostname varchar(100), static_mac bit default 0, 
 mac_address varchar(100),vlan_id MEDIUMINT UNSIGNED,
 PRIMARY KEY (ID),
 FOREIGN KEY (partition_id) 
 REFERENCES partition_configuration(partition_id));
 
 
 create table partition_interface_advance_static_host_ip(ID MEDIUMINT UNSIGNED NOT NULL AUTO_INCREMENT,
 partition_id MEDIUMINT UNSIGNED NOT NULL,ip_address varchar(100),hostname varchar(100),
 alias varchar(100),
 PRIMARY KEY (ID),
 FOREIGN KEY (partition_id) REFERENCES partition_configuration(partition_id));
 
 create table partition_interface_advance_dns_servers(ID MEDIUMINT UNSIGNED NOT NULL AUTO_INCREMENT,
 partition_id MEDIUMINT UNSIGNED NOT NULL,dns_address varchar(100),PRIMARY KEY (ID),
 FOREIGN KEY (partition_id) REFERENCES partition_configuration(partition_id));
 
 create table partition_interface_advance_serach_domain_names(ID MEDIUMINT UNSIGNED NOT NULL AUTO_INCREMENT,
 partition_id MEDIUMINT UNSIGNED NOT NULL,
 domain_names varchar(100),PRIMARY KEY (ID),
 FOREIGN KEY (partition_id) REFERENCES partition_configuration(partition_id));
 
 create table partition_client_certificates(ID MEDIUMINT UNSIGNED NOT NULL AUTO_INCREMENT,
 partition_id MEDIUMINT UNSIGNED NOT NULL,file_name varchar(200),
 uploaded_file_id varchar(300),PRIMARY KEY (ID),
 FOREIGN KEY (partition_id) REFERENCES partition_configuration(partition_id));
 
 create table partition_info(partition_info_id MEDIUMINT UNSIGNED NOT NULL AUTO_INCREMENT,
 partition_id MEDIUMINT UNSIGNED NOT NULL,occupied_partitions MEDIUMINT UNSIGNED,
 total_partitions MEDIUMINT UNSIGNED,
  total_acclrdev MEDIUMINT UNSIGNED,occupied_acclrdev MEDIUMINT UNSIGNED,total_keys MEDIUMINT UNSIGNED,
  occupied_keys MEDIUMINT UNSIGNED, total_contexts MEDIUMINT UNSIGNED,occupied_contexts MEDIUMINT UNSIGNED,
  certificate_authenticate varchar(100),auditLogs varchar(100),PRIMARY KEY (partition_info_id),
 FOREIGN KEY (partition_id) REFERENCES partition_configuration(partition_id));
 
  create table partition_data(ID MEDIUMINT UNSIGNED NOT NULL AUTO_INCREMENT,
  partition_id MEDIUMINT UNSIGNED NOT NULL, certauth MEDIUMINT UNSIGNED,pco_fixed_key_finger_print varchar(100),
  max_keys MEDIUMINT UNSIGNED,cloning_method varchar(100),total_ssl_ctxs MEDIUMINT UNSIGNED,
  mvalue_cloning MEDIUMINT UNSIGNED,kek_method MEDIUMINT UNSIGNED,audit_log_status varchar(100),
  block_delete_user_with_keys MEDIUMINT UNSIGNED,cav_server_status MEDIUMINT UNSIGNED,node_id varchar(100),
  mvalue_miscco MEDIUMINT UNSIGNED,max_acclr_dev_count MEDIUMINT UNSIGNED,key_import varchar(100),
  key_export varchar(100),occupied_session_keys MEDIUMINT UNSIGNED,export_user_keys_other_thankek varchar(100),
  status varchar(100),mvalue_backup_by_co MEDIUMINT UNSIGNED, session_count MEDIUMINT UNSIGNED
  ,two_key_backup MEDIUMINT UNSIGNED,available_users MEDIUMINT UNSIGNED,max_pswd_len MEDIUMINT UNSIGNED,
  max_users MEDIUMINT UNSIGNED, group_id varchar(100),vm_status MEDIUMINT UNSIGNED,partition_name varchar(100), 
  n_value MEDIUMINT UNSIGNED, mco_backup_restore bit default 0,
 occupied_ssl_ctxs MEDIUMINT UNSIGNED,fips_state varchar(100),occupied_token_keys MEDIUMINT UNSIGNED, 
 mvalue_usermgmt MEDIUMINT UNSIGNED, min_pswd_len MEDIUMINT UNSIGNED,
 PRIMARY KEY (ID),
 FOREIGN KEY (partition_id) REFERENCES partition_configuration(partition_id));
 
   alter table partition_configuration add status varchar(100);
  alter table partition_configuration  drop column fipsstate;
 //////////////// for delete  purpose
 delete from partition_configuration;
 delete from partition_interface_general_eth;
 delete from partition_interface_advance_static_host_ip;
 delete from partition_interface_advance_dns_servers;
 delete from partition_interface_advance_serach_domain_names;
 delete from partition_client_certificates;
 
 ///////////
 
 ////////// for select purpose
  
 select * from partition_configuration;
 select * from partition_interface_general_eth;
  select * from partition_interface_advance_static_host_ip;
   select * from partition_interface_advance_dns_servers;
    select * from partition_interface_advance_serach_domain_names;
	////////
	
	///////////////////
	alter table alerts add appliance_id MEDIUMINT UNSIGNED;
alter table alerts add appliance_name varchar(255);
=============
 create table inprogress_activity(ID MEDIUMINT UNSIGNED NOT NULL AUTO_INCREMENT,job_id MEDIUMINT UNSIGNED,
                                  operation_name varchar(100),ip_address varchar(100),createdby varchar(250),
                                  status varchar(100), PRIMARY KEY (ID));
============================

alter table partition_configuration add column last_operation_performed varchar(100), 
add column error_message varchar(100);

alter table inprogress_activity add column partition_id MEDIUMINT UNSIGNED,
add column appliance_id MEDIUMINT UNSIGNED;
===========================================
alter table appliance_details drop column operation_performed;
alter table partition_configuration add column last_operation_status varchar(100);
alter table appliance_details add column last_operation_status varchar(100),
add column last_operation_performed varchar(100),add column error_message varchar(500);
 
 
alter table appliance_details add column  initialized__through_cavium bit(1) default 0;


alter table alerts add column module_type varchar(200);
alter table alerts add column module_id varchar(200);
alter table alerts drop column appliance_id ;
alter table alerts drop column appliance_name;

ALTER TABLE appliance_details 
ADD total_acclr_device MEDIUMINT UNSIGNED,
ADD occupied_acclr_dev MEDIUMINT UNSIGNED;


ALTER TABLE appliance_details 
ADD total_keys MEDIUMINT UNSIGNED,
ADD occupied_keys MEDIUMINT UNSIGNED,
ADD total_contexts MEDIUMINT UNSIGNED,
ADD occupied_contexts MEDIUMINT UNSIGNED;


alter table partition_configuration add column part_of_cluster bit default 0;

alter table appliance_details drop column user_name;
alter table appliance_details drop column user_password;
alter table appliance_details add column zone_id  MEDIUMINT UNSIGNED;


drop table network_stats;

alter table appliance_details add column user_name  varchar(200);   
alter table appliance_details add column user_password varchar(200) ;
alter table inprogress_activity add column partition_deleted bit default 0;
////////////////
alter table inprogress_activity add column
appliance_name varchar(255),
add column partition_name varchar(255);

----------
 ALTER TABLE partition_configuration MODIFY error_message varchar(1000);
 ALTER TABLE appliance_details MODIFY error_message varchar(1000);

