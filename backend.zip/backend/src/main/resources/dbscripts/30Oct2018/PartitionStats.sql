 

CREATE TABLE partition_stats_details (
      id MEDIUMINT UNSIGNED NOT NULL auto_increment,
	  status varchar(1000),
	 message varchar(1000),
	  data MEDIUMINT UNSIGNED,
	   PRIMARY KEY (id));
 

CREATE TABLE partition_stats_data_details (
      id MEDIUMINT UNSIGNED NOT NULL auto_increment,
	  vm_status MEDIUMINT UNSIGNED ,
	  vmstats MEDIUMINT UNSIGNED ,
	   PRIMARY KEY (id));
 

CREATE TABLE partition_stats_vm_details (
      id MEDIUMINT UNSIGNED NOT NULL auto_increment,
	  tx_queue MEDIUMINT UNSIGNED ,
	  link_status_eth0 MEDIUMINT UNSIGNED,
	  link_status_eth1 MEDIUMINT UNSIGNED ,
	  cav_server_status MEDIUMINT UNSIGNED,
	  drv_req_id_queue MEDIUMINT UNSIGNED ,
	  cpu_usage_percentage MEDIUMINT UNSIGNED,
	  disk_space_in_mb MEDIUMINT UNSIGNED ,
	  fw_req_id_queue MEDIUMINT UNSIGNED,
	   system_up_time MEDIUMINT UNSIGNED,
	  driver_status MEDIUMINT UNSIGNED ,
	  process_count MEDIUMINT UNSIGNED,
	  swap_stats_in_mb MEDIUMINT UNSIGNED ,
	  rx_queue MEDIUMINT UNSIGNED,
	  ram_stats_in_mb MEDIUMINT UNSIGNED ,
	  PRIMARY KEY (id));

 
CREATE TABLE partition_stats_tx_queue_details (
      id MEDIUMINT UNSIGNED NOT NULL auto_increment,
	  tdh MEDIUMINT UNSIGNED ,
	  tdt MEDIUMINT UNSIGNED ,
	   PRIMARY KEY (id));

 

CREATE TABLE partition_stats_drv_req_id_queue_details (
      id MEDIUMINT UNSIGNED NOT NULL auto_increment,
	  head MEDIUMINT UNSIGNED ,
	  tail MEDIUMINT UNSIGNED ,
	   PRIMARY KEY (id));
 
CREATE TABLE partition_stats_diskspace_details (
      id MEDIUMINT UNSIGNED NOT NULL auto_increment,
	  total MEDIUMINT UNSIGNED ,
	  free MEDIUMINT UNSIGNED ,
	   PRIMARY KEY (id));

 
CREATE TABLE partition_stats_fw_req_id_queue_details (
      id MEDIUMINT UNSIGNED NOT NULL auto_increment,
	  head MEDIUMINT UNSIGNED ,
	  tail MEDIUMINT UNSIGNED ,
	   PRIMARY KEY (id));

 
CREATE TABLE partition_stats_system_up_time_details (
      id MEDIUMINT UNSIGNED NOT NULL auto_increment,
	  hours MEDIUMINT UNSIGNED ,
	  minutes MEDIUMINT UNSIGNED ,
	  seconds MEDIUMINT UNSIGNED ,
	   PRIMARY KEY (id));
 
CREATE TABLE partition_stats_swap_details (
      id MEDIUMINT UNSIGNED NOT NULL auto_increment,
	  total MEDIUMINT UNSIGNED ,
	  free MEDIUMINT UNSIGNED ,
	   PRIMARY KEY (id));
	   
 
CREATE TABLE partition_stats_rx_queue_details (
      id MEDIUMINT UNSIGNED NOT NULL auto_increment,
	  rdt MEDIUMINT UNSIGNED ,
	  rdh MEDIUMINT UNSIGNED ,
	   PRIMARY KEY (id));
 
 
CREATE TABLE partition_stats_ram_details (
      id MEDIUMINT UNSIGNED NOT NULL auto_increment,
	  total MEDIUMINT UNSIGNED ,
	  free MEDIUMINT UNSIGNED ,
	   PRIMARY KEY (id));
	   
	    
	alter table partition_stats_details add column operation varchar(1000);
 	 alter table partition_stats_details add column partition_name varchar(1000);
     alter table partition_stats_details add column start_time MEDIUMINT UNSIGNED;
    alter table partition_stats_details add column end_time MEDIUMINT UNSIGNED;
     alter table partition_stats_details add column job_id MEDIUMINT UNSIGNED;
     
     alter table partition_stats_details add column  created_date DATETIME;
  
     alter table partition_stats_details add column partition_id MEDIUMINT UNSIGNED;
  
  