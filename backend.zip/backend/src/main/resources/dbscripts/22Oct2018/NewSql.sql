insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='GroupAdmin'),'14'); 
delete from  acl_role where  acl_id in (select id from acl_details where descr='MonitorUser') and permission_id=23;
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='GroupAdmin'),'13');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SecondaryUser'),'13');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SecondaryUser'),'14');
alter table user_details add column created_by varchar(250);

delete from user_details where user_id !="SuperAdmin";

////////////////
alter table inprogress_activity add column
appliance_name varchar(255),
add column partition_name varchar(255);

 ALTER TABLE partition_configuration MODIFY error_message varchar(1000);
 ALTER TABLE appliance_details MODIFY error_message varchar(1000);

