package com.cavium.utill;

public class CaviumConstant {
	
	public static final String APPLIANCE_MANAGEMENT = "applianceManagement";
	public static final String CLUSTER_MANAGEMENT = "clusterManagement";
	public static final String PARTITION_MANAGEMENT = "partitionManagement";
	public static final String USER_MANAGEMENT = "userManagement";
	public static final String CREATE_CLUSTER = "create Cluster";
	public static final String REMOVE_CLUSTER = "remove Cluster";
	public static final String DOT = ".";
	public static final String USER_LOGIN_MANAGEMENT="loginManagement";
	
}

 