package com.cavium.utill;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;

import org.apache.log4j.Logger;
import org.hyperic.sigar.CpuPerc;
import org.hyperic.sigar.Mem;
import org.hyperic.sigar.Sigar;
import org.hyperic.sigar.SigarException;
import org.springframework.util.ResourceUtils;

import com.cavium.pojo.SystemInformationDetails;

public class SystemInformationUtil {
       
	private   Logger logger = Logger.getLogger(this.getClass());
	static {
	    try {
	    	 boolean is64bit = System.getProperty("sun.arch.data.model").contains("64");
	    	 System.out.println(".......is64Bit...."+is64bit);
	    	String operatingSystem=System.getProperty("os.name");
	    	System.out.println(".......operatingSystem...."+operatingSystem);
	    	if(!operatingSystem.contains("Window")){
	    	if(is64bit){	    		
	    	File fileForLinuxfor64bit = ResourceUtils.getFile("classpath:libsigar-amd64-linux.so");
	    	System.load(fileForLinuxfor64bit.getAbsolutePath());
	    	}else{
	    	File fileForLinux = ResourceUtils.getFile("classpath:libsigar-x86-linux.so");
	    	System.load(fileForLinux.getAbsolutePath());
	    	 }    
	      	}else{
	      		if(is64bit){
	      		File fileforWindowfor64bit = ResourceUtils.getFile("classpath:sigar-amd64-winnt.dll");     
	      		System.load(fileforWindowfor64bit.getAbsolutePath());
	      		} 
	      		else{
	      			File fileforWindow = ResourceUtils.getFile("classpath:sigar-x86-winnt.dll");
	      			System.load(fileforWindow.getAbsolutePath());
	      		}
	      	 }
	     } 
	    catch (FileNotFoundException e) {
	    	System.out.println("error is coming during initilize dll or so files in SystemInformationUtil class ::  "+ e.getMessage());
	    }
	  }
  
         public  SystemInformationDetails getSystemInformationDetails() {
        	   
        	logger.info("start of systemInformationDetails method  of SystemInformationUtil class");
        	   
              SystemInformationDetails systemInformationDetails= new SystemInformationDetails();
                      try {
                    	  
                    	  Sigar sigar = new Sigar();

                          long total_disk_space = 0;
                          long free_disk_space = 0;
	                      Mem memInfo = sigar.getMem();
                    
                         Long ramSize= memInfo.getRam();
                         double ramUsage = memInfo.getUsedPercent();
                 
                         File[] roots = File.listRoots();
                         /* For each filesystem root, print some info */
                         for (File root : roots) {
                     
                           total_disk_space = total_disk_space + root.getTotalSpace();
                           free_disk_space = free_disk_space + root.getFreeSpace();
                         } 
                         long used_disk_space =total_disk_space-free_disk_space;
                         systemInformationDetails.setDiskSpaceAvaliabe(formatBytesInNumber(free_disk_space));
                         systemInformationDetails.setTotaldiskSpace(formatBytesInNumber(total_disk_space));
                         systemInformationDetails.setDiskSpaceAvaliabeStr(formatBytes(free_disk_space));
                         systemInformationDetails.setTotalDiskSpaceStr(formatBytes(total_disk_space));
                         systemInformationDetails.setUsedDiskSpaceStr(formatBytes(used_disk_space));
                         systemInformationDetails.setRamUsage(convertUptoTwoDecimal(ramUsage));
                         systemInformationDetails.setRamSize(ramSize/1000);
                         systemInformationDetails.setOperatingSystem(System.getProperty("os.name"));
                         CpuPerc cpuperc = null;
                         cpuperc = sigar.getCpuPerc();
                         systemInformationDetails.setCpuUsage(convertUptoTwoDecimal(cpuperc.getCombined()*100));
                        // System.out.print("New CPU Usage %" + (convertUptoTwoDecimal(cpuperc.getCombined()*100)));

                      } catch (Exception ex) {
                    	 logger.error("some error coming while getting system details in getSystemInformationDetails method of SystemInformationUtil class :: "+ex.getMessage());
                      }
                      logger.info("end of systemInformationDetails method  of SystemInformationUtil class");
                      return systemInformationDetails;
                  }      
         
         
    /*     public static void main(String[] args) {
             
             
              Total number of processors or cores available to the JVM 
             System.out.println("Available processors (cores): " + 
                 Runtime.getRuntime().availableProcessors());

              Total amount of free memory available to the JVM 
             System.out.println("Free memory (bytes) for the JVM: " + 
                 Runtime.getRuntime().freeMemory());

              This will return Long.MAX_VALUE if there is no preset limit 
             long maxMemory = Runtime.getRuntime().maxMemory();
              Maximum amount of memory the JVM will attempt to use 
             System.out.println("Maximum memory (bytes) for the JVM: " + 
                 (maxMemory == Long.MAX_VALUE ? "no limit" : maxMemory));

              Total memory currently available to the JVM 
             System.out.println("Total memory available to JVM (bytes): " + 
                 Runtime.getRuntime().totalMemory());

             
             System.out.println(System.getProperty("os.name"));
             System.out.println((System.getProperty("java.library.path")));
             calculateStats();
             
             //System.getProperties().list(System.out);    
             File[] roots = File.listRoots();

             long total_disk_space = 0;
             long free_disk_space = 0;
              For each filesystem root, print some info 
             for (File root : roots) {
         
               total_disk_space = total_disk_space + root.getTotalSpace();
               free_disk_space = free_disk_space + root.getFreeSpace();
             } 
             
             System.out.println("Total Disk Space : " +       
                       formatBytes(total_disk_space));
             
             System.out.println("Free Space : " + 
                       formatBytes(free_disk_space));
           }*/

         
             
       /*      public static void calculateStats() {
                 //numCores = Runtime.getRuntime().availableProcessors();
                 Sigar sigar = new Sigar();
                 try {
                     //CpuInfo[] cpuInfo = sigar.getCpuInfoList();
                     //cpuFreq = cpuInfo[0].getMhz();
                     Mem memInfo = sigar.getMem();
                     double freeRAM = memInfo.getRam();
                     long ram = memInfo.getRam();
                     double ramUsage = memInfo.getUsedPercent();
                    System.out.println("rrrrrrrrrrrrrrrrr"+ convertUptoTwoDecimal(ramUsage));
                     System.out.println("Ram Freepercent : " + freeRAM);
                     System.out.println("Ram total : " + ram/1000);
                     System.out.println("Ram Usage.."+ramUsage);
                     //cpuLoad = sigar.getLoadAverage();
                     for (int i = 0; i < getCpuLoad().length; i++) {
                         cpuLoad[i] /= numCores;
                     } 
                 } catch (SigarException ex) {
                     ex.printStackTrace();
                 }
             }*/
             


       public static  String formatBytes(long bytes) {

                return(bytes / 1073741824) + " GB";

       }
       
       public static  long formatBytesInNumber(long bytes) {

           return (bytes / 1073741824);

  }
       
   	public static double convertUptoTwoDecimal(double ramUsage){	
   		DecimalFormat f = new DecimalFormat("##.00");
	 
   		ramUsage=Double.parseDouble(f.format(ramUsage));
	
		return ramUsage;
	}

}

