package com.cavium.controller.snapshot;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.controller.alerts.AlertsController;
import com.cavium.controller.appliance.ApplianceTopologyController;
import com.cavium.controller.partition.PartitionController;
import com.cavium.controller.recentactivity.RecentActivityController;
import com.cavium.model.alerts.Alerts;
import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.recentactivity.RecentActivity;
import com.cavium.pojo.ApplianceCityDetail;
import com.cavium.pojo.PartitionsDetails;
import com.cavium.pojo.SnapshotDetails;
import com.cavium.pojo.UserAttributes;
import com.cavium.service.alerts.AlertsService;
import com.cavium.service.appliance.ApplianceService;
import com.cavium.service.partition.PartitionService;
import com.cavium.service.recentactivity.RecentActivityService;
import com.cavium.utill.CaviumConstant;
import com.cavium.utill.CaviumResponseModel;


@RestController
@RequestMapping("rest")
public class SnapshotController {


	/*@Autowired
	private ApplianceTopologyController applianceTopologyController;

	@Autowired
	private PartitionController partitionController;

	@Autowired
	private RecentActivityController recentActivityController;*/

	@Autowired
	private SnapshotDetails snapshotDetails;
	
	 
	
/*	@Autowired
	private AlertsController alertsController;*/
	
	@Autowired
	private RecentActivityService recentActivityService;
	
	@Autowired
	private ApplianceService applianceService;
	@Autowired
	private UserAttributes userAttributes;
	@Autowired
	private PartitionService partitionService;
	@Autowired
	private AlertsService alertsService; 
	
	@Lookup
	public PartitionsDetails getPartitionsDetails() {
		return null;
	}
 

	private Logger logger = Logger.getLogger(this.getClass());

	@RequestMapping(value = "getSnapshotDetails", method = RequestMethod.GET)
	public SnapshotDetails snapshotDetailsForAppliance(){
		
		logger.info("start of getSnapshotDetails Method");

 
		List<RecentActivity> recentActivity = null;
		List<ApplianceCityDetail> listApplianceToplology=null;
		List<Alerts> alerts=null;
		 List<ApplianceDetailModel>listApplianceDetailModels= new ArrayList<ApplianceDetailModel>();
	PartitionsDetails partitionsDetails=getPartitionsDetails();
		try{
			String loggedInUser = userAttributes.getlogInUserName();			
			recentActivity=recentActivityService.getRecentActivity(loggedInUser,CaviumConstant.APPLIANCE_MANAGEMENT);	
			listApplianceDetailModels = applianceService.listOfApplianceByGroupId(loggedInUser);
			for (Iterator<ApplianceDetailModel> iterator = listApplianceDetailModels.iterator(); iterator.hasNext();) {
				ApplianceDetailModel applianceDetailModel = (ApplianceDetailModel) iterator.next();
				 partitionsDetails=partitionService.getPartitionInfo(applianceDetailModel,partitionsDetails);			
			}
			listApplianceDetailModels = applianceService.listOfApplianceByGroupId(loggedInUser);	
			listApplianceToplology=applianceService.listAppliancesDetailCityWise(listApplianceDetailModels);
		 	alerts=alertsService.getAlerts(loggedInUser,CaviumConstant.APPLIANCE_MANAGEMENT);
			snapshotDetails.setRecentActivity(recentActivity);
			snapshotDetails.setListApplianceToplology(listApplianceToplology);
			snapshotDetails.setPartitionsDetails(partitionsDetails);
			snapshotDetails.setAlerts(alerts);
		}catch(Exception exp){
			logger.error("error occured during getRecentActivity" + exp.getMessage());
		}
		logger.info("end of getSnapshotDetails Method");
		return snapshotDetails;
	}

}
