package com.cavium.controller.user;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.user.UserDetailModel;
import com.cavium.pojo.UserAttributes;
import com.cavium.service.user.UserService;
import com.cavium.utill.CaviumResponseModel;


/**
 * @author RK00490847
 * 
 */
@RestController
@RequestMapping("rest")
public class ChangePasswordController {

	// logger - instance of application log.
	private Logger logger = Logger.getLogger(this.getClass());

	// userService - Service class provide the interface for the Repository Operation.
	@Autowired
	private UserService userService;

	// userAttributes - get LogIn User Details
	@Autowired
	private UserAttributes userAttributes;

	@Lookup
	public CaviumResponseModel getCaviumResponseModel() {
		return null;
	}
	/**
	 * This changePassword method used for changing the password User 
	 * and return Success message or failure message to the response.
	 * 
	 * @param response
	 *            - success message or error message
	 * @param request
	 *            - UserDetailModel
	 * 
	 */
	@RequestMapping(value = "changePassword", method = RequestMethod.POST)
	public final CaviumResponseModel changePassword(@RequestBody UserDetailModel userDetailModel) {
		String userId=	userAttributes.getlogInUserName();
		logger.info("User ID " + userId + " is going for changePassword");
		CaviumResponseModel responseModel=getCaviumResponseModel();
		if(userDetailModel!=null) {
		String oldPassword = String.valueOf(userDetailModel.getOldPassword()); 	
		String newPassword = String.valueOf(userDetailModel.getNewPassword());
		responseModel = userService.changePassword(userId,oldPassword,newPassword);
		}
		else {
			logger.error("User Details for change password is empty");
			responseModel.setResponseCode("204");
			responseModel.setResponseMessage("User Details for change password is empty");
		}
		return responseModel;
	}
}
