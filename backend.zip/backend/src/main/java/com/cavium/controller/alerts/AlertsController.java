package com.cavium.controller.alerts;



import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.alerts.Alerts;
import com.cavium.pojo.UserAttributes;
import com.cavium.service.alerts.AlertsService;
import com.cavium.utill.CaviumConstant;
 

@RestController
@RequestMapping("rest")
public class AlertsController {
	
	private Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	private AlertsService alertsService;
	
	@Autowired
	private UserAttributes userAttributes;
	
	/***
	 * This method is used to get appliance by id.
	 */
	@RequestMapping(value = "alertsForAppliance", method = RequestMethod.GET)
	public List<Alerts> getAlertsForAppliance() {
		List<Alerts> alerts = null;
		logger.info("inside getAlertsForAppliance method");
		try {
			String loggedInUser = userAttributes.getlogInUserName();
			alerts=alertsService.getAlerts(loggedInUser,CaviumConstant.APPLIANCE_MANAGEMENT);
		} catch (Exception e) {
			logger.error("error occured during getRecentActivity" + e.getMessage());
		}
		return alerts;
	}
	
	/***
	 * This method is used to get alerts for partition
	 */
	@RequestMapping(value = "alertsForPartition", method = RequestMethod.GET)
	public List<Alerts> getAlertsForPartition() {
		List<Alerts> alerts = null;
		logger.info("inside getAlertsForPartition method");
		try {
			String loggedInUser = userAttributes.getlogInUserName();
			alerts=alertsService.getAlerts(loggedInUser,CaviumConstant.PARTITION_MANAGEMENT);
		} catch (Exception e) {
			logger.error("error occured during getRecentActivity" + e.getMessage());
		}
		return alerts;
	}

}
