package com.cavium.controller.usergroup;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.user.ApplianceDetailsWithGroupModel;
import com.cavium.model.user.DesignationApplianceModel;
import com.cavium.model.user.UserGroupModel;
import com.cavium.pojo.UserAttributes;
import com.cavium.service.alerts.AlertsService;
import com.cavium.service.user.UserService;
import com.cavium.utill.CaviumConstant;
import com.cavium.utill.CaviumResponseModel;

/*
 * This ModifyUserGroupController class is used for modify the existing UserGroup in Database.
 *  @author RK00490847
 */
@RestController
@RequestMapping("rest")
public class ModifyUserGroupController {

	// logger - instance of application log.
	private Logger logger = Logger.getLogger(this.getClass());

	// userService - Service class provide the interface for the Repository
	// Operation.
	@Autowired
	private UserService userService;

	// userAttributes - get LogIn User Details
	@Autowired
	private UserAttributes userAttributes;

	// get Property Value from Property File
	@Autowired
	private Environment env;
	

	@Lookup
	public CaviumResponseModel getCaviumResponseModel() {
		return null;
	}
 
	
	@Autowired
	private AlertsService alertsService;
	/*
	 * This getUserDetails method will get groupId from request and return all the
	 * appliances Details associated with Group.
	 * 
	 * @param PathVariable - groupId
	 * 
	 * @return - The Appliances Details along with Group Detail.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "getUserGroupDetail/{groupId}")
	public final ApplianceDetailsWithGroupModel getUserDetails(@PathVariable("groupId") String groupId) {
		logger.info("Start of getUserDetails Method");
		ApplianceDetailsWithGroupModel applianceDetailsWithGroupModel = new ApplianceDetailsWithGroupModel();
		List<DesignationApplianceModel> listDesignationApplianceModel= new ArrayList<DesignationApplianceModel>();
		try {
			 listDesignationApplianceModel = userService.getDefaultGroupAppliances();
		 
			UserGroupModel userGroupModel = new UserGroupModel();
			if (org.apache.commons.lang3.StringUtils.isNotEmpty(groupId)
					&& org.apache.commons.lang.StringUtils.isNumeric(groupId)) {
				userGroupModel = this.userService.getGroupDetailById(groupId);
				applianceDetailsWithGroupModel.setListDesignationApplianceModel(listDesignationApplianceModel);;
				applianceDetailsWithGroupModel.setObjUserGroupModel(userGroupModel);
			}
		} catch (Exception exp) {
			logger.info("Some Error is coming while performing Opeartion:: " + exp.getMessage());
		}
		logger.info("End of getUserDetails Method");
		return applianceDetailsWithGroupModel;
	}

	/*
	 * This method will update the UserGroup Details and return the success message
	 * or error message .
	 * 
	 * @param RequestBody - UserGroupModel from Request
	 * 
	 * @return responseModel - CaviumResponseModel Object
	 */
	@RequestMapping(value = "modifyUserGroup", method = RequestMethod.PUT)
	protected final CaviumResponseModel editUserGroup(@RequestBody UserGroupModel userGroupModel) {
		List<DesignationApplianceModel> listDesignationApplianceModel = new ArrayList<DesignationApplianceModel>();
		CaviumResponseModel responseModel = getCaviumResponseModel();
		String userName = userAttributes.getlogInUserName();
		try {
	
			if (userGroupModel != null) {
				userGroupModel.setUsername(userName);
				userGroupModel.setListDesignationApplianceModel(listDesignationApplianceModel);
				responseModel = userService.modifyUserGroup(userGroupModel);
			} else {
				logger.error("userGroup Details Empty");
				responseModel.setResponseCode("204");
				responseModel.setResponseMessage("userGroup Details Empty");
			}
		} catch (Exception e) {
			logger.info("Some Error is coming while performing Opeartion:: " + e.getMessage());
			responseModel.setResponseCode("500");
			responseModel.setResponseMessage(env.getProperty("userGroupModification.failure"));
			alertsService.createAlert(userName,"Error is coming while modify existing user "+userGroupModel.getRoleName()+" by "+userName +"",CaviumConstant.USER_MANAGEMENT);
		}
		logger.info("ResponseModel for editUserGroup :: " + responseModel.toString());
		return responseModel;
	}
}
