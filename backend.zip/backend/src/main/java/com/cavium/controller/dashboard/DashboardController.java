package com.cavium.controller.dashboard;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.alerts.Alerts;
import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.appliance.StoreType;
import com.cavium.model.recentactivity.RecentActivity;
import com.cavium.pojo.DashboardDetails;
import com.cavium.pojo.SystemInformationDetails;
import com.cavium.pojo.UserAttributes;
import com.cavium.repository.appliance.ApplianceRepository;
import com.cavium.repository.partition.PartitionRepository;
import com.cavium.repository.user.DesignationApplianceRepository;
import com.cavium.repository.user.UserACLRepository;
import com.cavium.repository.user.UserGroupRepository;
import com.cavium.repository.user.UserRepository;
import com.cavium.service.alerts.AlertsService;
import com.cavium.service.recentactivity.RecentActivityService;
import com.cavium.utill.CaviumConstant;
import com.cavium.utill.CaviumUtil;
import com.cavium.utill.SystemInformationUtil;


@RestController
@RequestMapping("rest")
public class DashboardController {


	private Logger logger = Logger.getLogger(this.getClass());

	@Autowired
	private RecentActivityService recentActivityService;

	@Autowired
	private UserAttributes userAttributes;

	@Autowired
	private AlertsService alertsService;
	@Autowired
	private DesignationApplianceRepository 	designationApplianceRepository;
	@Autowired
	private	UserGroupRepository  userGroupRepository;

	@Autowired
	private PartitionRepository partitionRepository;
	@Autowired
	private ApplianceRepository applianceRepository;
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private UserACLRepository userACLRepository;



	@Lookup
	public DashboardDetails getDashboardDetails() {
		return null;
	}

	@RequestMapping(value = "groupWiseAppliancesForDashBoard", method = RequestMethod.GET)
	public DashboardDetails groupWiseAppliancesForDashBoard(){

		logger.info("start of groupWiseAppliancesForDashBoard Method");

		List<Object[]> applianceCountforEachGroups =designationApplianceRepository.numberOfAppliancesforEachGroup();
		DashboardDetails dashboardDetails =getDashboardDetails();
		try{
			if(applianceCountforEachGroups!=null && applianceCountforEachGroups.size()>0){
				String groupNames[]= new String[applianceCountforEachGroups.size()];
				String applianceCounts[]= new String[applianceCountforEachGroups.size()];
				int i=0;
				for (Object[] applianceCountforGroup : applianceCountforEachGroups) {
					try{
					Integer groupId = (Integer)applianceCountforGroup[0];
					if(groupId!=null){
					BigInteger noOfAppliances = (BigInteger)applianceCountforGroup[1];			 
					String groupName=  userGroupRepository.getGroupName(Long.valueOf(groupId.longValue()));
					groupNames[i]=groupName;
					applianceCounts[i]=String.valueOf(noOfAppliances);
					i++;
					}
					}
					catch(Exception exp){
						logger.error("error occured during groupWiseAppliancesForDashBoard while iterating :: " + exp.getMessage());
					}
				}
				dashboardDetails.setGroupNames(groupNames);
				dashboardDetails.setApplianceCounts(applianceCounts);
			}

		}catch(Exception exp){
			logger.error("error occured during groupWiseAppliancesForDashBoard :: " + exp.getMessage());
		}
		logger.info("end of groupWiseAppliancesForDashBoard Method");
		return dashboardDetails;
	}

	@RequestMapping(value = "recentActivitiesForDashBoard", method = RequestMethod.GET)
	public  DashboardDetails recentActivitiesForDashBoard(){

		logger.info("start of recentActivitiesForDashBoard Method");
		DashboardDetails dashboardDetails =getDashboardDetails();
		List<RecentActivity> recentActivity= new ArrayList<RecentActivity>();
		try{
			String loggedInUser = userAttributes.getlogInUserName();
			recentActivity=recentActivityService.getRecentActivity(loggedInUser,null);
			dashboardDetails.setRecentActivity(recentActivity);
		}catch(Exception exp){
			logger.error("error occured during recentActivitiesForDashBoard :: " + exp.getMessage());
		}
		logger.info("end of recentActivitiesForDashBoard Method");
		return dashboardDetails;
	}


	@RequestMapping(value = "usersDetailsForDashBoard", method = RequestMethod.GET)
	public DashboardDetails usersDetailsForDashBoard(){

		logger.info("start of usersDetailsForDashBoard Method");

		DashboardDetails dashboardDetails =getDashboardDetails();
		try{
			List<Object[]> usersCountWithACLs=userRepository.getNumberOfUsersForEachACL();
			if(usersCountWithACLs!=null){
				String aclNames[]= new String[usersCountWithACLs.size()];
				String usersCount[]= new String[usersCountWithACLs.size()];
				int i=0;
				for (Object[] usersCountWithACL : usersCountWithACLs) {
					try{
					Integer aclId = (Integer)usersCountWithACL[0];
					BigInteger noOfUsers = (BigInteger)usersCountWithACL[1];			 
					String applianceName=  userACLRepository.getACLName(Long.valueOf(aclId.longValue()));
					aclNames[i]=applianceName;
					usersCount[i]=String.valueOf(noOfUsers);
					i++;
					}catch (Exception e) { 
						logger.error("error occured during usersDetailsForDashBoard while iterating :: " + e.getMessage());
					}
				}
				dashboardDetails.setAclNames(aclNames);
				dashboardDetails.setUserCounts(usersCount);
			}
		}catch(Exception exp){
			logger.error("error occured during usersDetailsForDashBoard :: " + exp.getMessage());
		}
		logger.info("end of usersDetailsForDashBoard Method");
		return dashboardDetails;
	}


	@RequestMapping(value = "partitionWiseAppliancesForDashBoard", method = RequestMethod.GET)
	public DashboardDetails partitionWiseAppliancesForDashBoard(){

		logger.info("start of partitionWiseAppliancesForDashBoard Method");

		DashboardDetails dashboardDetails =getDashboardDetails();
		try{
			List<Object[]> partitionCountWithAppliances =partitionRepository.numberOfPartitionsforEachAppliance();
			if(partitionCountWithAppliances!=null){
				String applianceNames[]= new String[partitionCountWithAppliances.size()];
				String partitionsCount[]= new String[partitionCountWithAppliances.size()];
				int i=0;
				for (Object[] partitionCountWithAppliance : partitionCountWithAppliances) {
					try{
					Integer applianceId = (Integer)partitionCountWithAppliance[0];
					BigInteger noOfPartitions = (BigInteger)partitionCountWithAppliance[1];			 
					String applianceName=  applianceRepository.getApplianceName(Long.valueOf(applianceId.longValue()));
					applianceNames[i]=applianceName;
					partitionsCount[i]=String.valueOf(noOfPartitions);
					i++;
					}catch(Exception exp){
						logger.error("error occured during partitionWiseAppliancesForDashBoard while iterating :: " + exp.getMessage());
					}
				}
				dashboardDetails.setApplianceNames(applianceNames);
				dashboardDetails.setPartitionCounts(partitionsCount);
			}
		}catch(Exception exp){
			logger.error("error occured during partitionWiseAppliancesForDashBoard :: " + exp.getMessage());
		}
		logger.info("end of partitionWiseAppliancesForDashBoard Method");
		return dashboardDetails;
	}


	@RequestMapping(value = "alertsForDashBoard", method = RequestMethod.GET)
	public DashboardDetails alertsForDashBoard(){

		logger.info("start of alertsForDashBoard Method");
		DashboardDetails dashboardDetails =getDashboardDetails();
		List<Alerts> alerts = null;
		try{
			String loggedInUser = userAttributes.getlogInUserName();
			alerts=alertsService.getAlerts(loggedInUser,null);
			dashboardDetails.setAlerts(alerts);
		}catch(Exception exp){
			logger.error("error occured during alertsForDashBoard" + exp.getMessage());
		}
		logger.info("end of alertsForDashBoard Method");
		return dashboardDetails;
	}

	@RequestMapping(value = "userTrackingSummaryForDashBoard", method = RequestMethod.GET)
	public DashboardDetails userTrackingSummaryForDashBoard(){

		logger.info("start of userTrackingSummaryForDashBoard Method");


		try{

		}catch(Exception exp){
			logger.error("error occured during userTrackingSummaryForDashBoard" + exp.getMessage());
		}
		logger.info("end of userTrackingSummaryForDashBoard Method");
		return null;
	}
	
	@RequestMapping(value = "systemInformation", method = RequestMethod.GET)
	public SystemInformationDetails systemInformationForDashBoard(){

		logger.info("start of systemInformationForDashBoard Method");
		SystemInformationDetails systemInformationDetails=null;

		try{
			SystemInformationUtil systemInformationUtil= new SystemInformationUtil();
			systemInformationDetails=systemInformationUtil.getSystemInformationDetails();
			
			systemInformationDetails.setAppVersion("1.0");
			systemInformationDetails.setReleaseDate(CaviumUtil.formatDateTimeFromCurrenDate(new Date()) + " IST");
			int noOfAppliances=applianceRepository.getTotalNumberOfAppliances("PERMANENT");
			systemInformationDetails.setNumberofApplianceConnected(noOfAppliances);
		}catch(Exception exp){
			logger.error("error occured during systemInformationForDashBoard :: " + exp.getMessage());
		}
		logger.info("end of systemInformationForDashBoard Method");
		return systemInformationDetails;
	}
}
