package com.cavium.controller.devicediscovery;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.pojo.DeviceDiscoveryDetail;
import com.cavium.repository.appliance.ApplianceRepository;
import com.cavium.utill.CaviumConstant;
import com.cavium.utill.CaviumUtil;
import com.cavium.utill.SNMPUtil;

@RestController
@RequestMapping("rest")
public class DeviceDiscoveryController {

	

	@Autowired
	private ApplianceRepository applianceRepository;
	
	private Logger logger = Logger.getLogger(this.getClass());

	@RequestMapping(value = "discoverIpAddress", method = RequestMethod.POST)
	public DeviceDiscoveryDetail getDiscoverIpAddress(@RequestBody DeviceDiscoveryDetail snmpDiscoveryDetail) {

		logger.info("inside getDiscoverIpAddress method");
		boolean discoverIp=false;
		try {
			String ipAddress=snmpDiscoveryDetail.getIpAddress();
			boolean  ipAddressValid=CaviumUtil.validateIp(ipAddress);
			if(!ipAddressValid){
				snmpDiscoveryDetail.setErrorMessage("Ip is not valid");
				return snmpDiscoveryDetail;
			}
			 String startRange[]=ipAddress.split("\\.");
			 if (startRange.length != 4){
				 snmpDiscoveryDetail.setErrorMessage("Ip is not valid");
				return snmpDiscoveryDetail;
			}
			int count= applianceRepository.checkIpExistorNot(ipAddress);
			if(count==0){
			discoverIp =SNMPUtil.discoverSNMP(ipAddress);
			snmpDiscoveryDetail.getIpDiscoveryResults().put(ipAddress, Boolean.valueOf(discoverIp));
			}else{
				snmpDiscoveryDetail.getIpDiscoveryResults().put(ipAddress,"Ip already Exist in our DB");
			}
		} catch (Exception e) {
			logger.error("error occured during getDiscoverIpAddress method of SNMPController class" + e.getMessage());
		}
		return snmpDiscoveryDetail;
	}

	@RequestMapping(value = "discoverIpAddressRange", method = RequestMethod.POST)
	public DeviceDiscoveryDetail getDiscoverIpAddressRange(@RequestBody DeviceDiscoveryDetail snmpDiscoveryDetail) {
		logger.info("inside getDiscoverIpAddressRange method");
		boolean discoverIp=false;
		int start=0;
		int end=0;
		String startingIndex=null;
		String endingIndex=null;

		try {
			String startingRange=snmpDiscoveryDetail.getIpAddressStartingRange();
			String endingRange=snmpDiscoveryDetail.getIpAddressEndRange();
			boolean  startingIpvalid=CaviumUtil.validateIp(startingRange);
			boolean  endIpvalid=CaviumUtil.validateIp(endingRange);
			if(!startingIpvalid){
				snmpDiscoveryDetail.setErrorMessage("Staring Ip is not valid");
				return snmpDiscoveryDetail;
			}
			if(!endIpvalid){
				snmpDiscoveryDetail.setErrorMessage("End Ip is not valid");
				return snmpDiscoveryDetail;
			}
			 
			String startRange[]=startingRange.split("\\.");
			String endRange[]=endingRange.split("\\.");
			if (startRange.length != 4 || endRange.length != 4){
				snmpDiscoveryDetail.setErrorMessage("Ip is not valid");
				return snmpDiscoveryDetail;
			}
			if((startRange[0].equalsIgnoreCase(endRange[0])) && (startRange[1].equalsIgnoreCase(endRange[1])) && (startRange[2].equalsIgnoreCase(endRange[2]))){
			if(Integer.parseInt(startRange[3])<=Integer.parseInt(endRange[3])){
			if(startRange.length==4 && endRange.length==4){
			
			
				startingIndex=startRange[3];
				endingIndex=endRange[3];
				if(startingIndex!=null &&  endingIndex!=null){
					start=Integer.parseInt(startingIndex);
					end=Integer.parseInt(endingIndex);

					for(int range=start; range<=end;range++){
						String ipAddress=startRange[0]+CaviumConstant.DOT+startRange[1]+CaviumConstant.DOT+startRange[2]+CaviumConstant.DOT+range;
						int count= applianceRepository.checkIpExistorNot(ipAddress);
						if(count==0){
						discoverIp =SNMPUtil.discoverSNMP(ipAddress);
						snmpDiscoveryDetail.getIpDiscoveryResults().put(ipAddress, Boolean.valueOf(discoverIp));
						}else{
							snmpDiscoveryDetail.getIpDiscoveryResults().put(ipAddress,"Ip already Exist in our DB");
						}
					}
				}	
				else{
					
				}
			}
			}else{
				snmpDiscoveryDetail.setErrorMessage("Starting Ip should be Smaller from End Ip.");	
			}
			}else{
				snmpDiscoveryDetail.setErrorMessage("Start and End Ip should be in same range");
			}			
		}
		catch (Exception e) {
			logger.error("error occured during getDiscoverIpAddressRange method of SNMPController class" + e.getMessage());
		}
		return snmpDiscoveryDetail;
	}

}



