package com.cavium.controller.fileupload;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cavium.utill.CaviumUtil;
import com.cavium.utill.RestClient;

@RestController
@RequestMapping("/rest")
public class FileUploadController {
	
	
	@Autowired
	RestClient restClient;

    @RequestMapping(method = RequestMethod.POST)
    public String handleFileUpload(
            @RequestParam("file") MultipartFile multipartFile ,@RequestParam("username") String username ) throws IOException {
        try{
        	
        	MultiValueMap<String, Object> bodyMap = new LinkedMultiValueMap<>();
            File convertedFile= CaviumUtil.convert(multipartFile);
            bodyMap.add("file", getUserFileResource(convertedFile));
            bodyMap.add("username", "cavium");
            bodyMap.add("password", "default");
            bodyMap.add("type", "InitHSM");
           
            ResponseEntity<String>  response=restClient.invokePOSTMethodObject("https://10.89.7.150/liquidsa/upload", bodyMap);
     
        }catch(Exception ex){
        	ex.printStackTrace();
        	ex.getStackTrace();
        	ex.getMessage();
        }
        return "file uploaded";
    }
    
    public static Resource getUserFileResource(File convertedfile) throws IOException {
 
        return new FileSystemResource(convertedfile);
    }
}