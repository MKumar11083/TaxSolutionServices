package com.cavium.controller.hostadminvm;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.hostadminvm.monitorstats.MonitorStats;
import com.cavium.pojo.AdminVMSelfTestReport;
import com.cavium.pojo.ApplianceInfo;
import com.cavium.pojo.HSMInfo;
import com.cavium.pojo.HostSelfTestReport;
import com.cavium.pojo.PartitionsDetails;
import com.cavium.pojo.hostadminvm.AdminSNMPConfig;
import com.cavium.pojo.hostadminvm.AdminVMConfig;
import com.cavium.pojo.hostadminvm.HostStats;
import com.cavium.pojo.hostadminvm.HostSystemInfo;
import com.cavium.service.appliance.ApplianceService;
import com.cavium.service.hostadminvm.HostAdminVMService;
import com.cavium.service.partition.PartitionService;
import com.cavium.utill.CaviumResponseModel;

@RestController
@RequestMapping("rest")
public class AdminVMDetailsController {

	@Autowired
	private ApplianceService applianceService;
	@Autowired
	private PartitionService partitionService;
	@Autowired
	private HostAdminVMService hostAdminVMService;
	@Lookup
	public HostStats getHostStats() {
		return null;
	}
	@Lookup
	public CaviumResponseModel getCaviumResponseModel() {
		return null;
	}
	@Lookup
	public PartitionsDetails getPartitionsDetails() {
		return null;
	}

	@Lookup
	public ApplianceInfo getApplianceInfo() {
		return null;
	}

	@Lookup
	public HostSystemInfo getHostSystemInfo() {
		return null;
	}
	@Lookup
	public HSMInfo getHSMInfo() {
		return null;
	}
	@Lookup
	public AdminVMConfig getAdminVMConfig() {
		return null;
	}

	@Lookup
	public AdminSNMPConfig getAdminSNMPConfig() {
		return null;
	}

	@Lookup
	public AdminVMSelfTestReport getAdminVMSelfTestReport() {
		return null;
	}

	@Lookup
	public HostSelfTestReport getHostSelfTestReport() {
		return null;
	}

	private Logger logger = Logger.getLogger(this.getClass());

	@RequestMapping(value = "getAdminVMInfo/{applianceId}", method = RequestMethod.GET)
	public HostSystemInfo getAdminVMInfo(@PathVariable("applianceId") String applianceId){
		logger.info("start of getAdminVMInfo Method");
		ApplianceDetailModel applianceDetailModel = null ;
		HostSystemInfo hostSystemInfo=getHostSystemInfo();
		String apiName="admin_vm_stats";
		PartitionsDetails partitionsDetails=getPartitionsDetails();
		try{
			applianceDetailModel=applianceService.getApplianceById(applianceId);		 
			partitionsDetails=partitionService.getPartitionInfo(applianceDetailModel,partitionsDetails);		
			HostStats hostStats=hostAdminVMService.GetHostAdminVMStats(applianceDetailModel,getHostStats(),apiName);
			ApplianceInfo	applianceInfo=applianceService.GetApplianceInfo(applianceDetailModel,getApplianceInfo());
			HSMInfo	hsmInfo=applianceService.getHSMInfo(applianceDetailModel,getHSMInfo());
			AdminVMConfig	adminVMConfig=hostAdminVMService.GetAdminVMConfig(applianceDetailModel,getAdminVMConfig());
			AdminSNMPConfig	adminSNMPConfig=hostAdminVMService.GetAdminSNMPConfig(applianceDetailModel,getAdminSNMPConfig());
			hostSystemInfo.setApplianceInfo(applianceInfo);
			hostSystemInfo.setHostStats(hostStats);
			hostSystemInfo.setPartitionsDetails(partitionsDetails);
			hostSystemInfo.setAdminSNMPConfig(adminSNMPConfig);
			hostSystemInfo.setAdminVMConfig(adminVMConfig);		
			hostSystemInfo.setApplianceDetailModel(applianceDetailModel);
			hostSystemInfo.setHsmInfo(hsmInfo);
			logger.info("end of getAdminVMInfo Method");
		}catch(Exception exp){
			logger.error("error while get AdminVMInfo ::"+exp.getMessage());
		}
		return hostSystemInfo;
	}

	
	

	@RequestMapping(value = "getAdminNetworkInfo/{applianceId}", method = RequestMethod.GET)
	public HostSystemInfo getAdminNetworkInfo(@PathVariable("applianceId") String applianceId){
		logger.info("start of getAdminNetworkInfo Method");
		ApplianceDetailModel applianceDetailModel = new ApplianceDetailModel() ;		 
		HostSystemInfo	hostSystemInfo=getHostSystemInfo();
		try{	 
			applianceDetailModel=applianceService.getApplianceById(applianceId);
			AdminVMConfig	adminVMConfig=hostAdminVMService.GetAdminVMConfig(applianceDetailModel,getAdminVMConfig());
			hostSystemInfo.setAdminVMConfig(adminVMConfig);	
			hostSystemInfo.setApplianceDetailModel(applianceDetailModel);
			logger.info("end of getAdminNetworkInfo Method");
		}catch(Exception exp){
			logger.error("error while getAdminNetworkInfo ::"+exp.getMessage());
		}
		return hostSystemInfo;
	}
	
	
	@RequestMapping(value = "getAdminVMSelfTestReport/{applianceId}", method = RequestMethod.GET)
	public AdminVMSelfTestReport getAdminVMSelfTestReport(@PathVariable("applianceId") String applianceId){
		logger.info("start of getAdminVMSelfTestReport Method");
		ApplianceDetailModel applianceDetailModel = null ;
		AdminVMSelfTestReport AdminVMSFTInfo = getAdminVMSelfTestReport();
		String apiName="admin_vm_selftest_report";
		try{
			applianceDetailModel=applianceService.getApplianceById(applianceId);		 
			AdminVMSFTInfo=applianceService.getAdminVMSelfTestReport(applianceDetailModel, AdminVMSFTInfo);
			logger.info("end of getAdminVMSelfTestReport Method");
		}catch(Exception exp){
			logger.error("error while get getAdminVMSelfTestReport ::"+exp.getMessage());
		}
		return AdminVMSFTInfo;
	}
	
	@RequestMapping(value = "getHostSelfTestReport/{applianceId}", method = RequestMethod.GET)
	public HostSelfTestReport getHostSelfTestReport(@PathVariable("applianceId") String applianceId){
		logger.info("start of getHostSelfTestReport Method");
		ApplianceDetailModel applianceDetailModel = null ;
		HostSelfTestReport HostSFTInfo = getHostSelfTestReport();
		String apiName="admin_vm_selftest_report";
		try{
			applianceDetailModel=applianceService.getApplianceById(applianceId);		 
			HostSFTInfo = applianceService.getHostSelfTestReport(applianceDetailModel, HostSFTInfo);
			logger.info("end of getAdminVMSelfTestReport Method");
		}catch(Exception exp){
			logger.error("error while get getAdminVMSelfTestReport ::"+exp.getMessage());
		}
		return HostSFTInfo;
	}

	@RequestMapping(value = "adminMonitorStats", method = RequestMethod.POST)
	public final List<MonitorStats> getHostMonitorStats(@RequestBody ApplianceDetailModel applianceDetailModel) {
		List<MonitorStats> monitorStatsList= new ArrayList<MonitorStats>();
		try {
			String apiName="admin";
			monitorStatsList=hostAdminVMService.getMonitorStats(applianceDetailModel.getIpAddress(), apiName);
			for (Iterator<MonitorStats> iterator = monitorStatsList.iterator(); iterator.hasNext();) {
				MonitorStats monitorStats = (MonitorStats) iterator.next();
				monitorStats.setUsageInfo(monitorStats.getData().getCpu().getUsageInfo());
				monitorStats.setInfo(monitorStats.getData().getPcpu().getInfo());
				monitorStats.setListCpus(monitorStats.getData().getPcpu().getListCpus());
				monitorStats.setDetails(monitorStats.getData().getMemory().getDetails());
				monitorStats.setUsage(monitorStats.getData().getMemory().getUsage());
				monitorStats.setLo(monitorStats.getData().getNetwork().getLo());
				monitorStats.setSit0(monitorStats.getData().getNetwork().getSit0());
				monitorStats.setEth1(monitorStats.getData().getNetwork().getEth1());
				monitorStats.setEth0(monitorStats.getData().getNetwork().getEth0());
				monitorStats.setData(null);
		 }
			}
		 catch (Exception e) {
			 logger.error("error while getHostMonitorStats ::"+e.getMessage());
		}
		return monitorStatsList;
	}
}
