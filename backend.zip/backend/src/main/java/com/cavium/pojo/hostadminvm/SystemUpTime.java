package com.cavium.pojo.hostadminvm;

public class SystemUpTime {
	 private long hours;
	 private long seconds;
	 private long minutes;
	 private String formatedDate;
	/**
	 * @return the hours
	 */
	public long getHours() {
		return hours;
	}
	/**
	 * @param hours the hours to set
	 */
	public void setHours(long hours) {
		this.hours = hours;
	}
	/**
	 * @return the seconds
	 */
	public long getSeconds() {
		return seconds;
	}
	/**
	 * @param seconds the seconds to set
	 */
	public void setSeconds(long seconds) {
		this.seconds = seconds;
	}
	/**
	 * @return the minutes
	 */
	public long getMinutes() {
		return minutes;
	}
	/**
	 * @param minutes the minutes to set
	 */
	public void setMinutes(long minutes) {
		this.minutes = minutes;
	}
	/**
	 * @return the formatedDate
	 */
	public String getFormatedDate() {
		return formatedDate;
	}
	/**
	 * @param formatedDate the formatedDate to set
	 */
	public void setFormatedDate(String formatedDate) {
		this.formatedDate = formatedDate;
	}
	 
	 
}