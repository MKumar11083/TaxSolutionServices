package com.cavium.pojo.logs;

public class Logs
{
  private Admin admin;

  public Admin getAdmin() { return this.admin; }

  public void setAdmin(Admin admin) { this.admin = admin; }

  private Host host;

  public Host getHost() { return this.host; }

  public void setHost(Host host) { this.host = host; }

  private Partitions partitions;

  public Partitions getPartitions() { return this.partitions; }

  public void setPartitions(Partitions partitions) { this.partitions = partitions; }
}
