package com.cavium.pojo.partitionstats;
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
@Entity
@Table(name = "partition_stats_rx_queue_details")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class RxQueue implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@JsonProperty(access = Access.WRITE_ONLY)
	@Column(name = "id", nullable = false)
	private Long id;

	@Column(name = "rdt")
	private Long rdt;

	@Column(name = "rdh")
	private Long rdh;
	/**
	 * @return the rdt
	 */
	public Long getRdt() {
		return rdt;
	}
	/**
	 * @param rdt the rdt to set
	 */
	public void setRdt(Long rdt) {
		this.rdt = rdt;
	}
	/**
	 * @return the rdh
	 */
	public Long getRdh() {
		return rdh;
	}
	/**
	 * @param rdh the rdh to set
	 */
	public void setRdh(Long rdh) {
		this.rdh = rdh;
	}
	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}


}
