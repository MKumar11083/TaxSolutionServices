package com.cavium.pojo;

import com.cavium.model.appliance.ApplianceDetailModel;

public class PartitionDetailsWithPercentage {

	private double percentage;
	private String type;
	private ApplianceDetailModel applianceDetailModel;
	/**
	 * @return the percentage
	 */
	public double getPercentage() {
		return percentage;
	}
	/**
	 * @param percentage the percentage to set
	 */
	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return the applianceDetailModel
	 */
	public ApplianceDetailModel getApplianceDetailModel() {
		return applianceDetailModel;
	}
	/**
	 * @param applianceDetailModel the applianceDetailModel to set
	 */
	public void setApplianceDetailModel(ApplianceDetailModel applianceDetailModel) {
		this.applianceDetailModel = applianceDetailModel;
	}
}
