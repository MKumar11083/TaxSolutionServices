package com.cavium.pojo.hostadminvm;

public class AdminSNMPData {

	 private boolean enabled;

	    private boolean enableTrap;

	    private String ip;

	    private String uname;

	    private int port;

	    private String engineId;

	    private AuthMode authMode;

	    private PrivMode privMode;

	    public void setEnabled(boolean enabled){
	        this.enabled = enabled;
	    }
	    public boolean getEnabled(){
	        return this.enabled;
	    }
	    public void setEnableTrap(boolean enableTrap){
	        this.enableTrap = enableTrap;
	    }
	    public boolean getEnableTrap(){
	        return this.enableTrap;
	    }
	    public void setIp(String ip){
	        this.ip = ip;
	    }
	    public String getIp(){
	        return this.ip;
	    }
	    public void setUname(String uname){
	        this.uname = uname;
	    }
	    public String getUname(){
	        return this.uname;
	    }
	    public void setPort(int port){
	        this.port = port;
	    }
	    public int getPort(){
	        return this.port;
	    }
	    public void setEngineId(String engineId){
	        this.engineId = engineId;
	    }
	    public String getEngineId(){
	        return this.engineId;
	    }
	    public void setAuthMode(AuthMode authMode){
	        this.authMode = authMode;
	    }
	    public AuthMode getAuthMode(){
	        return this.authMode;
	    }
	    public void setPrivMode(PrivMode privMode){
	        this.privMode = privMode;
	    }
	    public PrivMode getPrivMode(){
	        return this.privMode;
	    }
}
