package com.cavium.pojo;

import java.io.Serializable;

public class SNMPDetails implements Serializable {
	 /**
	 * 
	 */
	private static final long serialVersionUID = -6906422746991615876L;
	
	private boolean enable;
	 private boolean enableTrap;
	 private String snmpip;
	 private String uname;
	 private int port;
	 private String engineId;
	 private String authModeEncryption;
	 private String authModePassword;
	 private String privModeEncryption;
	 private String privModePassword;
	 private String applianceIp;
	 private Long applianceId;
	 private String message;
	 private String code;
	 private String operationUsername;
	 private String operationPassword;
	/**
	 * @return the enable
	 */
	public boolean isEnable() {
		return enable;
	}
	/**
	 * @param enable the enable to set
	 */
	public void setEnable(boolean enable) {
		this.enable = enable;
	}
	/**
	 * @return the enableTrap
	 */
	public boolean isEnableTrap() {
		return enableTrap;
	}
	/**
	 * @param enableTrap the enableTrap to set
	 */
	public void setEnableTrap(boolean enableTrap) {
		this.enableTrap = enableTrap;
	}
	/**
	 * @return the snmpip
	 */
	public String getSnmpip() {
		return snmpip;
	}
	/**
	 * @param snmpip the snmpip to set
	 */
	public void setSnmpip(String snmpip) {
		this.snmpip = snmpip;
	}
	/**
	 * @return the uname
	 */
	public String getUname() {
		return uname;
	}
	/**
	 * @param uname the uname to set
	 */
	public void setUname(String uname) {
		this.uname = uname;
	}
	/**
	 * @return the port
	 */
	public int getPort() {
		return port;
	}
	/**
	 * @param port the port to set
	 */
	public void setPort(int port) {
		this.port = port;
	}
	/**
	 * @return the engineId
	 */
	public String getEngineId() {
		return engineId;
	}
	/**
	 * @param engineId the engineId to set
	 */
	public void setEngineId(String engineId) {
		this.engineId = engineId;
	}
	/**
	 * @return the authModeEncryption
	 */
	public String getAuthModeEncryption() {
		return authModeEncryption;
	}
	/**
	 * @param authModeEncryption the authModeEncryption to set
	 */
	public void setAuthModeEncryption(String authModeEncryption) {
		this.authModeEncryption = authModeEncryption;
	}
	/**
	 * @return the authModePassword
	 */
	public String getAuthModePassword() {
		return authModePassword;
	}
	/**
	 * @param authModePassword the authModePassword to set
	 */
	public void setAuthModePassword(String authModePassword) {
		this.authModePassword = authModePassword;
	}
	 
	/**
	 * @return the applianceIp
	 */
	public String getApplianceIp() {
		return applianceIp;
	}
	/**
	 * @param applianceIp the applianceIp to set
	 */
	public void setApplianceIp(String applianceIp) {
		this.applianceIp = applianceIp;
	}
	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}
	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}
	/**
	 * @return the applianceId
	 */
	public Long getApplianceId() {
		return applianceId;
	}
	/**
	 * @param applianceId the applianceId to set
	 */
	public void setApplianceId(Long applianceId) {
		this.applianceId = applianceId;
	}
	/**
	 * @return the privModeEncryption
	 */
	public String getPrivModeEncryption() {
		return privModeEncryption;
	}
	/**
	 * @param privModeEncryption the privModeEncryption to set
	 */
	public void setPrivModeEncryption(String privModeEncryption) {
		this.privModeEncryption = privModeEncryption;
	}
	/**
	 * @return the privModePassword
	 */
	public String getPrivModePassword() {
		return privModePassword;
	}
	/**
	 * @param privModePassword the privModePassword to set
	 */
	public void setPrivModePassword(String privModePassword) {
		this.privModePassword = privModePassword;
	}
	/**
	 * @return the operationUsername
	 */
	public String getOperationUsername() {
		return operationUsername;
	}
	/**
	 * @param operationUsername the operationUsername to set
	 */
	public void setOperationUsername(String operationUsername) {
		this.operationUsername = operationUsername;
	}
	/**
	 * @return the operationPassword
	 */
	public String getOperationPassword() {
		return operationPassword;
	}
	/**
	 * @param operationPassword the operationPassword to set
	 */
	public void setOperationPassword(String operationPassword) {
		this.operationPassword = operationPassword;
	}
 
 
	}

