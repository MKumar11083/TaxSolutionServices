package com.cavium.pojo.hostadminvm;

import java.util.List;

import org.springframework.stereotype.Component;
@Component
public class AdminVMConfig
{
    private String status;

    private List<String> errors;

    private String partitionName;

    private String jobId;

    private String startTime;

    private String message;

    private String endTime;

    private AdminVMData adminVMData;

    private String operation;

    public void setStatus(String status){
        this.status = status;
    }
    public String getStatus(){
        return this.status;
    }
    public void setErrors(List<String> errors){
        this.errors = errors;
    }
    public List<String> getErrors(){
        return this.errors;
    }
    public void setPartitionName(String partitionName){
        this.partitionName = partitionName;
    }
    public String getPartitionName(){
        return this.partitionName;
    }
    public void setJobId(String jobId){
        this.jobId = jobId;
    }
    public String getJobId(){
        return this.jobId;
    }
    public void setStartTime(String startTime){
        this.startTime = startTime;
    }
    public String getStartTime(){
        return this.startTime;
    }
    public void setMessage(String message){
        this.message = message;
    }
    public String getMessage(){
        return this.message;
    }
    public void setEndTime(String endTime){
        this.endTime = endTime;
    }
    public String getEndTime(){
        return this.endTime;
    }
  
    public void setOperation(String operation){
        this.operation = operation;
    }
    public String getOperation(){
        return this.operation;
    }
	/**
	 * @return the adminVMData
	 */
	public AdminVMData getAdminVMData() {
		return adminVMData;
	}
	/**
	 * @param adminVMData the adminVMData to set
	 */
	public void setAdminVMData(AdminVMData adminVMData) {
		this.adminVMData = adminVMData;
	}
 
}
