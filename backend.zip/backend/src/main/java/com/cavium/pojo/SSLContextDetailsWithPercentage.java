package com.cavium.pojo;

import java.util.ArrayList;
import java.util.List;

public class SSLContextDetailsWithPercentage {

	private List<PartitionDetailsWithPercentage> tenPercentList= new ArrayList<PartitionDetailsWithPercentage>();
	private List<PartitionDetailsWithPercentage> twentyPercentList=new ArrayList<PartitionDetailsWithPercentage>();
	private List<PartitionDetailsWithPercentage> thirtyPercentList=new ArrayList<PartitionDetailsWithPercentage>();
	private List<PartitionDetailsWithPercentage> fortyPercentList=new ArrayList<PartitionDetailsWithPercentage>();
	private List<PartitionDetailsWithPercentage> fiftyPercentList=new ArrayList<PartitionDetailsWithPercentage>();
	private List<PartitionDetailsWithPercentage> sixtyPercentList=new ArrayList<PartitionDetailsWithPercentage>();
	private List<PartitionDetailsWithPercentage> seventyPercentList=new ArrayList<PartitionDetailsWithPercentage>();
	private List<PartitionDetailsWithPercentage> eightyPercentList=new ArrayList<PartitionDetailsWithPercentage>();
	private List<PartitionDetailsWithPercentage> ninetyPercentList=new ArrayList<PartitionDetailsWithPercentage>();
	private List<PartitionDetailsWithPercentage> hundredPercentList=new ArrayList<PartitionDetailsWithPercentage>();
	/**
	 * @return the tenPercentList
	 */
	public List<PartitionDetailsWithPercentage> getTenPercentList() {
		return tenPercentList;
	}
	/**
	 * @param tenPercentList the tenPercentList to set
	 */
	public void setTenPercentList(List<PartitionDetailsWithPercentage> tenPercentList) {
		this.tenPercentList = tenPercentList;
	}
	/**
	 * @return the twentyPercentList
	 */
	public List<PartitionDetailsWithPercentage> getTwentyPercentList() {
		return twentyPercentList;
	}
	/**
	 * @param twentyPercentList the twentyPercentList to set
	 */
	public void setTwentyPercentList(List<PartitionDetailsWithPercentage> twentyPercentList) {
		this.twentyPercentList = twentyPercentList;
	}
	/**
	 * @return the thirtyPercentList
	 */
	public List<PartitionDetailsWithPercentage> getThirtyPercentList() {
		return thirtyPercentList;
	}
	/**
	 * @param thirtyPercentList the thirtyPercentList to set
	 */
	public void setThirtyPercentList(List<PartitionDetailsWithPercentage> thirtyPercentList) {
		this.thirtyPercentList = thirtyPercentList;
	}
	/**
	 * @return the fortyPercentList
	 */
	public List<PartitionDetailsWithPercentage> getFortyPercentList() {
		return fortyPercentList;
	}
	/**
	 * @param fortyPercentList the fortyPercentList to set
	 */
	public void setFortyPercentList(List<PartitionDetailsWithPercentage> fortyPercentList) {
		this.fortyPercentList = fortyPercentList;
	}
	/**
	 * @return the fiftyPercentList
	 */
	public List<PartitionDetailsWithPercentage> getFiftyPercentList() {
		return fiftyPercentList;
	}
	/**
	 * @param fiftyPercentList the fiftyPercentList to set
	 */
	public void setFiftyPercentList(List<PartitionDetailsWithPercentage> fiftyPercentList) {
		this.fiftyPercentList = fiftyPercentList;
	}
	/**
	 * @return the sixtyPercentList
	 */
	public List<PartitionDetailsWithPercentage> getSixtyPercentList() {
		return sixtyPercentList;
	}
	/**
	 * @param sixtyPercentList the sixtyPercentList to set
	 */
	public void setSixtyPercentList(List<PartitionDetailsWithPercentage> sixtyPercentList) {
		this.sixtyPercentList = sixtyPercentList;
	}
	/**
	 * @return the seventyPercentList
	 */
	public List<PartitionDetailsWithPercentage> getSeventyPercentList() {
		return seventyPercentList;
	}
	/**
	 * @param seventyPercentList the seventyPercentList to set
	 */
	public void setSeventyPercentList(List<PartitionDetailsWithPercentage> seventyPercentList) {
		this.seventyPercentList = seventyPercentList;
	}
	/**
	 * @return the eightyPercentList
	 */
	public List<PartitionDetailsWithPercentage> getEightyPercentList() {
		return eightyPercentList;
	}
	/**
	 * @param eightyPercentList the eightyPercentList to set
	 */
	public void setEightyPercentList(List<PartitionDetailsWithPercentage> eightyPercentList) {
		this.eightyPercentList = eightyPercentList;
	}
	/**
	 * @return the ninetyPercentList
	 */
	public List<PartitionDetailsWithPercentage> getNinetyPercentList() {
		return ninetyPercentList;
	}
	/**
	 * @param ninetyPercentList the ninetyPercentList to set
	 */
	public void setNinetyPercentList(List<PartitionDetailsWithPercentage> ninetyPercentList) {
		this.ninetyPercentList = ninetyPercentList;
	}
	/**
	 * @return the hundredPercentList
	 */
	public List<PartitionDetailsWithPercentage> getHundredPercentList() {
		return hundredPercentList;
	}
	/**
	 * @param hundredPercentList the hundredPercentList to set
	 */
	public void setHundredPercentList(List<PartitionDetailsWithPercentage> hundredPercentList) {
		this.hundredPercentList = hundredPercentList;
	}
}
