package com.cavium.pojo;

public class PartitionSnapshotDetails {
	
	
	private KeyDetailsWithPercentage keyDetailsWithPercentage = new KeyDetailsWithPercentage();
	private AcclrDetailsWithPercentage acclrDeviceDetailsWithPercentage= new AcclrDetailsWithPercentage();
	private SSLContextDetailsWithPercentage contextDetailsWithPercentage= new SSLContextDetailsWithPercentage();
	private int zeroizedState;
	private int fipMode;
	private int fipModeWithDualfactor;
	private int nonFipMode;
	private int avaliablePartitionSlots;
	private int totalPartitionSlots;
	private int occupiedPartitionSlots;
	private int partitionFunctionalStatus;
	private int partitionNonFunctionalStatus;
	
	 
	/**
	 * @return the zeroizedState
	 */
	public int getZeroizedState() {
		return zeroizedState;
	}
	/**
	 * @param zeroizedState the zeroizedState to set
	 */
	public void setZeroizedState(int zeroizedState) {
		this.zeroizedState = zeroizedState;
	}
	/**
	 * @return the fipMode
	 */
	public int getFipMode() {
		return fipMode;
	}
	/**
	 * @param fipMode the fipMode to set
	 */
	public void setFipMode(int fipMode) {
		this.fipMode = fipMode;
	}
	/**
	 * @return the fipModeWithDualfactor
	 */
	public int getFipModeWithDualfactor() {
		return fipModeWithDualfactor;
	}
	/**
	 * @param fipModeWithDualfactor the fipModeWithDualfactor to set
	 */
	public void setFipModeWithDualfactor(int fipModeWithDualfactor) {
		this.fipModeWithDualfactor = fipModeWithDualfactor;
	}
	/**
	 * @return the nonFipMode
	 */
	public int getNonFipMode() {
		return nonFipMode;
	}
	/**
	 * @param nonFipMode the nonFipMode to set
	 */
	public void setNonFipMode(int nonFipMode) {
		this.nonFipMode = nonFipMode;
	}
	/**
	 * @return the avaliablePartitionSlots
	 */
	public int getAvaliablePartitionSlots() {
		return avaliablePartitionSlots;
	}
	/**
	 * @param avaliablePartitionSlots the avaliablePartitionSlots to set
	 */
	public void setAvaliablePartitionSlots(int avaliablePartitionSlots) {
		this.avaliablePartitionSlots = avaliablePartitionSlots;
	}
	/**
	 * @return the totalPartitionSlots
	 */
	public int getTotalPartitionSlots() {
		return totalPartitionSlots;
	}
	/**
	 * @param totalPartitionSlots the totalPartitionSlots to set
	 */
	public void setTotalPartitionSlots(int totalPartitionSlots) {
		this.totalPartitionSlots = totalPartitionSlots;
	}
	/**
	 * @return the occupiedPartitionSlots
	 */
	public int getOccupiedPartitionSlots() {
		return occupiedPartitionSlots;
	}
	/**
	 * @param occupiedPartitionSlots the occupiedPartitionSlots to set
	 */
	public void setOccupiedPartitionSlots(int occupiedPartitionSlots) {
		this.occupiedPartitionSlots = occupiedPartitionSlots;
	}
	/**
	 * @return the keyDetailsWithPercentage
	 */
	public KeyDetailsWithPercentage getKeyDetailsWithPercentage() {
		return keyDetailsWithPercentage;
	}
	/**
	 * @param keyDetailsWithPercentage the keyDetailsWithPercentage to set
	 */
	public void setKeyDetailsWithPercentage(KeyDetailsWithPercentage keyDetailsWithPercentage) {
		this.keyDetailsWithPercentage = keyDetailsWithPercentage;
	}
	/**
	 * @return the acclrDeviceDetailsWithPercentage
	 */
	public AcclrDetailsWithPercentage getAcclrDeviceDetailsWithPercentage() {
		return acclrDeviceDetailsWithPercentage;
	}
	/**
	 * @param acclrDeviceDetailsWithPercentage the acclrDeviceDetailsWithPercentage to set
	 */
	public void setAcclrDeviceDetailsWithPercentage(AcclrDetailsWithPercentage acclrDeviceDetailsWithPercentage) {
		this.acclrDeviceDetailsWithPercentage = acclrDeviceDetailsWithPercentage;
	}
	/**
	 * @return the contextDetailsWithPercentage
	 */
	public SSLContextDetailsWithPercentage getContextDetailsWithPercentage() {
		return contextDetailsWithPercentage;
	}
	/**
	 * @param contextDetailsWithPercentage the contextDetailsWithPercentage to set
	 */
	public void setContextDetailsWithPercentage(SSLContextDetailsWithPercentage contextDetailsWithPercentage) {
		this.contextDetailsWithPercentage = contextDetailsWithPercentage;
	}
	/**
	 * @return the partitionFunctionalStatus
	 */
	public int getPartitionFunctionalStatus() {
		return partitionFunctionalStatus;
	}
	/**
	 * @param partitionFunctionalStatus the partitionFunctionalStatus to set
	 */
	public void setPartitionFunctionalStatus(int partitionFunctionalStatus) {
		this.partitionFunctionalStatus = partitionFunctionalStatus;
	}
	/**
	 * @return the partitionNonFunctionalStatus
	 */
	public int getPartitionNonFunctionalStatus() {
		return partitionNonFunctionalStatus;
	}
	/**
	 * @param partitionNonFunctionalStatus the partitionNonFunctionalStatus to set
	 */
	public void setPartitionNonFunctionalStatus(int partitionNonFunctionalStatus) {
		this.partitionNonFunctionalStatus = partitionNonFunctionalStatus;
	}
} 
 
