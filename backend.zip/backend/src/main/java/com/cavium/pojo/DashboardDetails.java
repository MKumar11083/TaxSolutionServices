package com.cavium.pojo;

import java.util.List;

import org.springframework.stereotype.Component;

import com.cavium.model.alerts.Alerts;
import com.cavium.model.recentactivity.RecentActivity;

@Component
public class DashboardDetails {

	 
		private List<RecentActivity> recentActivity;
	 
		private	List<Alerts> alerts;
		
		 private String[] groupNames;
		 
		 private String[] applianceCounts;
		 
		 private String[] applianceNames;
		 
		 private String[] partitionCounts;
		 
		 private String[] userCounts;
		 
		 private String[]aclNames;
		/**
		 * @return the recentActivity
		 */
		public List<RecentActivity> getRecentActivity() {
			return recentActivity;
		}
		/**
		 * @param recentActivity the recentActivity to set
		 */
		public void setRecentActivity(List<RecentActivity> recentActivity) {
			this.recentActivity = recentActivity;
		}
		 
		/**
		 * @return the alerts
		 */
		public List<Alerts> getAlerts() {
			return alerts;
		}
		/**
		 * @param alerts the alerts to set
		 */
		public void setAlerts(List<Alerts> alerts) {
			this.alerts = alerts;
		}
		/**
		 * @return the groupNames
		 */
		public String[] getGroupNames() {
			return groupNames;
		}
		/**
		 * @param groupNames the groupNames to set
		 */
		public void setGroupNames(String[] groupNames) {
			this.groupNames = groupNames;
		}
		/**
		 * @return the applianceCounts
		 */
		public String[] getApplianceCounts() {
			return applianceCounts;
		}
		/**
		 * @param applianceCounts the applianceCounts to set
		 */
		public void setApplianceCounts(String[] applianceCounts) {
			this.applianceCounts = applianceCounts;
		}
		/**
		 * @return the applianceNames
		 */
		public String[] getApplianceNames() {
			return applianceNames;
		}
		/**
		 * @param applianceNames the applianceNames to set
		 */
		public void setApplianceNames(String[] applianceNames) {
			this.applianceNames = applianceNames;
		}
		/**
		 * @return the partitionCounts
		 */
		public String[] getPartitionCounts() {
			return partitionCounts;
		}
		/**
		 * @param partitionCounts the partitionCounts to set
		 */
		public void setPartitionCounts(String[] partitionCounts) {
			this.partitionCounts = partitionCounts;
		}
		/**
		 * @return the userCounts
		 */
		public String[] getUserCounts() {
			return userCounts;
		}
		/**
		 * @param userCounts the userCounts to set
		 */
		public void setUserCounts(String[] userCounts) {
			this.userCounts = userCounts;
		}
		/**
		 * @return the aclNames
		 */
		public String[] getAclNames() {
			return aclNames;
		}
		/**
		 * @param aclNames the aclNames to set
		 */
		public void setAclNames(String[] aclNames) {
			this.aclNames = aclNames;
		}
		 
		 
		 
}
