package com.cavium.pojo;

import org.springframework.stereotype.Component;

@Component
public class HostSelfTestReport {

	private String status;
    private int jobId;
    private String startTime;
    private String errorMessage;
    private String operation;
    private String SelfTest;
    
    
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getJobId() {
		return jobId;
	}
	public void setJobId(int jobId) {
		this.jobId = jobId;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
    public String getOperation() {
		return operation;
	}
	public void setOperation(String operation) {
		this.operation = operation;
	}
	public String getSelfTest() {
		return SelfTest;
	}
	public void setSelfTest(String selfTest) {
		SelfTest = selfTest;
	}
    
}
