package com.cavium.pojo.hostadminvm;

import java.util.List;

import org.springframework.stereotype.Component;
@Component
public class AdminSNMPConfig {

	 private String status;

	    private List<String> errors;

	    private String partitionName;

	    private String jobId;

	    private String startTime;

	    private String message;

	    private String endTime;

	    private AdminSNMPData adminSNMPData;

	    public void setStatus(String status){
	        this.status = status;
	    }
	    public String getStatus(){
	        return this.status;
	    }
	    public void setErrors(List<String> errors){
	        this.errors = errors;
	    }
	    public List<String> getErrors(){
	        return this.errors;
	    }
	    public void setPartitionName(String partitionName){
	        this.partitionName = partitionName;
	    }
	    public String getPartitionName(){
	        return this.partitionName;
	    }
	    public void setJobId(String jobId){
	        this.jobId = jobId;
	    }
	    public String getJobId(){
	        return this.jobId;
	    }
	    public void setStartTime(String startTime){
	        this.startTime = startTime;
	    }
	    public String getStartTime(){
	        return this.startTime;
	    }
	    public void setMessage(String message){
	        this.message = message;
	    }
	    public String getMessage(){
	        return this.message;
	    }
	    public void setEndTime(String endTime){
	        this.endTime = endTime;
	    }
	    public String getEndTime(){
	        return this.endTime;
	    }
		/**
		 * @return the adminSNMPData
		 */
		public AdminSNMPData getAdminSNMPData() {
			return adminSNMPData;
		}
		/**
		 * @param adminSNMPData the adminSNMPData to set
		 */
		public void setAdminSNMPData(AdminSNMPData adminSNMPData) {
			this.adminSNMPData = adminSNMPData;
		}
	    
	}

