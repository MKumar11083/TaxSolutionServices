package com.cavium.pojo.partitionstats;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

@Entity
@Table(name = "partition_stats_fw_req_id_queue_details")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})

public class FwReqIdQueue implements Serializable{
	

/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
@JsonProperty(access = Access.WRITE_ONLY)
@Column(name = "id", nullable = false)
private Long id;

@Column(name = "head")
 private Long head;

@Column(name = "tail")
 private Long tail;
/**
 * @return the head
 */
public Long getHead() {
	return head;
}
/**
 * @param head the head to set
 */
public void setHead(Long head) {
	this.head = head;
}
/**
 * @return the tail
 */
public Long getTail() {
	return tail;
}
/**
 * @param tail the tail to set
 */
public void setTail(Long tail) {
	this.tail = tail;
}
/**
 * @return the id
 */
public Long getId() {
	return id;
}
/**
 * @param id the id to set
 */
public void setId(Long id) {
	this.id = id;
}


  
}
