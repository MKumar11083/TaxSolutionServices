package com.cavium.pojo.logs;

import java.util.ArrayList;

public class Partitions
{
  private ArrayList<String> options;

  public ArrayList<String> getOptions() { return this.options; }

  public void setOptions(ArrayList<String> options) { this.options = options; }

  private ArrayList<String> partitionsNames;

/**
 * @return the partitionsNames
 */
public ArrayList<String> getPartitionsNames() {
	return partitionsNames;
}

/**
 * @param partitionsNames the partitionsNames to set
 */
public void setPartitionsNames(ArrayList<String> partitionsNames) {
	this.partitionsNames = partitionsNames;
}

 
 
}
