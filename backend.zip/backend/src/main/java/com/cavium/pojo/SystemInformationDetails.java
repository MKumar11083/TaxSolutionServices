package com.cavium.pojo;

import java.util.Date;

public class SystemInformationDetails {
	
private long diskSpaceAvaliabe;
private long totaldiskSpace;

private String diskSpaceAvaliabeStr;
private String totalDiskSpaceStr;
private String usedDiskSpaceStr;
private String releaseDate;


private double ramUsage;
private double cpuUsage;
private String appVersion;
private int numberofApplianceConnected;
private Long ramSize;
private String operatingSystem;
private String lastBackUpStatus;
private Date nextBackupTime;
 
/**
 * @return the ramUsage
 */
public double getRamUsage() {
	return ramUsage;
}
/**
 * @param ramUsage the ramUsage to set
 */
public void setRamUsage(double ramUsage) {
	this.ramUsage = ramUsage;
}
 
/**
 * @return the numberofApplianceConnected
 */
public int getNumberofApplianceConnected() {
	return numberofApplianceConnected;
}
/**
 * @param numberofApplianceConnected the numberofApplianceConnected to set
 */
public void setNumberofApplianceConnected(int numberofApplianceConnected) {
	this.numberofApplianceConnected = numberofApplianceConnected;
}
 
/**
 * @return the operatingSystem
 */
public String getOperatingSystem() {
	return operatingSystem;
}
/**
 * @param operatingSystem the operatingSystem to set
 */
public void setOperatingSystem(String operatingSystem) {
	this.operatingSystem = operatingSystem;
}
/**
 * @return the lastBackUpStatus
 */
public String getLastBackUpStatus() {
	return lastBackUpStatus;
}
/**
 * @param lastBackUpStatus the lastBackUpStatus to set
 */
public void setLastBackUpStatus(String lastBackUpStatus) {
	this.lastBackUpStatus = lastBackUpStatus;
}
/**
 * @return the nextBackupTime
 */
public Date getNextBackupTime() {
	return nextBackupTime;
}
/**
 * @param nextBackupTime the nextBackupTime to set
 */
public void setNextBackupTime(Date nextBackupTime) {
	this.nextBackupTime = nextBackupTime;
}
 
/**
 * @return the ramSize
 */
public Long getRamSize() {
	return ramSize;
}
/**
 * @param ramSize the ramSize to set
 */
public void setRamSize(Long ramSize) {
	this.ramSize = ramSize;
}
/**
 * @return the diskSpaceAvaliabe
 */
public long getDiskSpaceAvaliabe() {
	return diskSpaceAvaliabe;
}
/**
 * @param diskSpaceAvaliabe the diskSpaceAvaliabe to set
 */
public void setDiskSpaceAvaliabe(long diskSpaceAvaliabe) {
	this.diskSpaceAvaliabe = diskSpaceAvaliabe;
}
/**
 * @return the totaldiskSpace
 */
public long getTotaldiskSpace() {
	return totaldiskSpace;
}
/**
 * @param totaldiskSpace the totaldiskSpace to set
 */
public void setTotaldiskSpace(long totaldiskSpace) {
	this.totaldiskSpace = totaldiskSpace;
}
/**
 * @return the diskSpaceAvaliabeStr
 */
public String getDiskSpaceAvaliabeStr() {
	return diskSpaceAvaliabeStr;
}
/**
 * @param diskSpaceAvaliabeStr the diskSpaceAvaliabeStr to set
 */
public void setDiskSpaceAvaliabeStr(String diskSpaceAvaliabeStr) {
	this.diskSpaceAvaliabeStr = diskSpaceAvaliabeStr;
}
/**
 * @return the totalDiskSpaceStr
 */
public String getTotalDiskSpaceStr() {
	return totalDiskSpaceStr;
}
/**
 * @param totalDiskSpaceStr the totalDiskSpaceStr to set
 */
public void setTotalDiskSpaceStr(String totalDiskSpaceStr) {
	this.totalDiskSpaceStr = totalDiskSpaceStr;
}
/**
 * @return the usedDiskSpaceStr
 */
public String getUsedDiskSpaceStr() {
	return usedDiskSpaceStr;
}
/**
 * @param usedDiskSpaceStr the usedDiskSpaceStr to set
 */
public void setUsedDiskSpaceStr(String usedDiskSpaceStr) {
	this.usedDiskSpaceStr = usedDiskSpaceStr;
}
/**
 * @return the appVersion
 */
public String getAppVersion() {
	return appVersion;
}
/**
 * @param appVersion the appVersion to set
 */
public void setAppVersion(String appVersion) {
	this.appVersion = appVersion;
}
/**
 * @return the releaseDate
 */
public String getReleaseDate() {
	return releaseDate;
}
/**
 * @param releaseDate the releaseDate to set
 */
public void setReleaseDate(String releaseDate) {
	this.releaseDate = releaseDate;
}
/**
 * @return the cpuUsage
 */
public double getCpuUsage() {
	return cpuUsage;
}
/**
 * @param cpuUsage the cpuUsage to set
 */
public void setCpuUsage(double cpuUsage) {
	this.cpuUsage = cpuUsage;
}
 
 
 

}
