package com.cavium;

import java.util.Properties;

import javax.servlet.MultipartConfigElement;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.app.VelocityEngine;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.boot.web.servlet.MultipartConfigFactory;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.Scope;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.client.RestTemplate;

import com.cavium.pojo.ApplianceInfo;
import com.cavium.pojo.DashboardDetails;
import com.cavium.pojo.HSMInfo;
import com.cavium.pojo.PartitionsDetails;
import com.cavium.pojo.hostadminvm.AdminSNMPConfig;
import com.cavium.pojo.hostadminvm.AdminVMConfig;
import com.cavium.pojo.hostadminvm.HostStats;
import com.cavium.pojo.hostadminvm.HostSystemInfo;
import com.cavium.utill.CaviumResponseModel;


/*MK00497144
 * This class is used to configure the spring boot framework
 * */
@SpringBootApplication
@PropertySource({"classpath:log4j.properties","classpath:applicationMessages.properties","classpath:mail.properties","classpath:operations.properties","classpath:CaviumErrorMessages.properties"})
@EnableTransactionManagement
public class Application extends SpringBootServletInitializer {
	private Logger logger = LogManager.getLogger(this.getClass());

	@Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		logger.info("Welcome to the Spring Boot Project");
        return application.sources(Application.class);
        
    }
	
  /*  public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }*/
    
	/*
	 * This method is used to encrypt the password
	 * */
	
    @Bean
	public BCryptPasswordEncoder passwordEncoder() {
	    return new BCryptPasswordEncoder();
	}
   

    @Bean
    public VelocityEngine getVelocityEngine() throws  Exception {
        Properties properties = new Properties();
        properties.setProperty("input.encoding", "UTF-8");
        properties.setProperty("output.encoding", "UTF-8");
        properties.setProperty("resource.loader", "class");
        properties.setProperty("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
        VelocityEngine velocityEngine = new VelocityEngine(properties);
        return velocityEngine;
    } 
    
    @Bean
	public RestTemplate getRestTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}
    
    @Bean
    public ResourceBundleMessageSource messageSource() {
        ResourceBundleMessageSource source = new ResourceBundleMessageSource();
        source.setBasename("applicationMessages");
        source.setUseCodeAsDefaultMessage(true);
        return source;
    }
    
  
    
    @Bean
    @Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
    public CaviumResponseModel caviumResponseModel() {
        return new CaviumResponseModel();
    }
    
    @Bean
    @Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
    public PartitionsDetails partitionsDetails() {
        return new PartitionsDetails();
    }
    
    
    @Bean
    @Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
    public ApplianceInfo applianceInfo() {
        return new ApplianceInfo();
    }
    @Bean
    @Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
    public HostSystemInfo hostSystemInfo() {
        return new HostSystemInfo();
    }
    @Bean
    @Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
    public HSMInfo HSMInfo() {
        return new HSMInfo();
    }
    @Bean
    @Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
    public HostStats hostStats() {
        return new HostStats();
    }
    @Bean
    @Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
    public AdminVMConfig adminVMConfig() {
        return new AdminVMConfig();
    }
     
    @Bean
    @Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
    public AdminSNMPConfig adminSNMPConfig() {
        return new AdminSNMPConfig();
    }
    
    @Bean
    @Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
    public DashboardDetails dashboardDetails() {
        return new DashboardDetails();
    }
    
    @Bean
    MultipartConfigElement multipartConfigElement() {
        MultipartConfigFactory factory = new MultipartConfigFactory();
        factory.setMaxFileSize("2000MB");
        factory.setMaxRequestSize("2000MB");
        return factory.createMultipartConfig();
    }
 }
 

