package com.cavium.model.hostadminvm.monitorstats;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="monitor_stats_info_details")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Info
{
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "info_id", nullable = false)
	private Long infoId;
	@Column(name = "thread")
    private int nThread;
	@Column(name = "name")
    private String name;
	@Column(name = "cpu_percent")
    private String cpuPercent;
	@Column(name = "cpu")
    private int cpu;
    
	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name = "pcpu_id", nullable = false)
	@JsonBackReference
	private Pcpu pcpu;

	/**
	 * @return the infoId
	 */
	public Long getInfoId() {
		return infoId;
	}

	/**
	 * @param infoId the infoId to set
	 */
	public void setInfoId(Long infoId) {
		this.infoId = infoId;
	}

	/**
	 * @return the nThread
	 */
	public int getnThread() {
		return nThread;
	}

	/**
	 * @param nThread the nThread to set
	 */
	public void setnThread(int nThread) {
		this.nThread = nThread;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the cpuPercent
	 */
	public String getCpuPercent() {
		return cpuPercent;
	}

	/**
	 * @param cpuPercent the cpuPercent to set
	 */
	public void setCpuPercent(String cpuPercent) {
		this.cpuPercent = cpuPercent;
	}

	/**
	 * @return the cpu
	 */
	public int getCpu() {
		return cpu;
	}

	/**
	 * @param cpu the cpu to set
	 */
	public void setCpu(int cpu) {
		this.cpu = cpu;
	}

	/**
	 * @return the pcpu
	 */
	public Pcpu getPcpu() {
		return pcpu;
	}

	/**
	 * @param pcpu the pcpu to set
	 */
	public void setPcpu(Pcpu pcpu) {
		this.pcpu = pcpu;
	}
    
 
}

