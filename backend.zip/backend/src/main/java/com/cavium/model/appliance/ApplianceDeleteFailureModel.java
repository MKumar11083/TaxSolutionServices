package com.cavium.model.appliance;

import java.util.List;

public class ApplianceDeleteFailureModel {
	
	private List<ApplianceDetailModel> dueToCluster;
	private List<ApplianceDetailModel> fipsStateNonZeroize;
	private List<ApplianceDetailModel> successList;
	public List<ApplianceDetailModel> getDueToCluster() {
		return dueToCluster;
	}
	public void setDueToCluster(List<ApplianceDetailModel> dueToCluster) {
		this.dueToCluster = dueToCluster;
	}
	public List<ApplianceDetailModel> getFipsStateNonZeroize() {
		return fipsStateNonZeroize;
	}
	public void setFipsStateNonZeroize(List<ApplianceDetailModel> fipsStateNonZeroize) {
		this.fipsStateNonZeroize = fipsStateNonZeroize;
	}
	public List<ApplianceDetailModel> getSuccessList() {
		return successList;
	}
	public void setSuccessList(List<ApplianceDetailModel> successList) {
		this.successList = successList;
	}
}
