package com.cavium.model.partition;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Table(name = "partition_interface_advance_dns_servers")
public class PartitionAdvanceDNSServers implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1030951658800120360L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	private Long Id;
	@Column(name="dns_address")
	private String dnsAddress;
	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name = "partition_id", nullable = false)
	@JsonBackReference
	private PartitionDetailModel partitionDetailModel;
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	public String getDnsAddress() {
		return dnsAddress;
	}
	public void setDnsAddress(String dnsAddress) {
		this.dnsAddress = dnsAddress;
	}
	public PartitionDetailModel getPartitionDetailModel() {
		return partitionDetailModel;
	}
	public void setPartitionDetailModel(PartitionDetailModel partitionDetailModel) {
		this.partitionDetailModel = partitionDetailModel;
	}
	
	
}
