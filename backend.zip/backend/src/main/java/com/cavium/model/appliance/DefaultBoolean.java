package com.cavium.model.appliance;
public enum DefaultBoolean
{
  Y("Y"),  N("N");
  
   String value;
  
  private DefaultBoolean(String value)
  {
    this.value = value;
  }
}