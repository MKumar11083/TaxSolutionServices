package com.cavium.model.recentactivity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "inprogress_activity")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class InProgressActivity implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1901330837349823900L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	@Column(name="job_id")
	private Integer jobId;
	@Column(name="operation_name")
	private String operationName;
	@Column(name="ip_address")
	private String ipAddress;
	@Column(name="createdby")
	private String createdBy;
	@Column(name="status")
	private String status;
	@Column(name="partition_id")
	private Long partitionId;
	@Column(name="appliance_iD")
	private Long applianceID;
	@Column(name="module_name")
	private String moduleName;
	@Column(name="cluster_id")
	private Long clusterId;
	@Column(name = "partition_deleted")
	private boolean partitionDeleted;
	@Column(name="appliance_name")
	private String applianceName;
	@Column(name="partition_name")
	private String partitionName;
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Integer getJobId() {
		return jobId;
	}
	public void setJobId(Integer jobId) {
		this.jobId = jobId;
	}
	public String getOperationName() {
		return operationName;
	}
	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}
	public String getIpAddress() {
		return ipAddress;
	}
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Long getPartitionId() {
		return partitionId;
	}
	public void setPartitionId(Long partitionId) {
		this.partitionId = partitionId;
	}
	public Long getApplianceID() {
		return applianceID;
	}
	public void setApplianceID(Long applianceID) {
		this.applianceID = applianceID;
	}
	/**
	 * @return the moduleName
	 */
	public String getModuleName() {
		return moduleName;
	}
	/**
	 * @param moduleName the moduleName to set
	 */
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	/**
	 * @return the clusterId
	 */
	public Long getClusterId() {
		return clusterId;
	}
	/**
	 * @param clusterId the clusterId to set
	 */
	public void setClusterId(Long clusterId) {
		this.clusterId = clusterId;
	}
	/**
	 * @return the partitionDeleted
	 */
	public boolean isPartitionDeleted() {
		return partitionDeleted;
	}
	/**
	 * @param partitionDeleted the partitionDeleted to set
	 */
	public void setPartitionDeleted(boolean partitionDeleted) {
		this.partitionDeleted = partitionDeleted;
	}
	public String getApplianceName() {
		return applianceName;
	}
	public void setApplianceName(String applianceName) {
		this.applianceName = applianceName;
	}
	public String getPartitionName() {
		return partitionName;
	}
	public void setPartitionName(String partitionName) {
		this.partitionName = partitionName;
	}
	
	public String toString() {
	    return " PartitionName: '" + this.partitionName + "', applianceName: '" + this.applianceName + "', clusterId: '" + this.clusterId + ","
	    + "applianceID: '" + this.applianceID + "', partitionId: '" + this.partitionId + "', jobId: '" + this.jobId;
	   
	}
}
