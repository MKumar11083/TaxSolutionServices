package com.cavium.model.appliance;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.cavium.model.partition.PartitionDetailModel;
import com.cavium.model.partition.monitor.MonitorData;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
/**
 *  * @author MK00497144
 *  Class is used as a bean entity for Appliance and Partition associations 
 */
 
@Entity
@Table(name = "appliance_details")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class ApplianceDetailModel implements Serializable {

	private static final long serialVersionUID = -3840562434180092945L;

	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "appliance_id", nullable = false)
	private Long applianceId;
	@Column(name = "appliance_name")
	private String applianceName;
	@Column(name = "appliance_status")
	private String applianceStatus;
	@Column(name = "serial_number")
	private String serialNumber;
	@Column(name = "network_timezone")
	private String networkTimezone;
	@Column(name = "gateway_ip")
	private String gatewayIp;
	@Column(name = "ip_address")
	private String ipAddress;
	@Column(name = "subnet_mask")
	private String subnetMask;
	@Column(name = "network_mode")
	private String networkMode;
	@Column(name = "network_id")
	private String networkId;
	@Column(name = "hostname")
	private String hostName;
	@Column(name = "device_added_by_user")
	private String deviceAddedByUser;
	@Column(name = "last_operation_performed")
	private String lastOperationPerformed;
	@Column(name = "last_operation_status")
	private String lastOperationStatus;
	@Column(name = "error_message")
	private String errorMessage;
	@Column(name = "ipmi_ip")
	private String ipmiIp;
	@Column(name = "total_acclr_device")
	private Integer totalAcclrDevice;
	@Column(name = "occupied_acclr_dev")
	private Integer occupiedAcclrDev;
	@Column(name = "total_keys")
	private Integer totalKeys;
	@Column(name = "occupied_keys")
	private Integer occupiedKeys; 
	@Column(name = "total_contexts")
	private Integer totalContexts; 
	@Column(name = "occupied_partitions")
	private Integer occupiedPartitions; 
	@Column(name = "total_partitions")
	private Integer totalPartitions; 
	@Column(name = "occupied_contexts")
	private Integer occupiedContexts; 
	@JsonProperty(access = Access.WRITE_ONLY)
	@Column(name = "user_name")
	private String userName;
	@Column(name = "user_password")
	private String userPassword;
	@Column(name = "zone_id")
	private String zoneId;
	
	/*@JsonManagedReference
	@OneToMany(fetch = FetchType.LAZY,mappedBy="applianceDetailModel",cascade = CascadeType.ALL)
	private List<PartitionDetailModel> partitionDetailModels;*/
	@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY

	)
	@JoinColumn(name = "appliance_id")
	private List<PartitionDetailModel> partitionDetailModels;
	
	
	@Transient
	private String code;
	@Transient
	private String message;
	@Column(name = "min_pasword_length")
	private Integer minPwdLen = 0;
	@Column(name = "max_pasword_length")
	private Integer maxPwdLen = 0;
	@Column(name = "co_login_failure_count")
	private Integer coLoginFailureCount = 0;
	
	@Column(name = "created_date", columnDefinition = "DATETIME")
	private Date createdDate;
	@Column(name = "modified_date", columnDefinition = "DATETIME")
	private Date modifiedDate;
	@Column(name = "created_by")
	private String createdBy;
	@Column(name = "modified_by")
	private String modifiedBy;
	@Column(name = "authid")
	private String authId;
	
	@Column(name = "city_name")
	private String cityName;
	
	@Transient
	private String operationUsername;
	@Transient
	private String operationPassword;
	@Transient
	private String newPassword;
	
	@Enumerated(EnumType.STRING)
	@Column(name="appliance_store_type")
	private StoreType storeType;	 
		 
	@Column(name = "credential_saved")
	private boolean credentialSaved;
	
	
	@Column(name = "appliance_initialized")
	private boolean applianceinitialized;
	
	@Transient
	private FirmwareUpgradeDetailModel firmwareUpgradeDetailModel;
	
	@Column(name = "initialized__through_cavium")
	private boolean initializedthroughCavium;
	
	@Transient
	private Boolean forceZeroize;
	
	@Transient
	private String type;
	
	@Transient
	private String monitorType;
	
	@Transient
	private MonitorData monitorData;
	
	@Transient
	private String selfReportType;
	
	
	
	 
	/**
	 * @return the cityName
	 */
	public String getCityName() {
		return cityName;
	}

	/**
	 * @param cityName the cityName to set
	 */
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public Long getApplianceId() {
		return applianceId;
	}

	public void setApplianceId(Long applianceId) {
		this.applianceId = applianceId;
	}

	public String getApplianceName() {
		return applianceName;
	}

	public void setApplianceName(String applianceName) {
		this.applianceName = applianceName;
	}

	public String getApplianceStatus() {
		return applianceStatus;
	}

	public void setApplianceStatus(String applianceStatus) {
		this.applianceStatus = applianceStatus;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getNetworkTimezone() {
		return networkTimezone;
	}

	public void setNetworkTimezone(String networkTimezone) {
		this.networkTimezone = networkTimezone;
	}

	public String getGatewayIp() {
		return gatewayIp;
	}

	public void setGatewayIp(String gatewayIp) {
		this.gatewayIp = gatewayIp;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public String getSubnetMask() {
		return subnetMask;
	}

	public void setSubnetMask(String subnetMask) {
		this.subnetMask = subnetMask;
	}

	public String getNetworkMode() {
		return networkMode;
	}

	public void setNetworkMode(String networkMode) {
		this.networkMode = networkMode;
	}

	public String getHostName() {
		return hostName;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	public String getDeviceAddedByUser() {
		return deviceAddedByUser;
	}

	public void setDeviceAddedByUser(String deviceAddedByUser) {
		this.deviceAddedByUser = deviceAddedByUser;
	}
	
	public String getLastOperationPerformed() {
		return lastOperationPerformed;
	}

	public void setLastOperationPerformed(String lastOperationPerformed) {
		this.lastOperationPerformed = lastOperationPerformed;
	}

	public String getLastOperationStatus() {
		return lastOperationStatus;
	}

	public void setLastOperationStatus(String lastOperationStatus) {
		this.lastOperationStatus = lastOperationStatus;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getIpmiIp() {
		return ipmiIp;
	}

	public void setIpmiIp(String ipmiIp) {
		this.ipmiIp = ipmiIp;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

/*	public List<PartitionDetailModel> getPartitionDetailModels() {
		return partitionDetailModels;
	}

	public void setPartitionDetailModels(List<PartitionDetailModel> partitionDetailModels) {
		this.partitionDetailModels = partitionDetailModels;
	}*/

	public String getNetworkId() {
		return networkId;
	}

	public void setNetworkId(String networkId) {
		this.networkId = networkId;
	}
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	
	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getAuthId() {
		return authId;
	}

	public void setAuthId(String authId) {
		this.authId = authId;
	}

	public String getOperationUsername() {
		return operationUsername;
	}

	public void setOperationUsername(String operationUsername) {
		this.operationUsername = operationUsername;
	}

	public String getOperationPassword() {
		return operationPassword;
	}

	public void setOperationPassword(String operationPassword) {
		this.operationPassword = operationPassword;
	}

	public StoreType getStoreType() {
		return storeType;
	}

	public void setStoreType(StoreType storeType) {
		this.storeType = storeType;
	}
	
	/**
	 * @return the credentialSaved
	 */
	public boolean isCredentialSaved() {
		return credentialSaved;
	}

	/**
	 * @param credentialSaved the credentialSaved to set
	 */
	public void setCredentialSaved(boolean credentialSaved) {
		this.credentialSaved = credentialSaved;
	}

	public Integer getMinPwdLen() {
		return minPwdLen;
	}

	public void setMinPwdLen(Integer minPwdLen) {
		this.minPwdLen = minPwdLen;
	}

	public Integer getMaxPwdLen() {
		return maxPwdLen;
	}

	public void setMaxPwdLen(Integer maxPwdLen) {
		this.maxPwdLen = maxPwdLen;
	}

	public Integer getCoLoginFailureCount() {
		return coLoginFailureCount;
	}

	public void setCoLoginFailureCount(Integer coLoginFailureCount) {
		this.coLoginFailureCount = coLoginFailureCount;
	}

	/**
	 * @return the applianceinitialized
	 */
	public boolean isApplianceinitialized() {
		return applianceinitialized;
	}

	/**
	 * @param applianceinitialized the applianceinitialized to set
	 */
	public void setApplianceinitialized(boolean applianceinitialized) {
		this.applianceinitialized = applianceinitialized;
	}

	public FirmwareUpgradeDetailModel getFirmwareUpgradeDetailModel() {
		return firmwareUpgradeDetailModel;
	}

	public void setFirmwareUpgradeDetailModel(FirmwareUpgradeDetailModel firmwareUpgradeDetailModel) {
		this.firmwareUpgradeDetailModel = firmwareUpgradeDetailModel;
	}

	public List<PartitionDetailModel> getPartitionDetailModels() {
		return partitionDetailModels;
	}

	public void setPartitionDetailModels(List<PartitionDetailModel> partitionDetailModels) {
		this.partitionDetailModels = partitionDetailModels;
	}

	/**
	 * @return the initializedthroughCavium
	 */
	public boolean isInitializedthroughCavium() {
		return initializedthroughCavium;
	}

	/**
	 * @param initializedthroughCavium the initializedthroughCavium to set
	 */
	public void setInitializedthroughCavium(boolean initializedthroughCavium) {
		this.initializedthroughCavium = initializedthroughCavium;
	}

	/**
	 * @return the forceZeroize
	 */
	public Boolean getForceZeroize() {
		return forceZeroize;
	}

	/**
	 * @param forceZeroize the forceZeroize to set
	 */
	public void setForceZeroize(Boolean forceZeroize) {
		this.forceZeroize = forceZeroize;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the totalAcclrDevice
	 */
	public Integer getTotalAcclrDevice() {
		return totalAcclrDevice;
	}

	/**
	 * @param totalAcclrDevice the totalAcclrDevice to set
	 */
	public void setTotalAcclrDevice(Integer totalAcclrDevice) {
		this.totalAcclrDevice = totalAcclrDevice;
	}

	/**
	 * @return the occupiedAcclrDev
	 */
	public Integer getOccupiedAcclrDev() {
		return occupiedAcclrDev;
	}

	/**
	 * @param occupiedAcclrDev the occupiedAcclrDev to set
	 */
	public void setOccupiedAcclrDev(Integer occupiedAcclrDev) {
		this.occupiedAcclrDev = occupiedAcclrDev;
	}

	/**
	 * @return the totalKeys
	 */
	public Integer getTotalKeys() {
		return totalKeys;
	}

	/**
	 * @param totalKeys the totalKeys to set
	 */
	public void setTotalKeys(Integer totalKeys) {
		this.totalKeys = totalKeys;
	}

	/**
	 * @return the occupiedKeys
	 */
	public Integer getOccupiedKeys() {
		return occupiedKeys;
	}

	/**
	 * @param occupiedKeys the occupiedKeys to set
	 */
	public void setOccupiedKeys(Integer occupiedKeys) {
		this.occupiedKeys = occupiedKeys;
	}

	/**
	 * @return the totalContexts
	 */
	public Integer getTotalContexts() {
		return totalContexts;
	}

	/**
	 * @param totalContexts the totalContexts to set
	 */
	public void setTotalContexts(Integer totalContexts) {
		this.totalContexts = totalContexts;
	}

	/**
	 * @return the occupiedContexts
	 */
	public Integer getOccupiedContexts() {
		return occupiedContexts;
	}

	/**
	 * @param occupiedContexts the occupiedContexts to set
	 */
	public void setOccupiedContexts(Integer occupiedContexts) {
		this.occupiedContexts = occupiedContexts;
	}

	public String getMonitorType() {
		return monitorType;
	}

	public void setMonitorType(String monitorType) {
		this.monitorType = monitorType;
	}

	public MonitorData getMonitorData() {
		return monitorData;
	}

	public void setMonitorData(MonitorData monitorData) {
		this.monitorData = monitorData;
	}

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	public String getSelfReportType() {
		return selfReportType;
	}

	public void setSelfReportType(String selfReportType) {
		this.selfReportType = selfReportType;
	}

	/**
	 * @return the zoneId
	 */
	public String getZoneId() {
		return zoneId;
	}

	/**
	 * @param zoneId the zoneId to set
	 */
	public void setZoneId(String zoneId) {
		this.zoneId = zoneId;
	}

	/**
	 * @return the occupiedPartitions
	 */
	public Integer getOccupiedPartitions() {
		return occupiedPartitions;
	}

	/**
	 * @param occupiedPartitions the occupiedPartitions to set
	 */
	public void setOccupiedPartitions(Integer occupiedPartitions) {
		this.occupiedPartitions = occupiedPartitions;
	}

	/**
	 * @return the totalPartitions
	 */
	public Integer getTotalPartitions() {
		return totalPartitions;
	}

	/**
	 * @param totalPartitions the totalPartitions to set
	 */
	public void setTotalPartitions(Integer totalPartitions) {
		this.totalPartitions = totalPartitions;
	}
}
