package com.cavium.model.cluster;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.cavium.model.partition.PartitionData;
import com.cavium.model.partition.PartitionDetailModel;
import com.cavium.pojo.ConnectedPartitions;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/*
 * cluster_partitions_relationship Model class hold the relationship between cluster and partitions
 * author : RK00490847
 */
@Entity
@Table(name="cluster_partitions_relationship")
public class ClusterPartitionsRelationship
  implements Serializable
{
  private static final long serialVersionUID = 4692301322760007284L;
  @Id
  @GeneratedValue(strategy=GenerationType.IDENTITY)
  private Long id;
  @Column(name="cluster_id")
  private Long clusterId;
  @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
  @OneToOne(fetch=FetchType.EAGER)
  @JoinColumn(name = "partition_id",nullable = true)
	private PartitionDetailModel partitionDetailModel;
  
  @Column(name = "node_id")
  private Integer nodeId;
  @Column(name = "zone_id")
	private Integer zoneId;
	 @Column(name = "main_Channel_port")
  	private Integer mainChannelPort;
	 @Column(name = "back_channel_port")
	 private Integer backChannelPort;
	 @Column(name = "remote_eth0_addr")
	 private String remoteEth0Addr;
	 @Column(name = "remote_eth1_addr")
	 private String remoteEth1Addr;
	 @Transient
	 private Long deletedPartitionId;
	 
	 @Transient
	 private int tombstoneKeys;
	 
	 @Transient
	 private List<ConnectedPartitions> connectedPartitions = new ArrayList<ConnectedPartitions>();
	 @Transient
	 private Long applianceId;
	 @Transient
	 private String operationPerformedUserName;
	 @Transient
	 private String operationPerformedPassword;	  
	 @Column(name = "ip_address")
	 private String ipAddress;
	 @Column(name = "appliance_name")
	 private String applianceName;
	 @Column(name = "partition_name")
	 private String partitionName;
	 @Transient
	 private Long partitionId;
	 @Transient
	 private PartitionData partitionData;
	 
	 
/**
 * @return the id
 */
public Long getId() {
	return id;
}
/**
 * @param id the id to set
 */
public void setId(Long id) {
	this.id = id;
}
/**
 * @return the clusterId
 */
public Long getClusterId() {
	return clusterId;
}
/**
 * @param clusterId the clusterId to set
 */
public void setClusterId(Long clusterId) {
	this.clusterId = clusterId;
}
/**
 * @return the partitionDetailModel
 */
public PartitionDetailModel getPartitionDetailModel() {
	return partitionDetailModel;
}
/**
 * @param partitionDetailModel the partitionDetailModel to set
 */
public void setPartitionDetailModel(PartitionDetailModel partitionDetailModel) {
	this.partitionDetailModel = partitionDetailModel;
}
/**
 * @return the applianceId
 */
public Long getApplianceId() {
	return applianceId;
}
/**
 * @param applianceId the applianceId to set
 */
public void setApplianceId(Long applianceId) {
	this.applianceId = applianceId;
}
/**
 * @return the ipAddress
 */
public String getIpAddress() {
	return ipAddress;
}
/**
 * @param ipAddress the ipAddress to set
 */
public void setIpAddress(String ipAddress) {
	this.ipAddress = ipAddress;
}
/**
 * @return the applianceName
 */
public String getApplianceName() {
	return applianceName;
}
/**
 * @param applianceName the applianceName to set
 */
public void setApplianceName(String applianceName) {
	this.applianceName = applianceName;
}
/**
 * @return the partitionName
 */
public String getPartitionName() {
	return partitionName;
}
/**
 * @param partitionName the partitionName to set
 */
public void setPartitionName(String partitionName) {
	this.partitionName = partitionName;
}
 
/**
 * @return the partitionData
 */
public PartitionData getPartitionData() {
	return partitionData;
}
/**
 * @param partitionData the partitionData to set
 */
public void setPartitionData(PartitionData partitionData) {
	this.partitionData = partitionData;
}
/**
 * @return the nodeId
 */
public Integer getNodeId() {
	return nodeId;
}
/**
 * @param nodeId the nodeId to set
 */
public void setNodeId(Integer nodeId) {
	this.nodeId = nodeId;
}
/**
 * @return the zoneId
 */
public Integer getZoneId() {
	return zoneId;
}
/**
 * @param zoneId the zoneId to set
 */
public void setZoneId(Integer zoneId) {
	this.zoneId = zoneId;
}
/**
 * @return the mainChannelPort
 */
public Integer getMainChannelPort() {
	return mainChannelPort;
}
/**
 * @param mainChannelPort the mainChannelPort to set
 */
public void setMainChannelPort(Integer mainChannelPort) {
	this.mainChannelPort = mainChannelPort;
}
/**
 * @return the backChannelPort
 */
public Integer getBackChannelPort() {
	return backChannelPort;
}
/**
 * @param backChannelPort the backChannelPort to set
 */
public void setBackChannelPort(Integer backChannelPort) {
	this.backChannelPort = backChannelPort;
}
 
 
/**
 * @return the partitionId
 */
public Long getPartitionId() {
	return partitionId;
}
/**
 * @param partitionId the partitionId to set
 */
public void setPartitionId(Long partitionId) {
	this.partitionId = partitionId;
}
/**
 * @return the remoteEth0Addr
 */
public String getRemoteEth0Addr() {
	return remoteEth0Addr;
}
/**
 * @param remoteEth0Addr the remoteEth0Addr to set
 */
public void setRemoteEth0Addr(String remoteEth0Addr) {
	this.remoteEth0Addr = remoteEth0Addr;
}
/**
 * @return the remoteEth1Addr
 */
public String getRemoteEth1Addr() {
	return remoteEth1Addr;
}
/**
 * @param remoteEth1Addr the remoteEth1Addr to set
 */
public void setRemoteEth1Addr(String remoteEth1Addr) {
	this.remoteEth1Addr = remoteEth1Addr;
}
 
/**
 * @return the operationPerformedUserName
 */
public String getOperationPerformedUserName() {
	return operationPerformedUserName;
}
/**
 * @param operationPerformedUserName the operationPerformedUserName to set
 */
public void setOperationPerformedUserName(String operationPerformedUserName) {
	this.operationPerformedUserName = operationPerformedUserName;
}
/**
 * @return the operationPerformedPassword
 */
public String getOperationPerformedPassword() {
	return operationPerformedPassword;
}
/**
 * @param operationPerformedPassword the operationPerformedPassword to set
 */
public void setOperationPerformedPassword(String operationPerformedPassword) {
	this.operationPerformedPassword = operationPerformedPassword;
}

/**
 * @return the tombstoneKeys
 */
public int getTombstoneKeys() {
	return tombstoneKeys;
}
/**
 * @param tombstoneKeys the tombstoneKeys to set
 */
public void setTombstoneKeys(int tombstoneKeys) {
	this.tombstoneKeys = tombstoneKeys;
}
/**
 * @return the connectedPartitions
 */
public List<ConnectedPartitions> getConnectedPartitions() {
	return connectedPartitions;
}
/**
 * @param connectedPartitions the connectedPartitions to set
 */
public void setConnectedPartitions(List<ConnectedPartitions> connectedPartitions) {
	this.connectedPartitions = connectedPartitions;
}
/**
 * @return the deletedPartitionId
 */
public Long getDeletedPartitionId() {
	return deletedPartitionId;
}
/**
 * @param deletedPartitionId the deletedPartitionId to set
 */
public void setDeletedPartitionId(Long deletedPartitionId) {
	this.deletedPartitionId = deletedPartitionId;
}
 

}
