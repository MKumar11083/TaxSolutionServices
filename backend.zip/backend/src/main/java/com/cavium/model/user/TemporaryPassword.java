package com.cavium.model.user;

/*
 * TemporaryPassword Model class for User Temporary Password
 * author : RK00490847
 */
public enum TemporaryPassword
{
  Y("Y"),  N("N");
  
   String value;
  
  private TemporaryPassword(String value)
  {
    this.value = value;
  }
}
