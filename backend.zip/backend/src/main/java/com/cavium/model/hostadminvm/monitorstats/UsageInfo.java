package com.cavium.model.hostadminvm.monitorstats;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="monitor_stats_usage_info_details")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class UsageInfo
{ 
	@Id 
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "usageinfo_id", nullable = false)
	private Long usageInfoId;
	@Column(name = "command")
    private String command;
	@Column(name = "usage_detail")
    private String usage;
	@Column(name = "pid")
    private String pid;
	@Column(name = "mem_usage_detail")
    private String memUsage;
	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name = "cpu_id", nullable = false)
	@JsonBackReference
	private Cpu cpu;
	/**
	 * @return the usageInfoId
	 */
	public Long getUsageInfoId() {
		return usageInfoId;
	}
	/**
	 * @param usageInfoId the usageInfoId to set
	 */
	public void setUsageInfoId(Long usageInfoId) {
		this.usageInfoId = usageInfoId;
	}
	/**
	 * @return the command
	 */
	public String getCommand() {
		return command;
	}
	/**
	 * @param command the command to set
	 */
	public void setCommand(String command) {
		this.command = command;
	}
	/**
	 * @return the usage
	 */
	public String getUsage() {
		return usage;
	}
	/**
	 * @param usage the usage to set
	 */
	public void setUsage(String usage) {
		this.usage = usage;
	}
	/**
	 * @return the pid
	 */
	public String getPid() {
		return pid;
	}
	/**
	 * @param pid the pid to set
	 */
	public void setPid(String pid) {
		this.pid = pid;
	}
	/**
	 * @return the memUsage
	 */
	public String getMemUsage() {
		return memUsage;
	}
	/**
	 * @param memUsage the memUsage to set
	 */
	public void setMemUsage(String memUsage) {
		this.memUsage = memUsage;
	}
	/**
	 * @return the cpu
	 */
	public Cpu getCpu() {
		return cpu;
	}
	/**
	 * @param cpu the cpu to set
	 */
	public void setCpu(Cpu cpu) {
		this.cpu = cpu;
	}
    
}
