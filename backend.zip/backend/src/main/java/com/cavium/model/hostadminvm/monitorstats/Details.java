package com.cavium.model.hostadminvm.monitorstats;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="monitor_stats_command_details")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Details
{
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "details_id", nullable = false)
	private Long detailsId;
	
	@Column(name = "cpu")
    private String cpu;
	
	@Column(name = "command")
    private String command;
	
	@Column(name = "mem")
    private String mem;
	
	@Column(name = "pid")
    private String pid;
	
	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name = "memory_id", nullable = false)
	@JsonBackReference
	private Memory memory;

	/**
	 * @return the detailsId
	 */
	public Long getDetailsId() {
		return detailsId;
	}

	/**
	 * @param detailsId the detailsId to set
	 */
	public void setDetailsId(Long detailsId) {
		this.detailsId = detailsId;
	}

	/**
	 * @return the cpu
	 */
	public String getCpu() {
		return cpu;
	}

	/**
	 * @param cpu the cpu to set
	 */
	public void setCpu(String cpu) {
		this.cpu = cpu;
	}

	/**
	 * @return the command
	 */
	public String getCommand() {
		return command;
	}

	/**
	 * @param command the command to set
	 */
	public void setCommand(String command) {
		this.command = command;
	}

	/**
	 * @return the mem
	 */
	public String getMem() {
		return mem;
	}

	/**
	 * @param mem the mem to set
	 */
	public void setMem(String mem) {
		this.mem = mem;
	}

	/**
	 * @return the pid
	 */
	public String getPid() {
		return pid;
	}

	/**
	 * @param pid the pid to set
	 */
	public void setPid(String pid) {
		this.pid = pid;
	}

	/**
	 * @return the memory
	 */
	public Memory getMemory() {
		return memory;
	}

	/**
	 * @param memory the memory to set
	 */
	public void setMemory(Memory memory) {
		this.memory = memory;
	}
    
   
}
