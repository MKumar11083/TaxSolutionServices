package com.cavium.model.user;

import java.util.ArrayList;
import java.util.List;

/*
 * UserManagementDashboardModel class holds the data of Users Details, Groups Details and ACLs Details.
 * author : RK00490847
 */
public class UserManagementDashboardModel {
	
private List<UserGroupModel> listUserGroupModel= new ArrayList<UserGroupModel>();
	
private List<UserACLDetailsModel>  listUserACLDetailsModel= new ArrayList<UserACLDetailsModel>();

private List<UserDetailModel> listUserDetailModel= new ArrayList<UserDetailModel>();

/**
 * @return the listUserGroupModel
 */
public List<UserGroupModel> getListUserGroupModel() {
	return listUserGroupModel;
}

/**
 * @param listUserGroupModel the listUserGroupModel to set
 */
public void setListUserGroupModel(List<UserGroupModel> listUserGroupModel) {
	this.listUserGroupModel = listUserGroupModel;
}

/**
 * @return the listUserACLDetailsModel
 */
public List<UserACLDetailsModel> getListUserACLDetailsModel() {
	return listUserACLDetailsModel;
}

/**
 * @param listUserACLDetailsModel the listUserACLDetailsModel to set
 */
public void setListUserACLDetailsModel(List<UserACLDetailsModel> listUserACLDetailsModel) {
	this.listUserACLDetailsModel = listUserACLDetailsModel;
}

/**
 * @return the listUserDetailModel
 */
public List<UserDetailModel> getListUserDetailModel() {
	return listUserDetailModel;
}

/**
 * @param listUserDetailModel the listUserDetailModel to set
 */
public void setListUserDetailModel(List<UserDetailModel> listUserDetailModel) {
	this.listUserDetailModel = listUserDetailModel;
}
}
