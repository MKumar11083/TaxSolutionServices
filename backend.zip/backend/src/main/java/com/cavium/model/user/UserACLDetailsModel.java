package com.cavium.model.user;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

/*
 * UserACLDetailsModel Model class for ACL Details along with Permission Details
 * author : RK00490847
 */

@Entity
@Table(name = "acl_details")
public class UserACLDetailsModel implements Serializable {

	private static final long serialVersionUID = -684881629527582638L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(name = "descr", unique = true)
	private String aclName;
	@Column(name = "last_updated", columnDefinition = "DATETIME")
	@Temporal(TemporalType.TIMESTAMP)
	private Date lastUpdated;
	@Column(name = "user_id")
	private String username;
	@Transient
	@JsonProperty(access = Access.WRITE_ONLY)
	private List<String> permissionIds;

	public List<String> getPermissionIds() {
		return permissionIds;
	}

	public void setPermissionIds(List<String> permissionIds) {
		this.permissionIds = permissionIds;
	}

	@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY

			)
	@JoinColumn(name = "acl_id")
	private List<ACLRoleModel> listACLRoleModel = new ArrayList<ACLRoleModel>();

	public List<ACLRoleModel> getListACLRoleModel() {
		return listACLRoleModel;
	}

	public void setListACLRoleModel(List<ACLRoleModel> listACLRoleModel) {
		ACLRoleModel objACLRoleModel = null;
		if (permissionIds != null && !permissionIds.isEmpty()) {
			for (int i = 0; i < permissionIds.size(); i++) {
				if (org.apache.commons.lang.StringUtils.isNumeric(permissionIds.get(i))
						&& org.apache.commons.lang.StringUtils.isNotEmpty(permissionIds.get(i))) {
					objACLRoleModel = new ACLRoleModel();
					PermisssionDetailModel objPermisssionDetailModel = new PermisssionDetailModel();
					objPermisssionDetailModel.setPermissionId((Long.parseLong(permissionIds.get(i))));
					objACLRoleModel.setObjPermisssionDetailModel(objPermisssionDetailModel);
					objACLRoleModel.setAclId(id);
					listACLRoleModel.add(objACLRoleModel);
				}
			}
		}
		this.listACLRoleModel = listACLRoleModel;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the lastUpdated
	 */
	public Date getLastUpdated() {
		return lastUpdated;
	}

	/**
	 * @param lastUpdated
	 *            the lastUpdated to set
	 */
	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = new Date();
	}

	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * @param username
	 *            the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * @return the aclName
	 */
	public String getAclName() {
		return aclName;
	}

	/**
	 * @param aclName
	 *            the aclName to set
	 */
	public void setAclName(String aclName) {
		this.aclName = aclName;
	}

	public String toString() {
		return "ACL id: '" + this.id + "', aclName: '" + this.aclName + "', CreatedBy: '" + this.username
				+ " , PermissionIds; " + this.permissionIds;
	}

}
