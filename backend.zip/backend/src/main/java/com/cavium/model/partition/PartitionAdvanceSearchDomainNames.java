package com.cavium.model.partition;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Table(name = "partition_interface_advance_serach_domain_names")
public class PartitionAdvanceSearchDomainNames implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3803660324584160638L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	private Long Id;
	@Column(name="domain_names")
	private String domainNames;
	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name = "partition_id", nullable = false)
	@JsonBackReference
	private PartitionDetailModel partitionDetailModel;
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	public String getDomainNames() {
		return domainNames;
	}
	public void setDomainNames(String domainNames) {
		this.domainNames = domainNames;
	}
	public PartitionDetailModel getPartitionDetailModel() {
		return partitionDetailModel;
	}
	public void setPartitionDetailModel(PartitionDetailModel partitionDetailModel) {
		this.partitionDetailModel = partitionDetailModel;
	}
}
