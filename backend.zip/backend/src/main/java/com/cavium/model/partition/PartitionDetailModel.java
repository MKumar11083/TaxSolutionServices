package com.cavium.model.partition;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.partition.monitor.PartitionMonitorData;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
/**
 *  * @author MK00497144
 * Class is used as a partition entity having association with Appliance entity
 */
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Table(name = "partition_configuration")
public class PartitionDetailModel implements Serializable {

	private static final long serialVersionUID = -3840562434180092945L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "partition_id", nullable = false)
	private Long partitionId;
	@Column(name = "partition_name")
	private String partitionName;
	@Column(name = "csr")
	private String csr;
	@Column(name = "partition_keys")
	private Integer keys = 0;
	@Column(name = "ssl_context")
	private Integer sslContexts = 0;
	@Column(name = "acceleration_devices")
	private Integer acclrDev = 0;
	@Column(name = "wrap")
	private boolean wrap;
	@Column(name = "backup")
	private boolean backup;
	@Column(name = "created_date", columnDefinition = "DATETIME")
	private Date createdDate;
	@Column(name = "modified_date", columnDefinition = "DATETIME")
	private Date modifiedDate;
	@Column(name = "created_by")
	private String createdBy;
	@Column(name = "modified_by")
	private String modifiedBy;
	@Column(name="status")
	private String status;
	@Column(name="part_of_cluster")
	private boolean partOfCluster;
	
	
	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name = "appliance_id", nullable = false)
	@JsonBackReference
	@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
	private ApplianceDetailModel applianceDetailModel;
	
	@Transient
	private PartitionData partitionData;
	
	@Transient
	private PartitionInterfaces networkStats;
	
	
	@Transient
	private String message;
	@Transient
	private String code;
	
	
	@Transient
	private String username;
	@Transient
	private String password;
	
	@Column(name="last_operation_performed")
	private String lastOperationPerformed;
	@Column(name="error_message")
	private String errorMessage;
	@Column(name="last_operation_status")
	private String lastOperationStatus;
	@Transient
	private Long applianceId;
	@Transient
	private String applianceName;
	@Transient
	private String IpAddress;
	@Transient
	private boolean credentialSaved;
	@Transient
	private boolean sessionClose;
	@Transient
	private boolean enableCavServer;
	@Transient
	private boolean noKey;
	@Transient
	private boolean checkIntegrity;
	@Transient
	private Integer nodeId;
	@Transient
	private String zoneId;
	@Transient
	private String fromPartitionId;
	@Transient
	private String fromApplianceId;
	@Transient
	private String fromRestoreUsername;
	@Transient
	private String fromRestorePassword;
	
	
	@Transient
	private PartitionMonitorData partitionMonitorData;
	
	@Transient
	private List<PartitionCertificates> certificates;
	
	public Long getPartitionId() {
		return partitionId;
	}
	public void setPartitionId(Long partitionId) {
		this.partitionId = partitionId;
	}
	public String getPartitionName() {
		return partitionName;
	}
	public void setPartitionName(String partitionName) {
		this.partitionName = partitionName;
	}
	public String getCsr() {
		return csr;
	}
	public void setCsr(String csr) {
		this.csr = csr;
	}
	
	public Integer getKeys() {
		return keys;
	}
	public void setKeys(Integer keys) {
		this.keys = keys;
	}
	
	public Integer getSslContexts() {
		return sslContexts;
	}
	public void setSslContexts(Integer sslContexts) {
		this.sslContexts = sslContexts;
	}
	public Integer getAcclrDev() {
		return acclrDev;
	}
	public void setAcclrDev(Integer acclrDev) {
		this.acclrDev = acclrDev;
	}
	public boolean isWrap() {
		return wrap;
	}
	public void setWrap(boolean wrap) {
		this.wrap = wrap;
	}
	public boolean isBackup() {
		return backup;
	}
	public void setBackup(boolean backup) {
		this.backup = backup;
	}
	public ApplianceDetailModel getApplianceDetailModel() {
		return applianceDetailModel;
	}
	public void setApplianceDetailModel(ApplianceDetailModel applianceDetailModel) {
		this.applianceDetailModel = applianceDetailModel;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public PartitionInterfaces getNetworkStats() {
		return networkStats;
	}
	public void setNetworkStats(PartitionInterfaces networkStats) {
		this.networkStats = networkStats;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public PartitionData getPartitionData() {
		return partitionData;
	}
	public void setPartitionData(PartitionData partitionData) {
		this.partitionData = partitionData;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getLastOperationPerformed() {
		return lastOperationPerformed;
	}
	public void setLastOperationPerformed(String lastOperationPerformed) {
		this.lastOperationPerformed = lastOperationPerformed;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getLastOperationStatus() {
		return lastOperationStatus;
	}
	public void setLastOperationStatus(String lastOperationStatus) {
		this.lastOperationStatus = lastOperationStatus;
	}
	public Long getApplianceId() {
		return applianceId;
	}
	public void setApplianceId(Long applianceId) {
		this.applianceId = applianceId;
	}
	public String getApplianceName() {
		return applianceName;
	}
	public void setApplianceName(String applianceName) {
		this.applianceName = applianceName;
	}
	public String getIpAddress() {
		return IpAddress;
	}
	public void setIpAddress(String ipAddress) {
		IpAddress = ipAddress;
	}
	public boolean isCredentialSaved() {
		return credentialSaved;
	}
	public void setCredentialSaved(boolean credentialSaved) {
		this.credentialSaved = credentialSaved;
	}
	public boolean isSessionClose() {
		return sessionClose;
	}
	public void setSessionClose(boolean sessionClose) {
		this.sessionClose = sessionClose;
	}
	public boolean isEnableCavServer() {
		return enableCavServer;
	}
	public void setEnableCavServer(boolean enableCavServer) {
		this.enableCavServer = enableCavServer;
	}
	public List<PartitionCertificates> getCertificates() {
		return certificates;
	}
	public void setCertificates(List<PartitionCertificates> certificates) {
		this.certificates = certificates;
	}
	public boolean isNoKey() {
		return noKey;
	}
	public void setNoKey(boolean noKey) {
		this.noKey = noKey;
	}
	public boolean isCheckIntegrity() {
		return checkIntegrity;
	}
	public void setCheckIntegrity(boolean checkIntegrity) {
		this.checkIntegrity = checkIntegrity;
	}
	public Integer getNodeId() {
		return nodeId;
	}
	public void setNodeId(Integer nodeId) {
		this.nodeId = nodeId;
	}
	/**
	 * @return the partOfCluster
	 */
	public boolean isPartOfCluster() {
		return partOfCluster;
	}
	/**
	 * @param partOfCluster the partOfCluster to set
	 */
	public void setPartOfCluster(boolean partOfCluster) {
		this.partOfCluster = partOfCluster;
	}
	public PartitionMonitorData getPartitionMonitorData() {
		return partitionMonitorData;
	}
	public void setPartitionMonitorData(PartitionMonitorData partitionMonitorData) {
		this.partitionMonitorData = partitionMonitorData;
	}
	/**
	 * @return the zoneId
	 */
	public String getZoneId() {
		return zoneId;
	}
	/**
	 * @param zoneId the zoneId to set
	 */
	public void setZoneId(String zoneId) {
		this.zoneId = zoneId;
	}
	public String getFromPartitionId() {
		return fromPartitionId;
	}
	public void setFromPartitionId(String fromPartitionId) {
		this.fromPartitionId = fromPartitionId;
	}
	public String getFromApplianceId() {
		return fromApplianceId;
	}
	public void setFromApplianceId(String fromApplianceId) {
		this.fromApplianceId = fromApplianceId;
	}
	public String getFromRestoreUsername() {
		return fromRestoreUsername;
	}
	public void setFromRestoreUsername(String fromRestoreUsername) {
		this.fromRestoreUsername = fromRestoreUsername;
	}
	public String getFromRestorePassword() {
		return fromRestorePassword;
	}
	public void setFromRestorePassword(String fromRestorePassword) {
		this.fromRestorePassword = fromRestorePassword;
	}
}
