package com.cavium.model.appliance;

import java.util.List;
import com.cavium.model.appliance.FirmwareUpgradeDetailModel;

public class FirmwareListModel {
	
	private List<FirmwareUpgradeDetailModel> listFirmwareModel;

	public List<FirmwareUpgradeDetailModel> getListFirmwareModel() {
		return listFirmwareModel;
	}

	public void setListFirmwareModel(List<FirmwareUpgradeDetailModel> listFirmwareModel) {
		this.listFirmwareModel = listFirmwareModel;
	}

}
