package com.cavium.model.user;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/*
 * PermisssionDetailModel Model class for Permission Details along with Application Details
 * author : RK00490847
 */
@Entity
@Table(name="permission")
public class PermisssionDetailModel implements Serializable  {
	
	private static final long serialVersionUID = -3840562434180092945L;
	
	@Id
	@Column(name="id",nullable = false)
	private Long permissionId;
 
	@Column(name="short_permission")
	private String shortPermission;
	
	 @Column(name="permission_description")
	private String permissionDescription;
	 
	 @OneToOne(fetch = FetchType.LAZY)
	 @JoinColumn(name = "app_id",nullable = false)
	 @JsonBackReference
	 @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	 private ApplicationDetailModel objApplicationDetailModel;
	/**
	 * @return the permissionId
	 */
	public Long getPermissionId() {
		return permissionId;
	}
	/**
	 * @param permissionId the permissionId to set
	 */
	public void setPermissionId(Long permissionId) {
		this.permissionId = permissionId;
	}
	/**
	 * @return the shortPermission
	 */
	public String getShortPermission() {
		return shortPermission;
	}
	/**
	 * @param shortPermission the shortPermission to set
	 */
	public void setShortPermission(String shortPermission) {
		this.shortPermission = shortPermission;
	}
	/**
	 * @return the permissionDescription
	 */
	public String getPermissionDescription() {
		return permissionDescription;
	}
	/**
	 * @param permissionDescription the permissionDescription to set
	 */
	public void setPermissionDescription(String permissionDescription) {
		this.permissionDescription = permissionDescription;
	}
	/**
	 * @return the objApplicationDetailModel
	 */
	public ApplicationDetailModel getObjApplicationDetailModel() {
		return objApplicationDetailModel;
	}
	/**
	 * @param objApplicationDetailModel the objApplicationDetailModel to set
	 */
	public void setObjApplicationDetailModel(ApplicationDetailModel objApplicationDetailModel) {
		this.objApplicationDetailModel = objApplicationDetailModel;
	}	 
	}

