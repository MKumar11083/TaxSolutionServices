package com.cavium.model.hostadminvm.monitorstats;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="monitor_stats_data_details")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
 
public class Data
{
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "data_id", nullable = false)
	private Long dataId;
	
	@OneToOne(cascade=CascadeType.ALL,fetch = FetchType.LAZY)
	 @JoinColumn(name = "cpu_id",nullable = false)
	@JsonIgnoreProperties(ignoreUnknown = true)
    private Cpu cpu;

	@OneToOne(cascade=CascadeType.ALL,fetch = FetchType.LAZY)
	 @JoinColumn(name = "pcpu_id",nullable = false)
	@JsonIgnoreProperties(ignoreUnknown = true)
    private Pcpu pcpu;

	@OneToOne(cascade=CascadeType.ALL,fetch = FetchType.LAZY)
	 @JoinColumn(name = "memory_id",nullable = false)	
	@JsonIgnoreProperties(ignoreUnknown = true)
    private Memory memory;

	@OneToOne(cascade=CascadeType.ALL,fetch = FetchType.LAZY)
	@JoinColumn(name = "network_id",nullable = false)
	@JsonIgnoreProperties(ignoreUnknown = true)
    private Network network;
 

	/**
	 * @return the dataId
	 */
	public Long getDataId() {
		return dataId;
	}

	/**
	 * @param dataId the dataId to set
	 */
	public void setDataId(Long dataId) {
		this.dataId = dataId;
	}

	/**
	 * @return the cpu
	 */
	public Cpu getCpu() {
		return cpu;
	}

	/**
	 * @param cpu the cpu to set
	 */
	public void setCpu(Cpu cpu) {
		this.cpu = cpu;
	}

	/**
	 * @return the pcpu
	 */
	public Pcpu getPcpu() {
		return pcpu;
	}

	/**
	 * @param pcpu the pcpu to set
	 */
	public void setPcpu(Pcpu pcpu) {
		this.pcpu = pcpu;
	}

	/**
	 * @return the memory
	 */
	public Memory getMemory() {
		return memory;
	}

	/**
	 * @param memory the memory to set
	 */
	public void setMemory(Memory memory) {
		this.memory = memory;
	}

	/**
	 * @return the network
	 */
	public Network getNetwork() {
		return network;
	}

	/**
	 * @param network the network to set
	 */
	public void setNetwork(Network network) {
		this.network = network;
	}

 
 
 
 
 
 
 

  
}
