package com.cavium.model.partition;

import java.io.Serializable;

public class PartitionDnsConfig implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2483260588083234531L;
	
	private String[] dnsServers;
	private String[] searchDomainNames;
	private boolean enableService;
	
	public String[] getDnsServers() {
		return dnsServers;
	}
	public void setDnsServers(String[] dnsServers) {
		this.dnsServers = dnsServers;
	}
	public boolean isEnableService() {
		return enableService;
	}
	public void setEnableService(boolean enableService) {
		this.enableService = enableService;
	}
	public String[] getSearchDomainNames() {
		return searchDomainNames;
	}
	public void setSearchDomainNames(String[] searchDomainNames) {
		this.searchDomainNames = searchDomainNames;
	}
	
}
