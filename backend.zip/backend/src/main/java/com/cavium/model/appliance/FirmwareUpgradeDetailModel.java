package com.cavium.model.appliance;

public class FirmwareUpgradeDetailModel {
	
	private String hsmFirmwareType;
	private boolean zeroize;
	private FirmwareUpgradeFiles imageFileDeatils;
	private FirmwareUpgradeFiles signFileDeatils;
	private Integer applianceId;
	private String username;
	private String password;
	public String getHsmFirmwareType() {
		return hsmFirmwareType;
	}
	public void setHsmFirmwareType(String hsmFirmwareType) {
		this.hsmFirmwareType = hsmFirmwareType;
	}
	public boolean isZeroize() {
		return zeroize;
	}
	public void setZeroize(boolean zeroize) {
		this.zeroize = zeroize;
	}
	public FirmwareUpgradeFiles getImageFileDeatils() {
		return imageFileDeatils;
	}
	public void setImageFileDeatils(FirmwareUpgradeFiles imageFileDeatils) {
		this.imageFileDeatils = imageFileDeatils;
	}
	public FirmwareUpgradeFiles getSignFileDeatils() {
		return signFileDeatils;
	}
	public void setSignFileDeatils(FirmwareUpgradeFiles signFileDeatils) {
		this.signFileDeatils = signFileDeatils;
	}
	
	public Integer getApplianceId() {
		return applianceId;
	}
	public void setApplianceId(Integer applianceId) {
		this.applianceId = applianceId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
