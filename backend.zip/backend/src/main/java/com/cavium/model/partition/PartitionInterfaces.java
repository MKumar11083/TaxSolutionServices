package com.cavium.model.partition;

import java.io.Serializable;

public class PartitionInterfaces implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4119884984790009822L;
	
	private PartitionInterfacesGeneral general;
	private PartitionInterfacesAdvance advanced;
	public PartitionInterfacesGeneral getGeneral() {
		return general;
	}
	public void setGeneral(PartitionInterfacesGeneral general) {
		this.general = general;
	}
	public PartitionInterfacesAdvance getAdvanced() {
		return advanced;
	}
	public void setAdvanced(PartitionInterfacesAdvance advanced) {
		this.advanced = advanced;
	}
	
}
