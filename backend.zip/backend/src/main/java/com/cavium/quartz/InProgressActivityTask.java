package com.cavium.quartz;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.appliance.InitializeApplianceDetailModel;
import com.cavium.model.appliance.InitializeAppliancesRelationshipModel;
import com.cavium.model.cluster.ClusterDetailModel;
import com.cavium.model.cluster.ClusterPartitionsRelationship;
import com.cavium.model.partition.PartitionData;
import com.cavium.model.partition.PartitionDetailModel;
import com.cavium.model.recentactivity.InProgressActivity;
import com.cavium.pojo.HSMInfo;
import com.cavium.pojo.PartitionsDetails;
import com.cavium.repository.appliance.ApplianceRepository;
import com.cavium.repository.appliance.InitializeAppliancesRelationshipReposiotry;
import com.cavium.repository.appliance.InitializeRepository;
import com.cavium.repository.cluster.ClusterPartitionsRelationshipRepository;
import com.cavium.repository.cluster.ClusterRepository;
import com.cavium.repository.partition.PartitionAdvanceDNSServersRepository;
import com.cavium.repository.partition.PartitionAdvanceSearchDomainNamesRepository;
import com.cavium.repository.partition.PartitionAdvanceStaticHostIpsRepository;
import com.cavium.repository.partition.PartitionDataRepository;
import com.cavium.repository.partition.PartitionETHRepository;
import com.cavium.repository.partition.PartitionRepository;
import com.cavium.repository.recentactivity.InProgressActivityRepository;
import com.cavium.service.alerts.AlertsService;
import com.cavium.service.appliance.ApplianceService;
import com.cavium.service.partition.PartitionService;
import com.cavium.service.recentactivity.RecentActivityServiceImpl;
import com.cavium.utill.CaviumConstant;
import com.cavium.utill.CaviumUtil;
import com.cavium.utill.RestClient;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class InProgressActivityTask implements Job {
	private Logger logger = Logger.getLogger(this.getClass());

	@Autowired
	private InProgressActivityRepository inProgressActivityRepository;
	@Autowired
	RestClient restClient;
	@Autowired
	private PartitionRepository partitionRepository;
	@Autowired
	private ClusterRepository clusterRepository;
	@Autowired 
	private ApplianceRepository applianceRepository;
	@Autowired
	Environment env;
	@Autowired
	private AlertsService alertsService;
	@Autowired
	private RecentActivityServiceImpl recentActivityServiceImpl;
	@Autowired
	private PartitionAdvanceStaticHostIpsRepository advanceStaticHostIpsRepository;
	@Autowired
	private PartitionAdvanceDNSServersRepository advanceDNSServersRepository;
	@Autowired
	private PartitionAdvanceSearchDomainNamesRepository advanceSearchDomainNamesRepository;
	@Autowired
	private PartitionETHRepository partitionETHRepository;
	@Autowired
	private PartitionDataRepository partitionDataRepository;
	@Autowired
	private InitializeAppliancesRelationshipReposiotry initializeAppliancesRelationshipReposiotry;
	@Autowired
	private InitializeRepository initializeRepository;

	@Autowired
	private PartitionService partitionService;
	@Autowired
	private ApplianceService applianceService;
	@Autowired
	private ClusterPartitionsRelationshipRepository clusterPartitionsRelationshipRepository;

 

	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		// TODO Auto-generated method stub
		logger.info("Start InProgressActivityJob");
		List<InProgressActivity> listInp=null;
		ResponseEntity<String> response=null;
		try {
			listInp=inProgressActivityRepository.getInProgressStatusList();
			if(listInp!=null && listInp.size() > 0) {
				for(InProgressActivity in: listInp) {
					if(in.getJobId()!=null && in.getJobId()!=0) {
						response=restClient.invokeGETMethod("https://"+in.getIpAddress()+"/liquidsa/notification/"+in.getJobId()+"");
						if(response!=null && response.getBody()!=null) {
							ObjectMapper mapper = new ObjectMapper();
							JsonNode root = mapper.readTree(response.getBody());
							if(!root.isNull()){
								if(!root.path("status").isNull() && root.path("status").asText().equals("success")) {
									PartitionDetailModel partitionDetailModel=null;
									in.setStatus("Completed");
									if(in.getPartitionId()!=null  && in.getPartitionId() > 0) {
										  partitionDetailModel=partitionRepository.findOne(in.getPartitionId());
										  if(in.getOperationName()!=null && (in.getOperationName().equalsIgnoreCase("DeletePartition") || in.getOperationName().equalsIgnoreCase("CreatePartition") || in.getOperationName().equalsIgnoreCase("ResizePartition"))){
												ApplianceDetailModel applianceDetailModel =applianceService.updateApplianceDetails(partitionDetailModel.getApplianceDetailModel());
												applianceRepository.save(applianceDetailModel);
											}
										if(in.getOperationName()!=null && in.getOperationName().equalsIgnoreCase("DeletePartition")) {
											deletePartitionData(partitionDetailModel);								
											
										}else {
											partitionDetailModel.setLastOperationStatus("Completed");
											partitionDetailModel.setLastOperationPerformed(in.getOperationName());
											partitionDetailModel.setErrorMessage("");
											partitionDetailModel.setCode("200");
											if(in.getOperationName().equalsIgnoreCase("RemoveClusterNode")){
												ClusterDetailModel cdm=	clusterRepository.findOne(in.getClusterId());
												partitionDetailModel.setMessage("Partition " + partitionDetailModel.getPartitionName() +" deleted successfully from cluster "+cdm.getClusterName()+".");											
											}
											partitionRepository.save(partitionDetailModel);
										}
										if(in.getOperationName().equalsIgnoreCase("AddClusterNode")){
											ClusterDetailModel cdm=	clusterRepository.findOne(in.getClusterId());
											recentActivityServiceImpl.createRecentActivity(cdm.getCreatedBy(), "Partition "+partitionDetailModel.getPartitionName()+" created successfully on cluster "+cdm.getClusterName()+" by" +cdm.getCreatedBy()+".",CaviumConstant.CLUSTER_MANAGEMENT);
											int count=inProgressActivityRepository.allInprogressActivityCompletedorNot(in.getClusterId());
											if(count==1){										
											String	lastOperationStatus="Completed";
											String	lastOperationPerformed=in.getOperationName();
											String errorMessage="";
											Long clusterId=cdm.getClusterId();
											clusterRepository.updateClusterDetails(lastOperationStatus,lastOperationPerformed ,errorMessage,clusterId);
											cdm.setCode("200");											
											}
										}
										if(in.getOperationName().equalsIgnoreCase("RemoveClusterNode")){
										boolean partOfCluster=false;
										ClusterDetailModel cdm=	clusterRepository.findOne(in.getClusterId());
										
										if(in.isPartitionDeleted()){
										partitionRepository.updatePartOfCluster(partOfCluster,in.getPartitionId());
										clusterPartitionsRelationshipRepository.deletePartitionFromCluster(in.getPartitionId());
										}
										int count=inProgressActivityRepository.allInprogressActivityCompletedorNot(in.getClusterId());
										if(count==1){										
											String	lastOperationStatus="Completed";
											String	lastOperationPerformed=in.getOperationName();
											String errorMessage="";
											Long clusterId=cdm.getClusterId();
											clusterRepository.updateClusterDetails(lastOperationStatus,lastOperationPerformed ,errorMessage,clusterId);
									 
										cdm.setCode("200");											
										}
										}
										if(!in.getOperationName().equalsIgnoreCase("AddClusterNode")){
											recentActivityServiceImpl.createRecentActivity(partitionDetailModel.getCreatedBy(), ""+in.getOperationName()+" performed on "+partitionDetailModel.getPartitionName()+" by "+partitionDetailModel.getCreatedBy()+".",CaviumConstant.PARTITION_MANAGEMENT);
											}
									}if(in.getApplianceID()!=null && in.getApplianceID() > 0) {
										
										ApplianceDetailModel app=applianceRepository.findOne(in.getApplianceID());
										app.setLastOperationStatus("Completed");
										app.setLastOperationPerformed(in.getOperationName());
										app.setErrorMessage("");
										app.setCode("200");
										applianceRepository.save(app);
										if(in.getOperationName()!=null && in.getOperationName().equalsIgnoreCase("ZeroizeHSM") || (in.getOperationName().equalsIgnoreCase("FirmwareUpgradeAdapter") && in.isPartitionDeleted()))
										{
											deletePartitionsAndInitializeFromDB(app);
											boolean credentialSaved=false;
											boolean	applianceinitialized=false;
											boolean initializedthroughCavium=false;
											Long applianceId=in.getApplianceID();
											applianceRepository.updateApplianceStatus(credentialSaved,applianceinitialized,initializedthroughCavium,applianceId);
											
										}
										recentActivityServiceImpl.createRecentActivity(app.getCreatedBy(), ""+in.getOperationName()+" performed on "+app.getApplianceName()+" by "+app.getCreatedBy()+".",CaviumConstant.APPLIANCE_MANAGEMENT);
									}
								}else {
									if(!root.path("status").isNull() && (root.path("status").asText().equals("error") || root.path("status").asText().equals("warning"))) {
										in.setStatus("Failed");
										if(in.getPartitionId()!=null && in.getPartitionId() > 0) {
											PartitionDetailModel partitionDetailModel=partitionRepository.findOne(in.getPartitionId());
											if(in.getOperationName().equalsIgnoreCase("AddClusterNode")){
												partitionDetailModel.setLastOperationStatus("Failed");
												partitionDetailModel.setLastOperationPerformed(in.getOperationName());							
												partitionDetailModel=getErrorMessageForPartition(response, partitionDetailModel);
												in.setStatus("Failed");
												partitionRepository.save(partitionDetailModel);
												//clusterPartitionsRelationshipRepository.deletePartitionFromCluster(in.getPartitionId());
												ClusterDetailModel cdm=	clusterRepository.findOne(in.getClusterId());
												int count=inProgressActivityRepository.allInprogressActivityCompletedorNot(in.getClusterId());
												if(cdm!=null){
												alertsService.createAlert(cdm.getCreatedBy(),"Partition "+partitionDetailModel.getPartitionName()+" creation on cluster "+cdm.getClusterName() +" by "+cdm.getCreatedBy()+" does not complete due to "+partitionDetailModel.getErrorMessage()+".",cdm.getClusterName(),cdm.getClusterId(),CaviumConstant.CLUSTER_MANAGEMENT);
												}
												boolean partOfCluster=true;
												partitionRepository.updatePartOfCluster(partOfCluster,in.getPartitionId());											
												
												if(count==1){
													int partitionsCount=clusterPartitionsRelationshipRepository.getNumberOfPartitionForCluster(in.getClusterId());
													if(partitionsCount==0){
														if(cdm!=null){
													clusterRepository.delete(cdm);
														}
													}else{
														if(cdm!=null){
															String	lastOperationStatus="Completed";
															String	lastOperationPerformed=in.getOperationName();
															String errorMessage="";
															Long clusterId=cdm.getClusterId();
															clusterRepository.updateClusterDetails(lastOperationStatus,lastOperationPerformed ,errorMessage,clusterId);
													 
														cdm.setCode("200");
														}
													}
												 }
											}
											if(!in.getOperationName().equalsIgnoreCase("AddClusterNode")){
											partitionDetailModel.setLastOperationStatus("Failed");
											partitionDetailModel.setLastOperationPerformed(in.getOperationName());							
											partitionDetailModel=getErrorMessageForPartition(response, partitionDetailModel);
											in.setStatus("Failed");
											if(in.getOperationName()!=null && in.getOperationName().equalsIgnoreCase("CreatePartition")) {
												deletePartitionData(partitionDetailModel);
											}else {
												if(in.getOperationName().equalsIgnoreCase("RemoveClusterNode")){
												  partitionDetailModel.setMessage("");		
													int count=inProgressActivityRepository.allInprogressActivityCompletedorNot(in.getClusterId());
													ClusterDetailModel cdm=	clusterRepository.findOne(in.getClusterId());
													if(count==1){
														String	lastOperationStatus="Completed";
														String	lastOperationPerformed=in.getOperationName();
														String errorMessage="";
														Long clusterId=cdm.getClusterId();
														clusterRepository.updateClusterDetails(lastOperationStatus,lastOperationPerformed ,errorMessage,clusterId);
														 
														cdm.setCode("200");
													}
												}
												partitionRepository.save(partitionDetailModel);
											}
											
											alertsService.createAlert(partitionDetailModel.getCreatedBy(),""+in.getOperationName()+" performed on "+partitionDetailModel.getPartitionName()+" by "+partitionDetailModel.getCreatedBy()+" does not "+in.getOperationName()+" due to "+partitionDetailModel.getErrorMessage()+".",partitionDetailModel.getPartitionName(),partitionDetailModel.getPartitionId(),CaviumConstant.PARTITION_MANAGEMENT);
										}
										}if(in.getApplianceID() !=null && in.getApplianceID() > 0) {
											ApplianceDetailModel app=applianceRepository.findOne(in.getApplianceID());
											app=getErrorMessageForAppliance(response, app);
											app.setLastOperationStatus("Failed");
											app.setLastOperationPerformed(in.getOperationName());
											applianceRepository.save(app);
											if(in.getOperationName()!=null && in.getOperationName().equalsIgnoreCase("ZeroizeHSM"))
											{
												
												List<PartitionDetailModel> partlist = partitionRepository.getListOfPartitionByApplianceID(app.getApplianceId());
													for (PartitionDetailModel partitionDetailModel: partlist) {
														Long partitionId=partitionDetailModel.getPartitionId();
														String lastOperationStatus="failed";
														String lastOperationPerformed="ZeroizeHSM";
														String status="Completed";
														partitionDetailModel=getErrorMessageForPartition(response, partitionDetailModel);
														partitionRepository.save(partitionDetailModel);
														partitionRepository.updatePartitionStatus(status,lastOperationStatus,lastOperationPerformed,partitionDetailModel.getErrorMessage(),partitionId);
														
													}
											}
											
											alertsService.createAlert(app.getCreatedBy(),""+in.getOperationName()+" performed on "+app.getApplianceName()+" by "+app.getCreatedBy()+" doesnot "+in.getOperationName()+" due to "+app.getErrorMessage()+".",app.getApplianceName(),app.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
											in.setStatus("Failed");
											if(in.getOperationName()!=null && in.getOperationName().equalsIgnoreCase("Initialize")) {
												InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(app.getApplianceId());
												InitializeApplianceDetailModel init=initializeRepository.findOne(initmodel.getInitializeId());
												initializeAppliancesRelationshipReposiotry.delete(initmodel);
												initializeRepository.delete(init);
											}
										}
									}
								}
							}
						}
					}else {
						if(in.getJobId()!=null && in.getJobId()==0) {
							response=restClient.invokeGETMethod("https://"+in.getIpAddress()+"/liquidsa/notification");
							if(response!=null && response.getBody()!=null) {
								ObjectMapper mapper = new ObjectMapper();
								JsonNode root = mapper.readTree(response.getBody());
								if(!root.isNull()){
									if(!root.path("status").isNull() && root.path("status").asText().equals("success")) {
										in.setStatus("Completed");
										if(in.getPartitionId()!=null  && in.getPartitionId() > 0) {
											PartitionDetailModel partitionDetailModel=partitionRepository.findOne(in.getPartitionId());
											partitionDetailModel.setErrorMessage("");
											partitionDetailModel.setCode("200");
											partitionDetailModel.setLastOperationStatus("Completed");
											partitionDetailModel.setLastOperationPerformed(in.getOperationName());
											partitionRepository.save(partitionDetailModel);
											recentActivityServiceImpl.createRecentActivity(partitionDetailModel.getCreatedBy(), ""+in.getOperationName()+" performed on "+partitionDetailModel.getPartitionName()+" by "+partitionDetailModel.getCreatedBy()+".",CaviumConstant.PARTITION_MANAGEMENT);
										}if(in.getApplianceID()!=null && in.getApplianceID() > 0) {
											ApplianceDetailModel app=applianceRepository.findOne(in.getApplianceID());
											app.setCode("200");
											app.setLastOperationPerformed(in.getOperationName());
											app.setLastOperationStatus("Completed");
											applianceRepository.save(app);
											recentActivityServiceImpl.createRecentActivity(app.getCreatedBy(), ""+in.getOperationName()+" performed on "+app.getApplianceName()+" by "+app.getCreatedBy()+".",CaviumConstant.APPLIANCE_MANAGEMENT);
										}
									}else {
										if(!root.path("status").isNull() && (root.path("status").asText().equals("error") || root.path("status").asText().equals("warning"))) {
											if(in.getPartitionId()!=null && in.getPartitionId() > 0) {
												PartitionDetailModel partitionDetailModel=partitionRepository.findOne(in.getPartitionId());
												partitionDetailModel.setLastOperationStatus("Failed");
												partitionDetailModel.setLastOperationPerformed(in.getOperationName());
												partitionDetailModel=getErrorMessageForPartition(response, partitionDetailModel);
												in.setStatus("Failed");
												partitionRepository.save(partitionDetailModel);
												alertsService.createAlert(partitionDetailModel.getCreatedBy(), 
														 ""+in.getOperationName()+" performed on "+partitionDetailModel.getPartitionName()+" by "+partitionDetailModel.getCreatedBy()+" by "+partitionDetailModel.getCreatedBy()+" does not perfomed "+in.getOperationName()+" due to "+partitionDetailModel.getErrorMessage()+".",partitionDetailModel.getPartitionName(),partitionDetailModel.getPartitionId(),CaviumConstant.PARTITION_MANAGEMENT);
											}if(in.getApplianceID() !=null && in.getApplianceID() > 0) {
												ApplianceDetailModel app=applianceRepository.findOne(in.getApplianceID());
												app.setLastOperationPerformed(in.getOperationName());
												app.setLastOperationStatus("Failed");
												app=getErrorMessageForAppliance(response, app);
												applianceRepository.save(app);
												alertsService.createAlert(app.getCreatedBy(),""+in.getOperationName()+" performed on "+app.getApplianceName()+" by "+app.getCreatedBy()+" does not "+in.getOperationName()+".",app.getApplianceName(),app.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
												in.setStatus("Failed");
												if(in.getOperationName()!=null && in.getOperationName().equalsIgnoreCase("Initialize")) {
													InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(app.getApplianceId());
													InitializeApplianceDetailModel init=initializeRepository.findOne(initmodel.getInitializeId());
													initializeAppliancesRelationshipReposiotry.delete(initmodel);
													initializeRepository.delete(init);
												}
											}
										}
									}
								}
							}
						}
					}
					inProgressActivityRepository.save(in);
				}
			}

		} catch (Exception e) {
			logger.error("Error occured duringInProgressActivityJob"+e.getMessage());
			// TODO: handle exception
		}
		logger.info("End InProgressActivityJob");
	}

	/**
	 * This method is used for error handling for partition management
	 * @param partitionDetailModel
	 * @param root
	 * @return
	 */
	private PartitionDetailModel getErrorMessageForPartition(ResponseEntity<String> response,PartitionDetailModel partitionDetailModel) {
		try {

			if(response==null) {
				partitionDetailModel.setErrorMessage(env.getProperty("partition.applainceinternalerror.cavium"));
			}

			if(response!=null && response.getStatusCodeValue()== 408){
				partitionDetailModel.setErrorMessage(env.getProperty("partition.connectionerror.cavium"));
			}

			if(response.getBody()!=null) {
				ObjectMapper mapper = new ObjectMapper();
				JsonNode root = mapper.readTree(response.getBody());
				if(root!=null){
					if(!root.isNull()) {
						if(response.getBody().contains("busy")) {
							String operation = root.path("operation").asText();
							partitionDetailModel.setLastOperationPerformed(operation);
							partitionDetailModel.setErrorMessage("Appliance is busy due to operation "+operation+" is being performed on partition "+partitionDetailModel.getPartitionName()+".");
						}
						if(response.getBody().contains("errors")) {
							JsonNode errors = root.path("errors");
							String operation = root.path("operation").asText();
							if(!errors.isNull() && errors.size() > 0){
								logger.info("Error size from Cavium Rsponse :: "+errors.size()+" is Array "+errors.isArray());
								StringBuilder sbmessage=new StringBuilder();
								StringBuilder sbcode=new StringBuilder();
								Iterator<JsonNode> itr = errors.elements();	
								while (itr.hasNext()) {
									JsonNode temp = itr.next();
									sbcode.append(""+temp.asInt()+"");
									if(env.containsProperty(""+temp.asInt()+"")) {
										sbmessage.append(env.getProperty(""+temp.asInt()+""));
									}else {
										sbmessage.append("Error message not available");
									}
									sbcode.append(",");
									sbmessage.append(",");
								}
								String message=sbmessage.toString();
								message=message.substring(0, message.length()-1);
								message=message+".";
								String code=sbcode.toString();
								code=code.substring(0, code.length()-1);
								code=code+".";
								partitionDetailModel.setLastOperationPerformed(operation);
								partitionDetailModel.setErrorMessage(message);
							}else {
								String encodeMessage = "";
								if (errors.size() == 0) {
									encodeMessage = root.path("message").asText();
									encodeMessage = CaviumUtil.decodeMessageBase64(encodeMessage);
									partitionDetailModel.setCode("");
									partitionDetailModel.setMessage(encodeMessage);
								}else {
									partitionDetailModel.setCode("");
									partitionDetailModel.setMessage("No message found");
								}
							}
						}
					}
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured while setting error code and message..");
		}
		return partitionDetailModel;
	}


	private ApplianceDetailModel getErrorMessageForAppliance(ResponseEntity<String> response,ApplianceDetailModel applianceDetailModel) {
		try {

			if(response==null) {
				applianceDetailModel.setErrorMessage(env.getProperty("appliance.applainceinternalerror.cavium"));
			}

			if(response!=null && response.getStatusCodeValue()== 408){
				applianceDetailModel.setErrorMessage(env.getProperty("appliance.connectionerror.cavium"));
			}

			if(response.getBody()!=null) {
				ObjectMapper mapper = new ObjectMapper();
				JsonNode root = mapper.readTree(response.getBody());
				if(root!=null){
					if(!root.isNull()) {
						if(response.getBody().contains("busy")) {
							String operation = root.path("operation").asText();
							applianceDetailModel.setLastOperationPerformed(operation);
							applianceDetailModel.setErrorMessage(""+applianceDetailModel.getApplianceName()+" is busy due to operation "+operation+" is being performed");
						}
						if(response.getBody().contains("errors")) {
							JsonNode errors = root.path("errors");
							String operation = root.path("operation").asText();
							if(!errors.isNull() && errors.size() > 0){
								logger.info("Error size"+errors.size()+" is Array"+errors.isArray());
								StringBuilder sbmessage=new StringBuilder();
								StringBuilder sbcode=new StringBuilder();
								Iterator<JsonNode> itr = errors.elements();	
								while (itr.hasNext()) {
									JsonNode temp = itr.next();
									sbcode.append(""+temp.asInt()+"");
									if(env.containsProperty(""+temp.asInt()+"")) {
										sbmessage.append(env.getProperty(""+temp.asInt()+""));
									}else {
										sbmessage.append("Error message not available");
									}
									sbcode.append(",");
									sbmessage.append(",");
								}
								String message=sbmessage.toString();
								message=message.substring(0, message.length()-1);
								message=message+".";
								String code=sbcode.toString();
								code=code.substring(0, code.length()-1);
								code=code+".";
								applianceDetailModel.setLastOperationPerformed(operation);
								applianceDetailModel.setErrorMessage(message);
							}else {
								String encodeMessage = "";
								if (errors.size() == 0) {
									encodeMessage = root.path("message").asText();
									encodeMessage = CaviumUtil.decodeMessageBase64(encodeMessage);
									applianceDetailModel.setCode("");
									applianceDetailModel.setMessage(encodeMessage);
								}else {
									applianceDetailModel.setCode("");
									applianceDetailModel.setMessage("No message found");
								}
							}
						}
					}
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured while setting error code and message..");
		}
		return applianceDetailModel;
	}

	private void deletePartitionData(PartitionDetailModel partitionDetailModel) {
		boolean issuccess=false;
		try {
			
			if(partitionDetailModel!=null && partitionDetailModel.getPartitionId()!=0) {
				partitionETHRepository.deletePartitionETH(partitionDetailModel.getPartitionId());
				advanceStaticHostIpsRepository.deletePartitionAdvanceStaticHostIps(partitionDetailModel.getPartitionId());
				advanceDNSServersRepository.deletePartitionAdvanceDNSServers(partitionDetailModel.getPartitionId());
				advanceSearchDomainNamesRepository.deletePartitionAdvanceSearchDomainNames(partitionDetailModel.getPartitionId());
				partitionDataRepository.deletePartitionData(partitionDetailModel.getPartitionId());
			}
			issuccess=true;
		} catch (Exception e) {
			issuccess=false;
			// TODO: handle exception
			logger.error("Error ocuured during delete partition data");
			alertsService.createAlert(partitionDetailModel.getCreatedBy(),"Device "+partitionDetailModel.getApplianceDetailModel().getApplianceName()+"  try to perofrm delete partition by "+partitionDetailModel.getCreatedBy()+" does not perfomed delete partition due to db error",partitionDetailModel.getPartitionName(),partitionDetailModel.getPartitionId(),CaviumConstant.PARTITION_MANAGEMENT);
		}finally {
			if(issuccess) {
				partitionDetailModel.setApplianceDetailModel(null);
				partitionRepository.delete(partitionDetailModel);
				recentActivityServiceImpl.createRecentActivity(partitionDetailModel.getCreatedBy(), "Partition "+partitionDetailModel.getPartitionName()+" deleted by "+partitionDetailModel.getCreatedBy()+".",CaviumConstant.PARTITION_MANAGEMENT);
			}
		}
	}


	public void deletePartitionsAndInitializeFromDB(ApplianceDetailModel app){
		try{
			
			HSMInfo hSMInfo= new HSMInfo();
			HSMInfo hsmInfo=applianceService.getHSMInfo(app,hSMInfo);
			if(hsmInfo.getFipsState().replaceAll(" ","").contains("-1[zeroized]"))
			{
				PartitionsDetails partitionsDetails=null;
				partitionsDetails=partitionService.getPartitionInfo(app,partitionsDetails);	
				if(partitionsDetails!=null){
					if(partitionsDetails.getTotalPartitions()==0 && partitionsDetails.getPartitionDataList().size()==0){
						List<PartitionDetailModel> PartitionDetailModelList = partitionRepository.getListOfPartitionByApplianceID(app.getApplianceId());
						if(PartitionDetailModelList!=null && PartitionDetailModelList.size()>0){
							for(PartitionDetailModel pdm : PartitionDetailModelList){
								Long partitionId=pdm.getPartitionId();
								PartitionDetailModel partitionDetailModel=partitionRepository.findOne(partitionId);								 
								deletePartitionData(partitionDetailModel);
								List<ClusterPartitionsRelationship> clus=clusterPartitionsRelationshipRepository.getListOfClusters(partitionDetailModel.getPartitionId());
								if(clus!=null && clus.size() > 0) {
									clusterPartitionsRelationshipRepository.deletePartitionFromCluster(partitionDetailModel.getPartitionId());
									/*for(ClusterPartitionsRelationship cls: clus) {
										clusterRepository.delete(cls.getClusterId());
									}*/
								}
							 }
						}
					 }
					else{
						List<String>removedpartitionNamesList = new ArrayList<String>();
				 
						List<PartitionDetailModel> PartitionDetailModelList = partitionRepository.getListOfPartitionByApplianceID(app.getApplianceId());
						for(PartitionDetailModel pdm : PartitionDetailModelList){
							removedpartitionNamesList.add(pdm.getPartitionName());
						}
						
						 for (String removedpartitionName:removedpartitionNamesList ) {
							
							for (Iterator<PartitionData> iterator = partitionsDetails.getPartitionDataList().iterator(); iterator.hasNext();) {
								PartitionData partitionData = (PartitionData) iterator.next();
								if(!StringUtils.isEmpty(partitionData.getName())) {
									if(removedpartitionName.equalsIgnoreCase(partitionData.getName()))
									{ 
										removedpartitionNamesList.remove(removedpartitionName);
									}
								}
							}
						}
							Long applianceId=Long.valueOf(app.getApplianceId());
							  List<PartitionDetailModel> pdm=null;	
							  for(String partitionName : removedpartitionNamesList){
								pdm=partitionRepository.getListOfPartitionByPartitionNameAndApplianceId(partitionName,applianceId);
								if(pdm!=null && pdm.size()!=0) {
									PartitionDetailModel pdmodel=pdm.get(0);
									deletePartitionData(pdmodel);
								}
							 }
						 }
					}
				}
				InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(app.getApplianceId());
				if(initmodel!=null){
				InitializeApplianceDetailModel init=initializeRepository.findOne(initmodel.getInitializeId());
				initializeAppliancesRelationshipReposiotry.delete(initmodel);
				initializeRepository.delete(init);
				}
			
		}catch (Exception e) {
			logger.error("Error ocuured during delete partitions and initialize Data from DB :: "+e.getMessage());
		}
	}

}
