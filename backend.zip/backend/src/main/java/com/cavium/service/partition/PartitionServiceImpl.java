package com.cavium.service.partition;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.transaction.Transactional;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.log4j.Logger;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.appliance.DualFactorAuthDetailModel;
import com.cavium.model.appliance.InitializeApplianceDetailModel;
import com.cavium.model.appliance.InitializeAppliancesRelationshipModel;
import com.cavium.model.appliance.StoreType;
import com.cavium.model.hostadminvm.monitorstats.MonitorStats;
import com.cavium.model.partition.PartitionAdvanceDNSServers;
import com.cavium.model.partition.PartitionAdvanceSearchDomainNames;
import com.cavium.model.partition.PartitionAdvanceStaticHostIps;
import com.cavium.model.partition.PartitionCertificates;
import com.cavium.model.partition.PartitionData;
import com.cavium.model.partition.PartitionDetailModel;
import com.cavium.model.partition.PartitionDnsConfig;
import com.cavium.model.partition.PartitionETH;
import com.cavium.model.partition.PartitionInterfaces;
import com.cavium.model.partition.PartitionInterfacesAdvance;
import com.cavium.model.partition.PartitionInterfacesGeneral;
import com.cavium.model.partition.RestorePartitionModel;
import com.cavium.model.partition.StaticSearchADD;
import com.cavium.model.partition.monitor.MonitorData;
import com.cavium.model.partition.monitor.PartitionMonitorCWI;
import com.cavium.model.partition.monitor.PartitionMonitorData;
import com.cavium.model.partition.monitor.PartitionMonitorPMNCData;
import com.cavium.model.partition.monitor.PartitionNetworkMonitorStats;
import com.cavium.model.recentactivity.InProgressActivity;
import com.cavium.model.user.UserDetailModel;
import com.cavium.pojo.PartitionDetailsWithPercentage;
import com.cavium.pojo.PartitionSnapshotDetails;
import com.cavium.pojo.PartitionsDetails;
import com.cavium.pojo.UserAttributes;
import com.cavium.pojo.partitionstats.PartitionStatsDetails;
import com.cavium.repository.appliance.ApplianceRepository;
import com.cavium.repository.appliance.InitializeAppliancesRelationshipReposiotry;
import com.cavium.repository.appliance.InitializeRepository;
import com.cavium.repository.partition.PartitionAdvanceDNSServersRepository;
import com.cavium.repository.partition.PartitionAdvanceSearchDomainNamesRepository;
import com.cavium.repository.partition.PartitionAdvanceStaticHostIpsRepository;
import com.cavium.repository.partition.PartitionDataRepository;
import com.cavium.repository.partition.PartitionETHRepository;
import com.cavium.repository.partition.PartitionRepository;
import com.cavium.repository.partition.PartitionStatsRepository;
import com.cavium.repository.recentactivity.InProgressActivityRepository;
import com.cavium.repository.user.UserRepository;
import com.cavium.service.alerts.AlertsService;
import com.cavium.service.fileupload.FileUploadService;
import com.cavium.service.recentactivity.InProgressActivityService;
import com.cavium.service.recentactivity.RecentActivityServiceImpl;
import com.cavium.utill.CaviumConstant;
import com.cavium.utill.CaviumResponseModel;
import com.cavium.utill.CaviumUtil;
import com.cavium.utill.RestClient;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;



/**
 *  * @author MK00497144
 *  Class is used as a service implementation for Partitions 
 */
@Component
public class PartitionServiceImpl implements PartitionService {
	private Logger logger = Logger.getLogger(this.getClass());



	/**
	 * This class is used to set the response attributes for incoming requests
	 */
	@Lookup
	public CaviumResponseModel getCaviumResponseModel() {
		return null;
	}

	/**
	 * This Interface is used to get the values from the property file
	 */
	@Autowired
	Environment env;


	/*
	 * getAllAppliancesDetails method is used for fetch All appliances Details.
	 * 
	 * @return listApplianceDetailModel - List of ApplianceDetailModel Object.
	 * 
	 */

	@Autowired
	RestClient restClient;
	@Autowired
	private UserAttributes userAttributes;
	@Autowired
	private PartitionRepository partitionRepository;
	
	@Autowired
	private PartitionStatsRepository partitionStatsRepository;
	@Autowired
	private PartitionAdvanceDNSServersRepository advanceDNSServersRepository;
	@Autowired
	private PartitionAdvanceSearchDomainNamesRepository advanceSearchDomainNamesRepository;
	@Autowired
	private PartitionAdvanceStaticHostIpsRepository advanceStaticHostIpsRepository;
	@Autowired
	private PartitionETHRepository partitionETHRepository;
	@Autowired
	private ApplianceRepository applianceRepository;
	@Autowired
	private InitializeRepository initializeRepository;
	@Autowired
	private InitializeAppliancesRelationshipReposiotry initializeAppliancesRelationshipReposiotry;
	@Autowired
	private RecentActivityServiceImpl recentActivityServiceImpl;
	@Autowired
	private AlertsService alertsService;
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private PartitionDataRepository partitionDataRepository;
	@Autowired
	private InProgressActivityService inProgressActivityService;
	@Autowired
	private InProgressActivityRepository inProgressActivityRepository;
	@Autowired
	private FileUploadService fileUploadService;
	
	@Lookup
	public PartitionsDetails getPartitionsDetails() {
		return null;
	}

	@Override
	public PartitionDetailModel createPartition(String loggedInUser,PartitionDetailModel partitionDetailModels,Boolean partitionAlreadyExist) {
		// TODO Auto-generated method stub
		List<PartitionDetailModel> pdm=null;
		ObjectMapper mapper = new ObjectMapper();
		try {
			List<PartitionDetailModel> listOfPartitions=partitionRepository.getListOfPartitionByApplianceID(partitionDetailModels.getApplianceId());
			if(listOfPartitions!=null && listOfPartitions.size() < 32) {
				if(!StringUtils.isEmpty(partitionDetailModels.getPartitionName())) {
					pdm=partitionRepository.getListOfPartitionByPartitionNameAndApplianceId(partitionDetailModels.getPartitionName(),partitionDetailModels.getApplianceId());
				}
				if(pdm!=null && pdm.size()==0) {
					ResponseEntity<String> response=null;
					JsonNode root=null;
					if(partitionDetailModels!=null && partitionDetailModels.getApplianceDetailModel()!=null && partitionDetailModels.getApplianceDetailModel().getIpAddress()!=null) {
						if(partitionAlreadyExist==null){
							response=createPartitionViaCaviumExtenalAPI(partitionDetailModels);
						}
						if((response!=null && response.getBody()!=null) || partitionAlreadyExist!=null) {
							if((response!=null && response.getBody().contains("success")) || partitionAlreadyExist!=null ) {
								logger.info("response is not null in  createPartition method");
								if(partitionAlreadyExist==null) {
									partitionDetailModels.setIpAddress(partitionDetailModels.getApplianceDetailModel().getIpAddress());
									root = mapper.readTree(response.getBody());
									partitionDetailModels.setCreatedBy(loggedInUser);
									partitionDetailModels.setCreatedDate(new Date());
								}
								else{
									partitionDetailModels.setCreatedBy(loggedInUser);
									partitionDetailModels.setCreatedDate(new Date());
								}
								/**
								 * Saving partition
								 */
								
								try {
									
									ApplianceDetailModel applianceDetailModel=applianceRepository.getApplianceById(partitionDetailModels.getApplianceDetailModel().getApplianceId(), StoreType.PERMANENT);
									partitionDetailModels.setApplianceDetailModel(applianceDetailModel);
									if(partitionAlreadyExist==null)
									partitionDetailModels.setStatus("In-Progress");
									else
									 partitionDetailModels.setStatus("Completed");
									partitionRepository.save(partitionDetailModels);
									
									if(root==null){
										logger.info("Existng Partitions imported from cavium");
									 if(partitionDetailModels.getPartitionData()!=null) {
										 
										 partitionDetailModels.getPartitionData().setPartitionId(Integer.valueOf(String.valueOf(partitionDetailModels.getPartitionId())));
										 partitionDataRepository.save(partitionDetailModels.getPartitionData());
										 logger.info("Saving Partition Data in DB");
									 }
									}
									if(partitionDetailModels!=null && partitionDetailModels.getPartitionId() > 0) {
										/**
										 * Saving ETH0 and ETH1	
										 */
										 PartitionETH eth0=partitionDetailModels.getNetworkStats().getGeneral().getEth0();
										 PartitionETH eth1=partitionDetailModels.getNetworkStats().getGeneral().getEth1();
										 eth0.setEthName("eth0");
										 eth1.setEthName("eth1");
										 eth0.setPartitionDetailModel(partitionDetailModels);
										 eth1.setPartitionDetailModel(partitionDetailModels);
										 partitionETHRepository.save(eth0);
										 partitionETHRepository.save(eth1);
										 
										 								 
										 /**
										  * Save partition_inetrface_advance_static_host_ip
										  */
										 List<PartitionAdvanceStaticHostIps> StaticHostIps=partitionDetailModels.getNetworkStats().getAdvanced().getStaticIpToHostConfig().getAdd();
										 if(StaticHostIps!=null && StaticHostIps.size() > 0) {
											 for(PartitionAdvanceStaticHostIps ips : StaticHostIps) {
												 ips.setPartitionDetailModel(partitionDetailModels);
											 }
											 advanceStaticHostIpsRepository.save(StaticHostIps);
										 }
										 
										 /**
										  * Save partition_inetrface_advance_dns_servers
										  */
										 String[] dnsServers=partitionDetailModels.getNetworkStats().getAdvanced().getDnsConfig().getDnsServers();
										 if(dnsServers!=null && dnsServers.length > 0) {
											 List<PartitionAdvanceDNSServers> listDNSServers=new ArrayList<PartitionAdvanceDNSServers>();
											 for(String dns : dnsServers) {
												 PartitionAdvanceDNSServers dnsser=new PartitionAdvanceDNSServers();
												 dnsser.setDnsAddress(dns);
												 dnsser.setPartitionDetailModel(partitionDetailModels);
												 listDNSServers.add(dnsser);
											 }
											 advanceDNSServersRepository.save(listDNSServers);
										 }
										 
										 
										 /**
										  * Save partition_inetrface_advance_serach_domain_names
										  */
										 String[] domainNames= partitionDetailModels.getNetworkStats().getAdvanced().getDnsConfig().getSearchDomainNames();
										 if(domainNames!=null && domainNames.length > 0) {
											 List<PartitionAdvanceSearchDomainNames> listSerachDomains=new ArrayList<PartitionAdvanceSearchDomainNames>();;
											 for(String domainName : domainNames) {
												 PartitionAdvanceSearchDomainNames domain=new PartitionAdvanceSearchDomainNames();
												 domain.setDomainNames(domainName);
												 domain.setPartitionDetailModel(partitionDetailModels);
												 listSerachDomains.add(domain);
											 }
											 advanceSearchDomainNamesRepository.save(listSerachDomains);
										 }
										
										}
									partitionDetailModels.setMessage("Create partition Initiated successfully for "+partitionDetailModels.getPartitionName()+"");
									partitionDetailModels.setCode("200");
									partitionDetailModels.setLastOperationPerformed("Create Partition");
								
									partitionDetailModels.setErrorMessage("");
									if(root!=null){
										partitionDetailModels.setLastOperationStatus("In-Progress");
										getPartitionInformationModel(partitionDetailModels);
										updateInProgressActivity(partitionDetailModels, loggedInUser, root);
										}else{
											partitionDetailModels.setLastOperationStatus("Completed");
											recentActivityServiceImpl.createRecentActivity(loggedInUser, "Partition "+partitionDetailModels.getPartitionName()+" created for appliance "+partitionDetailModels.getApplianceDetailModel().getApplianceName()+" by "+ partitionDetailModels.getCreatedBy(),CaviumConstant.PARTITION_MANAGEMENT);
										}
								} catch (Exception e) {
									partitionDetailModels.setCode("408");
									partitionDetailModels.setErrorMessage(env.getProperty("partition.dberror"));
									// TODO: handle exception
								}
							
							}else {
								partitionDetailModels=getErrorMessage(response, partitionDetailModels,loggedInUser,"Create Partition");
							}
						}else {
							partitionDetailModels=getErrorMessage(response, partitionDetailModels,loggedInUser,"Create Partition");
						}
					}
				}else {
					partitionDetailModels.setCode("408");
					partitionDetailModels.setErrorMessage(env.getProperty("partition.alreadyexists"));
				}
			}else {
				partitionDetailModels.setCode("408");
				partitionDetailModels.setErrorMessage("Partition can not be create due to maximum number of partitions exceeded.");
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during create partition inside method createPartition of class PartitionServiceIMPL :: "+e.getMessage());
		}
		
		return partitionDetailModels;
	}


	@Override
	public PartitionDetailModel modifyPartition(String loggedInUser,PartitionDetailModel partitionDetailModels) {
		// TODO Auto-generated method stub
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return partitionDetailModels;
	}


	@Override
	public List<PartitionDetailModel> deletePartition(String loggedInUser, List<PartitionDetailModel> partitionDetailModels) {
		// TODO Auto-generated method stub
		List<PartitionDetailModel> listPartition=new ArrayList<>();
		boolean isSessionCloseFailed = false;
		JSONObject jsonObject =new JSONObject();
		try {
			for(PartitionDetailModel pdmobj : partitionDetailModels) {
				ResponseEntity<String> response = null;
				PartitionDetailModel pdm = partitionRepository.findOne(pdmobj.getPartitionId());
				if (pdm != null && pdm.getPartitionId() > 0 && pdmobj.getApplianceDetailModel() != null) {
					logger.info("Deleted partition Id :: " +pdmobj.getPartitionId());
					ApplianceDetailModel app = pdmobj.getApplianceDetailModel();
					ApplianceDetailModel dbAppliance = applianceRepository.findOne(app.getApplianceId());
					if (dbAppliance != null) {
						 jsonObject = getUserNamePassword(pdmobj,jsonObject);
							if(pdmobj.isSessionClose()) {
								jsonObject.put("action", "close_session");
								ResponseEntity<String>	closeSessionresponse=restClient.invokePUTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/partition/"+pdmobj.getPartitionName()+"",jsonObject);
								if(closeSessionresponse!=null && closeSessionresponse.getBody()!=null) {
									ObjectMapper mapper = new ObjectMapper();
									JsonNode root = mapper.readTree(closeSessionresponse.getBody());
									Thread.sleep(15000);
									pdm=getStatusFromJobId(pdm, root, loggedInUser, "Session Close");
									if(pdm.getMessage()!=null && pdm.getStatus().equalsIgnoreCase("Completed")) {
										jsonObject.remove("action");
										response = restClient.invokeDELETEMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/partition/"+pdmobj.getPartitionName()+"", jsonObject);
										isSessionCloseFailed=false;
									}else {
										isSessionCloseFailed=true;
										pdm.setMessage("Failed");
										pdm.setErrorMessage("Delete Partition failed due to close session");
										pdm.setLastOperationPerformed("Delete Partition");
										pdm.setLastOperationStatus("Failed");
										pdm.setCode("11032");
										partitionRepository.save(pdm);
									}
								}
							}else {
								response = restClient.invokeDELETEMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/partition/"+pdmobj.getPartitionName()+"", jsonObject);
								isSessionCloseFailed=false;
							}
						if(response!=null && response.getBody()!=null && isSessionCloseFailed==false) {
							if(response.getBody().contains("success")) {
								pdm.setMessage("Delete Partition Initiated successfully.");
								pdm.setErrorMessage("");
								pdm.setLastOperationPerformed("Delete Partition");
								pdm.setLastOperationStatus("In-Progress");
								pdm.setCode("200");
								ObjectMapper mapper = new ObjectMapper();
								JsonNode root = mapper.readTree(response.getBody());
								if (!root.isNull()) {
									updateInProgressActivity(pdm, loggedInUser, root);
								}
								partitionRepository.save(pdm);
							}else {
								if(isSessionCloseFailed==false) {
									pdm=getErrorMessage(response, pdm,loggedInUser,"Delete Partition");
									partitionRepository.save(pdm);
								}
							}
						}else {
							if(isSessionCloseFailed==false) {
								pdm=getErrorMessage(response, pdm,loggedInUser,"Delete Partition");
								partitionRepository.save(pdm);
							}
						}
					}
				}else {
					pdm=pdmobj;
					pdm.setCode("408");
					pdm.setErrorMessage("Partition "+pdm.getPartitionName()+" does not exists.");
				}
				listPartition.add(pdm);
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error(
					"Error occured during partition delete in method deletePartition of class PartitionServiceImpl "
							+ e.getMessage());
		}
		return listPartition;
	}

	@Override
	public List<PartitionDetailModel> getListOfPartitions(String loggedInUser) {
		// TODO Auto-generated method stub
		List<PartitionDetailModel> listPartitions = null;
		try {
			UserDetailModel objUserDetailModel=userRepository.findOne(loggedInUser);
			if(objUserDetailModel!=null && objUserDetailModel.getObjUserACLDetailsModel().getAclName().equals(env.getProperty("user.superadmin"))) {
				listPartitions = partitionRepository.findAll();
			}else {
				listPartitions = partitionRepository.getListOfPartitionByGroupId(loggedInUser);
			}
			listPartitions=setObjectsInPartitionDetailModel(listPartitions);
			inProgressActivityRepository.deleteInProgressActivityByStatus();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return listPartitions;
	}
	
	private ResponseEntity<String> createPartitionViaCaviumExtenalAPI(PartitionDetailModel partitionDetailModels) {
		ResponseEntity<String> response=null;
		try {
			boolean initialized=false;
			partitionDetailModels.setIpAddress(null);
			ApplianceDetailModel app=partitionDetailModels.getApplianceDetailModel();
			ApplianceDetailModel dbAppliance=applianceRepository.findOne(app.getApplianceId()); 
			JSONObject jsonObject=new JSONObject(partitionDetailModels);
			jsonObject=removeNullsAndKeysFrom(jsonObject,null);
			if(dbAppliance!=null) {
				long applianceId=app.getApplianceId();
				InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(applianceId);
				ApplianceDetailModel	applianceDetailModel=applianceRepository.findOne(applianceId);
				if(applianceDetailModel!=null){
					initialized=applianceDetailModel.isApplianceinitialized();
				}
				if(initmodel!=null || initialized ) {
					jsonObject=getUserNamePassword(partitionDetailModels,jsonObject);
					response=restClient.invokePOSTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/partition",jsonObject);
				}else {
					response=new ResponseEntity<>(HttpStatus.valueOf(env.getProperty("partition.initializenotdone")));
					}
			}else {
				response=new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during method createPartitionViaCaviumExtenalAPI in class PartitionServiceImpl "+e.getMessage());
		}
		return response;
	}
	
	private JSONObject removeNullsAndKeysFrom(JSONObject object,String type) throws JSONException {
		 
		try {
			if (object != null) {
				
				object=removeUnwantedKeysForCreatePartition(object, type);
				Iterator<String> iterator = object.keys();
				while (iterator.hasNext()) {
					String key = iterator.next();
					Object o = object.get(key);
					if (o != null && o.equals("")) {
						iterator.remove();
					}
					if (key.equals("networkStats")) {
						JSONObject general = (JSONObject) o;
						JSONObject gen = (JSONObject) general.get("general");
						/**
						 * Eth0 modification
						 */
						JSONObject eth0 = (JSONObject) gen.get("eth0");
						Iterator<String> iteratorr = eth0.keys();
						while (iteratorr.hasNext()) {
							String keyy = iteratorr.next();
							Object oo = eth0.get(keyy);
							if (oo != null && oo.equals("")) {
								iterator.remove();
							}
						}

						eth0.remove("id");
						eth0.remove("ethName");
						eth0.remove("disableEth1");
						Map<String, Object> staticmac = new HashMap<>();
						staticmac.put("staticMac", eth0.get("staticMac"));
						boolean staticMac = (boolean) eth0.get("staticMac");
						if (staticMac == true && !eth0.isNull("address")) {
							staticmac.put("address", eth0.get("address"));
							eth0.remove("staticMac");
							eth0.remove("address");
							eth0.put("mac", staticmac);
						} else {
							eth0.remove("staticMac");
							eth0.put("mac", staticmac);
							if(eth0.has("address")) {
								eth0.remove("address");
							}
						}

						/**
						 * Eth1 modification
						 */

						JSONObject eth1 = (JSONObject) gen.get("eth1");
						eth1.remove("id");
						eth1.remove("ethName");
						eth1.remove("gateway");
						Map<String, Object> mac = new HashMap<>();
						mac.put("staticMac", eth1.get("staticMac"));
						boolean isstaticmac1 = (boolean) eth1.get("staticMac");
						if (isstaticmac1 == true && !eth1.isNull("address")) {
							mac.put("address", eth1.get("address"));
							eth1.remove("staticMac");
							eth1.remove("address");
							eth1.put("mac", mac);
						} else {
							eth1.remove("staticMac");
							eth1.put("mac", staticmac);
							if(eth1.has("address")) {
								eth1.remove("address");
							}
						}
					}
					if (o == null || o == JSONObject.NULL) {
						iterator.remove();
					}
				}

			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during method removeNullsAndKeysFrom in class PartitionServiceImpl "+e.getMessage());
		}
		 return object;
	 }
 
public List<PartitionDetailModel> setObjectsInPartitionDetailModel(List<PartitionDetailModel> listPartitionDetailModel){
    	
    	try {
    		for(PartitionDetailModel pdm: listPartitionDetailModel){
    			ApplianceDetailModel app=pdm.getApplianceDetailModel();
    			pdm.setApplianceId(app.getApplianceId());
    			pdm.setApplianceName(app.getApplianceName());
    			pdm.setIpAddress(app.getIpAddress());
    			pdm.setCredentialSaved(app.isCredentialSaved());
    			pdm.setZoneId(app.getZoneId());
    			/**
    			 * Merging eth into partition detail model
    			 */
    			List<PartitionETH> ethlist=partitionETHRepository.getPartitionETHList(String.valueOf(pdm.getPartitionId()));
    			PartitionInterfaces interfaces=new PartitionInterfaces();
				PartitionInterfacesGeneral general=new PartitionInterfacesGeneral();
    			for(PartitionETH eth:ethlist) {
    				if(!StringUtils.isEmpty(eth.getEthName()) && eth.getEthName().equals("eth0")) {
    					general.setEth0(eth);
    					interfaces.setGeneral(general);
    					pdm.setNetworkStats(interfaces);
    				}if(!StringUtils.isEmpty(eth.getEthName()) && eth.getEthName().equals("eth1")) {
    					general.setEth1(eth);
    					interfaces.setGeneral(general);
    					pdm.setNetworkStats(interfaces);
    				}
    			}
    			
    			/**
    			 * Merging dnsServers into the partition object under advance child object
    			 */
    			
    			List<PartitionAdvanceDNSServers> dnsServers=advanceDNSServersRepository.getDNSServersList(String.valueOf(pdm.getPartitionId()));
    			PartitionInterfacesAdvance advanced=new PartitionInterfacesAdvance();
    			PartitionDnsConfig dnsconfig=new PartitionDnsConfig();
    			String[] dnsarray=new String[dnsServers.size()];
    			int count=0;
    			for(PartitionAdvanceDNSServers dns:dnsServers) {
    				dnsarray[count]=dns.getDnsAddress();
    				count++;
    			}
    			dnsconfig.setDnsServers(dnsarray);
    			
    			
    			/**
    			 * Merging domainNames into partition object  under advance child object
    			 */
    			
    			List<PartitionAdvanceSearchDomainNames> domainNames=advanceSearchDomainNamesRepository.getDomainNamesList(String.valueOf(pdm.getPartitionId()));
    			String[] domainNamesarray=new String[dnsServers.size()];
    			int countt=0;
    			for(PartitionAdvanceSearchDomainNames dn:domainNames) {
    				domainNamesarray[countt]=dn.getDomainNames();
    				countt++;
    			}
    			dnsconfig.setSearchDomainNames(domainNamesarray);
    			advanced.setDnsConfig(dnsconfig);
    			
    			/**
    			 * Merging staticIpHost into partition object  under advance child object
    			 */
    			List<PartitionAdvanceStaticHostIps> staticipHost=advanceStaticHostIpsRepository.getStaticIpHostList(String.valueOf(pdm.getPartitionId()));
    			StaticSearchADD add=new StaticSearchADD();
    			add.setAdd(staticipHost);
    			advanced.setStaticIpToHostConfig(add);
    			interfaces.setAdvanced(advanced);
    			/**
    			 * Merging Appliance Object into partition object
    			 */
    			/*ApplianceDetailModel applianceDetailModel = pdm.getApplianceDetailModel();
    			pdm.setApplianceDetailModel(applianceDetailModel);*/
    			PartitionData data=partitionDataRepository.getPartitionData(String.valueOf(pdm.getPartitionId()));
    			if(data!=null) {
    				if(data.getMaxKeys()!=null && data.getOccupiedSessionKeys()!=null && data.getOccupiedTokenKeys()!=null) {
    					Integer keys=data.getMaxKeys()-data.getOccupiedSessionKeys()-data.getOccupiedTokenKeys();
        				data.setKeysUsage(keys);
    				}
    				Integer maxKeys=data.getMaxKeys();
    				Integer occupiedSessionKeys=data.getOccupiedSessionKeys();
    				Integer	occupiedTokenKeys=data.getOccupiedTokenKeys();
    				Integer sslContextUsed=data.getOccupiedSslCtxs();
    				Integer totalsslContext=data.getTotalSslCtxs();
    				if(totalsslContext!=null && sslContextUsed!=null){
    				Integer sslContextAvaliabe=totalsslContext-sslContextUsed;
    				data.setSslContextAvaliable(sslContextAvaliabe);
    				}
    				if(maxKeys!=null && occupiedSessionKeys!=null && occupiedTokenKeys!=null){
    				Integer keysAvaliable=maxKeys-occupiedSessionKeys-occupiedTokenKeys;
    				Integer keysUsed=occupiedSessionKeys+occupiedTokenKeys;		
    				data.setKeysAvaliable(keysAvaliable);
    				data.setKeysUsed(keysUsed);
    				}
    				pdm.setPartitionData(data);
    			}
    		}
    		
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during method setObjectsInPartitionDetailModel in class PartitionServiceImpl "+e.getMessage());
		}
    	
    	return listPartitionDetailModel;
    }


	@Override
	public CaviumResponseModel validateInitOperationForCreatePartition(ApplianceDetailModel applianceDetailModel) {
		// TODO Auto-generated method stub
		CaviumResponseModel response=new CaviumResponseModel();
		boolean initialized=false;
		try {
			if(applianceDetailModel!=null) {
				long applianceId=applianceDetailModel.getApplianceId();
				InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(applianceId);
				applianceDetailModel=applianceRepository.findOne(applianceId);
				if(applianceDetailModel!=null){
					initialized=applianceDetailModel.isApplianceinitialized();
				}
				if(initmodel!=null || initialized) {
					response.setResponseCode("200");
					response.setResponseMessage("success");
				}else {
					response.setResponseCode("401");
					response.setResponseMessage("failed");
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during method validateInitOperationForCreatePartition in class PartitionServiceImpl "+e.getMessage());
		}
		return response;
	}
	
	@Override
	@Transactional
	public void getPartitionInformationModel(PartitionDetailModel partitionDetailModel) {
		
		logger.info("Asynchronous task started successfully..");
		try {
			new Thread(new Runnable() {
				PartitionData partitionData=new PartitionData();
				ResponseEntity<String> response=null;
				ResponseEntity<String> responseNetworkStat=null;
				@Override
				public void run() {
					// TODO Auto-generated method stub
					try {
						TimeUnit.MINUTES.sleep(2);
					} catch (InterruptedException e1) {
						// TODO Auto-generated catch block
						logger.error("Error occured during restClient call for partitioninfo"+e1.getMessage());
					}
					if(partitionDetailModel!=null && partitionDetailModel.getApplianceDetailModel().getIpAddress()!=null) {
						try {
							response=restClient.invokeGETMethod("https://"+partitionDetailModel.getApplianceDetailModel().getIpAddress()+"/liquidsa/partition/"+partitionDetailModel.getPartitionName()+"");
						} catch (KeyManagementException e) {
							// TODO Auto-generated catch block
							logger.error("Error occured during restClient call for partitioninfo"+e.getMessage());
						} catch (KeyStoreException e) {
							// TODO Auto-generated catch block
							logger.error("Error occured during restClient call for partitioninfo"+e.getMessage());
						} catch (NoSuchAlgorithmException e) {
							// TODO Auto-generated catch block
							logger.error("Error occured during restClient call for partitioninfo"+e.getMessage());
						}
						JSONObject jsonObject=new JSONObject(response.getBody());
						partitionData=validatePartitionInformationModel(jsonObject);
						 if(partitionData!=null) {
							 PartitionData data=partitionDataRepository.getPartitionData(String.valueOf(partitionDetailModel.getPartitionId()));
							 if(data!=null && data.getId()!=null && data.getId() > 0) {
								 partitionDataRepository.deletePartitionData(partitionDetailModel.getPartitionId());
							 }
							 partitionData.setPartitionId(Integer.valueOf(String.valueOf(partitionDetailModel.getPartitionId())));
							 partitionDataRepository.save(partitionData);
							 recentActivityServiceImpl.createRecentActivity(partitionDetailModel.getCreatedBy(), "Partition "+partitionDetailModel.getPartitionName()+" created for appliance "+partitionDetailModel.getApplianceDetailModel().getApplianceName()+" by "+partitionDetailModel.getCreatedBy(),CaviumConstant.PARTITION_MANAGEMENT);
							 if(partitionDetailModel!=null && partitionDetailModel.getPartitionId()!=0) {
								 PartitionDetailModel pd=partitionRepository.findOne(partitionDetailModel.getPartitionId());
								 pd.setErrorMessage("");
								 pd.setLastOperationPerformed("");
								 pd.setLastOperationStatus("");
								 pd.setStatus("Completed");
								 partitionRepository.save(pd);
							 }
						 }
					}
					try {
						 responseNetworkStat=restClient.invokeGETMethod("https://"+partitionDetailModel.getApplianceDetailModel().getIpAddress()+"/liquidsa/partition_network_stats/"+partitionDetailModel.getPartitionName()+"");
					 if(responseNetworkStat!=null && responseNetworkStat.getStatusCode().name().equals("OK")) {
							ObjectMapper mapperNetworkStat = new ObjectMapper();
							if(responseNetworkStat.getBody()!=null){
								JsonNode root = mapperNetworkStat.readTree(responseNetworkStat.getBody());
								if(!root.isNull()){
									 PartitionETH eth0=null;
									 PartitionETH eth1=null;
									String status = root.path("status").asText();
									JsonNode dataNode = root.path("data");
									if(status.equals("success")){
									if(!dataNode.isNull()){
										if(dataNode.has("general")){
											JsonNode generalNode = dataNode.path("general");	
											if(!generalNode.isNull()){
												if(generalNode.has("eth1")){
												eth1= new PartitionETH();
												eth1.setEthName("eth1");
												JsonNode eth1Node = generalNode.path("eth1");
												String subnet=eth1Node.path("subnet").asText();
												String hostname=eth1Node.path("hostname").asText();													 
												String vlan=eth1Node.path("vlan").asText();											
												String vlanStatus=eth1Node.path("vlanStatus").asText();	
												String ip=eth1Node.path("ip").asText();
												if(!"127.0.0.1".equalsIgnoreCase(ip)){
													eth1.setDisableEth1(false);	
												}
												else{
													eth1.setDisableEth1(true);	
												}
												if(eth1Node.hasNonNull("dhcp")){
												boolean dhcp=eth1Node.path("dhcp").asBoolean();
												if(!dhcp){
														eth1.setDhcp(true);
												 }
												}
												else{
													eth1.setDhcp(false);
												}
												String gateway=eth1Node.path("gateway").asText();
												String macAddress=eth1Node.path("mac").asText();
												Boolean staticMac= eth1Node.path("macStatic").asBoolean();
												eth1.setSubnet(subnet);
												eth1.setHostname(hostname);
												if(vlan!=null && !vlan.equalsIgnoreCase("")){
													eth1.setVlan(Integer.valueOf(vlan));		
													}												
												eth1.setIp(ip);				
												eth1.setGateway(gateway);
												eth1.setAddress(macAddress);
												eth1.setStaticMac(staticMac);
											 }
												if(generalNode.has("eth0")){
													 eth0=new PartitionETH();
													 eth0.setEthName("eth0");
													JsonNode eth0Node = generalNode.path("eth0");
													String subnet=eth0Node.path("subnet").asText();
													String hostname=eth0Node.path("hostname").asText();
													String vlan=eth0Node.path("vlan").asText();																 
													String ip=eth0Node.path("ip").asText();													 
													Boolean dhcp=eth0Node.path("dhcp").asBoolean();
													String gateway=eth0Node.path("gateway").asText();	
													String macAddress=eth0Node.path("mac").asText();
													Boolean staticMac= eth0Node.path("macStatic").asBoolean();
													eth0.setStaticMac(staticMac);
													eth0.setSubnet(subnet);
													eth0.setHostname(hostname);
													if(vlan!=null && !vlan.equalsIgnoreCase("")){
													eth0.setVlan(Integer.valueOf(vlan));		
													}
													eth0.setIp(ip);
													eth0.setDhcp(dhcp);
													eth0.setGateway(gateway);
													eth0.setAddress(macAddress);
												 }
										
								}
				}
									
											
											 }
											 List<PartitionETH> ethlist=partitionETHRepository.getPartitionETHList(String.valueOf(partitionDetailModel.getPartitionId()));
											 if(ethlist!=null && ethlist.size() > 0) {
									    			for(PartitionETH eth:ethlist) {
									    				if(!StringUtils.isEmpty(eth.getEthName()) && eth.getEthName().equals("eth0")) {
									    					eth0=setEditDataForNetworkConfig(eth0, eth);
									    				}if(!StringUtils.isEmpty(eth.getEthName()) && eth.getEthName().equals("eth1")) {
									    					eth1=setEditDataForNetworkConfig(eth1, eth);
									    				}
									    			}
											 } 
											 }
											 if(eth0!=null && eth1!=null){
											 eth0.setPartitionDetailModel(partitionDetailModel);
											 eth1.setPartitionDetailModel(partitionDetailModel);
											 try{
											 partitionETHRepository.save(eth0);
											 partitionETHRepository.save(eth1);
											 /**
												 * Saving ETH0 and ETH1	
												 */if(partitionDetailModel.getNetworkStats()!=null){
													 if(partitionDetailModel.getNetworkStats().getGeneral()!=null){
												   partitionDetailModel.getNetworkStats().getGeneral().setEth0(eth0);
												   partitionDetailModel.getNetworkStats().getGeneral().setEth1(eth1);
													 }
													 partitionDetailModel.setErrorMessage("");
													 partitionDetailModel.setLastOperationPerformed("");
													 partitionDetailModel.setLastOperationStatus("");
													 partitionDetailModel.setStatus("Completed");
													 partitionRepository.save(partitionDetailModel);
												 }
											 }catch (Exception e) {
												 logger.error("Error occured while saving network Data for partition in DB :: "+e.getMessage());
											}
											 }
										
								}
					 
					 
							
					 } 
							}
					 }catch (KeyManagementException e) {
							// TODO Auto-generated catch block
							logger.error("Error occured during restClient call for partitioninfo"+e.getMessage());
						} catch (KeyStoreException e) {
							// TODO Auto-generated catch block
							logger.error("Error occured during restClient call for partitioninfo"+e.getMessage());
						} catch (NoSuchAlgorithmException e) {
							// TODO Auto-generated catch block
							logger.error("Error occured during restClient call for partitioninfo"+e.getMessage());
						}catch (Exception e) {
							logger.error("Error occured during restClient call for partitioninfo"+e.getMessage());
						}
					logger.info("Asynchronous task completed successfully..");
				}
			}).start();
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during method getPartitionInformationModel in class PartitionServiceImpl "+e.getMessage());
		}
	}
	
	public PartitionData validatePartitionInformationModel(JSONObject object) {
		PartitionData partitionInformationModel=new PartitionData();
			try {
				if (object != null && object.get("status").equals("success")) {
					Iterator<String> iterator = object.keys();
					while (iterator.hasNext()) {
						String key = iterator.next();
						Object o = object.get(key);
						if (key.equals("data")) {
							if(o!=null){
							JSONObject data = (JSONObject) o;
							//JSONObject partitions = (JSONObject) data.get("partitions");
							data.put("mValueCloning", data.get("mValue[cloning]"));
							data.put("mValueMiscCO", data.get("mValue[miscCO]"));
							data.put("mValueBackupByCO", data.get("mValue[backupByCO]"));
							data.put("mValueUserMgmt", data.get("mValue[userMgmt]"));
							data.put("exportWithUserKeysOtherThanKEK", data.get("exportWithUserKeys(OtherThanKEK)"));
							data.remove("mValue[cloning]");
							data.remove("mValue[miscCO]");
							data.remove("mValue[backupByCO]");
							data.remove("mValue[userMgmt]");
							data.remove("exportWithUserKeys(OtherThanKEK)");
							ObjectMapper objectMapper = new ObjectMapper();
							try {
								partitionInformationModel=objectMapper.readValue(data.toString(),PartitionData.class);
							} catch (Exception e) {
								logger.error("Error occured during"+e.getMessage());
								// TODO: handle exception
							}
						
							return partitionInformationModel;
						}
						}
						if (o == null || o == JSONObject.NULL) {
							iterator.remove();
						}
					}
				}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during method validatePartitionInformationModel in class PartitionServiceImpl "+e.getMessage());
		}
		return partitionInformationModel;
	}
	
	@Override
	public PartitionDetailModel getPartitionInfo(PartitionDetailModel partitionDetailModel) {
		// TODO Auto-generated method stub
		ResponseEntity<String> response = null;
		PartitionDetailModel  partitionDetailModels=partitionRepository.findOne(partitionDetailModel.getPartitionId());
		String loggedInUser = userAttributes.getlogInUserName();
		try {
			response = restClient
					.invokeGETMethod("https://" + partitionDetailModels.getApplianceDetailModel().getIpAddress()
							+ "/liquidsa/partition/" + partitionDetailModels.getPartitionName() + "");
			
			if (response != null && response.getBody() != null && response.getBody().contains("success")) {
				ObjectMapper mapper = new ObjectMapper();
				JsonNode root = mapper.readTree(response.getBody());
				JsonNode data=root.path("data");
				partitionDetailModel.setCode("200");
				partitionDetailModel.setMessage(data.toString());
				
			} else {
					partitionDetailModel =getErrorMessage(response, partitionDetailModel, loggedInUser, "Partition Info");
			}
			if (response != null && response.getStatusCodeValue() == 404) {
				String error=env.getProperty("partition.notexists.cavium.network");
				partitionDetailModel.setCode("408");
				partitionDetailModel.setMessage(error);
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during method getPartitionInfo in class PartitionServiceImpl "+e.getMessage());
		}
		return partitionDetailModel;
	}

	@Override
	public PartitionDetailModel getPartitionStatsInfo(PartitionDetailModel partitionDetailModel) {
		// TODO Auto-generated method stub
		ResponseEntity<String> response=null;
		PartitionDetailModel  partitionDetailModels=partitionRepository.findOne(partitionDetailModel.getPartitionId());
		String loggedInUser = userAttributes.getlogInUserName();
		try {
			response=restClient.invokeGETMethod("https://"+partitionDetailModels.getApplianceDetailModel().getIpAddress()+"/liquidsa/partition_stats/"+partitionDetailModels.getPartitionName()+"");
			if (response != null && response.getBody() != null && response.getBody().contains("success")) {
				ObjectMapper mapper = new ObjectMapper();
				JsonNode root = mapper.readTree(response.getBody());
				JsonNode data=root.path("data");
				partitionDetailModel.setCode("200");
				partitionDetailModel.setMessage(data.toString());
				
			} else {
					partitionDetailModel =getErrorMessage(response, partitionDetailModel, loggedInUser, "Stats");
			}
			if (response != null && response.getStatusCodeValue() == 404) {
				String error=env.getProperty("partition.notexists.cavium.network");
				partitionDetailModel.setCode("408");
				partitionDetailModel.setMessage(error);
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during method getPartitionStatsInfo in class PartitionServiceImpl "+e.getMessage());
		}
		return partitionDetailModel;
	}

	@Override
	public PartitionDetailModel getPartitionNetworkStatsInfo(PartitionDetailModel partitionDetailModel) {
		// TODO Auto-generated method stub
		ResponseEntity<String> response=null;
		String loggedInUser = userAttributes.getlogInUserName();
		try {
			if(partitionDetailModel.getPartitionId()!=null){
				  partitionDetailModel=partitionRepository.findOne(partitionDetailModel.getPartitionId());
				}
			response=restClient.invokeGETMethod("https://"+partitionDetailModel.getApplianceDetailModel().getIpAddress()+"/liquidsa/partition_network_stats/"+partitionDetailModel.getPartitionName()+"");
			if (response != null && response.getBody() != null && response.getBody().contains("success")) {
				ObjectMapper mapper = new ObjectMapper();
				JsonNode root = mapper.readTree(response.getBody());
				JsonNode data=root.path("data");
				partitionDetailModel.setCode("200");
				partitionDetailModel.setMessage(data.toString());
				
			} else {
				partitionDetailModel =getErrorMessage(response, partitionDetailModel, loggedInUser, "Network Stats");
			}
			if (response != null && response.getStatusCodeValue() == 404) {
				String error=env.getProperty("partition.notexists.cavium.network");
				partitionDetailModel.setCode("408");
				partitionDetailModel.setMessage(error);
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getPartitionNetworkStatsInfo from class PartitionServiceIMPL"+e.getMessage());
		}
		return partitionDetailModel;
	}

	@Override
	public List<PartitionDetailModel> resetPartition(String loggedInUser, List<PartitionDetailModel> partitionDetailModels) {
		// TODO Auto-generated method stub
		List<PartitionDetailModel> partitionList=new ArrayList<>();
		boolean isSessionCloseFailed = false;
		try {
			for(PartitionDetailModel pdmobj:partitionDetailModels) {
				ResponseEntity<String> response=null;
				PartitionDetailModel pdm=partitionRepository.findOne(pdmobj.getPartitionId());
				if(pdm!=null && pdm.getPartitionId() > 0 && pdmobj.getApplianceDetailModel()!=null) {
					ApplianceDetailModel app=pdm.getApplianceDetailModel();
					ApplianceDetailModel dbAppliance=applianceRepository.findOne(app.getApplianceId()); 
					if(dbAppliance!=null) {
						JSONObject jsonObject =new JSONObject();
						jsonObject=getUserNamePassword(pdmobj,jsonObject);
						
							if(pdmobj.isSessionClose()) {
								jsonObject.put("action", "close_session");
								ResponseEntity<String>	closeSessionresponse=restClient.invokePUTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/partition/"+pdmobj.getPartitionName()+"",jsonObject);
								if(closeSessionresponse!=null && closeSessionresponse.getBody()!=null) {
									ObjectMapper mapper = new ObjectMapper();
									JsonNode root = mapper.readTree(closeSessionresponse.getBody());
									Thread.sleep(15000);
									pdm=getStatusFromJobId(pdm, root, loggedInUser, "Session Close");
									if(pdm.getMessage()!=null && pdm.getStatus().equalsIgnoreCase("Completed")) {
										jsonObject.remove("action");
										jsonObject.put("action", "reset");
										response=restClient.invokePUTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/partition/"+pdmobj.getPartitionName()+"",jsonObject);
										isSessionCloseFailed=false;
									}else {
										isSessionCloseFailed=true;
										pdm.setMessage("Failed");
										pdm.setErrorMessage("Reset Partition failed due to close session");
										pdm.setLastOperationPerformed("Reset Partition");
										pdm.setLastOperationStatus("Failed");
										pdm.setCode("11032");
										partitionRepository.save(pdm);
									}
								}
							}else {
								jsonObject.put("action", "reset");
								response=restClient.invokePUTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/partition/"+pdmobj.getPartitionName()+"",jsonObject);
								isSessionCloseFailed=false;
							}
						
						if(response!=null && response.getBody()!=null && isSessionCloseFailed==false && response.getBody().contains("success")) {
								pdm.setMessage("Reset Partition is Initiated successfully for "+pdmobj.getPartitionName()+"");
								pdm.setErrorMessage("");
								pdm.setLastOperationPerformed("Reset Partition");
								pdm.setLastOperationStatus("In-Progress");
								pdm.setCode("200");
									ObjectMapper mapper = new ObjectMapper();
									JsonNode root = mapper.readTree(response.getBody());
									if (!root.isNull()) {
										updateInProgressActivity(pdm, loggedInUser, root);
									}
									partitionRepository.save(pdm);
								{
								if(isSessionCloseFailed==false) {
								pdm=getErrorMessage(response, pdm,loggedInUser,"Reset Partition");
								partitionRepository.save(pdm);
								}
							}
						}else {
							if(isSessionCloseFailed==false) {
							pdm=getErrorMessage(response, pdm,loggedInUser,"Reset Partition");
							partitionRepository.save(pdm);
							}
						}
					}
				}
				partitionList.add(pdm);
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during partition delete in method resetPartition of class PartitionServiceImpl "+e.getMessage());
		}
		return partitionList;
	}
	
	private void updateInProgressActivity(PartitionDetailModel partitionDetailModels,String loggedInUser, JsonNode root) {
		try {
			InProgressActivity activity = new InProgressActivity();
			activity.setCreatedBy(loggedInUser);
			activity.setIpAddress(partitionDetailModels.getApplianceDetailModel().getIpAddress());
			Integer jobId = 0;
			if (!root.path("jobId").isNull()) {
			jobId = root.path("jobId").asInt();
			} else {
			jobId = 000;
			}
			activity.setJobId(jobId);
			activity.setModuleName(CaviumConstant.PARTITION_MANAGEMENT);
			activity.setOperationName(root.path("operation").asText());
			activity.setStatus("In-Progress");
			activity.setPartitionId(partitionDetailModels.getPartitionId());
			if(partitionDetailModels.getApplianceDetailModel()!=null && !StringUtils.isEmpty(partitionDetailModels.getApplianceDetailModel().getApplianceName())) {
				activity.setApplianceName(partitionDetailModels.getApplianceDetailModel().getApplianceName());
			}
			activity.setPartitionName(partitionDetailModels.getPartitionName());
			inProgressActivityService.createInProgressActivity(activity);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during updateInProgressActivity"+e.getMessage());
		}
	}
	
	
	@Override
	public List<PartitionDetailModel> closeSessionForPartition(List<PartitionDetailModel> partitionDetailModels) {
		// TODO Auto-generated method stub
		List<PartitionDetailModel> listPartition=new ArrayList<>();
		try {
			for(PartitionDetailModel pdmobj: partitionDetailModels) {
				String loggedInUser = userAttributes.getlogInUserName(); 
				ResponseEntity<String> closeSessionresponse=null;
				PartitionDetailModel pdm=partitionRepository.findOne(pdmobj.getPartitionId());
				if(pdm!=null && pdm.getPartitionId() > 0 && pdmobj.getApplianceDetailModel()!=null) {
					ApplianceDetailModel app=pdmobj.getApplianceDetailModel();
					ApplianceDetailModel dbAppliance=applianceRepository.findOne(app.getApplianceId()); 
					if(dbAppliance!=null) {
							JSONObject jsonObject =new JSONObject();
							 jsonObject=getUserNamePassword(pdmobj,jsonObject);
							jsonObject.put("action", "close_session");
							closeSessionresponse=restClient.invokePUTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/partition/"+pdmobj.getPartitionName()+"",jsonObject);
						if(closeSessionresponse!=null && closeSessionresponse.getBody()!=null) {
							if(closeSessionresponse.getBody().contains("success")) {
								pdm.setMessage("Session close is Initiated successfully for "+pdmobj.getPartitionName()+"");
								pdm.setErrorMessage("");
								pdm.setLastOperationPerformed("Session Close");
								pdm.setLastOperationStatus("In-Progress");
								pdm.setCode("200");
								if (closeSessionresponse != null && closeSessionresponse.getBody() != null) {
									ObjectMapper mapper = new ObjectMapper();
									JsonNode root = mapper.readTree(closeSessionresponse.getBody());
									if (!root.isNull()) {
										updateInProgressActivity(pdmobj, loggedInUser, root);
									}
								}
								partitionRepository.save(pdm);
							}else {
								pdm=getErrorMessage(closeSessionresponse, pdm,loggedInUser,"Session Close");
								partitionRepository.save(pdm);
							}
						}else {
							pdm=getErrorMessage(closeSessionresponse, pdm,loggedInUser,"Session Close");
							partitionRepository.save(pdm);
						}
					}
				}
				listPartition.add(pdm);
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during partition delete in method closeSessionForPartition of class PartitionServiceImpl "+e.getMessage());
		}
		return listPartition;
	}
	
	/**
	 * This method is used for error handling for partition management
	 * @param partitionDetailModel
	 * @param root
	 * @return
	 */
	public PartitionDetailModel getErrorMessage(ResponseEntity<String> response,PartitionDetailModel partitionDetailModel,String loggedInUser,String type) {
		try {
			if(response==null) {
				partitionDetailModel.setCode("409");
				partitionDetailModel.setLastOperationPerformed(type);
				partitionDetailModel.setLastOperationStatus("Failed");
				partitionDetailModel.setMessage("");
				partitionDetailModel.setErrorMessage(env.getProperty("partition.applainceinternalerror.cavium"));
				if(!CaviumConstant.CREATE_CLUSTER.equalsIgnoreCase(type))
				alertsService.createAlert(loggedInUser,"Device "+partitionDetailModel.getApplianceDetailModel().getApplianceName()+"  try to perofrm "+type+" by "+loggedInUser+" does not "+type+" due to appliance internal error",partitionDetailModel.getPartitionName(),partitionDetailModel.getPartitionId(),CaviumConstant.PARTITION_MANAGEMENT);
				return partitionDetailModel;
			}
			
			if(response!=null && response.getStatusCodeValue()== 408){
				partitionDetailModel.setCode("408");
				partitionDetailModel.setLastOperationPerformed(type);
				partitionDetailModel.setLastOperationStatus("Failed");
				partitionDetailModel.setErrorMessage(env.getProperty("partition.connectionerror.cavium"));
				partitionDetailModel.setMessage("");
				if(!CaviumConstant.CREATE_CLUSTER.equalsIgnoreCase(type))
				alertsService.createAlert(loggedInUser,"Device "+partitionDetailModel.getApplianceDetailModel().getApplianceName()+"  try to perofrm "+type+" by "+loggedInUser+" does not "+type+" due to connection issue.",partitionDetailModel.getPartitionName(),partitionDetailModel.getPartitionId(),CaviumConstant.PARTITION_MANAGEMENT);
				return partitionDetailModel;
			}
			
			if(response.getBody()!=null) {
				ObjectMapper mapper = new ObjectMapper();
				JsonNode root = mapper.readTree(response.getBody());
				JsonNode errors = root.path("errors");
				if(root!=null){
					if(!root.isNull()) {
						if(response.getBody().contains("busy")) {
							String operation = root.path("operation").asText();
							if(!StringUtils.isEmpty(operation) && operation.equalsIgnoreCase("CreatePartition")) {
								String partitionName = root.path("partitionName").asText();
								partitionDetailModel.setErrorMessage("Appliance is busy due to operation "+operation+" is being performed on partition "+partitionName+"");
							}else {
								String partitionName ="";
								if(root.has("partitionName")) {
									partitionName = root.path("partitionName").asText();
								}
								partitionDetailModel.setErrorMessage("Appliance is busy due to operation "+operation+" is being performed on partition "+partitionName+"");
							}
							partitionDetailModel.setCode("409");
							if(!CaviumConstant.CREATE_CLUSTER.equalsIgnoreCase(type))
							alertsService.createAlert(loggedInUser,"Device "+partitionDetailModel.getApplianceDetailModel().getApplianceName()+"  try to perofrm "+type+" by "+loggedInUser+" does not "+type+"  due to operation "+operation+" is already in progress.",partitionDetailModel.getPartitionName(),partitionDetailModel.getPartitionId(),CaviumConstant.PARTITION_MANAGEMENT);
							return partitionDetailModel;
						}
						if(response.getBody().contains("errors")) {
							
							if(!errors.isNull() && errors.size() > 0){
								String operation = root.path("operation").asText();
								logger.info("Error size"+errors.size()+" is Array"+errors.isArray());
								StringBuilder sbmessage=new StringBuilder();
								StringBuilder sbcode=new StringBuilder();
								 Iterator<JsonNode> itr = errors.elements();	
						            while (itr.hasNext()) {
						                JsonNode temp = itr.next();
						                sbcode.append(""+temp.asInt()+"");
						                if(env.containsProperty(""+temp.asInt()+"")) {
						                	 sbmessage.append(env.getProperty(""+temp.asInt()+""));
						                }else {
						                	 sbmessage.append("Error message not available");
						                }
						                sbcode.append(",");
						                sbmessage.append(",");
						            }
						            String message=sbmessage.toString();
						            message=message.substring(0, message.length()-1);
						            message=message+".";
						            String code=sbcode.toString();
						            code=code.substring(0, code.length()-1);
						            code=code+".";
						            partitionDetailModel.setCode(code);
									partitionDetailModel.setErrorMessage(message);
									partitionDetailModel.setLastOperationPerformed(operation);
									partitionDetailModel.setLastOperationStatus("Failed");
									partitionDetailModel.setMessage("");
									if(!CaviumConstant.CREATE_CLUSTER.equalsIgnoreCase(type))
									alertsService.createAlert(loggedInUser,""+type+" failed due to "+message+" on Device "+partitionDetailModel.getApplianceDetailModel().getApplianceName()+"  by "+loggedInUser+".",partitionDetailModel.getPartitionName(),partitionDetailModel.getPartitionId(),CaviumConstant.PARTITION_MANAGEMENT);
							} else {
								String encodeMessage = "";
								if (errors.size() == 0) {
									encodeMessage = root.path("message").asText();
									encodeMessage = CaviumUtil.decodeMessageBase64(encodeMessage);
									partitionDetailModel.setCode("");
									partitionDetailModel.setErrorMessage(encodeMessage);
									partitionDetailModel.setMessage("");
								}else {
									partitionDetailModel.setCode("");
									partitionDetailModel.setErrorMessage("No message found");
									partitionDetailModel.setMessage("");
								}
							}
						}
					}
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured while setting error code and message..");
		}
		return partitionDetailModel;
	}
	
	@Override
	public List<PartitionData> getAllPartitionsDetails(ApplianceDetailModel applianceDetailModel) {
		logger.info("Start of  getAllPartitionsDetails method");
		List<PartitionData> partitionDataList= new ArrayList<PartitionData>();
		try {			 
			ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/partitions");
			if(response!=null && response.getStatusCode().name().equals("OK")) {
			  if(response.getBody()!=null){
					JSONObject jsonObject=new JSONObject(response.getBody());
					if (jsonObject != null) {
						Iterator<String> iterator = jsonObject.keys();
						while (iterator.hasNext()) {
							String key = iterator.next();
							Object o = jsonObject.get(key);
							if (key.equals("data")) {
								JSONObject dataObj = (JSONObject) o;
								Iterator<String> dataIterator =dataObj.keys();
								 while (dataIterator.hasNext()) {
								 String datakey = dataIterator.next();
									 if(datakey.equals("partitions")){
										 JSONArray dataArray  =(JSONArray) dataObj.get(datakey);
								 
								for (int i = 0; i < dataArray.length(); i++) {
									PartitionData partitionInformationModel=new PartitionData();	
									
									   JSONObject data = dataArray.getJSONObject(i);
									data.put("mValueCloning", data.get("mValue[cloning]"));						
									data.put("mValueMiscCO", data.get("mValue[miscCO]"));
									data.put("mValueBackupByCO", data.get("mValue[backupByCO]"));
									data.put("mValueUserMgmt", data.get("mValue[userMgmt]"));
									data.put("exportWithUserKeysOtherThanKEK", data.get("exportWithUserKeys(OtherThanKEK)"));
									data.remove("mValue[cloning]");
									data.remove("mValue[miscCO]");
									data.remove("mValue[backupByCO]");
									data.remove("mValue[userMgmt]");
									data.remove("exportWithUserKeys(OtherThanKEK)");
									ObjectMapper objectMapper = new ObjectMapper();
									try {
										if(data.has("cavServerStatus")){
											if(!data.isNull("cavServerStatus"))
											{
												
											}else{
												data.put("cavServerStatus",0);
											}
										}
										else{
											data.put("cavServerStatus",0);
										}
										partitionInformationModel=objectMapper.readValue(data.toString(),PartitionData.class);
										partitionDataList.add(partitionInformationModel);
									} catch (Exception e) {
										logger.error("Error occured during convert Json to Partition Data in getAllPartitionsDetails method ::"+e.getMessage());								 
									}	 

								}
							}
						}
						}
					}
				}
			  }

		}
		}
		catch (Exception e) {
			logger.error("Error occured during fetch  resource usag into getPartitionInfo of class PartitionServiceImpl ::" + e.getMessage());		 
		}
		logger.info("End of  getAllPartitionsDetails method");
		return partitionDataList;
	}
	
	@Override
	public List<PartitionDetailModel> setNetworkConfiguration(String loggedInUser, List<PartitionDetailModel> partitionDetailModels) {
		// TODO Auto-generated method stub
		List<PartitionDetailModel> responseList=new ArrayList<>();
		try {
			boolean sessionFailed=false;
			for(PartitionDetailModel pdm: partitionDetailModels) {
				if(pdm.isSessionClose()) {
					 JSONObject jsonObject=new JSONObject();
					 jsonObject=getUserNamePassword(pdm, jsonObject);
					 jsonObject.put("action", "close_session");
					 pdm=closeSession(pdm, "Network Configuration", jsonObject);
					 if(!StringUtils.isEmpty(pdm.getErrorMessage()) && !StringUtils.isEmpty(pdm.getCode()) && !pdm.getCode().equalsIgnoreCase("200")) {
						 sessionFailed=true;
					 }
				}
				if(sessionFailed==false || pdm.isSessionClose()==false) {
					ResponseEntity<String> response=setPartitionNetworksConfigurationOnExtenalAPI(pdm);
					PartitionDetailModel pdmdb=partitionRepository.findOne(pdm.getPartitionId());
					if(response!=null && response.getBody()!=null && response.getBody().contains("success")) {
						/**
						 * Saving network data into db
						 */
						saveNetworkConfigData(pdm, response, loggedInUser);
						
						/**
						 * Updating success details into partition model
						 */
						pdmdb.setStatus("In-Progress");
						pdmdb.setMessage("Netowk configuration Initiated successfully for "+pdm.getPartitionName()+"");
						pdmdb.setCode("200");
						pdmdb.setLastOperationPerformed("Network Configuration");
						pdmdb.setLastOperationStatus("In-Progress");
						pdmdb.setErrorMessage("");
						pdmdb.setModifiedBy(loggedInUser);
						pdmdb.setModifiedDate(new Date());
						partitionRepository.save(pdmdb);
						
						/**
						 * Update In-progress activity
						 */
							ObjectMapper mapper = new ObjectMapper();
							JsonNode root = mapper.readTree(response.getBody());
							if(root!=null){
								
							getPartitionInformationModel(pdmdb);
							
							updateInProgressActivity(pdmdb, loggedInUser, root);
							}
						
						/**
						 * setting object to return with appropriate messages	
						 */
						pdmdb.setNetworkStats(pdm.getNetworkStats());
						responseList.add(pdmdb);
						
					}else {
							/**
							 * Getting errors to return
							 */
							pdmdb=getErrorMessage(response,pdmdb,loggedInUser,"Network Configuration");
							pdmdb=partitionRepository.save(pdmdb);
							
							/**
							 * setting object to return with appropriate error messages	
							 */
							pdmdb.setNetworkStats(pdm.getNetworkStats());
							responseList.add(pdmdb);
					}
				}else {
					responseList.add(pdm);
				}
			
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during setNetworkConfiguration in class PartitionServiceIMPL"+e.getMessage());
		}
		return responseList;
	}
	
	/**
	 * 
	 * @param partitionDetailModels
	 * @return
	 */
	private ResponseEntity<String> setPartitionNetworksConfigurationOnExtenalAPI(PartitionDetailModel partitionDetailModels) {
		ResponseEntity<String> response=null;
		boolean initialized=false;
		try {
			partitionDetailModels.setIpAddress(null);
			ApplianceDetailModel app=partitionDetailModels.getApplianceDetailModel();
			ApplianceDetailModel dbAppliance=applianceRepository.findOne(app.getApplianceId()); 
			PartitionDetailModel networkConfig=new PartitionDetailModel();
			if(partitionDetailModels.getNetworkStats()!=null) {
				networkConfig.setNetworkStats(partitionDetailModels.getNetworkStats());
				String[] dnsServers=partitionDetailModels.getNetworkStats().getAdvanced().getDnsConfig().getDnsServers();
				dnsServers=removeNullfromArray(dnsServers);
				partitionDetailModels.getNetworkStats().getAdvanced().getDnsConfig().setDnsServers(dnsServers);
				String[] searchDomainNames=partitionDetailModels.getNetworkStats().getAdvanced().getDnsConfig().getSearchDomainNames();
				searchDomainNames=removeNullfromArray(searchDomainNames);
				partitionDetailModels.getNetworkStats().getAdvanced().getDnsConfig().setSearchDomainNames(searchDomainNames);
			}
			JSONObject jsonObject=new JSONObject(networkConfig);
			jsonObject=removeNullsAndKeysFrom(jsonObject,"networkconfig");
								
			if(app!=null){
				initialized=dbAppliance.isApplianceinitialized();
			}
				long applianceId=app.getApplianceId();
				InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(applianceId);
				if(initmodel!=null || initialized) {
					jsonObject=getUserNamePassword(partitionDetailModels,jsonObject);
					response=restClient.invokePUTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/partition_network_stats/"+partitionDetailModels.getPartitionName()+"",jsonObject);
				}else {
					response=new ResponseEntity<>(HttpStatus.valueOf(env.getProperty("partition.initializenotdone")));
					}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during method createPartitionViaCaviumExtenalAPI in class PartitionServiceImpl "+e.getMessage());
		}
		return response;
	}
	
	/***
	 * 
	 * @param partitionDetailModels
	 * @param response
	 * @param loggedInUser
	 * @return
	 */
	private void saveNetworkConfigData(PartitionDetailModel partitionDetailModels,ResponseEntity<String> response,String loggedInUser) {
		
					/**
					 * Saving partition
					 */
					PartitionDetailModel dbpartmodel=partitionRepository.findOne(partitionDetailModels.getPartitionId());
					try {
						
						if(partitionDetailModels!=null && partitionDetailModels.getPartitionId() > 0) {
							/**
							 * Saving ETH0 and ETH1	
							 */
							 PartitionETH eth0=partitionDetailModels.getNetworkStats().getGeneral().getEth0();
							 PartitionETH eth1=partitionDetailModels.getNetworkStats().getGeneral().getEth1();
							 
							 List<PartitionETH> ethlist=partitionETHRepository.getPartitionETHList(String.valueOf(dbpartmodel.getPartitionId()));
							 if(ethlist!=null && ethlist.size() > 0) {
					    			for(PartitionETH eth:ethlist) {
					    				if(!StringUtils.isEmpty(eth.getEthName()) && eth.getEthName().equals("eth0")) {
					    					eth0=setEditDataForNetworkConfig(eth0, eth);
					    				}if(!StringUtils.isEmpty(eth.getEthName()) && eth.getEthName().equals("eth1")) {
					    					eth1=setEditDataForNetworkConfig(eth1, eth);
					    				}
					    			}
							 }else {
								 eth0.setEthName("eth0");
								 eth1.setEthName("eth1");
								 eth0.setPartitionDetailModel(dbpartmodel);
								 eth1.setPartitionDetailModel(dbpartmodel);
							 }
							 partitionETHRepository.save(eth0);
							 partitionETHRepository.save(eth1);
							 
							 								 
							 /**
							  * Save partition_inetrface_advance_static_host_ip
							  */
							 List<PartitionAdvanceStaticHostIps> StaticHostIps=partitionDetailModels.getNetworkStats().getAdvanced().getStaticIpToHostConfig().getAdd();
							 if(StaticHostIps!=null && StaticHostIps.size() > 0) {
								 List<PartitionAdvanceStaticHostIps> staticipHost=advanceStaticHostIpsRepository.getStaticIpHostList(String.valueOf(dbpartmodel.getPartitionId()));
								 if(staticipHost!=null && staticipHost.size() > 0) {
									 advanceStaticHostIpsRepository.deletePartitionAdvanceStaticHostIps(dbpartmodel.getPartitionId());
								 }
								 if(StaticHostIps!=null && StaticHostIps.size() > 0) {
									 for(PartitionAdvanceStaticHostIps ips : StaticHostIps) {
										 ips.setPartitionDetailModel(dbpartmodel);
									 }
									 advanceStaticHostIpsRepository.save(StaticHostIps); 
								 }
							 }
							 
							 /**
							  * Save partition_inetrface_advance_dns_servers
							  */
							 List<PartitionAdvanceDNSServers> listDNSServers=new ArrayList<PartitionAdvanceDNSServers>();
							 String[] dnsServers=partitionDetailModels.getNetworkStats().getAdvanced().getDnsConfig().getDnsServers();
							 if(dnsServers!=null && dnsServers.length > 0) {
								 List<PartitionAdvanceDNSServers> dbdnsServers=advanceDNSServersRepository.getDNSServersList(String.valueOf(dbpartmodel.getPartitionId()));
								 if(dbdnsServers!=null && dbdnsServers.size() > 0) {
									 advanceDNSServersRepository.deletePartitionAdvanceDNSServers(dbpartmodel.getPartitionId());
								 }
								 if(listDNSServers!=null && dnsServers.length > 0) {
									 for(String dns : dnsServers) {
										 PartitionAdvanceDNSServers dnsser=new PartitionAdvanceDNSServers();
										 dnsser.setDnsAddress(dns);
										 dnsser.setPartitionDetailModel(dbpartmodel);
										 listDNSServers.add(dnsser);
									 }
									 advanceDNSServersRepository.save(listDNSServers);
								 }
								
							 }
							 
							 
							 /**
							  * Save partition_inetrface_advance_serach_domain_names
							  */
							 String[] domainNames= partitionDetailModels.getNetworkStats().getAdvanced().getDnsConfig().getSearchDomainNames();
							 List<PartitionAdvanceSearchDomainNames> listSerachDomains=new ArrayList<PartitionAdvanceSearchDomainNames>();;
							 List<PartitionAdvanceSearchDomainNames> dbdomainNames=advanceSearchDomainNamesRepository.getDomainNamesList(String.valueOf(dbpartmodel.getPartitionId()));
								 if(dbdomainNames!=null && dbdomainNames.size() > 0) {
									 advanceSearchDomainNamesRepository.deletePartitionAdvanceSearchDomainNames(dbpartmodel.getPartitionId());
								 }
								 if(domainNames!=null && domainNames.length > 0) {
								 for(String domainName : domainNames) {
									 PartitionAdvanceSearchDomainNames domain=new PartitionAdvanceSearchDomainNames();
									 domain.setDomainNames(domainName);
									 domain.setPartitionDetailModel(dbpartmodel);
									 listSerachDomains.add(domain);
								 }
								 advanceSearchDomainNamesRepository.save(listSerachDomains);
							  }
							}
						
					} catch (Exception e) {
						partitionDetailModels.setCode("408");
						partitionDetailModels.setErrorMessage(env.getProperty("partition.dberror"));
						// TODO: handle exception
					}
	}
	
	private PartitionDetailModel getStatusFromJobId(PartitionDetailModel pdm,JsonNode root,String loggedInUser,String type) {
		try {
			if (!root.isNull()) {
				if (!root.path("jobId").isNull()) {
					Integer jobId = root.path("jobId").asInt();
					ResponseEntity<String> res=restClient.invokeGETMethod("https://"+pdm.getApplianceDetailModel().getIpAddress()+"/liquidsa/notification/"+jobId+"");
					if(res!=null && res.getBody()!=null && res.getBody().contains("success")) {
						pdm.setErrorMessage("");
						pdm.setCode("200");
						pdm.setStatus("Completed");
						pdm.setMessage(""+type+" successfully completed");
						pdm.setLastOperationPerformed(type);
						pdm.setLastOperationStatus("Completed");
						partitionRepository.save(pdm);
					}else {
						if(res!=null && res.getBody()!=null && res.getBody().contains("error")) {
							ObjectMapper mapperr = new ObjectMapper();
							JsonNode roott = mapperr.readTree(res.getBody());
							JsonNode errors = roott.path("errors");
							if(!errors.isNull() && errors.size() > 0) {
								pdm=getErrorMessage(res, pdm,loggedInUser,type);
								pdm.setMessage("");
								}
							}
						}
					}else {
						String success=root.path("status").asText();
						if(root!=null && !StringUtils.isEmpty(success) && success.equalsIgnoreCase("success")) {
							pdm.setErrorMessage("");
							pdm.setCode("200");
							pdm.setStatus("Completed");
							pdm.setMessage(""+type+" successfully completed");
							pdm.setLastOperationPerformed(type);
							pdm.setLastOperationStatus("Completed");
							partitionRepository.save(pdm);
						}
					}
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error ocuured during getStatusFromJobId"+e.getMessage());
		}
		return pdm;
	}
	
	@Override
    public PartitionsDetails getPartitionInfo(ApplianceDetailModel applianceDetailModel, PartitionsDetails partitionsDetails) {

           try {
                  ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/partitions");
                  if(response!=null && response.getStatusCode().name().equals("OK")) {
                        ObjectMapper mapper = new ObjectMapper();
                        if(response.getBody()!=null){
                               JsonNode root = mapper.readTree(response.getBody());

                               
                               if(!root.isNull()){
                                      JSONObject jsonObject=new JSONObject(response.getBody());
                                      JsonNode dataNode = root.path("data");
                                      if(partitionsDetails==null)
                                      partitionsDetails= getPartitionsDetails();
                                      if(!dataNode.isNull()){
                                             Object o = jsonObject.get("data");
                                             JSONObject dataObj = (JSONObject) o;
                                             JSONArray dataArray  =(JSONArray) dataObj.get("partitions");
                                             List<PartitionData> partitionDataList= new ArrayList<PartitionData>();
                                             for (int i = 0; i < dataArray.length(); i++) {
                                                    PartitionData partitionData=new PartitionData();    
                                                    
                                                    JSONObject data = dataArray.getJSONObject(i);
                                                    data.put("mValueCloning", data.get("mValue[cloning]"));                                        
                                                    data.put("mValueMiscCO", data.get("mValue[miscCO]"));
                                                    data.put("mValueBackupByCO", data.get("mValue[backupByCO]"));
                                                    data.put("mValueUserMgmt", data.get("mValue[userMgmt]"));
                                                    data.put("exportWithUserKeysOtherThanKEK", data.get("exportWithUserKeys(OtherThanKEK)"));
                                                    data.remove("mValue[cloning]");
                                                    data.remove("mValue[miscCO]");
                                                    data.remove("mValue[backupByCO]");
                                                    data.remove("mValue[userMgmt]");
                                                    data.remove("exportWithUserKeys(OtherThanKEK)");
                                                    ObjectMapper objectMapper = new ObjectMapper();
                                                    try {
                                                           partitionData=objectMapper.readValue(data.toString(),PartitionData.class);
                                                           partitionDataList.add(partitionData);
                                                     } catch (Exception e) {
                                                           logger.error("Error occured during getting partitionData :: "+e.getMessage());                                                   
                                                    }      

                                             }
                                             partitionsDetails.setPartitionDataList(partitionDataList);
                                             if(dataNode.has("totalKeys")) {
                                                    int totalKeys = dataNode.path("totalKeys").asInt();
                                                    partitionsDetails.setTotalKeys(partitionsDetails.getTotalKeys()+totalKeys);
                                             }
                                             if(dataNode.has("occupiedKeys")){
                                                    int occupiedKeys = dataNode.path("occupiedKeys").asInt();
                                                    partitionsDetails.setOccupiedKeys(partitionsDetails.getOccupiedKeys()+occupiedKeys);
                                             }
                                             if(dataNode.has("totalAcclrDev")) {
                                                    int totalAcclrDev = dataNode.path("totalAcclrDev").asInt();
                                                    partitionsDetails.setTotalAcclrDev(partitionsDetails.getTotalAcclrDev()+ totalAcclrDev);
                                             }
                                             if(dataNode.has("occupiedAcclrDev")) {
                                                    int occupiedAcclrDev = dataNode.path("occupiedAcclrDev").asInt();
                                                    partitionsDetails.setOccupiedAcclrDev(partitionsDetails.getOccupiedAcclrDev()+ occupiedAcclrDev);
                                             }
                                             if(dataNode.has("totalContexts")){
                                                    int totalContexts = dataNode.path("totalContexts").asInt();
                                                    partitionsDetails.setTotalContexts(partitionsDetails.getTotalContexts()+totalContexts);
                                             }
                                             if(dataNode.has("occupiedContexts")){
                                                    int occupiedContexts = dataNode.path("occupiedContexts").asInt();
                                                    partitionsDetails.setOccupiedContexts(partitionsDetails.getOccupiedContexts()+ occupiedContexts);
                                             }
                                             if(dataNode.has("totalPartitions")) {
                                                 int totalpartitions = dataNode.path("totalPartitions").asInt();
                                                 partitionsDetails.setTotalPartitions(partitionsDetails.getTotalPartitions()+totalpartitions);
                                          }
                                             if(dataNode.has("occupiedPartitions")) {
                                                 int occupiedPartitions = dataNode.path("occupiedPartitions").asInt();
                                                 partitionsDetails.setOccupiedPartitions(partitionsDetails.getOccupiedPartitions()+occupiedPartitions);
                                          }
                                             
                                      }
                               } 
                        }
                  }
           } catch (Exception e) {
                  logger.error("Error occured during fetch  resource usag into getPartitionInfo of class PartitionServiceImpl ::" + e.getMessage());          
           }
           return partitionsDetails;
    }
	
	private JSONObject removeUnwantedKeysForCreatePartition(JSONObject object,String type) throws JSONException {
		 
		try {
			if (object != null) {
				Iterator<String> iterator = object.keys();
				while (iterator.hasNext()) {
					String key = iterator.next();
					Object o = object.get(key);
					
					if (o != null && o.equals("")) {
						iterator.remove();
					}
					if(key.equalsIgnoreCase("checkIntegrity")) {
						iterator.remove();
					}
					if(key.equalsIgnoreCase("noKey")) {
						iterator.remove();
					}
					if(key.equalsIgnoreCase("enableCavServer")) {
						iterator.remove();
					}
					if(key.equalsIgnoreCase("sessionClose")) {
						iterator.remove();
					}
					if(key.equalsIgnoreCase("credentialSaved")) {
						iterator.remove();
					}
					if(key.equalsIgnoreCase("lastOperationPerformed")) {
						iterator.remove();
					}
					if(key.equalsIgnoreCase("errorMessage")) {
						iterator.remove();
					}
					if(key.equalsIgnoreCase("lastOperationStatus")) {
						iterator.remove();
					}
					if(key.equalsIgnoreCase("applianceId")) {
						iterator.remove();
					}
					if(key.equalsIgnoreCase("applianceName")) {
						iterator.remove();
					}
					if(key.equalsIgnoreCase("applianceName")) {
						iterator.remove();
					}
					if (key.equalsIgnoreCase("applianceDetailModel")) {
						iterator.remove();
					}
					if (key.equalsIgnoreCase("partitionInformationModel")) {
						iterator.remove();
					}
					if (key.equalsIgnoreCase("partOfCluster")) {
						iterator.remove();
					}
					if (key.equalsIgnoreCase("zoneId")) {
						iterator.remove();
					}
					
					if(!StringUtils.isEmpty(type) && type.equalsIgnoreCase("networkconfig")) {
						if (key.equalsIgnoreCase("backup")) {
							iterator.remove();
						}
						if (key.equalsIgnoreCase("sslContexts")) {
							iterator.remove();
						}
						if (key.equalsIgnoreCase("keys")) {
							iterator.remove();
						}
						if (key.equalsIgnoreCase("wrap")) {
							iterator.remove();
						}
						if (key.equalsIgnoreCase("acclrDev")) {
							iterator.remove();
						}
					}
				}
			}
		}catch (Exception e) {
			// TODO: handle exception
		}
		return object;
	}

	@Override
	public List<PartitionDetailModel> stopStartPartitionCavSever(String loggedInUser,
			List<PartitionDetailModel> partitionDetailModels) {
		// TODO Auto-generated method stub
		List<PartitionDetailModel> listPartition=new ArrayList<>();
		boolean isSessionCloseFailed = false;
		String type="";
		try {
			for(PartitionDetailModel pdmobj : partitionDetailModels) {
				if(pdmobj.isEnableCavServer()==true) {
					type="Start Restart";
				}else {
					type="Stop CavServer";
				}
				ResponseEntity<String> response = null;
				PartitionDetailModel pdm = partitionRepository.findOne(pdmobj.getPartitionId());
				if (pdm != null && pdm.getPartitionId() > 0 && pdmobj.getApplianceDetailModel() != null) {
					ApplianceDetailModel app = pdmobj.getApplianceDetailModel();
					ApplianceDetailModel dbAppliance = applianceRepository.findOne(app.getApplianceId());
					if (dbAppliance != null) {
						JSONObject jsonObject=new JSONObject();
						 jsonObject = getUserNamePassword(pdmobj,jsonObject);
							if(pdmobj.isSessionClose()) {
								jsonObject.put("action", "close_session");
								ResponseEntity<String>	closeSessionresponse=restClient.invokePUTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/partition/"+pdmobj.getPartitionName()+"",jsonObject);
								if(closeSessionresponse!=null && closeSessionresponse.getBody()!=null) {
										ObjectMapper mapper = new ObjectMapper();
										JsonNode root = mapper.readTree(closeSessionresponse.getBody());
										Thread.sleep(15000);
										pdm=getStatusFromJobId(pdm, root, loggedInUser, "Session Close");
										logger.info("waiting...");
										if(pdm.getMessage()!=null && pdm.getStatus().equalsIgnoreCase("Completed")) {
											jsonObject.remove("action");
											jsonObject.put("partitionName", pdmobj.getPartitionName());
											jsonObject.put("enableCavServer", pdmobj.isEnableCavServer());
											logger.info("Notifying..");
											response = restClient.invokePOSTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/toggle_partition_cav_server", jsonObject);
											isSessionCloseFailed=false;
										}else {
											isSessionCloseFailed=true;
											pdm.setMessage("Failed");
											pdm.setErrorMessage(""+type+" failed due to close session");
											pdm.setLastOperationPerformed(type);
											pdm.setLastOperationStatus("Failed");
											pdm.setCode("11032");
											partitionRepository.save(pdm);
										}
									
								}
							}else {
								jsonObject.put("partitionName", pdmobj.getPartitionName());
								jsonObject.put("enableCavServer", pdmobj.isEnableCavServer());
								response = restClient.invokePOSTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/toggle_partition_cav_server", jsonObject);
								isSessionCloseFailed=false;
							}
						if(response!=null && response.getBody()!=null && response.getBody().contains("success") && isSessionCloseFailed==false) {
								if(pdmobj.isEnableCavServer()==true) {
									pdm.setMessage("Start/Restart cav server Initiated successfully.");
									pdm.setLastOperationPerformed(type);
								}else {
									pdm.setMessage("Stop cav server Initiated successfully.");
									pdm.setLastOperationPerformed(type);
								}
								pdm.setErrorMessage("");
								pdm.setLastOperationStatus("In-Progress");
								pdm.setCode("200");
								ObjectMapper mapper = new ObjectMapper();
								JsonNode root = mapper.readTree(response.getBody());
								if (!root.isNull()) {
									updateInProgressActivity(pdm, loggedInUser, root);
								}
								partitionRepository.save(pdm);
						}else {
							if(isSessionCloseFailed==false) {
								pdm=getErrorMessage(response, pdm,loggedInUser,type);
								partitionRepository.save(pdm);
							}
						}
					}
				}else {
					pdm=pdmobj;
					pdm.setCode("408");
					pdm.setErrorMessage("Partition "+pdm.getPartitionName()+" does not exists.");
				}
				listPartition.add(pdm);
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error(
					"Error occured during partition delete in method stopStartPartitionCavSever of class PartitionServiceImpl "
							+ e.getMessage());
		}
		return listPartition;
	}

	/**
	 * Used to uploadCavServerConfigFile
	 */
	@Override
	public List<PartitionDetailModel> uploadCavServerConfigFile(String loggedInUser,
			List<PartitionDetailModel> partitionDetailModels) {
		// TODO Auto-generated method stub
		List<PartitionDetailModel> partitionList=new ArrayList<>();
		boolean isSessionCloseFailed = false;
		try {
			for(PartitionDetailModel pdmobj:partitionDetailModels) {
				ResponseEntity<String> response=null;
				PartitionDetailModel pdm=partitionRepository.findOne(pdmobj.getPartitionId());
				if(pdm!=null && pdm.getPartitionId() > 0 && pdmobj.getApplianceDetailModel()!=null) {
					ApplianceDetailModel app=pdmobj.getApplianceDetailModel();
					ApplianceDetailModel dbAppliance=applianceRepository.findOne(app.getApplianceId()); 
					if(dbAppliance!=null) {
						 JSONObject jsonObject=new JSONObject();
						 /**
						  * Get username and password
						  */
						 jsonObject = getUserNamePassword(pdmobj,jsonObject);
						 /**
						  * Upload file to cavium server
						  */
						pdmobj=uploadFileforPartition(pdmobj,"UploadCavServerConfig",null);
						/**
						 * Session close is true
						 */
						if(pdmobj.isSessionClose()) {
							jsonObject.put("action", "close_session");
							ResponseEntity<String>	closeSessionresponse=restClient.invokePUTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/partition/"+pdmobj.getPartitionName()+"",jsonObject);
							if(closeSessionresponse!=null && closeSessionresponse.getBody()!=null) {
								ObjectMapper mapper = new ObjectMapper();
								JsonNode root = mapper.readTree(closeSessionresponse.getBody());
								Thread.sleep(15000);
								pdm=getStatusFromJobId(pdm, root, loggedInUser, "Session Close");
								if(pdm.getMessage()!=null && pdm.getStatus().equalsIgnoreCase("Completed")) {
									/**
									 * File being upload in below method
									 */
									if(!StringUtils.isEmpty(pdmobj.getCode()) && pdmobj.getCode().equalsIgnoreCase("200")) {
										jsonObject.remove("action");
										jsonObject.put("partitionName", pdmobj.getPartitionName());
										jsonObject.put("configFileId", pdmobj.getMessage());
										response=restClient.invokePUTMethodForOperations("https://"+pdmobj.getApplianceDetailModel().getIpAddress()+"/liquidsa/upload_cav_serv_config/"+pdmobj.getPartitionName()+"",jsonObject);											isSessionCloseFailed=false;
										isSessionCloseFailed=false;
									}
								}else {
									isSessionCloseFailed=true;
								}
							}
						}else {
							if(!StringUtils.isEmpty(pdmobj.getCode()) && pdmobj.getCode().equalsIgnoreCase("200")) {
								jsonObject.put("partitionName", pdmobj.getPartitionName());
								jsonObject.put("configFileId", pdmobj.getMessage());
								response=restClient.invokePUTMethodForOperations("https://"+pdmobj.getApplianceDetailModel().getIpAddress()+"/liquidsa/upload_cav_server_config/"+pdmobj.getPartitionName()+"",jsonObject);
								isSessionCloseFailed=false;
							}
						}
						
						if(response!=null && response.getBody()!=null && response.getBody().contains("success") && isSessionCloseFailed==false) {
								pdm.setMessage("UploadCavServerConfig Initiated successfully.");
								pdm.setErrorMessage("");
								pdm.setLastOperationPerformed("UploadCavServerConfig");
								pdm.setLastOperationStatus("Completed");
								pdm.setCode("200");
								recentActivityServiceImpl.createRecentActivity(pdm.getCreatedBy(), " Cav Server Config file uploaded successfully for Partition "+pdm.getPartitionName()+"  for appliance "+pdm.getApplianceDetailModel().getApplianceName()+" by "+pdm.getCreatedBy(),CaviumConstant.PARTITION_MANAGEMENT);
								/*ObjectMapper mapper = new ObjectMapper();
								JsonNode root = mapper.readTree(response.getBody());
								if (!root.isNull()) {
									updateInProgressActivity(pdm, loggedInUser, root);
								}*/
								partitionRepository.save(pdm);
						}else {
							if(isSessionCloseFailed==false) {
							pdm=getErrorMessage(response, pdm,loggedInUser,"UploadCavServerConfig");
							partitionRepository.save(pdm);
							}
						}
					}
				}
				partitionList.add(pdm);
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during partition delete in method resetPartition of class PartitionServiceImpl "+e.getMessage());
		}
		return partitionList;
	}
	/**
	 * used to resetCavServerConfig
	 */
	@Override
	public List<PartitionDetailModel> resetCavServerConfig(String loggedInUser,
			List<PartitionDetailModel> partitionDetailModels) {
		// TODO Auto-generated method stub
		List<PartitionDetailModel> partitionList=new ArrayList<>();
		boolean isSessionCloseFailed = false;
		try {
			for(PartitionDetailModel pdmobj:partitionDetailModels) {
				ResponseEntity<String> response=null;
				PartitionDetailModel pdm=partitionRepository.findOne(pdmobj.getPartitionId());
				if(pdm!=null && pdm.getPartitionId() > 0 && pdmobj.getApplianceDetailModel()!=null) {
					ApplianceDetailModel app=pdmobj.getApplianceDetailModel();
					ApplianceDetailModel dbAppliance=applianceRepository.findOne(app.getApplianceId()); 
					if(dbAppliance!=null) {
						
						JSONObject jsonObject=new JSONObject();
						jsonObject = getUserNamePassword(pdmobj,jsonObject);
						
						if(pdmobj.isSessionClose()) {
							jsonObject.put("action", "close_session");
							ResponseEntity<String>	closeSessionresponse=restClient.invokePUTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/partition/"+pdmobj.getPartitionName()+"",jsonObject);
							if(closeSessionresponse!=null && closeSessionresponse.getBody()!=null) {
								ObjectMapper mapper = new ObjectMapper();
								JsonNode root = mapper.readTree(closeSessionresponse.getBody());
								Thread.sleep(15000);
								pdm=getStatusFromJobId(pdm, root, loggedInUser, "Session Close");
								if(pdm.getMessage()!=null && pdm.getStatus().equalsIgnoreCase("Completed")) {
									jsonObject.remove("action");
									response=restClient.invokePUTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/reset_cav_server_config/"+pdmobj.getPartitionName()+"",jsonObject);
									isSessionCloseFailed=false;
								}else {
									isSessionCloseFailed=true;
									pdm.setMessage("Failed");
									pdm.setErrorMessage("ResetCavServerConfig failed due to close session");
									pdm.setLastOperationPerformed("ResetCavServerConfig");
									pdm.setLastOperationStatus("Failed");
									pdm.setCode("11032");
									partitionRepository.save(pdm);
								}
							}
						}else {
							response=restClient.invokePUTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/reset_cav_server_config/"+pdmobj.getPartitionName()+"",jsonObject);
							isSessionCloseFailed=false;
						}
						
						if(response!=null && response.getBody()!=null && response.getBody().contains("success") && isSessionCloseFailed==false) {
								pdm.setMessage("Reset Partition is Initiated successfully for "+pdmobj.getPartitionName()+"");
								pdm.setErrorMessage("");
								pdm.setLastOperationPerformed("ResetCavServerConfig");
								pdm.setLastOperationStatus("In-Progress");
								pdm.setCode("200");
								ObjectMapper mapper = new ObjectMapper();
								JsonNode root = mapper.readTree(response.getBody());
								if (!root.isNull()) {
									updateInProgressActivity(pdm, loggedInUser, root);
								}
								partitionRepository.save(pdm);
						}else {
							if(isSessionCloseFailed==false) {
							pdm=getErrorMessage(response, pdm,loggedInUser,"ResetCavServerConfig");
							partitionRepository.save(pdm);
							}
						}
					}
				}
				partitionList.add(pdm);
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during partition delete in method resetPartition of class PartitionServiceImpl "+e.getMessage());
		}
		return partitionList;
	}
	
	/**
	 * 
	 * @param detailModel
	 * @return
	 */
	private PartitionDetailModel uploadFileforPartition(PartitionDetailModel detailModel,String type,File file) {
			File convertedFile=null;
			List<PartitionCertificates> newList=new ArrayList<>();
			try {
						try{
							if(detailModel.getCertificates()!=null && detailModel.getCertificates().size() > 0) {
								for(PartitionCertificates ptrc:  detailModel.getCertificates()) {
								if(!StringUtils.isEmpty(ptrc.getFileName()) && !StringUtils.isEmpty(ptrc.getFileExtension()) && !StringUtils.isEmpty(ptrc.getFileContent())) {
									convertedFile= CaviumUtil.createFilefromByte(ptrc.getFileName(),ptrc.getFileExtension(),ptrc.getFileContent());
									}
								}
							}else {
								if(file!=null) {
									convertedFile=file;
								}
							}
						}catch (IOException e) {
							logger.error("Error while creating file in initilizeAppliance method"); 
							detailModel.setCode("409");
							detailModel.setErrorMessage("Failed to create file for upload");
						}
						if(convertedFile!=null && convertedFile.exists()) {
						CaviumResponseModel	caviumResponseModel=fileUploadService.uploadFile(convertedFile,detailModel.getUsername(),detailModel.getPassword(),type,detailModel.getApplianceDetailModel().getIpAddress(),null);
						if(caviumResponseModel.getResponseCode()!=null && caviumResponseModel.getResponseCode().equalsIgnoreCase("200")) {
							detailModel.setMessage(caviumResponseModel.getResponseMessage());
							detailModel.setCode("200");
						}else {
							detailModel.setCode("409");
							detailModel.setErrorMessage("Failed to create file for upload");
						}
						}else {
							detailModel.setErrorMessage("Failed to create file for upload");
						}
				detailModel.setCertificates(newList);
			} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during uploadFileforPartitionCavSever");
		}finally {
			if(convertedFile!=null && convertedFile.exists()) {
				convertedFile.delete();
			}
		}
		return detailModel;
	}
	
	/**
	 * 
	 * @param pdmobj
	 * @return
	 */
	@Override
	public JSONObject getUserNamePassword(PartitionDetailModel pdmobj,JSONObject jsonObject) {
		try {
			if (pdmobj.getApplianceDetailModel() != null) {
				ApplianceDetailModel app = pdmobj.getApplianceDetailModel();
				ApplianceDetailModel dbAppliance = applianceRepository.findOne(app.getApplianceId());
				if (dbAppliance != null) {
					long applianceId = app.getApplianceId();
					InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry
							.getInitializeIdByApplianceId(applianceId);
					if (initmodel != null) {
						InitializeApplianceDetailModel initAppDetailModel = initializeRepository
								.findOne(initmodel.getInitializeId());
						DualFactorAuthDetailModel dualAuthModel = initAppDetailModel.getDualFactorAuthDetailModel();
						if (!StringUtils.isEmpty(pdmobj.getUsername())
								&& !StringUtils.isEmpty(pdmobj.getPassword())) {
							if (initAppDetailModel.getAuthenticationLevel() == 0) {
								jsonObject.put("username", pdmobj.getUsername());
								jsonObject.put("password", pdmobj.getPassword());
							}
							if (initAppDetailModel.getAuthenticationLevel() == 1 && dualAuthModel != null) {
								jsonObject.put("username", pdmobj.getUsername());
								jsonObject.put("password", pdmobj.getPassword());
								jsonObject.put("dualFactorHostname", dualAuthModel.getDualFactorAuthServerAddress());
								jsonObject.put("dualFactorPort", dualAuthModel.getDualFactorAuthServerPortNo());
								jsonObject.put("dualFactorCertificate", dualAuthModel.getDualFactorAuthServerCertId());
							}
						} else {
							if (initAppDetailModel.getAuthenticationLevel() == 0) {
								jsonObject.put("username", initAppDetailModel.getCryptoOfficerName());
								jsonObject.put("password",  CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));
							}
							if (initAppDetailModel.getAuthenticationLevel() == 1 && dualAuthModel != null) {
								jsonObject.put("username", initAppDetailModel.getCryptoOfficerName());
								jsonObject.put("password",  CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));
								jsonObject.put("dualFactorHostname", dualAuthModel.getDualFactorAuthServerAddress());
								jsonObject.put("dualFactorPort", dualAuthModel.getDualFactorAuthServerPortNo());
								jsonObject.put("dualFactorCertificate", dualAuthModel.getDualFactorAuthServerCertId());
							}
						}
						}else {
							jsonObject.put("username", pdmobj.getUsername());
							jsonObject.put("password", pdmobj.getPassword());
						}
					}
			}else {
				jsonObject.put("Error", "Partition does Not exists");
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getUserNamePassword method in partitionServiceIMPL");
		}
		return jsonObject;
	}

	public void getFipsState(PartitionSnapshotDetails partitionSnapshotDetails ,PartitionsDetails partitionsDetails){

		for (Iterator<PartitionData> iterator = partitionsDetails.getPartitionDataList().iterator(); iterator.hasNext();) {
			PartitionData partitionData = (PartitionData) iterator.next();
			String fipState=partitionData.getFipsState();
			if(!StringUtils.isEmpty(fipState)){
				if(fipState.replaceAll(" ","").contains("-1[zeroized]")){
					partitionSnapshotDetails.setZeroizedState(partitionSnapshotDetails.getZeroizedState()+1);
				}
				if(fipState.replaceAll(" ","").contains("3")){
					partitionSnapshotDetails.setFipModeWithDualfactor(partitionSnapshotDetails.getFipModeWithDualfactor()+1);
				}
				if(fipState.replaceAll(" ","").contains("2")){
					partitionSnapshotDetails.setFipMode(partitionSnapshotDetails.getFipMode()+1);
				}
				if(fipState.replaceAll(" ","").contains("0")){
					partitionSnapshotDetails.setNonFipMode(partitionSnapshotDetails.getNonFipMode()+1);
				}
			}
		}
	}

	public void getSSlContextDetails(double usedsslContextsPercentage, PartitionSnapshotDetails partitionSnapshotDetails, PartitionDetailsWithPercentage sslContextssWithPercentage){
		if(usedsslContextsPercentage<=10.0){
			partitionSnapshotDetails.getContextDetailsWithPercentage().getTenPercentList().add(sslContextssWithPercentage);
		}
		else if(usedsslContextsPercentage>10.0 && usedsslContextsPercentage<=20.0){
			partitionSnapshotDetails.getContextDetailsWithPercentage().getTwentyPercentList().add(sslContextssWithPercentage);
		}
		else if(usedsslContextsPercentage>20.0 && usedsslContextsPercentage<=30.0){
			partitionSnapshotDetails.getContextDetailsWithPercentage().getThirtyPercentList().add(sslContextssWithPercentage);
		}
		else if(usedsslContextsPercentage>30.0 && usedsslContextsPercentage<=40.0){
			partitionSnapshotDetails.getContextDetailsWithPercentage().getFortyPercentList().add(sslContextssWithPercentage);
		}
		else if(usedsslContextsPercentage>40.0 && usedsslContextsPercentage<=50.0){
			partitionSnapshotDetails.getContextDetailsWithPercentage().getFiftyPercentList().add(sslContextssWithPercentage);
		}
		else if(usedsslContextsPercentage>50.0 && usedsslContextsPercentage<=60.0){
			partitionSnapshotDetails.getContextDetailsWithPercentage().getSixtyPercentList().add(sslContextssWithPercentage);
		}
		else if(usedsslContextsPercentage>60.0 && usedsslContextsPercentage<=70.0){
			partitionSnapshotDetails.getContextDetailsWithPercentage().getSeventyPercentList().add(sslContextssWithPercentage);
		}
		else if(usedsslContextsPercentage>70.0 && usedsslContextsPercentage<=80.0){
			partitionSnapshotDetails.getContextDetailsWithPercentage().getEightyPercentList().add(sslContextssWithPercentage);
		}
		else if(usedsslContextsPercentage>80.0 && usedsslContextsPercentage<=90.0){
			partitionSnapshotDetails.getContextDetailsWithPercentage().getNinetyPercentList().add(sslContextssWithPercentage);
		}
		else{
			partitionSnapshotDetails.getContextDetailsWithPercentage().getHundredPercentList().add(sslContextssWithPercentage);
		}
	}

	public void getAccelerationDeviceDetails(double usedAcclrDevPercentage , PartitionSnapshotDetails partitionSnapshotDetails, PartitionDetailsWithPercentage accelerationDevicesWithPercentage)
	{

		if(usedAcclrDevPercentage<=10.0){
			partitionSnapshotDetails.getAcclrDeviceDetailsWithPercentage().getTenPercentList().add(accelerationDevicesWithPercentage);
		}
		else if(usedAcclrDevPercentage>10.0 && usedAcclrDevPercentage<=20.0){
			partitionSnapshotDetails.getAcclrDeviceDetailsWithPercentage().getTwentyPercentList().add(accelerationDevicesWithPercentage);
		}
		else if(usedAcclrDevPercentage>20.0 && usedAcclrDevPercentage<=30.0){
			partitionSnapshotDetails.getAcclrDeviceDetailsWithPercentage().getThirtyPercentList().add(accelerationDevicesWithPercentage);
		}
		else if(usedAcclrDevPercentage>30.0 && usedAcclrDevPercentage<=40.0){
			partitionSnapshotDetails.getAcclrDeviceDetailsWithPercentage().getFortyPercentList().add(accelerationDevicesWithPercentage);
		}
		else if(usedAcclrDevPercentage>40.0 && usedAcclrDevPercentage<=50.0){
			partitionSnapshotDetails.getAcclrDeviceDetailsWithPercentage().getFiftyPercentList().add(accelerationDevicesWithPercentage);
		}
		else if(usedAcclrDevPercentage>50.0 && usedAcclrDevPercentage<=60.0){
			partitionSnapshotDetails.getAcclrDeviceDetailsWithPercentage().getSixtyPercentList().add(accelerationDevicesWithPercentage);
		}
		else if(usedAcclrDevPercentage>60.0 && usedAcclrDevPercentage<=70.0){
			partitionSnapshotDetails.getAcclrDeviceDetailsWithPercentage().getSeventyPercentList().add(accelerationDevicesWithPercentage);
		}
		else if(usedAcclrDevPercentage>70.0 && usedAcclrDevPercentage<=80.0){
			partitionSnapshotDetails.getAcclrDeviceDetailsWithPercentage().getEightyPercentList().add(accelerationDevicesWithPercentage);
		}
		else if(usedAcclrDevPercentage>80.0 && usedAcclrDevPercentage<=90.0){
			partitionSnapshotDetails.getAcclrDeviceDetailsWithPercentage().getNinetyPercentList().add(accelerationDevicesWithPercentage);
		}
		else{
			partitionSnapshotDetails.getAcclrDeviceDetailsWithPercentage().getHundredPercentList().add(accelerationDevicesWithPercentage);
		}
	}

	public void getKeysDetails(double usedKeysPercentage , PartitionSnapshotDetails partitionSnapshotDetails, PartitionDetailsWithPercentage keysWithPercentage)
	{

		if(usedKeysPercentage<=10.0){
			partitionSnapshotDetails.getKeyDetailsWithPercentage().getTenPercentList().add(keysWithPercentage);
		}
		else if(usedKeysPercentage>10.0 && usedKeysPercentage<=20.0){
			partitionSnapshotDetails.getKeyDetailsWithPercentage().getTwentyPercentList().add(keysWithPercentage);
		}
		else if(usedKeysPercentage>20.0 && usedKeysPercentage<=30.0){
			partitionSnapshotDetails.getKeyDetailsWithPercentage().getThirtyPercentList().add(keysWithPercentage);
		}
		else if(usedKeysPercentage>30.0 && usedKeysPercentage<=40.0){
			partitionSnapshotDetails.getKeyDetailsWithPercentage().getFortyPercentList().add(keysWithPercentage);
		}
		else if(usedKeysPercentage>40.0 && usedKeysPercentage<=50.0){
			partitionSnapshotDetails.getKeyDetailsWithPercentage().getFiftyPercentList().add(keysWithPercentage);
		}
		else if(usedKeysPercentage>50.0 && usedKeysPercentage<=60.0){
			partitionSnapshotDetails.getKeyDetailsWithPercentage().getSixtyPercentList().add(keysWithPercentage);
		}
		else if(usedKeysPercentage>60.0 && usedKeysPercentage<=70.0){
			partitionSnapshotDetails.getKeyDetailsWithPercentage().getSeventyPercentList().add(keysWithPercentage);
		}
		else if(usedKeysPercentage>70.0 && usedKeysPercentage<=80.0){
			partitionSnapshotDetails.getKeyDetailsWithPercentage().getEightyPercentList().add(keysWithPercentage);
		}
		else if(usedKeysPercentage>80.0 && usedKeysPercentage<=90.0){
			partitionSnapshotDetails.getKeyDetailsWithPercentage().getNinetyPercentList().add(keysWithPercentage);
		}
		else{
			partitionSnapshotDetails.getKeyDetailsWithPercentage().getHundredPercentList().add(keysWithPercentage);
		}
	}
	
	
	public void getUsageDetails(PartitionSnapshotDetails partitionSnapshotDetails ,PartitionsDetails partitionsDetails){
		// for testing purpose we use hardcode value. After that we will get these values from response.
		int bm=1;
		int cm=1;
		int dm=1;
		// end of hardcode values
		int actualAvaliabeContexts=0;
		int actualAvaliabeKeys=0;
		int actualAvaliableAcclrDevices=0;
		int avaliablePartitions=partitionsDetails.getTotalPartitions()-partitionsDetails.getOccupiedPartitions();
		int avaliableAcclrDevices=partitionsDetails.getTotalAcclrDev()-partitionsDetails.getOccupiedAcclrDev();
		int avaliableKeys=partitionsDetails.getTotalKeys()-partitionsDetails.getOccupiedKeys();
		int avaliabeContexts=partitionsDetails.getTotalContexts()-partitionsDetails.getOccupiedContexts();
		int totalPartitions=partitionsDetails.getTotalPartitions();
		if(bm!=0){
		 actualAvaliableAcclrDevices=avaliableAcclrDevices/bm;
		}
		if(cm!=0){	 
		 actualAvaliabeKeys=avaliableKeys/cm;
		}
		
		if(dm!=0){
			actualAvaliabeContexts=avaliabeContexts/dm;
		}
		int  avaliableArray[] = {avaliablePartitions, actualAvaliableAcclrDevices, actualAvaliabeKeys, actualAvaliabeContexts};
		 int minimumPartitionSlot=avaliableArray[0];
		for (int i=1; i < avaliableArray.length; i++)
		{
			if(avaliableArray[i] < minimumPartitionSlot){ 
				minimumPartitionSlot = avaliableArray[i]; 
			} 
		}
		partitionSnapshotDetails.setAvaliablePartitionSlots(partitionSnapshotDetails.getAvaliablePartitionSlots()+minimumPartitionSlot);
		partitionSnapshotDetails.setTotalPartitionSlots(partitionSnapshotDetails.getTotalPartitionSlots()+totalPartitions);
		int occupiedParttions=partitionSnapshotDetails.getTotalPartitionSlots()-partitionSnapshotDetails.getAvaliablePartitionSlots();
		partitionSnapshotDetails.setOccupiedPartitionSlots(occupiedParttions);
	}
	
	public void getPartitionStatusDetails(PartitionSnapshotDetails partitionSnapshotDetails ,PartitionsDetails partitionsDetails){
		for (Iterator<PartitionData> iterator = partitionsDetails.getPartitionDataList().iterator(); iterator.hasNext();) {
			PartitionData partitionData = (PartitionData) iterator.next();
		int cavServerStatus=partitionData.getCavServerStatus();
		int vmStatus=partitionData.getVmStatus();
		if(cavServerStatus==1 && vmStatus==1)
		{
			 partitionSnapshotDetails.setPartitionFunctionalStatus(partitionSnapshotDetails.getPartitionFunctionalStatus()+1);
		}
		if(vmStatus==-1){
			partitionSnapshotDetails.setPartitionNonFunctionalStatus(partitionSnapshotDetails.getPartitionNonFunctionalStatus()+1);
		}
		if(vmStatus==1 && cavServerStatus==-1){
			partitionSnapshotDetails.setPartitionNonFunctionalStatus(partitionSnapshotDetails.getPartitionNonFunctionalStatus()+1);
		}
		}
	}

	@Override
	public CaviumResponseModel downloadConfigFileURL(PartitionDetailModel detailModel,String type) {

		String	errorMessage=null;
		CaviumResponseModel responseModel=getCaviumResponseModel();
		String loggedInUser = userAttributes.getlogInUserName();
		try{
			JSONObject jsonobject=new JSONObject();
			jsonobject=getUserNamePassword(detailModel, jsonobject);
			if(!StringUtils.isEmpty(type) && type.equalsIgnoreCase("backup_partition")) {
				jsonobject.put("noKey", detailModel.isNoKey());
			}
			ResponseEntity<String> response=restClient.invokePUTMethodForOperations("https://"+detailModel.getApplianceDetailModel().getIpAddress()+"/liquidsa/"+type+"/"+detailModel.getPartitionName()+"",jsonobject);
				ObjectMapper mapper = new ObjectMapper();
				if(response!=null && response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						String status = root.path("status").asText();
				 
						if("success".equalsIgnoreCase(status)){
							JsonNode dataNode = root.path("data");
							if(!dataNode.isNull() && dataNode.size()>0){
								if(dataNode.has("downloadUrlAddr")) {
									String certificateUrl = dataNode.path("downloadUrlAddr").asText();
									responseModel.setResponseCode("200");
									responseModel.setResponseMessage(certificateUrl);
								}if(dataNode.has("certificateUrlAddr")) {
									String certificateUrl = dataNode.path("certificateUrlAddr").asText();
									responseModel.setResponseCode("200");
									responseModel.setResponseMessage(certificateUrl);
								}
							}else {
								if(!StringUtils.isEmpty(type) && type.equalsIgnoreCase("backup_partition")) {
									Thread.sleep(10000);
									Integer jobId = root.path("jobId").asInt();
									ResponseEntity<String> res=restClient.invokeGETMethod("https://"+detailModel.getApplianceDetailModel().getIpAddress()+"/liquidsa/notification/"+jobId+"");
									JsonNode roott = mapper.readTree(res.getBody());
									if(!roott.isNull()){
										String backupstatus = roott.path("status").asText();
										if("success".equalsIgnoreCase(backupstatus)){
											JsonNode dataNodee = roott.path("data");
											if(dataNodee.has("backupFileUrlAddr")) {
												String certificateUrl = dataNodee.path("backupFileUrlAddr").asText();
												responseModel.setResponseCode("200");
												responseModel.setResponseMessage(certificateUrl);
											}
										}else {
											detailModel=getErrorMessage(res, detailModel, loggedInUser, type);
											responseModel.setResponseMessage(detailModel.getErrorMessage());	  
											responseModel.setResponseCode(detailModel.getCode());	 
										}
									}
								}
							}
						}
						 if("error".equalsIgnoreCase(status)){
								JsonNode errors = root.path("errors");
								if(!errors.isNull() && errors.size()>0){
									Iterator<JsonNode> itr = errors.elements();                           
									while (itr.hasNext()) {
										JsonNode temp = itr.next();
										if(temp.asInt()==11095)
											{ 
											errorMessage="HSM owner certificate is not installed."; 
									  }
										if(temp.asInt()==11096)
										{ 
											errorMessage="HSM Certificate issued by HO is not installed."; 
										 }
										if(temp.asInt()==11097)
										{ 
											errorMessage="HSM owner certificate is not installed.";
										}
									 }
									responseModel.setResponseMessage(errorMessage);	  
									responseModel.setResponseCode("409");	  
									}
								}
						 }
					 }else {
						 detailModel = getErrorMessage(response, detailModel, loggedInUser, "Upload for RestorePartition");
						 responseModel.setResponseCode(detailModel.getCode());
						 responseModel.setResponseMessage(detailModel.getErrorMessage());
					 }
		}catch (Exception e) {
			logger.error("Error occured in  getCertificateURL Method :: "+e.getMessage());
		}
		return responseModel;
	}
	
	@Override
	public File downloadConfigFile(String certificateUrl, String partitionName) {
		File file=null;
		String fileName=null;
		try{
			ResponseEntity<byte[]> response=restClient.invokeGETMethodForFileDownload(certificateUrl);
			if(response!=null && response.getStatusCode().name().equals("OK") ) {
				String finalfileName=null;
				List<String> CONTENT_DISPOSITION=response.getHeaders().get("Content-Disposition");
				for (Iterator<String> iterator = CONTENT_DISPOSITION.iterator(); iterator.hasNext();) {
					String contentDisposition = (String) iterator.next();
					String fileNameSplit[]=contentDisposition.split("=");
					if(fileNameSplit.length>0){
						fileName=fileNameSplit[1];
					}
				}				
				finalfileName = partitionName+"-"+CaviumUtil.getRandomText()+"-"+fileName;
				file = CaviumUtil.createFile(finalfileName,null,"");
				Files.write(Paths.get(file.getAbsolutePath()), response.getBody());		
			}		 
		}catch (Exception e) {
			logger.error("Error occured in  getCertificateFile Method :: "+e.getMessage());
		}
		return file;
		
		/*logger.info("Start of downloadConfigFile Method ::");
		File file=null;
		String fileName=null;
		InputStream inputStream=null;
		  OutputStream   outputStream=null;
		try{
			HttpResponse response=restClient.invokeGETMethodForLargeFileDownload(certificateUrl);
			if(response!=null) {
				String finalfileName=null;
				String contentDisposition=response.getFirstHeader("Content-Disposition").getValue();
				String fileNameSplit[]=contentDisposition.split("=");
				if(fileNameSplit.length>0){
				  	fileName=fileNameSplit[1];
				
				}
				 finalfileName = partitionName+"-"+CaviumUtil.getRandomText()+"-"+fileName;
				  file = CaviumUtil.createFile(finalfileName,null,"");
				 
				  HttpEntity entity=response.getEntity();
					  if (entity != null) {
					   inputStream = entity.getContent();
			            outputStream = new FileOutputStream(file);
			            IOUtils.copy(inputStream, outputStream);
						 }
			 	
			}		 
		}catch (Exception e) {
			try{
				Files.deleteIfExists(Paths.get(file.getAbsolutePath()));
				file=null;
			}catch (Exception exp) {
				logger.error("Error in writting content to file  in downloadConfigFile method of PartitionServiceImpl Class :: " + e.getMessage()); 
			}
			
			logger.error("Error occured in  downloadConfigFile Method :: "+e.getMessage());
		}finally{
			try{
			if(inputStream!=null)
			{
				inputStream.close();	
			}
			if(outputStream!=null)
			{
				outputStream.flush();
				outputStream.close();
			}
			}catch (Exception e) {
				logger.error("Error occured in  downloadConfigFile Method for closing InputStream and OutputStream :: "+e.getMessage());
			}
		}
		logger.info("end of downloadConfigFile Method ::");
		return file;*/
	}

	@Override
	public List<PartitionDetailModel> uploadPartitionCertificate(String loggedInUser,
			List<PartitionDetailModel> partitionDetailModels) {
		// TODO Auto-generated method stub
		List<PartitionDetailModel> partitionList=new ArrayList<>();
		boolean isSessionCloseFailed = false;
		try {
			for(PartitionDetailModel pdmobj:partitionDetailModels) {
				ResponseEntity<String> response=null;
				PartitionDetailModel pdm=partitionRepository.findOne(pdmobj.getPartitionId());
				if(pdm!=null && pdm.getPartitionId() > 0 && pdmobj.getApplianceDetailModel()!=null) {
					ApplianceDetailModel app=pdmobj.getApplianceDetailModel();
					ApplianceDetailModel dbAppliance=applianceRepository.findOne(app.getApplianceId()); 
					if(dbAppliance!=null) {
						 JSONObject jsonObject=new JSONObject();
						 /**
						  * Get username and password
						  */
						 jsonObject = getUserNamePassword(pdmobj,jsonObject);
						 /**
						  * Upload file to cavium server
						  */
						pdmobj=uploadFileforPartition(pdmobj,"importPartitionCertificates",null);
						/**
						 * Session close is true
						 */
						if(pdmobj.isSessionClose()) {
							jsonObject.put("action", "close_session");
							ResponseEntity<String>	closeSessionresponse=restClient.invokePUTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/partition/"+pdmobj.getPartitionName()+"",jsonObject);
							if(closeSessionresponse!=null && closeSessionresponse.getBody()!=null) {
								ObjectMapper mapper = new ObjectMapper();
								JsonNode root = mapper.readTree(closeSessionresponse.getBody());
								Thread.sleep(15000);
								pdm=getStatusFromJobId(pdm, root, loggedInUser, "Session Close");
								if(pdm.getMessage()!=null && pdm.getStatus().equalsIgnoreCase("Completed")) {
									/**
									 * File being upload in below method
									 */
									if(!StringUtils.isEmpty(pdmobj.getCode()) && pdmobj.getCode().equalsIgnoreCase("200")) {
										if(pdmobj.getCertificates()!=null && pdmobj.getCertificates().size() > 0) {
											for(PartitionCertificates pc: pdmobj.getCertificates()) {
												if(pc.getFileName().equals("poSignedCertificate")) {
													jsonObject.put("poSignedCertificate", pc.getFileContent());
												}if(pc.getFileName().equals("poCertificate")) {
													jsonObject.put("poCertificate", pc.getFileContent());
												}
											}
										}
										response=restClient.invokePUTMethodForOperations("https://"+pdmobj.getApplianceDetailModel().getIpAddress()+"/liquidsa/upload_partition_certificates/"+pdmobj.getPartitionName()+"",jsonObject);											isSessionCloseFailed=false;
										isSessionCloseFailed=false;
									}
								}else {
									isSessionCloseFailed=true;
								}
							}
						}else {
							if(!StringUtils.isEmpty(pdmobj.getCode()) && pdmobj.getCode().equalsIgnoreCase("200")) {
								if(pdmobj.getCertificates()!=null && pdmobj.getCertificates().size() > 0) {
									for(PartitionCertificates pc: pdmobj.getCertificates()) {
										if(pc.getFileName().equals("poSignedCertificate")) {
											jsonObject.put("poSignedCertificate", pc.getFileContent());
										}if(pc.getFileName().equals("poCertificate")) {
											jsonObject.put("poCertificate", pc.getFileContent());
										}
									}
								}
								response=restClient.invokePUTMethodForOperations("https://"+pdmobj.getApplianceDetailModel().getIpAddress()+"/liquidsa/upload_partition_certificates/"+pdmobj.getPartitionName()+"",jsonObject);											isSessionCloseFailed=false;
								isSessionCloseFailed=false;
							}
						}
						
						if(response!=null && response.getBody()!=null && response.getBody().contains("success") && isSessionCloseFailed==false) {
								pdm.setMessage("Upload partition certificate Initiated successfully.");
								pdm.setErrorMessage("");
								pdm.setLastOperationPerformed("importPartitionCertificates");
								pdm.setLastOperationStatus("In-Progress");
								pdm.setCode("200");
								ObjectMapper mapper = new ObjectMapper();
								JsonNode root = mapper.readTree(response.getBody());
								if (!root.isNull()) {
									updateInProgressActivity(pdm, loggedInUser, root);
								}
								partitionRepository.save(pdm);
						}else {
							if(isSessionCloseFailed==false) {
							pdm=getErrorMessage(response, pdm,loggedInUser,"importPartitionCertificates");
							partitionRepository.save(pdm);
							}
						}
					}
				}
				partitionList.add(pdm);
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during partition delete in method resetPartition of class PartitionServiceImpl "+e.getMessage());
		}
		return partitionList;
	}


	@Override
	public List<PartitionDetailModel> restorePartition(String loggedInUser,
			RestorePartitionModel restorePartitionModel) {
		boolean isSessionCloseFailed =false;
		List<PartitionDetailModel> partitionList=new ArrayList<>();
		// TODO Auto-generated method stub
		try {
			if(restorePartitionModel!=null && restorePartitionModel.getPartitionList()!=null && restorePartitionModel.getPartitionList().size() > 0) {
				for(PartitionDetailModel pdmobj:restorePartitionModel.getPartitionList()) {
					ResponseEntity<String> response=null;
					PartitionDetailModel pdm=partitionRepository.findOne(pdmobj.getPartitionId());
					if(pdm!=null && pdm.getPartitionId() > 0 && pdmobj.getApplianceDetailModel()!=null) {
						ApplianceDetailModel app=pdmobj.getApplianceDetailModel();
						ApplianceDetailModel dbAppliance=applianceRepository.findOne(app.getApplianceId()); 
						if(dbAppliance!=null) {
							 JSONObject jsonObject=new JSONObject();
							 /**
							  * Get username and password
							  */
							 jsonObject = getUserNamePassword(pdmobj,jsonObject);
							 
							/**
							 * Session close is true
							 */
							if(pdmobj.isSessionClose()) {
								    jsonObject.put("action", "close_session");
								    pdmobj=closeSession(pdmobj, "restorePartition",jsonObject);
									if(pdmobj.getMessage()!=null && pdmobj.getStatus().equalsIgnoreCase("Completed")) {
										jsonObject.remove("action");
										
										/**
										 * File being upload in below method
										 */
										//pdmobj=getUploadedFileIdForRestore(restorePartitionModel, pdmobj);
										if(!StringUtils.isEmpty(pdmobj.getCode()) && pdmobj.getCode().equalsIgnoreCase("200")) {
											jsonObject.put("backupFile", pdmobj.getMessage());
											if(pdmobj.isCheckIntegrity()) {
												jsonObject.put("checkIntegrity", pdmobj.isCheckIntegrity());
											}
											jsonObject.put("nodeId", pdmobj.getNodeId());
											response=restClient.invokePUTMethodForOperations("https://"+pdm.getApplianceDetailModel().getIpAddress()+"/liquidsa/restore_partition/"+pdm.getPartitionName()+"",jsonObject);											
											isSessionCloseFailed=false;
										}
									}else {
										isSessionCloseFailed=true;
									}
							}else {
								/**
								 * File being upload in below method
								 */
								String username=jsonObject.getString("username");
								String password=jsonObject.getString("password");
								pdmobj.setUsername(username);
								pdmobj.setPassword(password);
								//pdmobj=getUploadedFileIdForRestore(restorePartitionModel, pdmobj);
								
								if(!StringUtils.isEmpty(pdmobj.getCode()) && pdmobj.getCode().equalsIgnoreCase("200")) {
									jsonObject.put("backupFile", pdmobj.getMessage());
									if(pdmobj.isCheckIntegrity()) {
										jsonObject.put("checkIntegrity", pdmobj.isCheckIntegrity());
									}
									jsonObject.put("nodeId", pdmobj.getNodeId());
									response=restClient.invokePUTMethodForOperations("https://"+pdm.getApplianceDetailModel().getIpAddress()+"/liquidsa/restore_partition/"+pdm.getPartitionName()+"",jsonObject);											
									isSessionCloseFailed=false;
								}
							}
							
							if(response!=null && response.getBody()!=null && response.getBody().contains("success") && isSessionCloseFailed==false) {
									pdm=partitionRepository.findOne(pdmobj.getPartitionId());
									pdm.setMessage("RestorePartition Initiated successfully.");
									pdm.setErrorMessage("");
									pdm.setLastOperationPerformed("restorePartition");
									pdm.setLastOperationStatus("In-Progress");
									pdm.setCode("200");
									ObjectMapper mapper = new ObjectMapper();
									JsonNode root = mapper.readTree(response.getBody());
									if (!root.isNull()) {
										updateInProgressActivity(pdm, loggedInUser, root);
									}
									 partitionRepository.save(pdm);
									 PartitionData data=partitionDataRepository.getPartitionData(String.valueOf(pdm.getPartitionId()));
									 data.setNodeId(String.valueOf(pdmobj.getNodeId()));
									 partitionDataRepository.save(data);
							}else {
								if(isSessionCloseFailed==false) {
								pdm=getErrorMessage(response, pdm,loggedInUser,"restorePartition");
								partitionRepository.save(pdm);
								}
							}
						}
					}
					partitionList.add(pdm);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during restorePartition in method restorePartition"+e.getMessage());
		}
		return partitionList;
	}
	
	public PartitionDetailModel closeSession(PartitionDetailModel detailModel,String type, JSONObject jsonObject) {
		String loggedInUser = userAttributes.getlogInUserName();
		try {
				ResponseEntity<String>	closeSessionresponse=restClient.invokePUTMethodForOperations("https://"+detailModel.getApplianceDetailModel().getIpAddress()+"/liquidsa/partition/"+detailModel.getPartitionName()+"",jsonObject);
				if(closeSessionresponse!=null && closeSessionresponse.getBody()!=null) {
					ObjectMapper mapper = new ObjectMapper();
					JsonNode root = mapper.readTree(closeSessionresponse.getBody());
					Thread.sleep(15000);
					detailModel=getStatusFromJobId(detailModel, root, loggedInUser, "Session Close");
					if(detailModel.getMessage()!=null && !StringUtils.isEmpty(detailModel.getStatus()) && detailModel.getStatus().equalsIgnoreCase("Completed")) {
						detailModel.setMessage("success");
						detailModel.setErrorMessage("Close session successfully completed");
						detailModel.setLastOperationPerformed(type);
						detailModel.setLastOperationStatus("Completed");
						detailModel.setCode("200");
					}else {
						detailModel=partitionRepository.findOne(detailModel.getPartitionId());
						detailModel.setMessage("Failed");
						detailModel.setErrorMessage("Delete Partition failed due to close session");
						detailModel.setLastOperationPerformed("Delete Partition");
						detailModel.setLastOperationStatus("Failed");
						detailModel.setCode("11032");
						partitionRepository.save(detailModel);
					}
			}else {
				detailModel=getErrorMessage(closeSessionresponse, detailModel,loggedInUser,"Close Session");
				partitionRepository.save(detailModel);
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during session close in partitionServiceIMPL class in method closeSession");
		}
		return detailModel;
	}
	
	private PartitionDetailModel getUploadedFileIdForRestore(PartitionDetailModel restorePartitionModel,PartitionDetailModel backupFrom, JSONObject jsonObject,MultipartFile file) {
		try {
			if(backupFrom==null) {
				restorePartitionModel=partitionRestoreFileUpload(restorePartitionModel,file,jsonObject);
			}else {
					PartitionDetailModel pdm=partitionRepository.findOne(Long.parseLong(backupFrom.getFromPartitionId()));
					pdm.setUsername(backupFrom.getFromRestoreUsername());
					pdm.setPassword(backupFrom.getFromRestorePassword());
					CaviumResponseModel	responseModel = downloadConfigFileURL(pdm,"backup_partition");
					if(responseModel!=null && responseModel.getResponseCode().equalsIgnoreCase("200")) {
						File filee=downloadConfigFile(responseModel.getResponseMessage(), backupFrom.getPartitionName());
						restorePartitionModel=uploadFileforPartition(restorePartitionModel,"RestorePartition",filee);	
					}else {
						restorePartitionModel.setCode(responseModel.getResponseCode());
						restorePartitionModel.setErrorMessage(responseModel.getResponseMessage());
					}
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getUploadedFileIdForRestore"+e.getMessage());
		}
		return restorePartitionModel;
	}

	@Override
	public List<PartitionDetailModel> getListOfPartitionsByApplianceID(String loggedInUser, Long applainceId) {
		// TODO Auto-generated method stub
		List<PartitionDetailModel> partlist=null;
		try {
				partlist=partitionRepository.getListOfPartitionByApplianceID(applainceId);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getListOfPartitionsByApplianceID"+e.getMessage());
		}
		return partlist;
	}
	
	private String[] removeNullfromArray(String[] arr) {
		try {
			List<String> list = new ArrayList<String>();
			for(String s : arr) {
			       if(s != null && s.length() > 0) {
			          list.add(s);
			       }
			    }

			arr = list.toArray(new String[list.size()]);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return arr;
	}
	
	private PartitionETH setEditDataForNetworkConfig(PartitionETH eth,PartitionETH dbeth) {
		try {
			if(eth!=null && dbeth!=null) {
				if(!StringUtils.isEmpty(eth.getIp())) {
					dbeth.setIp(eth.getIp());
				}if(!StringUtils.isEmpty(eth.getAddress())) {
					dbeth.setAddress(eth.getAddress());
				}if(!StringUtils.isEmpty(eth.getGateway())) {
					dbeth.setGateway(eth.getGateway());
				}if(!StringUtils.isEmpty(eth.getHostname())) {
					dbeth.setHostname(eth.getHostname());
				}if(!StringUtils.isEmpty(eth.getSubnet())) {
					dbeth.setSubnet(eth.getSubnet());
				}if(!StringUtils.isEmpty(eth.getVlan())) {
					dbeth.setVlan(eth.getVlan());
				}if(eth.isDhcp()!=dbeth.isDhcp()) {
					dbeth.setDhcp(eth.isDhcp());
				}if(eth.isDisableEth1()!=dbeth.isDisableEth1()) {
					dbeth.setDisableEth1(eth.isDisableEth1());
				}if(eth.isStaticMac()!=dbeth.isStaticMac()) {
					dbeth.setStaticMac(eth.isStaticMac());
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during setEditDataForNetworkConfig"+e.getMessage());
		}
		return dbeth;
	}
	
	public List<PartitionDetailModel> setPartitionDataIntoPartitionModel(List<PartitionDetailModel> listPartitionDetailModel)
	{
		try {
    		for(PartitionDetailModel pdm: listPartitionDetailModel){
    			ApplianceDetailModel app=pdm.getApplianceDetailModel();
    			pdm.setApplianceId(app.getApplianceId());
    			pdm.setApplianceName(app.getApplianceName());
    			pdm.setIpAddress(app.getIpAddress());
    			pdm.setCredentialSaved(app.isCredentialSaved());
				PartitionData data=partitionDataRepository.getPartitionData(String.valueOf(pdm.getPartitionId()));
    			if(data!=null) {
    				if(data.getMaxKeys()!=null && data.getOccupiedSessionKeys()!=null && data.getOccupiedTokenKeys()!=null) {
    					Integer keys=data.getMaxKeys()-data.getOccupiedSessionKeys()-data.getOccupiedTokenKeys();
        				data.setKeysUsage(keys);
    				}
    				Integer maxKeys=data.getMaxKeys();
    				Integer occupiedSessionKeys=data.getOccupiedSessionKeys();
    				Integer	occupiedTokenKeys=data.getOccupiedTokenKeys();
    				Integer sslContextUsed=data.getOccupiedSslCtxs();
    				Integer totalsslContext=data.getTotalSslCtxs();
    				if(totalsslContext!=null && sslContextUsed!=null){
    				Integer sslContextAvaliabe=totalsslContext-sslContextUsed;
    				data.setSslContextAvaliable(sslContextAvaliabe);
    				}
    				if(maxKeys!=null && occupiedSessionKeys!=null && occupiedTokenKeys!=null){
    				Integer keysAvaliable=maxKeys-occupiedSessionKeys-occupiedTokenKeys;
    				Integer keysUsed=occupiedSessionKeys+occupiedTokenKeys;		
    				data.setKeysAvaliable(keysAvaliable);
    				data.setKeysUsed(keysUsed);
    				}
    				pdm.setPartitionData(data);
    			}
				}
				} catch (Exception e) {
					logger.error("Error occured during method setPartitionDataIntoPartitionModel in class PartitionServiceImpl "+e.getMessage());
	}
	
	return listPartitionDetailModel;
	}

	@Override
	public List<PartitionDetailModel> getPartitionInfoData(List<PartitionDetailModel> partitionDetailModel) {
		// TODO Auto-generated method stub
		ResponseEntity<String> response=null;
		try {
			for(PartitionDetailModel part : partitionDetailModel) {
				response=restClient.invokeGETMethod("https://"+part.getApplianceDetailModel().getIpAddress()+"/liquidsa/partitions");
				if(response!=null && response.getBody()!=null && response.getBody().contains("success")) {
					PartitionData pd=new PartitionData();
					ObjectMapper mapper = new ObjectMapper();
					JsonNode root = mapper.readTree(response.getBody());
						if(!root.isNull()){
						JsonNode dataNode = root.path("data");
						if(!dataNode.isNull()){
									Integer availableUserKeys=dataNode.path("totalKeys").asInt() - dataNode.path("occupiedKeys").asInt() ;
									Integer avaliableSSLContextKeys= dataNode.path("totalContexts").asInt() - dataNode.path("occupiedContexts").asInt() ;
									Integer avaliableAcclDevices= dataNode.path("totalAcclrDev").asInt() - dataNode.path("occupiedAcclrDev").asInt() ;
									pd.setKeysAvaliable(availableUserKeys);
									pd.setSslContextAvaliable(avaliableSSLContextKeys);
									pd.setAcclrDevicesAvaliable(avaliableAcclDevices);
							}
						}
						ResponseEntity<String>	responsee=restClient.invokeGETMethod("https://"+part.getApplianceDetailModel().getIpAddress()+"/liquidsa/partition/"+part.getPartitionName()+"");
						if(responsee!=null && responsee.getBody()!=null && responsee.getBody().contains("success")) {
							ObjectMapper mapperr = new ObjectMapper();
							JsonNode roott = mapperr.readTree(responsee.getBody());
								if(!roott.isNull()){
								JsonNode dataNodee = roott.path("data");
									if(!dataNodee.isNull()){
									Integer allocatedUserKeys=dataNodee.path("maxKeys").asInt();
									Integer allocatedSSLContexts=dataNodee.path("totalSslCtxs").asInt();
									Integer allocatedAccelDevice=dataNodee.path("maxAcclrDevCount").asInt();
									pd.setAllocatedUserKeys(allocatedUserKeys);
									pd.setAllocatedSSLContexts(allocatedSSLContexts);
									pd.setAllocatedAccelDevices(allocatedAccelDevice);
									}
								}
						}
						part.setPartitionData(pd);
				}	
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getPartitionInfoData");
		}
		return partitionDetailModel;
	}
	/**
	 * This method is use to perform resize partition
	 */
	@Override
	public PartitionDetailModel resizePartitions(PartitionDetailModel pdmobj) {
		// TODO Auto-generated method stub
		boolean isSessionCloseFailed = false;
		String loggedInUser = userAttributes.getlogInUserName();
		try {
			JSONObject jsonObject=new JSONObject();
			ResponseEntity<String> response = null;
			PartitionDetailModel pdm = partitionRepository.findOne(pdmobj.getPartitionId());
			if (pdm != null && pdm.getPartitionId() > 0 && pdmobj.getApplianceDetailModel() != null) {
				ApplianceDetailModel app = pdmobj.getApplianceDetailModel();
				ApplianceDetailModel dbAppliance = applianceRepository.findOne(app.getApplianceId());
				if (dbAppliance != null) {
					 jsonObject = getUserNamePassword(pdmobj,jsonObject);
						if(pdmobj.isSessionClose()) {
							jsonObject.put("action", "close_session");
							ResponseEntity<String>	closeSessionresponse=restClient.invokePUTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/partition/"+pdmobj.getPartitionName()+"",jsonObject);
							if(closeSessionresponse!=null && closeSessionresponse.getBody()!=null) {
								ObjectMapper mapper = new ObjectMapper();
								JsonNode root = mapper.readTree(closeSessionresponse.getBody());
								Thread.sleep(15000);
								pdm=getStatusFromJobId(pdm, root, loggedInUser, "Session Close");
								if(pdm.getMessage()!=null && pdm.getStatus().equalsIgnoreCase("Completed")) {
									PartitionData pd=pdmobj.getPartitionData();
									if(pd!=null) {
										jsonObject.remove("action");
										if(pd.getModifiedUserKeys()!=null && pd.getModifiedUserKeys()!=0) {
											jsonObject.put("keys", pd.getModifiedUserKeys());
											jsonObject.put("incrementKeys", pd.isIncrementKeys());
										}
										if(pd.getModifiedSSLContexts()!=null && pd.getModifiedSSLContexts()!=0) {
											jsonObject.put("sslContexts", pd.getModifiedSSLContexts());
											jsonObject.put("incrementSslContexts", pd.isIncrementSslContexts());
										}
										if(pd.getModifiedAccelDevices()!=null && pd.getModifiedAccelDevices()!=0) {
											jsonObject.put("acclrDev", pd.getModifiedAccelDevices());
											jsonObject.put("incrementAcclrDev", pd.isIncrementAcclrDev());
										}
										jsonObject.put("backup", pd.isBackup());
										response = restClient.invokePUTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/partition/"+pdmobj.getPartitionName()+"", jsonObject);
										isSessionCloseFailed=false;
									}else {
										pdm.setMessage("Failed");
										pdm.setErrorMessage("Resize Partition failed due to no data available");
										pdm.setLastOperationPerformed("Resize Partition");
										pdm.setLastOperationStatus("Failed");
										partitionRepository.save(pdm);
									}
									
								}else {
									isSessionCloseFailed=true;
									pdm.setMessage("Failed");
									pdm.setErrorMessage("Resize Partition failed due to close session");
									pdm.setLastOperationPerformed("Resize Partition");
									pdm.setLastOperationStatus("Failed");
									pdm.setCode("11032");
									partitionRepository.save(pdm);
								}
							}
						}else {
							PartitionData pd=pdmobj.getPartitionData();
							if(pd!=null) {
								jsonObject.remove("action");
								if(pd.getModifiedUserKeys()!=null && pd.getModifiedUserKeys()!=0) {
									jsonObject.put("keys", pd.getModifiedUserKeys());
									jsonObject.put("incrementKeys", pd.isIncrementKeys());
								}
								if(pd.getModifiedSSLContexts()!=null && pd.getModifiedSSLContexts()!=0) {
									jsonObject.put("sslContexts", pd.getModifiedSSLContexts());
									jsonObject.put("incrementSslContexts", pd.isIncrementSslContexts());
								}
								if(pd.getModifiedAccelDevices()!=null && pd.getModifiedAccelDevices()!=0) {
									jsonObject.put("acclrDev", pd.getModifiedAccelDevices());
									jsonObject.put("incrementAcclrDev", pd.isIncrementAcclrDev());
								}
								jsonObject.put("backup", pd.isBackup());
								response = restClient.invokePUTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/partition/"+pdmobj.getPartitionName()+"", jsonObject);
								isSessionCloseFailed=false;
							}else {
								pdm.setMessage("Failed");
								pdm.setErrorMessage("Resize Partition failed due to no data available");
								pdm.setLastOperationPerformed("Resize Partition");
								pdm.setLastOperationStatus("Failed");
								partitionRepository.save(pdm);
							}
						}
					if(response!=null && response.getBody()!=null && isSessionCloseFailed==false) {
						if(response.getBody().contains("success")) {
							pdm.setMessage("Resize Partition Initiated successfully.");
							pdm.setErrorMessage("");
							pdm.setLastOperationPerformed("Resize Partition");
							pdm.setLastOperationStatus("In-Progress");
							pdm.setCode("200");
							ObjectMapper mapper = new ObjectMapper();
							JsonNode root = mapper.readTree(response.getBody());
							if (!root.isNull()) {
								updateInProgressActivity(pdm, loggedInUser, root);
							}
							partitionRepository.save(pdm);
						}else {
							if(isSessionCloseFailed==false) {
								pdm=getErrorMessage(response, pdm,loggedInUser,"Resize Partition");
								partitionRepository.save(pdm);
							}
						}
					}else {
						if(isSessionCloseFailed==false) {
							pdm=getErrorMessage(response, pdm,loggedInUser,"Resize Partition");
							partitionRepository.save(pdm);
							}
						}
					}
				}
				pdmobj=pdm;
			}catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during resizePartitions");
		}
		return pdmobj;
	}

	/**
	 * This method is used to setPartitionMonitorConfig
	 */
	@Override
	public List<PartitionDetailModel> setPartitionMonitorConfig(List<PartitionDetailModel> partitionDetailModel) {
		// TODO Auto-generated method stub
		String loggedInUser = userAttributes.getlogInUserName();
		List<PartitionDetailModel> listPartition=new ArrayList<>();
		boolean isSessionCloseFailed = false;
		JSONObject jsonObject =new JSONObject();
		try {
			for(PartitionDetailModel pdmobj : partitionDetailModel) {
				ResponseEntity<String> response = null;
				PartitionDetailModel pdm = partitionRepository.findOne(pdmobj.getPartitionId());
				if (pdm != null && pdm.getPartitionId() > 0 && pdmobj.getApplianceDetailModel() != null) {
					ApplianceDetailModel app = pdmobj.getApplianceDetailModel();
					ApplianceDetailModel dbAppliance = applianceRepository.findOne(app.getApplianceId());
					JSONObject jsonRequest=new JSONObject();
					if (dbAppliance != null) {
						 jsonObject = getUserNamePassword(pdmobj,jsonObject);
							if(pdmobj.isSessionClose()) {
								jsonObject.put("action", "close_session");
								ResponseEntity<String>	closeSessionresponse=restClient.invokePUTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/partition/"+pdmobj.getPartitionName()+"",jsonObject);
								if(closeSessionresponse!=null && closeSessionresponse.getBody()!=null) {
									ObjectMapper mapper = new ObjectMapper();
									JsonNode root = mapper.readTree(closeSessionresponse.getBody());
									Thread.sleep(15000);
									pdm=getStatusFromJobId(pdm, root, loggedInUser, "Session Close");
									if(pdm.getMessage()!=null && pdm.getStatus().equalsIgnoreCase("Completed")) {
										jsonObject.remove("action");
										if(pdmobj.getPartitionMonitorData()!=null) {
											JSONObject	josnObject=new JSONObject(pdmobj.getPartitionMonitorData());
											String jsonObj=josnObject.toString();
											jsonObj=jsonObj.toString().replaceAll( "samplecount","sample-count");
											jsonObj=jsonObj.replaceAll("interfacename","interface-name");
											josnObject=new JSONObject(jsonObj);
											jsonObject.put("config", josnObject);
										}
										response = restClient.invokePOSTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/monitor/partition/"+pdmobj.getPartitionName()+"",jsonRequest);
										isSessionCloseFailed=false;
									}else {
										isSessionCloseFailed=true;
										pdm.setMessage("Failed");
										pdm.setErrorMessage("Partition setMonitorConfig failed due to close session");
										pdm.setLastOperationPerformed("Partition setMonitorConfig");
										pdm.setLastOperationStatus("Failed");
										pdm.setCode("11032");
										partitionRepository.save(pdm);
									}
								}
							}else {
								if(pdmobj.getPartitionMonitorData()!=null) {
									JSONObject	josnObject=new JSONObject(pdmobj.getPartitionMonitorData());
									String jsonObj=josnObject.toString();
									jsonObj=jsonObj.toString().replaceAll( "samplecount","sample-count");
									jsonObj=jsonObj.replaceAll("interfacename","interface-name");
									josnObject=new JSONObject(jsonObj);
									jsonObject.put("config", josnObject);
								}
								response = restClient.invokePOSTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/monitor/partition/"+pdmobj.getPartitionName()+"",jsonObject);
								isSessionCloseFailed=false;
							}
						if(response!=null && response.getBody()!=null && isSessionCloseFailed==false) {
							if(response.getBody().contains("success")) {
								pdm.setMessage("Partition Monitor Config Initiated successfully.");
								pdm.setErrorMessage("");
								pdm.setLastOperationPerformed("setMonitorConfig");
								pdm.setLastOperationStatus("In-Progress");
								pdm.setCode("200");
								ObjectMapper mapper = new ObjectMapper();
								JsonNode root = mapper.readTree(response.getBody());
								if (!root.isNull()) {
									updateInProgressActivity(pdm, loggedInUser, root);
								}
								partitionRepository.save(pdm);
							}else {
								if(isSessionCloseFailed==false) {
									pdm=getErrorMessage(response, pdm,loggedInUser,"Partition Monitor Config");
									partitionRepository.save(pdm);
								}
							}
						}else {
							if(isSessionCloseFailed==false) {
								pdm=getErrorMessage(response, pdm,loggedInUser,"Partition Monitor Config");
								partitionRepository.save(pdm);
							}
						}
					}
				}else {
					pdm=pdmobj;
					pdm.setCode("408");
					pdm.setErrorMessage("Partition "+pdm.getPartitionName()+" does not exists.");
				}
				listPartition.add(pdm);
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error(
					"Error occured during Partition MonitorStats in method getPartitionMonitorStats of class PartitionServiceImpl "
							+ e.getMessage());
		}
		return listPartition;
	}
	/**
	 * This methiod is used to get partition monitor stats data
	 */
	@Override
	public List<PartitionDetailModel> getPartitionMonitorData(List<PartitionDetailModel> partitionDetailModels) {
		// TODO Auto-generated method stub
		String loggedInUser = userAttributes.getlogInUserName();
		List<PartitionDetailModel> listPartition=new ArrayList<>();
		boolean isSessionCloseFailed = false;
		JSONObject jsonObject =new JSONObject();
		try {
			for(PartitionDetailModel pdmobj : partitionDetailModels) {
				ResponseEntity<String> response = null;
				PartitionDetailModel pdm = partitionRepository.findOne(pdmobj.getPartitionId());
				if (pdm != null && pdm.getPartitionId() > 0 && pdmobj.getApplianceDetailModel() != null) {
					ApplianceDetailModel app = pdmobj.getApplianceDetailModel();
					ApplianceDetailModel dbAppliance = applianceRepository.findOne(app.getApplianceId());
					if (dbAppliance != null) {
						 jsonObject = getUserNamePassword(pdmobj,jsonObject);
							if(pdmobj.isSessionClose()) {
								jsonObject.put("action", "close_session");
								ResponseEntity<String>	closeSessionresponse=restClient.invokePUTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/partition/"+pdmobj.getPartitionName()+"",jsonObject);
								if(closeSessionresponse!=null && closeSessionresponse.getBody()!=null) {
									ObjectMapper mapper = new ObjectMapper();
									JsonNode root = mapper.readTree(closeSessionresponse.getBody());
									Thread.sleep(15000);
									pdm=getStatusFromJobId(pdm, root, loggedInUser, "Session Close");
									if(pdm.getMessage()!=null && pdm.getStatus().equalsIgnoreCase("Completed")) {
										jsonObject.remove("action");
										response = restClient.invokeGETMethod("https://"+app.getIpAddress()+"/liquidsa/monitor/partition/"+pdmobj.getPartitionName()+"");
										isSessionCloseFailed=false;
									}else {
										isSessionCloseFailed=true;
										pdm.setMessage("Failed");
										pdm.setErrorMessage("Partition MonitorStats failed due to close session");
										pdm.setLastOperationPerformed("Partition MonitorStats");
										pdm.setLastOperationStatus("Failed");
										pdm.setCode("11032");
										partitionRepository.save(pdm);
									}
								}
							}else {
								response = restClient.invokeGETMethod("https://"+app.getIpAddress()+"/liquidsa/monitor/partition/"+pdmobj.getPartitionName()+"");
								isSessionCloseFailed=false;
							}
						if(response!=null && response.getBody()!=null && isSessionCloseFailed==false) {
							if(response.getBody().contains("success")) {
								ObjectMapper mapper = new ObjectMapper();
								JsonNode root = mapper.readTree(response.getBody());
								if(root.has("data")) {
									JsonNode dataNode = root.path("data");
									if(dataNode.size() > 0) {
										String data=dataNode.toString().replaceAll("sample-count", "samplecount");
										data=data.replaceAll("interface-name", "interfacename");
										PartitionMonitorData pdata=mapper.readValue(data, PartitionMonitorData.class);
										pdm.setPartitionMonitorData(pdata);
										pdm.setMessage("success");
										pdm.setCode("200");
										pdm.setErrorMessage("");
									}else {
										 PartitionMonitorPMNCData cpu=new PartitionMonitorPMNCData();
										 PartitionMonitorCWI info=new PartitionMonitorCWI();
										 cpu.setInfo(info);
										 cpu.setWarn(info);
										 cpu.setCrit(info);
										 PartitionMonitorPMNCData pcpu=new PartitionMonitorPMNCData();
										 cpu.setInfo(info);
										 cpu.setWarn(info);
										 cpu.setCrit(info);
										 PartitionMonitorPMNCData memory=new PartitionMonitorPMNCData();
										 cpu.setInfo(info);
										 cpu.setWarn(info);
										 cpu.setCrit(info);
										 PartitionNetworkMonitorStats network=new PartitionNetworkMonitorStats();
										 network.setInterfacename("eth0");
										 PartitionMonitorData mdata=new PartitionMonitorData();
										 mdata.setCpu(cpu);
										 mdata.setMemory(memory);
										 mdata.setNetwork(network);
										 mdata.setPcpu(pcpu);
										 pdm.setPartitionMonitorData(mdata);
									}
								}else {
									pdm.setMessage("No data to display");
									pdm.setCode("200");
								}
								
							}else {
								if(isSessionCloseFailed==false) {
									pdm=getErrorMessage(response, pdm,loggedInUser,"Partition Monitor Stats");
									partitionRepository.save(pdm);
								}
							}
						}else {
							if(isSessionCloseFailed==false) {
								pdm=getErrorMessage(response, pdm,loggedInUser,"Partition Monitor Stats");
								partitionRepository.save(pdm);
							}
						}
					}
				}else {
					pdm=pdmobj;
					pdm.setCode("408");
					pdm.setErrorMessage("Partition "+pdm.getPartitionName()+" does not exists.");
				}
				listPartition.add(pdm);
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error(
					"Error occured during Partition MonitorStats in method getPartitionMonitorStats of class PartitionServiceImpl "
							+ e.getMessage());
		}
		return listPartition;
	}

	@Override
	public List<PartitionDetailModel> getPartitionMonitorStats(List<PartitionDetailModel> partitionDetailModels) {
		// TODO Auto-generated method stub
		String loggedInUser = userAttributes.getlogInUserName();
		List<PartitionDetailModel> listPartition=new ArrayList<>();
		boolean isSessionCloseFailed = false;
		JSONObject jsonObject =new JSONObject();
		try {
			for(PartitionDetailModel pdmobj : partitionDetailModels) {
				ResponseEntity<String> response = null;
				PartitionDetailModel pdm = partitionRepository.findOne(pdmobj.getPartitionId());
				if (pdm != null && pdm.getPartitionId() > 0 && pdmobj.getApplianceDetailModel() != null) {
					ApplianceDetailModel app = pdmobj.getApplianceDetailModel();
					ApplianceDetailModel dbAppliance = applianceRepository.findOne(app.getApplianceId());
					if (dbAppliance != null) {
						 jsonObject = getUserNamePassword(pdmobj,jsonObject);
							if(pdmobj.isSessionClose()) {
								jsonObject.put("action", "close_session");
								ResponseEntity<String>	closeSessionresponse=restClient.invokePUTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/partition/"+pdmobj.getPartitionName()+"",jsonObject);
								if(closeSessionresponse!=null && closeSessionresponse.getBody()!=null) {
									ObjectMapper mapper = new ObjectMapper();
									JsonNode root = mapper.readTree(closeSessionresponse.getBody());
									Thread.sleep(15000);
									pdm=getStatusFromJobId(pdm, root, loggedInUser, "Session Close");
									if(pdm.getMessage()!=null && pdm.getStatus().equalsIgnoreCase("Completed")) {
										jsonObject.remove("action");
										response = restClient.invokeGETMethod("https://"+app.getIpAddress()+"/liquidsa/monitor_stats/partition/"+pdmobj.getPartitionName()+"");
										isSessionCloseFailed=false;
									}else {
										isSessionCloseFailed=true;
										pdm.setMessage("Failed");
										pdm.setErrorMessage("Partition MonitorStats failed due to close session");
										pdm.setLastOperationPerformed("Partition MonitorStats");
										pdm.setLastOperationStatus("Failed");
										pdm.setCode("11032");
										partitionRepository.save(pdm);
									}
								}
							}else {
								response = restClient.invokeGETMethod("https://"+app.getIpAddress()+"/liquidsa/monitor_stats/partition/"+pdmobj.getPartitionName()+"");
								isSessionCloseFailed=false;
							}
						if(response!=null && response.getBody()!=null && isSessionCloseFailed==false) {
							if(response.getBody().contains("success")) {
								ObjectMapper mapper = new ObjectMapper();
								JsonNode root = mapper.readTree(response.getBody());
								if(root.has("data")) {
									JsonNode dataNode = root.path("data");
									pdm.setMessage(dataNode.toString());
									pdm.setCode("200");
									pdm.setErrorMessage("");
								}else {
									pdm.setMessage("No data to display");
									pdm.setCode("200");
								}
								
							}else {
								if(isSessionCloseFailed==false) {
									pdm=getErrorMessage(response, pdm,loggedInUser,"Partition MonitorStats");
									partitionRepository.save(pdm);
								}
							}
						}else {
							if(isSessionCloseFailed==false) {
								pdm=getErrorMessage(response, pdm,loggedInUser,"Partition MonitorStats");
								partitionRepository.save(pdm);
							}
						}
					}
				}else {
					pdm=pdmobj;
					pdm.setCode("408");
					pdm.setErrorMessage("Partition "+pdm.getPartitionName()+" does not exists.");
				}
				listPartition.add(pdm);
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error(
					"Error occured during Partition MonitorStats in method getPartitionMonitorStats of class PartitionServiceImpl "
							+ e.getMessage());
		}
		return listPartition;
	}
	
	@Override
	public List<PartitionDetailModel> getListOfNotAssignedPartitions(String loggedInUser) {
		// TODO Auto-generated method stub
		List<PartitionDetailModel> listPartitions = null;
		try {
			UserDetailModel objUserDetailModel=userRepository.findOne(loggedInUser);
			if(objUserDetailModel!=null && objUserDetailModel.getObjUserACLDetailsModel().getAclName().equals(env.getProperty("user.superadmin"))) {
				Long aclId=objUserDetailModel.getObjUserACLDetailsModel().getId();
				listPartitions = partitionRepository.getListOfAllNotAssignedPartitions(aclId);
			}else {
				listPartitions = partitionRepository.getListOfNotAssignedPartitionsByGroupId(loggedInUser);
			}
			listPartitions=setObjectsInPartitionDetailModel(listPartitions);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return listPartitions;
	}

	@Override
	public void updateEth01IpAddress(PartitionETH partitionETH) {
		String ipAddress=partitionETH.getIp();
		Long partitionId=partitionETH.getPartitionDetailModel().getPartitionId();
		partitionETHRepository.udpateEth01IpAddress(ipAddress,partitionId);
	}
	
	
	@Override
	public void updateNodeIdforPartitionId(Integer nodId,Long partitionId) {
		 
		String nodeId=nodId.toString();
		partitionDataRepository.updateNodeIdforPartitionId(nodeId,partitionId);
	}
	
	@Override
	public void savePartitionStatsDetails(Long partitionId) {
		// TODO Auto-generated method stub
		ResponseEntity<String> response=null;
		PartitionStatsDetails partitionStatsDetails=null;
		PartitionDetailModel  partitionDetailModels=partitionRepository.findOne(partitionId);
		try {
			response=restClient.invokeGETMethod("https://"+partitionDetailModels.getApplianceDetailModel().getIpAddress()+"/liquidsa/partition_stats/"+partitionDetailModels.getPartitionName()+"");
			if (response != null && response.getBody() != null && response.getBody().contains("success")) {
			 
				ObjectMapper mapper = new ObjectMapper();
				JSONObject jsonObject=new JSONObject(response.getBody());
				Object dataObj = jsonObject.get("data");
		 		JSONObject dataObject = (JSONObject) dataObj;
				Object obj = dataObject.get("vmstats");
				JSONObject vmstatsObject = (JSONObject) obj;
				
					vmstatsObject.put("linkStatusEth0",vmstatsObject.get("linkStatus(eth0)"));
					vmstatsObject.put("diskSpaceInMb",vmstatsObject.get("diskSpace(mb)"));
					vmstatsObject.put("linkStatusEth1",vmstatsObject.get("linkStatus(eth1)"));
					vmstatsObject.put("swapStatsInMb",vmstatsObject.get("swapStats(mb)"));
					vmstatsObject.put("ramStatsInMb",vmstatsObject.get("ramStats(mb)"));
					vmstatsObject.put("cpuUsagePercentage",vmstatsObject.get("cpuUsage(%)"));
					vmstatsObject.remove("linkStatus(eth0)");
					vmstatsObject.remove("diskSpace(mb)");
					vmstatsObject.remove("linkStatus(eth1)");
					vmstatsObject.remove("swapStats(mb)");
					vmstatsObject.remove("ramStats(mb)");
					vmstatsObject.remove("cpuUsage(%)");
					partitionStatsDetails=mapper.readValue(jsonObject.toString(),PartitionStatsDetails.class);
					partitionStatsDetails.setPartitionId(partitionId);
					savePartitionStatsGraphDetails(partitionStatsDetails);
			 } 
			 
		} catch (Exception e) {
			logger.error("Error occured during method savePartitionStatsDetails in PartitionServiceImpl class :: " +e.getMessage());
		}
	 }
	
	public void savePartitionStatsGraphDetails(PartitionStatsDetails partitionStatsDetails ) {
		try {
			Long partitionId=partitionStatsDetails.getPartitionId();
			List<PartitionStatsDetails> PartitionStatsDetailsList= partitionStatsRepository.getPartitionStats(partitionId);
			
			if(PartitionStatsDetailsList.size() == 5) {
				partitionStatsRepository.delete(PartitionStatsDetailsList.get(4).getId());
				partitionStatsDetails=partitionStatsRepository.save(partitionStatsDetails);
			}else {
			 partitionStatsRepository.save(partitionStatsDetails);
				}
		} catch (Exception e) {
		  logger.error("Error occured due to db error inside savePartitionStatsGraphDetails ::" + e.getMessage());
		 }
	}
	
	public List<PartitionStatsDetails> getPartitionStatsGraphDetails(Long partitionId) {
		List<PartitionStatsDetails> PartitionStatsDetails=null;
		try {
		  PartitionStatsDetails= partitionStatsRepository.getPartitionStats(partitionId);
		} catch (Exception e) {	 
			logger.error("Error occured due to db error inside getPartitionStatsGraphDetails ::" + e.getMessage());
			 
		}
		return PartitionStatsDetails;
	}

	@Override
	public List<PartitionDetailModel> partitionRestore(List<PartitionDetailModel> partitionListDetailModel,
			PartitionDetailModel backupFrom, MultipartFile file) {
		boolean isSessionCloseFailed =false;
		List<PartitionDetailModel> partitionList=new ArrayList<>();
		String loggedInUser = userAttributes.getlogInUserName();
			try {
				for(PartitionDetailModel pdmobj:partitionListDetailModel) {
					ResponseEntity<String> response=null;
					PartitionDetailModel pdm=partitionRepository.findOne(pdmobj.getPartitionId());
					if(pdm!=null && pdm.getApplianceDetailModel()!=null) {
						ApplianceDetailModel app=pdm.getApplianceDetailModel();
						pdmobj.setApplianceDetailModel(app);
					    pdmobj.setPartitionName(pdm.getPartitionName());
					    JSONObject jsonObject=new JSONObject();
					    /**
						  * Get username and password
						  */
						 jsonObject = getUserNamePassword(pdmobj,jsonObject);
							/**
							 * Session close is true
							 */
							if(pdmobj.isSessionClose()) {
								    jsonObject.put("action", "close_session");
								    pdm=closeSession(pdm, "restorePartition",jsonObject);
									if(pdm.getMessage()!=null && pdm.getStatus().equalsIgnoreCase("Completed")) {
										jsonObject.remove("action");
										isSessionCloseFailed=false;
									}else {
										isSessionCloseFailed=true;
									}
								}
						if(isSessionCloseFailed==false) {
							pdmobj=getUploadedFileIdForRestore(pdmobj,backupFrom,jsonObject,file);
							if(!StringUtils.isEmpty(pdmobj.getCode()) && pdmobj.getCode().equalsIgnoreCase("200")) {
								jsonObject.put("backupFile", pdmobj.getMessage());
								if(pdmobj.isCheckIntegrity()) {
									jsonObject.put("checkIntegrity", pdmobj.isCheckIntegrity());
								}
								jsonObject.put("nodeId", pdmobj.getNodeId());
								response=restClient.invokePUTMethodForOperations("https://"+pdm.getApplianceDetailModel().getIpAddress()+"/liquidsa/restore_partition/"+pdm.getPartitionName()+"",jsonObject);											
								if(response!=null && response.getBody()!=null && response.getBody().contains("success")) {
									pdm=partitionRepository.findOne(pdmobj.getPartitionId());
									pdm.setMessage("RestorePartition Initiated successfully.");
									pdm.setErrorMessage("");
									pdm.setLastOperationPerformed("restorePartition");
									pdm.setLastOperationStatus("In-Progress");
									pdm.setCode("200");
									ObjectMapper mapper = new ObjectMapper();
									JsonNode root = mapper.readTree(response.getBody());
									if (!root.isNull()) {
										updateInProgressActivity(pdm, loggedInUser, root);
									}
									 partitionRepository.save(pdm);
									 PartitionData data=partitionDataRepository.getPartitionData(String.valueOf(pdm.getPartitionId()));
									 data.setNodeId(String.valueOf(pdmobj.getNodeId()));
									 partitionDataRepository.save(data);
								}else {
									pdm = getErrorMessage(response, pdm, loggedInUser, "restorePartition");
									partitionRepository.save(pdm);
								}
							}else {
								pdm.setCode(pdmobj.getCode());
								pdm.setErrorMessage(pdmobj.getErrorMessage());
								pdm.setLastOperationPerformed("Restore Partition");
								pdm.setLastOperationStatus("Failed");
								pdm.setMessage("");
								partitionRepository.save(pdm);
							}
						} 
						partitionList.add(pdm);
					}
				}
			} catch (Exception e) {
				// TODO: handle exception
				logger.error("Error occured during restore partition");
			}
		// TODO Auto-generated method stub
		return partitionList;
	}
	
	
	public PartitionDetailModel partitionRestoreFileUpload(PartitionDetailModel pdm,MultipartFile multipartFile,JSONObject jsonObject) {
		File convertedFile=null;
		try {
			MultiValueMap<String, Object> bodyMap = new LinkedMultiValueMap<>();
            convertedFile= CaviumUtil.convert(multipartFile);
            bodyMap.add("file", CaviumUtil.getUserFileResource(convertedFile));
            bodyMap.add("username", jsonObject.get("username"));
            bodyMap.add("password", jsonObject.get("password"));
            bodyMap.add("type", "RestorePartition");
            ResponseEntity<String>  response=restClient.invokePOSTMethodObject("https://"+pdm.getApplianceDetailModel().getIpAddress()+"/liquidsa/upload", bodyMap);
            if(response.getBody()!=null) {
            	ObjectMapper mapper = new ObjectMapper();
    			JsonNode root = mapper.readTree(response.getBody());
    			if(!root.isNull() && root.isArray()){
    				for(int i=0;i<root.size();i++){
    					String status = root.get(i).path("status").asText();
    					 if(status.equalsIgnoreCase("Success")){
    							String  uploadedFileID= root.get(i).path("uploadedFileID").asText();
    							pdm.setCode("200");
    							pdm.setMessage(uploadedFileID);
    							 }else {
    								 String loggedInUser = userAttributes.getlogInUserName();
    								 pdm = getErrorMessage(response, pdm, loggedInUser, "Upload for RestorePartition");
    							 }
    					}
    			}
            }else {
            	 String loggedInUser = userAttributes.getlogInUserName();
				 pdm = getErrorMessage(response, pdm, loggedInUser, "Upload for RestorePartition");
            }
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during file upload for restore partition."+e.getMessage());
		}finally {
			if(convertedFile!=null && convertedFile.exists()) {
				convertedFile.delete();
			}
		}
		return pdm;
	}
}
