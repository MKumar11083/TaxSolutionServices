/**
 * 
 */
package com.cavium.service.user;

import java.util.List;

import org.springframework.mail.MailException;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.user.ApplicationDetailModel;
import com.cavium.model.user.DesignationApplianceModel;
import com.cavium.model.user.PermisssionDetailModel;
import com.cavium.model.user.UserACLDetailsModel;
import com.cavium.model.user.UserDetailModel;
import com.cavium.model.user.UserGroupModel;
import com.cavium.utill.CaviumResponseModel;

/**
 * @author RK00490847
 * 
 */
public interface UserService {

	/*
	 *  createUser method is  used for creating new user
	 *   
	 *  @param userModel
	 *  		- Object of UserDetailModel
	 *    
	 *  @return responseModel
	 *  		- CaviumResponseModel Class object
	 */
	CaviumResponseModel createUser(UserDetailModel userModel,String pwdWithoutEncoded) throws MailException,Exception;

	/*
	 *  getUserGroups method is  used for fetch all UserGroups Details
	 *     
	 *  @return 
	 *  	- List of UserGroupModel
	 */
	List<UserGroupModel> getUserGroups();

	/*
	 *  listUsers method is used for fetch User Details.
	 *  
	 *  If userName,LatsName,firstName,userGroupId,userACLId,emailId.phoneNumber is blank then it will return list of all the users
	 *  else it will search the user based on the input from request like firstName etc
	 *    
	 *  @param userSearchModel
	 *  		- Object of UserDetailModel
	 *  
	 *  @return  listAllUsers
	 *  	- List of UserDetailModel
	 */
	List<UserDetailModel> listUsers(UserDetailModel userSearchModel,String GroupId,String createdBy);

	/*
	 *  getUserDetails method is  used for fetch user Detail based on userId
	 *     
	 *   @param userId
	 *  		- String Variable
	 *  
	 *  @return objUserDetailModel
	 *  	- object of UserDetailModel
	 */
	UserDetailModel getUserDetails(String userId);

	/*
	 *  modifyUserGroup method is used for update the group Details.
	 * 
	 *  @param userGroupModel
	 *  		- Object of UserGroupModel.
	 *  
	 *  @return CaviumResponseModel
	 *  		- CaviumResponseModel Object.
	 *  	 
	 */
	CaviumResponseModel modifyUser(UserDetailModel userModel);


	/*
	 *  deleteUser method is  used for delete the user Detail based on userid
	 *  
	 *   @param userId
	 *  		- String Variable  
	 *    
	 *  @return responseModel
	 *  	- object of CaviumResponseModel
	 */
	CaviumResponseModel deleteUser(String userId);

	/*
	 *  changePassword method is  used for change the password of user  
	 *  
	 *   @param userId
	 *  		- String Variable  
	 *   *   @param oldpassword
	 *  		- String Variable
	 *    
	 *  @return boolean variable
	 *  	 
	 */
	CaviumResponseModel changePassword(String userid, String oldPassword, String newPassword);

	/*
	 *  createUserGroup method is  used for creating the userGroup.
	 *  
	 *   @param userGrpModel
	 *  		- Object of UserGroupModel.
	 *    
	 *  @return CaviumResponseModel
	 *  		- object of CaviumResponseModel.
	 *  	 
	 */
	CaviumResponseModel createUserGroup(UserGroupModel userGrpModel);

	/*
	 *  getUserGroupData method is  used for fetch the userGroup.
	 *  
	 *  If roleName is blank in userGroup object then it will fetch all the userGorups .
	 *  if roleName is not blank them it will fetch Group details based on roleName.
	 *  
	 *   @param userGroup
	 *  		- Object of UserGroupModel.
	 *    
	 *  @return listUserGroupModel
	 *  		- List  of UserGroupModel Object.
	 *  	 
	 */
	List<UserGroupModel> getUserGroupData(UserGroupModel groupModel,String UserName);

	/*
	 *  deleteUserGroup method is  used for delete the userGroup based on groupId.  
	 *  
	 *   @param groupId
	 *  		- String Variable  
	 *    
	 *  @return integer variable
	 *  	 
	 */
	CaviumResponseModel deleteUserGroup(String groupId);

	/*
	 *  getAllPermissions method is  used for fetch the Application Details.
	 *    
	 *  @return listApplicationDetailModel
	 *  		- List  of ApplicationDetailModel Object.
	 *  	 
	 */
	List<ApplicationDetailModel> getAllPermissions();

	/*
	 *  modifyUserGroup method is used for update the group Details.
	 * 
	 *  @param userGroupModel
	 *  		- Object of UserGroupModel.
	 *  
	 *  @return CaviumResponseModel
	 *  		- CaviumResponseModel Object.
	 *  	 
	 */
	CaviumResponseModel modifyUserGroup(UserGroupModel userGroupModel) throws Exception;

	/*
	 *  getAllACLDetails method is  used for fetch all ACLs Details
	 *     
	 *  @return 
	 *  	- List of UserACLDetailsModel
	 */
	List<UserACLDetailsModel> getAllACLDetails() ;

	/*
	 *  getAllAppliancesDetails method is used for fetch All appliances Details.
	 * 
	 *  @return listApplianceDetailModel
	 *  		- List of ApplianceDetailModel Object.
	 *  	 
	 */
	List<ApplianceDetailModel>  getAllAppliancesDetails();


	/*
	 *  getGroupDetail method is used for fetch GroupDetail based on GroupName.
	 * 
	 *  @return UserGroupModel
	 *  		- UserGroupModel Object.
	 *  	 
	 */
	UserGroupModel getGroupDetail(String groupName);

	/*
	 *  createACL method is used for creating ACL.
	 * 
	 *  @param userACLDetailsModel
	 *  		- Object of UserACLDetailsModel
	 *    
	 *  @return CaviumResponseModel
	 *  		- object of CaviumResponseModel 
	 *  	 
	 */
	CaviumResponseModel createACL(UserACLDetailsModel userACLDetailsModel);

	/*
	 *  getACLDetails method is used for fetch the ACL details.
	 *  if AclName field is blank then it will fetch all the ACL details.
	 *  if AclName field is not blank then it will fetch ACL deatils based in AclName
	 * 
	 *  @param userACLDetailsModel
	 *  		- Object of UserACLDetailsModel
	 *    
	 *  @return listUserACLDetailsModel
	 *  		- List of UserACLDetailsModel Object 
	 *  	 
	 */
	List<UserACLDetailsModel> getACLDetails(UserACLDetailsModel userACLDetailsModel);


	/*
	 *  getACLDetailById method is used for fetch the ACL details based on the ACL ID.
	 *  
	 *  @param aclId
	 *  		   
	 *  @return objUserACLDetailsModel
	 *  		- UserACLDetailsModel Object 
	 *  	 
	 */
	UserACLDetailsModel getACLDetailById(String aclId);

	/*
	 *  getGroupDetailById method is used for fetch the group details based on the group Id.
	 *  
	 *  @param groupId
	 *  		   
	 *  @return objUserGroupModel
	 *  		- UserGroupModel Object 
	 *  	 
	 */
	UserGroupModel getGroupDetailById(String groupId);

	/*
	 *  modifyACL method is used for update the  existing ACL details.
	 *  
	 *  @param userAclDetailModel
	 *  	   - UserACLDetailsModel Object
	 *  		   
	 *  @return CaviumResponseModel
	 *  		- CaviumResponseModel Object 
	 *  	 
	 */
	CaviumResponseModel modifyACL(UserACLDetailsModel userAclDetailModel) throws Exception;
	
	/*
	 *  deleteACL method is used for delete the ACL detail.
	 *  
	 *  @param aclId
	 *  	      
	 *  @return result
	 *  	 
	 */
	CaviumResponseModel deleteACL(String aclId);
	
	
	/*
	 *  forgotPassword method is used for update the existing password with temporary Password and
	 *  mark TempPassword field to "Y".
	 *  
	 *   @param userId,
	 *  		- String Variable  
	 *   @param oldpassword
	 *  		- String Variable
	 *   @param newPassword
	 *  		- String Variable
	 *    
	 *  @return boolean variable
	 *  	 
	 */
 
	CaviumResponseModel forgotPassword(String userid, String oldPassword,String newPassword) throws MailException,Exception;
	
	/*
	 * This getDefaultGroupAppliances method will return all the ACLs associated with Default UserGroup. 
	 * 	  
	 *  @return	
	 *  		- The List of All ACLs.
	 */
	List<DesignationApplianceModel> getDefaultGroupAppliances();
	
	/***
	 * This method is used to provide all roles for logged in user
	 * @param loggedInUser
	 * @return
	 */
	UserDetailModel findUserDeatils(String loggedInUser);
	
	public int updateLoginFailureCount(String loggedInUser,int logInfailureCount);
	
	public  List<UserDetailModel> listUsersOnBasisOfCreatedBy(String loggedInUser);
	

}
