package com.cavium.service.appliance;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.transaction.Transactional;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.log4j.Logger;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.cavium.model.appliance.ApplianceDeleteFailureModel;
import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.appliance.DualFactorAuthDetailModel;
import com.cavium.model.appliance.InitializeApplianceDetailModel;
import com.cavium.model.appliance.InitializeAppliancesRelationshipModel;
import com.cavium.model.appliance.StoreType;
import com.cavium.model.cluster.ClusterPartitionsRelationship;
import com.cavium.model.hostadminvm.monitorstats.MonitorStats;
import com.cavium.model.partition.PartitionAdvanceStaticHostIps;
import com.cavium.model.partition.PartitionData;
import com.cavium.model.partition.PartitionDetailModel;
import com.cavium.model.partition.PartitionDnsConfig;
import com.cavium.model.partition.PartitionETH;
import com.cavium.model.partition.PartitionInterfaces;
import com.cavium.model.partition.PartitionInterfacesAdvance;
import com.cavium.model.partition.PartitionInterfacesGeneral;
import com.cavium.model.partition.StaticSearchADD;
import com.cavium.model.partition.monitor.MonitorData;
import com.cavium.model.partition.monitor.PartitionMonitorCWI;
import com.cavium.model.partition.monitor.PartitionMonitorPMNCData;
import com.cavium.model.partition.monitor.PartitionNetworkMonitorStats;
import com.cavium.model.recentactivity.InProgressActivity;
import com.cavium.model.user.DesignationApplianceModel;
import com.cavium.model.user.UserDetailModel;
import com.cavium.model.user.UserGroupModel;
import com.cavium.pojo.AdminVMSelfTestReport;
import com.cavium.pojo.ApplianceCityDetail;
import com.cavium.pojo.ApplianceInfo;
import com.cavium.pojo.HSMInfo;
import com.cavium.pojo.HostSelfTestReport;
import com.cavium.pojo.MCOKeyCertificateDetails;
import com.cavium.pojo.ManageCertificatesDetails;
import com.cavium.pojo.PartitionsDetails;
import com.cavium.pojo.SNMPDetails;
import com.cavium.pojo.UserAttributes;
import com.cavium.pojo.hostadminvm.AdminVMData;
import com.cavium.pojo.hostadminvm.Data;
import com.cavium.pojo.hostadminvm.DrvReqIdQueue;
import com.cavium.pojo.hostadminvm.FwReqIdQueue;
import com.cavium.pojo.hostadminvm.HostStats;
import com.cavium.pojo.hostadminvm.RamStats;
import com.cavium.pojo.hostadminvm.RxQueue;
import com.cavium.pojo.hostadminvm.StaticIpToHostConfig;
import com.cavium.pojo.hostadminvm.SwapStats;
import com.cavium.pojo.hostadminvm.SystemUpTime;
import com.cavium.pojo.hostadminvm.TxQueue;
import com.cavium.pojo.hostadminvm.Vmstats;
import com.cavium.pojo.logs.LogsDetails;
import com.cavium.repository.alerts.AlertsRepository;
import com.cavium.repository.appliance.ApplianceRepository;
import com.cavium.repository.appliance.DesignationAppliance;
import com.cavium.repository.appliance.InitializeAppliancesRelationshipReposiotry;
import com.cavium.repository.appliance.InitializeRepository;
import com.cavium.repository.cluster.ClusterPartitionsRelationshipRepository;
import com.cavium.repository.cluster.ClusterRepository;
import com.cavium.repository.hostadmin.monitorstats.MonitorStatsRepository;
import com.cavium.repository.partition.PartitionAdvanceDNSServersRepository;
import com.cavium.repository.partition.PartitionAdvanceSearchDomainNamesRepository;
import com.cavium.repository.partition.PartitionAdvanceStaticHostIpsRepository;
import com.cavium.repository.partition.PartitionDataRepository;
import com.cavium.repository.partition.PartitionETHRepository;
import com.cavium.repository.partition.PartitionRepository;
import com.cavium.repository.recentactivity.InProgressActivityRepository;
import com.cavium.repository.user.UserGroupRepository;
import com.cavium.repository.user.UserRepository;
import com.cavium.service.alerts.AlertsService;
import com.cavium.service.fileupload.FileUploadService;
import com.cavium.service.partition.PartitionService;
import com.cavium.service.recentactivity.InProgressActivityService;
import com.cavium.service.recentactivity.RecentActivityServiceImpl;
import com.cavium.utill.CaviumConstant;
import com.cavium.utill.CaviumResponseModel;
import com.cavium.utill.CaviumUtil;
import com.cavium.utill.RestClient;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
/**
 *  * @author MK00497144
 *  Class is used as a service implementation for Appliance Management
 */
@Component
public class ApplianceServiceImpl implements ApplianceService {
	private Logger logger = Logger.getLogger(this.getClass());

	/**
	 * ApplicationRepository - Repository class for perform Database operation on ApplicationDetailModel
	 */
	@Autowired
	private ApplianceRepository applianceRepository;


	@Autowired
	private ClusterRepository clusterRepository;

	@Autowired
	private ClusterPartitionsRelationshipRepository clusterPartitionsRelationshipRepository;

	@Autowired
	private InitializeRepository initializeRepository;

	@Autowired
	private FileUploadService fileUploadService;

	@Autowired
	private InitializeAppliancesRelationshipReposiotry initializeAppliancesRelationshipReposiotry;

	@Autowired
	private InProgressActivityRepository inProgressActivityRepository;

	@Autowired
	private PartitionService partitionService;

	@Autowired
	private PartitionRepository partitionRepository;
	@Autowired
	private MonitorStatsRepository monitorStatsRepository;
	@Autowired
	private AlertsRepository alertsRepository;

	/**
	 * This class is used to set the response attributes for incoming requests
	 */
	@Lookup
	public CaviumResponseModel getCaviumResponseModel() {
		return null;
	}

	/**
	 * This Interface is used to get the values from the property file
	 */
	@Autowired
	Environment env;
	/*
	 * getAllAppliancesDetails method is used for fetch All appliances Details.
	 * 
	 * @return listApplianceDetailModel - List of ApplianceDetailModel Object.
	 * 
	 */

	@Autowired
	RestClient restClient;

	@Autowired
	DesignationAppliance designationAppliance;

	@Autowired
	UserGroupRepository userGroupRepository;

	@Autowired
	private UserAttributes userAttributes;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private RecentActivityServiceImpl recentActivityServiceImpl;

	@Autowired
	private AlertsService alertsService;

	@Lookup
	public HSMInfo getHSMInfo() {
		return null;
	}

	@Autowired
	private InProgressActivityService inProgressActivityService;

	@Autowired
	private PartitionAdvanceStaticHostIpsRepository advanceStaticHostIpsRepository;
	@Autowired
	private PartitionAdvanceDNSServersRepository advanceDNSServersRepository;
	@Autowired
	private PartitionAdvanceSearchDomainNamesRepository advanceSearchDomainNamesRepository;
	@Autowired
	private PartitionETHRepository partitionETHRepository;
	@Autowired
	private PartitionDataRepository partitionDataRepository;

	@Override
	@Transactional
	public List<ApplianceDetailModel> getListOfAppliances() {
		List<ApplianceDetailModel> listApplianceDetailModel = null;
		CaviumResponseModel responseModel=getCaviumResponseModel();
		try {	
			listApplianceDetailModel = applianceRepository.findAll();
			inProgressActivityRepository.deleteInProgressActivityByStatus();
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured due to db error inside getListOfAppliances Method of class ApplianceServiceImpl ::" + e.getMessage());
			responseModel.setResponseCode("500");
			responseModel.setResponseMessage(env.getProperty("applianceList.failureDB"));
		}
		return listApplianceDetailModel;
	}


	@Override
	@Transactional
	public CaviumResponseModel createAppliance(List<ApplianceDetailModel> applianceDetailModel) {

		// TODO Auto-generated method stub
		CaviumResponseModel responseModel=getCaviumResponseModel();	 
		String loggedInUser = userAttributes.getlogInUserName();
		DesignationApplianceModel designationApplianceDB=null;
		if (applianceDetailModel != null && applianceDetailModel.size() > 0) {

			for(ApplianceDetailModel app : applianceDetailModel) {
				try{
					List<ApplianceDetailModel> tempApplianceDetailmodel=applianceRepository.getApplianceExists(app.getIpAddress());
					if(tempApplianceDetailmodel.size() == 1 ) {
						ApplianceDetailModel tempAppliance=tempApplianceDetailmodel.get(0);
						if(tempAppliance!=null && tempAppliance.getStoreType().equals(StoreType.TEMP)) {
							tempAppliance.setCreatedBy(loggedInUser);
							tempAppliance.setCreatedDate(new Date());
							tempAppliance.setStoreType(StoreType.PERMANENT);
							tempAppliance.setApplianceStatus("Active");
							if(StringUtils.isEmpty(tempAppliance.getAuthId())) {
								tempAppliance.setAuthId("1234");
							}
							HSMInfo	hsmInfo=getHSMInfo();
							hsmInfo=getHSMInfo(tempAppliance, hsmInfo);
							PartitionsDetails partitionsDetails=null;
							partitionsDetails=partitionService.getPartitionInfo(app,partitionsDetails);	
							if(partitionsDetails!=null){
								int totalAcclrDevice=partitionsDetails.getTotalAcclrDev();
								int occupiedAcclrDev=partitionsDetails.getOccupiedAcclrDev();
								int totalKeys=partitionsDetails.getTotalKeys();
								int occupiedKeys=partitionsDetails.getOccupiedKeys();
								int totalContexts=partitionsDetails.getTotalContexts();
								int occupiedContexts=partitionsDetails.getOccupiedContexts();
								int totalPartitions=partitionsDetails.getTotalPartitions();
								int occupiedPartitions=partitionsDetails.getOccupiedPartitions();
								tempAppliance.setTotalAcclrDevice(totalAcclrDevice);
								tempAppliance.setOccupiedAcclrDev(occupiedAcclrDev);
								tempAppliance.setOccupiedKeys(occupiedKeys);
								tempAppliance.setTotalKeys(totalKeys);
								tempAppliance.setOccupiedContexts(occupiedContexts);
								tempAppliance.setTotalContexts(totalContexts);
								tempAppliance.setTotalPartitions(totalPartitions);
								tempAppliance.setOccupiedPartitions(occupiedPartitions);
							}
							tempAppliance.setMaxPwdLen(hsmInfo.getMaxPswdLen());
							tempAppliance.setMinPwdLen(hsmInfo.getMinPswdLen());
							tempAppliance.setCoLoginFailureCount(hsmInfo.getCoLoginFailure());	
							ApplianceDetailModel applianceTemp=applianceRepository.save(tempAppliance);
							if(applianceTemp!=null) {
								List<UserGroupModel> usg=userGroupRepository.findGroupDetailsForGroupName(env.getProperty("user.defaultusergroup")); 
								if(!usg.isEmpty()) {
									UserGroupModel userGroupModel=(UserGroupModel)usg.get(0);
									DesignationApplianceModel designationApplianceModel=new DesignationApplianceModel();
									designationApplianceModel.setDesignationId(userGroupModel.getId());
									designationApplianceModel.setObjApplianceDetailModel(applianceTemp);
									designationApplianceDB=designationAppliance.save(designationApplianceModel);
								}


								if(!hsmInfo.getFipsState().replaceAll(" ","").contains("-1[zeroized]") && !hsmInfo.getFipsState().contains("3") && designationApplianceDB!=null){
									tempAppliance.setApplianceinitialized(true);
									tempAppliance.setLastOperationPerformed("initialized");
									tempAppliance.setInitializedthroughCavium(true);
									applianceRepository.save(tempAppliance);
									logger.info("Applaince is non Zeroize state");
									List<PartitionData>	partitionDataList =	partitionService.getAllPartitionsDetails(tempAppliance);
									for (Iterator<PartitionData> iterator = partitionDataList.iterator(); iterator.hasNext();) {
										PartitionData partitionData = (PartitionData) iterator.next();

										PartitionDetailModel partitionDetailModel = new PartitionDetailModel();
										partitionDetailModel.setPartitionData(partitionData);								
										partitionDetailModel.setPartitionName(partitionData.getName());
										partitionDetailModel.setApplianceDetailModel(tempAppliance);
										partitionDetailModel=partitionService.getPartitionNetworkStatsInfo(partitionDetailModel);

										if("200".equals(partitionDetailModel.getCode())){
											List<String> listSearchDomainName= new ArrayList<String>();
											List<String> listdnsServers= new ArrayList<String>();
											List<PartitionAdvanceStaticHostIps> listPartitionAdvanceStaticHostIps= new ArrayList<PartitionAdvanceStaticHostIps>();

											PartitionETH eth0=null;
											PartitionETH eth1=null;
											ObjectMapper mapper = new ObjectMapper();
											JsonNode dataNode = mapper.readTree(partitionDetailModel.getMessage());

											if(!dataNode.isNull()){
												if(dataNode.has("general")){
													logger.info("Setting General Tab data");
													JsonNode generalNode = dataNode.path("general");	
													if(!generalNode.isNull()){
														if(generalNode.has("eth1")){
															logger.info("Setting eth1 Tab data");
															eth1= new PartitionETH();
															eth1.setEthName("eth1");
															JsonNode eth1Node = generalNode.path("eth1");
															String subnet=eth1Node.path("subnet").asText();
															String hostname=eth1Node.path("hostname").asText();													 
															String vlan=eth1Node.path("vlan").asText();											
															String ip=eth1Node.path("ip").asText();
															if(!"127.0.0.1".equalsIgnoreCase(ip)){
																eth1.setDisableEth1(false);	
															}
															else{
																eth1.setDisableEth1(true);	
															}
															if(eth1Node.hasNonNull("dhcp")){
																boolean dhcp=eth1Node.path("dhcp").asBoolean();
																if(!dhcp){
																	eth1.setDhcp(true);
																}
															}
															else{
																eth1.setDhcp(false);
															}
															String gateway=eth1Node.path("gateway").asText();
															String macAddress=eth1Node.path("mac").asText();
															Boolean staticMac= eth1Node.path("macStatic").asBoolean();
															eth1.setSubnet(subnet);
															eth1.setHostname(hostname);
															if(vlan!=null && !vlan.equalsIgnoreCase("")){
																eth1.setVlan(Integer.valueOf(vlan));		
															}												
															eth1.setIp(ip);				
															eth1.setGateway(gateway);
															eth1.setAddress(macAddress);
															eth1.setStaticMac(staticMac);
														}
														if(generalNode.has("eth0")){
															logger.info("Setting eth0 Tab data");
															eth0=new PartitionETH();
															eth0.setEthName("eth0");
															JsonNode eth0Node = generalNode.path("eth0");
															String subnet=eth0Node.path("subnet").asText();
															String hostname=eth0Node.path("hostname").asText();
															String vlan=eth0Node.path("vlan").asText();																 
															String ip=eth0Node.path("ip").asText();													 
															Boolean dhcp=eth0Node.path("dhcp").asBoolean();
															String gateway=eth0Node.path("gateway").asText();	
															String macAddress=eth0Node.path("mac").asText();
															Boolean staticMac= eth0Node.path("macStatic").asBoolean();
															eth0.setStaticMac(staticMac);
															eth0.setSubnet(subnet);
															eth0.setHostname(hostname);
															if(vlan!=null && !vlan.equalsIgnoreCase("")){
																eth0.setVlan(Integer.valueOf(vlan));		
															}
															eth0.setIp(ip);
															eth0.setDhcp(dhcp);
															eth0.setGateway(gateway);
															eth0.setAddress(macAddress);
														}

													}
												}
											}
											PartitionInterfaces partitionInterfaces= new PartitionInterfaces();	
											PartitionInterfacesAdvance partitionInterfacesAdvance=new PartitionInterfacesAdvance();
											StaticSearchADD staticSearchADD= new StaticSearchADD();
											List<PartitionAdvanceStaticHostIps> partitionAdvanceStaticHostIpsList = new ArrayList<PartitionAdvanceStaticHostIps>();
											staticSearchADD.setAdd(partitionAdvanceStaticHostIpsList);
											PartitionDnsConfig partitionDnsConfig= new PartitionDnsConfig();
											partitionInterfacesAdvance.setStaticIpToHostConfig(staticSearchADD);
											partitionInterfacesAdvance.setDnsConfig(partitionDnsConfig);

											PartitionInterfacesGeneral partitionInterfacesGeneral = new PartitionInterfacesGeneral();
											partitionInterfacesGeneral.setEth0(eth0);
											partitionInterfacesGeneral.setEth1(eth1);

											partitionInterfaces.setAdvanced(partitionInterfacesAdvance);
											partitionInterfaces.setGeneral(partitionInterfacesGeneral);
											partitionDetailModel.setNetworkStats(partitionInterfaces);

											JsonNode advancedNode = dataNode.path("advanced");							 
											if(!advancedNode.isNull()){
												logger.info("Setting Advanced Tab data");
												JsonNode searchDomainNames=	advancedNode.path("searchDomainNames");
												JsonNode staticIpToHostConfigs=	advancedNode.path("staticIpToHostConfig");
												JsonNode dnsServers=advancedNode.path("dnsServers");
												if(!searchDomainNames.isNull()){
													Iterator<JsonNode> searchDomainName = searchDomainNames.elements();					         
													while (searchDomainName.hasNext()) {
														JsonNode temp = searchDomainName.next();    
														listSearchDomainName.add(temp.asText());
													}
													partitionDetailModel.getNetworkStats().getAdvanced().getDnsConfig().setSearchDomainNames(listSearchDomainName.toArray(new String[listSearchDomainName.size()]));
												}
												if(!dnsServers.isNull()){
													Iterator<JsonNode> dnsServer = dnsServers.elements();					         
													while (dnsServer.hasNext()) {
														JsonNode temp = dnsServer.next();
														listdnsServers.add(temp.asText());
													}
													partitionDetailModel.getNetworkStats().getAdvanced().getDnsConfig().setDnsServers(listdnsServers.toArray(new String[listdnsServers.size()]));
												}
												if (staticIpToHostConfigs.isArray()) {
													for (final JsonNode staticIpToHostConfig : staticIpToHostConfigs) {
														PartitionAdvanceStaticHostIps obj= new PartitionAdvanceStaticHostIps();
														//	listSearchDomainName.add(staticIpToHostConfig.asText());
														if(staticIpToHostConfig.has("alias")) {
															obj.setAlias(staticIpToHostConfig.get("alias").asText());
														}
														if(staticIpToHostConfig.has("hostname")) {
															obj.setHostname(staticIpToHostConfig.get("hostname").asText());
														}
														if(staticIpToHostConfig.has("ip")) {
															obj.setIp(staticIpToHostConfig.get("ip").asText());
														}
														listPartitionAdvanceStaticHostIps.add(obj);
													}
													partitionDetailModel.getNetworkStats().getAdvanced().getStaticIpToHostConfig().setAdd(listPartitionAdvanceStaticHostIps);
												}

											}
											Boolean partitionAlreadyExist=true;
											logger.info("Starting of create Partition");
											partitionService.createPartition(loggedInUser,partitionDetailModel,partitionAlreadyExist);
										}
									}
								}
								responseModel.setResponseCode("200");
								responseModel.setResponseMessage(env.getProperty("applianceCreation.success"));
								recentActivityServiceImpl.createRecentActivity(loggedInUser, "New device "+app.getApplianceName()+" added by "+loggedInUser,CaviumConstant.APPLIANCE_MANAGEMENT);
							}
						}
					}else {
						//alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+" added by "+loggedInUser+" does not exists into the cavium networks");
						alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+" added by "+loggedInUser+" does not exists in the cavium networks.",app.getApplianceName(),app.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
						responseModel.setResponseCode("409");
						responseModel.setResponseMessage(env.getProperty("appliance.notexists.cavium.network"));
					}
				} catch (Exception e) {
					logger.error("Error occured due to db error inside createAppliance Method of class ApplianceServiceImpl ::" + e.getMessage());
					responseModel.setResponseCode("500");
					responseModel.setResponseMessage(env.getProperty("applianceCreation.failureDB"));
					//alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+" added by "+loggedInUser+" does not exists into the cavium networks");
					alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+" added by "+loggedInUser+" does not exists in the cavium networks.",app.getApplianceName(),app.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
				}
			}
		} else {
			logger.error("ApplianceDetailModel is empty or null ::");
			responseModel.setResponseCode("204");
			responseModel.setResponseMessage(env.getProperty("applianceCreation.failureEmpty"));
		}

		return responseModel;
	}

	/*
	 * This method is used to modify the appliance 
	 * (non-Javadoc)
	 * @see com.cavium.service.appliance.ApplianceService#modifyAppliance(java.lang.String, com.cavium.model.appliance.ApplianceDetailModel)
	 */
	@Override
	@Transactional
	public CaviumResponseModel modifyAppliance(String loggedInUser, ApplianceDetailModel applianceDetailModel) {
		CaviumResponseModel responseModel=getCaviumResponseModel();
		try	{
			if(applianceDetailModel!=null && applianceDetailModel.getApplianceId()!=null && applianceDetailModel.getApplianceId().longValue() > 0) {
				applianceRepository.save(applianceDetailModel);
				responseModel.setResponseCode("200");
				responseModel.setResponseMessage(env.getProperty("applianceModification.success"));
				recentActivityServiceImpl.createRecentActivity(loggedInUser,"Device "+applianceDetailModel.getApplianceName()+" modified by "+loggedInUser,CaviumConstant.APPLIANCE_MANAGEMENT);

				/*	ApplianceDetailModel applianceDetailFromDBModel=applianceRepository.findOne(applianceDetailModel.getApplianceId());
				if(applianceDetailFromDBModel!=null && applianceDetailFromDBModel.getApplianceId().longValue() > 0) {
					applianceDetailFromDBModel.setApplianceName(applianceDetailModel.getApplianceName());
					applianceDetailFromDBModel.setApplianceStatus(applianceDetailModel.getApplianceStatus());
					applianceDetailFromDBModel.setGatewayIp(applianceDetailModel.getGatewayIp());
					applianceDetailFromDBModel.setIpAddress(applianceDetailModel.getIpAddress());
					applianceDetailFromDBModel.setNetworkMode(applianceDetailModel.getNetworkMode());
					applianceDetailFromDBModel.setModifiedBy(loggedInUser);
					applianceDetailFromDBModel.setModifiedDate(new Date());
					if(!applianceDetailModel.getPartitionDetailModels().isEmpty()) {
						List<PartitionDetailModel> partitionResquestDetailModel=applianceDetailModel.getPartitionDetailModels();
						List<PartitionDetailModel> partitionDBDetailModel=applianceDetailFromDBModel.getPartitionDetailModels();
						int count=0;
						for(PartitionDetailModel db : partitionDBDetailModel){
							PartitionDetailModel req=partitionResquestDetailModel.get(count);
							db.setPartitionAvailableSize(req.getPartitionAvailableSize());
							db.setPartitionType(req.getPartitionType());
							count++;
						}
					}
					applianceRepository.save(applianceDetailFromDBModel);
					responseModel.setResponseCode("200");
					responseModel.setResponseMessage(env.getProperty("applianceModification.success"));
					recentActivityServiceImpl.createRecentActivity(loggedInUser, "Device "+applianceDetailFromDBModel.getApplianceName()+" modified by "+loggedInUser+" at "+ CaviumUtil.formatDateTimeFromCurrenDate(new Date()));
				}else {
					alertsService.createAlert(loggedInUser,"Device "+applianceDetailFromDBModel.getApplianceName()+" modified by "+loggedInUser+ " at "+CaviumUtil.formatDateTimeFromCurrenDate(new Date()) +"does not exists into the cavium networks");
					responseModel.setResponseCode("409");
					responseModel.setResponseMessage(env.getProperty("applianceModification.failureNotExist"));
				}*/
			}

		}catch (Exception e) {
			logger.error("Error occured during Appliance modification :: "+ e.getMessage());
			responseModel.setResponseCode("-230");
			responseModel.setResponseMessage("Failed to execute the request at the backend");	 
		}
		return responseModel;	 
	}

	/**
	 * Method is used to delete the particular appliance
	 */
	@Override
	@Transactional
	public CaviumResponseModel deleteAppliances(ApplianceDetailModel app) {
		CaviumResponseModel caviumResponseModel=getCaviumResponseModel();
		String loggedInUser = userAttributes.getlogInUserName();
			if(app!=null && app.getApplianceId()!=null) {
				try {
					logger.info("Deleted Appliance Id :: " +app.getApplianceId());
				DesignationApplianceModel design=designationAppliance.getDesignationModelByApplianceId(app.getApplianceId());
				if(design!=null) {
					String desc=userGroupRepository.getGroupName(design.getDesignationId());
					if(!desc.equalsIgnoreCase("DefaultUserGroup")) {
						/**
						 * move appliance to DefaultUserGroup 
						 */
						List<UserGroupModel> usg=userGroupRepository.findGroupDetailsForGroupName(env.getProperty("user.defaultusergroup")); 
						if(!usg.isEmpty()) {
							UserGroupModel userGroupModel=(UserGroupModel)usg.get(0);
							designationAppliance.updateDesignationId(userGroupModel.getId(), app.getApplianceId());
						}
						caviumResponseModel.setResponseCode("200");
						caviumResponseModel.setResponseMessage("Appliance "+app.getApplianceName()+" deleted successfully.");
						recentActivityServiceImpl.createRecentActivity(loggedInUser, "device "+app.getApplianceName()+" deleted successfully by "+loggedInUser+".",CaviumConstant.APPLIANCE_MANAGEMENT);
					}else {


						/**
						 * Delete in-progress activity and alerts for appliance
						 */
						   inProgressActivityRepository.deleteInProgressByApplianceId(app.getApplianceId());
						   alertsRepository.deleteAlertsByApplianceId(app.getApplianceId());
						
						
						/**
						 * Delete all partitions related records
						 */
						List<PartitionDetailModel> partlist=partitionRepository.getListOfPartitionByApplianceID(app.getApplianceId());
						if(partlist!=null && partlist.size() > 0) {
							for(PartitionDetailModel partdm: partlist) {
								partdm.setSessionClose(true);
								List<ClusterPartitionsRelationship> clus=clusterPartitionsRelationshipRepository.getListOfClusters(partdm.getPartitionId());
								if(clus!=null && clus.size() > 0) {
									clusterPartitionsRelationshipRepository.deletePartitionFromCluster(partdm.getPartitionId());
									/*for(ClusterPartitionsRelationship cls: clus) {
										clusterRepository.delete(cls.getClusterId());
									}*/
								}
								PartitionDetailModel partitionDetailModel=partitionRepository.findOne(partdm.getPartitionId());
								deletePartitionData(partitionDetailModel);
							}
						}
						try {
							//partitionService.deletePartition(loggedInUser, partlist);
						}catch (Exception e) {
							// TODO: handle exception
							caviumResponseModel.setResponseCode("500");
							caviumResponseModel.setResponseMessage("Delete partition operation failed from live appliance");
							return caviumResponseModel;
						}
						

						/**
						 * Delete designation appliance record 
						 */
						if(design!=null) {
							designationAppliance.deleteDesignationAppliance(app.getApplianceId());
						}
						

						/**
						 * Delete all initialize related records 
						 */

						InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(app.getApplianceId());
						if(initmodel!=null){
							InitializeApplianceDetailModel init=initializeRepository.findOne(initmodel.getInitializeId());
							initializeAppliancesRelationshipReposiotry.delete(initmodel);
							initializeRepository.delete(init);
						}
						
						/**
						 * Delete monitor data
						 */
						List<MonitorStats> monitorStats=monitorStatsRepository.getListOfMonistorStatsByApplianceIp(app.getIpAddress());
						monitorStatsRepository.delete(monitorStats);
						/**
						 * Delete appliance in the last
						 */
						applianceRepository.deleteAppliance(app.getApplianceId());
						caviumResponseModel.setResponseCode("200");
						caviumResponseModel.setResponseMessage("Appliance "+app.getApplianceName()+" deleted successfully.");
						recentActivityServiceImpl.createRecentActivity(loggedInUser, "device "+app.getApplianceName()+" deleted successfully by "+loggedInUser+".",CaviumConstant.APPLIANCE_MANAGEMENT);
					}
				}
			}
		 catch (Exception e) {
			logger.error("Error occured due to db error inside deleteAppliance Method of class ApplianceServiceImpl for "+ app.getApplianceName() +" :: "
					+ e.getMessage());
			caviumResponseModel.setResponseCode("500");
			caviumResponseModel.setResponseMessage(env.getProperty("applianceDeletion.failureDB"));
			alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+" trying to delete by "+loggedInUser+" does not delete due to "+ e.getMessage(),app.getApplianceName(),app.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
		}
			}
		return caviumResponseModel; 
	}

	/***
	 * This method is used to validate the appliance whether exists or not
	 */
	@Override
	public synchronized ApplianceDetailModel validateAppliance(ApplianceDetailModel applianceDetailModel) {
		// TODO Auto-generated method stub
		try {
			String loggedInUser = userAttributes.getlogInUserName();
			List<ApplianceDetailModel> isAvailable=applianceRepository.getApplianceExists(applianceDetailModel.getIpAddress());
			if(isAvailable.isEmpty()) {
				List<ApplianceDetailModel> isNameAvailable=applianceRepository.getApplianceNameByGivenName(applianceDetailModel.getApplianceName());
				if(isNameAvailable.isEmpty()) {
					ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/appliance_info");
					if(response !=null && response.getStatusCode().name().equals("OK")) {
						List <ApplianceDetailModel> applianceDetailList= new ArrayList<ApplianceDetailModel>();
						//applianceDetailModel.setOperationUsername(applianceDetailModel.getUserName());
						//applianceDetailModel.setOperationPassword(applianceDetailModel.getUserPassword());
						applianceDetailList.add(applianceDetailModel);

						applianceDetailList=validateCredentialsByLoginHSM(applianceDetailList);
						for(ApplianceDetailModel applianceDetail: applianceDetailList){
							if("200".equals(applianceDetail.getCode()))
							{
								// Appliance can be add to list
								applianceDetailModel.setUserPassword(CaviumUtil.encrypt(applianceDetailModel.getUserPassword()));
								applianceDetailModel.setCode("200");
								applianceDetailModel.setMessage("Success");
								applianceDetailModel.setCreatedBy(loggedInUser);
								applianceDetailModel.setStoreType(StoreType.TEMP);
								ApplianceDetailModel applianceDetailModeldb=applianceRepository.save(applianceDetailModel);
								applianceDetailModeldb.setOperationUsername(applianceDetailModel.getOperationUsername());
								applianceDetailModeldb.setOperationPassword(applianceDetailModel.getOperationPassword());
								saveZoneDetails(applianceDetailModeldb);
							}else{
								applianceDetailModel=applianceDetail;
							}
						}				
					}else {
						applianceDetailModel.setCode("409");
						applianceDetailModel.setMessage(env.getProperty("appliance.notexists.cavium.network"));
						//alertsService.createAlert(loggedInUser,"Device "+applianceDetailModel.getApplianceName()+" added by "+loggedInUser+" does not exists into the cavium networks");
						// Appliance not found hence can't add to list
						alertsService.createAlert(loggedInUser,"Device "+applianceDetailModel.getApplianceName()+" added by "+loggedInUser+" does not exists in the cavium networks.",applianceDetailModel.getApplianceName(),applianceDetailModel.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
					}
				
				}else {
					applianceDetailModel.setCode("409");
					applianceDetailModel.setMessage(env.getProperty("applianceCreation.failureNameExist"));
				}
			}else {
				applianceDetailModel.setCode("409");
				applianceDetailModel.setMessage(env.getProperty("applianceCreation.failureExist"));
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Error occured during appliance validation.. into validateAppliance of class ApplianceServiceIMPL");
		}
		return applianceDetailModel;
	}

	/***
	 * This method is used to get appliance by id.
	 */
	@Override
	public ApplianceDetailModel getApplianceById(String applianceID) {
		// TODO Auto-generated method stub
		ApplianceDetailModel applianceDetailModel = null;
		CaviumResponseModel responseModel=getCaviumResponseModel();

		try {	
			applianceDetailModel = applianceRepository.getApplianceById(Long.parseLong(applianceID), StoreType.PERMANENT);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured due to db error inside getListOfAppliances Method of class ApplianceServiceImpl ::" + e.getMessage());
			responseModel.setResponseCode("500");
			responseModel.setResponseMessage(env.getProperty("applianceList.failureDB"));
		}
		return applianceDetailModel;
	}

	/***
	 * This method is used to get appliance by id.
	 */
	@Override
	public List<ApplianceDetailModel> listOfApplianceByGroupId(String loggedInUser) {
		// TODO Auto-generated method stub
		List<ApplianceDetailModel>  applianceDetailModel = null;
		CaviumResponseModel responseModel=getCaviumResponseModel();
		try {
			UserDetailModel objUserDetailModel=userRepository.findOne(loggedInUser);
			if(objUserDetailModel!=null && objUserDetailModel.getObjUserACLDetailsModel().getAclName().equals(env.getProperty("user.superadmin"))) {
				applianceDetailModel = applianceRepository.getAllListOfAppliances(StoreType.PERMANENT);
			}else {
				applianceDetailModel = applianceRepository.getListOfApplianceByGroupId(loggedInUser);
			}
			inProgressActivityRepository.deleteInProgressActivityByStatus();
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured due to db error inside getListOfAppliances Method of class ApplianceServiceImpl ::" + e.getMessage());
			responseModel.setResponseCode("500");
			responseModel.setResponseMessage(env.getProperty("applianceList.failureDB"));
		}
		return applianceDetailModel;
	}

	/***
	 * This method is used to reboot the appliance and update last operation performed column in db
	 */

	@Override
	public List<ApplianceDetailModel> rebootAppliance(List<ApplianceDetailModel> applianceDetailModellist) {
		// TODO Auto-generated method stub

		// TODO Auto-generated method stub
		String loggedInUser = userAttributes.getlogInUserName();
		List<ApplianceDetailModel> responseList=new ArrayList<ApplianceDetailModel>();
		try {
			if (applianceDetailModellist.size() > 0) {
				Iterator<ApplianceDetailModel> itr = applianceDetailModellist.iterator();
				while (itr.hasNext()) {
					ResponseEntity<String> response = null;
					ApplianceDetailModel app = (ApplianceDetailModel) itr.next();
					ApplianceDetailModel dbAppliance = applianceRepository.findOne(app.getApplianceId());
					if (dbAppliance != null) {
						long applianceId = app.getApplianceId();
					//	MultiValueMap<String, Object> body = new LinkedMultiValueMap<String, Object>();
						JSONObject body = new JSONObject(); 
						InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry
								.getInitializeIdByApplianceId(applianceId);
						if (initmodel != null) {
							InitializeApplianceDetailModel initAppDetailModel = initializeRepository
									.findOne(initmodel.getInitializeId());
							DualFactorAuthDetailModel dualAuthModel = initAppDetailModel.getDualFactorAuthDetailModel();
							if (!StringUtils.isEmpty(app.getOperationUsername())
									&& !StringUtils.isEmpty(app.getOperationPassword())) {
								if (initAppDetailModel.getAuthenticationLevel() == 0) {
									body.put("username", app.getOperationUsername());
									body.put("password", app.getOperationPassword());
								}
								if (initAppDetailModel.getAuthenticationLevel() == 1 && dualAuthModel != null) {
									body.put("username", app.getOperationUsername());
									body.put("password", app.getOperationPassword());
									body.put("dualFactorHostname", dualAuthModel.getDualFactorAuthServerAddress());
									body.put("dualFactorPort", dualAuthModel.getDualFactorAuthServerPortNo());
									body.put("dualFactorCertificate", dualAuthModel.getDualFactorAuthServerCertId());
								}
							} else {
								if (initAppDetailModel.getAuthenticationLevel() == 0) {
									body.put("username", initAppDetailModel.getCryptoOfficerName());
									body.put("password", CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));
								}
								if (initAppDetailModel.getAuthenticationLevel() == 1 && dualAuthModel != null) {
									body.put("username", initAppDetailModel.getCryptoOfficerName());
									body.put("password", CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));
									body.put("dualFactorHostname", dualAuthModel.getDualFactorAuthServerAddress());
									body.put("dualFactorPort", dualAuthModel.getDualFactorAuthServerPortNo());
									body.put("dualFactorCertificate", dualAuthModel.getDualFactorAuthServerCertId());
								}
							}
							response = restClient.invokePOSTMethodForOperations(
									"https://" + app.getIpAddress() + "/liquidsa/admin_vm_reboot", body);

						} else {
							if (!StringUtils.isEmpty(app.getOperationUsername())
									&& !StringUtils.isEmpty(app.getOperationPassword())) {
								body.put("username", app.getOperationUsername());
								body.put("password", app.getOperationPassword());
								response = restClient.invokePOSTMethodForOperations(
										"https://" + app.getIpAddress() + "/liquidsa/admin_vm_reboot", body);
							} else {
								app.setMessage("Appliance not rebooted due to credentials not available");
								alertsService.createAlert(loggedInUser,
										"Device " + app.getApplianceName() + "  try to perofrm reboot by "
												+ loggedInUser + " does not reboot due to credentials not available.",app.getApplianceName(),app.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
							}
						}
						if (response != null && response.getBody() != null) {
							ObjectMapper mapper = new ObjectMapper();
							JsonNode root = mapper.readTree(response.getBody());
							if (response != null && response.getBody() != null
									&& response.getBody().contains("success")) {
								dbAppliance.setLastOperationPerformed(env.getProperty("appliance.reboot"));
								dbAppliance.setLastOperationStatus("In-Progress");
								dbAppliance.setApplianceinitialized(app.isApplianceinitialized());
								dbAppliance.setCode("200");
								dbAppliance.setMessage(env.getProperty("appliance.reboot.success"));
								dbAppliance.setErrorMessage("");
								applianceRepository.save(dbAppliance);
								updateInProgressActivity(dbAppliance, loggedInUser, root);

							} else {
								dbAppliance = getErrorMessage(response, dbAppliance, loggedInUser, "Reboot");
								applianceRepository.save(dbAppliance);
							}
						} else {
							dbAppliance = getErrorMessage(response, dbAppliance, loggedInUser, "Reboot");
							applianceRepository.save(dbAppliance);
						}
						responseList.add(dbAppliance);
					} else {
						app.setCode("409");
						app.setMessage(env.getProperty("appliance.notexists.cavium"));
						alertsService.createAlert(loggedInUser, "Device " + app.getApplianceName()
						+ "  try to perofrm reboot by " + loggedInUser + " does not exist in cavium netwoork.",app.getApplianceName(),app.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
						responseList.add(app);
					}
				}
			}
		}catch (Exception e) {
			// TODO: handle exception
			logger.info("Error occured during appliance rebootAppliance.. into rebootAppliance of class ApplianceServiceIMPL");
		}
		return responseList;
	}

	/***
	 * This method is used to reboot the appliance and update last operation performed column in db
	 */
	@Override
	public List<ApplianceDetailModel> zeroizeAppliance(List<ApplianceDetailModel> applianceDetailModellist) {
		// TODO Auto-generated method stub
		List<ApplianceDetailModel> responseList=new ArrayList<ApplianceDetailModel>();
		String loggedInUser = userAttributes.getlogInUserName();
		// TODO Auto-generated method stub
		try {
			if(applianceDetailModellist.size() > 0) {
				Iterator<ApplianceDetailModel> itr=applianceDetailModellist.iterator();
				while(itr.hasNext()) {
					ResponseEntity<String> response=null;
					ApplianceDetailModel app=(ApplianceDetailModel)itr.next();
					ApplianceDetailModel dbAppliance=applianceRepository.findOne(app.getApplianceId()); 
					Map<String,Object> map=new HashMap<>();
					JSONObject json = new JSONObject(); 
					if(dbAppliance!=null) {
						if(app.getType()!=null && !app.getType().equalsIgnoreCase("adapter")){
							json.put("type",app.getType());
						}
						if(app.getForceZeroize()!=null && app.getType()!=null && app.getType().equalsIgnoreCase("adapter")){
							json.put("forceZeroize",app.getForceZeroize().booleanValue());
						}
						long applianceId=dbAppliance.getApplianceId();
						InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(applianceId);
						if(initmodel!=null) {
							InitializeApplianceDetailModel initAppDetailModel = initializeRepository.findOne(initmodel.getInitializeId());
							DualFactorAuthDetailModel dualAuthModel=initAppDetailModel.getDualFactorAuthDetailModel();
							if(!StringUtils.isEmpty(app.getOperationUsername()) && !StringUtils.isEmpty(app.getOperationPassword())) {
								if(initAppDetailModel.getAuthenticationLevel()==0) {
									map.put("username", app.getOperationUsername());
									map.put("password", app.getOperationPassword());
								}if(initAppDetailModel.getAuthenticationLevel()==1 && dualAuthModel!=null) {
									map.put("username", app.getOperationUsername());
									map.put("password", app.getOperationPassword());
									map.put("dualFactorHostname", dualAuthModel.getDualFactorAuthServerAddress());
									map.put("dualFactorPort", dualAuthModel.getDualFactorAuthServerPortNo());
									map.put("dualFactorCertificate", dualAuthModel.getDualFactorAuthServerCertId());
								}
								if(!app.getType().equalsIgnoreCase("adapter")) {
									json.put("mcoLoginInfo", map);
								}
							}else {
								if(initAppDetailModel.getAuthenticationLevel()==0) {
									map.put("username", initAppDetailModel.getCryptoOfficerName());
									map.put("password", CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));
								}if(initAppDetailModel.getAuthenticationLevel()==1 && dualAuthModel!=null) {
									map.put("username", initAppDetailModel.getCryptoOfficerName());
									map.put("password", CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));
									map.put("dualFactorHostname", dualAuthModel.getDualFactorAuthServerAddress());
									map.put("dualFactorPort", dualAuthModel.getDualFactorAuthServerPortNo());
									map.put("dualFactorCertificate", dualAuthModel.getDualFactorAuthServerCertId());
								}
								if(!app.getType().equalsIgnoreCase("adapter")) {
									json.put("mcoLoginInfo", map);
								}
							}
							response=restClient.invokePOSTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/zeroize",json);
						}else {
							if(!StringUtils.isEmpty(app.getOperationUsername()) && !StringUtils.isEmpty(app.getOperationPassword())) {
								map.put("username", app.getOperationUsername());
								map.put("password", app.getOperationPassword());
								if(!app.getType().equalsIgnoreCase("adapter")) {
									json.put("mcoLoginInfo", map);
								}
								response=restClient.invokePOSTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/zeroize",json);
							}else {
								app.setMessage("Appliance not rebooted due to credentials not available");
								alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+"  try to perofrm zeroize by "+loggedInUser+" does not zeroize.",app.getApplianceName(),app.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
							}
						}

						if(response!=null && response.getBody()!=null)
						{
							ObjectMapper mapper = new ObjectMapper();
							JsonNode root = mapper.readTree(response.getBody());
							if(response!=null && response.getBody()!=null && response.getBody().contains("success")) {
								dbAppliance.setLastOperationPerformed(env.getProperty("appliance.zeroize"));
								dbAppliance.setLastOperationStatus("In-Progress");
								dbAppliance.setCode("200");
								dbAppliance.setErrorMessage("");
								dbAppliance.setMessage(env.getProperty("appliance.zeroize.success"));
								applianceRepository.save(dbAppliance);

								List<PartitionDetailModel> partlist=partitionRepository.getListOfPartitionByApplianceID(app.getApplianceId());
								for (PartitionDetailModel partitionDetailModel: partlist) {
									Long partitionId=partitionDetailModel.getPartitionId();
									String lastOperationStatus="In-Progress";
									String lastOperationPerformed=env.getProperty("appliance.zeroize");
									String status="Completed";
									String errorMessage="";
									partitionRepository.updatePartitionStatus(status,lastOperationStatus,lastOperationPerformed,errorMessage,partitionId);
								}
								updateInProgressActivity(dbAppliance, loggedInUser, root);

							}else {
								dbAppliance = getErrorMessage(response, dbAppliance, loggedInUser, "Zeroize");
								applianceRepository.save(dbAppliance);
							}	
						}else {
							dbAppliance = getErrorMessage(response, dbAppliance, loggedInUser, "Zeroize");
							applianceRepository.save(dbAppliance);
						}
						responseList.add(dbAppliance);
					}else {
						app.setCode("409");
						app.setMessage(env.getProperty("appliance.notexists.cavium"));
						alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+"  try to perofrm zeroize by "+loggedInUser+" does not exist in cavium network.",app.getApplianceName(),app.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
						responseList.add(app);
					}
				}
			}

		}catch (Exception e) {
			// TODO: handle exception
			logger.info("Error occured during appliance zeroizeAppliance.. into zeroizeAppliance of class ApplianceServiceIMPL");
		}
		return responseList;
	}
	/***
	 * This method is used to reboot the appliance and update last operation performed column in db
	 */
	@Override
	public ApplianceDetailModel applianceFirmwareUpgrade(ApplianceDetailModel app,HashMap<String,String> map, String loggedInUser) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		ApplianceDetailModel dbAppliance=null;
		try {
			if(app!=null) {
					 ResponseEntity<String> response = null;
					 dbAppliance=applianceRepository.findOne(app.getApplianceId()); 
					JSONObject json = new JSONObject(); 
					if(dbAppliance!=null) {
						json=getUserNamePassword(app, json);
						json.put("hsmFirmwareType", app.getFirmwareUpgradeDetailModel().getHsmFirmwareType());
						json.put("imageFilePath", map.get("imageFilePath"));
						json.put("signFilePath", map.get("signFilePath"));
						if(!StringUtils.isEmpty(app.getFirmwareUpgradeDetailModel().getHsmFirmwareType()) && app.getFirmwareUpgradeDetailModel().getHsmFirmwareType().equalsIgnoreCase("adapter")) {
							json.put("zeroize", app.getFirmwareUpgradeDetailModel().isZeroize());
						}
						response=restClient.invokePOSTMethodForOperations("https://"+dbAppliance.getIpAddress()+"/liquidsa/firmware_upgrade", json);
						if (response != null && response.getBody() != null) {
							ObjectMapper mapper = new ObjectMapper();
							JsonNode root = mapper.readTree(response.getBody());
							if(response!=null && response.getBody()!=null && response.getBody().contains("success")) {
								dbAppliance.setLastOperationPerformed(env.getProperty("appliance.firmware"));
								dbAppliance.setLastOperationStatus("In-Progress");
								dbAppliance.setCode("200");
								dbAppliance.setErrorMessage("");
								dbAppliance.setMessage(env.getProperty("appliance.firmwareupgrade.success"));
								applianceRepository.save(dbAppliance);
								if(app.getFirmwareUpgradeDetailModel()!=null && app.getFirmwareUpgradeDetailModel().isZeroize()) {
									dbAppliance.setFirmwareUpgradeDetailModel(app.getFirmwareUpgradeDetailModel());
								}
								updateInProgressActivity(dbAppliance, loggedInUser, root);
							}else {
								dbAppliance = getErrorMessage(response, dbAppliance, loggedInUser, "Firmware Upgrade");
								applianceRepository.save(dbAppliance);
							}
						}else {
							dbAppliance = getErrorMessage(response, dbAppliance, loggedInUser, "Firmware Upgrade");
							applianceRepository.save(dbAppliance);
							}
						}else {
							app.setCode("408");
							app.setErrorMessage("Appliance not exists into data base");
						}
					}
			} catch (Exception e) {
				// TODO: handle exception
				logger.info("Error occured during appliance applianceFirmwareUpgrade.. into applianceFirmwareUpgrade of class ApplianceServiceIMPL");
			}
		return dbAppliance;
	}

	/***
	 * This method is used to initilizeAppliance the appliance and update last operation performed column in db
	 */
	@Override
	@Transactional
	public List<ApplianceDetailModel> initilizeAppliance(InitializeApplianceDetailModel initializeApplianceDetailModel) throws RuntimeException{
		logger.error("Start of initilizeAppliance method"); 
		List<ApplianceDetailModel> listApplianceDetailModel= new ArrayList<ApplianceDetailModel>();	
		synchronized (initializeApplianceDetailModel) {
			ApplianceDetailModel objApplianceDetailModel=null;
			CaviumResponseModel caviumResponseModel=null;			
			if(initializeApplianceDetailModel.getAuthenticationLevel()!=null){
				if(initializeApplianceDetailModel.getApplianceDetailModels()!=null && initializeApplianceDetailModel.getApplianceDetailModels().size()>0 ){
					Iterator<ApplianceDetailModel> applianceDetailModel=initializeApplianceDetailModel.getApplianceDetailModels().iterator();
					while(applianceDetailModel.hasNext()) {
						ApplianceDetailModel appliance=(ApplianceDetailModel)applianceDetailModel.next();
						try{
							if(initializeApplianceDetailModel.getAuthenticationLevel()==1){
								File convertedFile=null;
								String coPassword=initializeApplianceDetailModel.getConfirmCryptoOfficerpassword();
								String coUsername=initializeApplianceDetailModel.getCryptoOfficerName();
								String fileName=initializeApplianceDetailModel.getDualFactorAuthDetailModel().getFileName();
								String fileExtension=initializeApplianceDetailModel.getDualFactorAuthDetailModel().getFileExtension();
								String fileContent=initializeApplianceDetailModel.getDualFactorAuthDetailModel().getFileContent();
								try{
									convertedFile= CaviumUtil.createFile(fileName,fileExtension,fileContent);
								}catch (IOException e) {
									logger.error("Error while creating file in initilizeAppliance method"); 
									throw new RuntimeException("FileUploadError");
								}
								caviumResponseModel=fileUploadService.uploadFile(convertedFile,coUsername,coPassword,"InitHSM",appliance.getIpAddress(),null);
								if(convertedFile!=null){
									Files.deleteIfExists(Paths.get(convertedFile.getAbsolutePath()));
								}					         
							}
							if(caviumResponseModel!=null && "200".equals(caviumResponseModel.getResponseCode()) || initializeApplianceDetailModel.getAuthenticationLevel()==0 ){
								initializeApplianceDetailModel.setConfirmCryptoOfficerpassword(CaviumUtil.encrypt(initializeApplianceDetailModel.getConfirmCryptoOfficerpassword()));
								initializeApplianceDetailModel.setCryptoOfficerPassword(CaviumUtil.encrypt(initializeApplianceDetailModel.getCryptoOfficerPassword()));
								if(caviumResponseModel!=null && initializeApplianceDetailModel.getDualFactorAuthDetailModel()!=null){
									initializeApplianceDetailModel.getDualFactorAuthDetailModel().setDualFactorAuthServerCertId(caviumResponseModel.getResponseMessage());
								}
								InitializeApplianceDetailModel dbinitializeApplianceDetailModel=initializeRepository.save(initializeApplianceDetailModel);
								Long initializeId=dbinitializeApplianceDetailModel.getInitialize_id();


								objApplianceDetailModel= initilizeApplianceRelationship(appliance,initializeApplianceDetailModel,initializeId,caviumResponseModel);
								listApplianceDetailModel.add(objApplianceDetailModel);
								logger.info("Appliance Initilized Succesfully"); 
							}else{
								logger.error("Error while sending file to cavium network"); 
								throw new RuntimeException("FileUploadError");
							}
						}
						catch (Exception e) {
							logger.error("Error coming while initilize Appliance in initilizeAppliance method"+e.getMessage()); 
							throw new RuntimeException(e.getMessage());

						}
					}
				}
			}
		}
		logger.info("End of initilizeAppliance method"); 
		return listApplianceDetailModel;
	}
	@Override
	@Transactional
	public ApplianceDetailModel  initilizeApplianceRelationship(ApplianceDetailModel applianceDetailModel, InitializeApplianceDetailModel initializeApplianceDetailModel,Long initializeId,CaviumResponseModel caviumResponseModel) throws RuntimeException{
		synchronized (initializeApplianceDetailModel) {
			String loggedInUser = userAttributes.getlogInUserName();
			ApplianceDetailModel dbAppliance=applianceRepository.findOne(applianceDetailModel.getApplianceId()); 
			if(dbAppliance!=null) {
				dbAppliance.setCredentialSaved(initializeApplianceDetailModel.isCredentialSaved());
				dbAppliance.setApplianceinitialized(true);


				InitializeAppliancesRelationshipModel initializeAppliancesRelationshipModel=new InitializeAppliancesRelationshipModel();
				initializeAppliancesRelationshipModel.setInitializeId(initializeId);
				initializeAppliancesRelationshipModel.setApplianceDetailModel(dbAppliance);
				if(initializeApplianceDetailModel.isCredentialSaved()){
					initializeAppliancesRelationshipModel.setOperationPerformUserName(initializeApplianceDetailModel.getUserName());
					initializeAppliancesRelationshipModel.setOperationPerformPassword(CaviumUtil.encrypt(initializeApplianceDetailModel.getPassword()));
				}


				JSONObject json = new JSONObject(); 
				Map<String,Object> initData= new HashMap<String,Object>();
				json.put("username",initializeApplianceDetailModel.getUserName());
				json.put("password",initializeApplianceDetailModel.getPassword());
				initData.put("cryptoOfficerName",initializeApplianceDetailModel.getCryptoOfficerName());
				initData.put("cryptoOfficerPassword",CaviumUtil.decrypt(initializeApplianceDetailModel.getCryptoOfficerPassword()));
				initData.put("authenticationLevel",initializeApplianceDetailModel.getAuthenticationLevel());
				initData.put("fipsState",initializeApplianceDetailModel.getFipsState());
				initData.put("hsmAuditLog",initializeApplianceDetailModel.isHsmAuditLog());
				initData.put("certAuth",initializeApplianceDetailModel.getCertAuthentication());
				initData.put("loginFailCount",initializeApplianceDetailModel.getLoginFailureCount());               
				initData.put("maxPasswordLength",initializeApplianceDetailModel.getMaximumPasswordLength());
				initData.put("minPasswordLength",initializeApplianceDetailModel.getMinimumPasswordLength());                           
				initData.put("label",initializeApplianceDetailModel.getHsmLabel());

				if(initializeApplianceDetailModel.getDualFactorAuthDetailModel()!=null){
					if(caviumResponseModel!=null){
						initData.put("dfCertificate",caviumResponseModel.getResponseMessage());
					}
					initData.put("dfHostname",initializeApplianceDetailModel.getDualFactorAuthDetailModel().getDualFactorAuthServerAddress());
					initData.put("dfPort",initializeApplianceDetailModel.getDualFactorAuthDetailModel().getDualFactorAuthServerPortNo());
				}
				json.put("initData", initData);
				try{
					ResponseEntity<String> response=restClient.invokePOSTMethodForOperations("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/initialize", json);
					if (response != null && response.getBody() != null) {
						ObjectMapper mapper = new ObjectMapper();
						JsonNode root = mapper.readTree(response.getBody());
						if(response!=null && response.getBody()!=null && response.getBody().contains("success")) {
							long applianceId=applianceDetailModel.getApplianceId();
							InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(applianceId);
							if(initmodel!=null){
								initializeRepository.delete(initmodel.getInitializeId());
								initializeAppliancesRelationshipReposiotry.delete(initmodel.getId());
							}
							applianceRepository.save(dbAppliance);
							initializeAppliancesRelationshipReposiotry.save(initializeAppliancesRelationshipModel);    
							dbAppliance.setLastOperationPerformed(env.getProperty("appliance.initialize"));
							dbAppliance.setLastOperationStatus("In-Progress");
							dbAppliance.setCode("200");
							dbAppliance.setMessage(env.getProperty("appliance.initialize.success"));
							applianceRepository.save(dbAppliance);
							updateInProgressActivity(dbAppliance, loggedInUser, root);
						}else {
							dbAppliance = getErrorMessage(response, dbAppliance, loggedInUser, "Initialize");
							dbAppliance.setApplianceinitialized(false);
							dbAppliance.setCredentialSaved(false);
							applianceRepository.save(dbAppliance);
							initializeRepository.delete(initializeApplianceDetailModel);
						}
					}else {
						dbAppliance = getErrorMessage(response, dbAppliance, loggedInUser, "Initialize");
						dbAppliance.setApplianceinitialized(false);
						dbAppliance.setCredentialSaved(false);
						applianceRepository.save(dbAppliance);
						initializeRepository.delete(initializeApplianceDetailModel);
					}
				}catch (Exception e) {
					logger.error("Error occured during initialize object"+e.getMessage());
					dbAppliance.setApplianceinitialized(false);
					dbAppliance.setCredentialSaved(false);
					applianceRepository.save(dbAppliance);
					initializeRepository.delete(initializeApplianceDetailModel);
				}
			}else {
				dbAppliance=applianceDetailModel;
				dbAppliance.setCode("409");
				dbAppliance.setMessage("appliance does not exists into the system");
			}
			return dbAppliance;
		}
	}

	/*
	 * This method is used to get AdminHost Details from Cavium REST API
	 * 
	 */
	public HostStats GetHostAdminVMStats(ApplianceDetailModel applianceDetailModel,HostStats hostStats,String apiName){
		try{
			ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/"+apiName);
			if(response!=null && response.getStatusCode().name().equals("OK")) {
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						String status = root.path("status").asText();
						String operation = root.path("operation").asText();
						String partitionName = root.path("partitionName").asText();
						long startTime = root.path("startTime").asLong();
						long endTime = root.path("endTime").asLong();
						String startDateTime=CaviumUtil.formatDatefromLong(startTime);
						String endDateTime=CaviumUtil.formatDatefromLong(endTime);
						String message = root.path("message").asText();
						String jobId = root.path("jobId").asText();
						JsonNode dataNode = root.path("data");
						hostStats.setStatus(status);
						hostStats.setEndTime(endDateTime);
						hostStats.setStartTime(startDateTime);
						hostStats.setOperation(operation);
						hostStats.setPartitionName(partitionName);
						hostStats.setMessage(message);
						hostStats.setJobId(jobId);						 
						/*	if(!errors.isNull()){
							Iterator<JsonNode> itr = errors.elements();					         
							while (itr.hasNext()) {
								JsonNode temp = itr.next();
							}
						}*/
						if(!dataNode.isNull()){
							if(dataNode.has("vmstats")){
								Data data = new Data();
								hostStats.setDataObject(data);
								JsonNode vmstatsNode = dataNode.path("vmstats");
								if(!vmstatsNode.isNull()){
									Vmstats vmstats= new Vmstats();
									data.setVmstatsObject(vmstats);
									if(vmstatsNode.has("cavServerStatus")){										
										double cavServerStatus=vmstatsNode.path("cavServerStatus").asDouble();
										vmstats.setCavServerStatus(cavServerStatus);
									}
									if(vmstatsNode.has("systemUpTime")){										
										JsonNode systemUpTimeNode = vmstatsNode.path("systemUpTime");
										if(!systemUpTimeNode.isNull()){
											long totalSeconds=0;
											SystemUpTime systemUpTime= new SystemUpTime();
											vmstats.setSystemUpTimeObject(systemUpTime);
											if(systemUpTimeNode.has("hours")){
												long hours=systemUpTimeNode.path("hours").asLong();
												systemUpTime.setHours(hours);
												totalSeconds=totalSeconds+CaviumUtil.hoursToSeconds(hours);
											}
											if(systemUpTimeNode.has("minutes")){
												long minutes=systemUpTimeNode.path("minutes").asLong();
												systemUpTime.setMinutes(minutes);
												totalSeconds=totalSeconds+CaviumUtil.minutesToSeconds(minutes);
											}
											if(systemUpTimeNode.has("seconds")){
												long seconds=systemUpTimeNode.path("seconds").asLong();
												systemUpTime.setSeconds(seconds);
												totalSeconds=totalSeconds+seconds;
											}
											systemUpTime.setFormatedDate(CaviumUtil.timeInDaysHoursFormat(totalSeconds));
										}
									}
									if(vmstatsNode.has("rxQueue")){
										JsonNode rxQueueNode = vmstatsNode.path("rxQueue");
										if(!rxQueueNode.isNull()){
											RxQueue rxQueue= new RxQueue();
											vmstats.setRxQueueObject(rxQueue);
											if(rxQueueNode.has("rdt")){
												double rdt=rxQueueNode.path("rdt").asDouble();
												rxQueue.setRdt(rdt);
											}
											if(rxQueueNode.has("rdh")){
												double rdh=rxQueueNode.path("rdh").asDouble();
												rxQueue.setRdh(rdh);
											}						 
										}
									}
									if(vmstatsNode.has("drvReqIdQueue")){
										JsonNode drvReqIdQueueNode = vmstatsNode.path("drvReqIdQueue");
										if(!drvReqIdQueueNode.isNull()){
											DrvReqIdQueue drvReqIdQueue = new DrvReqIdQueue();
											vmstats.setDrvReqIdQueueObject(drvReqIdQueue);
											if(drvReqIdQueueNode.has("head")){
												double head=drvReqIdQueueNode.path("head").asDouble();
												drvReqIdQueue.setHead(head);
											}
											if(drvReqIdQueueNode.has("tail")){
												double tail=drvReqIdQueueNode.path("tail").asDouble();
												drvReqIdQueue.setTail(tail);
											}						 
										}
									}
									if(vmstatsNode.has("ramStats(mb)")){
										JsonNode ramStatsNode = vmstatsNode.path("ramStats(mb)");
										if(!ramStatsNode.isNull()){
											RamStats ramStats= new RamStats();
											vmstats.setRamStats(ramStats);
											if(ramStatsNode.has("total")){
												double total=ramStatsNode.path("total").asDouble();
												ramStats.setTotal(total);
											}
											if(ramStatsNode.has("free")){
												double free=ramStatsNode.path("free").asDouble();
												ramStats.setFree(free);
											}	
											ramStats.setUsed(ramStats.getTotal()-ramStats.getFree());
											ramStats.setUsedPercentage(CaviumUtil.calculatePercetage(ramStats.getTotal(),ramStats.getUsed()));
										}
									}		
									if(vmstatsNode.has("txQueue")){
										JsonNode txQueueNode = vmstatsNode.path("txQueue");
										if(!txQueueNode.isNull()){
											TxQueue txQueue= new TxQueue();
											vmstats.setTxQueueObject(txQueue);
											if(txQueueNode.has("tdh")){
												double tdh=txQueueNode.path("tdh").asDouble();
												txQueue.setTdh(tdh);
											}
											if(txQueueNode.has("tdt")){
												double tdt=txQueueNode.path("tdt").asDouble();
												txQueue.setTdt(tdt);
											}						 
										}
									}
									if(vmstatsNode.has("fwReqIdQueue")){
										JsonNode fwReqIdQueueNode = vmstatsNode.path("fwReqIdQueue");
										if(!fwReqIdQueueNode.isNull()){
											FwReqIdQueue fwReqIdQueue= new FwReqIdQueue();
											vmstats.setFwReqIdQueueObject(fwReqIdQueue);
											if(fwReqIdQueueNode.has("head")){
												double head=fwReqIdQueueNode.path("head").asDouble();
												fwReqIdQueue.setHead(head);
											}
											if(fwReqIdQueueNode.has("tail")){
												double tail=fwReqIdQueueNode.path("tail").asDouble();
												fwReqIdQueue.setTail(tail);
											}						 
										}
									}
									if(vmstatsNode.has("swapStats(mb)")){
										JsonNode swapStatsNode = vmstatsNode.path("swapStats(mb)");
										if(!swapStatsNode.isNull()){
											SwapStats swapStats= new SwapStats();
											vmstats.setSwapStats(swapStats);
											if(swapStatsNode.has("total")){
												double total=swapStatsNode.path("total").asDouble();
												swapStats.setTotal(total);
											}
											if(swapStatsNode.has("free")){
												double free=swapStatsNode.path("free").asDouble();
												swapStats.setFree(free);
											}

											swapStats.setUsedPercentage(CaviumUtil.calculatePercetage(swapStats.getTotal(),swapStats.getUsed()));
										}
									}							
									if(vmstatsNode.has("linkStatus(eth0)")){
										double linkStatusEth0=vmstatsNode.path("linkStatus(eth0)").asDouble();
										vmstats.setLinkStatusEth0(linkStatusEth0);
									}
									if(vmstatsNode.has("cpuUsage(%)")){
										double cpuUsage=vmstatsNode.path("cpuUsage(%)").asDouble();	
										vmstats.setCpuUsage(cpuUsage);
									}
									if(vmstatsNode.has("linkStatus(eth1)")){
										double linkStatusEth01=vmstatsNode.path("linkStatus(eth1)").asDouble();
										vmstats.setLinkStatusEth1(linkStatusEth01);
									}
									if(vmstatsNode.has("processCount")){
										double processCount=vmstatsNode.path("processCount").asDouble();
										vmstats.setProcessCount(processCount);
									}
									if(vmstatsNode.has("freeSpace(mb)")){
										double freeSpace=vmstatsNode.path("freeSpace(mb)").asDouble();
										vmstats.setFreeSpace(freeSpace);									 
									}
									if(vmstatsNode.has("driverStatus")){
										double driverStatus=vmstatsNode.path("driverStatus").asDouble();
										vmstats.setDriverStatus(driverStatus);		
										if(driverStatus==0){
											vmstats.setDriverStatusStr("down");
										}
										if(driverStatus==1){
											vmstats.setDriverStatusStr("Up");
										}
									}		
								}

							}
						}
					}
				}
			}
		}catch(Exception exp){
			logger.error("Error occured during fetch AdminHostStats Info of class ApplianceServiceImpl ::" + exp.getMessage());
		}
		return hostStats;
	}
	/*
	 * This method is used to get Appliance Information from Cavium REST API 
	 *
	 */
	public ApplianceInfo GetApplianceInfo(ApplianceDetailModel applianceDetailModel ,ApplianceInfo applianceInfo){
		try{
			ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/appliance_info");
			if(response!=null && response.getStatusCode().name().equals("OK")) {
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						String status = root.path("status").asText();
						//JsonNode errors = root.path("errors");
						String operation = root.path("operation").asText();
						long startTime = root.path("startTime").asLong();
						long endTime = root.path("endTime").asLong();
						String startDateTime=CaviumUtil.formatDatefromLong(startTime);
						String endDateTime=CaviumUtil.formatDatefromLong(endTime);
						String message = root.path("message").asText();
						applianceInfo.setStatus(status);
						applianceInfo.setOperation(operation);
						applianceInfo.setStartTime(startDateTime);
						applianceInfo.setEndTime(endDateTime);
						applianceInfo.setErrorMessage(message);
						/*	if(!errors.isNull()){
							Iterator<JsonNode> itr = errors.elements();					         
							while (itr.hasNext()) {
								JsonNode temp = itr.next();    
							}
						}	*/					
						JsonNode dataNode = root.path("data");
						if(!dataNode.isNull()){
							if(dataNode.has("linuxVersion")) {
								String linuxVersion = dataNode.path("linuxVersion").asText();
								applianceInfo.setLinuxVersion(linuxVersion);
							}
							if(dataNode.has("serialNum")) {
								String serialNum = dataNode.path("serialNum").asText();
								applianceInfo.setSerialNum(serialNum);
							}
							if(dataNode.has("firmwareVersion")) {
								String firmwareVersion = dataNode.path("firmwareVersion").asText();
								applianceInfo.setFirmwareVersion(firmwareVersion);
							}
						}
					}
				}
			}		
		}catch(Exception exp){
			logger.error("Error occured during fetch Appliance Info of class ApplianceServiceImpl ::" + exp.getMessage());	
		}
		return applianceInfo;
	}

	/*
	 * This method is used to get HSM Information from Cavium REST API 
	 *  
	 */

	public HSMInfo getHSMInfo(ApplianceDetailModel applianceDetailModel,HSMInfo objHSMInfo){
		try{

			ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/info");
			if(response!=null && response.getStatusCode().name().equals("OK")) {
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						String status = root.path("status").asText();
						//JsonNode errors = root.path("errors");
						String operation = root.path("operation").asText();
						String partitionName = root.path("partitionName").asText();
						long startTime = root.path("startTime").asLong();
						long endTime = root.path("endTime").asLong();
						String startDateTime=CaviumUtil.formatDatefromLong(startTime);
						String endDateTime=CaviumUtil.formatDatefromLong(endTime);
						String message = root.path("message").asText();
						int jobId = root.path("jobId").asInt();
						JsonNode dataNode = root.path("data");
						objHSMInfo.setStatus(status);
						objHSMInfo.setOperation(operation);
						objHSMInfo.setPartitionName(partitionName);
						objHSMInfo.setStartTime(startDateTime);
						objHSMInfo.setEndTime(endDateTime);
						objHSMInfo.setErrorMessage(message);
						objHSMInfo.setJobId(jobId);
						/*	if(!errors.isNull()){
							Iterator<JsonNode> itr = errors.elements();                                       
							while (itr.hasNext()) {
								JsonNode temp = itr.next();                                              
							}
						}*/
						if(!dataNode.isNull()){
							if(dataNode.has("totalPublicMemory(KB)")) {
								int totalPublicMemory = dataNode.path("totalPublicMemory(KB)").asInt();
								objHSMInfo.setTotalPublicMemory(totalPublicMemory);
							}
							if(dataNode.has("mwVersion")) {
								String mwVersion = dataNode.path("mwVersion").asText();
								objHSMInfo.setMwVersion(mwVersion);
							}
							if(dataNode.has("hardwareMinor")) {
								String hardwareMinor = dataNode.path("hardwareMinor").asText();
								objHSMInfo.setHardwareMinor(hardwareMinor);
							}
							if(dataNode.has("systemVendorId")) {
								String systemVendorId = dataNode.path("systemVendorId").asText();
								objHSMInfo.setSystemVendorId(systemVendorId);
							}
							if(dataNode.has("cuLoginFailure")) {
								int cuLoginFailure = dataNode.path("cuLoginFailure").asInt();
								objHSMInfo.setCuLoginFailure(cuLoginFailure);
							}
							if(dataNode.has("rwSessionCount")) {
								int rwSessionCount = dataNode.path("rwSessionCount").asInt();
								objHSMInfo.setRwSessionCount(rwSessionCount);
							}
							if(dataNode.has("coLoginFailure")) {
								int coLoginFailure = dataNode.path("coLoginFailure").asInt();
								objHSMInfo.setCoLoginFailure(coLoginFailure);
							}
							if(dataNode.has("freePrivateMemory(KB)")) {
								int freePrivateMemory = dataNode.path("freePrivateMemory(KB)").asInt();
								objHSMInfo.setFreePrivateMemory(freePrivateMemory);
							}
							if(dataNode.has("slaveConfig")) {
								String slaveConfig = dataNode.path("slaveConfig").asText();
								objHSMInfo.setSlaveConfig(slaveConfig);
							}
							if(dataNode.has("temperature")) {
								String temperature = dataNode.path("temperature").asText();
								objHSMInfo.setTemperature(temperature);
							}
							if(dataNode.has("firmwareMajor")) {
								String firmwareMajor = dataNode.path("firmwareMajor").asText();
								objHSMInfo.setFirmwareMajor(firmwareMajor);;
							}
							if(dataNode.has("label")) {
								String label = dataNode.path("label").asText();
								objHSMInfo.setLabel(label);
							}
							if(dataNode.has("subSystemId")) {
								String subSystemId = dataNode.path("subSystemId").asText();
								objHSMInfo.setSubSystemId(subSystemId);
							}
							if(dataNode.has("manufacturerId")) {
								String manufacturerId = dataNode.path("manufacturerId").asText();
								objHSMInfo.setManufacturerId(manufacturerId);
							}
							if(dataNode.has("masterConfig")) {
								String masterConfig = dataNode.path("masterConfig").asText();
								objHSMInfo.setMasterConfig(masterConfig);
							}
							if(dataNode.has("authenticationPath")) {
								int authenticationPath = dataNode.path("authenticationPath").asInt();
								objHSMInfo.setAuthenticationPath(authenticationPath);

							}
							if(dataNode.has("classCode")) {
								int classCode = dataNode.path("classCode").asInt();
								objHSMInfo.setClassCode(classCode);
							}
							if(dataNode.has("maxSessionCount")) {
								int maxSessionCount = dataNode.path("maxSessionCount").asInt();
								objHSMInfo.setMaxSessionCount(maxSessionCount);
							}
							if(dataNode.has("manufacturerId")) {
								String manufacturerId = dataNode.path("manufacturerId").asText();
								objHSMInfo.setManufacturerId(manufacturerId);
							}
							if(dataNode.has("sessionCount")) {
								int sessionCount = dataNode.path("sessionCount").asInt();
								objHSMInfo.setSessionCount(sessionCount);
							}
							if(dataNode.has("firmwareId")) {
								String firmwareId = dataNode.path("firmwareId").asText();
								objHSMInfo.setFirmwareId(firmwareId);
							}
							if(dataNode.has("maxRwSessionCount")) {
								int maxRwSessionCount = dataNode.path("maxRwSessionCount").asInt();
								objHSMInfo.setMaxRwSessionCount(maxRwSessionCount);
							}
							if(dataNode.has("buildNumber")) {
								String buildNumber = dataNode.path("buildNumber").asText();
								objHSMInfo.setBuildNumber(buildNumber);
							}
							if(dataNode.has("hardwareMajor")) {
								String hardwareMajor = dataNode.path("hardwareMajor").asText();
								objHSMInfo.setHardwareMajor(hardwareMajor);
							}
							if(dataNode.has("minPswdLen")) {
								int minPswdLen = dataNode.path("minPswdLen").asInt();
								objHSMInfo.setMinPswdLen(minPswdLen);
							}
							if(dataNode.has("maxPswdLen")) {
								int maxPswdLen = dataNode.path("maxPswdLen").asInt();
								objHSMInfo.setMaxPswdLen(maxPswdLen);
							}
							if(dataNode.has("totalPrivateMemory(KB)")) {
								int totalPrivateMemory = dataNode.path("totalPrivateMemory(KB)").asInt();
								objHSMInfo.setTotalPrivateMemory(totalPrivateMemory);
							}
							if(dataNode.has("firmwareMinor")) {
								String firmwareMinor = dataNode.path("firmwareMinor").asText();
								objHSMInfo.setFirmwareMinor(firmwareMinor);
							}
							if(dataNode.has("partNumber")) {
								String partNumber = dataNode.path("partNumber").asText();
								objHSMInfo.setPartNumber(partNumber);
							}
							if(dataNode.has("freePublicMemory(KB)")) {
								int freePublicMemory = dataNode.path("freePublicMemory(KB)").asInt();
								objHSMInfo.setFreePublicMemory(freePublicMemory);
							}
							if(dataNode.has("serialNumber")){
								String serialNumber = dataNode.path("serialNumber").asText();
								objHSMInfo.setSerialNumber(serialNumber);
							}
							if(dataNode.has("fipsState")) {
								String fipsState = dataNode.path("fipsState").asText();
								objHSMInfo.setFipsState(fipsState);                                      
							}
							if(dataNode.has("hsmFlags")) {
								int hsmFlags = dataNode.path("hsmFlags").asInt();
								objHSMInfo.setHsmFlags(hsmFlags);
							}
							if(dataNode.has("model")) {
								String model = dataNode.path("model").asText();
								objHSMInfo.setModel(model);
							}
							if(dataNode.has("deviceId")) {
								String deviceId = dataNode.path("deviceId").asText();
								objHSMInfo.setDeviceId(deviceId);
							}
							StringBuffer firmwareVersion= new StringBuffer();
							if(objHSMInfo.getFirmwareMajor()!=null){
								firmwareVersion=firmwareVersion.append(objHSMInfo.getFirmwareMajor()+":");
							}
							if(objHSMInfo.getFirmwareMinor()!=null){
								firmwareVersion=firmwareVersion.append(objHSMInfo.getFirmwareMinor()+":");
							}
							if(objHSMInfo.getBuildNumber()!=null){
								firmwareVersion=firmwareVersion.append(objHSMInfo.getBuildNumber());
							}
							objHSMInfo.setFirmwareVersion(firmwareVersion.toString());
						}
					}
				}
			}
		}catch(Exception exp){
			logger.error("Error occured during fetch HSM Info of class ApplianceServiceImpl ::" + exp.getMessage()); 
		}
		return objHSMInfo;
	}


	/*
	 * This method is used to get Admin VM Self Test Report Information from Cavium REST API 
	 *  
	 */

	public AdminVMSelfTestReport getAdminVMSelfTestReport (ApplianceDetailModel applianceDetailModel,AdminVMSelfTestReport objAdminVMSFT){
		try{

			ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/admin_vm_selftest_report");
			if(response!=null && response.getStatusCode().name().equals("OK")) {
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						String status = root.path("status").asText();
						//JsonNode errors = root.path("errors");
						String operation = root.path("operation").asText();
						long startTime = root.path("startTime").asLong();
						String startDateTime=CaviumUtil.formatDatefromLong(startTime);
						String message = root.path("message").asText();
						int jobId = root.path("jobId").asInt();
						JsonNode dataNode = root.path("data");
						objAdminVMSFT.setStatus(status);
						objAdminVMSFT.setOperation(operation);
						objAdminVMSFT.setStartTime(startDateTime);
						objAdminVMSFT.setErrorMessage(message);
						objAdminVMSFT.setJobId(jobId);
						/*	if(!errors.isNull()){
							Iterator<JsonNode> itr = errors.elements();                                       
							while (itr.hasNext()) {
								JsonNode temp = itr.next();                                              
							}
						}*/
						if(!dataNode.isNull()){
							if(dataNode.has("SelfTest")) {
								String SelfTest = dataNode.path("SelfTest").toString();
								objAdminVMSFT.setSelfTest(SelfTest);
							}

						}
					}
				}
			}
		}catch(Exception exp){
			logger.error("Error occured during fetch HSM Info of class ApplianceServiceImpl ::" + exp.getMessage()); 
		}
		return objAdminVMSFT;
	}

	/*
	 * This method is used to get Host Self Test Report Information from Cavium REST API 
	 *  
	 */

	public HostSelfTestReport getHostSelfTestReport (ApplianceDetailModel applianceDetailModel,HostSelfTestReport objHostSFT){
		try{

			ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/admin_vm_selftest_report");
			if(response!=null && response.getStatusCode().name().equals("OK")) {
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						String status = root.path("status").asText();
						//JsonNode errors = root.path("errors");
						String operation = root.path("operation").asText();
						long startTime = root.path("startTime").asLong();
						String startDateTime=CaviumUtil.formatDatefromLong(startTime);
						String message = root.path("message").asText();
						int jobId = root.path("jobId").asInt();
						JsonNode dataNode = root.path("data");
						objHostSFT.setStatus(status);
						objHostSFT.setOperation(operation);
						objHostSFT.setStartTime(startDateTime);
						objHostSFT.setErrorMessage(message);
						objHostSFT.setJobId(jobId);
						/*	if(!errors.isNull()){
							Iterator<JsonNode> itr = errors.elements();                                       
							while (itr.hasNext()) {
								JsonNode temp = itr.next();                                              
							}
						}*/
						if(!dataNode.isNull()){
							if(dataNode.has("SelfTest")) {
								String SelfTest = dataNode.path("SelfTest").toString();
								objHostSFT.setSelfTest(SelfTest);
							}

						}
					}
				}
			}
		}catch(Exception exp){
			logger.error("Error occured during fetch HSM Info of class ApplianceServiceImpl ::" + exp.getMessage()); 
		}
		return objHostSFT;
	}
	/***
	 * This method is used for search operation as normal and advanced search
	 */
	@Override
	public List<ApplianceDetailModel> searchAppliance(ApplianceDetailModel applianceDetailModel) {
		List<ApplianceDetailModel> serachApplianceDetailModel=null;
		try {
			String applianceName = applianceDetailModel.getApplianceName();
			String applianceStatus = applianceDetailModel.getApplianceStatus();
			String ipAddress = applianceDetailModel.getIpAddress();
			String hostName = applianceDetailModel.getHostName();
			String ipmiIp = applianceDetailModel.getIpmiIp();

			if (applianceName == null) {
				applianceName = "";
			}
			if (applianceStatus == null) {
				applianceStatus = "";
			}
			if (ipAddress == null) {
				ipAddress = "";
			}

			if (hostName == null) {
				hostName = "";
			}
			if (ipmiIp == null) {
				ipmiIp = "";
			}
			serachApplianceDetailModel=applianceRepository.serchAppliance(applianceName,applianceStatus,ipAddress,hostName,ipmiIp,StoreType.PERMANENT);

		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Error occured during serach operation on appliance inside method searchAppliance of class ApplianceDetailModel ");
		}
		// TODO Auto-generated method stub
		return serachApplianceDetailModel;
	}

	@Override
	public List<ApplianceDetailModel> getListOfTempAppliances() {
		String loggedInUser = userAttributes.getlogInUserName();
		List<ApplianceDetailModel> applianceTempModel=null;
		try {
			applianceTempModel=applianceRepository.getListOfTempAppliancesByUserId(loggedInUser,StoreType.TEMP);
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Error occured during fetch of the temporary list of appliances");
		}
		// TODO Auto-generated method stub
		return applianceTempModel;
	}


	@Override
	public CaviumResponseModel createApplianceForTesting(List<ApplianceDetailModel> applianceDetailModel) {

		// TODO Auto-generated method stub
		CaviumResponseModel responseModel=getCaviumResponseModel();
		try {
			if (applianceDetailModel != null && applianceDetailModel.size() > 0) {
				String loggedInUser = userAttributes.getlogInUserName();
				for(ApplianceDetailModel app : applianceDetailModel) {
					List<ApplianceDetailModel> tempApplianceDetailmodel=applianceRepository.getApplianceExists(app.getIpAddress());
					if(tempApplianceDetailmodel.size() == 0) {
						app.setCreatedBy(loggedInUser);
						app.setCreatedDate(new Date());
						app.setStoreType(StoreType.PERMANENT);
						app.setApplianceStatus("Active");
						if(StringUtils.isEmpty(app.getAuthId())) {
							app.setAuthId("1234");
						}
						ApplianceDetailModel applianceTemp=applianceRepository.save(app);
						if(applianceTemp!=null) {
							List<UserGroupModel> usg=userGroupRepository.findGroupDetailsForGroupName(env.getProperty("user.defaultusergroup")); 
							if(!usg.isEmpty()) {
								UserGroupModel userGroupModel=(UserGroupModel)usg.get(0);
								DesignationApplianceModel designationApplianceModel=new DesignationApplianceModel();
								designationApplianceModel.setDesignationId(userGroupModel.getId());
								designationApplianceModel.setObjApplianceDetailModel(applianceTemp);
								designationAppliance.save(designationApplianceModel);
							}
						}
						responseModel.setResponseCode("200");
						responseModel.setResponseMessage(env.getProperty("applianceCreation.success"));
						recentActivityServiceImpl.createRecentActivity(loggedInUser, "New device "+app.getApplianceName()+" added by "+loggedInUser,CaviumConstant.APPLIANCE_MANAGEMENT);

					}else {
						responseModel.setResponseCode("409");
						responseModel.setResponseMessage("Failed to create as already available");
					}
				}
			} else {
				logger.error("ApplianceDetailModel is empty or null ::");
				responseModel.setResponseCode("204");
				responseModel.setResponseMessage(env.getProperty("applianceCreation.failureEmpty"));
			}
		} catch (Exception e) {
			logger.error("Error occured due to db error inside createAppliance Method of class ApplianceServiceImpl ::" + e.getMessage());
			responseModel.setResponseCode("500");
			responseModel.setResponseMessage(env.getProperty("applianceCreation.failureDB"));
		}
		return responseModel;
	}

	public List<ApplianceCityDetail>listAppliancesDetailCityWise(List<ApplianceDetailModel> listApplianceDetailModels){
		TreeMap<String,ApplianceCityDetail> cityNameMap= new TreeMap<String, ApplianceCityDetail>(String.CASE_INSENSITIVE_ORDER);
		ApplianceCityDetail objApplianceCityDetail= null;	
		List<ApplianceCityDetail> listApplianceToplology=null;
		for (Iterator<ApplianceDetailModel> iterator = listApplianceDetailModels.iterator(); iterator.hasNext();) {
			ApplianceDetailModel applianceDetailModel = (ApplianceDetailModel) iterator.next();
			String cityName=applianceDetailModel.getCityName();
			logger.info("cityName :: Appliance Status "+cityName +"::"+applianceDetailModel.getApplianceStatus());	 
			if("Active".equals(applianceDetailModel.getApplianceStatus())){

				if(!cityNameMap.containsKey(cityName)){
					objApplianceCityDetail= new ApplianceCityDetail();
					objApplianceCityDetail.setCityName(cityName);
					cityNameMap.put(cityName,objApplianceCityDetail);	
				}					 					
				if(cityNameMap.containsKey(cityName)){
					objApplianceCityDetail=cityNameMap.get(cityName);
					objApplianceCityDetail.getApplianceStatus().setActiveStatus((objApplianceCityDetail.getApplianceStatus().getActiveStatus()+1));
				}
			}
			if("Inactive".equals(applianceDetailModel.getApplianceStatus())){
				if(!cityNameMap.containsKey(cityName)){		
					objApplianceCityDetail= new ApplianceCityDetail();
					objApplianceCityDetail.setCityName(cityName);
					cityNameMap.put(cityName,objApplianceCityDetail);
				}					 					
				if(cityNameMap.containsKey(cityName)){
					objApplianceCityDetail=cityNameMap.get(cityName);
					objApplianceCityDetail.getApplianceStatus().setInactiveStatus((objApplianceCityDetail.getApplianceStatus().getInactiveStatus()+1));
				}
			}
			if("Suspended".equals(applianceDetailModel.getApplianceStatus())){
				if(!cityNameMap.containsKey(cityName)){
					objApplianceCityDetail= new ApplianceCityDetail();
					objApplianceCityDetail.setCityName(cityName);
					cityNameMap.put(cityName,objApplianceCityDetail);	
				}					 					
				if(cityNameMap.containsKey(cityName)){
					objApplianceCityDetail=cityNameMap.get(cityName);
					objApplianceCityDetail.getApplianceStatus().setSuspendedStatus((objApplianceCityDetail.getApplianceStatus().getSuspendedStatus()+1));
				}
			}
		}
		listApplianceToplology = new ArrayList<ApplianceCityDetail>(cityNameMap.values());
		return listApplianceToplology;
	}
	/*
	 * setHostNetorkVmConfig is used to send the network Data in Cavium Rest API 
	 * @ requestParam : adminVMData
	 *  
	 */
	public CaviumResponseModel setHostNetorkVmConfig(String applianceIp,AdminVMData adminVMData){
		CaviumResponseModel responseModel=getCaviumResponseModel();
		try{
			JSONObject json = new JSONObject(); 
			ApplianceDetailModel dbAppliance=applianceRepository.findOne(Long.parseLong(adminVMData.getApplianceId())); 
			if(dbAppliance!=null) {
				long applianceId=dbAppliance.getApplianceId();  
				InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(applianceId);
				if(initmodel!=null) {
					InitializeApplianceDetailModel initAppDetailModel = initializeRepository.findOne(initmodel.getInitializeId());
					DualFactorAuthDetailModel dualAuthModel=initAppDetailModel.getDualFactorAuthDetailModel();
					if(!StringUtils.isEmpty(adminVMData.getUsername()) && !StringUtils.isEmpty(adminVMData.getPassword())) {
						if(initAppDetailModel.getAuthenticationLevel()==0) {
							json.put("username", adminVMData.getUsername());
							json.put("password", adminVMData.getPassword());
						}if(initAppDetailModel.getAuthenticationLevel()==1 && dualAuthModel!=null) {
							json.put("username", adminVMData.getUsername());
							json.put("password", adminVMData.getPassword());
							json.put("dualFactorHostname", dualAuthModel.getDualFactorAuthServerAddress());
							json.put("dualFactorPort", dualAuthModel.getDualFactorAuthServerPortNo());
							json.put("dualFactorCertificate", dualAuthModel.getDualFactorAuthServerCertId());
						}
					}else {
						if(initAppDetailModel.getAuthenticationLevel()==0) {
							json.put("username", initAppDetailModel.getCryptoOfficerName());
							json.put("password", CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));
						}if(initAppDetailModel.getAuthenticationLevel()==1 && dualAuthModel!=null) {
							json.put("username", initAppDetailModel.getCryptoOfficerName());
							json.put("password", CaviumUtil.decrypt(initAppDetailModel.getCryptoOfficerPassword()));
							json.put("dualFactorHostname", dualAuthModel.getDualFactorAuthServerAddress());
							json.put("dualFactorPort", dualAuthModel.getDualFactorAuthServerPortNo());
							json.put("dualFactorCertificate", dualAuthModel.getDualFactorAuthServerCertId());
						}
					}
				}else {
					if(!StringUtils.isEmpty(adminVMData.getUsername()) && !StringUtils.isEmpty(adminVMData.getUsername())) {
						json.put("username", adminVMData.getUsername());
						json.put("password", adminVMData.getUsername());
					}else {
						responseModel.setResponseCode("409");
						responseModel.setResponseMessage("Host Network data not saved due to credentials not available");
						return responseModel;
						//	alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+"  try to perofrm reboot by "+loggedInUser+ " at "+CaviumUtil.formatDateTimeFromCurrenDate(new Date()) +" doesnot reboot.");
					}
				}


				Map<String,Object> general= new HashMap<String,Object>();
				general.put("gateway", adminVMData.getGeneral().getGateway());
				general.put("ip",adminVMData.getGeneral().getIp());
				general.put("subnetMask", adminVMData.getGeneral().getSubnet());
				general.put("dhcp", adminVMData.getGeneral().getDhcp());
				general.put("vlan", adminVMData.getGeneral().getVlan());	
				Map<String,Object> mac= new HashMap<String,Object>();
				mac.put("staticMac", adminVMData.getGeneral().getMacStatic());
				mac.put("address", adminVMData.getGeneral().getMacAddress());
				general.put("mac", mac);
				json.put("general",general);
				Map<String,Object> advanced= new HashMap<String,Object>();
				Map<String,Object> dnsConfig= new HashMap<String,Object>();
				if(adminVMData.getAdvanced()!=null){
					dnsConfig.put("enableService",adminVMData.getAdvanced().getEnableDNSService());
					dnsConfig.put("searchDomainNames", adminVMData.getAdvanced().getSearchDomainNames());
					dnsConfig.put("dnservers", adminVMData.getAdvanced().getDnsServers());
					advanced.put("dnsConfig", dnsConfig);
					json.put("advanced",advanced);
					if(adminVMData.getAdvanced().getRemovedHostIPs()!=null && adminVMData.getAdvanced().getRemovedHostIPs().size()>0){
						json.put("remove",adminVMData.getAdvanced().getRemovedHostIPs());
					}
					Map<String,Object> staticIpToHostConfig= new HashMap<String,Object>();
					List<Map<String,Object>> addList= new ArrayList<Map<String,Object>>();
					if(adminVMData.getAdvanced().getStaticIpToHostConfig()!=null){
						for (Iterator<StaticIpToHostConfig> iterator = adminVMData.getAdvanced().getStaticIpToHostConfig().iterator(); iterator.hasNext();) {
							StaticIpToHostConfig  obj = (StaticIpToHostConfig) iterator.next();
							Map<String,Object> staticIpToHostConfigMap= new HashMap<String,Object>();
							staticIpToHostConfigMap.put("ip", obj.getIp());
							staticIpToHostConfigMap.put("hostname", obj.getHostname());
							staticIpToHostConfigMap.put("alias", obj.getAlias());
							addList.add(staticIpToHostConfigMap);
						}
						staticIpToHostConfig.put("add",addList);
						json.put("staticIpToHostConfig",staticIpToHostConfig);
					}
				}
				ResponseEntity<String> response=restClient.invokePOSTMethodForOperations("https://"+applianceIp+"/liquidsa/admin_vm_config", json);
				if(response!=null && response.getStatusCode().name().equals("OK")) {
					ObjectMapper mapper = new ObjectMapper();
					if(response.getBody()!=null){
						JsonNode root = mapper.readTree(response.getBody());
						if(!root.isNull()){
							String status = root.path("status").asText();
							if("success".equalsIgnoreCase(status)){
								responseModel.setResponseCode("200");
								responseModel.setResponseMessage("data saved successfully");
							}
							JsonNode errors = root.path("errors");
							if(!errors.isNull() && errors.size()>0){
								String encodeMessage = root.path("message").asText();
								Iterator<JsonNode> itr = errors.elements();                           
								while (itr.hasNext()) { 
									//	JsonNode temp = itr.next();
									if(StringUtils.isEmpty(encodeMessage)){
										responseModel.setResponseCode("409");
										responseModel.setResponseMessage("error is coming while saving data to cavium Network.");
									}
									else{
										responseModel.setResponseCode("409");
										responseModel.setResponseMessage(CaviumUtil.decodeMessageBase64(encodeMessage));
									}   
								}
							}
						}
					} 
				}
			}else {
				responseModel.setResponseCode("409");
				responseModel.setResponseMessage(env.getProperty("appliance.notexists.cavium"));
				//alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+"  try to perofrm reboot by "+loggedInUser+ " at "+CaviumUtil.formatDateTimeFromCurrenDate(new Date()) +" doesnot exist in cavium netwoork.");
			}
		}			
		catch (Exception e) {
			logger.error("Error occured during saving data in cavium network in setHostNetorkVmConfig method."+e.getMessage());
		}

		return responseModel;
	}
	/**
	 * This method will upload the files for firmware upgrade
	 * @param app
	 * @param coUsername
	 * @param coPassword
	 * @param dualAuthModel
	 * @return
	 */
	private HashMap<String,String> getUploadedFileNames(String ip,String coUsername,String coPassword,DualFactorAuthDetailModel dualAuthModel,MultipartFile imageFile,MultipartFile signFile){
		HashMap<String,String> map=new HashMap<>();
		String loggedInUser = userAttributes.getlogInUserName();
		List<ApplianceDetailModel> dbApplianc=applianceRepository.getApplianceExists(ip);
		try {
			File signFileConvertedFile=CaviumUtil.convertMultipartFileIntoNewFile(signFile);
			File imageFileConvertedFile=CaviumUtil.convertMultipartFileIntoNewFile(imageFile);
			if(dualAuthModel!=null) {
				if(imageFileConvertedFile!=null && signFileConvertedFile!=null) {
					CaviumResponseModel	imageFilePath=fileUploadService.uploadFileForFirmwareUpgrade(imageFile.getOriginalFilename(),imageFileConvertedFile,coUsername,coPassword,"FirmwareUpgrade",ip,dualAuthModel);
					CaviumResponseModel	signFilePath=fileUploadService.uploadFileForFirmwareUpgrade(signFile.getOriginalFilename(),signFileConvertedFile,coUsername,coPassword,"FirmwareUpgrade",ip,dualAuthModel);
					if(imageFilePath.getResponseCode().equalsIgnoreCase("200") && signFilePath.getResponseCode().equalsIgnoreCase("200")) {
						map.put("imageFilePath", imageFilePath.getResponseMessage());
						map.put("signFilePath", signFilePath.getResponseMessage());
					}else {
							if(dbApplianc!=null && dbApplianc.size() > 0) {
								ApplianceDetailModel dbAppliance=(ApplianceDetailModel)dbApplianc.get(0);
								ApplianceDetailModel db=applianceRepository.findOne(dbAppliance.getApplianceId());
								db.setLastOperationPerformed("FirmwareUpgrade");
								db.setLastOperationStatus("Completed");
								db.setCode("408");
								db.setMessage("Failed");
								if(!StringUtils.isEmpty(imageFilePath.getResponseMessage())) {
									db.setErrorMessage(imageFilePath.getResponseMessage());
								}
								if(!StringUtils.isEmpty(signFilePath.getResponseMessage())) {
									db.setErrorMessage(signFilePath.getResponseMessage());
								}else {
									db.setErrorMessage("Error occured during file upload for firmware upgrade");
									alertsService.createAlert(loggedInUser,"Device "+db.getApplianceName()+"  try to perofrm Upload for Firmware Upgrade by "+loggedInUser+" does not Upload due to "+db.getErrorMessage()+"",db.getApplianceName(),db.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
								}
								applianceRepository.save(db);
							}
					}
				}
			}else {
				if(imageFileConvertedFile!=null && signFileConvertedFile!=null) {
					CaviumResponseModel	imageFilePath=fileUploadService.uploadFileForFirmwareUpgrade(imageFile.getOriginalFilename(),imageFileConvertedFile,coUsername,coPassword,"FirmwareUpgrade",ip,null);
					CaviumResponseModel	signFilePath=fileUploadService.uploadFileForFirmwareUpgrade(signFile.getOriginalFilename(),signFileConvertedFile,coUsername,coPassword,"FirmwareUpgrade",ip,null);
					if(imageFilePath.getResponseCode().equalsIgnoreCase("200") && signFilePath.getResponseCode().equalsIgnoreCase("200")) {
						map.put("imageFilePath", imageFilePath.getResponseMessage());
						map.put("signFilePath", signFilePath.getResponseMessage());
					}else {
						if(dbApplianc!=null && dbApplianc.size() > 0) {
							ApplianceDetailModel dbAppliance=(ApplianceDetailModel)dbApplianc.get(0);
							ApplianceDetailModel db=applianceRepository.findOne(dbAppliance.getApplianceId());
							db.setLastOperationPerformed("FirmwareUpgrade");
							db.setLastOperationStatus("Completed");
							db.setCode("408");
							db.setMessage("Failed");
							if(!StringUtils.isEmpty(imageFilePath.getResponseMessage())) {
								db.setErrorMessage(imageFilePath.getResponseMessage());
							}
							if(!StringUtils.isEmpty(signFilePath.getResponseMessage())) {
								db.setErrorMessage(signFilePath.getResponseMessage());
							}else {
								db.setErrorMessage("Error occured during file upload for firmware upgrade");
								alertsService.createAlert(loggedInUser,"Device "+db.getApplianceName()+"  try to perofrm Upload for Firmware Upgrade by "+loggedInUser+" does not Upload due to "+db.getErrorMessage()+"",db.getApplianceName(),db.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
							}
							applianceRepository.save(db);
						}
					}
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getUploadedFileNames");
			if(dbApplianc!=null && dbApplianc.size() > 0) {
				ApplianceDetailModel dbAppliance=(ApplianceDetailModel)dbApplianc.get(0);
				ApplianceDetailModel db=applianceRepository.findOne(dbAppliance.getApplianceId());
				alertsService.createAlert(loggedInUser,"Device "+db.getApplianceName()+"  try to perofrm Upload for Firmware Upgrade by "+loggedInUser+" does not Upload due to appliance internal error",db.getApplianceName(),db.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
			}
			
		}
		return map;
	}




	public CaviumResponseModel getCertificateURL(String certificateType, String applianceIp) {

		String certificateUrl=null;
		String	errorMessage=null;
		CaviumResponseModel responseModel=getCaviumResponseModel();
		try{
			ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceIp+"/liquidsa/"+certificateType);
			if(response!=null && response.getStatusCode().name().equals("OK")) {
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						String status = root.path("status").asText();

						if("success".equalsIgnoreCase(status)){
							JsonNode dataNode = root.path("data");
							if(!dataNode.isNull() && dataNode.size()>0){
								if(dataNode.has("downloadCaviumCertificateUrlAddr")) {
									certificateUrl = dataNode.path("downloadCaviumCertificateUrlAddr").asText();
									responseModel.setResponseCode("200");
									responseModel.setResponseMessage(certificateUrl);
								}	 
							}
						}
						if("error".equalsIgnoreCase(status)){
							JsonNode errors = root.path("errors");
							if(!errors.isNull() && errors.size()>0){
								Iterator<JsonNode> itr = errors.elements();                           
								while (itr.hasNext()) {
									JsonNode temp = itr.next();
									if(temp.asInt()==11095)
									{ 
										errorMessage="HSM owner certificate is not installed."; 
									}
									if(temp.asInt()==11096)
									{ 
										errorMessage="HSM Certificate issued by HO is not installed."; 
									}
									if(temp.asInt()==11097)
									{ 
										errorMessage="HSM owner certificate is not installed.";

									}
								}
								responseModel.setResponseMessage(errorMessage);	  
								responseModel.setResponseCode("409");	  
							}
						}
					}
				}
			}				 
		}catch (Exception e) {
			logger.error("Error occured in  getCertificateURL Method :: "+e.getMessage());
		}
		return responseModel;
	}

	public CaviumResponseModel uploadCertificate(ManageCertificatesDetails manageCertificatesDetails) {

		CaviumResponseModel responseModel=getCaviumResponseModel();
		String hsmFileUploadedId=null;
		String signedHsmFileUploadedId=null;
		String username=null;
		String password=null;
		String dualFactorHostname=null;
		Integer dualFactorPort=null;
		String dualFactorCertificate=null;
		try{
			File hsmFile=null;
			File signedHsmFile=null;
			if(manageCertificatesDetails.getHsmFileContent()!=null && manageCertificatesDetails.getHsmFileExtension()!=null  && manageCertificatesDetails.getHsmFileName()!=null){
				hsmFile = CaviumUtil.createFile(manageCertificatesDetails.getHsmFileName(),manageCertificatesDetails.getHsmFileExtension(),manageCertificatesDetails.getHsmFileContent());
			}
			if(manageCertificatesDetails.getSignedHSMfileName()!=null && manageCertificatesDetails.getSignedHSMfileExtension()!=null && manageCertificatesDetails.getSignedHSMfileContent()!=null){
				signedHsmFile = CaviumUtil.createFile(manageCertificatesDetails.getSignedHSMfileName(),manageCertificatesDetails.getSignedHSMfileExtension(),manageCertificatesDetails.getSignedHSMfileContent());
			}
			InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(manageCertificatesDetails.getApplianceId());
			if(initmodel!=null) {
				InitializeApplianceDetailModel initAppDetailModel = initializeRepository.findOne(initmodel.getInitializeId());
				String operationPerformedPassword=CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword());
				String operationPerformedUserName= initAppDetailModel.getCryptoOfficerName();
				DualFactorAuthDetailModel dualAuthModel=initAppDetailModel.getDualFactorAuthDetailModel();
				username=operationPerformedUserName;
				password=operationPerformedPassword;
				if(dualAuthModel!=null) {
					dualFactorHostname=dualAuthModel.getDualFactorAuthServerAddress();
					dualFactorPort=dualAuthModel.getDualFactorAuthServerPortNo();
					dualFactorCertificate=dualAuthModel.getDualFactorAuthServerCertId();

					if(hsmFile!=null){
						responseModel=fileUploadService.uploadFile(hsmFile,operationPerformedUserName,operationPerformedPassword,"StoreHSMOwnerCerts",manageCertificatesDetails.getApplianceIp(),dualAuthModel);
						hsmFileUploadedId=responseModel.getResponseMessage();
					}
					if(signedHsmFile!=null){
						responseModel=fileUploadService.uploadFile(signedHsmFile,operationPerformedUserName,operationPerformedPassword,"StoreHSMOwnerCerts",manageCertificatesDetails.getApplianceIp(),dualAuthModel);
						signedHsmFileUploadedId=responseModel.getResponseMessage();
					}
				}
			}else{
				username=manageCertificatesDetails.getOperationUsername();
				password=manageCertificatesDetails.getOperationPassword();
				if(hsmFile!=null){
					responseModel=fileUploadService.uploadFile(hsmFile,manageCertificatesDetails.getOperationUsername(),manageCertificatesDetails.getOperationPassword(),"StoreHSMOwnerCerts",manageCertificatesDetails.getApplianceIp(),null);
					hsmFileUploadedId=responseModel.getResponseMessage();
				}
				if(signedHsmFile!=null){
					responseModel=fileUploadService.uploadFile(signedHsmFile,manageCertificatesDetails.getOperationUsername(),manageCertificatesDetails.getOperationPassword(),"StoreHSMOwnerCerts",manageCertificatesDetails.getApplianceIp(),null);
					signedHsmFileUploadedId=responseModel.getResponseMessage();
				}
			}
			if(hsmFileUploadedId!=null && signedHsmFileUploadedId!=null){
				if(username!=null && password!=null)
				{
					JSONObject json = new JSONObject(); 	
					json.put("username",username);
					json.put("password",password);
					if(dualFactorHostname!=null && dualFactorPort!=null && dualFactorCertificate!=null){
						json.put("dualFactorHostname",dualFactorHostname);
						json.put("dualFactorPort",dualFactorPort);
						json.put("dualFactorCertificate",dualFactorCertificate);
					}
					json.put("hsmOwnerCertFileId",hsmFileUploadedId);
					json.put("hsmOwnerSignedCertFileId",signedHsmFileUploadedId);
					ResponseEntity<String> response=restClient.invokePOSTMethodForOperations("https://"+manageCertificatesDetails.getApplianceIp()+"/liquidsa/import_hsm_owner_certificates", json);
					if(response!=null && response.getStatusCode().name().equals("OK")) {	
						responseModel.setResponseCode("200");
						responseModel.setResponseMessage("Certificates uploaded succeessfully.");
					}
					else{
						responseModel.setResponseCode("409");
						responseModel.setResponseMessage("error coming while import certificates."); 
					}
				}
				else{
					responseModel.setResponseCode("409");
					responseModel.setResponseMessage("Credentials are required."); 
				}
			}
			else{
				responseModel.setResponseCode("409");
				responseModel.setResponseMessage("Either HSM FileUploadId or SignedHSM FileUploadId is missing"); 
			}
		}catch (Exception e) {
			logger.error("Error occured in  uploadCertificate Method :: "+e.getMessage());
		}
		return responseModel;
	}

	public File	downloadFileFromURL(String fileUrl,String applianceName){
		logger.info("Start of downloadFileFromURL Method ::");
		File file=null;
		String fileName=null;
		InputStream inputStream=null;
		  OutputStream   outputStream=null;
		try{
			HttpResponse response=restClient.invokeGETMethodForLargeFileDownload(fileUrl);
			if(response!=null) {
				String finalfileName=null;
				String contentDisposition=response.getFirstHeader("Content-Disposition").getValue();
				String fileNameSplit[]=contentDisposition.split("=");
				if(fileNameSplit.length>0){
				  	fileName=fileNameSplit[1];
				
				}
				 finalfileName = applianceName+"-"+CaviumUtil.getRandomText()+"-"+fileName;
				  file = CaviumUtil.createFile(finalfileName,null,"");
				 
				  HttpEntity entity=response.getEntity();
					  if (entity != null) {
					   inputStream = entity.getContent();
			            outputStream = new FileOutputStream(file);
			            IOUtils.copy(inputStream, outputStream);
						 }
			 	
			}		 
		}catch (Exception e) {
			try{
				Files.deleteIfExists(Paths.get(file.getAbsolutePath()));
				file=null;
			}catch (Exception exp) {
				logger.error("Error in writting content to file  in downloadFileFromURL method of Appliance ServiceImpl Class :: " + e.getMessage()); 
			}
		}finally{
			try{
			if(inputStream!=null)
			{
				inputStream.close();	
			}
			if(outputStream!=null)
			{
				outputStream.flush();
				outputStream.close();
			}
			}catch (Exception e) {
				logger.error("Error occured in  downloadFileFromURL Method for closing InputStream and OutputStream :: "+e.getMessage());
			}
		}
		logger.info("end of downloadFileFromURL Method ::");
		return file;
	}

	private void updateInProgressActivity(ApplianceDetailModel applianceDetailModel,String loggedInUser, JsonNode root) {
		try {
			InProgressActivity activity = new InProgressActivity();
			activity.setCreatedBy(loggedInUser);
			activity.setModuleName(CaviumConstant.APPLIANCE_MANAGEMENT);
			activity.setIpAddress(applianceDetailModel.getIpAddress());
			Integer jobId = 0;
			if (!root.path("jobId").isNull()) {
				jobId = root.path("jobId").asInt();
			} else {
				jobId = 000;
			}
			activity.setJobId(jobId);
			activity.setOperationName(root.path("operation").asText());
			activity.setStatus("In-Progress");
			activity.setApplianceID(applianceDetailModel.getApplianceId());
			if(applianceDetailModel.getFirmwareUpgradeDetailModel()!=null && applianceDetailModel.getFirmwareUpgradeDetailModel().isZeroize()) {
				activity.setPartitionDeleted(true);
			}
			activity.setApplianceName(applianceDetailModel.getApplianceName());
			inProgressActivityService.createInProgressActivity(activity);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during updateInProgressActivity"+e.getMessage());
		}
	}


	private ApplianceDetailModel getErrorMessage(ResponseEntity<String> response,ApplianceDetailModel applianceDetailModel,String loggedInUser,String type) {
		try {
			if(response==null) {
				applianceDetailModel.setCode("409");
				applianceDetailModel.setErrorMessage(env.getProperty("appliance.applainceinternalerror.cavium"));
				applianceDetailModel.setLastOperationPerformed(type);
				applianceDetailModel.setLastOperationStatus("Failed");
				alertsService.createAlert(loggedInUser,"Device "+applianceDetailModel.getApplianceName()+"  try to perofrm "+type+" by "+loggedInUser+" does not "+type+" due to appliance internal error",applianceDetailModel.getApplianceName(),applianceDetailModel.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
				return applianceDetailModel;
			}

			if(response!=null && response.getStatusCodeValue()== 408){
				applianceDetailModel.setCode("408");
				applianceDetailModel.setErrorMessage(env.getProperty("appliance.connectionerror.cavium"));
				applianceDetailModel.setLastOperationPerformed(type);
				applianceDetailModel.setLastOperationStatus("Failed");
				alertsService.createAlert(loggedInUser,"Device "+applianceDetailModel.getApplianceName()+"  try to perofrm "+type+" by "+loggedInUser+" does not "+type+" due to connection issue.",applianceDetailModel.getApplianceName(),applianceDetailModel.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
				return applianceDetailModel;
			}

			if(response.getBody()!=null) {
				ObjectMapper mapper = new ObjectMapper();
				JsonNode root = mapper.readTree(response.getBody());
				if(root!=null){
					if(!root.isNull()) {
						if(response.getBody().contains("busy")) {
							String operation = root.path("operation").asText();
							applianceDetailModel.setCode("409");
							applianceDetailModel.setLastOperationPerformed(operation);
							applianceDetailModel.setErrorMessage("System is busy due to operation "+operation+" is being performed on appliance "+applianceDetailModel.getApplianceName()+"");
							applianceDetailModel.setLastOperationStatus("Failed");
							alertsService.createAlert(loggedInUser,"Device "+applianceDetailModel.getApplianceName()+"  try to perofrm "+type+" by "+loggedInUser+" does not "+type+"  due to operation "+operation+" is already in progress.",applianceDetailModel.getApplianceName(),applianceDetailModel.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
							return applianceDetailModel;
						}
						if(response.getBody().contains("errors")) {
							JsonNode errors = root.path("errors");
							if(!errors.isNull() && errors.size() > 0){
								logger.info("Error size"+errors.size()+" is Array"+errors.isArray());
								StringBuilder sbmessage=new StringBuilder();
								StringBuilder sbcode=new StringBuilder();
								Iterator<JsonNode> itr = errors.elements();	
								while (itr.hasNext()) {
									JsonNode temp = itr.next();
									sbcode.append(""+temp.asInt()+"");
									if(env.containsProperty(""+temp.asInt()+"")) {
										sbmessage.append(env.getProperty(""+temp.asInt()+""));
									}else {
										sbmessage.append("Error message not available");
									}
									sbcode.append(",");
									sbmessage.append(",");
								}
								String message=sbmessage.toString();
								message=message.substring(0, message.length()-1);
								message=message+".";
								String code=sbcode.toString();
								code=code.substring(0, code.length()-1);
								code=code+".";
								applianceDetailModel.setCode(code);
								applianceDetailModel.setErrorMessage(message);
								applianceDetailModel.setLastOperationPerformed(type);
								applianceDetailModel.setLastOperationStatus("Failed");
								applianceDetailModel.setMessage("");
								alertsService.createAlert(loggedInUser,""+type+" failed due to "+message+" on Device "+applianceDetailModel.getApplianceName()+"  by "+loggedInUser+".",applianceDetailModel.getApplianceName(),applianceDetailModel.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
							} else {
								String encodeMessage = "";
								if (errors.size() == 0) {
									encodeMessage = root.path("message").asText();
									encodeMessage = CaviumUtil.decodeMessageBase64(encodeMessage);
									applianceDetailModel.setCode("");
									applianceDetailModel.setErrorMessage(encodeMessage);
									applianceDetailModel.setMessage("");
								}else {
									applianceDetailModel.setCode("");
									applianceDetailModel.setErrorMessage("No message found");
									applianceDetailModel.setMessage("");
								}
							}
						}
					}
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured while setting error code and message..");
		}
		return applianceDetailModel;
	}

	public   CaviumResponseModel  getDownloadlogsURL(LogsDetails logsDetail){
		JSONObject json = new JSONObject(); 
		String loggedInUser = userAttributes.getlogInUserName();
		CaviumResponseModel responseModel=getCaviumResponseModel();
		try{
			InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry
					.getInitializeIdByApplianceId(logsDetail.getApplianceId());
			if (initmodel != null) {
				InitializeApplianceDetailModel initAppDetailModel = initializeRepository
						.findOne(initmodel.getInitializeId());
				DualFactorAuthDetailModel dualAuthModel = initAppDetailModel.getDualFactorAuthDetailModel();
				if (!StringUtils.isEmpty(logsDetail.getOperationUsername())
						&& !StringUtils.isEmpty(logsDetail.getOperationPassword())) {
					if (initAppDetailModel.getAuthenticationLevel() == 0) {
						json.put("username", logsDetail.getOperationUsername());
						json.put("password", logsDetail.getOperationPassword());
					}
					if (initAppDetailModel.getAuthenticationLevel() == 1 && dualAuthModel != null) {
						json.put("username", logsDetail.getOperationUsername());
						json.put("password", logsDetail.getOperationPassword());
						json.put("dualFactorHostname", dualAuthModel.getDualFactorAuthServerAddress());
						json.put("dualFactorPort", dualAuthModel.getDualFactorAuthServerPortNo());
						json.put("dualFactorCertificate", dualAuthModel.getDualFactorAuthServerCertId());
					}
				} else {
					if (initAppDetailModel.getAuthenticationLevel() == 0) {
						json.put("username", initAppDetailModel.getCryptoOfficerName());
						json.put("password", CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));
					}
					if (initAppDetailModel.getAuthenticationLevel() == 1 && dualAuthModel != null) {
						json.put("username", initAppDetailModel.getCryptoOfficerName());
						json.put("password", CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));
						json.put("dualFactorHostname", dualAuthModel.getDualFactorAuthServerAddress());
						json.put("dualFactorPort", dualAuthModel.getDualFactorAuthServerPortNo());
						json.put("dualFactorCertificate", dualAuthModel.getDualFactorAuthServerCertId());
					}
				}
			} else {
				if (!StringUtils.isEmpty(logsDetail.getOperationUsername())
						&& !StringUtils.isEmpty(logsDetail.getOperationPassword())) {
					json.put("username", logsDetail.getOperationUsername());
					json.put("password", logsDetail.getOperationPassword());

				} else {
					responseModel.setResponseCode("409");
					responseModel.setResponseMessage("Credentials not provided");
					alertsService.createAlert(loggedInUser,"Credentails not provided by " +loggedInUser +" while trying to download logs ",logsDetail.getApplianceName(),logsDetail.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
					return responseModel;

				}
			}
			Map<String,Object> logs= new HashMap<String,Object>();
			Map<String,Object> admin= new HashMap<String,Object>();
			Map<String,Object> partitions= new HashMap<String,Object>();
			Map<String,Object> host= new HashMap<String,Object>();

			if(logsDetail!=null && logsDetail.getLogs()!=null){
				if(logsDetail.getLogs().getPartitions()!=null){
					if(logsDetail.getLogs().getPartitions().getOptions()!=null && logsDetail.getLogs().getPartitions().getOptions().size()>0){
						partitions.put("options", logsDetail.getLogs().getPartitions().getOptions());
					}
					if(logsDetail.getLogs().getPartitions().getPartitionsNames()!=null && logsDetail.getLogs().getPartitions().getPartitionsNames().size()>0){
						partitions.put("list", logsDetail.getLogs().getPartitions().getPartitionsNames());
						logs.put("partitions",partitions);
					}
				}
				if(logsDetail.getLogs().getHost()!=null && logsDetail.getLogs().getHost().getOptions()!=null && logsDetail.getLogs().getHost().getOptions().size()>0){	
					host.put("options", logsDetail.getLogs().getHost().getOptions());
					logs.put("host", host);
				}
				if(logsDetail.getLogs().getAdmin()!=null && logsDetail.getLogs().getAdmin().getOptions()!=null && logsDetail.getLogs().getAdmin().getOptions().size()>0){
					admin.put("options",logsDetail.getLogs().getAdmin().getOptions());
					logs.put("admin", admin);
				}
				json.put("logs", logs);
			}
			ResponseEntity<String> response=restClient.invokePOSTMethodForOperations("https://"+logsDetail.getApplianceIp()+"/liquidsa/admin_vm_logs", json);
			if(response!=null && response.getStatusCode().name().equals("OK")) {
				String logUrl=null;	 
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						String status = root.path("status").asText();

						if("success".equalsIgnoreCase(status)){
							JsonNode dataNode = root.path("data");
							if(!dataNode.isNull() && dataNode.size()>0){
								if(dataNode.has("liquidSecurityLogsUrlAddr")) {
									logUrl = dataNode.path("liquidSecurityLogsUrlAddr").asText();
									responseModel.setResponseCode("200");
									responseModel.setResponseMessage(logUrl);
								}	 
							}
							recentActivityServiceImpl.createRecentActivity(loggedInUser,"Logs sucessfully download by " +loggedInUser,CaviumConstant.APPLIANCE_MANAGEMENT);
						}
						if("error".equalsIgnoreCase(status)){
							StringBuilder sbmessage=new StringBuilder();
							StringBuilder sbcode=new StringBuilder();
							JsonNode errors = root.path("errors");
							if(!errors.isNull() && errors.size()>0){
								Iterator<JsonNode> itr = errors.elements();                           
								while (itr.hasNext()) {
									JsonNode temp = itr.next();
									sbcode.append(""+temp.asInt()+"");
									if(env.containsProperty(""+temp.asInt()+"")) {
										sbmessage.append(env.getProperty(""+temp.asInt()+""));
									}else {
										sbmessage.append("Error message not available");
									}
									sbcode.append(",");
									sbmessage.append(",");
								}
								String message=sbmessage.toString();
								message=message.substring(0, message.length()-1);
								message=message+".";
								String code=sbcode.toString();
								code=code.substring(0, code.length()-1);
								code=code+".";
								responseModel.setResponseMessage(message);	  
								responseModel.setResponseCode("409");	  

							}
							alertsService.createAlert(loggedInUser,"Credentails not provided by " +loggedInUser +" while trying to download logs ",logsDetail.getApplianceName(),logsDetail.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
						}
					}
				}
			}
		}catch (Exception e) {
			logger.error("Error occured while download Appliance logs in getDownloadlogsURL method of ApplianceServiceImpl ::  "+e.getMessage());
		}
		return responseModel;  
	}

	public CaviumResponseModel deleteAppliancelogs(LogsDetails logsDetail){

		JSONObject json = new JSONObject(); 
		String loggedInUser = userAttributes.getlogInUserName();
		CaviumResponseModel responseModel=getCaviumResponseModel();
		try{
			InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry
					.getInitializeIdByApplianceId(logsDetail.getApplianceId());
			if (initmodel != null) {
				InitializeApplianceDetailModel initAppDetailModel = initializeRepository
						.findOne(initmodel.getInitializeId());
				DualFactorAuthDetailModel dualAuthModel = initAppDetailModel.getDualFactorAuthDetailModel();
				if (!StringUtils.isEmpty(logsDetail.getOperationUsername())
						&& !StringUtils.isEmpty(logsDetail.getOperationPassword())) {
					if (initAppDetailModel.getAuthenticationLevel() == 0) {
						json.put("username", logsDetail.getOperationUsername());
						json.put("password", logsDetail.getOperationPassword());
					}
					if (initAppDetailModel.getAuthenticationLevel() == 1 && dualAuthModel != null) {
						json.put("username", logsDetail.getOperationUsername());
						json.put("password", logsDetail.getOperationPassword());
						json.put("dualFactorHostname", dualAuthModel.getDualFactorAuthServerAddress());
						json.put("dualFactorPort", dualAuthModel.getDualFactorAuthServerPortNo());
						json.put("dualFactorCertificate", dualAuthModel.getDualFactorAuthServerCertId());
					}
				} else {
					if (initAppDetailModel.getAuthenticationLevel() == 0) {
						json.put("username", initAppDetailModel.getCryptoOfficerName());
						json.put("password", CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));
					}
					if (initAppDetailModel.getAuthenticationLevel() == 1 && dualAuthModel != null) {
						json.put("username", initAppDetailModel.getCryptoOfficerName());
						json.put("password", CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));
						json.put("dualFactorHostname", dualAuthModel.getDualFactorAuthServerAddress());
						json.put("dualFactorPort", dualAuthModel.getDualFactorAuthServerPortNo());
						json.put("dualFactorCertificate", dualAuthModel.getDualFactorAuthServerCertId());
					}
				}
			} else {
				if (!StringUtils.isEmpty(logsDetail.getOperationUsername())
						&& !StringUtils.isEmpty(logsDetail.getOperationPassword())) {
					json.put("username", logsDetail.getOperationUsername());
					json.put("password", logsDetail.getOperationPassword());

				} else {
					responseModel.setResponseCode("409");
					responseModel.setResponseMessage("Credentials not provided");
					return responseModel;

				}
			}
			Map<String,Object> logs= new HashMap<String,Object>();
			Map<String,Object> admin= new HashMap<String,Object>();
			Map<String,Object> partitions= new HashMap<String,Object>();
			Map<String,Object> host= new HashMap<String,Object>();

			if(logsDetail!=null && logsDetail.getLogs()!=null){
				if(logsDetail.getLogs().getPartitions()!=null){
					if(logsDetail.getLogs().getPartitions().getOptions()!=null && logsDetail.getLogs().getPartitions().getOptions().size()>0){
						partitions.put("options", logsDetail.getLogs().getPartitions().getOptions());
					}
					if(logsDetail.getLogs().getPartitions().getPartitionsNames()!=null && logsDetail.getLogs().getPartitions().getPartitionsNames().size()>0){
						partitions.put("list", logsDetail.getLogs().getPartitions().getPartitionsNames());
						logs.put("partitions",partitions);
					}
				}
				if(logsDetail.getLogs().getHost()!=null && logsDetail.getLogs().getHost().getOptions()!=null && logsDetail.getLogs().getHost().getOptions().size()>0){	
					host.put("options", logsDetail.getLogs().getHost().getOptions());
					logs.put("host", host);
				}
				if(logsDetail.getLogs().getAdmin()!=null && logsDetail.getLogs().getAdmin().getOptions()!=null && logsDetail.getLogs().getAdmin().getOptions().size()>0){
					admin.put("options",logsDetail.getLogs().getAdmin().getOptions());
					logs.put("admin", admin);
				}
				json.put("logs", logs);
			}
			ResponseEntity<String> response=restClient.invokePOSTMethodForOperations("https://"+logsDetail.getApplianceIp()+"/liquidsa/delete_admin_vm_logs", json);
			if(response!=null && response.getStatusCode().name().equals("OK")) { 	 
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						String status = root.path("status").asText();

						if("success".equalsIgnoreCase(status)){
							responseModel.setResponseCode("200");
							responseModel.setResponseMessage("Logs Deleted Suceesfully");	
							recentActivityServiceImpl.createRecentActivity(loggedInUser,"Logs sucessfully deleted by " +loggedInUser,CaviumConstant.APPLIANCE_MANAGEMENT);
						}
						if("error".equalsIgnoreCase(status)){
							StringBuilder sbmessage=new StringBuilder();
							StringBuilder sbcode=new StringBuilder();
							JsonNode errors = root.path("errors");
							if(!errors.isNull() && errors.size()>0){
								Iterator<JsonNode> itr = errors.elements();                           
								while (itr.hasNext()) {
									JsonNode temp = itr.next();
									sbcode.append(""+temp.asInt()+"");
									if(env.containsProperty(""+temp.asInt()+"")) {
										sbmessage.append(env.getProperty(""+temp.asInt()+""));
									}else {
										sbmessage.append("Error message not available");
									}
									sbcode.append(",");
									sbmessage.append(",");
								}
								String message=sbmessage.toString();
								message=message.substring(0, message.length()-1);
								message=message+".";
								String code=sbcode.toString();
								code=code.substring(0, code.length()-1);
								code=code+".";
								responseModel.setResponseMessage(message);	  
								responseModel.setResponseCode("409");	  
							}
							alertsService.createAlert(loggedInUser,"Logs not deleted while trying to delete logs by "+ loggedInUser,logsDetail.getApplianceName(),logsDetail.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
						}
					}
				}
			}
		}catch (Exception e) {
			logger.error("Error occured while delete Appliancelogs in deleteAppliancelogs method of ApplianceServiceImpl");
		}
		return responseModel;  

	}

	public CaviumResponseModel getAlreadyConfiguredLoggerType(LogsDetails logsDetail){


		CaviumResponseModel responseModel=getCaviumResponseModel();
		try{
			ResponseEntity<String> response=restClient.invokeGETMethod("https://"+logsDetail.getApplianceIp()+"/liquidsa/config_logger");
			if(response!=null && response.getStatusCode().name().equals("OK")) { 	 
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						String status = root.path("status").asText();

						if("success".equalsIgnoreCase(status)){
							JsonNode dataNode = root.path("data");
							if(!dataNode.isNull()){
								if(dataNode.has("logger")){
									JsonNode loggerNode = dataNode.path("logger");
									if(!loggerNode.isNull()){
										String  loggerType=loggerNode.path("middleware").asText();
										responseModel.setResponseMessage(loggerType);	  
										responseModel.setResponseCode("200");
									}
								}
							}

						}
						if("error".equalsIgnoreCase(status)){
							StringBuilder sbmessage=new StringBuilder();
							StringBuilder sbcode=new StringBuilder();
							JsonNode errors = root.path("errors");
							if(!errors.isNull() && errors.size()>0){
								Iterator<JsonNode> itr = errors.elements();                           
								while (itr.hasNext()) {
									JsonNode temp = itr.next();
									sbcode.append(""+temp.asInt()+"");
									if(env.containsProperty(""+temp.asInt()+"")) {
										sbmessage.append(env.getProperty(""+temp.asInt()+""));
									}else {
										sbmessage.append("Error message not available");
									}
									sbcode.append(",");
									sbmessage.append(",");
								}
								String message=sbmessage.toString();
								message=message.substring(0, message.length()-1);
								message=message+".";
								String code=sbcode.toString();
								code=code.substring(0, code.length()-1);
								code=code+".";
								responseModel.setResponseMessage(message);	  
								responseModel.setResponseCode("409");	  
							}
						}
					}
				}
			}
		}catch (Exception e) {
			logger.error("Error occured in getAlreadyConfiguredLoggerType method of ApplianceServiceImpl class.." +e.getMessage());
		}
		return responseModel;  

	}

	public CaviumResponseModel updateConfigureLoggerType(LogsDetails logsDetail){
		logger.info("start of updateConfigureLoggerType method");
		JSONObject json = new JSONObject(); 
		String loggedInUser = userAttributes.getlogInUserName();
		CaviumResponseModel responseModel=getCaviumResponseModel();
		try{
			InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry
					.getInitializeIdByApplianceId(logsDetail.getApplianceId());
			if (initmodel != null) {
				InitializeApplianceDetailModel initAppDetailModel = initializeRepository
						.findOne(initmodel.getInitializeId());
				DualFactorAuthDetailModel dualAuthModel = initAppDetailModel.getDualFactorAuthDetailModel();
				if (!StringUtils.isEmpty(logsDetail.getOperationUsername())
						&& !StringUtils.isEmpty(logsDetail.getOperationPassword())) {
					if (initAppDetailModel.getAuthenticationLevel() == 0) {
						json.put("username", logsDetail.getOperationUsername());
						json.put("password", logsDetail.getOperationPassword());
					}
					if (initAppDetailModel.getAuthenticationLevel() == 1 && dualAuthModel != null) {
						json.put("username", logsDetail.getOperationUsername());
						json.put("password", logsDetail.getOperationPassword());
						json.put("dualFactorHostname", dualAuthModel.getDualFactorAuthServerAddress());
						json.put("dualFactorPort", dualAuthModel.getDualFactorAuthServerPortNo());
						json.put("dualFactorCertificate", dualAuthModel.getDualFactorAuthServerCertId());
					}
				} else {
					if (initAppDetailModel.getAuthenticationLevel() == 0) {
						json.put("username", initAppDetailModel.getCryptoOfficerName());
						json.put("password",  CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));
					}
					if (initAppDetailModel.getAuthenticationLevel() == 1 && dualAuthModel != null) {
						json.put("username", initAppDetailModel.getCryptoOfficerName());
						json.put("password", CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));
						json.put("dualFactorHostname", dualAuthModel.getDualFactorAuthServerAddress());
						json.put("dualFactorPort", dualAuthModel.getDualFactorAuthServerPortNo());
						json.put("dualFactorCertificate", dualAuthModel.getDualFactorAuthServerCertId());
					}
				}
			} else {
				if (!StringUtils.isEmpty(logsDetail.getOperationUsername())
						&& !StringUtils.isEmpty(logsDetail.getOperationPassword())) {
					json.put("username", logsDetail.getOperationUsername());
					json.put("password", logsDetail.getOperationPassword());

				} else {
					responseModel.setResponseCode("409");
					responseModel.setResponseMessage("Credentials not provided");
					return responseModel;
				}

			}
			Map<String,Object> logger= new HashMap<String,Object>();
			if(logsDetail.getLoggerType()!=null){
				logger.put("middleware", logsDetail.getLoggerType());
				json.put("logger", logger);
				ResponseEntity<String> response=restClient.invokePOSTMethodForOperations("https://"+logsDetail.getApplianceIp()+"/liquidsa/config_logger", json);
				if(response!=null && response.getStatusCode().name().equals("OK")) { 	 
					ObjectMapper mapper = new ObjectMapper();
					if(response.getBody()!=null){
						JsonNode root = mapper.readTree(response.getBody());
						if(!root.isNull()){
							String status = root.path("status").asText();

							if("success".equalsIgnoreCase(status)){
								responseModel.setResponseCode("200");
								responseModel.setResponseMessage("Logger type updated Suceesfully");	
								recentActivityServiceImpl.createRecentActivity(loggedInUser,"Logger type updated sucessfully by " +loggedInUser,CaviumConstant.APPLIANCE_MANAGEMENT);
							}
							if("error".equalsIgnoreCase(status)){
								StringBuilder sbmessage=new StringBuilder();
								StringBuilder sbcode=new StringBuilder();
								JsonNode errors = root.path("errors");
								if(!errors.isNull() && errors.size()>0){
									Iterator<JsonNode> itr = errors.elements();                           
									while (itr.hasNext()) {
										JsonNode temp = itr.next();
										sbcode.append(""+temp.asInt()+"");
										if(env.containsProperty(""+temp.asInt()+"")) {
											sbmessage.append(env.getProperty(""+temp.asInt()+""));
										}else {
											sbmessage.append("Error message not available");
										}
										sbcode.append(",");
										sbmessage.append(",");
									}
									String message=sbmessage.toString();
									message=message.substring(0, message.length()-1);
									message=message+".";
									String code=sbcode.toString();
									code=code.substring(0, code.length()-1);
									code=code+".";
									responseModel.setResponseMessage(message);	  
									responseModel.setResponseCode("409");	  
								}
								alertsService.createAlert(loggedInUser,"Logger type is not updataed while trying to update by "+ loggedInUser,logsDetail.getApplianceName(),logsDetail.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
							}
						}
					}
				}
			}else{
				responseModel.setResponseCode("409");
				responseModel.setResponseMessage("logger Type is not  provided");
			}
		}catch (Exception e) {
			logger.error("Error occured in updateConfigureLoggerType method of ApplianceServiceImpl class :: "+e.getMessage());
		}
		logger.info("end of updateConfigureLoggerType method");
		return responseModel;  

	}
	public List<PartitionDetailModel> setPartitionDataInPartitonModel(ApplianceDetailModel app){

		List<PartitionDetailModel> listPartitions = null;
		listPartitions=partitionRepository.getListOfPartitionByApplianceID(app.getApplianceId());
		if(listPartitions!=null && listPartitions.size()>0){
			listPartitions=partitionService.setPartitionDataIntoPartitionModel(listPartitions);
		}
		return listPartitions;

	}


	@Override
	public List<ApplianceDetailModel> validateCredentialsByLoginHSM(List<ApplianceDetailModel> listApplianceDetailModels) {
		// TODO Auto-generated method stub
		ResponseEntity<String> response=null;
		String loggedInUser = userAttributes.getlogInUserName();
		try {
			for(ApplianceDetailModel app: listApplianceDetailModels) {
				if(app!=null && !StringUtils.isEmpty(app.getIpAddress())) {
					String url="https://"+app.getIpAddress()+"/liquidsa/login";
					JSONObject body=new JSONObject();
					body.put("username", app.getOperationUsername());
					body.put("password", app.getOperationPassword());
					response=restClient.invokePOSTMethodForOperations(url, body);
					if(response != null && response.getBody() != null
							&& response.getBody().contains("success")) {
						app.setMessage("success");
						app.setCode("200");
					}else {
						app=getErrorMessage(response, app, loggedInUser, "loginHSM");
						if(app!=null && app.getErrorMessage()!=null && (app.getErrorMessage().contains("connection") || app.getErrorMessage().contains("busy") )) {
							//do nothing
						}else {
							app.setErrorMessage("Incorrect Username or Password. Try Again");
						}
					 }
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during validateCredentialsByLoginHSM"+e.getMessage());
		}
		return listApplianceDetailModels;
	}

	private void deletePartitionData(PartitionDetailModel partitionDetailModel) {
		try {
			if(partitionDetailModel!=null && partitionDetailModel.getPartitionId()!=0) {
				partitionETHRepository.deletePartitionETH(partitionDetailModel.getPartitionId());
				advanceStaticHostIpsRepository.deletePartitionAdvanceStaticHostIps(partitionDetailModel.getPartitionId());
				advanceDNSServersRepository.deletePartitionAdvanceDNSServers(partitionDetailModel.getPartitionId());
				advanceSearchDomainNamesRepository.deletePartitionAdvanceSearchDomainNames(partitionDetailModel.getPartitionId());
				partitionDataRepository.deletePartitionData(partitionDetailModel.getPartitionId());
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error ocuured during delete partition data");
		}finally {
			partitionDetailModel.setApplianceDetailModel(null);
			partitionRepository.delete(partitionDetailModel);
		}
	}


	@Override
	public List<ApplianceDetailModel> getMonitorData(List<ApplianceDetailModel> applianceDetailModellist) {
		// TODO Auto-generated method stub
		String loggedInUser = userAttributes.getlogInUserName();
		List<ApplianceDetailModel> responseList=new ArrayList<ApplianceDetailModel>();
		try {
			if (applianceDetailModellist.size() > 0) {
				for (ApplianceDetailModel app: applianceDetailModellist) {
					ResponseEntity<String> response = null;
					ApplianceDetailModel dbAppliance = applianceRepository.findOne(app.getApplianceId());
					if (dbAppliance != null) {
						response = restClient.invokeGETMethod("https://"+app.getIpAddress()+"/liquidsa/monitor/"+app.getMonitorType()+"");
						if(response!=null && response.getBody()!=null && response.getBody().contains("success")) {
							ObjectMapper mapper = new ObjectMapper();
							JsonNode root = mapper.readTree(response.getBody());
							if(root.has("data")) {
								JsonNode dataNode = root.path("data");
								if(dataNode.size() > 0) {
									String data=dataNode.toString().replaceAll("sample-count", "samplecount");
									data=data.replaceAll("interface-name", "interfacename");
									MonitorData mdata=mapper.readValue(data, MonitorData.class);
									app.setMonitorData(mdata);
								}else {
									 PartitionMonitorPMNCData cpu=new PartitionMonitorPMNCData();
									 PartitionMonitorCWI info=new PartitionMonitorCWI();
									 cpu.setInfo(info);
									 cpu.setWarn(info);
									 cpu.setCrit(info);
									 PartitionMonitorPMNCData pcpu=new PartitionMonitorPMNCData();
									 cpu.setInfo(info);
									 cpu.setWarn(info);
									 cpu.setCrit(info);
									 PartitionMonitorPMNCData memory=new PartitionMonitorPMNCData();
									 cpu.setInfo(info);
									 cpu.setWarn(info);
									 cpu.setCrit(info);
									 PartitionNetworkMonitorStats network=new PartitionNetworkMonitorStats();
									 network.setInterfacename("eth0");
									 MonitorData mdata=new MonitorData();
									 mdata.setCpu(cpu);
									 mdata.setMemory(memory);
									 mdata.setNetwork(network);
									 mdata.setPcpu(pcpu);
									 app.setMonitorData(mdata);
								}
							}else {
								app.setMessage("No data to display");
								app.setCode("200");
							}
						}else {
							app=getErrorMessage(response, app,loggedInUser,app.getMonitorType());
						}
						responseList.add(app);
					} else {
						app.setCode("409");
						app.setMessage(env.getProperty("appliance.notexists.cavium"));
						responseList.add(app);
					}
				}
			}
		}catch (Exception e) {
			// TODO: handle exception
			logger.info("Error occured during appliance getMonitorData.. into getMonitorData of class ApplianceServiceIMPL");
		}
		return responseList;
	}

	/**
	 * This method is used to setMonitorData
	 */
	@Override
	public List<ApplianceDetailModel> setMonitorData(List<ApplianceDetailModel> applianceDetailModellist) {
		// TODO Auto-generated method stub
		String loggedInUser = userAttributes.getlogInUserName();
		List<ApplianceDetailModel> responseList=new ArrayList<ApplianceDetailModel>();
		try {
			if (applianceDetailModellist.size() > 0) {
				for (ApplianceDetailModel app: applianceDetailModellist) {
					ResponseEntity<String> response = null;
					ApplianceDetailModel dbAppliance = applianceRepository.findOne(app.getApplianceId());
					JSONObject jsonRequest=new JSONObject();
					if (dbAppliance != null) {
						JSONObject josnObject=null;
						if(app.getMonitorData()!=null) {
							josnObject=new JSONObject(app.getMonitorData());
							String jsonObj=josnObject.toString();
							jsonObj=jsonObj.toString().replaceAll( "samplecount","sample-count");
							jsonObj=jsonObj.replaceAll("interfacename","interface-name");
							josnObject=new JSONObject(jsonObj);
							jsonRequest.put("config", josnObject);

						}
						long applianceId = app.getApplianceId();
						InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(applianceId);
						if (initmodel != null) {
							InitializeApplianceDetailModel initAppDetailModel = initializeRepository.findOne(initmodel.getInitializeId());
							DualFactorAuthDetailModel dualAuthModel = initAppDetailModel.getDualFactorAuthDetailModel();
							if (!StringUtils.isEmpty(app.getOperationUsername())
									&& !StringUtils.isEmpty(app.getOperationPassword())) {
								if (initAppDetailModel.getAuthenticationLevel() == 0) {
									jsonRequest.put("username", app.getOperationUsername());
									jsonRequest.put("password", app.getOperationPassword());
								}
								if (initAppDetailModel.getAuthenticationLevel() == 1 && dualAuthModel != null) {
									jsonRequest.put("username", app.getOperationUsername());
									jsonRequest.put("password", app.getOperationPassword());
									jsonRequest.put("dualFactorHostname", dualAuthModel.getDualFactorAuthServerAddress());
									jsonRequest.put("dualFactorPort", dualAuthModel.getDualFactorAuthServerPortNo());
									jsonRequest.put("dualFactorCertificate", dualAuthModel.getDualFactorAuthServerCertId());
								}
							} else {
								if (initAppDetailModel.getAuthenticationLevel() == 0) {
									jsonRequest.put("username", initAppDetailModel.getCryptoOfficerName());
									jsonRequest.put("password",  CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));
								}
								if (initAppDetailModel.getAuthenticationLevel() == 1 && dualAuthModel != null) {
									jsonRequest.put("username", initAppDetailModel.getCryptoOfficerName());
									jsonRequest.put("password",  CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));
									jsonRequest.put("dualFactorHostname", dualAuthModel.getDualFactorAuthServerAddress());
									jsonRequest.put("dualFactorPort", dualAuthModel.getDualFactorAuthServerPortNo());
									jsonRequest.put("dualFactorCertificate", dualAuthModel.getDualFactorAuthServerCertId());
								}
							}
							response = restClient.invokePOSTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/monitor/"+app.getMonitorType()+"",jsonRequest);
						} else {
							if (!StringUtils.isEmpty(app.getOperationUsername())
									&& !StringUtils.isEmpty(app.getOperationPassword())) {
								jsonRequest.put("username", app.getOperationUsername());
								jsonRequest.put("password", app.getOperationPassword());
								response = restClient.invokePOSTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/monitor/"+app.getMonitorType()+"",jsonRequest);
							} else {
								app.setMessage("Appliance can not set monitor data due to credentials not available");
								alertsService.createAlert(loggedInUser,
										"Device " + app.getApplianceName() + "  try to perofrm reboot by "
												+ loggedInUser + " does not set monitor data due to credentials not available.",app.getApplianceName(),app.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
							}
						}
						if (response != null && response.getBody() != null) {
							ObjectMapper mapper = new ObjectMapper();
							JsonNode root = mapper.readTree(response.getBody());
							if (response != null && response.getBody() != null
									&& response.getBody().contains("success")) {
								dbAppliance.setLastOperationPerformed("setMonitorData");
								dbAppliance.setLastOperationStatus("In-Progress");
								dbAppliance.setApplianceinitialized(app.isApplianceinitialized());
								dbAppliance.setCode("200");
								dbAppliance.setMessage("Monitor data configured successfully.");
								dbAppliance.setErrorMessage("");
								applianceRepository.save(dbAppliance);
								updateInProgressActivity(dbAppliance, loggedInUser, root);
							} else {
								dbAppliance = getErrorMessage(response, dbAppliance, loggedInUser, "setMonitorData");
								applianceRepository.save(dbAppliance);
							}
						} else {
							dbAppliance = getErrorMessage(response, dbAppliance, loggedInUser, "setMonitorData");
							applianceRepository.save(dbAppliance);
						}
						dbAppliance.setPartitionDetailModels(null);
						responseList.add(dbAppliance);
					} else {
						app.setCode("409");
						app.setMessage(env.getProperty("appliance.notexists.cavium"));
						responseList.add(app);
					}
				}
			}
		}catch (Exception e) {
			// TODO: handle exception
			logger.info("Error occured during appliance setMonitorData.. into setMonitorData of class ApplianceServiceIMPL");
		}
		return responseList;
	}


	@Override
	public List<ApplianceDetailModel> getApplianceMonitorStats(List<ApplianceDetailModel> listApplianceDetailModels) {
		// TODO Auto-generated method stub
		String loggedInUser = userAttributes.getlogInUserName();
		List<ApplianceDetailModel> responseList=new ArrayList<ApplianceDetailModel>();
		try {
			if (listApplianceDetailModels.size() > 0) {
				for (ApplianceDetailModel app: listApplianceDetailModels) {
					ResponseEntity<String> response = null;
					ApplianceDetailModel dbAppliance = applianceRepository.findOne(app.getApplianceId());
					if (dbAppliance != null) {
						response = restClient.invokeGETMethod("https://"+app.getIpAddress()+"/liquidsa/monitor_stats/"+app.getMonitorType()+"");
						if(response!=null && response.getBody()!=null && response.getBody().contains("success")) {
							ObjectMapper mapper = new ObjectMapper();
							JsonNode root = mapper.readTree(response.getBody());
							if(root.has("data")) {
								JsonNode dataNode = root.path("data");
								app.setMessage(dataNode.toString());
							}else {
								app.setMessage("No data to display");
								app.setCode("200");
							}
						}else {
							app=getErrorMessage(response, app,loggedInUser,app.getMonitorType());
						}
						responseList.add(app);
					} else {
						app.setCode("409");
						app.setMessage(env.getProperty("appliance.notexists.cavium"));
						responseList.add(app);
					}
				}
			}
		}catch (Exception e) {
			// TODO: handle exception
			logger.info("Error occured during appliance getApplianceMonitorStats.. into getApplianceMonitorStats of class ApplianceServiceIMPL");
		}
		return responseList;
	}

	/**
	 * This method is used to changeAppliancePassword by ChangeCOPswd api
	 */
	@Override
	public ApplianceDetailModel changeAppliancePassword(ApplianceDetailModel app) {
		// TODO Auto-generated method stub
		String loggedInUser = userAttributes.getlogInUserName();
		try {
			if (app!=null) {
				ResponseEntity<String> response = null;
				ApplianceDetailModel dbAppliance = applianceRepository.findOne(app.getApplianceId());
				JSONObject jsonRequest=new JSONObject();
				if (dbAppliance != null) {
					if(!StringUtils.isEmpty(app.getNewPassword())) {
						jsonRequest.put("newPassword", app.getNewPassword());
					}
					jsonRequest=getUserNamePassword(app, jsonRequest);
					response = restClient.invokePOSTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/change_password",jsonRequest);
					if (response != null && response.getBody() != null && response.getBody().contains("success")) {
						dbAppliance.setLastOperationPerformed("ChangeCOPswd");
						dbAppliance.setCode("200");
						dbAppliance.setMessage("Password changed successfully");
						dbAppliance.setErrorMessage("");
						dbAppliance.setLastOperationStatus("Completed");
						applianceRepository.save(dbAppliance);
						recentActivityServiceImpl.createRecentActivity(loggedInUser, "Password changed for "+app.getApplianceName()+" by "+loggedInUser,CaviumConstant.APPLIANCE_MANAGEMENT);
						InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(app.getApplianceId());
						if(initmodel!=null) {
							if(app.isCredentialSaved()) {
								initmodel.setOperationPerformPassword(app.getNewPassword());
								initializeAppliancesRelationshipReposiotry.save(initmodel);
							}else {
								initializeAppliancesRelationshipReposiotry.delete(initmodel);
							}
						}
					} else {
						dbAppliance = getErrorMessage(response, dbAppliance, loggedInUser, "ChangeCOPswd");
						applianceRepository.save(dbAppliance);
					}
					dbAppliance.setPartitionDetailModels(null);
					app=dbAppliance;
				} else {
					app.setCode("409");
					app.setMessage(env.getProperty("appliance.notexists.cavium"));
				}
			}
		}catch (Exception e) {
			// TODO: handle exception
			logger.info("Error occured during appliance ChangeCOPswd.. into changeAppliancePassword of class ApplianceServiceIMPL");
		}
		return app;
	}

	@Override
	public CaviumResponseModel downloadMonitorLogsURL(String url, ApplianceDetailModel applianceDetailModel) {

		String	errorMessage=null;
		CaviumResponseModel responseModel=getCaviumResponseModel();
		JSONObject jsonObject=new JSONObject();

		try{
			jsonObject=getUserNamePassword(applianceDetailModel, jsonObject);
			ResponseEntity<String> response=restClient.invokePOSTMethodForOperations(url,jsonObject);
			ObjectMapper mapper = new ObjectMapper();
			if(response.getBody()!=null){
				JsonNode root = mapper.readTree(response.getBody());
				if(!root.isNull()){
					String status = root.path("status").asText();
					if("success".equalsIgnoreCase(status)){
						JsonNode dataNode = root.path("data");
						if(!dataNode.isNull() && dataNode.size()>0){
							if(dataNode.has("liquidSecurityMonitorLogsUrlAddr")) {
								String certificateUrl = dataNode.path("liquidSecurityMonitorLogsUrlAddr").asText();
								responseModel.setResponseCode("200");
								responseModel.setResponseMessage(certificateUrl);
							}
						}
					}
					if("error".equalsIgnoreCase(status)){
						JsonNode errors = root.path("errors");
						if(!errors.isNull() && errors.size()>0){
							Iterator<JsonNode> itr = errors.elements();                           
							while (itr.hasNext()) {
								JsonNode temp = itr.next();
								if(temp.asInt()==11095)
								{ 
									errorMessage="HSM owner certificate is not installed."; 
								}
								if(temp.asInt()==11096)
								{ 
									errorMessage="HSM Certificate issued by HO is not installed."; 
								}
								if(temp.asInt()==11097)
								{ 
									errorMessage="HSM owner certificate is not installed.";
								}
							}
							responseModel.setResponseMessage(errorMessage);	  
							responseModel.setResponseCode("409");	  
						}
					}
				}
			}
		}catch (Exception e) {
			logger.error("Error occured in  getCertificateURL Method :: "+e.getMessage());
		}
		return responseModel;
	}

	/**
	 * 
	 * @param pdmobj
	 * @return
	 */
	private JSONObject getUserNamePassword(ApplianceDetailModel app,JSONObject jsonObject) {
		try {
			if (app != null) {
				ApplianceDetailModel dbAppliance = applianceRepository.findOne(app.getApplianceId());
				if (dbAppliance != null) {
					long applianceId = app.getApplianceId();
					InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry
							.getInitializeIdByApplianceId(applianceId);
					if (initmodel != null) {
						InitializeApplianceDetailModel initAppDetailModel = initializeRepository
								.findOne(initmodel.getInitializeId());
						DualFactorAuthDetailModel dualAuthModel = initAppDetailModel.getDualFactorAuthDetailModel();
						if (!StringUtils.isEmpty(app.getOperationUsername())	&& !StringUtils.isEmpty(app.getOperationPassword())) {
							if (initAppDetailModel.getAuthenticationLevel() == 0) {
								jsonObject.put("username", app.getOperationUsername());
								jsonObject.put("password", app.getOperationPassword());
							}
							if (initAppDetailModel.getAuthenticationLevel() == 1 && dualAuthModel != null) {
								jsonObject.put("username", app.getOperationUsername());
								jsonObject.put("password", app.getOperationPassword());
								jsonObject.put("dualFactorHostname", dualAuthModel.getDualFactorAuthServerAddress());
								jsonObject.put("dualFactorPort", dualAuthModel.getDualFactorAuthServerPortNo());
								jsonObject.put("dualFactorCertificate", dualAuthModel.getDualFactorAuthServerCertId());
							}
						} else {
							if (initAppDetailModel.getAuthenticationLevel() == 0) {
								jsonObject.put("username", initAppDetailModel.getCryptoOfficerName());
								jsonObject.put("password", CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));
							}
							if (initAppDetailModel.getAuthenticationLevel() == 1 && dualAuthModel != null) {
								jsonObject.put("username", initAppDetailModel.getCryptoOfficerName());
								jsonObject.put("password", CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));
								jsonObject.put("dualFactorHostname", dualAuthModel.getDualFactorAuthServerAddress());
								jsonObject.put("dualFactorPort", dualAuthModel.getDualFactorAuthServerPortNo());
								jsonObject.put("dualFactorCertificate", dualAuthModel.getDualFactorAuthServerCertId());
							}
						}
					}else {
						jsonObject.put("username", app.getOperationUsername());
						jsonObject.put("password", app.getOperationPassword());
					}
				}
			}else {
				jsonObject.put("Error", "Partition does Not exists");
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getUserNamePassword method in partitionServiceIMPL");
		}
		return jsonObject;
	}
	/**
	 * this method is used to download monitor Logs File
	 */
	@Override
	public File downloadMonitorFile(String certificateUrl, String name) {
		logger.info("Start of downloadMonitorFile Method ::");
		File file=null;
		String fileName=null;
		InputStream inputStream=null;
		  OutputStream   outputStream=null;
		try{
			HttpResponse response=restClient.invokeGETMethodForLargeFileDownload(certificateUrl);
			if(response!=null) {
				String finalfileName=null;
				String contentDisposition=response.getFirstHeader("Content-Disposition").getValue();
				String fileNameSplit[]=contentDisposition.split("=");
				if(fileNameSplit.length>0){
				  	fileName=fileNameSplit[1];
				
				}
				 finalfileName = name+"-"+CaviumUtil.getRandomText()+"-"+fileName;
				  file = CaviumUtil.createFile(finalfileName,null,"");
				 
				  HttpEntity entity=response.getEntity();
					  if (entity != null) {
					   inputStream = entity.getContent();
			            outputStream = new FileOutputStream(file);
			            IOUtils.copy(inputStream, outputStream);
						 }
			 	
			}		 
		}catch (Exception e) {
			try{
				Files.deleteIfExists(Paths.get(file.getAbsolutePath()));
				file=null;
			}catch (Exception exp) {
				logger.error("Error in writting content to file  in downloadMonitorFile method of ApplianceServiceImpl Class :: " + e.getMessage()); 
			}
		 
		}finally{
			try{
			if(inputStream!=null)
			{
				inputStream.close();	
			}
			if(outputStream!=null)
			{
				outputStream.flush();
				outputStream.close();
			}
			}catch (Exception e) {
				logger.error("Error occured in  downloadMonitorFile Method for closing InputStream and OutputStream :: "+e.getMessage());
			}
		}
		logger.info("end of downloadMonitorFile Method ::");
		return file;
	}


	@Override
	public CaviumResponseModel getSelfReportData(ApplianceDetailModel applianceDetailModel) {
		// TODO Auto-generated method stub
		CaviumResponseModel caviumResponseModel=new CaviumResponseModel();
		String loggedInUser = userAttributes.getlogInUserName();
		ResponseEntity<String> response=null;
		try {
			if(applianceDetailModel!=null && !StringUtils.isEmpty(applianceDetailModel.getIpAddress())) {
				if (!StringUtils.isEmpty(applianceDetailModel.getSelfReportType())
						&& applianceDetailModel.getSelfReportType().equalsIgnoreCase("admin")) {
					response = restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/admin_vm_selftest_report");
				}
				if (!StringUtils.isEmpty(applianceDetailModel.getSelfReportType())
						&& applianceDetailModel.getSelfReportType().equalsIgnoreCase("host")) {
					response = restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/host_selftest_report");
				}
				if (!StringUtils.isEmpty(applianceDetailModel.getSelfReportType())
						&& applianceDetailModel.getSelfReportType().equalsIgnoreCase("partition")) {
					List<PartitionDetailModel> pdmlist=applianceDetailModel.getPartitionDetailModels();
					if(pdmlist.size() > 0) {
						for(PartitionDetailModel pdm:pdmlist) {
							response = restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/partition_vm_selftest_report/"+pdm.getPartitionName()+"");
						}
					}
				}
				if(response!=null && response.getBody()!=null && response.getBody().contains("success")) {
					ObjectMapper mapper = new ObjectMapper();
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						String status = root.path("status").asText();
						if("success".equalsIgnoreCase(status)){
							JsonNode dataNode = root.path("data");
							if(!dataNode.isNull() && dataNode.size()>0){
								caviumResponseModel.setResponseCode("200");
								caviumResponseModel.setResponseMessage(dataNode.toString());
							}
						}
					}
				}else {
					applianceDetailModel=getErrorMessage(response, applianceDetailModel,loggedInUser,applianceDetailModel.getSelfReportType());
					if(applianceDetailModel.getCode()!=null && applianceDetailModel.getErrorMessage()!=null) {
						caviumResponseModel.setResponseCode(applianceDetailModel.getCode());
						caviumResponseModel.setResponseMessage(applianceDetailModel.getErrorMessage());
					}else {
						caviumResponseModel.setResponseCode("000");
						caviumResponseModel.setResponseMessage("No error data found");
					}
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getSelfReportData"+e.getMessage());
		}
		return caviumResponseModel;
	}


	@Override
	public SNMPDetails getSNMPInfo(SNMPDetails snmpdetails) {
		// TODO Auto-generated method stub
		logger.error("Start of  method getSNMPInfo in class ApplianceServiceImpl class");
		ResponseEntity<String> response = null;
		ApplianceDetailModel applianceDetailModel=applianceRepository.findOne(snmpdetails.getApplianceId());
		String loggedInUser = userAttributes.getlogInUserName();
		try {
			response = restClient
					.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/admin_snmp_config");

			if (response != null && response.getBody() != null && response.getBody().contains("success")) {
				ObjectMapper mapper = new ObjectMapper();
				JsonNode root = mapper.readTree(response.getBody());
				JsonNode data=root.path("data");
				snmpdetails.setCode("200");
				snmpdetails.setMessage(data.toString());
			} else {
				applianceDetailModel=getErrorMessage(response, applianceDetailModel,loggedInUser,applianceDetailModel.getSelfReportType());
				if(applianceDetailModel.getCode()!=null && applianceDetailModel.getErrorMessage()!=null) {
					snmpdetails.setCode(applianceDetailModel.getCode());
					snmpdetails.setMessage(applianceDetailModel.getErrorMessage());
				}else {
					snmpdetails.setCode("000");
					snmpdetails.setMessage("No error data found");
				}
			}
		} catch (Exception e) {
			logger.error("Error occured during method getSNMPInfo in class ApplianceServiceImpl class :: "+e.getMessage());
		}
		logger.error("end of method getSNMPInfo in ApplianceServiceImpl class");
		return snmpdetails;
	}


	@Override
	public SNMPDetails setSNMPInfo(SNMPDetails snmpDetails){
		// TODO Auto-generated method stub
		logger.error("Start of  method setSNMPInfo in class ApplianceServiceImpl class");
 
		ApplianceDetailModel applianceDetailModel=applianceRepository.findOne(snmpDetails.getApplianceId());
		String loggedInUser = userAttributes.getlogInUserName();

		try {
			JSONObject jsonObject=new JSONObject();
			if (snmpDetails.getApplianceId() != null) {
				ApplianceDetailModel dbAppliance = applianceRepository.findOne(snmpDetails.getApplianceId());
				if (dbAppliance != null) {
					long applianceId = snmpDetails.getApplianceId();
					InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry
							.getInitializeIdByApplianceId(applianceId);
					if (initmodel != null) {
						InitializeApplianceDetailModel initAppDetailModel = initializeRepository
								.findOne(initmodel.getInitializeId());
						DualFactorAuthDetailModel dualAuthModel = initAppDetailModel.getDualFactorAuthDetailModel();
						if (!StringUtils.isEmpty(snmpDetails.getOperationUsername())	&& !StringUtils.isEmpty(snmpDetails.getOperationPassword())) {
							if (initAppDetailModel.getAuthenticationLevel() == 0) {
								jsonObject.put("username", snmpDetails.getOperationUsername());
								jsonObject.put("password", snmpDetails.getOperationPassword());
							}
							if (initAppDetailModel.getAuthenticationLevel() == 1 && dualAuthModel != null) {
								jsonObject.put("username", snmpDetails.getOperationUsername());
								jsonObject.put("password", snmpDetails.getOperationPassword());
								jsonObject.put("dualFactorHostname", dualAuthModel.getDualFactorAuthServerAddress());
								jsonObject.put("dualFactorPort", dualAuthModel.getDualFactorAuthServerPortNo());
								jsonObject.put("dualFactorCertificate", dualAuthModel.getDualFactorAuthServerCertId());
							}
						} else {
							if (initAppDetailModel.getAuthenticationLevel() == 0) {
								jsonObject.put("username", initAppDetailModel.getCryptoOfficerName());
								jsonObject.put("password", CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));
							}
							if (initAppDetailModel.getAuthenticationLevel() == 1 && dualAuthModel != null) {
								jsonObject.put("username", initAppDetailModel.getCryptoOfficerName());
								jsonObject.put("password", CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));
								jsonObject.put("dualFactorHostname", dualAuthModel.getDualFactorAuthServerAddress());
								jsonObject.put("dualFactorPort", dualAuthModel.getDualFactorAuthServerPortNo());
								jsonObject.put("dualFactorCertificate", dualAuthModel.getDualFactorAuthServerCertId());
							}
						}
					}else {
						jsonObject.put("username", snmpDetails.getOperationUsername());
						jsonObject.put("password", snmpDetails.getOperationPassword());
					}
				}
			 jsonObject.put("enable", snmpDetails.isEnable());
			if(snmpDetails.isEnable()){
				jsonObject.put("enableTrap", snmpDetails.isEnableTrap());
				jsonObject.put("ip", snmpDetails.getSnmpip());
				jsonObject.put("uname", snmpDetails.getUname());
				jsonObject.put("engineId", snmpDetails.getEngineId());
				jsonObject.put("port", snmpDetails.getPort());
				Map<String,String> authMode= new HashMap<String,String>();
				authMode.put("encryption", snmpDetails.getAuthModeEncryption());
				if(snmpDetails.getAuthModeEncryption()!=null && !snmpDetails.getAuthModeEncryption().equalsIgnoreCase("none")){
					authMode.put("password", snmpDetails.getAuthModePassword());
				}
				Map<String,String> privMode= new HashMap<String,String>();
				privMode.put("encryption", snmpDetails.getPrivModeEncryption());
				if(snmpDetails.getPrivModeEncryption()!=null && !snmpDetails.getPrivModeEncryption().equalsIgnoreCase("none")){
					privMode.put("password", snmpDetails.getPrivModeEncryption());
				}
				jsonObject.put("authMode", authMode);	
				jsonObject.put("privMode", privMode);	
			}
			ResponseEntity<String> response=restClient.invokePOSTMethodForOperations("https://"+snmpDetails.getApplianceIp()+"/liquidsa/admin_snmp_config",jsonObject);
			if (response != null && response.getBody() != null && response.getBody().contains("success")) {			 		 
				snmpDetails.setCode("200");
				snmpDetails.setMessage("SNMP Infomation saved Sucessfully");
			//	snmpDetails.setMessage(data.toString());
			} else {
				applianceDetailModel =getErrorMessage(response, applianceDetailModel, loggedInUser, "SNMP Info");
				snmpDetails.setCode(applianceDetailModel.getCode());
				snmpDetails.setMessage(applianceDetailModel.getErrorMessage());
			}
			if (response != null && response.getStatusCodeValue() == 404) {
				String error=env.getProperty("partition.notexists.cavium.network");
				snmpDetails.setCode("408");
				snmpDetails.setMessage(error);
			}
		}
			
		}catch (Exception e) {
			logger.error("Error occured during method getSNMPInfo in class ApplianceServiceImpl class :: "+e.getMessage());
		}
		logger.error("end of method getSNMPInfo in ApplianceServiceImpl class");
		return snmpDetails;
	}
	
	
	public CaviumResponseModel uploadMCOKeyCertificate(MCOKeyCertificateDetails mcoKeyCertificateDetails, File convMCOKeyKeyCertificate) {

		logger.info("start of uploadMCOKeyCertificate Method of ApplianceServiceImpl class");
		CaviumResponseModel responseModel=getCaviumResponseModel();
		String fileUploadedId=null;	 
		String username=null;
		String password=null;
		String dualFactorHostname=null;
		Integer dualFactorPort=null;
		String dualFactorCertificate=null;
		try{
			File file=convMCOKeyKeyCertificate; 
			/*if(mcoKeyCertificateDetails.getFileContent()!=null && mcoKeyCertificateDetails.getFileExtension()!=null  && mcoKeyCertificateDetails.getFileName()!=null){
				file = CaviumUtil.createFile(mcoKeyCertificateDetails.getFileName(),mcoKeyCertificateDetails.getFileExtension(),mcoKeyCertificateDetails.getFileContent());
			}*/
			 
			InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(mcoKeyCertificateDetails.getApplianceId());
			if(initmodel!=null) {
				InitializeApplianceDetailModel initAppDetailModel = initializeRepository.findOne(initmodel.getInitializeId());
				password= CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword());
				username=initAppDetailModel.getCryptoOfficerName();
				DualFactorAuthDetailModel dualAuthModel=initAppDetailModel.getDualFactorAuthDetailModel();
				if(dualAuthModel!=null) {
					dualFactorHostname=dualAuthModel.getDualFactorAuthServerAddress();
					dualFactorPort=dualAuthModel.getDualFactorAuthServerPortNo();
					dualFactorCertificate=dualAuthModel.getDualFactorAuthServerCertId();

					if(file!=null){
						responseModel=fileUploadService.uploadFile(file,username,password,"StoreMCOFixedKeyBlob",mcoKeyCertificateDetails.getApplianceIp(),dualAuthModel);
						fileUploadedId=responseModel.getResponseMessage();
					}
					 
				}
			}else{
				username=mcoKeyCertificateDetails.getOperationUsername();
				password=mcoKeyCertificateDetails.getOperationPassword();
				if(file!=null){
					responseModel=fileUploadService.uploadFile(file,mcoKeyCertificateDetails.getOperationUsername(),mcoKeyCertificateDetails.getOperationPassword(),"StoreMCOFixedKeyBlob",mcoKeyCertificateDetails.getApplianceIp(),null);
					fileUploadedId=responseModel.getResponseMessage();
				}
				 
			}
			if(file!=null){
				if(username!=null && password!=null)
				{
					JSONObject json = new JSONObject(); 	
					json.put("username",username);
					json.put("password",password);
					if(dualFactorHostname!=null && dualFactorPort!=null && dualFactorCertificate!=null){
						json.put("dualFactorHostname",dualFactorHostname);
						json.put("dualFactorPort",dualFactorPort);
						json.put("dualFactorCertificate",dualFactorCertificate);
					}
					json.put("keyFileId",fileUploadedId);
					ResponseEntity<String> response=restClient.invokePOSTMethodForOperations("https://"+mcoKeyCertificateDetails.getApplianceIp()+"/liquidsa/store_mco_fixed_key", json);
					if(response!=null && response.getStatusCode().name().equals("OK")) {
						ObjectMapper mapper = new ObjectMapper();
						if(response.getBody()!=null){
							JsonNode root = mapper.readTree(response.getBody());
							if(!root.isNull()){			
							String status = root.path("status").asText();
		
							if("success".equalsIgnoreCase(status)){
								responseModel.setResponseCode("200");
								responseModel.setResponseMessage("MCO key Certificate uploaded succeessfully.");
							}else{
								if(response.getBody().contains("errors")) {
									JsonNode errors = root.path("errors");
									if(!errors.isNull() && errors.size() > 0){
										logger.info("Error size"+errors.size()+" is Array"+errors.isArray());
										StringBuilder sbmessage=new StringBuilder();
										StringBuilder sbcode=new StringBuilder();
										Iterator<JsonNode> itr = errors.elements();	
										while (itr.hasNext()) {
											JsonNode temp = itr.next();
											sbcode.append(""+temp.asInt()+"");
											if(env.containsProperty(""+temp.asInt()+"")) {
												sbmessage.append(env.getProperty(""+temp.asInt()+""));
											}else {
												sbmessage.append("Error message not available");
											}
											sbcode.append(",");
											sbmessage.append(",");
										}
										String errorMessage=sbmessage.toString();
										errorMessage=errorMessage.substring(0, errorMessage.length()-1);
										errorMessage=errorMessage+".";
										String code=sbcode.toString();
										code=code.substring(0, code.length()-1);
										code=code+".";
										responseModel.setResponseCode(code);
										responseModel.setResponseMessage(errorMessage); 
									} else {
										String encodeMessage = "";
										if (errors.size() == 0) {
											encodeMessage = root.path("message").asText();
											encodeMessage = CaviumUtil.decodeMessageBase64(encodeMessage);										 
											responseModel.setResponseMessage(encodeMessage);
										}else {
											responseModel.setResponseMessage("No message found");
										}
									}
								}
							}
				  
					}
						}
					else{
						responseModel.setResponseCode("409");
						responseModel.setResponseMessage("error coming while import certificate."); 
					}
				}
				}
				else{
					responseModel.setResponseCode("409");
					responseModel.setResponseMessage("Credentials are required."); 
				}
			}
			else{
				responseModel.setResponseCode("409");
				responseModel.setResponseMessage("FileUploadId is missing"); 
			}
		}catch (Exception e) {
			logger.error("Error occured in  uploadMCOKeyCertificate Method of ApplianceServiceImpl class:: "+e.getMessage());
		}
		logger.info("end of uploadMCOKeyCertificate Method of ApplianceServiceImpl class");
		return responseModel;
	}


	@Override
	public void doFirmwareUpgrade(List<ApplianceDetailModel> listApplianceDetailModels,
			MultipartFile imageFile, MultipartFile signFile,String loggedInUser) {
		// TODO Auto-generated method stub
		try {
			new Thread(new Runnable() {
				@Override
			public void run() {
				// TODO Auto-generated method stub
					if(listApplianceDetailModels!=null && listApplianceDetailModels.size() > 0) {
						for(ApplianceDetailModel app:listApplianceDetailModels) {
							ApplianceDetailModel dbmodel=applianceRepository.findOne(app.getApplianceId());
							JSONObject jsonObject=new JSONObject();
							jsonObject=getUserNamePassword(app, jsonObject);
							String username=(String)jsonObject.get("username");
							String password=(String)jsonObject.get("password");
							HashMap<String,String> map=getUploadedFileNames(dbmodel.getIpAddress(), username, password, null,imageFile,signFile);
							if(map.containsKey("imageFilePath") && map.containsKey("signFilePath")) {
								applianceFirmwareUpgrade(app,map,loggedInUser);
								}
							}
					}
				}
			}).start();
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured due to FirmwareUpgrade inside method doFirmwareUpgrade from ApplianceserviceIMPL");
		}
	}

	/**
	 * This method is used to validate appliance for delete
	 */
	@Override
	public ApplianceDeleteFailureModel validateDeleteAppliance(List<ApplianceDetailModel> listApplianceDetailModels) {
		// TODO Auto-generated method stub
		ApplianceDeleteFailureModel applianceDeleteFailureModel=new ApplianceDeleteFailureModel();
		try {
			boolean found = false;
			List<ApplianceDetailModel> clusterFailureList=new ArrayList<>();
			List<ApplianceDetailModel> fipsStateNonZeroizeList=new ArrayList<>();
			List<ApplianceDetailModel> sucessList=new ArrayList<>();
			
			for (ApplianceDetailModel app : listApplianceDetailModels) {
				List<PartitionDetailModel> partlist = partitionRepository
						.getListOfPartitionByApplianceID(app.getApplianceId());
				if (partlist != null && partlist.size() > 0) {
					for (PartitionDetailModel partdm : partlist) {
						List<ClusterPartitionsRelationship> clus = clusterPartitionsRelationshipRepository.getListOfClusters(partdm.getPartitionId());
						if (clus != null && clus.size() > 0) {
							clusterFailureList.add(app);
						}
					}
				}
			}

			for (ApplianceDetailModel mainList : listApplianceDetailModels) {

				for (ApplianceDetailModel clus : clusterFailureList) {
					if (mainList.getApplianceId() == clus.getApplianceId()) {
						found = true;
					}
				}
				if (!found) {
					/**
					 * Do logic
					 */
					HSMInfo hsmInfo = getHSMInfo(mainList, getHSMInfo());
					if (hsmInfo != null && !StringUtils.isEmpty(hsmInfo.getFipsState())
							&& hsmInfo.getFipsState().replaceAll(" ","").contains("-1[zeroized]")) {
						sucessList.add(mainList);
					}else {
						fipsStateNonZeroizeList.add(mainList);
					}
				}
				found = false;
			}
			
			applianceDeleteFailureModel.setDueToCluster(clusterFailureList);
			applianceDeleteFailureModel.setFipsStateNonZeroize(fipsStateNonZeroizeList);
			applianceDeleteFailureModel.setSuccessList(sucessList);
			
			
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured due to validateDeleteAppliance"+e.getMessage());
		}
		return applianceDeleteFailureModel;
	}

	private CaviumResponseModel saveZoneDetails(ApplianceDetailModel applianceDetailModel){
		logger.info("Start of saveZoneDetails Method of ApplianceServiceImpl class");
		CaviumResponseModel responseModel=new CaviumResponseModel();
		String dualFactorHostname=null;
		Integer dualFactorPort=null;
		String dualFactorCertificate=null;
		String username=null;
		String password=null;
		InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(applianceDetailModel.getApplianceId());
		if(initmodel!=null) {
			InitializeApplianceDetailModel initAppDetailModel = initializeRepository.findOne(initmodel.getInitializeId());
		 	password= CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword());
		 	username=initAppDetailModel.getCryptoOfficerName();
			DualFactorAuthDetailModel dualAuthModel=initAppDetailModel.getDualFactorAuthDetailModel();
			if(dualAuthModel!=null) {
			 dualFactorHostname=dualAuthModel.getDualFactorAuthServerAddress();
			 dualFactorPort=dualAuthModel.getDualFactorAuthServerPortNo();
			 dualFactorCertificate=dualAuthModel.getDualFactorAuthServerCertId();
			}
		}else{
			username=applianceDetailModel.getOperationUsername();
			password=applianceDetailModel.getOperationPassword();
		 }
		
		JSONObject json = new JSONObject(); 	
		json.put("username",username);
		json.put("password",password);
		json.put("name",applianceDetailModel.getCityName());
		json.put("zoneId",Integer.parseInt(applianceDetailModel.getZoneId()));
		if(dualFactorHostname!=null && dualFactorPort!=null && dualFactorCertificate!=null){
			json.put("dualFactorHostname",dualFactorHostname);
			json.put("dualFactorPort",dualFactorPort);
			json.put("dualFactorCertificate",dualFactorCertificate);
		}
		try{
		ResponseEntity<String> response=restClient.invokePOSTMethodForOperations("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/app_zone", json);
		if(response!=null && response.getStatusCode().name().equals("OK")) {
			ObjectMapper mapper = new ObjectMapper();
			if(response.getBody()!=null){
				JsonNode root = mapper.readTree(response.getBody());
				if(!root.isNull()){			
				String status = root.path("status").asText();

				if("success".equalsIgnoreCase(status)){
					responseModel.setResponseCode("200");
					responseModel.setResponseMessage("Zone details saved successfully.");
				}else{
					if(response.getBody().contains("errors")) {
						JsonNode errors = root.path("errors");
						if(!errors.isNull() && errors.size() > 0){
							logger.info("Error size"+errors.size()+" is Array"+errors.isArray());
							StringBuilder sbmessage=new StringBuilder();
							StringBuilder sbcode=new StringBuilder();
							Iterator<JsonNode> itr = errors.elements();	
							while (itr.hasNext()) {
								JsonNode temp = itr.next();
								sbcode.append(""+temp.asInt()+"");
								if(env.containsProperty(""+temp.asInt()+"")) {
									sbmessage.append(env.getProperty(""+temp.asInt()+""));
								}else {
									sbmessage.append("Error message not available");
								}
								sbcode.append(",");
								sbmessage.append(",");
							}
							String errorMessage=sbmessage.toString();
							errorMessage=errorMessage.substring(0, errorMessage.length()-1);
							errorMessage=errorMessage+".";
							String code=sbcode.toString();
							code=code.substring(0, code.length()-1);
							code=code+".";
							responseModel.setResponseCode(code);
							responseModel.setResponseMessage(errorMessage); 
						} else {
							String encodeMessage = "";
							if (errors.size() == 0) {
								encodeMessage = root.path("message").asText();
								encodeMessage = CaviumUtil.decodeMessageBase64(encodeMessage);										 
								responseModel.setResponseMessage(encodeMessage);
							}else {
								responseModel.setResponseMessage("No message found");
							}
						}
					}
				}
	  
		}
			}
		else{
			responseModel.setResponseCode("409");
			responseModel.setResponseMessage("error coming while import certificate."); 
		}
	}
		}catch (Exception e) {
			logger.error("Error occured in  saveZoneDetails Method of ApplianceServiceImpl class:: "+e.getMessage());
		}
		logger.info("end of saveZoneDetails Method of ApplianceServiceImpl class::");
		return  responseModel;
	}


	@Override
	public CaviumResponseModel deleteTemporaryAppliance(ApplianceDetailModel app) {
		CaviumResponseModel caviumResponseModel=getCaviumResponseModel();
			if(app!=null && app.getApplianceId()!=null) {
				try {
						applianceRepository.deleteAppliance(app.getApplianceId());
						caviumResponseModel.setResponseCode("200");
						caviumResponseModel.setResponseMessage("Appliance "+app.getApplianceName()+" deleted successfully.");
			  }
		 catch (Exception e) {
			logger.error("Error occured due to db error inside deleteTemporaryAppliance Method of class ApplianceServiceImpl for "+ app.getApplianceName() +" :: "
					+ e.getMessage());
			caviumResponseModel.setResponseCode("500");
			caviumResponseModel.setResponseMessage("Appliance "+app.getApplianceName()+" failed to deleted.");
			 
		}
			}
		return caviumResponseModel; 
	}

	

	@Override
    public ApplianceDetailModel updateApplianceDetails(ApplianceDetailModel applianceDetailModel) {
		 logger.info("Start of updateApplianceDetail Method in ApplianceServiceImpl class");   
           try {
                  ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/partitions");
                  if(response!=null && response.getStatusCode().name().equals("OK")) {
                        ObjectMapper mapper = new ObjectMapper();
                        if(response.getBody()!=null){
                               JsonNode root = mapper.readTree(response.getBody());
                               if(!root.isNull()){
	                                   JsonNode dataNode = root.path("data");
	                                
	                                      if(!dataNode.isNull()){
                                          if(dataNode.has("totalKeys")) {
                                                    int totalKeys = dataNode.path("totalKeys").asInt();
                                                    applianceDetailModel.setTotalKeys(totalKeys);
                                             }
                                             if(dataNode.has("occupiedKeys")){
                                                    int occupiedKeys = dataNode.path("occupiedKeys").asInt();
                                                    applianceDetailModel.setOccupiedKeys(occupiedKeys);
                                             }
                                             if(dataNode.has("totalAcclrDev")) {
                                                    int totalAcclrDev = dataNode.path("totalAcclrDev").asInt();
                                                    applianceDetailModel.setTotalAcclrDevice(totalAcclrDev);
                                             }
                                             if(dataNode.has("occupiedAcclrDev")) {
                                                    int occupiedAcclrDev = dataNode.path("occupiedAcclrDev").asInt();
                                                    applianceDetailModel.setOccupiedAcclrDev(occupiedAcclrDev);
                                             }
                                             if(dataNode.has("totalContexts")){
                                                    int totalContexts = dataNode.path("totalContexts").asInt();
                                                    applianceDetailModel.setTotalContexts(totalContexts);
                                             }
                                             if(dataNode.has("occupiedContexts")){
                                                    int occupiedContexts = dataNode.path("occupiedContexts").asInt();
                                                    applianceDetailModel.setOccupiedContexts(occupiedContexts);
                                             }
                                             if(dataNode.has("totalPartitions")) {
                                                 int totalPartitions = dataNode.path("totalPartitions").asInt();
                                                 applianceDetailModel.setTotalPartitions(totalPartitions);
                                          }
                                             if(dataNode.has("occupiedPartitions")) {
                                                 int occupiedPartitions = dataNode.path("occupiedPartitions").asInt();
                                                 applianceDetailModel.setOccupiedPartitions(occupiedPartitions);
                                          }
                                             
                                      }
                               } 
                        }
                  }
           } catch (Exception e) {
                  logger.error("Error occured during update Applaince Details in method updateApplianceDetail  of class ApplianceServiceImpl ::" + e.getMessage());          
           }
      	 logger.info("End of updateApplianceDetail Method in ApplianceServiceImpl class");     
      	return applianceDetailModel;
    }

}

