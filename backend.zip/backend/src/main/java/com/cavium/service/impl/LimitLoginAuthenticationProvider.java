package com.cavium.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Component;

import com.cavium.service.user.UserService;
 

@Component
public class LimitLoginAuthenticationProvider extends DaoAuthenticationProvider {

	 
	@Autowired
	private UserService userService;
	
	@Autowired
	@Qualifier("userDetailsService")
	@Override
	public void setUserDetailsService(UserDetailsService userDetailsService) {
		super.setUserDetailsService(userDetailsService);
	}
	
	@Override
	public Authentication authenticate(Authentication authentication) 
          throws AuthenticationException {

	  try {

		Authentication auth = super.authenticate(authentication);
		 userService.updateLoginFailureCount(authentication.getName(),0);
		return auth;
			
	  } catch (BadCredentialsException e) {	
			
		//invalid login, update to user_attempts
	int count=	 userService.updateLoginFailureCount(authentication.getName(),-1);
		if(count==5)
		{
			//this user is locked!
			String error = "User Account got locked due to five consecutive wrong attempts.";
	 
		  throw new LockedException(error);
		}
		throw e;
			
	  } catch (LockedException e){
			
		//this user is locked!
		String error = "User Account got locked due to five consecutive wrong attempts.";
 
	  throw new LockedException(error);
	}

	}

}
