package com.cavium.service.recentactivity;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.cavium.model.recentactivity.InProgressActivity;
import com.cavium.repository.recentactivity.InProgressActivityRepository;
@Component
public class InProgressActivityServiceImpl implements  InProgressActivityService {
	private Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	private InProgressActivityRepository inProgressActivityRepository;

	@Override
	public List<InProgressActivity> getListOfInProgressActivity(String loggedInUser,String moduleName) {
		// TODO Auto-generated method stub
		List<InProgressActivity> inProgressActivity=null;
		List<InProgressActivity> deleteList=new ArrayList<InProgressActivity>();
		List<InProgressActivity> returnList=new ArrayList<InProgressActivity>();
		
		try {
			if(!StringUtils.isEmpty(loggedInUser)) {				
				inProgressActivity=inProgressActivityRepository.getListInProgressActivity(loggedInUser,moduleName);
				if(inProgressActivity!=null && inProgressActivity.size() > 0) {
					for(InProgressActivity inpro: inProgressActivity) {
						if(!StringUtils.isEmpty(inpro.getStatus()) && inpro.getStatus().equalsIgnoreCase("success")) {
							deleteList.add(inpro);
						}else {
							returnList.add(inpro);
						}
					}
				}
			}
			if(deleteList.size() > 0) {
				inProgressActivityRepository.delete(deleteList);
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getListOfInProgressActivity"+e.getMessage());
		}
		return returnList;
	}

	@Override
	public void createInProgressActivity(InProgressActivity inProgressActivity) {
		// TODO Auto-generated method stub
		try {
			logger.info("Details of Inprogress Activity :: " + inProgressActivity.toString());
			if(inProgressActivity!=null) {
				inProgressActivityRepository.save(inProgressActivity);
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during createInProgressActivity"+e.getMessage());
		}
	}

}
