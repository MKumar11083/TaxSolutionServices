package com.cavium.service.user;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.core.env.Environment;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.mail.MailException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.cavium.mail.MailUtil;
import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.user.ApplicationDetailModel;
import com.cavium.model.user.DesignationApplianceModel;
import com.cavium.model.user.Status;
import com.cavium.model.user.TemporaryPassword;
import com.cavium.model.user.UserACLDetailsModel;
import com.cavium.model.user.UserDetailModel;
import com.cavium.model.user.UserGroupModel;
import com.cavium.pojo.UserAttributes;
import com.cavium.repository.appliance.ApplianceRepository;
import com.cavium.repository.user.ApplicationRepository;
import com.cavium.repository.user.DesignationApplianceRepository;
import com.cavium.repository.user.UserACLRepository;
import com.cavium.repository.user.UserGroupRepository;
import com.cavium.repository.user.UserRepository;
import com.cavium.service.alerts.AlertsService;
import com.cavium.service.recentactivity.RecentActivityServiceImpl;
import com.cavium.utill.CaviumConstant;
import com.cavium.utill.CaviumResponseModel;
import com.cavium.utill.CaviumUtil;

/**
 * This service class UserServiceImpl is used for CRUD operation on User,
 * UserGroup and UserACL.
 * 
 * @author RK00490847
 * 
 */
@Component
public class UserServiceImpl implements UserService {

	// UserRepository - Repository class for perform Database operation on
	// UserDetailModel.
	@Autowired
	private UserRepository userRepository;

	// UserGroupRepository - Repository class for perform Database operation on
	// UserGroupModel.
	@Autowired
	private UserGroupRepository userGroupRepository;

	// ApplicationRepository - Repository class for perform Database operation on
	// ApplicationDetailModel .
	@Autowired
	private ApplicationRepository applicationRepository;

	// UserACLRepository - Repository class for perform Database operation on
	// UserACLDetailsModel.
	@Autowired
	private UserACLRepository userAclRepository;

	// ApplianceRepository - Repository class for perform Database operation on
	// ApplianceDetailModel.
	@Autowired
	private ApplianceRepository applianceRepository;

	// passwordEncoder - used this class for encrypt the user password
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;

	// get Property Value from Property File
	@Autowired
	private Environment env;
	// for Dynamic Messages
	@Autowired
	private ResourceBundleMessageSource messageSource;
	
	@Autowired
	private UserAttributes userAttributes;
	
	// for Sending email
	@Autowired
	MailUtil mailutil;
	

	@Autowired
	private RecentActivityServiceImpl recentActivityServiceImpl;
	
	@Autowired
	private AlertsService alertsService;
	
	@Autowired
	private CaviumUtil caviumUtil;
	
	@Autowired
	private	DesignationApplianceRepository designationApplianceRepository;

	// logger - instance of application log.
	private Logger logger = Logger.getLogger(this.getClass());

	@Lookup
	public CaviumResponseModel getCaviumResponseModel() {
		return null;
	}

	/*
	 * createUser method is used for creating new user
	 * 
	 * @param userModel - Object of UserDetailModel
	 * 
	 * @return responseModel - CaviumResponseModel Class object
	 */

	@Override
	public CaviumResponseModel createUser(UserDetailModel userModel,String pwdWithoutEncoded) throws MailException {
		logger.info("Start of createUser Method in UserServiceImpl Class");
		CaviumResponseModel responseModel = getCaviumResponseModel();
		boolean createUser=true;
		boolean errorInMail=false;
		String loggedInUser = userAttributes.getlogInUserName(); 
			UserGroupModel objUserGroupModel = null;
			UserACLDetailsModel objUserACLModel = null;
			Map<String, String> toAddress = new HashMap<String, String>();
			Long groupId=null;
			if (org.apache.commons.lang3.StringUtils.isNotEmpty(userModel.getUserGroupId())) {
				if(org.apache.commons.lang.StringUtils.isNumeric(userModel.getUserGroupId())) {
					  groupId=Long.parseLong(userModel.getUserGroupId());
			 		 objUserGroupModel = userGroupRepository.findOne(Long.parseLong(userModel.getUserGroupId()));
					if(	objUserGroupModel == null) {
						responseModel.setResponseCode("409");
						responseModel.setResponseMessage("GroupId doesnot exist in DB ");	
						createUser=false;
					}			
				}else {
					responseModel.setResponseCode("500");
					responseModel.setResponseMessage("GroupId is not valid.It should be Numeric");
					createUser=false;
				}
			}
			if (org.apache.commons.lang.StringUtils.isNotEmpty(userModel.getUserACLId())) {
				if(org.apache.commons.lang.StringUtils.isNumeric(userModel.getUserACLId())){
					objUserACLModel = userAclRepository.findOne(Long.parseLong(userModel.getUserACLId()));
					if(objUserACLModel == null) {
						responseModel.setResponseCode("409");
						responseModel.setResponseMessage("ACLId  doesnot exist in DB ");
						createUser=false;	
					}else{
						 if(groupId!=null){
						if(objUserACLModel.getAclName().trim().equalsIgnoreCase("SecondaryUser")){
						 int numberOfgroupAdminUsers=userRepository.getSecondaryUserForUserGroup(groupId);	
						if(numberOfgroupAdminUsers>0){
									responseModel.setResponseCode("409");
									responseModel.setResponseMessage("Secondary User already exist.");	
									createUser=false;	
								}
						}
						 if(objUserACLModel.getAclName().trim().equalsIgnoreCase("GroupAdmin")){
								int numberOfgroupAdminUsers=userRepository.getGroupAdimUserForUserGroup(groupId);	
								if(numberOfgroupAdminUsers>0){
									responseModel.setResponseCode("409");
									responseModel.setResponseMessage("Group Admin already exist.");	
									createUser=false;	
								}
						}
						 }
					}
				}else {
					responseModel.setResponseCode("500");
					responseModel.setResponseMessage("AclId is not valid.It should be Numeric");
					createUser=false;	
				}	
			}
			if (createUser) {
				if (userModel.getUserName() != null
						&& !userRepository.exists(userModel.getUserName())) {
					userModel.setObjUserGroupModel(objUserGroupModel);
					userModel.setObjUserACLDetailsModel(objUserACLModel);
					if (StringUtils.isEmpty(userModel.getTemporaryPassword()))
						userModel.setTemporaryPassword(TemporaryPassword.Y);
					if (StringUtils.isEmpty(userModel.getStatus()))
						userModel.setStatus(Status.ACTIVE);
					if(userModel.getLoginFailureCount()==null){
						userModel.setLoginFailureCount(0);
					}
					userModel.setCreatedBy(loggedInUser);
					userModel = userRepository.save(userModel);
					    toAddress.put(userModel.getUserName(),userModel.getEmailId());	
					    try{
						mailutil.mailNotificationToUser(userModel.getUserName(), toAddress, null,"/templates/userCreation.vm", "User Creation", pwdWithoutEncoded,userModel.getFirstName());
					    }catch (MailException mailexp) {
					    	logger.info("User created successfuly without Email Trigger"); 
					    	String message=	messageSource.getMessage("userCreation.success.withoutEmail", 
									new Object[] { userModel.getUserName() }, Locale.US);
					    	errorInMail=true;
					    	responseModel.setResponseMessage(message);
					    	recentActivityServiceImpl.createRecentActivity(loggedInUser,"New user "+userModel.getUserName()+" added by "+loggedInUser +"but email not triger due to some issue in Email",CaviumConstant.USER_MANAGEMENT);
					  	}catch (Exception exp) {
					    	logger.info("User created successfuly without Email Trigger"); 
					    	String message=	messageSource.getMessage("userCreation.success.withoutEmail", 
									new Object[] { userModel.getUserName() }, Locale.US);
					    	errorInMail=true;
					    	responseModel.setResponseMessage(message);
					    	recentActivityServiceImpl.createRecentActivity(loggedInUser,"New user "+userModel.getUserName()+" added by "+loggedInUser +"but email not triger due to some issue in Email",CaviumConstant.USER_MANAGEMENT);
					  	}
					    if(!errorInMail){
					  		String message=	messageSource.getMessage("userCreation.success", 
								new Object[] { userModel.getUserName() }, Locale.US);
						responseModel.setResponseMessage(message);
						recentActivityServiceImpl.createRecentActivity(loggedInUser, "New user "+userModel.getUserName()+" added by "+loggedInUser,CaviumConstant.USER_MANAGEMENT);
						}
						responseModel.setResponseCode("200");
						logger.info("User created successfuly");
			 } else {
					responseModel.setResponseCode("409");				 
					String message=	messageSource.getMessage("userCreation.userAllreadyExist", 
							new Object[] { userModel.getUserName() }, Locale.US);
					responseModel.setResponseMessage(message);
				}
			
			} 
			 logger.info("End of createUser Method in UserServiceImpl Class");
		 
		return responseModel;
	}

	/*
	 * getUserGroups method is used for fetch all UserGroups Details
	 * 
	 * @return - List of UserGroupModel
	 */
	@Override
	public List<UserGroupModel> getUserGroups() {
		List<UserGroupModel> objUserGroupModel = new ArrayList<UserGroupModel>();
		try {
			objUserGroupModel = userGroupRepository.findAll();
		} catch (Exception e) {
			logger.error("Error is coming while getting Group Details ::" + e.getMessage());
		}
		return objUserGroupModel;
	}

	/*
	 * getAllACLDetails method is used for fetch all ACLs Details
	 * 
	 * @return - List of UserACLDetailsModel
	 */
	@Override
	public List<UserACLDetailsModel> getAllACLDetails() {
		List<UserACLDetailsModel> objUserACLDetailsModel = new ArrayList<UserACLDetailsModel>();
		try {
			objUserACLDetailsModel = userAclRepository.findAll();
		} catch (Exception e) {
			logger.error("Error is coming while getting ACL Details ::" + e.getMessage());
		}
		return objUserACLDetailsModel;
	}

	/*
	 * listUsers method is used for fetch User Details.
	 * 
	 * If userName,LatsName,firstName,userGroupId,userACLId,emailId.phoneNumber is
	 * blank then it will return list of all the users else it will search the user
	 * based on the input from request like firstName etc
	 * 
	 * @param userSearchModel - Object of UserDetailModel
	 * 
	 * @return listAllUsers - List of UserDetailModel
	 */

	@Override
	public List<UserDetailModel> listUsers(UserDetailModel userSearchModel,String groupId,String createdBy) {
		List<UserDetailModel> listAllUsers = new ArrayList<UserDetailModel>();
		String loggedInUser = userAttributes.getlogInUserName();
		try {
			if (userSearchModel != null) {

				String userName = userSearchModel.getUserName();
				String lastName = userSearchModel.getLastName();
				String firstName = userSearchModel.getFirstName();
				String userGroupId = userSearchModel.getUserGroupId();
				String userACLId = userSearchModel.getUserACLId();
				String emailId = userSearchModel.getEmailId();
				String phoneNumber = userSearchModel.getPhoneNumber();

				if (userName == null) {
					userName = "";
				}
				if (firstName == null) {
					firstName = "";
				}
				if (lastName == null) {
					lastName = "";
				}

				if (userGroupId == null) {
					userGroupId = "";
				}
				if (emailId == null) {
					emailId = "";
				}
				if (phoneNumber == null) {
					phoneNumber = "";
				}

				if (org.apache.commons.lang3.StringUtils.isNotEmpty(userGroupId)
						&& org.apache.commons.lang3.StringUtils.isNotEmpty(userACLId)) {
					if (org.apache.commons.lang.StringUtils.isNumeric(userACLId)
							&& org.apache.commons.lang.StringUtils.isNumeric(userGroupId)) {
						UserGroupModel objUserGroupModel = null;
						UserACLDetailsModel objUserACLDetailsModel = null;
						objUserGroupModel = userGroupRepository.findOne(Long.parseLong(userGroupId));
						objUserACLDetailsModel = userAclRepository.findOne(Long.parseLong(userACLId));
						listAllUsers = userRepository.searchUserDetailsByGroupAndACL(userName, firstName, lastName,
								objUserGroupModel, objUserACLDetailsModel);
					}
				} else if (org.apache.commons.lang3.StringUtils.isNotEmpty(userGroupId)
						&& org.apache.commons.lang.StringUtils.isNumeric(userGroupId)) {
					UserGroupModel objUserGroupModel = null;
					objUserGroupModel = userGroupRepository.findOne(Long.parseLong(userGroupId));
					listAllUsers = userRepository.searchUserDetailsByGroup(userName, firstName, lastName,
							objUserGroupModel);
				} else if (org.apache.commons.lang3.StringUtils.isNotEmpty(userACLId)
						&& org.apache.commons.lang.StringUtils.isNumeric(userACLId)) {
					UserACLDetailsModel objUserACLDetailsModel = null;
					objUserACLDetailsModel = userAclRepository.findOne(Long.parseLong(userACLId));
					listAllUsers = userRepository.searchUserDetailsByACL(userName, firstName, lastName,
							objUserACLDetailsModel,groupId);
				} else {	
				 	 listAllUsers = userRepository.searchUserDetails(userName, firstName, lastName, emailId,
				    	phoneNumber,groupId,createdBy);
				}
			}

		} catch (Exception e) {
			logger.error("Error is coming in ListUser Method ::" + e.getMessage());
			alertsService.createAlert(loggedInUser,"error is coming while fetching the list of users by "+loggedInUser +"",CaviumConstant.USER_MANAGEMENT);
		}
		return listAllUsers;
	}

	/*
	 * getUserDetails method is used for fetch user Detail based on userId
	 * 
	 * @param userId - String Variable
	 * 
	 * @return objUserDetailModel - object of UserDetailModel
	 */
	@Override
	@Transactional
	public UserDetailModel getUserDetails(String userId) {
		logger.info("Getting details of user: " + userId);
		UserDetailModel objUserDetailModel = new UserDetailModel();
		try {
			if (userId != null) {
				objUserDetailModel = userRepository.findOne(userId);
				if(objUserDetailModel.getObjUserGroupModel()!=null){
				objUserDetailModel.setUserGroupId(String.valueOf(objUserDetailModel.getObjUserGroupModel().getId()));
				}
				logger.info("Returning Model object for updation:" + objUserDetailModel);
			}
		} catch (Exception exp) {
			logger.error("Error is coming in getUserDetails Method " + exp.getMessage());
		}
		return objUserDetailModel;
	}

	/*
	 * deleteUser method is used for delete the user Detail based on userid
	 * 
	 * @param userId - String Variable
	 * 
	 * @return responseModel - object of CaviumResponseModel
	 */
	@Transactional
	public CaviumResponseModel deleteUser(String userid) {
		logger.info("Start of deleteUser Method in USerServiceImpl Class :: ");
		logger.info("UserId :: " + userid);
		CaviumResponseModel responseModel = getCaviumResponseModel();
		String loggedInUser = userAttributes.getlogInUserName();
		try {
			if (!StringUtils.isEmpty(userid) && !userid.equals("SuperAdmin")) {
				int i = userRepository.deleteUser(userid);
				if (i == 1) {
					responseModel.setResponseCode("200");
					String message=	messageSource.getMessage("userDelete.success", 
							new Object[] { userid }, Locale.US);
					responseModel.setResponseMessage(message);		
					logger.info("User Deleted Successfully :: " + userid);
					recentActivityServiceImpl.createRecentActivity(loggedInUser,"User "+userid+" deleted by "+loggedInUser,CaviumConstant.USER_MANAGEMENT);
				} else {
					responseModel.setResponseCode("204");
					
					String message=	messageSource.getMessage("userCreation.doesnot.exist", 
							new Object[] { userid }, Locale.US);
					responseModel.setResponseMessage(message);			 
				}
			} else {
				if("SuperAdmin".equals(userid)){
					responseModel.setResponseCode("204");
					responseModel.setResponseMessage("SuperAdmin cannot be deleted");
				}else{
				responseModel.setResponseCode("204");
				responseModel.setResponseMessage(env.getProperty("userId.empty"));
				}
			}
		 logger.info("End of deleteUser Method in USerServiceImpl Class :: ");
		} catch (Exception exp) {
			logger.error("Error is coming in Delete User :: " + exp.getMessage());
			responseModel.setResponseCode("-230");
			responseModel.setResponseMessage("Failed to delete userId ::" + userid);
			alertsService.createAlert(loggedInUser,"Error is coming while deleting user "+userid+" by "+loggedInUser +"",CaviumConstant.USER_MANAGEMENT);
		}
		return responseModel;
	}

	/*
	 * changePassword method is used for change the password of user
	 * 
	 * @param userId - String Variable * @param oldpassword - String Variable
	 * 
	 * @return boolean variable
	 * 
	 */
	@Override
	@Transactional
	public CaviumResponseModel changePassword(String userid, String oldPassword, String newPassword) {
		logger.info("Start of changePassword Method in UserServiceImpl:");
		int pwdchanged = 0;
		int temppwdchanged = 0;
		CaviumResponseModel responseModel = getCaviumResponseModel();
		try {
			logger.info("Changing Password for the user:" + userid);
			UserDetailModel userDetail = userRepository.getOne(userid);
			String databasePassword = userDetail.getPassword();
			if (!passwordEncoder.matches(newPassword, databasePassword)){
				if(passwordEncoder.matches(oldPassword, databasePassword)) {
				pwdchanged = userRepository.updatePassword(passwordEncoder.encode(String.valueOf(newPassword)), userid);
				temppwdchanged = userRepository.updateTempPassword(TemporaryPassword.N, userid);
			}else{
				responseModel.setResponseCode("409");
				responseModel.setResponseMessage(env.getProperty("changePassword.oldPassword.notCorrect"));	
				pwdchanged=-1;
			}
		}else{
			if(!passwordEncoder.matches(oldPassword, databasePassword)){
				responseModel.setResponseMessage(env.getProperty("changePassword.oldPassword.notCorrect"));	
				pwdchanged=-1;
			}
			else{	responseModel.setResponseCode("409");
					responseModel.setResponseMessage(env.getProperty("changePassword.newPassword.same"));	
					pwdchanged=-1;
			}
			 }
			 logger.info("End of changePassword Method in UserServiceImpl:");
			if (pwdchanged > 0 && temppwdchanged > 0) {
				responseModel.setResponseCode("200");
				responseModel.setResponseMessage(env.getProperty("changePassword.success"));
			} if(pwdchanged==0 && temppwdchanged==0) {
				responseModel.setResponseCode("500");
				responseModel.setResponseMessage(env.getProperty("application.error"));
			}
		} catch (Exception e) {
			responseModel.setResponseCode("500");
			responseModel.setResponseMessage(env.getProperty("application.error"));
		}
		return responseModel;

	}

	/*
	 * deleteUserGroup method is used for delete the userGroup based on groupId.
	 * 
	 * @param groupId - String Variable
	 * 
	 * @return integer variable
	 * 
	 */
	@Override
	@Transactional
	public CaviumResponseModel deleteUserGroup(String groupId) {
		CaviumResponseModel responseModel = getCaviumResponseModel();
		List<String> listApplianceIds=new ArrayList<String>();
		List<String> listDefaultApplianceIds=new ArrayList<String>();
		UserGroupModel objUserGroupModel= new UserGroupModel();
		String loggedInUser = userAttributes.getlogInUserName(); 
		String roleName=null;
		try {
			UserGroupModel deletedUserGroup=getGroupDetail("DeletedUserGroup");	
			if (org.apache.commons.lang.StringUtils.isNotEmpty(groupId)
					&& org.apache.commons.lang.StringUtils.isNumeric(groupId)) {
				  objUserGroupModel=userGroupRepository.findOne(Long.parseLong(groupId));	
				  roleName= objUserGroupModel.getRoleName();
				if(objUserGroupModel!=null && objUserGroupModel.getlistDesignationApplianceModel()!=null) {
					for (Iterator<DesignationApplianceModel> iterator = objUserGroupModel.getlistDesignationApplianceModel().iterator(); iterator.hasNext();) {
						DesignationApplianceModel designationApplianceModel = (DesignationApplianceModel) iterator.next();
						Long applianceId= designationApplianceModel.getObjApplianceDetailModel().getApplianceId();	
						//designationApplianceRepository.deleteApplianceFromDesignationAppliance(applianceId);
						listApplianceIds.add(String.valueOf(applianceId));
					} 
				}
			 
				UserGroupModel defaultuserGroup=new UserGroupModel();
				 defaultuserGroup=getGroupDetail(env.getProperty("user.defaultusergroup"));	
				if(defaultuserGroup!=null &&  defaultuserGroup.getId()!=null ) {
					if(defaultuserGroup.getlistDesignationApplianceModel()!=null && defaultuserGroup.getlistDesignationApplianceModel().size()>0) {
						for (Iterator<DesignationApplianceModel> iterator = defaultuserGroup.getlistDesignationApplianceModel().iterator(); iterator.hasNext();) {
							DesignationApplianceModel designationApplianceModel = (DesignationApplianceModel) iterator.next();
							Long applianceId= designationApplianceModel.getObjApplianceDetailModel().getApplianceId();	
							listDefaultApplianceIds.add(String.valueOf(applianceId));
						} 
					}
				  if(listApplianceIds!=null && listApplianceIds.size()>0){
					listDefaultApplianceIds.addAll(listApplianceIds);
					}
					if(listDefaultApplianceIds!=null && listDefaultApplianceIds.size()>0){
						 
					defaultuserGroup.setListApplianceIds(listDefaultApplianceIds);
					defaultuserGroup.setListDesignationApplianceModel(new ArrayList<DesignationApplianceModel>());		
					defaultuserGroup=userGroupRepository.save(defaultuserGroup);
					}
				}				
				userGroupRepository.delete(Long.parseLong(groupId));	
				
				userRepository.updateUserRole(objUserGroupModel,deletedUserGroup);
				responseModel.setResponseCode("200");
				String message=	messageSource.getMessage("userGroup.delete.successs", 
						new Object[] { objUserGroupModel.getRoleName()}, Locale.US);
				responseModel.setResponseMessage(message);
			
				recentActivityServiceImpl.createRecentActivity(loggedInUser, "Group "+roleName+" deleted by "+loggedInUser,CaviumConstant.USER_MANAGEMENT);
			} else {
				responseModel.setResponseCode("204");
				String message=	messageSource.getMessage("userGroup.id.notvalid", 
						new Object[] { groupId}, Locale.US);
				responseModel.setResponseMessage(message);			 
			}
		}  catch (EmptyResultDataAccessException exp) {
			logger.error("UserGroupId doesnot exist in DB " + exp.getMessage());
			responseModel.setResponseCode("-230");
			String message=	messageSource.getMessage("userGroup.doesnot.exist", 
					new Object[] { objUserGroupModel.getRoleName()}, Locale.US);
			responseModel.setResponseMessage(message);
			alertsService.createAlert(loggedInUser,"Error is coming while deleting Group "+roleName+" by "+loggedInUser,CaviumConstant.USER_MANAGEMENT);
		 } catch (Exception exp) {
			logger.error("Error is coming in Delete UserGroup :: " + exp.getMessage());
			responseModel.setResponseCode("-230");
			String message=	messageSource.getMessage("userGroup.delete.failed", 
					new Object[] {objUserGroupModel.getRoleName()}, Locale.US);
			responseModel.setResponseMessage(message);
			alertsService.createAlert(loggedInUser, "Error is coming while deleting Group "+roleName+" by "+loggedInUser,CaviumConstant.USER_MANAGEMENT);

		}
		return responseModel;

	}

	/*
	 * createUserGroup method is used for creating the userGroup.
	 * 
	 * @param userGrpModel - Object of UserGroupModel.
	 * 
	 * @return CaviumResponseModel - object of CaviumResponseModel.
	 * 
	 */
	@Override
	@Transactional
	public CaviumResponseModel createUserGroup(UserGroupModel userGrpModel) {
		CaviumResponseModel responseModel = getCaviumResponseModel();
		String loggedInUser = userAttributes.getlogInUserName(); 
		try {
			List<String> listDefaultApplianceIds=new ArrayList<String>();
			List<String>defaulGroupApplianceIds=userGrpModel.getDefaultGroupApplianceIds();
			List<UserGroupModel> listUserGroupModel = userGroupRepository
					.findGroupDetailsForGroupName(userGrpModel.getRoleName());
		
			if (listUserGroupModel != null && listUserGroupModel.size() == 0) {
				if (userGrpModel.getLastUpdated() == null)
					userGrpModel.setLastUpdated(new Date());
				for (Iterator iterator = userGrpModel.getListApplianceIds().iterator(); iterator.hasNext();) {
					String applianceId = (String) iterator.next();
					designationApplianceRepository.deleteApplianceFromDesignationAppliance(Long.parseLong(applianceId));	
				}
				userGroupRepository.save(userGrpModel);
				responseModel.setResponseCode("200");
				String message=	messageSource.getMessage("userGroupCreation.success", 
						new Object[] { userGrpModel.getRoleName()}, Locale.US);
				responseModel.setResponseMessage(message);
				logger.info(userGrpModel.toString() + " is  created Sucessfully");
				UserGroupModel defaultuserGroup=new UserGroupModel();
				  defaultuserGroup=getGroupDetail(env.getProperty("user.defaultusergroup"));
				  
				if(defaultuserGroup!=null &&  defaultuserGroup.getId()!=null && defaulGroupApplianceIds!=null ) {
					for (Iterator<String> iterator = defaulGroupApplianceIds.iterator(); iterator.hasNext();) {
						String applianceId = (String) iterator.next();
						designationApplianceRepository.deleteApplianceFromDesignationAppliance(Long.parseLong(applianceId));	
					}
					if(defaulGroupApplianceIds!=null&& defaulGroupApplianceIds.size()>0){
					listDefaultApplianceIds.addAll(defaulGroupApplianceIds);
					}
					if(listDefaultApplianceIds!=null && listDefaultApplianceIds.size()>0){
					defaultuserGroup.setListApplianceIds(listDefaultApplianceIds);
					defaultuserGroup.setListDesignationApplianceModel(new ArrayList<DesignationApplianceModel>());		
					defaultuserGroup=userGroupRepository.save(defaultuserGroup);
					}
				}
				
				recentActivityServiceImpl.createRecentActivity(loggedInUser, "Group "+userGrpModel.getRoleName()+" created by "+loggedInUser,CaviumConstant.USER_MANAGEMENT);
			} else {
				String message=	messageSource.getMessage("usergroupCreation.allreadyExist", 
						new Object[] { userGrpModel.getRoleName()}, Locale.US);
				responseModel.setResponseMessage(message);
				logger.info("userGroup is already exist");
				responseModel.setResponseCode("204");
				responseModel.setResponseMessage(message);
				logger.info(userGrpModel.toString() + " - creation failed." + responseModel.getResponseMessage());
			}
		} catch (Exception e) {
			logger.error("Error occured due to db error ::" + e.getMessage());
			responseModel.setResponseCode("500");
			responseModel.setResponseMessage(env.getProperty("application.error"));
			alertsService.createAlert(loggedInUser, "Error is coming while creating Group "+userGrpModel.getRoleName()+" by "+loggedInUser,CaviumConstant.USER_MANAGEMENT);
		}
		return responseModel;
	}

	/*
	 * getUserGroupData method is used for fetch the userGroup.
	 * 
	 * If roleName is blank in userGroup object then it will fetch all the
	 * userGorups . if roleName is not blank them it will fetch Group details based
	 * on roleName.
	 * 
	 * @param userGroup - Object of UserGroupModel.
	 * 
	 * @return listUserGroupModel - List of UserGroupModel Object.
	 * 
	 */
	@Override
	public List<UserGroupModel> getUserGroupData(UserGroupModel userGroup,String userName) {
		List<UserGroupModel> listUserGroupModel = new ArrayList<UserGroupModel>();
		String loggedInUser = userAttributes.getlogInUserName(); 
		try {
			if (userGroup != null) {
				if (userGroup.getRoleName() == null) {
					userGroup.setRoleName("");
				}
			listUserGroupModel = userGroupRepository.listGroupDetails(userGroup.getRoleName(),userName);
			}
		} catch (Exception e) {
			alertsService.createAlert(loggedInUser,"error is coming while fetching the list of groups by "+loggedInUser +"",CaviumConstant.USER_MANAGEMENT);
			logger.error("Error occured due to db error ::" + e.getMessage());
		}
		return listUserGroupModel;
	}

	/*
	 * getAllPermissions method is used for fetch the Application Details.
	 * 
	 * @return listApplicationDetailModel - List of ApplicationDetailModel Object.
	 * 
	 */
	@Override
	@Transactional
	public List<ApplicationDetailModel> getAllPermissions() {
		List<ApplicationDetailModel> listApplicationDetailModel = new ArrayList<ApplicationDetailModel>();
		try {
			listApplicationDetailModel = applicationRepository.findAll();
		} catch (Exception e) {
			logger.error("Error is coming in createUserGroup Method ::" + e.getMessage());
		}
		return listApplicationDetailModel;
	}

	/*
	 * modifyUserGroup method is used for update the group Details.
	 * 
	 * @param userGroupModel - Object of UserGroupModel.
	 * 
	 * @return CaviumResponseModel - CaviumResponseModel Object.
	 * 
	 */
	@Override
	@Transactional(rollbackOn = Exception.class)
	public CaviumResponseModel modifyUserGroup(UserGroupModel userGroupModel) throws Exception {
		CaviumResponseModel responseModel = getCaviumResponseModel();
		List<String> listDefaultApplianceIds=new ArrayList<String>();
		List<String>defaulGroupApplianceIds=userGroupModel.getDefaultGroupApplianceIds();
		if (!Objects.isNull(userGroupModel.getId())) {
			UserGroupModel objUserGroupModel = userGroupRepository.findOne(userGroupModel.getId());
			if (objUserGroupModel != null) {
				if (userGroupModel.getLastUpdated() == null)
					userGroupModel.setLastUpdated(new Date());
				 
				for (Iterator iterator = userGroupModel.getListApplianceIds().iterator(); iterator.hasNext();) {
					String applianceId = (String) iterator.next();
					designationApplianceRepository.deleteApplianceFromDesignationAppliance(Long.parseLong(applianceId));	
				}
			
				userGroupRepository.save(userGroupModel);
				UserGroupModel defaultuserGroup=new UserGroupModel();
				  defaultuserGroup=getGroupDetail(env.getProperty("user.defaultusergroup"));	
				 
				  if(defaultuserGroup!=null &&  defaultuserGroup.getId()!=null && defaulGroupApplianceIds!=null ) {
						for (Iterator<String> iterator = defaulGroupApplianceIds.iterator(); iterator.hasNext();) {
							String applianceId = (String) iterator.next();
							designationApplianceRepository.deleteApplianceFromDesignationAppliance(Long.parseLong(applianceId));	
						}
					if(defaulGroupApplianceIds!=null && defaulGroupApplianceIds.size()>0){
					listDefaultApplianceIds.addAll(defaulGroupApplianceIds);
					}
					if(listDefaultApplianceIds!=null && listDefaultApplianceIds.size()>0){
					defaultuserGroup.setListApplianceIds(listDefaultApplianceIds);
					defaultuserGroup.setListDesignationApplianceModel(new ArrayList<DesignationApplianceModel>());		
					defaultuserGroup=userGroupRepository.save(defaultuserGroup);
					}
				}
				responseModel.setResponseCode("200");
				responseModel.setResponseMessage(env.getProperty("userGroupModification.success"));
				String loggedInUser = userAttributes.getlogInUserName(); 
				recentActivityServiceImpl.createRecentActivity(loggedInUser,"Group "+objUserGroupModel.getRoleName()+" modified by "+loggedInUser,CaviumConstant.USER_MANAGEMENT);
			} else {
				responseModel.setResponseCode("500");
				responseModel.setResponseMessage("userGroup Doesnot exist");
			}
		} else {
			responseModel.setResponseCode("500");
			responseModel.setResponseMessage("userGroup Id is blank");
		}
		return responseModel;
	}

	/*
	 * getAllAppliancesDetails method is used for fetch All appliances Details.
	 * 
	 * @return listApplianceDetailModel - List of ApplianceDetailModel Object.
	 * 
	 */
	@Override
	@Transactional
	public List<ApplianceDetailModel> getAllAppliancesDetails() {
		List<ApplianceDetailModel> listApplianceDetailModel = new ArrayList<ApplianceDetailModel>();
		try {
			listApplianceDetailModel = applianceRepository.findAll();
		} catch (Exception e) {
			logger.error("Error occured due to db error ::" + e.getMessage());
		}
		return listApplianceDetailModel;
	}

	/*
	 * getGroupDetail method is used for fetch GroupDetail based on GroupName.
	 * 
	 * @return UserGroupModel - UserGroupModel Object.
	 * 
	 */

	public UserGroupModel getGroupDetail(String groupName) {
		UserGroupModel objUserGroupModel = new UserGroupModel();
		try {
			List<UserGroupModel> listUserGroupModel = userGroupRepository.findGroupDetailsForGroupName(groupName);
			if (listUserGroupModel != null && listUserGroupModel.size() > 0)
				objUserGroupModel = listUserGroupModel.get(0);
		} catch (Exception e) {
			logger.error("Error occured due to db error ::" + e.getMessage());
		}
		return objUserGroupModel;
	}

	/*
	 * createACL method is used for creating ACL.
	 * 
	 * @param userACLDetailsModel - Object of UserACLDetailsModel
	 * 
	 * @return CaviumResponseModel - object of CaviumResponseModel
	 * 
	 */
	@Override
	public CaviumResponseModel createACL(UserACLDetailsModel userACLDetailsModel) {
		CaviumResponseModel responseModel = getCaviumResponseModel();
		try {
			List<UserACLDetailsModel> listUserACLDetailsModel = userAclRepository
					.findACLDetailsForACLName(userACLDetailsModel.getAclName());
			if (listUserACLDetailsModel != null && listUserACLDetailsModel.size() == 0) {
				if (userACLDetailsModel.getLastUpdated() == null)
					userACLDetailsModel.setLastUpdated(new Date());
				userAclRepository.save(userACLDetailsModel);
				responseModel.setResponseCode("200");
				responseModel.setResponseMessage(env.getProperty("aclCreation.success"));
				logger.info(userACLDetailsModel.toString() + " Created Sucessfully");
			} else {
				responseModel.setResponseCode("409");
				responseModel.setResponseMessage("UserACL already Exists");
			}
		} catch (Exception e) {
			logger.error("Error occured due to db error ::" + e.getMessage());
			responseModel.setResponseCode("500");
			responseModel.setResponseMessage(env.getProperty("applianceCreation.failureDB"));
		}
		return responseModel;
	}

	/*
	 * getACLDetails method is used for fetch the ACL details. if AclName field is
	 * blank then it will fetch all the ACL details. if AclName field is not blank
	 * then it will fetch ACL deatils based in AclName
	 * 
	 * @param userACLDetailsModel - Object of UserACLDetailsModel
	 * 
	 * @return listUserACLDetailsModel - List of UserACLDetailsModel Object
	 * 
	 */
	@Override
	@Transactional
	public List<UserACLDetailsModel> getACLDetails(UserACLDetailsModel userACLDetailsModel) {
		List<UserACLDetailsModel> listUserACLDetailsModel = new ArrayList<UserACLDetailsModel>();
		try {
			if (userACLDetailsModel != null) {
				if (userACLDetailsModel.getAclName() == null) {
					userACLDetailsModel.setAclName("");
				}
				listUserACLDetailsModel = userAclRepository.listACLDetails(userACLDetailsModel.getAclName());
			}
		} catch (Exception e) {
			logger.error("Error occured due to db error ::" + e.getMessage());
		}
		return listUserACLDetailsModel;
	}

	/*
	 * getACLDetailById method is used for fetch the ACL details based on the ACL
	 * ID.
	 * 
	 * @param aclId
	 * 
	 * @return objUserACLDetailsModel - UserACLDetailsModel Object
	 * 
	 */
	@Override
	@Transactional
	public UserACLDetailsModel getACLDetailById(String aclId) {
		UserACLDetailsModel objUserACLDetailsModel = new UserACLDetailsModel();
		try {
			if (org.apache.commons.lang3.StringUtils.isNotEmpty(aclId)
					&& org.apache.commons.lang.StringUtils.isNotEmpty(aclId)) {
				objUserACLDetailsModel = userAclRepository.findOne(Long.parseLong(aclId));
			}
		} catch (Exception e) {
			logger.error("Error is coming in getting  ACL Details :: " + e.getMessage());
		}
		return objUserACLDetailsModel;
	}

	/*
	 * getGroupDetailById method is used for fetch the group details based on the
	 * group Id.
	 * 
	 * @param groupId
	 * 
	 * @return objUserGroupModel - UserGroupModel Object
	 * 
	 */
	@Override
	@Transactional
	public UserGroupModel getGroupDetailById(String groupId) {
		UserGroupModel objUserGroupModel = new UserGroupModel();
		try {
			if (org.apache.commons.lang3.StringUtils.isNotEmpty(groupId)
					&& org.apache.commons.lang.StringUtils.isNumeric(groupId)) {
				objUserGroupModel = userGroupRepository.findOne(Long.parseLong(groupId));
			}
		} catch (Exception e) {
			logger.error("Error is coming in Modify Group Details :: " + e.getMessage());
		}
		return objUserGroupModel;
	}

	/*
	 * modifyACL method is used for update the existing ACL details.
	 * 
	 * @param userAclDetailModel - UserACLDetailsModel Object
	 * 
	 * @return CaviumResponseModel - CaviumResponseModel Object
	 * 
	 */
	@Override
	@Transactional(rollbackOn = Exception.class)
	public CaviumResponseModel modifyACL(UserACLDetailsModel userAclDetailModel) throws Exception {
		CaviumResponseModel responseModel = getCaviumResponseModel();
		if (!Objects.isNull(userAclDetailModel.getId())) {
			UserACLDetailsModel objUserACLDetailsModel = userAclRepository.findOne(userAclDetailModel.getId());
			if (objUserACLDetailsModel != null) {
				if (userAclDetailModel.getLastUpdated() == null)
					userAclDetailModel.setLastUpdated(new Date());
				userAclRepository.save(userAclDetailModel);
				responseModel.setResponseCode("200");
				responseModel.setResponseMessage(env.getProperty("aclModification.success"));
			} else {
				responseModel.setResponseCode("500");
				responseModel.setResponseMessage("ACL Id doesnot exist in DB");
			}
		} else {
			responseModel.setResponseCode("500");
			responseModel.setResponseMessage("ACL Id is blank");
		}

		/*
		 * catch (Exception e) { logger.error("Error is coming in Modify ACL :: "+
		 * e.getMessage()); responseModel.setResponseCode("500");
		 * responseModel.setResponseMessage(env.getProperty("aclModification.failure"));
		 * 
		 * }
		 */
		return responseModel;
	}

	/*
	 * modifyUser method is used for update the existing user details.
	 * 
	 * @param userModel - UserDetailModel Object
	 * 
	 * @return responseModel - CaviumResponseModel Object
	 * 
	 */
	@Override
	@Transactional
	public CaviumResponseModel modifyUser(UserDetailModel userModel) {
		CaviumResponseModel responseModel = getCaviumResponseModel();
		String loggedInUser = userAttributes.getlogInUserName(); 
		try {
			boolean modifyUser=true;
			TemporaryPassword temporaryPassword = null;
			Status status = null;
			UserGroupModel objUserGroupModel = null;
			UserACLDetailsModel objUserACLDetailsModel = null;	
			
			if (org.apache.commons.lang3.StringUtils.isNotEmpty(userModel.getUserGroupId())) {
				if(org.apache.commons.lang.StringUtils.isNumeric(userModel.getUserGroupId())) {
					objUserGroupModel = userGroupRepository.findOne(Long.parseLong(userModel.getUserGroupId()));
					if(	objUserGroupModel == null) {
						responseModel.setResponseCode("409");
						responseModel.setResponseMessage("GroupId doesnot exist in DB ");	
						modifyUser=false;
					}			
				}else {
					responseModel.setResponseCode("500");
					responseModel.setResponseMessage("GroupId is not valid.It should be Numeric");
					modifyUser=false;
				}
			}
			if (org.apache.commons.lang.StringUtils.isNotEmpty(userModel.getUserACLId())) {
				if(org.apache.commons.lang.StringUtils.isNumeric(userModel.getUserACLId())){
					objUserACLDetailsModel = userAclRepository.findOne(Long.parseLong(userModel.getUserACLId()));
					if(objUserACLDetailsModel == null) {
						responseModel.setResponseCode("409");
						responseModel.setResponseMessage("ACLId  doesnot exist in DB ");
						modifyUser=false;	
					}
					else{
						 if(userModel.getUserGroupId()!=null){
							 Long groupId=Long.parseLong(userModel.getUserGroupId());
						if(objUserACLDetailsModel.getAclName().trim().equalsIgnoreCase("SecondaryUser")){
							 UserDetailModel userDetailModel=getUserDetails(userModel.getUserName());
							 String aclName=userDetailModel.getObjUserACLDetailsModel().getAclName();
								if(!aclName.equals(objUserACLDetailsModel.getAclName())){
						 int numberOfgroupAdminUsers=userRepository.getSecondaryUserForUserGroup(groupId);	
						if(numberOfgroupAdminUsers>0){
									responseModel.setResponseCode("409");
									responseModel.setResponseMessage("Secondary User already exist.");	
									modifyUser=false;	
								}
						}
						}
						 if(objUserACLDetailsModel.getAclName().trim().equalsIgnoreCase("GroupAdmin")){
							 UserDetailModel userDetailModel=getUserDetails(userModel.getUserName());
							 String aclName=userDetailModel.getObjUserACLDetailsModel().getAclName();
								if(!aclName.equals(objUserACLDetailsModel.getAclName())){
								int numberOfgroupAdminUsers=userRepository.getGroupAdimUserForUserGroup(groupId);	
								if(numberOfgroupAdminUsers>0){
									responseModel.setResponseCode("409");
									responseModel.setResponseMessage("Group Admin already exist.");	
									modifyUser=false;	
								}
						}
						 }
						 }
					}
				}else {
					responseModel.setResponseCode("500");
					responseModel.setResponseMessage("AclId is not valid.It should be Numeric");
					modifyUser=false;	
				}	
			}
					if (modifyUser) {
						String firstName = userModel.getFirstName();
						String lastName = userModel.getLastName();
						String emailId = userModel.getEmailId();
						String message = userModel.getMessage();
						String userName = userModel.getUserName();
						String phoneNumber = userModel.getPhoneNumber();
						if (StringUtils.isEmpty(userModel.getTemporaryPassword())) {
							temporaryPassword = TemporaryPassword.Y;
						} else {
							temporaryPassword = userModel.getTemporaryPassword();
						}
						if (StringUtils.isEmpty(userModel.getStatus())) {
							status = Status.ACTIVE;
						} else {
							status = userModel.getStatus();
						}
						int result = userRepository.updateUserDetails(firstName, lastName, emailId, objUserGroupModel,
								phoneNumber, status, message, temporaryPassword, userName, objUserACLDetailsModel);
						if (result == 1) {
							responseModel.setResponseCode("200");
							responseModel.setResponseMessage(env.getProperty("userModification.success"));
						
							recentActivityServiceImpl.createRecentActivity(loggedInUser,"User "+userModel.getFirstName()+" modified by "+loggedInUser,CaviumConstant.USER_MANAGEMENT);
						}
						if (result == 0) {
							responseModel.setResponseCode("500");
							responseModel.setResponseMessage("UserId doesnot exist in DB");
						}
					}  
		} catch (Exception e) {
			logger.error("Error is coming in Modify User :: " + e.getMessage());
			responseModel.setResponseCode("500");
			responseModel.setResponseMessage(env.getProperty("userModification.failure"));
			alertsService.createAlert(loggedInUser,"Error is coming while modify existing user "+userModel.getUserName()+" by "+loggedInUser +"",CaviumConstant.USER_MANAGEMENT);
		}

		return responseModel;
	}

	/*
	 * deleteACL method is used for delete the ACL detail.
	 * 
	 * @param aclId
	 * 
	 * @return result
	 * 
	 */
	@Override
	public CaviumResponseModel deleteACL(String aclId) {
		CaviumResponseModel responseModel = getCaviumResponseModel();
		try {
			if (org.apache.commons.lang.StringUtils.isNotEmpty(aclId)
					&& org.apache.commons.lang.StringUtils.isNumeric(aclId)) {
				userAclRepository.delete(Long.parseLong(aclId));
				responseModel.setResponseCode("200");
				responseModel.setResponseMessage(env.getProperty("aclDelete.success"));
			} else {
				responseModel.setResponseCode("204");
				responseModel.setResponseMessage(env.getProperty("acl.id.notvalid"));
			}
		} catch (DataIntegrityViolationException exp) {
			logger.error("Error is coming in Delete ACL :: " + exp.getMessage());
			responseModel.setResponseCode("-230");
			responseModel.setResponseMessage("ACL id is associated with some User");
		} catch (EmptyResultDataAccessException exp) {
			logger.error("AclId doesnot exist in DB " + exp.getMessage());
			responseModel.setResponseCode("-230");
			responseModel.setResponseMessage("AclId doesnot exist");
		} catch (Exception exp) {
			logger.error("Error is coming in Delete ACL :: " + exp.getMessage());
			responseModel.setResponseCode("-230");
			responseModel.setResponseMessage(env.getProperty("aclDelete.failure") + "::" + aclId);
		}
		return responseModel;
	}

	/*
	 * forgotPassword method is used for update the existing password with temporary
	 * Password and mark TempPassword field to "Y".
	 * 
	 * @param userId, - String Variable
	 * 
	 * @param oldpassword - String Variable
	 * 
	 * @param newPassword - String Variable
	 * 
	 * @return boolean variable
	 * 
	 */
	@Override
	@Transactional
	public CaviumResponseModel  forgotPassword(String userid, String oldPassword, String newPassword) throws MailException,Exception{
		logger.info("Start of forgotPassword Method:");

		int pwchanged = 0;
		int tempPwdchanged = 0;
		UserDetailModel userDetail = null;
		Map<String, String> toAddress = new HashMap<String, String>();
		CaviumResponseModel responseModel = getCaviumResponseModel();		
			logger.info(" Forgot Password for the user:" + userid);
			userDetail = userRepository.getOne(userid);
			if (userDetail != null && userDetail.getUserName()!=null) {
				String databasePassword = userDetail.getPassword();
				if (!passwordEncoder.matches(newPassword, databasePassword) && StringUtils.isEmpty(oldPassword)) {
					pwchanged = userRepository.updatePassword(passwordEncoder.encode(String.valueOf(newPassword)),
							userid);
					if (pwchanged == 1)
						tempPwdchanged=	userRepository.updateTempPassword(TemporaryPassword.Y, userid);
					 if(tempPwdchanged==1){		
						updateLoginFailureCount(userid,0);
						toAddress.put(userid,userDetail.getEmailId());	
						mailutil.mailNotificationToUser(userid, toAddress, null,"/templates/forgotPassword.vm", "Forgot Password", newPassword,null);		
						responseModel.setResponseCode("200");
						String message=	messageSource.getMessage("forgotpassword.mail.success", 
								new Object[] {}, Locale.US);
						responseModel.setResponseMessage(message);					 
					}
				}
			}
			logger.info("End of forgotPassword Method:");
		 
	 	 
		return responseModel;
	}

	public List<DesignationApplianceModel> getDefaultGroupAppliances() {
		UserGroupModel defaultuserGroup=getGroupDetail(env.getProperty("user.defaultusergroup"));
		return	defaultuserGroup.getlistDesignationApplianceModel();
	}
	
	

	/***
	 * Method to find all logged-In user roles
	 */
	@Override
	public UserDetailModel findUserDeatils(String loggedInUser) {
		// TODO Auto-generated method stub
		UserDetailModel user=new UserDetailModel();
		try {
			user=userRepository.findOne(loggedInUser);
		} catch (Exception e) {
			logger.info("Error occured during findUserRoles");
			// TODO: handle exception
		}
		return user;
	}
	
	/***
	 * Method to find all logged-In user roles
	 */
	@Override
	public int updateLoginFailureCount(String userId,int logInfailureCount) {
		int	loginFailureCount=0;
		try {
			UserDetailModel userDetails = userRepository.findOne(userId);
			if((userDetails!=null && !userDetails.getObjUserACLDetailsModel().getAclName().equalsIgnoreCase("SuperAdmin"))){
			if(logInfailureCount!=0){
				 logInfailureCount=userRepository.getLoginFailureCount(userId);
					logInfailureCount=logInfailureCount+1;
			 } 
		Long failureCount=Long.parseLong(String.valueOf(logInfailureCount));
		 int count=userRepository.updateLoginFailureCount(userId,failureCount);
	 	loginFailureCount= userRepository.getNumberofLogInFailureCount(userId);
			}
		}catch (Exception e) {
			logger.info("Error occured during updateLoginFailureCount method of UserServiceImpl class "+e.getMessage());
			// TODO: handle exception
		}	
		return loginFailureCount;
	}
	
	
	public List<UserDetailModel> listUsersOnBasisOfCreatedBy(String loggedInUser){
		List<UserDetailModel> listAllUsers = new ArrayList<UserDetailModel>();
		
		listAllUsers=userRepository.getListUsersOnBasisOfCreatedBy(loggedInUser);
		
		return listAllUsers;
	}
}