package com.cavium.service.alerts;



import java.util.List;

import com.cavium.model.alerts.Alerts;


public interface AlertsService {
	
	/**
	 * Create recent activity
	 * @return
	 */
	public void createAlert(String loggedInUser, String message,String moduleName);
	/**
	 * Create recent activity
	 * @return
	 */
	public void createAlert(String loggedInUser, String message,String applianceName,long applianceId,String moduleName);
	
	/**
	 * Get recent activity
	 * @return
	 */
	public List<Alerts> getAlerts(String groupId,String moduleName);

}
