package com.cavium.mail;

import java.io.StringWriter;
import java.util.Iterator;
import java.util.Map;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import org.apache.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.mail.MailException;
import org.springframework.mail.MailPreparationException;
import org.springframework.mail.MailSendException;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

@Component
public class MailService implements MailserviceInf {
	@Autowired
	private JavaMailSenderImpl javaMailSender;
	@Autowired
	private VelocityEngine velocityEngine;
	
	// get Property Value from Property File
		@Autowired
		private Environment env;

	private Logger logger = Logger.getLogger(this.getClass());

	// private HashMap<String, Object> exchangeDetails = null;

	public void sendMail(String senderName, String senderAddress, Map<String, String> toAddresses,
			Map<String, String> ccAddresses, Map<String, String> bccAddresses, String subject, VelocityContext context,
			String template) throws MailSendException {

		try {
			javaMailSender.setUsername(env.getProperty("smtp.username"));
			javaMailSender.setPassword(env.getProperty("smtp.password"));
		//	logger.info("............smtp.username........ ::" +env.getProperty("smtp.username"));
			//.info("............smtp.password........ ::" +env.getProperty("smtp.password"));
			MimeMessage message = javaMailSender.createMimeMessage();
			 

			// create the message using the specified template
			MimeMessageHelper helper;
			try {
				helper = new MimeMessageHelper(message, true, "UTF-8");
			} catch (MessagingException exception) {
				throw new MailPreparationException("Couble not able to create a MIME message", exception);
			}

			logger.info("Sender Name : " + senderName);
			logger.info("Sender Name : " + senderAddress);

			// add the 'from' and the sender to the message
			helper.setFrom(senderAddress, senderName);
			 

			// add the 'cc'
			if (ccAddresses != null && !ccAddresses.isEmpty()) {
				Iterator<String> itr = ccAddresses.keySet().iterator();
				while (itr.hasNext()) {
					String name = (String) itr.next();
					String recipient = (String) ccAddresses.get(name);
					helper.addCc(recipient, name);
				}
			}

			// add the 'bcc'
			if (bccAddresses != null && !bccAddresses.isEmpty()) {
				Iterator<String> itr = bccAddresses.keySet().iterator();
				while (itr.hasNext()) {
					String name = (String) itr.next();
					String recipient = (String) bccAddresses.get(name);
					helper.addBcc(recipient, name);
				}
			}

			// add the 'to'
			if (toAddresses != null && !toAddresses.isEmpty()) {
				Iterator<String> itr = toAddresses.keySet().iterator();
				while (itr.hasNext()) {
					String name = (String) itr.next();
					String recipient = (String) toAddresses.get(name);
					helper.addTo(recipient, name);
				}
			}

			// Generate the mail in text format and store it in writer
			StringWriter writer = new StringWriter();

			// Generate the mail in html format and store it in writer
			StringWriter htmlString = new StringWriter();

			velocityEngine.mergeTemplate(template, "UTF-8", context, writer);
			velocityEngine.mergeTemplate(template, "UTF-8", context, htmlString);
			writer.close();
			htmlString.close();
			logger.info("html message ;" + htmlString.toString());
			logger.info("Text message ;" + writer.toString());

			// Set the mail text in the supported format (html/text)
			helper.setText(writer.toString(), htmlString.toString());
			helper.setSubject(subject);

			javaMailSender.send(message);
			logger.info("Mail Sent...");
		} catch (Exception exception) {
			logger.error("Error coming while sending");
			throw new MailSendException("Could not send mail", exception);

		}
	}

 

	/**
	 * @param velocityEngine
	 *            the velocityEngine to set
	 */
	public final void setVelocityEngine(VelocityEngine velocityEngine) {
		this.velocityEngine = velocityEngine;
	}

	 

	/**
	 * @return the velocityEngine
	 */
	public final VelocityEngine getVelocityEngine() {
		return velocityEngine;
	}

}
