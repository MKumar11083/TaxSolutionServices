package com.cavium.repository.recentactivity;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cavium.model.recentactivity.InProgressActivity;
@Repository
public interface InProgressActivityRepository extends JpaRepository<InProgressActivity, Long>{
	
	@Modifying
	@Query("update InProgressActivity inpa set inpa.status=:status where inpa.createdBy=:createdBy and inpa.jobId=:jobId")
	public InProgressActivity updateInProgressActivity(@Param("status") String status,@Param("createdBy") String createdBy,@Param("jobId") Integer jobId);
	
	@Query("select inpa from InProgressActivity inpa where inpa.createdBy=:createdBy and inpa.moduleName=:moduleName")
	public List<InProgressActivity> getListInProgressActivity(@Param("createdBy") String createdBy,@Param("moduleName") String moduleName);
	
	@Transactional
	@Modifying
  	@Query(value="delete from inprogress_activity where status != 'In-Progress'",nativeQuery=true)
  	public void deleteInProgressActivityByStatus();
	
	
  	@Query(value="select count(*) from inprogress_activity where cluster_id=:clusterId and status = 'In-Progress'",nativeQuery=true)
  	public int allInprogressActivityCompletedorNot(@Param("clusterId") long clusterId);
  	
  	
	@Query("select inpa from InProgressActivity inpa where inpa.clusterId=:clusterId")
	public List<InProgressActivity> getListInProgressActivityForClusterId(@Param("clusterId") Long clusterId);
	
	@Transactional
	@Modifying
  	@Query(value="delete from inprogress_activity where cluster_id=:clusterId",nativeQuery=true)
  	public void deleteInProgressActivityByClusterId(@Param("clusterId") Long clusterId);
	
	@Query("select inpa from InProgressActivity inpa where inpa.status='In-Progress'")
	public List<InProgressActivity> getInProgressStatusList();
	
	@Transactional
    @Modifying
  	@Query(value="delete from inprogress_activity where appliance_id = :applianceId",nativeQuery=true)
  	public int deleteInProgressByApplianceId(@Param("applianceId") Long applianceId);
	
	@Modifying
	@Query("update InProgressActivity inpa set inpa.ipAddress=:newIpAddress where inpa.ipAddress=:ipAddress")
	public InProgressActivity updateApplianceIp(@Param("newIpAddress") String newIpAddress,@Param("ipAddress") String ipAddress);
}
