package com.cavium.repository.user;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cavium.model.partition.PartitionData;
import com.cavium.model.user.UserGroupModel;

@Repository
public interface UserGroupRepository
  extends JpaRepository<UserGroupModel, Long>
{
  @Query("SELECT objUserGroupModel FROM UserGroupModel objUserGroupModel WHERE objUserGroupModel.roleName =:groupName")
  public List<UserGroupModel> findGroupDetailsForGroupName(@Param("groupName") String groupName);
  
  @Query("SELECT objUserGroupModel FROM UserGroupModel objUserGroupModel  WHERE  objUserGroupModel.roleName LIKE CONCAT('%', :roleName,'%') and objUserGroupModel.roleName!='DefaultUserGroup' and username like :createdBy group by objUserGroupModel.id")
  public List<UserGroupModel> listGroupDetails(@Param("roleName") String roleName,@Param("createdBy") String createdBy);
  
  @Query("SELECT objUserGroupModel FROM UserGroupModel objUserGroupModel WHERE objUserGroupModel.roleName !='DeletedUserGroup'")
  public List<UserGroupModel> findAll();
  
  @Query(value="select descr from  designation where id=:groupId" ,nativeQuery=true)
  public String getGroupName(@Param("groupId") Long groupId);
  
  @Query("SELECT objUserGroupModel FROM UserGroupModel objUserGroupModel WHERE objUserGroupModel.username =:username")
  public List<UserGroupModel> findGroupDetailsForUserId(@Param("username") String username);
   
}
