package com.cavium.repository.partition;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cavium.model.partition.PartitionDetailModel;
import com.cavium.model.partition.PartitionETH;
@Repository
public interface PartitionETHRepository extends JpaRepository<PartitionETH, Long> {
	
	@Query(value=" select * from partition_interface_general_eth where partition_id=:partitionId",nativeQuery=true)
	public List<PartitionETH> getPartitionETHList(@Param("partitionId") String partitionId);
	
	@Transactional
	@Modifying
  	@Query(value="DELETE FROM partition_interface_general_eth where partition_id = :partitionId",nativeQuery=true)
  	public int deletePartitionETH(@Param("partitionId") Long partitionId);

	@Transactional
	@Modifying
  	@Query(value="update partition_interface_general_eth  set  ip_address=:ipAddress where partition_id = :partitionId",nativeQuery=true)
  	public int udpateEth01IpAddress(@Param("ipAddress") String ipAddress,@Param("partitionId") Long partitionId);
}
