package com.cavium.repository.user;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cavium.model.user.DesignationApplianceModel;

@Repository
public interface DesignationApplianceRepository extends JpaRepository<DesignationApplianceModel, String>{
	
	@Modifying
	@Query("delete from DesignationApplianceModel da where da.objApplianceDetailModel.applianceId = :applianceId")
	public int deleteApplianceFromDesignationAppliance(@Param("applianceId") long applianceId);
	
	
@Query(value="select design_id,count(*) from  designation_appliance group by design_id" ,nativeQuery=true)
	public List<Object[]> numberOfAppliancesforEachGroup();
	
 
}
