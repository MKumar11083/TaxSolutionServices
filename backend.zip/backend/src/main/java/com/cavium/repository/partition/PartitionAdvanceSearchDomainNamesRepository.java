package com.cavium.repository.partition;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cavium.model.partition.PartitionAdvanceSearchDomainNames;
import com.cavium.model.partition.PartitionDetailModel;
@Repository
public interface PartitionAdvanceSearchDomainNamesRepository extends JpaRepository<PartitionAdvanceSearchDomainNames, Long> {
	@Query(value=" select * from partition_interface_advance_serach_domain_names where partition_id=:partitionId",nativeQuery=true)
	public List<PartitionAdvanceSearchDomainNames> getDomainNamesList(@Param("partitionId") String partitionId);
	
	@Transactional
	@Modifying
  	@Query(value="DELETE FROM partition_interface_advance_serach_domain_names where partition_id = :partitionId",nativeQuery=true)
  	public int deletePartitionAdvanceSearchDomainNames(@Param("partitionId") Long partitionId);
}
