package com.cavium.repository.cluster;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cavium.model.cluster.ClusterDetailModel;

 

@Repository
public interface ClusterRepository 
extends JpaRepository<ClusterDetailModel, Long>{

	
/*	@Query("select cluster from ClusterInfo cluster where cluster.clusterId = :clusterId" )
	public ClusterDetailModel getClusterById(@Param("clusterId") Long clusterId);
	
	@Query("select * from ClusterInfo ")
	public List<ClusterDetailModel> getAllListOfClusters();
	
	@Query(value="select  * from cluster_details a join designation_appliance d on "
			+ "d.appliance_id=a.appliance_id join user_details u on u.role=d.design_id where u.user_id= :userName", nativeQuery = true)
	public List<ClusterDetailModel> getListOfClusterByGroupId(@Param("userName") String userName);*/
	
	@Query(value="select  count(*) from cluster_details  where cluster_name=:clusterName and group_id=:groupId",nativeQuery=true)
	public  int clusterNameExistorNotinGroup(@Param("clusterName") String clusterName,@Param("groupId") Long groupId);
	
	
	
	 @Query("SELECT clusterDetailModel FROM ClusterDetailModel clusterDetailModel  WHERE  clusterDetailModel.groupId=:groupId")
	  public List<ClusterDetailModel> getListOfClusterByGroupId(@Param("groupId") Long groupId);
	 
	 @Query(value="select MAX(cluster_version) FROM cluster_details where cluster_id=:clusterId",nativeQuery=true)
	  public Integer getmaxCluterVersionNumber(@Param("clusterId") Long clusterId);
	 
	 @Transactional
		@Modifying
		@Query(value="update cluster_details set cluster_version=:clusterVersion where cluster_id=:clusterId",nativeQuery=true)
		public int updateClusterVersionNumber(@Param("clusterVersion") Long clusterVersion,@Param("clusterId") Long clusterId);
	 
	 @Transactional
		@Modifying
		@Query(value="update cluster_details set last_operation_status=:lastOperationStatus, last_operation_performed=:lastOperationPerformed, error_message=:errorMessage where cluster_id=:clusterId",nativeQuery=true)
		public int updateClusterDetails(@Param("lastOperationStatus") String lastOperationStatus,@Param("lastOperationPerformed") String lastOperationPerformed,@Param("errorMessage") String errorMessage,@Param("clusterId") Long clusterId);
	 
 
	  
}
