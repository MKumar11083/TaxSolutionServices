package com.cavium.repository.partition;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cavium.model.partition.PartitionData;
import com.cavium.model.partition.PartitionDetailModel;
@Repository
public interface PartitionDataRepository extends JpaRepository<PartitionData, Long>{
	@Query(value=" select * from partition_data where partition_id=:partitionId",nativeQuery=true)
	public PartitionData getPartitionData(@Param("partitionId") String partitionId);
	
	@Transactional
	@Modifying
  	@Query(value="DELETE FROM partition_data  where partition_id = :partitionId",nativeQuery=true)
  	public int deletePartitionData(@Param("partitionId") Long partitionId);

	@Transactional
	@Modifying
  	@Query(value="update partition_data  set  node_id=:nodeId where partition_id = :partitionId",nativeQuery=true)
  	public int updateNodeIdforPartitionId(@Param("nodeId") String nodeId,@Param("partitionId") Long partitionId);
}
