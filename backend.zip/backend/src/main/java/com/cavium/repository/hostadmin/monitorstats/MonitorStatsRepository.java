package com.cavium.repository.hostadmin.monitorstats;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cavium.model.hostadminvm.monitorstats.MonitorStats;
 


@Repository
public interface MonitorStatsRepository  extends JpaRepository<MonitorStats, Long> {
	
		@Query(value="select * from monitor_stats_details monitorstats where monitorstats.api_name= :apiName && monitorstats.appliance_ip=:applianceIp order by monitorstats.created_date desc",nativeQuery=true)
	   public List<MonitorStats> getMonistorStats(@Param("apiName") String apiName,@Param("applianceIp") String applianceIp);
		
			@Query(value="select * from monitor_stats_details monitorstats where monitorstats.appliance_ip=:applianceIp",nativeQuery=true)
		   public List<MonitorStats> getListOfMonistorStatsByApplianceIp(@Param("applianceIp") String applianceIp);
	
	
	 
	
}
