package com.cavium.repository.alerts;


import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cavium.model.alerts.Alerts;

@Repository
public interface AlertsRepository  extends JpaRepository<Alerts, String> {
	
	
	@Query(value="select * from alerts alert where alert.user_groupid= :usergroupid && alert.module_Type= :moduleType order by alert.created_date desc",nativeQuery=true)
	public List<Alerts> getAlerts(@Param("usergroupid") String usergroupid,@Param("moduleType") String moduleType);
	
	    @Transactional
	    @Modifying
	  	@Query(value="delete from alerts where module_id = :applianceId",nativeQuery=true)
	  	public int deleteAlertsByApplianceId(@Param("applianceId") Long applianceId);
	    
	    @Query(value="select * from alerts alert where alert.user_groupid= :usergroupid order by alert.created_date desc",nativeQuery=true)
		public List<Alerts> getAlertsForDashboard(@Param("usergroupid") String usergroupid);
	
}
