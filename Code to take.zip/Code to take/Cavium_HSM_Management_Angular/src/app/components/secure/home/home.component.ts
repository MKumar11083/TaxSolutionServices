import { Component, OnInit } from '@angular/core';
import { ChartsModule, Color } from 'ng2-charts';
 import { AppliancemanagementService } from './../../../services/appliancemanagement.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  recentActivityList: any = [];
  alertDetails:any=[];
  constructor(private _applianceManagementService: AppliancemanagementService) { }

ngOnInit(){
  this._applianceManagementService.getAllSnapshotDetails().subscribe(
    res => {
      this.alertDetails = res.alerts;   //alert details
      this.recentActivityList=[];
      let colors = ["red", "green", "blue"];
      let count = 0;
      res.recentActivity.forEach(element => {
        let recentActivity = {};
        if (count == 3) {
          count = 0;
        }
        recentActivity['message'] = element.message;
         recentActivity['createdDate'] = element.createdDate;
        recentActivity['color'] = colors[count];
        this.recentActivityList.push(recentActivity);
        count++;
      });
     }
    )
}


public pieChartType:string = 'pie';
public chartOptions = {
  responsive: true,
  legend: {
    display: true,
    position: 'right',
    labels: {
      boxWidth: 10
    }
  }
};

//piechart 1
public pieChartData:number[] = [5,11,30,12,21,13];
public pieChartLabels:string[] = ['Usergroup_02', 'Usergroup_04', 'Usergroup_05','Usergroup_07','Usergroup_08','Usergroup_09'];
public mycolors: Array<Color> = [
  {
    backgroundColor: [
      'rgb(77,136,255)',
      'rgb(255,195,77)',
      'rgb(204,68,0)',
      'rgb(0,102,153)',
      'rgb(211,211,211)',
      'rgb(112,128,144)'],
    hoverBackgroundColor: ['rgb(77,136,255)', 'rgb(255,195,77)','rgb(204,68,0)','rgb(0,102,153)',
                           'rgb(211,211,211)','rgb(112,128,144)'],
  }
];

//piechart 2
public pieChartData2:number[] = [12,12,30,24,18,21,11];
public pieChartLabels2:string[] = ['App_01','App_02','App_06','App_08','App_11','App_12','App_13'];
public mycolors2: Array<Color> = [
  {
    backgroundColor: [
      'rgb(0,179,89)',
      'rgb(0,153,153)',
      'rgb(25,178,255)',
      'rgb(0,119,179)',
      'rgb(153,102,255)',
      'rgb(234,128,255)',
      'rgb(255,153,187)'
    ],
    hoverBackgroundColor: ['rgb(0,179,89)', 'rgb(0,153,153)','rgb(25,178,255)','rgb(0,119,179)',
                           'rgb(153,102,255)','rgb(234,128,255)','rgb(255,153,187)'],
  }
];

//piechart 3
public pieChartData3:number[] = [5,12,1];
public pieChartLabels3:string[] = ['Administrator','Group Administrators','Monitor Users'];
public mycolors3: Array<Color> = [
  {
    backgroundColor: [
      'rgb(255,51,51)',
      'rgb(0,204,204)',
      'rgb(255,195,77)',
    ],
    hoverBackgroundColor: ['rgb(255,51,51)', 'rgb(0,204,204)','rgb(255,195,77)'],
  }
];

// events
public chartClicked(e:any):void {
  console.log(e);
}

public chartHovered(e:any):void {
  console.log(e);
}
       
}

