import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplianceOperationsComponent } from './appliance-operations.component';

describe('ApplianceOperationsComponent', () => {
  let component: ApplianceOperationsComponent;
  let fixture: ComponentFixture<ApplianceOperationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApplianceOperationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplianceOperationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
