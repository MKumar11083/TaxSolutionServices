import { Component, OnInit ,ViewChild} from '@angular/core';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { AnonymousSubscription } from "rxjs/Subscription";
import { DataTableResource } from './../../data-table/index';
import { I18nService } from '../../../../services/common/i18n/i18n.service';
import { BreadcrumbService } from './../../../../services/common/breadcrumb.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { InitializeApplianceComponent} from './../../appliancemanagement/initialize-appliance/initialize-appliance.component';
import { ApplianceLoginComponent} from './../../appliancemanagement/appliance-login/appliance-login.component';
// import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { LoadingModule } from 'ngx-loading';
import { Router } from '@angular/router';
declare var $: any;
declare var bootbox: any;
declare var jQuery: any;
@Component({
  selector: 'app-list-appliance',
  templateUrl: './list-appliance.component.html',
  styleUrls: ['./list-appliance.component.css'],

})
export class ListApplianceComponent implements OnInit {
  @ViewChild('initializeAppliance')
  private initializeAppliance: InitializeApplianceComponent;

  @ViewChild('applianceLogin')
  private applianceLogin: ApplianceLoginComponent;
  title = "Appliance Details";
  username: string = '';
  password: string = '';
  private groupsList: string;
  private details: string;
  private getInfoMessage: any = [];
  show: boolean = false;
  show1: boolean = false;
  listofAppliances: AnonymousSubscription;
  appliancesList: any = [];
  private selectedCheckboxData: object[] = [];
  private selectedCheckboxDataReferesh: object[] = [];
  private selectedTotalCheckData: object[] = [];
  itemResource: any;
  displayErrors: any = [];
  showList: boolean = true;
  showContent: boolean = true;
  showListAppliance: boolean = true;
  showCompareAppliance: boolean = false;
  showBack: boolean = false;

  rebootUp: boolean = false;
  rebootdown: boolean = true;
  zeroiseUp: boolean = false;
  zeroisedown: boolean = true;
  firmwareUpgradeUp: boolean = false;
  firmwareUpgradedown: boolean = true;
  selectedAppliances: any = [];
  intializedown: boolean = true;
  intializeUp: boolean = false;
  form: FormGroup;
  formAdvanced: FormGroup;
  searchApplianceSubsc: AnonymousSubscription;
  valid: boolean = true;
  selectCheck: boolean = false;
  selectName: boolean = false;
  private AppName: string;
  loginForm: FormGroup;
  private unrebootApp: string = '';
  private rebootedApp: string = '';
  public loading = false; 
  private sendCheckData: object[] = [];
  constructor(private _applianceManagementService: AppliancemanagementService,
    private _I18nService: I18nService,
    private _formBuilder: FormBuilder,
    // private spinnerService: Ng4LoadingSpinnerService,
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _router :Router,
  ) { }

  ngOnInit() {
    debugger;
    this.createForm();
    this.createLoginForm();
    this.createInitializeForm();
    this.selectedAppliances = [];
    this.loadingListAppliances();
    if(sessionStorage.getItem("showList")=="true"){
      this.showList = true;
    }else{
      this.showList = false;
    }
  }
  loadingListAppliances() {
    this.selectedCheckboxData =[];
    this.selectedAppliances=[];
    console.log("loading list of appliances.....");
    this._applianceManagementService.getAllListAppliances().subscribe(
      res => {
        this.appliancesList = res;
        if (this.appliancesList.length > 0) {
          this.valid = false;
          document.getElementById("operationTab").style.pointerEvents = "auto";
        }
        else {
          document.getElementById("operationTab").style.pointerEvents = "none";
        }
      },
      error => {
        document.getElementById("operationTab").style.pointerEvents = "none";
        console.log(error);
      },
    );
  }
  over(ip: string) {
    for (var i = 0; i < this.appliancesList.length; i++) {
      if (this.appliancesList[i]["ipAddress"] == ip) {
        this.details = (this.appliancesList[i]);

      }
    }
  }
  clickGetAppliance(event, idName) {
    debugger;
    this.details = "";
    this.appliancesList.find
      (appliance => {
        if (appliance.applianceId == idName) {
          this.details = appliance;
        }
      })
  }

  toggle() {
    this.showList = false;
    sessionStorage.setItem("showList","false");
  }
  toggle1() {
    this.showList = true;
    sessionStorage.setItem("showList","true");
  }
  toggle3() {
    this.showContent = false;
  }
  toggle4() {
    this.showContent = true;
    this.showBack = true;
  }

  onErrorOperation(error) {
    console.log('OnError' + JSON.stringify(error));
    this.displayErrors = this._I18nService.getI18NMessagesForError(error, "", "");
    console.log('errorMessages -->' + JSON.stringify(this.displayErrors));
  }

  getApplianceCheckData(event, value) {
    debugger;
    if (event.target.checked) {
      event.currentTarget.style.visibility = "visible";

      this.selectCheck = true;
      for (var i = 0; i < this.appliancesList.length; i++) {
        if (this.appliancesList[i]["ipAddress"] == value) {
          this.selectedCheckboxData.push(this.appliancesList[i]);

        }
      }
      this.rebootUp = true;
      this.rebootdown = false;
      this.zeroiseUp = true;
      this.zeroisedown = false;
      this.firmwareUpgradeUp = true;
      this.firmwareUpgradedown = false;
      this.intializeUp = true;
      this.intializedown = false;
    }
    else {
      event.currentTarget.style.removeProperty('visibility');

      this.selectCheck = true;
      if (this.selectedCheckboxData.length == 1) {
        this.selectedCheckboxData.pop();
        this.rebootUp = false;
        this.rebootdown = true;
        this.zeroiseUp = false;
        this.zeroisedown = true;
        this.firmwareUpgradeUp = false;
        this.firmwareUpgradedown = true;
        this.intializeUp = false;
        this.intializedown = true;

      }
      else {
        for (var i = 0; i < this.selectedCheckboxData.length; i++) {

          if (this.selectedCheckboxData[i]["ipAddress"] == value) {

            let index = i;
            this.selectedCheckboxData.splice(index, 1);
          }
        }
        if (this.selectedCheckboxData.length == 0) {
          this.rebootUp = false;
          this.rebootdown = true;
          this.zeroiseUp = false;
          this.zeroisedown = true;
          this.firmwareUpgradeUp = false;
          this.firmwareUpgradedown = true;
          this.intializeUp = false;
          this.intializedown = true;
        }
        else {
          this.rebootUp = true;
          this.rebootdown = false;
          this.zeroiseUp = true;
          this.zeroisedown = false;
          this.firmwareUpgradeUp = true;
          this.firmwareUpgradedown = false;
          this.intializeUp = true;
          this.intializedown = false;
        }
      }

    }
    /* if(this.onPageApplianceSent.length!=null || this.localStorageApplianceSent.length!=null)

     this.applianceSent.push(this.getValidateRes1[i]);
     debugger;
     this.checkboxFlag=event;
     console.log(this.checkboxFlag);*/

  }
  getmsg = '';
  saveUserData() {
    debugger;
    //this.spinnerService.show();
    this.loading = true; 
    if (this.saveToDBData.length > 0) {
      for (var i = 0; i < this.saveToDBData.length; i++) {
        this.selectSendData.push(this.saveToDBData[i]);
      }
    }
    if (this.selectSendData.length > 0) {
      this._applianceManagementService.setRebootActivity(JSON.stringify(this.selectSendData)).subscribe(
        res => {
          this.getInfoMessage = res;

          if (this.getInfoMessage.length > 0) {
            // this.spinnerService.hide(); 
            this.loading = false; 

            for (var i = 0; i < this.getInfoMessage.length; i++) {


              this.getmsg = this.getmsg + " " + "<b>" + this.getInfoMessage[i]["applianceName"] + "</b> :-- " + this.getInfoMessage[i]["message"] + "<br>";
              /* for(var i=0;i<this.unrebootApp.length;i++){
   
                 var unrebootedMessage=""+this.unrebootApp[i];
   
                          }
                          for(var i=0;i<this.rebootedApp.length;i++){
   
                           var rebootedMessage=""+this.rebootedApp[i];
                           
                                    }*/


            }
          }
          this.selectSendData = [];
          this.saveToDBData = [];

          let message = this.getmsg;
          this.getmsg = '';
          bootbox.dialog({
            message: message,
            buttons: {

              ok: {
                label: "Ok",
                className: 'btn btn-primary btn-flat',
                callback: () => this.loadingListAppliances()
              }
            }
          });

        },
        error => {
          console.log(error);
        },

      )

      this.username = '';
      this.password = '';
    }
    else {
      let message = this.getmsg;
      bootbox.dialog({
        message: message,
        buttons: {

          ok: {
            label: "Ok",
            className: 'btn btn-primary btn-flat',

          }
        }
      });

    }

  };
  saveUserData1() {
    debugger;
    this.loading = true; 
    if (this.saveToDBData.length > 0) {
      for (var i = 0; i < this.saveToDBData.length; i++) {

        this.selectSendData.push(this.saveToDBData[i]);
      }

    }
    if (this.selectSendData.length > 0) {
      debugger;


      this._applianceManagementService.firmwareUpgrade(JSON.stringify(this.selectSendData)).subscribe(
        res => {
          this.getInfoMessage = res;
          if (this.getInfoMessage.length > 0) {
            this.loading =false; 
            for (var i = 0; i < this.getInfoMessage.length; i++) {
              this.getmsg = this.getmsg + " " + "<b>" + this.getInfoMessage[i]["applianceName"] + "</b> :-- " + this.getInfoMessage[i]["message"] + "<br>";

            }
          }
          this.selectSendData = [];
          this.saveToDBData = [];

          let message = this.getmsg;
          this.getmsg = '';
          bootbox.dialog({
            message: message,
            buttons: {

              ok: {
                label: "Ok",
                className: 'btn btn-primary btn-flat',
                callback: () => this.loadingListAppliances()
              }
            }
          });

        },
        error => {
          console.log(error);
        },

      )


      this.username = '';
      this.password = '';
    }
    else {
      let message = "Sorry! No appliance selected to reboot."
      bootbox.dialog({
        message: message,
        buttons: {

          ok: {
            label: "Ok",
            className: 'btn btn-primary btn-flat',

          }
        }
      });

    }

  };
  saveUserData2() {
    debugger;
    //this.spinnerService.show();
    this.loading =true; 
    if (this.saveToDBData.length > 0) {
      for (var i = 0; i < this.saveToDBData.length; i++) {

        this.selectSendData.push(this.saveToDBData[i]);
      }

    }
    if (this.selectSendData.length > 0) {
      debugger;


      this._applianceManagementService.setZeroise(JSON.stringify(this.selectSendData)).subscribe(
        res => {
          this.getInfoMessage = res;
          if (this.getInfoMessage.length > 0) {
            this.loading =false; 
            //this.spinnerService.hide(); 

            for (var i = 0; i < this.getInfoMessage.length; i++) {

              this.getmsg = this.getmsg + " " + "<b>" + this.getInfoMessage[i]["applianceName"] + "</b> :-- " + this.getInfoMessage[i]["message"] + "<br>";
              /* for(var i=0;i<this.unrebootApp.length;i++){
   
                 var unrebootedMessage=""+this.unrebootApp[i];
   
                          }
                          for(var i=0;i<this.rebootedApp.length;i++){
   
                           var rebootedMessage=""+this.rebootedApp[i];
                           
                                    }*/
            }
          }
          this.selectSendData = [];
          this.saveToDBData = [];
          let message = this.getmsg;
          this.getmsg = '';
          bootbox.dialog({
            message: message,
            buttons: {

              ok: {
                label: "Ok",
                className: 'btn btn-primary btn-flat',
                callback: () => this.loadingListAppliances()
              }
            }
          });

        },
        error => {
          console.log(error);
        },

      )

      this.username = '';
      this.password = '';
    }
    else {
      let message = "Sorry! No appliance selected to reboot."
      bootbox.dialog({
        message: message,
        buttons: {

          ok: {
            label: "Ok",
            className: 'btn btn-primary btn-flat',

          }
        }
      });

    }

  };

  compareAppliance() {
    this.showListAppliance = false;
    this.showCompareAppliance = true;
    this.checkValidationsForAppliances();
  }
errorMessage : string;
  checkValidationsForAppliances() {
    if (this.selectedAppliances.length <= 1) {
      //this.showListAppliance = true;
      this.showCompareAppliance = false;
      $("#displayalert").modal("show");
      
      this.errorMessage = "Please select atleast two appliance to compare";
      // bootbox.dialog({
      //   message: message,
      //   buttons: {
      //     cancel: {
      //       label: "Cancel",
      //       className: 'btn btn-primary btn-flat'
      //     }
      //   }
      // });
    } else if (this.selectedAppliances.length > 6) {
      $("#displayalert").modal("show");
      //this.showListAppliance = true;
      this.showCompareAppliance = false;
      this.errorMessage  = "Maximum appliances to compare is 6";
      // bootbox.dialog({
      //   message: message,
      //   buttons: {
      //     cancel: {
      //       label: "Cancel",
      //       className: 'btn btn-primary btn-flat'
      //     }
      //   }
      // });
    }
  }

  closeModal(){
    $("#displayalert").modal("hide");
  }
  listAppliances = [];
  selectApplianceItems(event, applianceId: string) {
    debugger;
    if (event.target.checked) {
      event.currentTarget.style.visibility = "visible";
      // this.appliancesList.find
      //   (appliance => {
      //     if (appliance.applianceId == applianceId) {
      //       this.selectedAppliances.push(appliance);
      //     }
      //   })
      for (var i = 0; i < this.appliancesList.length; i++) {
        if (this.appliancesList[i].applianceId == applianceId) {
          this.selectedAppliances.push(this.appliancesList[i]);
          this.appliancesList[i]['checked']=true;
        }
        else if(!this.appliancesList[i]['checked']){
          this.appliancesList[i]['checked']=false;
        }
    }
    
    } else {
      // this.appliancesList.find
      //   (appliance => {
      //     if (appliance.applianceId == applianceId) {
      //       let index = this.selectedAppliances.indexOf(applianceId);
      //       this.selectedAppliances.splice(index);

      //     }
      //   })
      for (var i = 0; i < this.appliancesList.length; i++) {
        if (this.appliancesList[i].applianceId == applianceId) {
          let index = this.selectedAppliances.indexOf(applianceId);
          this.selectedAppliances.splice(index);
          this.appliancesList[i]['checked']=false;
        }
        else if(!this.appliancesList[i]['checked']){
          this.appliancesList[i]['checked']=false;
        }
    }
    }
  }

  navigateToCompareAppliance(){
    this.compareAppliance();
    if(this.showCompareAppliance){
      this._applianceManagementService.setSelectedAppliances(this.selectedAppliances);
      this._applianceManagementService.setAllAppliances(this.appliancesList);
      this._router.navigate(['/compareAppliances']);
    }else {
      return false;
    }
  }
  closeAppliance($event) {
    this.selectedAppliances = [];
    this.showCompareAppliance = false;
    this.showListAppliance = true;
  }

  createInitializeForm() {
    this.form = this._formBuilder.group({
      cryptoOffName: ['', Validators.required],
      cryptoOffPwd: ['', Validators.required],
      confirmPwd: ['', Validators.required],
      authLevel: ['', Validators.required],
      fipsState: ['', Validators.required],
      certAuthentication: [false],
      logFailureCount: [''],
      minPwdLength: [''],
      maxPwdLength: [''],
      hsmLabel: [''],
      hsmAuditLog: [false],
      saveToDB: [false],
      authServerAddress: [''],
      authServerPortNo: [''],
      authServerCert: ['']
    });
  }
  // create a form errors
  public formValidationFields = {
    "cryptoOffName": '',
    "cryptoOffPwd": '',
    "confirmPwd": '',
    "authLevel": '',
    "fipsState": '',
    "authServerAddress": '',
    "authServerPortNo": '',
    "authServerCert": '',
  }

  isFieldValid(field: string) {

    if (this.form.get(field).touched) {
      this.formValidationFields = this._fieldErrorDisplayService.validateField(this.form, field, this.formValidationFields, "initialize")
    }
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  // create form for advanced search.
  createForm() {
    this.formAdvanced = this._formBuilder.group({
      applianceName: '',
      ipAddress: '',
      applianceStatus: '',
      hostName: '',
      ipmiIp: '',
    });
  }

  // basic search operation
  searchAppliances(id) {
    let applianceDetailsModel = {
      "applianceName": id.value
    }
    this.getSearchResults(applianceDetailsModel);
  }
  // show search modal
  showAdvancedSearch() {
    $("#searchModel").modal("show");
    this.formAdvanced.reset();
  }

  // advance search operation
  advanceSearchAppliances() {
    this.getSearchResults(this.formAdvanced.value);
    $("#searchModel").modal("hide");
  }

  // get the search results
  getSearchResults(applianceDetailsModel) {
    this.searchApplianceSubsc = this._applianceManagementService.searchAppliances(applianceDetailsModel).subscribe(
      response => {
        this.appliancesList = response;
        if (response != null) {
          this.itemResource = new DataTableResource(this.appliancesList);
        }
      },
      error => {
        this.onErrorOperation(error);
      }
    )
  }
  count = 0;
  total = 0;
  count1 = 0;
  applianceName: string;
  flag: boolean = false;
  private selectSendData = [];
  private saveToDBData: any = [];
  private selectInitializeSendData = [];
  private selectInitializeSendDataBack = [];
  createLoginForm() {
    this.loginForm = this._formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]

    });
  }

  public formValidationFields1 = {
    "username": '',
    "password": ''

  }
  isFieldValid1(field: string) {
    if (this.loginForm.get(field).touched) {
      this.formValidationFields1 = this._fieldErrorDisplayService.validateField(this.loginForm, field, this.formValidationFields1, "login")
    }
    return !this.loginForm.get(field).valid && this.loginForm.get(field).touched;
  }

  displayFieldCss1(field: string) {
    return {
      'has-error': this.isFieldValid1(field),
      'has-feedback': this.isFieldValid1(field)
    };
  }
  openReboot() {
    debugger;
    this.count1 = 0;
    this.selectedCheckboxDataReferesh = [];
    if (this.selectedCheckboxData.length <= 5) {
      for (var i = 0; i < this.selectedCheckboxData.length; i++) {
        this.selectedCheckboxDataReferesh.push(this.selectedCheckboxData[i]);
      }
      var saveDbSelectCount = 0;

      if (this.selectedCheckboxDataReferesh.length <= 5) {
        for (var i = 0; i < this.selectedCheckboxDataReferesh.length; i++) {
          this.sendCheckData.push(this.selectedCheckboxDataReferesh[i]);

          if (this.selectedCheckboxDataReferesh[i]["credentialSaved"] == true) {
            saveDbSelectCount = saveDbSelectCount + 1;

          }

        }
        if (saveDbSelectCount == this.selectedCheckboxDataReferesh.length) {
          for (var i = 0; i < this.sendCheckData.length; i++) {

            this.selectSendData.push(this.sendCheckData[i]);
          }
          this.sendCheckData = [];
          this.saveUserData();
        }
        else {
          var saveDbSelectCount = 0;
          this.sendCheckData = [];
          $("#myModal").modal("show");
          for (var i = 0; i < this.selectedCheckboxDataReferesh.length; i++) {
            if (this.selectedCheckboxDataReferesh[i]["credentialSaved"] == true) {
              saveDbSelectCount = saveDbSelectCount + 1;
              this.saveToDBData.push(this.selectedCheckboxDataReferesh[i]);
              this.selectedCheckboxDataReferesh.splice(i, 1);
            }

          }
          this.applianceName = "";
          this.applianceName = this.selectedCheckboxDataReferesh[this.count]['applianceName'];
          this.selectSendData.push(this.selectedCheckboxDataReferesh[this.count1]);
          this.total = this.selectedCheckboxDataReferesh.length;
          this.count1 = this.selectSendData.length;
          this.loginForm.reset();

        }
      }
    }
    else {

      let message = "<b class=text-red>Sorry!Operation cannot be performed on more than five appliances</b>";
      bootbox.dialog({
        message: message,
        buttons: {
          cancel: {
            label: "Cancel",
            className: 'btn btn-primary btn-flat'
          }
        }
      });

    }
  }
  openZeroise() {
    debugger;
    this.count1 = 0;
    this.selectedCheckboxDataReferesh = [];
    if (this.selectedCheckboxData.length <= 5) {
      for (var i = 0; i < this.selectedCheckboxData.length; i++) {
        this.selectedCheckboxDataReferesh.push(this.selectedCheckboxData[i]);
      }
      var saveDbSelectCount = 0;

      if (this.selectedCheckboxDataReferesh.length <= 5) {
        for (var i = 0; i < this.selectedCheckboxDataReferesh.length; i++) {
          this.sendCheckData.push(this.selectedCheckboxDataReferesh[i]);

          if (this.selectedCheckboxDataReferesh[i]["credentialSaved"] == true) {
            saveDbSelectCount = saveDbSelectCount + 1;

          }

        }
        if (saveDbSelectCount == this.selectedCheckboxDataReferesh.length) {
          for (var i = 0; i < this.sendCheckData.length; i++) {

            this.selectSendData.push(this.sendCheckData[i]);
          }
          this.sendCheckData = [];
          this.saveUserData2();
        }
        else {
          this.sendCheckData = [];
          var saveDbSelectCount = 0;
          $("#myModal2").modal("show");
          for (var i = 0; i < this.selectedCheckboxDataReferesh.length; i++) {
            if (this.selectedCheckboxDataReferesh[i]["credentialSaved"] == true) {
              saveDbSelectCount = saveDbSelectCount + 1;
              this.saveToDBData.push(this.selectedCheckboxDataReferesh[i]);
              this.selectedCheckboxDataReferesh.splice(i, 1);
            }

          }
          this.applianceName = "";
          this.applianceName = this.selectedCheckboxDataReferesh[this.count]['applianceName'];
          this.selectSendData.push(this.selectedCheckboxDataReferesh[this.count1]);
          this.total = this.selectedCheckboxDataReferesh.length;
          this.count1 = this.selectSendData.length;
          this.loginForm.reset();

        }
      }
    }
    else {

      let message = "<b class=text-red>Sorry!Operation cannot be performed on more than five appliances</b>";
      bootbox.dialog({
        message: message,
        buttons: {
          cancel: {
            label: "Cancel",
            className: 'btn btn-primary btn-flat'
          }
        }
      });

    }
  }
  openFirmwareUpgrade() {
    debugger;
    this.count1 = 0;
    this.selectedCheckboxDataReferesh = [];
    if (this.selectedCheckboxData.length <= 5) {
      for (var i = 0; i < this.selectedCheckboxData.length; i++) {
        this.selectedCheckboxDataReferesh.push(this.selectedCheckboxData[i]);
      }
      var saveDbSelectCount = 0;

      if (this.selectedCheckboxDataReferesh.length <= 5) {
        for (var i = 0; i < this.selectedCheckboxDataReferesh.length; i++) {
          this.sendCheckData.push(this.selectedCheckboxDataReferesh[i]);

          if (this.selectedCheckboxDataReferesh[i]["credentialSaved"] == true) {
            saveDbSelectCount = saveDbSelectCount + 1;

          }

        }
        if (saveDbSelectCount == this.selectedCheckboxDataReferesh.length) {
          for (var i = 0; i < this.sendCheckData.length; i++) {

            this.selectSendData.push(this.sendCheckData[i]);
          }
          this.sendCheckData = [];
          this.saveUserData1();
        }
        else {
          var saveDbSelectCount = 0;
          this.sendCheckData = [];
          $("#myModal1").modal("show");
          for (var i = 0; i < this.selectedCheckboxDataReferesh.length; i++) {
            if (this.selectedCheckboxDataReferesh[i]["credentialSaved"] == true) {
              saveDbSelectCount = saveDbSelectCount + 1;
              this.saveToDBData.push(this.selectedCheckboxDataReferesh[i]);
              this.selectedCheckboxDataReferesh.splice(i, 1);
            }

          }
          this.applianceName = "";
          this.applianceName = this.selectedCheckboxDataReferesh[this.count]['applianceName'];
          this.selectSendData.push(this.selectedCheckboxDataReferesh[this.count1]);
          this.total = this.selectedCheckboxDataReferesh.length;
          this.count1 = this.selectSendData.length;
          this.loginForm.reset();

        }
      }
    }
    else {

      let message = "<b class=text-red>Sorry!Operation cannot be performed on more than five appliances</b>";
      bootbox.dialog({
        message: message,
        buttons: {
          cancel: {
            label: "Cancel",
            className: 'btn btn-primary btn-flat'
          }
        }
      });

    }
  }

  openInitializeOperation() {
    //this.resetForm();

    debugger;
    this.count1 = 0;
    this.selectedCheckboxDataReferesh = [];
    if (this.selectedCheckboxData.length <= 5) {
      for (var i = 0; i < this.selectedCheckboxData.length; i++) {
        this.selectedCheckboxDataReferesh.push(this.selectedCheckboxData[i]);
      }

      if (this.selectedCheckboxDataReferesh.length <= 5) {


        $("#initalizelogin").modal("show");



        this.applianceName = "";
        this.applianceName = this.selectedCheckboxDataReferesh[this.count]['applianceName'];
        this.selectSendData.push(this.selectedCheckboxDataReferesh[this.count1]);
        this.total = this.selectedCheckboxDataReferesh.length;
        this.count1 = this.selectSendData.length;
        this.loginForm.reset();
        this.loginFailureCount = this.selectedCheckboxDataReferesh[this.count]['coLoginFailureCount'];
        this.maxLength = this.selectedCheckboxDataReferesh[this.count]['maxPwdLen'];
        this.minPwdLen = this.selectedCheckboxDataReferesh[this.count]['minPwdLen'];
        this.form.get("logFailureCount").setValue(this.loginFailureCount);
        this.form.get("maxPwdLength").setValue(this.maxLength);
        this.form.get("minPwdLength").setValue(this.minPwdLen);
      }
    }
    else {

      let message = "<b class=text-red>Sorry!Operation cannot be performed on more than five appliances</b>";
      bootbox.dialog({
        message: message,
        buttons: {
          cancel: {
            label: "Cancel",
            className: 'btn btn-primary btn-flat'
          }
        }
      });

    }
  }

  nextAppliance() {
    debugger;
    this.selectSendData[this.count]["operationUsername"] = this.loginForm.get('username').value;
    this.selectSendData[this.count]["operationPassword"] = this.loginForm.get('password').value;
    if (this.selectedCheckboxDataReferesh.length > this.count1) {
      this.applianceName = this.selectedCheckboxDataReferesh[this.count1]['applianceName'];
      this.count++;
      this.selectSendData.push(this.selectedCheckboxDataReferesh[this.count1]);
      // this.selectedCheckboxData.splice(0,1);
      this.count1 = this.selectSendData.length;
    } else {
      $("#myModal").modal("hide");
      this.saveUserData();

    }
    if (this.count1 == this.total) {
      this.flag = true;
    }
    console.log(this.selectSendData);
    this.loginForm.reset();
  }
  nextAppliance1() {
    debugger;
    this.selectSendData[this.count]["operationUsername"] = this.loginForm.get('username').value;
    this.selectSendData[this.count]["operationPassword"] = this.loginForm.get('password').value;
    if (this.selectedCheckboxDataReferesh.length > this.count1) {
      this.applianceName = this.selectedCheckboxDataReferesh[this.count1]['applianceName'];
      this.count++;
      this.selectSendData.push(this.selectedCheckboxDataReferesh[this.count1]);
      // this.selectedCheckboxData.splice(0,1);
      this.count1 = this.selectSendData.length;
    } else {
      $("#myModal1").modal("hide");
      this.saveUserData1();
    }
    if (this.count1 == this.total) {
      this.flag = true;
    }
    console.log(this.selectSendData);
    this.loginForm.reset();
  }
  nextAppliance2() {
    debugger;
    this.selectSendData[this.count]["operationUsername"] = this.loginForm.get('username').value;
    this.selectSendData[this.count]["operationPassword"] = this.loginForm.get('password').value;
    if (this.selectedCheckboxDataReferesh.length > this.count1) {
      this.applianceName = this.selectedCheckboxDataReferesh[this.count1]['applianceName'];
      this.count++;
      this.selectSendData.push(this.selectedCheckboxDataReferesh[this.count1]);
      // this.selectedCheckboxData.splice(0,1);
      this.count1 = this.selectSendData.length;
    } else {
      $("#myModal2").modal("hide");
      this.saveUserData2();
    }
    if (this.count1 == this.total) {
      this.flag = true;
    }
    console.log(this.selectSendData);
    this.loginForm.reset();
  }
  closeLoginModal() {
    this.count = 0;

    this.applianceName = '';
    this.selectSendData = [];
    this.loginForm.reset();
    $("#myModal").modal("hide");
  }
  closeLoginModal1() {
    this.count = 0;

    this.applianceName = '';
    this.selectSendData = [];
    this.loginForm.reset();
    $("#myModal1").modal("hide");
  }
  closeLoginModal2() {
    this.count = 0;

    this.applianceName = '';
    this.selectSendData = [];
    this.loginForm.reset();
    $("#myModal2").modal("hide");
  }
  closeLoginModal4() {
    this.count = 0;


    this.applianceName = '';
    this.selectSendData = [];
    this.loginForm.reset();
    $("#initalizelogin").modal("hide");
  }
  closeLoginModal5() {
    this.count = 0;

    this.applianceName = '';
    this.selectSendData = [];
    this.loginForm.reset();
    this.form.reset();
    this.selectInitializeSendData = [];
    this.showContent = true;
    $("#InitializeModal").modal("hide");
  }
  save() {
    console.log("save")
  }

  resetForm() {
    this.count = 0;
    this.count1 = 0;
    this.total = 0;
    this.applianceName = '';

    this.selectSendData = [];
    this.loginForm.reset();
    this.form.reset();

  }

  nextInitializeAppliance() {

    debugger;
    this.selectSendData[this.count]["userName"] = this.loginForm.get('username').value;
    this.selectSendData[this.count]["userPassword"] = this.loginForm.get('password').value;
    if (this.selectedCheckboxDataReferesh.length > this.count1) {
      this.applianceName = this.selectedCheckboxDataReferesh[this.count1]['applianceName'];
      this.loginFailureCount = this.selectedCheckboxDataReferesh[this.count1]['coLoginFailureCount'];
      this.maxLength = this.selectedCheckboxDataReferesh[this.count1]['maxPwdLen'];
      this.minPwdLen = this.selectedCheckboxDataReferesh[this.count1]['minPwdLen'];
      this.form.get("logFailureCount").setValue(this.loginFailureCount);
      this.form.get("maxPwdLength").setValue(this.maxLength);
      this.form.get("minPwdLength").setValue(this.minPwdLen);
      this.count++;
      this.selectSendData.push(this.selectedCheckboxDataReferesh[this.count1]);
      // this.selectedCheckboxData.splice(0,1);
      this.count1 = this.selectSendData.length;
    } else {
      $("#initalizelogin").modal("hide");
      this.count1 = 1;
      this.count = 0;

      $("#InitializeModal").modal("show");

    }
    if (this.count1 == this.total) {
      this.flag = true;
    }
    console.log(this.selectSendData);
    this.loginForm.reset();

  }

  initializeList = [];
  saveInitializeAppliance(isvalid) {
    debugger;
    if (isvalid) {
      if (this.showBack == false) {
        this.applianceName = "";
        this.applianceName = this.selectSendData[this.count]['applianceName'];
        this.selectInitializeSendData.push(this.selectSendData[this.count]);
        // this.selectSendData.push(this.selectedCheckboxData[this.count1]);
        this.total = this.selectSendData.length;
        this.count1 = this.selectInitializeSendData.length;
        let initializeData = {
          "applianceDetailModels": []
        };
        initializeData['userName'] = this.selectInitializeSendData[this.count]["userName"];
        initializeData['password'] = this.selectInitializeSendData[this.count]["userPassword"];
        initializeData['cryptoOfficerName'] = this.form.get('cryptoOffName').value;
        initializeData['cryptoOfficerPassword'] = this.form.get('cryptoOffPwd').value;
        initializeData['confirmCryptoOfficerpassword'] = this.form.get('confirmPwd').value;
        initializeData['authenticationLevel'] = this.form.get('authLevel') ? parseInt(this.form.get('authLevel').value) : null;
        initializeData['fipsState'] = this.form.get('fipsState').value ? parseInt(this.form.get('fipsState').value) : null;
        if (this.form.get('certAuthentication').value == true) {
          initializeData['certAuthentication'] = 1;
        } else {
          initializeData['certAuthentication'] = 0;
        }
        if (this.form.get('hsmAuditLog').value == true) {
          initializeData['hsmAuditLog'] = 1;
        } else {
          initializeData['hsmAuditLog'] = 0;
        }
        if (this.form.get('saveToDB').value == true) {
          initializeData['credentialSaved'] = true;
        } else {
          initializeData['credentialSaved'] = false;
        }
        initializeData['hsmLabel'] = this.form.get('hsmLabel').value;
        initializeData['dualFactorAuthServerAddress'] = this.form.get('authServerAddress').value;
        initializeData['dualFactorAuthServerPortNo'] = this.form.get('authServerPortNo').value;
        initializeData['loginFailureCount'] = this.form.get('logFailureCount').value;
        initializeData['minimumPasswordLength'] = this.form.get('minPwdLength').value;
        initializeData['maximumPasswordLength'] = this.form.get('maxPwdLength').value;
        initializeData.applianceDetailModels.push(this.selectInitializeSendData[this.count]);
        this.initializeList.push(initializeData);

        if (this.selectSendData.length > this.count1) {
          this.applianceName = this.selectSendData[this.count1]['applianceName'];

          this.count1++;
          this.count++;
          this.showContent = true;

        } else {
          this.showContent = false;
          //this.saveUserData2();
        }
        console.log(this.selectSendData);
        this.form.reset();
        this.loginFailureCount = this.selectSendData[this.count]['coLoginFailureCount'];
        this.maxLength = this.selectSendData[this.count]['maxPwdLen'];
        this.minPwdLen = this.selectSendData[this.count]['minPwdLen'];
        this.form.get("logFailureCount").setValue(this.loginFailureCount);
        this.form.get("maxPwdLength").setValue(this.maxLength);
        this.form.get("minPwdLength").setValue(this.minPwdLen);

      }
      else {
        this.applianceName = "";
        this.applianceName = this.selectSendData[this.count]['applianceName'];
        this.selectInitializeSendDataBack.push(this.selectSendData[this.count]);
        // this.selectInitializeSendData.push(this.selectSendData[this.count]);

        // this.selectSendData.push(this.selectedCheckboxData[this.count1]);
        this.total = this.selectSendData.length;
        this.count1 = this.selectInitializeSendData.length;
        this.selectInitializeSendData.splice(this.count, 1);
        let initializeData = {
          "applianceDetailModels": []
        };

        initializeData['userName'] = this.selectInitializeSendDataBack["userName"];
        initializeData['password'] = this.selectInitializeSendDataBack["userPassword"];
        initializeData['cryptoOfficerName'] = this.form.get('cryptoOffName').value;
        initializeData['cryptoOfficerPassword'] = this.form.get('cryptoOffPwd').value;
        initializeData['confirmCryptoOfficerpassword'] = this.form.get('confirmPwd').value;
        if (this.form.get('certAuthentication').value == true) {
          initializeData['certAuthentication'] = 1;
        } else {
          initializeData['certAuthentication'] = 0;
        }
        if (this.form.get('hsmAuditLog').value == true) {
          initializeData['hsmAuditLog'] = 1;
        } else {
          initializeData['hsmAuditLog'] = 0;
        }
        if (this.form.get('saveToDB').value == true) {
          initializeData['credentialSaved'] = true;
        } else {
          initializeData['credentialSaved'] = false;
        }
        initializeData['hsmLabel'] = this.form.get('hsmLabel').value;
        initializeData['authenticationLevel'] = this.form.get('authLevel') ? parseInt(this.form.get('authLevel').value) : null;
        initializeData['fipsState'] = this.form.get('fipsState').value ? parseInt(this.form.get('fipsState').value) : null;
        initializeData['dualFactorAuthServerAddress'] = this.form.get('authServerAddress').value;
        initializeData['dualFactorAuthServerPortNo'] = this.form.get('authServerPortNo').value;
        initializeData['loginFailureCount'] = this.form.get('logFailureCount').value;
        initializeData['minimumPasswordLength'] = this.form.get('minPwdLength').value;
        initializeData['maximumPasswordLength'] = this.form.get('maxPwdLength').value;
        for (var i = 0; i < this.selectInitializeSendDataBack.length; i++) {

          this.selectInitializeSendData.push(this.selectInitializeSendDataBack[i]);
        }
        // this.selectInitializeSendData=this.selectInitializeSendDataBack;
        this.selectInitializeSendDataBack = [];
        initializeData.applianceDetailModels.push(this.selectInitializeSendData);
        this.initializeList.push(initializeData);

        if (this.selectSendData.length > this.count1) {
          this.applianceName = this.selectSendData[this.count1]['applianceName'];

          this.count1++;

          this.showContent = true;

        } else {
          this.showContent = false;
          //this.saveUserData2();
        }
        console.log(this.selectSendData);

        this.form.reset();
      }
    } else {
      this.formValidationFields = this._fieldErrorDisplayService.validateForm(this.form, this.formValidationFields, "initialize", false);
      // this.formValidationFields = this._fieldErrorDisplayService.validateForm(this.form, this.formValidationFields, "createuser", false)
      this.scrollToTop();
    }


  }

  submitInitialize() {
    //this.spinnerService.show();
    this._applianceManagementService.saveInitializedata(this.initializeList).subscribe((res) => {

      if (res.length > 0) {
        // this.spinnerService.hide();
        $("#InitializeModal").modal("hide");
        let displaymsg: string = '';

        res.forEach(obj => {
          if (displaymsg == '') {
            displaymsg = obj["message"] + "<br>";
          } else {
            displaymsg = displaymsg + obj["message"] + "<br>";
          }
        });
        bootbox.dialog({
          message: displaymsg,
          buttons: {

            Ok: {
              label: "Close",
              className: 'btn btn-primary btn-flat',
              callback: () => this.loadingListAppliances()
            }
          }
        });
        this.resetForm();
        this.initializeList = [];
        this.selectSendData = [];
        this.selectInitializeSendData = [];
        this.form.reset();
        this.showContent = true;
        displaymsg = '';
      }
    }, (err) => {
      console.log(err);
    })
  }



  removeAppliance(applianceId) {
    let selectedIds = [];
    selectedIds.push(applianceId);
    this.selectedAppliances = this.selectedAppliances.filter(
      val => !selectedIds.includes(val.applianceId));
    console.log(this.selectedAppliances);

  }
  certAuthenticationChecked: boolean;
  hsmAuditLogChecked: boolean;
  saveToDBChecked: boolean;
  toggleCertAuthentication($event) {
    if ($event.checked) {
      this.certAuthenticationChecked = true;
    } else {
      this.certAuthenticationChecked = false;
    }

  }
  toggleHSMAuditLog($event) {
    if ($event.checked) {
      this.hsmAuditLogChecked = true;
    } else {
      this.hsmAuditLogChecked = false;
    }
  }
  toggleSaveToDB($event) {
    if ($event.checked) {
      this.saveToDBChecked = true;
    } else {
      this.saveToDBChecked = false;
    }
  }
  isLoginFailureValid = true;
  isMaxPasswordValid = true;
  isMinPasswordValid = true
  loginFailureCount: any;
  maxLength: any;
  minPwdLen: any;
  validatelogFailureCount(property) {
    if (property.value <= 0 || property.value > 20) {
      this.isLoginFailureValid = false;
      this.form.get("logFailureCount").setValue("");
    } else {
      this.isLoginFailureValid = true;
    }
  }

  validateMaxPassword(property) {
    if (property.value < this.minPwdLen || property.value > this.maxLength) {
      this.isMaxPasswordValid = false;
      this.form.get("maxPwdLength").setValue("");
    } else {
      this.isMaxPasswordValid = true;
    }
  }
  validateMinPassword(property) {
    if (property.value < this.minPwdLen || property.value > this.maxLength) {
      this.isMinPasswordValid = false;
      this.form.get("minPwdLength").setValue("");
    } else {
      this.isMinPasswordValid = true;
    }
  }

  scrollToTop() {
    $('.tab-content').scrollTop(0);
  }
  showDualFactor: boolean = true;
  checkDualFactor(value) {
    if (value == 0) {
      this.showDualFactor = false;
    } else {
      this.showDualFactor = true;
    }
  }
  
  isValidPassword = true;
  checkConfirmPassword(){
      let cryptoOffPwd = this.form.get("cryptoOffPwd").value;
      let confirmPwd = this.form.get("confirmPwd").value;
      if (cryptoOffPwd !== confirmPwd) {
        this.isValidPassword =false;
        return false;
      }
      else {
        this.isValidPassword =true;
        return true;
      }
    }


    callback(){
      console.log("Callback ----> List Appliance");
      this.selectedAppliances = [];
      this.loadingListAppliances();
    }
}