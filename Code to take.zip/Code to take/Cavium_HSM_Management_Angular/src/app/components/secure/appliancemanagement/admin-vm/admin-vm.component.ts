import { Component, OnInit,Input } from '@angular/core';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';

@Component({
  selector: 'app-admin-vm',
  templateUrl: './admin-vm.component.html',
  styleUrls: ['./admin-vm.component.css']
})
export class AdminVmComponent implements OnInit {
  @Input() applianceId;
  stats:any = [];
  // network:any = [];
  // snmp:any = [];
  // status:any=[];
  // trapStatus:any=[];
  // username:any=[];
  // managerIp:any=[];
  showlist :  boolean = true;
  // adminVM gauge
  // gaugeLabe = 4;
  // gaugeLabe1 = 7;
  // gaugeLabel = 67;
  gaugeValue4 = [];
  gaugeValue5 = [];
  gaugeValue6 = [];
  gaugeValue7 = [];
  gaugeType = "arch";
  gaugeThickness=25;
  gaugeThresholdConfig = {
    '0': {color: 'rgb(0,179,30'},
    '60': {color:'rgb(230,191,0'},
    '80': {color:'rgb(204,0,0'}
  };
  gaugeAppendText = "%";
  constructor(private _applianceManagementService: AppliancemanagementService) { }

  ngOnInit() {
    console.log(this.applianceId);
    this._applianceManagementService.getAdminVMInfo(this.applianceId).subscribe(
      res => {
        this.stats = res.hostStats;
        console.log("hello adminVM", this.stats); 
        // this.network = res.adminVMConfig;
        // console.log("hello adminVM", this.network); 
        // this.snmp = res.adminSNMPConfig;
        // console.log("hello adminVM", this.snmp); 

        // if(this.snmp!=null){
        //   if(this.snmp.adminSNMPData!=null){
        //     if(this.snmp.adminSNMPData.uname==null){
        //       this.username='';
        //     }
        //   }
        // }
        // if(this.snmp!=null){
        //   if(this.snmp.adminSNMPData!=null){
        //     if(this.snmp.adminSNMPData.ip==null){
        //       this.managerIp='';
        //     }
        //   }
        // }

        // if(this.snmp!=null){
        //   if(this.snmp.adminSNMPData!=null){
        //     if(this.snmp.adminSNMPData.enabled==false){
        //       this.status="Disabled";
        //     }
        //     else if(this.snmp.adminSNMPData.enabled==true){
        //       this.status="Enabled";
        //     }
        //   }
        // }

        // if(this.snmp!=null){
        //   if(this.snmp.adminSNMPData!=null){
        //     if(this.snmp.adminSNMPData.enableTrap==false){
        //       this.trapStatus="Disabled";
        //     } 
        //     else if(this.snmp.adminSNMPData.enableTrap==true){
        //       this.trapStatus="Enabled";
        //     }         
        //   }
        // }

        if(this.stats!=null){
          if(this.stats.dataObject!=null){
            if(this.stats.dataObject.vmstatsObject!=null){
          this.gaugeValue4= this.stats.dataObject.vmstatsObject.cpuUsage;
      }
    }
  }
        if(this.stats!=null){
          if(this.stats.dataObject!=null){
            if(this.stats.dataObject.vmstatsObject!=null){
              if(this.stats.dataObject.vmstatsObject.ramStats!=null){
          this.gaugeValue6= this.stats.dataObject.vmstatsObject.ramStats.usedPercentage;
        }
      }
    }
  }
       if(this.stats!=null){
          if(this.stats.dataObject!=null){
            if(this.stats.dataObject.vmstatsObject!=null){
              if(this.stats.dataObject.vmstatsObject.swapStats!=null){
          this.gaugeValue7= this.stats.dataObject.vmstatsObject.swapStats.usedPercentage;
        }
      }
    }
  }


      }
    )
  }
// lineChart8
public lineChartData8:Array<any> = [
  {data: [25, 40, 30, 81, 56, 55, 40], label: 'Outgoing'},
  {data: [12, 20, 15, 18, 25, 15, 26], label: 'Incoming'},

];

toggle4(){
  this.showlist = true;
}
toggle5(){
  this.showlist = false;
  }
public lineChartLabels8:Array<any> = ['18:10', '18:20', '18:30', '18:40','18:50', '19:00', '19:10'];
public lineChartOptions8:any = {
  responsive: true,
  legend: {
    display: true,
    position: 'bottom'
    } 
};
public lineChartColors8:Array<any> = [
  { // blue
    backgroundColor: 'rgba(0,149,179,0)',
    borderColor: 'rgba(0,149,179,1)',
    pointBackgroundColor: 'rgba(0,149,179,1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(0,149,179,0.8)'
  },

  { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
  },
  
];
public lineChartLegend8:boolean = true;
public lineChartType8:string = 'line';

// lineChart9
public lineChartData9:Array<any> = [
  {data: [25, 40, 30, 81, 56, 55, 40], label: 'Outgoing'},
  {data: [12, 20, 15, 18, 25, 15, 26], label: 'Incoming'},

];
public lineChartLabels9:Array<any> = ['18:10', '18:20', '18:30', '18:40','18:50', '19:00', '19:10'];
public lineChartOptions9:any = {
  responsive: true,
  legend: {
    display: true,
    position: 'bottom'
    } 
};
public lineChartColors9:Array<any> = [
  { // blue
    backgroundColor: 'rgba(0,149,179,0)',
    borderColor: 'rgba(0,149,179,1)',
    pointBackgroundColor: 'rgba(0,149,179,1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(0,149,179,0.8)'
  },

  { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
  },
  
];
public lineChartLegend9:boolean = true;
public lineChartType9:string = 'line';


// events
public chartClicked9(e:any):void {
  console.log(e);
}

public chartHovered9(e:any):void {
  console.log(e);
}

// events
public chartClicked8(e:any):void {
  console.log(e);
}

public chartHovered8(e:any):void {
  console.log(e);
}

// lineChart10
public lineChartData10:Array<any> = [
  {data: [70, 59, 83, 81, 60, 87, 83], label: 'Head'},
  {data: [65, 48, 55, 50, 56, 60, 78], label: 'Tail'},
  {data: [45, 35, 45, 65, 47, 52, 40], label: 'Head'},
  {data: [27, 22, 33, 30, 38, 27, 32], label: 'Tail'},

];
public lineChartLabels10:Array<any> = ['18:10', '18:20', '18:30', '18:40','18:50', '19:00', '19:10'];
public lineChartOptions10:any = {
  responsive: true,
  legend: {
    display: true,
    position: 'bottom'
    } 
};
public lineChartColors10:Array<any> = [
  { // blue
    backgroundColor: 'rgba(0,102,204,0)',
    borderColor: 'rgba(0,102,204,1)',
    pointBackgroundColor: 'rgba(0,102,204,1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(0,102,204,0.8)'
  },
  { //green
    backgroundColor: 'rgba(89,179,0,0)',
    borderColor: 'rgba(89,179,0,1)',
    pointBackgroundColor: 'rgba(89,179,0,1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(89,179,0,0.8)'
  },
  
  { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
  },
  
  { // purple
    backgroundColor: 'rgba(102,0,153,0)',
    borderColor: 'rgba(102,0,153,1)',
    pointBackgroundColor: 'rgba(102,0,153,1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(102,0,153,1)'
  },
  
];
public lineChartLegend10:boolean = true;
public lineChartType10:string = 'line';


// events
public chartClicked10(e:any):void {
  console.log(e);
}

public chartHovered10(e:any):void {
  console.log(e);
}

// lineChart11
public lineChartData11:Array<any> = [
  {data: [70, 59, 83, 81, 60, 87, 83], label: 'Head'},
  {data: [65, 48, 55, 50, 56, 60, 78], label: 'Tail'},
  {data: [45, 35, 45, 65, 47, 52, 40], label: 'Head'},
  {data: [27, 22, 33, 30, 38, 27, 32], label: 'Tail'},
];
public lineChartLabels11:Array<any> = ['18:10', '18:20', '18:30', '18:40','18:50', '19:00', '19:10'];
public lineChartOptions11:any = {
  responsive: true,
  legend: {
    display: true,
    position: 'bottom'
    } 
};
public lineChartColors11:Array<any> = [
  { // blue
    backgroundColor: 'rgba(0,102,204,0)',
    borderColor: 'rgba(0,102,204,1)',
    pointBackgroundColor: 'rgba(0,102,204,1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(0,102,204,0.8)'
  },
  { //green
    backgroundColor: 'rgba(89,179,0,0)',
    borderColor: 'rgba(89,179,0,1)',
    pointBackgroundColor: 'rgba(89,179,0,1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(89,179,0,0.8)'
  },
  
  { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
  },
  
  { // purple
    backgroundColor: 'rgba(102,0,153,0)',
    borderColor: 'rgba(102,0,153,1)',
    pointBackgroundColor: 'rgba(102,0,153,1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(102,0,153,1)'
  },
  
];
public lineChartLegend11:boolean = true;
public lineChartType11:string = 'line';


// events
public chartClicked11(e:any):void {
  console.log(e);
}

public chartHovered11(e:any):void {
  console.log(e);
}


  // lineChart3
  public lineChartData3: Array<any> = [
    { data: [40, 59, 55, 81, 56, 55, 40], label: 'Series A' },
    { data: [28, 48, 40, 19, 86, 27, 60], label: 'Series B' },
  ];
  public lineChartLabels3: Array<any> = ['18:10', '18:20', '18:30', '18:40', '18:50', '19:00', '19:10'];
  public lineChartOptions3: any = {
    responsive: true,
    legend:  {
      display:  true,
      position:  'bottom'
    }
  };
  public lineChartColors3: Array<any> = [
    { // blue
      backgroundColor: 'rgba(0,149,179,0)',
      borderColor: 'rgba(0,149,179,1)',
      pointBackgroundColor: 'rgba(0,149,179,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(0,149,179,0.8)'
    },
    { // yellow
      backgroundColor: 'rgba(230,230,0,0)',
      borderColor: 'rgba(230,230,0,1)',
      pointBackgroundColor: 'rgba(230,230,0,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(230,230,0,1)'
    },

  ];
  public lineChartLegend3: boolean = true;
  public lineChartType3: string = 'line';


  // events
  public chartClicked3(e: any): void {
    console.log(e);
  }

  public chartHovered3(e: any): void {
    console.log(e);
  }

  // lineChart4
  public lineChartData4: Array<any> = [
    { data: [65, 59, 80, 81, 56, 55, 40], label: 'Series A' },
    { data: [28, 48, 40, 19, 86, 27, 90], label: 'Series B' },
    { data: [18, 48, 77, 9, 100, 27, 40], label: 'Series C' },
    { data: [40, 90, 56, 70, 30, 27, 40], label: 'Series D' },

  ];
  public lineChartLabels4: Array<any> = ['18:10', '18:20', '18:30', '18:40', '18:50', '19:00', '19:10'];
  public lineChartOptions4: any = {
    responsive: true,
    legend:  {
      display:  true,
      position:  'bottom'
    }
  };
  public lineChartColors4: Array<any> = [
    { // blue
      backgroundColor: 'rgba(0,149,179,0)',
      borderColor: 'rgba(0,149,179,1)',
      pointBackgroundColor: 'rgba(0,149,179,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(0,149,179,0.8)'
    },
    { // yellow
      backgroundColor: 'rgba(230,230,0,0)',
      borderColor: 'rgba(230,230,0,1)',
      pointBackgroundColor: 'rgba(230,230,0,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(230,230,0,1)'
    },

    { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
    },

    { //green
      backgroundColor: 'rgba(34,204,0,0)',
      borderColor: 'rgba(34,204,0,1)',
      pointBackgroundColor: 'rgba(34,204,0,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(34,204,0,0.8)'
    },

  ];
  public lineChartLegend4: boolean = true;
  public lineChartType4: string = 'line';


  // events
  public chartClicked4(e: any): void {
    console.log(e);
  }

  public chartHovered4(e: any): void {
    console.log(e);
  }


  // lineChart5
  public lineChartData5: Array<any> = [
    { data: [25, 40, 30, 81, 56, 55, 40], label: 'Outgoing' },
    { data: [12, 20, 15, 18, 25, 15, 26], label: 'Incoming' },

  ];
  public lineChartLabels5: Array<any> = ['18:10', '18:20', '18:30', '18:40', '18:50', '19:00', '19:10'];
  public lineChartOptions5: any = {
    responsive: true,
    legend:  {
      display:  true,
      position:  'bottom'
    }
  };
  public lineChartColors5: Array<any> = [
    { // blue
      backgroundColor: 'rgba(0,149,179,0)',
      borderColor: 'rgba(0,149,179,1)',
      pointBackgroundColor: 'rgba(0,149,179,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(0,149,179,0.8)'
    },

    { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
    },

  ];
  public lineChartLegend5: boolean = true;
  public lineChartType5: string = 'line';


  // events
  public chartClicked5(e: any): void {
    console.log(e);
  }

  public chartHovered5(e: any): void {
    console.log(e);
  }

  // lineChart6
  public lineChartData6: Array<any> = [
    { data: [25, 40, 30, 81, 56, 55, 40], label: 'Outgoing' },
    { data: [12, 20, 15, 18, 25, 15, 26], label: 'Incoming' },

  ];
  public lineChartLabels6: Array<any> = ['18:10', '18:20', '18:30', '18:40', '18:50', '19:00', '19:10'];
  public lineChartOptions6: any = {
    responsive: true,
    legend:  {
      display:  true,
      position:  'bottom'
    }
  };
  public lineChartColors6: Array<any> = [
    { // blue
      backgroundColor: 'rgba(0,149,179,0)',
      borderColor: 'rgba(0,149,179,1)',
      pointBackgroundColor: 'rgba(0,149,179,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(0,149,179,0.8)'
    },

    { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
    },

  ];
  public lineChartLegend6: boolean = true;
  public lineChartType6: string = 'line';


  // events
  public chartClicked6(e: any): void {
    console.log(e);
  }

  public chartHovered6(e: any): void {
    console.log(e);
  }

  // lineChart7
  public lineChartData7: Array<any> = [
    { data: [65, 59, 80, 81, 56, 55, 40], label: 'Series A' },
    { data: [28, 48, 40, 19, 86, 27, 90], label: 'Series B' },
    { data: [18, 48, 77, 9, 100, 27, 40], label: 'Series C' },
    { data: [40, 90, 56, 70, 30, 27, 40], label: 'Series D' },

  ];
  public lineChartLabels7: Array<any> = ['18:10', '18:20', '18:30', '18:40', '18:50', '19:00', '19:10'];
  public lineChartOptions7: any = {
    responsive: true,
    legend:  {
      display:  true,
      position:  'bottom'
    }
  };
  public lineChartColors7: Array<any> = [
    { // blue
      backgroundColor: 'rgba(0,149,179,0)',
      borderColor: 'rgba(0,149,179,1)',
      pointBackgroundColor: 'rgba(0,149,179,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(0,149,179,0.8)'
    },
    { // yellow
      backgroundColor: 'rgba(230,230,0,0)',
      borderColor: 'rgba(230,230,0,1)',
      pointBackgroundColor: 'rgba(230,230,0,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(230,230,0,1)'
    },

    { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
    },

    { //green
      backgroundColor: 'rgba(34,204,0,0)',
      borderColor: 'rgba(34,204,0,1)',
      pointBackgroundColor: 'rgba(34,204,0,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(34,204,0,0.8)'
    },

  ];
  public lineChartLegend7: boolean = true;
  public lineChartType7: string = 'line';


  // events
  public chartClicked7(e: any): void {
    console.log(e);
  }

  public chartHovered7(e: any): void {
    console.log(e);
  }

  // lineChart2
  public lineChartData2: Array<any> = [
    { data: [15,15,15,15,15,15,15], label: 'Free Space' },
    { data: [22,30,28,25,32,25,36], label: 'Cache' },
    { data: [48,54,50,56,53,50,54], label: 'Used' },
    { data: [42,38,40,38,46,40,39], label: 'Shared' },
    { data: [55,67,60,68,65,60,66], label: 'Buffered' },
    

  ];
  public lineChartLabels2: Array<any> = ['18:10', '18:20', '18:30', '18:40', '18:50', '19:00', '19:10'];
  public lineChartOptions2: any = {
    responsive: true,
    legend:  {
      display:  true,
      position:  'bottom'
    }
  };
  public lineChartColors2: Array<any> = [
    { // light green
      backgroundColor: 'rgba(102,204,0,0.2)',
      borderColor: 'rgba(102,204,0,1)',
      pointBackgroundColor: 'rgba(102,204,0,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(102,204,0,0.8)'
    },
   // blue3
  { backgroundColor: 'rgba(0,149,179,0.2)',
   borderColor: 'rgba(0,149,179,1)',
   pointBackgroundColor: 'rgba(0,149,179,1)',
   pointBorderColor: '#fff',
   pointHoverBackgroundColor: '#fff',
   pointHoverBorderColor: 'rgba(0,149,179,0.8)'
  },
    { // orange
      backgroundColor: 'rgba(255,166,77,0.2)',
      borderColor: 'rgba(255,166,77,1)',
      pointBackgroundColor: 'rgba(255,166,77,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,166,77,0.8)'
    },
    { // purple
      backgroundColor: 'rgba(136,77,255,0.2)',
      borderColor: 'rgba(136,77,255,1)',
      pointBackgroundColor: 'rgba(136,77,255,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(136,77,255,0.8)'
    },
    { // blue
      backgroundColor: 'rgba(51,119,255,0.2)',
      borderColor: 'rgba(51,119,255,1)',
      pointBackgroundColor: 'rgba(51,119,255,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(51,119,255,0.8)'
    }
  ];
  public lineChartLegend2: boolean = true;
  public lineChartType2: string = 'line';


  // events
  public chartClicked2(e: any): void {
    console.log(e);
  }

  public chartHovered2(e: any): void {
    console.log(e);
  }
}
