import { Component, OnInit,EventEmitter,Output } from '@angular/core';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { LoadingModule } from 'ngx-loading';
declare var $: any;
declare var bootbox: any;
declare var jQuery: any;
@Component({
  selector: 'app-appliance-operations',
  templateUrl: './appliance-operations.component.html',
  styleUrls: ['./appliance-operations.component.css']
})
export class ApplianceOperationsComponent implements OnInit {
  @Output() messageEvent = new EventEmitter<any>();
  public loading = false; 
  constructor(private _service :AppliancemanagementService) { }

  ngOnInit() {
  }


  submitApplianceOperations(listAppliance,applianceOperation){
    this.loading = true;
    if(applianceOperation == "Reboot"){
      this._service.setRebootActivity(listAppliance).subscribe(
        res => {
          this.responseOperation(res);
        },
        err => {
          console.log(err);
        }
      )
    }else if(applianceOperation == "filmwareUpgrade"){
      this._service.firmwareUpgrade(listAppliance).subscribe(
        res => {
          this.responseOperation(res);
        },
        err => {
          console.log(err);
        }
      )
    }else if(applianceOperation == "zeroize"){
      this._service.setZeroise(listAppliance).subscribe(
        res => {
          this.responseOperation(res);
        },
        err => {
          console.log(err);
        }
      )
    }
  }

  callBack() {
    this.messageEvent.emit();
  }

  responseOperation(res){
    this.loading = false;
    let displaymsg: string = '';
    res.forEach(obj => {
        displaymsg = displaymsg + " " + "<b>" + obj.applianceName + "</b> :-- " + obj["message"] + "<br>";
    });
    bootbox.dialog({
      message: displaymsg,
      buttons: {
        Ok: {
          label: "Close",
          className: 'btn btn-primary btn-flat',
          callback: () => this.callBack()
        }
      }
    });
  }
}
