import {  ViewChild, Component, OnInit, TemplateRef,Output, EventEmitter, } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FileUploader } from 'ng2-file-upload';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
const URL = '';

declare var bootbox: any;

@Component({
  selector: 'app-firmware-upgrade-appliance',
  templateUrl: './firmware-upgrade-appliance.component.html',
  styleUrls: ['./firmware-upgrade-appliance.component.css']
})
export class FirmwareUpgradeApplianceComponent implements OnInit {

  @ViewChild('firmwareUpgradeModal') firmwareUpgradeModal: ModalDirective;
  @Output() messageEvent = new EventEmitter<any>();
  form: FormGroup;
  applianceName: string;
  applianceCount = 1;
  selectedAppliances = [];
  firmwareDataList = [];
  totalAppliance = 0;
  performZeroizeChecked: boolean = false;
  applianceChecked: boolean=false;
  fipsAdapterChecked: boolean=false;
  showPerformFIPS:boolean=false;
  showFinalFirmwareList: boolean = false;
  showBackButton = false;
  loading = false;
  public uploader:FileUploader = new FileUploader({url: URL});
  public hasBaseDropZoneOver:boolean = false;
  public hasAnotherDropZoneOver:boolean = false;
  checked : boolean = true;
  public fileOverBase(e:any):void {
    this.hasBaseDropZoneOver = e;
  }
 
  public fileOverAnother(e:any):void {
    this.hasAnotherDropZoneOver = e;
  }
  constructor(private _formBuilder: FormBuilder,
    private _applianceManagementService: AppliancemanagementService,) { }

  ngOnInit() {
    this.createFirmwareUpgradeForm();
    
  }

  createFirmwareUpgradeForm(){
    this.form = this._formBuilder.group({
      hsmFirmwareType: [1],
      zeroize: [false],
      fileContent: [''],
      fileName: [''],
      fileExtension: [''],
      fileValidate : [''],

      fileContentSign: [''],
      fileNameSign: [''],
      fileExtensionSign: [''],
      fileValidateSign : [''],
      // applianceId:[],
      // applianceName: [],
      // applianceStatus: [],
      // serialNumber: [],
      // networkTimezone: [],
      // gatewayIp: [],
      // ipAddress: [],
      // networkId:[],
      // subnetMask: [],

      // firmwareUpgradeDetailModel: this._formBuilder.group({
      //   hsmFirmwareType:[false],
      //   zeroize:[''],
      //   imageFileDeatils: this._formBuilder.group({
      //     fileContent: [''],
      //     fileName: [''],
      //     fileExtension: [''],
      //   }),
      //   signFileDeatils:this._formBuilder.group({
      //     fileContent: [''],
      //     fileName: [''],
      //     fileExtension: [''],
      //   }),
      // }),
    });
  }
  
  setApplianceDetails(firmwareData){
    debugger;
    if(this.selectedAppliances[this.applianceCount]['applianceId']!=null && this.selectedAppliances[this.applianceCount]['applianceId']!=""){
      firmwareData['applianceId']=this.selectedAppliances[this.applianceCount-1]['applianceId'];
    }
    if(this.selectedAppliances[this.applianceCount]['applianceName']!=null && this.selectedAppliances[this.applianceCount]['applianceName']!=""){
      firmwareData['applianceName']=this.selectedAppliances[this.applianceCount - 1]['applianceName'];
    }
    if(this.selectedAppliances[this.applianceCount]['applianceStatus']!=null && this.selectedAppliances[this.applianceCount]['applianceStatus']!=""){
      firmwareData['applianceStatus']=this.selectedAppliances[this.applianceCount-1]['applianceStatus'];
    }
  }
  showFirmwareUpgradeModal(listAppliances) {
      debugger;
       console.log("List of selected appliance --->" + listAppliances);
       this.clearData();
       this.selectedAppliances = listAppliances;
       this.applianceName = this.selectedAppliances[this.applianceCount - 1]['applianceName'];
       this.totalAppliance = this.selectedAppliances.length;
       this.firmwareUpgradeModal.show();
  }

  saveFirmwareAppliance(isvalid, template: TemplateRef<any>) {
    debugger;
    if (isvalid) {
        /* begins, pushing each appliance into list*/
        if (typeof this.firmwareDataList[this.applianceCount - 1] === 'undefined') {
          this.pushApplianceDataIntoList();
        } else {
          // if (this.form.get('hsmFirmwareType').value == true) {
          //   this.firmwareDataList[this.applianceCount - 1]['hsmFirmwareType'] = 1;
          // } else {
          //   this.firmwareDataList[this.applianceCount - 1]['hsmFirmwareType'] = 0;
          // }
          this.firmwareDataList[this.applianceCount - 1]['firmwareUpgradeDetailModel']['hsmFirmwareType']=this.form.get('hsmFirmwareType').value;
          if (this.form.get('zeroize').value == true) {
            this.firmwareDataList[this.applianceCount - 1]['firmwareUpgradeDetailModel']['zeroize'] = 1;
          } else {
            this.firmwareDataList[this.applianceCount - 1]['firmwareUpgradeDetailModel']['zeroize'] = 0;
          }
          this.firmwareDataList[this.applianceCount - 1]['firmwareUpgradeDetailModel']['imageFileDeatils']['fileContent'] = this.form.get('fileContent').value;
          this.firmwareDataList[this.applianceCount - 1]['firmwareUpgradeDetailModel']['imageFileDeatils']['fileName'] = this.form.get('fileName').value;
          this.firmwareDataList[this.applianceCount - 1]['firmwareUpgradeDetailModel']['imageFileDeatils']['fileExtension'] = this.form.get('fileExtension').value;
          this.firmwareDataList[this.applianceCount - 1]['firmwareUpgradeDetailModel']['signFileDeatils']['fileContentSign'] = this.form.get('fileContentSign').value;
          this.firmwareDataList[this.applianceCount - 1]['firmwareUpgradeDetailModel']['signFileDeatils']['fileNameSign'] = this.form.get('fileNameSign').value;
          this.firmwareDataList[this.applianceCount - 1]['firmwareUpgradeDetailModel']['signFileDeatils']['fileExtensionSign'] = this.form.get('fileExtensionSign').value;
        }

        /* ends, pushing each appliance into list*/
        if (this.applianceCount < this.selectedAppliances.length) {
          /* get the next appliance coLoginFailureCount, min & max password length values */
          this.applianceName = this.selectedAppliances[this.applianceCount]['applianceName'];
          this.form.reset();
          if (typeof this.firmwareDataList[this.applianceCount] != 'undefined') {
            this.setValuesToForm(this.applianceCount);
          }
          this.applianceCount++;
          this.showBackButton = true;
          
        } else {
          this.form.reset();
          this.showFinalFirmwareList = true;
        } 
    } 
  }


  setValuesToForm(backOperationCount) {
    // if (this.firmwareDataList[backOperationCount]['firmwareUpgradeDetailModel']['hsmFirmwareType'] == 1) {
    //   this.form.get('hsmFirmwareType').setValue(true);
    // } else {
    //   this.form.get('hsmFirmwareType').setValue(false);
    // }
    this.form.get('hsmFirmwareType').setValue(this.firmwareDataList[backOperationCount]['firmwareUpgradeDetailModel']['hsmFirmwareType']);
    if (this.firmwareDataList[backOperationCount]['firmwareUpgradeDetailModel']['zeroize']) {
      this.form.get('zeroize').setValue(true);
    } else {
      this.form.get('zeroize').setValue(false);
    }
    this.form.get('fileContent').setValue(this.firmwareDataList[backOperationCount]['firmwareUpgradeDetailModel']['imageFileDeatils']['fileContent']);
    this.form.get('fileName').setValue(this.firmwareDataList[backOperationCount]['firmwareUpgradeDetailModel']['imageFileDeatils']['fileName']);
    this.form.get('fileExtension').setValue(this.firmwareDataList[backOperationCount]['firmwareUpgradeDetailModel']['imageFileDeatils']['fileExtension']);
    this.form.get('fileContentSign').setValue(this.firmwareDataList[backOperationCount]['firmwareUpgradeDetailModel']['signFileDeatils']['fileContentSign']);
    this.form.get('fileNameSign').setValue(this.firmwareDataList[backOperationCount]['firmwareUpgradeDetailModel']['signFileDeatils']['fileNameSign']);
    this.form.get('fileExtensionSign').setValue(this.firmwareDataList[backOperationCount]['firmwareUpgradeDetailModel']['signFileDeatils']['fileExtensionSign']);
    this.form.get('fileValidate').setValue("true");
    this.form.get('fileValidateSign').setValue("true");  
  }


  pushApplianceDataIntoList() {
    let imageFileDeatils={}
    let signFileDeatils ={};
    let firmwareUpgradeDetailModel = {
      "imageFileDeatils":imageFileDeatils,
      "signFileDeatils": signFileDeatils
    };
    let firmwareData = {
      "firmwareUpgradeDetailModel":firmwareUpgradeDetailModel
    };
    if (this.form.get('hsmFirmwareType').value!=null) {
      firmwareData['firmwareUpgradeDetailModel']['hsmFirmwareType'] = this.form.get('hsmFirmwareType').value;
     } 
    //else {
    //   firmwareData['firmwareUpgradeDetailModel']['hsmFirmwareType'] = 0;
    // }
   
    if (this.form.get('zeroize').value == true) {
      firmwareData['firmwareUpgradeDetailModel']['zeroize'] = 1;
    } else {
      firmwareData['firmwareUpgradeDetailModel']['zeroize'] = 0;
    }


    firmwareData['firmwareUpgradeDetailModel']['imageFileDeatils']['fileContent'] = this.form.get('fileContent').value;
    firmwareData['firmwareUpgradeDetailModel']['imageFileDeatils']['fileName'] = this.form.get('fileName').value;
    firmwareData['firmwareUpgradeDetailModel']['imageFileDeatils']['fileExtension'] = this.form.get('fileExtension').value;
    firmwareData['firmwareUpgradeDetailModel']['signFileDeatils']['fileContentSign'] = this.form.get('fileContentSign').value;
    firmwareData['firmwareUpgradeDetailModel']['signFileDeatils']['fileNameSign'] = this.form.get('fileNameSign').value;
    firmwareData['firmwareUpgradeDetailModel']['signFileDeatils']['fileExtensionSign'] = this.form.get('fileExtensionSign').value;
    firmwareData['applianceName']=this.selectedAppliances[this.applianceCount - 1]['applianceName'];
    firmwareData['applianceId']=this.selectedAppliances[this.applianceCount - 1]['applianceId'];
    firmwareData['applianceStatus']=this.selectedAppliances[this.applianceCount - 1]['applianceStatus'];
    firmwareData['serialNumber']=this.selectedAppliances[this.applianceCount - 1]['serialNumber'];
    firmwareData['networkTimezone']=this.selectedAppliances[this.applianceCount - 1]['networkTimezone'];
    firmwareData['gatewayIp']=this.selectedAppliances[this.applianceCount - 1]['gatewayIp'];
    firmwareData['ipAddress']=this.selectedAppliances[this.applianceCount - 1]['ipAddress'];
    firmwareData['networkId']=this.selectedAppliances[this.applianceCount - 1]['networkId'];
    firmwareData['subnetMask']=this.selectedAppliances[this.applianceCount - 1]['subnetMask'];
    //this.setApplianceDetails(firmwareData);
    this.firmwareDataList.push(firmwareData);
  }
  
  backToPreviousAppliance() {
    debugger;
    this.form.reset();
    this.applianceName = this.selectedAppliances[this.applianceCount - 2]['applianceName'];
    let backOperationCount = this.applianceCount - 2;
    this.setValuesToForm(backOperationCount);
    this.applianceCount = this.applianceCount - 1;
    if (this.applianceCount == 1) {
      this.showBackButton = false;
    } 
    //this.initializeTabs.tabs[0].active = true;
    //this.tabName ="Initialize";
  }

   // Back Operation in Final list of appliance.
   backOperationFromFinalList() {
    debugger;
    this.form.reset();
    this.applianceName = this.firmwareDataList[this.applianceCount - 1]['applianceName'];
    this.setValuesToForm(this.applianceCount - 1);
    if (this.applianceCount == 1) {
      this.showBackButton = false;
    } else {
      this.showBackButton = true;
    }
    this.showFinalFirmwareList = false;
  }

  /* Remove appliance from the final list */
  removeAppliance(applianceId) {
    debugger;
    let selectedIds = [];
    selectedIds.push(applianceId);
    this.firmwareDataList = this.firmwareDataList.filter(
      val => !selectedIds.includes(val.applianceId));
    this.selectedAppliances = this.selectedAppliances.filter(
      val => !selectedIds.includes(val.applianceId));
    this.applianceCount = this.applianceCount - 1;
    this.totalAppliance = this.firmwareDataList.length;
  }
  
  closeFirwareUpgradeModal() {
    this.firmwareUpgradeModal.hide();
    this.clearData();
  }

  clearData() {
    this.form.reset();
    this.form.get('hsmFirmwareType').setValue('appliance');
    this.applianceName = "";
    this.performZeroizeChecked = false;
    this.applianceChecked = false;
    this.fipsAdapterChecked = false;
    this.showFinalFirmwareList = false;
    this.firmwareDataList = [];
    this.uploader = new FileUploader({url: URL});
  }

  togglePerformZeroize($event) {
    if ($event.checked) {
      this.performZeroizeChecked = true;
    } else {
      this.performZeroizeChecked = false;
    }
  }

  toggleAppliance($event){
    if ($event.checked) {
      this.applianceChecked = true;
    } else {
      this.applianceChecked = false;
    }
  }

  toggleFIPSAdapter($event){
    if ($event.checked) {
      this.fipsAdapterChecked = true;
    } else {
      this.fipsAdapterChecked = false;

    }
  }

  showPerformFips(){
    this.showPerformFIPS = true;
  }

  hidePerformFips(){
    this.showPerformFIPS =false;
    this.form.get('zeroize').setValue(false);
  }


  onFileSelected(event){
    debugger;
    const filePicked = (event.target as HTMLInputElement).files[0];
    if(filePicked!=undefined){
      const fileName = filePicked.name;
      //this.form.get('fullName').setValue(fileName);
      const extension  =filePicked.name.split('.').pop() || filePicked.name;
     
      const reader = new FileReader();
      reader.onload = () => {
        if(extension == 'jpg'){
          this.form.get('fileContentSign').setValue(reader.result);
          if(this.form.get('fileContentSign').value!=null){
            this.form.get('fileValidateSign').setValue("true");
          }else {
            this.form.get('fileValidateSign').setValue("false");
          }
          this.form.get('fileNameSign').setValue(fileName.substring(0, fileName.indexOf('.')));
          this.form.get('fileExtensionSign').setValue(filePicked.name.split('.').pop() || filePicked.name);
        }else{
          this.form.get('fileContent').setValue(reader.result);
          if(this.form.get('fileContent').value!=null){
            this.form.get('fileValidate').setValue("true");
          }else {
            this.form.get('fileValidate').setValue("false");
          }
          this.form.get('fileName').setValue(fileName.substring(0, fileName.indexOf('.')));
          this.form.get('fileExtension').setValue(filePicked.name.split('.').pop() || filePicked.name);
        }
      };
      reader.readAsText(filePicked);
    }else {
     // this.form.get('fullName').setValue(null);
      this.form.get('fileName').setValue("");
      this.form.get('fileExtension').setValue("");
      this.form.get('fileContent').setValue("");
      this.form.get('fileValidate').setValue("false");
      this.form.get('fileNameSign').setValue("");
      this.form.get('fileExtensionSign').setValue("");
      this.form.get('fileContentSign').setValue("");
      this.form.get('fileValidateSign').setValue("false");
      return false;
    }  
  }

  submitFirmwareUpgrade() {
    debugger;
    this.loading = true;
    this._applianceManagementService.firmwareUpgrade(this.firmwareDataList).subscribe((res) => {
      if (res.length > 0) {
        debugger;
        this.loading = false;
        let displaymsg: string = '';
        this.firmwareUpgradeModal.hide();
        res.forEach(obj => {
          if (displaymsg == '') {
            displaymsg = "<b>" + obj.applianceName + "</b>&nbsp;:-- " + obj["message"] + "<br>";
          } else {
            displaymsg = displaymsg + "<b>" + obj.applianceName + "&nbsp;</b>:-- " + obj["message"] + "<br>";
          }
        });
        this.clearData();
        bootbox.dialog({
          message: displaymsg,
          buttons: {
            Ok: {
              label: "Close",
              className: 'btn btn-primary btn-flat',
              callback: () => this.callBack()
            }
          }
        });
        // this.initializeDataList = [];
        // this.form.reset();
      }
    }, (err) => {
      console.log(err);
    })
  }

  callBack() {
    this.messageEvent.emit();
  }
  
}
