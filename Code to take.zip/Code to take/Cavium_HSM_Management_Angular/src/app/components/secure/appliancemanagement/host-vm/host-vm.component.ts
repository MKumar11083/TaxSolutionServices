import { Component, OnInit, ViewChild, AfterViewInit, AfterViewChecked } from '@angular/core';
import  { ChartsModule,  Color }  from  'ng2-charts';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { AdminVmComponent } from './../admin-vm/admin-vm.component';
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, FormControl } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
declare var $: any;
declare var Highcharts: any;
declare var chart: any;
declare var bootbox: any;
declare var Chart: any;

@Component({
  selector: 'app-host-vm',
  templateUrl: './host-vm.component.html',
  styleUrls: ['./host-vm.component.css']
})
export class HostVmComponent implements OnInit {
  successMessage ='';
  errorMessages = [];
  form: FormGroup;
  loginForm: FormGroup;
  monitorLoginForm :FormGroup;  
  
  //network and snmp
  network:any = [];
  snmp:any = [];
  status:any=[];
  trapStatus:any=[];
  username:any=[];
  managerIp:any=[];
  obj:any=[];
  obj1:any=[];
  objMemoryDetails:any=[];
  objPCPU:any=[];
  networkObj:any=[];

  
  @ViewChild('adminVmComponent')
  private adminVmComponent: AdminVmComponent;
  resourceUsage: any = [];
  hostInfo: any = [];
  adapterInfo: any = [];
  stats: any = [];
  memoryUsage:any=[];
  //memoryDetails:any[];
  pcpuDetails:any[];
  cpuDetails:any[];
  showlist: boolean = true;
  showlist1: boolean = true;
  showlist2: boolean = true;
  gaugeType = "arch";
  gaugeThickness = 25;
  staticIpToHostConfigUpdated:object[]=[];
  submitApplianceNewtorkData={};
  applianceModel:any=[];
  ipAddressAdd:any;
  HostnameAdd:any;
  AliasAdd:any;
  showPopUp=false;
  public loading = false;
  memoryUsageGraph:object[]=[];
  cpuGraph:object[]=[];
  memoryDetails:object[]=[];
  memoryUsageGraphnew:object[]=[];
  memoryUsageGraphMemory:object[]=[];
  PCPUDetails:object[]=[];
  t1=[];
  memoryArray:object[]=[];
  swapArray:object[]=[];
  lineChartData9:any;
  lineChartData10:any;
  lineChartData11:any;
  lineChartData12:any;
  getNetworkDetails1:object[]=[];

  
  gaugeThresholdConfig = {
    '0': { color: 'rgb(0,179,30' },
    '60': { color: 'rgb(230,191,0' },
    '80': { color: 'rgb(204,0,0' }
  };
  gaugeAppendText = "%";

  // hostVM gauge
  gaugeValue = [];
  gaugeValue1 = [];
  gaugeValue2 = [];
  gaugeValue3 = [];
  public temp: any[] = [[25, 22]];
  constructor(private _applianceManagementService: AppliancemanagementService,
    private _route: ActivatedRoute, private builder: FormBuilder, 
    private _fieldErrorDisplayService: FieldErrorDisplayService) { }
  applianceId: string;
  applianceName: string;
  applianceObj: any;
  applianceObjAdvanced:object[]=[];
  applianceObjAdvancedDup:object[]=[];
  appAdd:object[]=[];
  getApplianceAdvancedData:any;
  saveModalFlag=false;
  hourMinutesArray=[];
  bufferMem=null;
  buffSwap=null;
  CacheSwap=null;
  freeSwap=null;
  totalSwap=null;
  usedSwap=null;
CacheMem=null;
  freeMem=null;
totalMem=null
usedMem=null;
usageArray=null;
memUsageArray=null;
pidCPUArray=null;
memoryDetailsCPUusageArray=null;
memoryDetailsMemoryArray=null;
memoryDetailsPIDUsageArray=null;
memoryDetailsCPUusageArray1=null;
memoryDetailsMemoryArray1=null;
memoryDetailsPIDUsageArray1=null;
PCPUDetailsPercentageArray=null;
PCPUDetailsNThreadArray=null;
PCPUDetailsPercentageArray1=null;
PCPUDetailsNThreadArray1=null;
PCPUDetailsUsageArray=null;
PCPUDetailsCPU=null;

pcdArray:object[]=[]; 
qemuArray:object[]=[];
memorDetails1:object[]=[];
memorDetails12:object[]=[];
PCPUDetails1:object[]=[];
PCPUDetails2:object[]=[];

  ngOnInit() {
    debugger;
    this.loading=true;
    this.createForm();
    this.createLoginForm();
    this.createMonitorLoginForm();    
    //this.saveMonitorUserData(); 
   
    this.applianceId = "";
    this._route.params.subscribe(params => {
      this.applianceId = params['applianceId'];
      this.applianceName = params['applianceName'];
    });
    this._applianceManagementService.getHostSystemInfo(this.applianceId).subscribe(
      res => {
        this.resourceUsage = res.partitionsDetails;
        this.hostInfo = res.applianceInfo;
        this.adapterInfo = res.hsmInfo;
        this.stats = res.hostStats;
        this.applianceObj = res.adminVMConfig;
        this.applianceModel=res.applianceDetailModel; 
        this.applianceModel["partitionDetailModels"]=null;
        this.getApplianceAdvancedData=res["adminVMConfig"]["adminVMData"]["advanced"]["staticIpToHostConfig"];
        console.log(this.applianceObj);
       // this.applianceObj.adminVMData["advanced"]["staticIpToHostConfig"][0]
        for(var i=0;i<this.getApplianceAdvancedData.length;i++){
           this.applianceObjAdvanced.push(this.getApplianceAdvancedData[i]);
           this.applianceObjAdvancedDup.push(this.getApplianceAdvancedData[i]);
           
        }
       for(var i=0;i<this.applianceObjAdvancedDup.length;i++){
         this.applianceObjAdvancedDup[i]["color"]="Green";

       }
        
        this.form.get("dhcp").setValue(this.applianceObj.adminVMData.general.dhcp);
        this.form.get("ipAddress").setValue(this.applianceObj.adminVMData.general.ip);
        this.form.get("gatewayIp").setValue(this.applianceObj.adminVMData.general.gateway);
        this.form.get("subnetMask").setValue(this.applianceObj.adminVMData.general.subnet);
        this.form.get("hostName").setValue(this.applianceObj.adminVMData.general.hostname);
        this.form.get("vLanId").setValue(this.applianceObj.adminVMData.general.vlan);
        this.form.get("macAddress").setValue(this.applianceObj.adminVMData.general.macAddress);
        this.form.get("staticMac").setValue(this.applianceObj.adminVMData.general.macStatic);
        this.form.get("dnsService").setValue(this.applianceObj.adminVMData.advanced.enableDNSService);
       

        if (this.stats != null) {
          if (this.stats.dataObject != null) {
            if (this.stats.dataObject.vmstatsObject != null) {
              this.gaugeValue = this.stats.dataObject.vmstatsObject.cpuUsage;
            }
          }
        }
        if (this.stats != null) {
          if (this.stats.dataObject != null) {
            if (this.stats.dataObject.vmstatsObject != null) {
              if (this.stats.dataObject.vmstatsObject.ramStats != null) {
                this.gaugeValue2 = this.stats.dataObject.vmstatsObject.ramStats.usedPercentage;
              }
            }
          }
        }
        if (this.stats != null) {
          if (this.stats.dataObject != null) {
            if (this.stats.dataObject.vmstatsObject != null) {
              if (this.stats.dataObject.vmstatsObject.swapStats != null) {
                this.gaugeValue3 = this.stats.dataObject.vmstatsObject.swapStats.usedPercentage;
              }
            }
          }
        }

       
        this.doughnutChartData.push(this.resourceUsage.occupiedKeys);
        this.doughnutChartData.push(this.resourceUsage.freeKeys);

        this.doughnutChartData1.push(this.resourceUsage.occupiedAcclrDev);
        this.doughnutChartData1.push(this.resourceUsage.freeAcclrDev);

        this.doughnutChartData2.push(this.resourceUsage.occupiedContexts);
        this.doughnutChartData2.push(this.resourceUsage.freeContexts);

        //response.forEach(element => {
        //   console.log(element);

      },
      error => {
        console.log(error);
      },
    );

    // network and snmp pane start

    console.log(this.applianceId);
    this._applianceManagementService.getAdminVMInfo(this.applianceId).subscribe(
      res => {
    
        this.network = res.adminVMConfig;
        console.log("hello adminVM", this.network); 
        this.snmp = res.adminSNMPConfig;
        console.log("hello adminVM", this.snmp); 

        if(this.snmp!=null){
          if(this.snmp.adminSNMPData!=null){
            if(this.snmp.adminSNMPData.uname==null){
              this.username='';
            }
          }
        }
        if(this.snmp!=null){
          if(this.snmp.adminSNMPData!=null){
            if(this.snmp.adminSNMPData.ip==null){
              this.managerIp='';
            }
          }
        }

        if(this.snmp!=null){
          if(this.snmp.adminSNMPData!=null){
            if(this.snmp.adminSNMPData.enabled==false){
              this.status="Disabled";
            }
            else if(this.snmp.adminSNMPData.enabled==true){
              this.status="Enabled";
            }
          }
        }

        if(this.snmp!=null){
          if(this.snmp.adminSNMPData!=null){
            if(this.snmp.adminSNMPData.enableTrap==false){
              this.trapStatus="Disabled";
            } 
            else if(this.snmp.adminSNMPData.enableTrap==true){
              this.trapStatus="Enabled";
            }         
          }
        }

       
      }
    )

    

  }
  
 
 // Monitor login form

getmsg='';
flag: boolean = false;
setMonitorData(){
  // alert("hi");
  console.log("hii");
 this.memoryUsageGraph=[];
  this.cpuGraph=[];
  this.memoryDetails=[];

  this.obj=[];
  this.memoryArray=[];
  this.swapArray=[];
this.bufferMem=null;
this.CacheMem=null;
this.freeMem=null;
this.totalMem=null;
this.usedMem=null;
  debugger;
$("#myModal1").modal("hide");

this.applianceModel["applianceId"]=this.applianceId;
this.monitorLoginForm.reset();
this.monitorLoginForm.get('applianceId').setValue(this.applianceId);
this._applianceManagementService.monitorLoginForm(this.applianceModel).subscribe((res) => 
   {

     let dataMonitorStat=res;
     // dataMonitorStat.data will get all the objects    
   console.log(res);
   for(var i=0;i<dataMonitorStat.length;i++){

    this.hourMinutesArray.push(dataMonitorStat[i]["hoursminutes"]);
      this.memoryUsageGraph.push(dataMonitorStat[i].usage);
      this.cpuGraph.push(dataMonitorStat[i].usageInfo);
      this.memoryDetails.push(dataMonitorStat[i].details);
      this.PCPUDetails.push(dataMonitorStat[i].info);
      //this.getNetworkDetails1.push(dataMonitorStat[i].data.network);

      

     
     var t1=this.memoryUsageGraph;
    }//Network Usage Graph

    
 

//Network Usage Graph end here
//PCPU Graph object Creation
for(var i=0;i<this.PCPUDetails.length;i++){

  this.objPCPU.push(this.PCPUDetails[i]);
}

for(var b=0;b<this.objPCPU.length;b++){

  for(var q=0;q<this.objPCPU[b].length;q++){

    if(this.objPCPU[b][q]["name"]=="qemu-system-x86_64"){
     this.PCPUDetails1.push(this.objPCPU[b][q]);
   
    }
    if(this.objPCPU[b][q]["name"]=="pcd"){
      this.PCPUDetails2.push(this.objPCPU[b][q]);

    }
  }
}
var barlabels=this.hourMinutesArray.map(item=>item);
this.PCPUDetailsPercentageArray1=this.PCPUDetails2.map(item=>item["cpuPercent"]);
this.PCPUDetailsNThreadArray1=this.PCPUDetails2.map(item=>item["nThread"]);
this.PCPUDetailsPercentageArray=this.PCPUDetails1.map(item=>item["cpuPercent"]);
this.PCPUDetailsNThreadArray=this.PCPUDetails1.map(item=>item["nThread"]);
//this.PCPUDetailsUsageArray=this.PCPUDetails1.map(item=>item[""])

this.lineChartData12 = new Chart(document.getElementById("PCPU-bar"), {
  type: 'line',
  data: {
    labels: barlabels,
    datasets: [
      
      {
        label: "CPU-Percent(qemu-system-x86_64)",
        backgroundColor: 'rgba(0,149,179,0)',
        borderColor: 'rgba(211, 111, 231,1)', 
        data: this.PCPUDetailsPercentageArray
      }, {
        label: "N-Thread(qemu-system-x86_64)",
       
        backgroundColor: 'rgba(0,149,179,0)',
        borderColor: 'rgba(230, 155, 117,1)', 
        data: this.PCPUDetailsNThreadArray
      },
      {
        label: "CPU-Percent(pcd)",
       
        backgroundColor: 'rgba(0,149,179,0)',
        borderColor: 'rgba(230, 155, 117,1)', 
        data: this.PCPUDetailsNThreadArray
      },
      {
        label: "N-Thread(pcd)",
       
        backgroundColor: 'rgba(0,149,179,0)',
        borderColor: 'rgba(230, 155, 117,1)', 
        data: this.PCPUDetailsNThreadArray
      }
    ]
    
  },
  options: {

    title: {
      display: true,
      text: ''
    },
    scales: {
      xAxes: [{
        stacked: true, // this should be set to make the bars stacked
        barPercentage: 0.4
      }],
      yAxes: [{
        stacked: true // this also..
      }]
    }
    // scales: {
    //   yAxes: [{
    //     scaleLabel: {
    //       display: true,
    //       labelString: "",
    //       gridLines: {
    //         drawBorder: true,
    //       },
    //     }
    //   }],
    //   xAxes: [{
    //     barPercentage: 0.9,
    //     scaleLabel: {
    //       display: true,
    //       labelString: ""
    //     }
    //   }]
    // }
  }
});
//End of PCPU Graph 

  for(var i=0;i<this.memoryDetails.length;i++){

    this.objMemoryDetails.push(this.memoryDetails[i]);
  }

  for(var i=0;i<this.objMemoryDetails.length;i++){
for(var t=0;t<this.objMemoryDetails[i].length;t++){

  if(this.objMemoryDetails[i][t]["command"]=="qemu-system-x86_64"){
  this.memorDetails1.push(this.objMemoryDetails[i][t]);

  }
  if(this.objMemoryDetails[i][t]["command"]=="python"){
    this.memorDetails12.push(this.objMemoryDetails[i][t]);
  
    }
  
}

  }
  var barlabels=this.hourMinutesArray.map(item=>item);
  this.memoryDetailsCPUusageArray=this.memorDetails1.map(item=>item["cpu"]);
  this.memoryDetailsMemoryArray=this.memorDetails1.map(item=>item["mem"]);
  this.memoryDetailsPIDUsageArray=this.memorDetails1.map(item=>item["pid"]);
  this.memoryDetailsCPUusageArray1=this.memorDetails12.map(item=>item["cpu"]);
  this.memoryDetailsMemoryArray1=this.memorDetails12.map(item=>item["mem"]);
  this.memoryDetailsPIDUsageArray1=this.memorDetails12.map(item=>item["pid"]);

  this.lineChartData11 = new Chart(document.getElementById("processMemory-bar"), {
    type: 'line',
    data: {
      labels: barlabels,
      datasets: [
        
        {
          label: "CPU(qemu-system-x86_64)",
          backgroundColor: 'rgba(0,149,179,0)',
          borderColor: 'rgba(223, 122, 90,1)', 
          data: this.memoryDetailsCPUusageArray
        }, {
          label: "Memory(qemu-system-x86_64)",
          backgroundColor: 'rgba(0,149,179,0)',
        borderColor: 'rgba(118, 198, 55,1)', 
          data: this.memoryDetailsMemoryArray
        },
        {
          label: "PID(qemu-system-x86_64)",
          backgroundColor: 'rgba(0,149,179,0)',
          borderColor: 'rgba(44, 105, 116,1)', 
          data: this.memoryDetailsPIDUsageArray
        },

        {
          label: "CPU(python)",
          backgroundColor: 'rgba(0,149,179,0)',
          borderColor: 'rgba(223, 122, 90,1)', 
          data: this.memoryDetailsCPUusageArray1
        }, {
          label: "Memory(python)",
          backgroundColor: 'rgba(0,149,179,0)',
        borderColor: 'rgba(118, 198, 55,1)', 
          data: this.memoryDetailsMemoryArray1
        },
        {
          label: "PID(python)",
          backgroundColor: 'rgba(0,149,179,0)',
          borderColor: 'rgba(44, 105, 116,1)', 
          data: this.memoryDetailsPIDUsageArray1
        }
      ]
      
    },
    options: {
  
      title: {
        display: true,
        text: ''
      },
      scales: {
        xAxes: [{
          stacked: true, // this should be set to make the bars stacked
          barPercentage: 0.4
        }],
        yAxes: [{
          stacked: true // this also..
        }]
      }
      // scales: {
      //   yAxes: [{
      //     scaleLabel: {
      //       display: true,
      //       labelString: "",
      //       gridLines: {
      //         drawBorder: true,
      //       },
      //     }
      //   }],
      //   xAxes: [{
      //     barPercentage: 0.9,
      //     scaleLabel: {
      //       display: true,
      //       labelString: ""
      //     }
      //   }]
      // }
    }
  });

  //CPU Graph starts here

   for(var r=0;r<this.cpuGraph.length;r++){
     this.obj1.push(this.cpuGraph[r]);

   } 

for(var i=0;i<this.memoryUsageGraph.length;i++){

    
  this.obj.push(this.memoryUsageGraph[i]);

}

//cpu Usage
for(var j=0;j<this.obj1.length;j++){
  for(var k=0;k<this.obj1[j].length;k++){

    console.log(this.obj[j][k]);
    if(this.obj1[j][k]["command"]=="pcd"){
      this.pcdArray.push(this.obj1[j][k]);
  
  
    }
    if(this.obj1[j][k]["command"]=="qemu-system-x86_64"){
      this.qemuArray.push(this.obj1[j][k]);
  
  
    }
    
  }

}
var barlabels=this.hourMinutesArray.map(item=>item);
this.usageArray=this.qemuArray.map(item=>item["usage"]);
this.memUsageArray=this.qemuArray.map(item=>item["memUsage"]);
this.pidCPUArray=this.qemuArray.map(item=>item["pid"]);

this.lineChartData10 = new Chart(document.getElementById("CPU-bar"), {
  type: 'line',
  data: {
    labels: barlabels,
    datasets: [
      {
        label: "Usage",
        
        backgroundColor: 'rgba(0,149,179,0)',
        borderColor: 'rgba(88, 187, 84,1)', 
        data: this.usageArray
      }, {
        label: "Memory Usage",
        
        backgroundColor: 'rgba(0,149,179,0)',
        borderColor: 'rgba(285, 189, 187,1)',
        data: this.memUsageArray
      },
      {
        label: "PID",
       
        backgroundColor: 'rgba(0,149,179,0)',
        borderColor: 'rgba(248, 228, 88,1)',
       data: this.pidCPUArray
      }
    ]
    
  },
  options: {

    title: {
      display: true,
      text: ''
    },
    scales: {
      xAxes: [{
        stacked: false, // this should be set to make the bars stacked
        barPercentage: 0.5
      }],
      yAxes: [{
        stacked: true // this also..
      }]
    }
    // scales: {
    //   yAxes: [{
    //     scaleLabel: {
    //       display: true,
    //       labelString: "",
    //       gridLines: {
    //         drawBorder: true,
    //       },
    //     }
    //   }],
    //   xAxes: [{
    //     barPercentage: 0.9,
    //     scaleLabel: {
    //       display: true,
    //       labelString: ""
    //     }
    //   }]
    // }
  }
});

//monitor Usage
for(var j=0;j<this.obj.length;j++)
{
for(var k=0;k<this.obj[j].length;k++){

  console.log(this.obj[j][k]);
  if(this.obj[j][k]["name"]=="Memory"){
    this.memoryArray.push(this.obj[j][k]);

  }
  if(this.obj[j][k]["name"]=="Swap"){
    this.swapArray.push(this.obj[j][k]);

  }
  
}

  //console.log(this.obj[j]);
}
  this.buffSwap=this.swapArray.map(item=>item["buffers"]);
this.CacheSwap=this.swapArray.map(item=>item["cache"]);
this.freeSwap=this.swapArray.map(item=>item["free"]);
this.totalSwap=this.swapArray.map(item=>item["total"]);
this.usedSwap=this.swapArray.map(item=>item["used"]);
   var barlabels=this.hourMinutesArray.map(item=>item);
  this.bufferMem=this.memoryArray.map(item=>item["buffers"]);
  this.CacheMem=this.memoryArray.map(item=>item["cache"]);
  this.freeMem=this.memoryArray.map(item=>item["free"]);
  this.totalMem=this.memoryArray.map(item=>item["total"]);
  this.usedMem=this.memoryArray.map(item=>item["used"]);

  this.lineChartData9 = new Chart(document.getElementById("topology-bar"), {
    type: 'line',
    data: {
      labels: barlabels,
      datasets: [
        {
          label: "Buffer-Memory",
          backgroundColor: "rgb(64, 197, 64)",
          data: this.bufferMem
        }, {
          label: "Cache-Memory",
          backgroundColor: "rgba(235, 109, 107, 0.911)",
          data: this.CacheMem
        },
        {
          label: "Free - Memory",
          backgroundColor: "rgba(247, 220, 67, 0.911)",
          data: this.freeMem
        },
        {
          label: "Buffer - Swap",
          backgroundColor: "rgba(255, 66,77, 0.911)",
          data: this.buffSwap
        },
        {
          label: "Cache-Swap",
          backgroundColor: "rgba(290,086,255, 0.911)",
          data: this.CacheSwap
        },
        {
          label: "Free - Swap",
          backgroundColor: "rgba(8, 81,199, 0.911)",
          data: this.freeSwap
        }
        
      ]
      
    },
    options: {

      title: {
        display: true,
        text: ''
      },
      scales: {
        xAxes: [{
          stacked: true, // this should be set to make the bars stacked
          barPercentage: 0.4
        }],
        yAxes: [{
          stacked: true // this also..
        }]
      }
      // scales: {
      //   yAxes: [{
      //     scaleLabel: {
      //       display: true,
      //       labelString: "",
      //       gridLines: {
      //         drawBorder: true,
      //       },
      //     }
      //   }],
      //   xAxes: [{
      //     barPercentage: 0.9,
      //     scaleLabel: {
      //       display: true,
      //       labelString: ""
      //     }
      //   }]
      // }
    }
  });

  

   
    
   //if (dataMonitorStat.data != null) {
  
    // for(var i=0;i<dataMonitorStat.length;i++){
    //   this.hourMinutesArray.push(dataMonitorStat[i].hoursminutes);
    //   for(var j=0;j<dataMonitorStat[i].memory.usage.length;j++){
    //     this.memoryUsageGraph.push(dataMonitorStat[i].memory.usage[j]);

        
    //   }
    
    

    // }

    
  
  //   if (dataMonitorStat.data.memory!= null) {
  //     if (dataMonitorStat.data.memory.usage != null) {
  //       this.memoryUsage = dataMonitorStat.data.memory.usage;
  //     }
  //   }
  // }
  //  if (dataMonitorStat.data != null) {
  //   if (dataMonitorStat.data.memory!= null) {
  //    if (dataMonitorStat.data.memory.details!= null) {
  //       this.memoryDetails = dataMonitorStat.data.memory.details;
  //      for(var i=0;i<this.memoryDetails.length;i++){

  //        this.memoryDetails[i]['checked']=true;
  //     }
  //    }
  //   }
  // }
  // if (dataMonitorStat.data != null) {
  //   if (dataMonitorStat.data.pcpu!= null) {
  //     if (dataMonitorStat.data.pcpu.info!= null) {
  //       this.pcpuDetails= dataMonitorStat.data.pcpu.info ;
  //       for(var i=0;i<this.pcpuDetails.length;i++){

  //         this.pcpuDetails[i]['checked']=true;
  //       }
  //     }
  //   }
  // }
  // if (dataMonitorStat.data != null) {
  //   if (dataMonitorStat.data.cpu!= null) {
  //     if (dataMonitorStat.data.cpu.usageInfo!= null) {
  //       this.cpuDetails= dataMonitorStat.data.cpu.usageInfo ;
  //       for(var i=0;i<this.cpuDetails.length;i++){

  //         this.cpuDetails[i]['checked']=true;
  //       }
  //     }
  //   }
  // }
  },
  error => {
    console.log(error); 
  },

)
}
saveMonitorUserData(){
  this.setMonitorData()

  
}

createMonitorLoginForm(){
   this.monitorLoginForm = this.builder.group({
     operationUsername: ['', Validators.required],
     operationPassword: ['', Validators.required],
     applianceId: ['']
   });
}

public formMonitorValidationFields1 = {
   "operationUsername": '',
   "operationPassword": ''
   
 }

isMonitorFieldValid1(field: string) {
   if (this.monitorLoginForm.get(field).touched) {
     this.formMonitorValidationFields1 = this._fieldErrorDisplayService.validateField(this.monitorLoginForm, field, this.formMonitorValidationFields1, "monitorlogin")
   }
   return !this.monitorLoginForm.get(field).valid && this.monitorLoginForm.get(field).touched;
}

monitorDisplayFieldCss1(field: string) {
   return {
     'has-error': this.isMonitorFieldValid1(field),
     'has-feedback': this.isMonitorFieldValid1(field)
   };
}
closeMonitorLoginModal1() {
   this.applianceName = '';
   this.monitorLoginForm.reset();
   $("#myModal1").modal("hide");
}

//monitor login form ends

  hostToggle() {
    this.showlist = true;
  }
  adminToggle() {
    this.showlist = false;
  }

  systemToggle() {
    this.showlist1 = true;
  }
  monitorToggle() {
    this.saveMonitorUserData();
   // this.monitorLoginForm.reset();
    //$("#myModal1").modal("show");
    this.showlist1 = false;
    this.flag = true;
    // this.showAreaChart();
  }

  //Doughnut
  public doughnutChartData: number[] = [];
  public doughnutChartData1: number[] = [];
  public doughnutChartData2: number[] = [];
  public doughnutChartType: string = 'doughnut';
  public doughnutChartLabels: string[] = ['Used', 'Available'];
  public  chartOptions  =  {
    responsive:  true,
    legend:  {
      display:  true,
      position:  'bottom',
      labels: {
        boxWidth:  10
      }
    }
  };
  public  mycolors:  Array<Color>  =  [
    {
      backgroundColor: [
        //'rgba(244, 99, 132, 0.8)',
        //'rgba(64, 162, 235, 0.8)',
        // 'rgba(255, 206, 86, 0.8)',
        // 'rgba(70, 192, 192, 0.8)',
        // 'rgba(287, 159, 64, 0.8)',
        // 'rgba(153, 102, 255, 0.8)',
        'rgb(247, 113, 131)',
        'rgb(84, 198, 233)'],
      hoverBackgroundColor:  ['rgb(247, 113, 131)', 'rgb(84, 198, 233)'],
    }
  ];

  // events
  public chartClicked(e: any): void {
    console.log(e);
  }

  public chartHovered(e: any): void {
    console.log(e);
  }

  // // lineChart1
  // public lineChartData: Array<any> = [
  //   { data: [18, 48, 77, 9, 100, 27, 40], label: 'Series A' },
  //   { data: [28, 48, 40, 19, 86, 27, 90], label: 'Series B' },
  // ];
  // public lineChartLabels: Array<any> = ['16:10', '16:20', '16:30', '16:40', '16:50', '17:00', '17:20'];
  // public lineChartOptions: any = {
  //   responsive: true,
  //   legend:  {
  //     display:  true,
  //     position:  'bottom'
  //   }
  // };
  // public lineChartColors: Array<any> = [
  //   { // red
  //     backgroundColor: 'rgba(255,255,255,0)',
  //     borderColor: 'rgba(255,51,85,1)',
  //     pointBackgroundColor: 'rgba(255,51,85,1)',
  //     pointBorderColor: '#fff',
  //     pointHoverBackgroundColor: '#fff',
  //     pointHoverBorderColor: 'rgba(255,51,85,0.8)'
  //   },

  //   { // blue
  //     backgroundColor: 'rgba(255,255,255,0.2)',
  //     borderColor: 'rgba(0,170,204,1)',
  //     pointBackgroundColor: 'rgba(0,170,204,1)',
  //     pointBorderColor: '#fff',
  //     pointHoverBackgroundColor: '#fff',
  //     pointHoverBorderColor: 'rgba(0,170,204,1)'
  //   },

  // ];
  // public lineChartLegend: boolean = true;
  // public lineChartType: string = 'line';

  // // events
  // public chartClicked1(e: any): void {
  //   console.log(e);
  // }

  // public chartHovered1(e: any): void {
  //   console.log(e);
  // }

  // // lineChart2
  // public lineChartData2: Array<any> = [
  //   { data: [18, 48, 77, 9, 100, 27, 40], label: 'Series A' },
  //   { data: [28, 48, 40, 19, 86, 27, 90], label: 'Series B' },
  // ];
  // public lineChartLabels2: Array<any> = ['16:10', '16:20', '16:30', '16:40', '16:50', '17:00', '17:20'];
  // public lineChartOptions2: any = {
  //   responsive: true,
  //   legend:  {
  //     display:  true,
  //     position:  'bottom'
  //   }
  // };
  // public lineChartColors2: Array<any> = [
  //   { // red
  //     backgroundColor: 'rgba(255,255,255,0)',
  //     borderColor: 'rgba(255,51,85,1)',
  //     pointBackgroundColor: 'rgba(255,51,85,1)',
  //     pointBorderColor: '#fff',
  //     pointHoverBackgroundColor: '#fff',
  //     pointHoverBorderColor: 'rgba(255,51,85,0.8)'
  //   },

  //   { // blue
  //     backgroundColor: 'rgba(255,255,255,0.2)',
  //     borderColor: 'rgba(0,170,204,1)',
  //     pointBackgroundColor: 'rgba(0,170,204,1)',
  //     pointBorderColor: '#fff',
  //     pointHoverBackgroundColor: '#fff',
  //     pointHoverBorderColor: 'rgba(0,170,204,1)'
  //   },

  // ];
  // public lineChartLegend2: boolean = true;
  // public lineChartType2: string = 'line';

  // // events
  // public chartClicked2(e: any): void {
  //   console.log(e);
  // }

  // public chartHovered2(e: any): void {
  //   console.log(e);
  // }

  // lineChart3 process memory stats
  public lineChartData3: Array<any> = [
    { data: [12,25,28,15,36,45,18], label: 'Series A' },
    { data: [28, 48, 40, 19, 86, 27, 60], label: 'Series B' },
  ];

  public lineChartLabels3: Array<any> = ['18:10', '18:20', '18:30', '18:40', '18:50', '19:00', '19:10'];
  
  public lineChartOptions3: any = {
    responsive: true,
    legend:  {
      display:  true,
      position:  'bottom'
    }
  };
  public lineChartColors3: Array<any> = [
    { // blue
      backgroundColor: 'rgba(0,149,179,0)',
      borderColor: 'rgba(0,149,179,1)',
      pointBackgroundColor: 'rgba(0,149,179,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(0,149,179,0.8)'
    },
    { // yellow
      backgroundColor: 'rgba(230,230,0,0)',
      borderColor: 'rgba(230,230,0,1)',
      pointBackgroundColor: 'rgba(230,230,0,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(230,230,0,1)'
    },

  ];
  public lineChartLegend3: boolean = true;
  public lineChartType3: string = 'line';

  // events
  public chartClicked3(e: any): void {
    console.log(e);
  }

  public chartHovered3(e: any): void {
    console.log(e);
  }

  // lineChart4 PCPU
  public lineChartData4: Array<any> = [
     { data: [18, 48, 77, 9, 100, 27, 40], label: 'Series A' },
     { data: [28, 48, 40, 19, 86, 27, 90], label: 'Series B' },
    ];
  public lineChartLabels4: Array<any> = ['0', '3', '9', '12', '15', '18', '21','24'];
  public lineChartOptions4: any = {
    responsive: true,
    legend:  {
      display:  true,
      position:  'bottom'
    }
  };
  public lineChartColors4: Array<any> = [
    { // blue
      backgroundColor: 'rgba(0,149,179,0)',
      borderColor: 'rgba(0,149,179,1)',
      pointBackgroundColor: 'rgba(0,149,179,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(0,149,179,0.8)'
    },
    { // yellow
      backgroundColor: 'rgba(230,230,0,0)',
      borderColor: 'rgba(230,230,0,1)',
      pointBackgroundColor: 'rgba(230,230,0,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(230,230,0,1)'
    },

    { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
    },

    { //green
      backgroundColor: 'rgba(34,204,0,0)',
      borderColor: 'rgba(34,204,0,1)',
      pointBackgroundColor: 'rgba(34,204,0,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(34,204,0,0.8)'
    },

  ];
  public lineChartLegend4: boolean = true;
  public lineChartType4: string = 'line';

  // events
  public chartClicked4(e: any): void {
    console.log(e);
  }

  public chartHovered4(e: any): void {
    console.log(e);
  }

  // lineChart5
  public lineChartData5: Array<any> = [
    { data: [25, 40, 30, 81, 56, 55, 40], label: 'Outgoing' },
    { data: [12, 20, 15, 18, 25, 15, 26], label: 'Incoming' },
    {data: [12, 20, 95, 18, 33, 1, 26], label: 'dasai'},

  ];
  public lineChartLabels5: Array<any> = ['18:10', '18:20', '18:30', '18:40', '18:50', '19:00', '19:10'];
  public lineChartOptions5: any = {
    responsive: true,
    legend:  {
      display:  true,
      position:  'bottom'
    }
  };
  public lineChartColors5: Array<any> = [
    { // blue
      backgroundColor: 'rgba(0,149,179,0)',
      borderColor: 'rgba(0,149,179,1)',
      pointBackgroundColor: 'rgba(0,149,179,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(0,149,179,0.8)'
    },

    { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
    },

  ];
  public lineChartLegend5: boolean = true;
  public lineChartType5: string = 'line';

  // events
  public chartClicked5(e: any): void {
    console.log(e);
  }

  public chartHovered5(e: any): void {
    console.log(e);
  }

  // lineChart6
  public lineChartData6: Array<any> = [
    { data: [25, 40, 30, 81, 56, 55, 40], label: 'Outgoing' },
    { data: [12, 20, 15, 18, 25, 15, 26], label: 'Incoming' },

  ];
  public lineChartLabels6: Array<any> = ['18:10', '18:20', '18:30', '18:40', '18:50', '19:00', '19:10'];
  public lineChartOptions6: any = {
    responsive: true,
    legend:  {
      display:  true,
      position:  'bottom'
    }
  };
  public lineChartColors6: Array<any> = [
    { // blue
      backgroundColor: 'rgba(0,149,179,0)',
      borderColor: 'rgba(0,149,179,1)',
      pointBackgroundColor: 'rgba(0,149,179,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(0,149,179,0.8)'
    },

    { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
    },

  ];
  public lineChartLegend6: boolean = true;
  public lineChartType6: string = 'line';

  // events
  public chartClicked6(e: any): void {
    console.log(e);
  }

  public chartHovered6(e: any): void {
    console.log(e);
  }

  // lineChart7
  public lineChartData7: Array<any> = [
    { data: [65, 59, 80, 81, 56, 55, 40], label: 'Series A' },
    { data: [28, 48, 40, 19, 86, 27, 90], label: 'Series B' },
    { data: [18, 48, 77, 9, 100, 27, 40], label: 'Series C' },
    { data: [40, 90, 56, 70, 30, 27, 40], label: 'Series D' },

  ];
  public lineChartLabels7: Array<any> = ['18:10', '18:20', '18:30', '18:40', '18:50', '19:00', '19:10'];
  public lineChartOptions7: any = {
    responsive: true,
    legend:  {
      display:  true,
      position:  'bottom'
    }
  };
  public lineChartColors7: Array<any> = [
    { // blue
      backgroundColor: 'rgba(0,149,179,0)',
      borderColor: 'rgba(0,149,179,1)',
      pointBackgroundColor: 'rgba(0,149,179,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(0,149,179,0.8)'
    },
    { // yellow
      backgroundColor: 'rgba(230,230,0,0)',
      borderColor: 'rgba(230,230,0,1)',
      pointBackgroundColor: 'rgba(230,230,0,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(230,230,0,1)'
    },

    { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
    },

    { //green
      backgroundColor: 'rgba(34,204,0,0)',
      borderColor: 'rgba(34,204,0,1)',
      pointBackgroundColor: 'rgba(34,204,0,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(34,204,0,0.8)'
    },

  ];
  public lineChartLegend7: boolean = true;
  public lineChartType7: string = 'line';

  // events
  public chartClicked7(e: any): void {
    console.log(e);
  }

  public chartHovered7(e: any): void {
    console.log(e);
  }

  // lineChart8
  
  public lineChartData8: Array<any> = [

    { data: this.bufferMem, label: 'Buffered' },
    { data: this.CacheMem, label: 'Cache' },
    { data: this.usedMem, label: 'Used' },
    { data: this.totalMem, label: 'Total' },
    { data: this.freeMem, label: 'Free' },
    

  ];
  public lineChartLabels8: Array<any> = ['18:10', '18:20', '18:30', '18:40', '18:50', '19:00', '19:10'];
  public lineChartOptions8: any = {
    responsive: true,
    legend:  {
      display:  true,
      position:  'bottom'
    }
  };
  public lineChartColors8: Array<any> = [
    { // light green
      backgroundColor: 'rgba(102,204,0,0.2)',
      borderColor: 'rgba(102,204,0,1)',
      pointBackgroundColor: 'rgba(102,204,0,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(102,204,0,0.8)'
    },
   // blue
  { backgroundColor: 'rgba(0,149,179,0.2)',
   borderColor: 'rgba(0,149,179,1)',
   pointBackgroundColor: 'rgba(0,149,179,1)',
   pointBorderColor: '#fff',
   pointHoverBackgroundColor: '#fff',
   pointHoverBorderColor: 'rgba(0,149,179,0.8)'
  },
    { // orange
      backgroundColor: 'rgba(255,166,77,0.2)',
      borderColor: 'rgba(255,166,77,1)',
      pointBackgroundColor: 'rgba(255,166,77,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,166,77,0.8)'
    },
    { // purple
      backgroundColor: 'rgba(136,77,255,0.2)',
      borderColor: 'rgba(136,77,255,1)',
      pointBackgroundColor: 'rgba(136,77,255,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(136,77,255,0.8)'
    },
    { // blue
      backgroundColor: 'rgba(51,119,255,0.2)',
      borderColor: 'rgba(51,119,255,1)',
      pointBackgroundColor: 'rgba(51,119,255,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(51,119,255,0.8)'
    }
  ];
  public lineChartLegend8: boolean = true;
  public lineChartType8: string = 'line';

  // events
  public chartClicked8(e: any): void {
    console.log(e);
  }

  public chartHovered8(e: any): void {
    console.log(e);
  }
  createForm() {

    this.form = this.builder.group({
      applianceId:[''],
      ipAddress: [''],
      gatewayIp: [''],
      subnetMask: [''],
      macAddress: [''],
      hostName: [''],
      vLanId: [''],
      dnsService: [''],
      dhcp: [''],
      staticMac: ['']
    });
  }
  getNetworkDetails() {
    $("#NetworkModal").modal("show");
  }

  createLoginForm() {
    this.loginForm = this.builder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]

    });
  }
  
  public formValidationFields1 = {
    "username": '',
    "password": ''

  }
  isFieldValid1(field: string) {
    if (this.loginForm.get(field).touched) {
      this.formValidationFields1 = this._fieldErrorDisplayService.validateField(this.loginForm, field, this.formValidationFields1, "login")
    }
    return !this.loginForm.get(field).valid && this.loginForm.get(field).touched;
  }

  displayFieldCss1(field: string) {
    return {
      'has-error': this.isFieldValid1(field),
      'has-feedback': this.isFieldValid1(field)
    };
  }

  onSubmit(){
    console.log(this.form.value);
    this._applianceManagementService.submitNetworkDetails(this.form.value).subscribe (
      data => this.onSuccessOperation(data),
      err => this.onErrorOperation(err)
    );
  }

  onSuccessOperation(response) {
    if(this.saveModalFlag==true){
    $("#myModal").modal("hide");
    }
    if(this.saveModalFlag==false){
    $("#NetworkModal").modal("hide");
    }

    this.successMessage =response.responseMessage;
    this.errorMessages = [];
    this.staticIpToHostConfigUpdated=[];
    let res = response;
    
    bootbox.dialog({
      message: this.successMessage,
      buttons: {

        Ok: {
          label: "Close",
          className: 'btn btn-primary btn-flat',
          //callback:location.reload()
         
        }
      }
    });
    this.saveModalFlag=false;
    this.staticIpToHostConfigUpdated=[];
    this.successMessage='';

  }
  onErrorOperation(errResp) {

  }

  closeModal(){
   
    $("#NetworkModal").modal("hide");
    this.successMessage ='';
    this.errorMessages = [];
  }

  addAdvancedData(){

    if(this.applianceObjAdvancedDup.length>0){
    for(var i=0;i<this.applianceObjAdvancedDup.length;i++){
     
     this.appAdd.push(this.applianceObjAdvancedDup[i]);
     this.applianceObjAdvancedDup.splice(i,1);

    }
  }
  if(this.ipAddressAdd!=null||this.HostnameAdd!=null||this.AliasAdd!=null){
    this.applianceObjAdvancedDup.push({"ip":this.ipAddressAdd,"hostname":this.HostnameAdd,"alias":this.AliasAdd,"color":"yellow"});
    
    
    for(var i=0;i<this.applianceObjAdvancedDup.length;i++){

      this.appAdd.push(this.applianceObjAdvancedDup[i]);
      this.applianceObjAdvancedDup.splice(i,1)
    }
    

    
    
    
  
  }
  //arrOfObj.map(v => v.isActive = true)
this.ipAddressAdd=null;
this.HostnameAdd=null;
this.AliasAdd=null;
  }
  delAddData(id){
    for(var i=0;i<this.appAdd.length;i++){

      if(this.appAdd[i]["ip"]==id){

        this.appAdd.splice(i,1);
      }
    }

  }
  submitData(){
    

    for(var i=0;i<this.appAdd.length;i++){
      
      this.staticIpToHostConfigUpdated.push(this.appAdd[i]);
    }
   
    this.submitApplianceNewtorkData={"username":this.loginForm.get("username").value,
    "applianceId":this.applianceModel.applianceId,
    "password":this.loginForm.get("password").value,
    "applianceIp":this.applianceModel.ipAddress,
    "advanced":{"searchDomainNames":this.applianceObj.adminVMData.advanced.searchDomainNames,

    "dnsServers":this.applianceObj.adminVMData.advanced.dnsServers,
    "removedHostIPs":this.applianceObj.adminVMData.advanced.removedHostIPs,
    "staticIpToHostConfig":this.staticIpToHostConfigUpdated,
    "enableDNSService":this.form.get("dnsService").value
    },
    "general":{"ip":this.form.get("ipAddress").value,"dhcp":this.form.get("dhcp").value,
    "gateway":this.form.get("gatewayIp").value,"subnet":this.form.get("subnetMask").value,
    "hostname":this.form.get("hostName").value,"vlan":parseInt(this.form.get("vLanId").value),
    "macAddress":this.form.get("macAddress").value,"macStatic":this.form.get("staticMac").value,

  
  
  }//this.applianceObj.adminVMData.general

  }
  if(this.applianceModel.credentialSaved==false){
    this.saveModalFlag=true;
     
   
    $("#NetworkModal").modal("hide");
   $("#myModal").modal("show");
    
    
  }
  if(this.applianceModel.credentialSaved==true){
    this.saveModalFlag=false;
  this._applianceManagementService.networkSettingsDataSubmit(this.submitApplianceNewtorkData).subscribe(

    
    data => this.onSuccessOperation(data),
      err => this.onErrorOperation(err)
  )
}
  }

  submitNetworkSaveToDB(){
    this.submitApplianceNewtorkData["operationUsername"]=this.loginForm.get("username").value;
    this.submitApplianceNewtorkData["operationPassword  "]=this.loginForm.get("password").value;
    this._applianceManagementService.networkSettingsDataSubmit(this.submitApplianceNewtorkData).subscribe(

    
      data => this.onSuccessOperation(data),
        err => this.onErrorOperation(err)
    )

  }
  closeLoginModal() {
      $("#myModal").modal("hide");
      }  
 
  }










