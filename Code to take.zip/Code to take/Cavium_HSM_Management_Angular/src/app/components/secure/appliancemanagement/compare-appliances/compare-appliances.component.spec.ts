import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompareAppliancesComponent } from './compare-appliances.component';

describe('CompareAppliancesComponent', () => {
  let component: CompareAppliancesComponent;
  let fixture: ComponentFixture<CompareAppliancesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompareAppliancesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompareAppliancesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
