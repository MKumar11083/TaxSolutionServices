import { Component, OnInit,ViewChild,Input,Output,EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { InitializeApplianceComponent} from './../../appliancemanagement/initialize-appliance/initialize-appliance.component';
import { ApplianceOperationsComponent} from './../../appliancemanagement/appliance-operations/appliance-operations.component';
import { FirmwareUpgradeApplianceComponent } from './../../appliancemanagement/firmware-upgrade-appliance/firmware-upgrade-appliance.component';

@Component({
  selector: 'app-appliance-login',
  templateUrl: './appliance-login.component.html',
  styleUrls: ['./appliance-login.component.css']
})
export class ApplianceLoginComponent implements OnInit {
  @Input () selectedAppliances;
  @ViewChild('loginModal') loginModal: ModalDirective;

  @ViewChild('initializeAppliance')
  private initializeAppliance: InitializeApplianceComponent;
  @ViewChild('firmwareUpgradeAppliance')
  private firmwareUpgradeAppliance: FirmwareUpgradeApplianceComponent;
  @ViewChild('applianceOperations')
  private applianceOperationsComponent : ApplianceOperationsComponent
  loginForm: FormGroup;
  applianceOperation : string;
  listAppliances =[];
  applianceCount = 1;
  totalApplianceCount = 0;
  applianceName : string;
  message : string;
  isLastAppliance :boolean= false;
  autoLoginApplianceList = [];
  @Output() loginEvent = new EventEmitter<any>();
  constructor(private _fieldErrorDisplayService : FieldErrorDisplayService,
    private _formBuilder: FormBuilder) { }

  ngOnInit() {
    this.createLoginForm();
    this.clearDetails();
  }
  createLoginForm() {
    this.loginForm = this._formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      credentialSaved:['']
    });
  }

  showloginModal(operation){
    debugger;
    this.clearDetails();
    this.listAppliances = this.selectedAppliances;
    this.loginForm.reset();
    let flag :boolean = true;
    if(this.listAppliances.length!=0){
      if(this.listAppliances.length<=5){
       let count:number = 0;
      // if credentialSaved="true" means autologin and if it false , show login popup
        this.listAppliances.forEach(appliance => {
          if (this.listAppliances[count]['credentialSaved']) {
             this.autoLoginApplianceList.push(this.listAppliances[count]);
             this.listAppliances.splice(count, 1);
             count++;
          }
        })
        this.applianceOperation = operation;
        if(this.listAppliances.length>0){
          this.applianceName = this.listAppliances[this.applianceCount-1]['applianceName'];
          this.totalApplianceCount = this.listAppliances.length;
          if(this.applianceCount == this.totalApplianceCount){
            this.isLastAppliance = true;
          }
          this.loginModal.show();
        }else{
          
          this.redirectToSelectedOperation();
        }
      }else{
        this.loginModal.show();
        this.message = "Sorry!Operation cannot be performed on more than five appliances";
      }
    }else{
      this.loginModal.show();
      this.message = "Please select any appliance to perform the activity!";
    }
  }
  

  goToNextLoginForm(){
    debugger;
    if(this.applianceOperation == "Initialize"){
      this.listAppliances[this.applianceCount-1]["userName"] = this.loginForm.get('username').value;
      this.listAppliances[this.applianceCount-1]["userPassword"] = this.loginForm.get('password').value;
    }else{
      this.listAppliances[this.applianceCount-1]["operationUsername"] = this.loginForm.get('username').value;
      this.listAppliances[this.applianceCount-1]["operationPassword"] = this.loginForm.get('password').value;
      if(this.loginForm.get('credentialSaved').value == true){
        this.listAppliances[this.applianceCount-1]["credentialSaved"] = true;
      }else{
        this.listAppliances[this.applianceCount-1]["credentialSaved"] = false;
      }
    }
    
    if(this.applianceCount  < this.listAppliances.length){
      this.applianceName = this.listAppliances[this.applianceCount]['applianceName'];
      this.applianceCount++;
      if(this.applianceCount==this.totalApplianceCount){
        this.isLastAppliance = true;
      }
    }else{
      this.loginModal.hide();
      this.redirectToSelectedOperation();
    }
    this.loginForm.reset();
  }

  redirectToSelectedOperation(){
    debugger;
    // added the "credentialSaved=true" records to fill the initialize form.
    this.autoLoginApplianceList.forEach(applianceObj => {
      this.listAppliances.push(applianceObj);
    });
   
    if(this.applianceOperation == "Initialize"){
      this.initializeAppliance.showInitializeModal(this.listAppliances);
    }
    else if(this.applianceOperation == "firmwareUpgrade"){
      this.firmwareUpgradeAppliance.showFirmwareUpgradeModal(this.listAppliances);
    }
    else {
      this.applianceOperationsComponent.submitApplianceOperations(this.listAppliances,this.applianceOperation)
    }
  }
  closeLoginModal(){
    console.log("Close ----> Login Modal");
    this.loginModal.hide();
    this.clearDetails();
  }

  callback(){
    console.log("Call back ----> Appliance Login Form");
   this.clearDetails();
    this.loginEvent.emit();
  }
  clearDetails(){
    this.loginForm.reset();
    this.applianceOperation = "";
    this.listAppliances =[];
    this.applianceCount = 1;
    this.totalApplianceCount = 0;
    this.applianceName ="";
    this.message ="";
    this.isLastAppliance = false;
    this.autoLoginApplianceList =[];
  }

  public formValidationFields1 = {
    "username": '',
    "password": ''

  }
  isFieldValid1(field: string) {
    if (this.loginForm.get(field).touched) {
      this.formValidationFields1 = this._fieldErrorDisplayService.validateField(this.loginForm, field, this.formValidationFields1, "login")
    }
    return !this.loginForm.get(field).valid && this.loginForm.get(field).touched;
  }

  displayFieldCss1(field: string) {
    return {
      'has-error': this.isFieldValid1(field),
      'has-feedback': this.isFieldValid1(field)
    };
  }
}
