import { Component, OnInit ,OnDestroy} from '@angular/core';
import { BreadcrumbService } from './../../../../services/common/breadcrumb.service';
import { UserManagementService } from './../../../../services/usermanagement.service';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, FormControl } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { AnonymousSubscription } from "rxjs/Subscription";
import { Router } from '@angular/router';
declare var $: any;
declare var bootbox: any;
@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.css']
})
export class CreateUserComponent implements OnInit,OnDestroy {

  form: FormGroup;
  list : any = [];
  aclList: any;
  groupList: any;
  dropdownList: any = [];
  successMessage: any = [];
  errorMessages: any = [];
  selectplaceholder = "Select the Options";
  canClearSelect: boolean = true;
  createUserSubsc :AnonymousSubscription;
  getGroupAndACLSubsc : AnonymousSubscription;
  displayUserGroup:boolean =false;
  constructor(
    // private _breadcrumbService: BreadcrumbService,
    private _userManagementService: UserManagementService,
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private builder: FormBuilder,
    private router: Router) { }

  ngOnInit() {
    // this._breadcrumbService.getBreadCrumbDetails("create-users");
    this.getdropdownList();
    this.createForm();
  }
  emailPattern = "^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$";
  createForm() {

    this.form = this.builder.group({
      userName: ['', Validators.required],
      password: ['', Validators.required],
      confirmPassword: ['', Validators.required],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      emailId: ['', [Validators.required, Validators.email]],
      phoneNumber: [null, Validators.required],
      userGroupId: ['', Validators.required],
      userACLId: ['', Validators.required],
      status: "ACTIVE",
      temporaryPassword: "Y"
    });
  }

  /* onSubmit function is to create users*/
  onSubmit(isValid: boolean) {
    console.log("onSubmit..");
    if(this.groupList.length <=1){
      let usergroup1 = this.groupList[0]["id"];
      this.form.get('userGroupId').setValue(usergroup1);
    }
    debugger;
    if (this.form.valid) {
      if(this.checkIfMatchingPasswords()){
        this.createUserSubsc= this._userManagementService.createUser(this.form.value).subscribe(
           data => this.onSuccessOperation(data),
           err => this.onErrorOperation(err)
         );
      }else{
        this.errorMessages.push("Password and Confirm Password should be same");
      }
    } else {
      this.formValidationFields = this._fieldErrorDisplayService.validateForm(this.form, this.formValidationFields, "createuser", false)
    }
  }

  checkIfMatchingPasswords() {
    let newPassword = this.form.get("password").value;
    let ConfirmPassword = this.form.get("confirmPassword").value;
    if (newPassword !== ConfirmPassword) {
      return false;
    }
    else {
      return true;
    }
  }
  onSuccessOperation(response) {
    this.successMessage = [];
    this.errorMessages = [];
    let res = response;
    if (res.responseCode == "200") {
      //this.successMessage.push(res.responseMessage);
      sessionStorage.setItem("msg",res.responseMessage);
      this.router.navigateByUrl("/manageuserlist");
    } else if (res.responseCode == "409" || res.responseCode == "-230" ) {
      this.errorMessages.push(res.responseMessage);
    } else if (res.responseCode == "500") {
      this.errorMessages.push(res.responseMessage);
    } else {
      this.errorMessages.push(res.responseMessage);
    }
  }
  onErrorOperation(errResp) {

  }
  reset() {
    this.form.reset();
    this.successMessage = [];
    this.errorMessages = [];
  }
  
  getdropdownList() {
    this.getGroupAndACLSubsc=this._userManagementService.getdropdownList().subscribe(
      res => {
        //this.dropdownList = res;
        //let options = [];
        //let options1 = [];
        // $.each(this.dropdownList.listUserACLDetailsModel, function (key, obj) {
        //   options.push(setOption(obj.id, obj.aclName));
        // });
        // this.aclList = options;
        // $.each(this.dropdownList.listUserGroupModel, function (key, obj) {
        //   options1.push(setOption(obj.id, obj.roleName));
        // });
        this.aclList = res.listUserACLDetailsModel;
        this.groupList = res.listUserGroupModel;
        if(this.groupList.length>1){
          this.displayUserGroup = true;
         
        }else{
          this.form.get('userGroupId').setValidators(null);
        }
      },
      error => {
        console.log(error);
      },

    )
  }
  // create a form errors
  public formValidationFields = {
    "userName": '',
    "password": '',
    "firstName": '',
    "lastName": '',
    "emailId": '',
    "phoneNumber": '',
    "userGroupId": '',
    "userACLId": '',
    "status": '',
    "temporaryPassword": '',
    "confirmPassword":''
  }

  isFieldValid(field: string) {
    if (this.form.get(field).touched) {
      this.formValidationFields = this._fieldErrorDisplayService.validateField(this.form, field, this.formValidationFields, "createuser")
    }
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }
 // destroy method 
 public ngOnDestroy(): void {
  if (this.createUserSubsc) {
    this.createUserSubsc.unsubscribe();
  }
  if (this.getGroupAndACLSubsc) {
    this.getGroupAndACLSubsc.unsubscribe();
  }
 
}
closeMessage(){
  this.successMessage = [];
  this.errorMessages = [];
}
}

export function setOption(value, label) {
  let option = new Option();
  option.value = value;
  option.label = label;
  return option;
} 
