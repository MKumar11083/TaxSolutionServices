import { Component, OnInit } from '@angular/core';
import { PartitionManagementService } from './../../../services/partitionmanagement/partitionmanagement.service';
import { AnonymousSubscription } from "rxjs/Subscription";
import { DataTableResource } from './../data-table/index';
import { I18nService } from '../../../services/common/i18n/i18n.service';
import { BreadcrumbService } from './../../../services/common/breadcrumb.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../services/common/field-error-display.service';
import {Observable} from "rxjs/Observable";

// import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

declare var $: any;
declare var bootbox: any;
declare var jQuery: any;
@Component({
  selector: 'app-partitionmanagement',
  templateUrl: './partitionmanagement.component.html',
  styleUrls: ['./partitionmanagement.component.css'],

})
export class PartitionmanagementComponent implements OnInit {
  debugger;
  title = "Partition Details";
  partitionList: any = [];
  showList:boolean =false;
  selectedPartitionList = [];
  toolTipData : string;
  private timer: AnonymousSubscription;
  constructor(private _service: PartitionManagementService,
    private _I18nService: I18nService,
    private _formBuilder: FormBuilder,
    // private spinnerService: Ng4LoadingSpinnerService,
    private _fieldErrorDisplayService: FieldErrorDisplayService) { }

  ngOnInit() {
    this.getPartitionList();
  }

  getPartitionList(){
    this._service.getListOfPartition().subscribe(
      res => {
        this.partitionList = res;
        console.log(this.partitionList);
        let count : number=0;
        this.partitionList.forEach(partitionObj => {
          this.partitionList[count]['loading']="false";
          if(partitionObj.partitionData!=null){
            const partitionData = partitionObj.partitionData;
            const fipsState = partitionData.fipsState;
            const vmStatus = partitionData.vmStatus;
            const cavServerStatus =  partitionData.partitionData;
            if(fipsState == "zeroized" && vmStatus == "0" && cavServerStatus == "0"){
              this.partitionList[count]['statusColor']="grey";
            }else if(fipsState == "zeroized" && vmStatus == "0" && cavServerStatus == "1"){
              this.partitionList[count]['statusColor']="grey";
            }else if(fipsState == "zeroized" && vmStatus == "0" && cavServerStatus == "-1"){
              this.partitionList[count]['statusColor']="orange";
            }else if(fipsState == "nonzeroized" && vmStatus == "1" && cavServerStatus == "0"){
              this.partitionList[count]['statusColor']="yellow";
            }else if(fipsState == "nonzeroized" && vmStatus == "1" && cavServerStatus == "1"){
              this.partitionList[count]['statusColor']="green";
            }else if(fipsState == "nonzeroized" && vmStatus == "1" && cavServerStatus == "-1"){
              this.partitionList[count]['statusColor']="red";
            }else if(fipsState == "nonzeroized" && vmStatus == "-1" && cavServerStatus == "0"){
              this.partitionList[count]['statusColor']="red";
            }else if(fipsState == "nonzeroized" && vmStatus == "-1" && cavServerStatus == "1"){
              this.partitionList[count]['statusColor']="red";
            }else if(fipsState == "nonzeroized" && vmStatus == "-1" && cavServerStatus == "-1"){
              this.partitionList[count]['statusColor']="red";
            }else if(fipsState == "zeroized" && vmStatus == "-1" && cavServerStatus == "0"){
              this.partitionList[count]['statusColor']="red";
            }else if(fipsState == "zeroized" && vmStatus == "-1" && cavServerStatus == "1"){
              this.partitionList[count]['statusColor']="red";
            }else if(fipsState == "zeroized" && vmStatus == "-1" && cavServerStatus == "11"){
              this.partitionList[count]['statusColor']="red";
            }
            count = count+1;
          }
        });
        this.getTimeIntervalData();
      },
      error => {
        console.log(error);
      },
    );
  }
  count = 0;
  private getTimeIntervalData(): void {
    if(this.count<1){
      this.timer = Observable.timer(1000 * 60).first().subscribe(() => this.getPartitionList());
      this.count=this.count+1;
    }else{
      this.timer.unsubscribe();
    }
  }

  toggle() {
    this.showList = false;
  }
  toggle1() {
    this.showList = true;
  }

  selectPartitionItems(event, partitionId: string) {
    debugger;
    if (event.target.checked) {
      event.currentTarget.style.visibility = "visible";
      for (var i = 0; i < this.partitionList.length; i++) {
        if (this.partitionList[i].partitionId == partitionId) {
          this.partitionList[i]['checked']=true;
          this.selectedPartitionList.push(this.partitionList[i]);
         
        }
        else if(!this.partitionList[i]['checked']){
          this.partitionList[i]['checked']=false;
        }
    }
    
    } else {
      for (var i = 0; i < this.partitionList.length; i++) {
        if (this.partitionList[i].applianceId == partitionId) {
          let index = this.selectedPartitionList.indexOf(partitionId);
          this.partitionList[i]['checked']=false;
          this.selectedPartitionList.splice(index);
  
        }
        else if(!this.partitionList[i]['checked']){
          this.partitionList[i]['checked']=false;
        }
    }
    }
  }

  getPartitionToolTipData(partitionId){
    debugger;
    this.toolTipData = "";
    this.partitionList.find
      (partition => {
        if (partition.partitionId == partitionId) {
          this.toolTipData = partition.partitionData;
        }
      })
  }
}
