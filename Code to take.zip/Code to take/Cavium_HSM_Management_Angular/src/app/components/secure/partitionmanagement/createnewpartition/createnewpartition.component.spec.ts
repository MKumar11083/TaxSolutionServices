import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreatenewpartitionComponent } from './createnewpartition.component';

describe('CreatenewpartitionComponent', () => {
  let component: CreatenewpartitionComponent;
  let fixture: ComponentFixture<CreatenewpartitionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreatenewpartitionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatenewpartitionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
