
import { Component, OnInit, TemplateRef,ViewChild } from '@angular/core';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { AnonymousSubscription } from "rxjs/Subscription";
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { BsModalService } from 'ngx-bootstrap/modal';
import { DataTableResource } from './../../data-table/index';
import { I18nService } from '../../../../services/common/i18n/i18n.service';
import { BreadcrumbService } from './../../../../services/common/breadcrumb.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { PartitionManagementService } from './../../../../services/partitionmanagement/partitionmanagement.service';
import { CreatenewpartitionComponent } from './../../../secure/partitionmanagement/createnewpartition/createnewpartition.component';
// import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

declare var $: any;
declare var bootbox: any;
declare var jQuery: any;
@Component({
  selector: 'app-partitionappliancelist',
  templateUrl: './partitionappliancelist.component.html',
  styleUrls: ['./partitionappliancelist.component.css']
})
export class PartitionappliancelistComponent implements OnInit {
  debugger;
  @ViewChild('loginModal') loginModal: ModalDirective;
  @ViewChild('createPartition') createPartition: CreatenewpartitionComponent;
  
  loginForm: FormGroup;
  modalRef: BsModalRef;
  title = "Partition Details";
  message: string;
  showButton: boolean = false;
  username: string = '';
  password: string = '';
  appliancesList: any = [];
  itemResource: any;
  displayErrors: any = [];
  showList: boolean = true;
  selectedAppliances: any = [];
  showPartitionList :boolean =true;
  applianceName:string;
  constructor(private _applianceManagementService: AppliancemanagementService,
    private _I18nService: I18nService,
    private _formBuilder: FormBuilder,
    // private spinnerService: Ng4LoadingSpinnerService,
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _service: PartitionManagementService,
    private modalService: BsModalService) { }

  ngOnInit() {
    this.selectedAppliances = [];
    this.createLoginForm();
    this._applianceManagementService.getAllListAppliances().subscribe(
      res => {
        debugger;
        if (res.length > 0) {
          for (var i = 0; i < res.length; i++) {
            let appliance = res[i];
            appliance['disabled'] = false;
            this.appliancesList.push(appliance);
          }
        }
      },
      error => {
        console.log(error);
      },
    );
  }

  createLoginForm() {
    this.loginForm = this._formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
    });
  }
  toggle() {
    this.showList = false;
  }
  toggle1() {
    this.showList = true;
  }

  selectApplianceItems(event, applianceId, template: TemplateRef<any>) {
    debugger;
    if (event.target.checked) {
      event.currentTarget.style.visibility = "visible";
      for (var i = 0; i < this.appliancesList.length; i++) {
        if (this.appliancesList[i].applianceId == applianceId) {
          this.selectedAppliances.push(this.appliancesList[i]);
          this.appliancesList[i]['checked'] = true;
          this.appliancesList[i]['disabled'] = false;
        }
        else if (!this.appliancesList[i]['checked']) {
          this.appliancesList[i]['disabled'] = true;
          this.appliancesList[i]['checked'] = false;
        }
      }
      this.validateInitOperation(this.selectedAppliances[0], template);
    } else {
      event.currentTarget.style.visibility = "";
      this.showButton = false;
      for (var i = 0; i < this.appliancesList.length; i++) {
        if (this.appliancesList[i].applianceId == applianceId) {
          let index = this.selectedAppliances.indexOf(applianceId);
          this.selectedAppliances.splice(index);
        }
        this.appliancesList[i]['disabled'] = false;
        this.appliancesList[i]['checked'] = false;
      }
    }
  }


  validateInitOperation(appliance, template) {
    this._service.validateInitOperation(appliance).subscribe(
      res => {
        if (res.responseCode == "200") {
          this.showButton = true;
          // this.message = "Selected Appliance is Initialize Successfully";
          // this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
        } else if (res.responseCode == "401") {
          this.showButton = false;
          this.message = "Selected Appliance is not Initialize ";
          this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
        }
      })
  }

  showLoginForm(){
    this.loginModal.show();
    this.loginForm.reset();
    this.applianceName = this.selectedAppliances[0].applianceName;
  }

  goToCreatePartition(){
    debugger;
    this.loginModal.hide();
    this.showPartitionList= false;
    const username = this.loginForm.get('username').value;
    const password = this.loginForm.get('password').value;
    this.selectedAppliances[0].userName=username;
    this.selectedAppliances[0].userPassword=password;
  }
  public formValidationFields1 = {
    "username": '',
    "password": ''

  }
  isFieldValid1(field: string) {
    if (this.loginForm.get(field).touched) {
      this.formValidationFields1 = this._fieldErrorDisplayService.validateField(this.loginForm, field, this.formValidationFields1, "login")
    }
    return !this.loginForm.get(field).valid && this.loginForm.get(field).touched;
  }

  displayFieldCss1(field: string) {
    return {
      'has-error': this.isFieldValid1(field),
      'has-feedback': this.isFieldValid1(field)
    };
  }
}