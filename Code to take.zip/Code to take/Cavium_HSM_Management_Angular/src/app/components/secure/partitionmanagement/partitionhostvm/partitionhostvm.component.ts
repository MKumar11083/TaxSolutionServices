// // import { Component, OnInit } from '@angular/core';

// // @Component({
// //   selector: 'app-partitionhostvm',
// //   templateUrl: './partitionhostvm.component.html',
// //   styleUrls: ['./partitionhostvm.component.css']
// // })
// // export class PartitionhostvmComponent implements OnInit {

// //   constructor() { }

// //   ngOnInit() {
   
// //   }

// // }
// import { Component, OnInit ,ChangeDetectorRef} from '@angular/core';
// import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, FormControl } from '@angular/forms';
// import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
// import { AddApplianceService } from './../../../../services/addAppliance.service';
// import { Router } from '@angular/router'; 

// declare var jquery:any;
// declare var $ :any;
// declare var bootbox: any;
// @Component({
//   selector: 'app-partitionhostvm',
//   templateUrl: './partitionhostvm.component.html',
//   styleUrls: ['./partitionhostvm.component.css']
// })
// export class PartitionhostvmComponent implements OnInit {
  
//   showlist :  boolean = true;
//   form: FormGroup;
//   public successMessage:string;
//   private groupsList:string;
//   getValidateRes:object[]=[];
//    getValidateRes1:object[]=[];
//    getValidateRes3:object[]=[];
//   private applianceSent:object[]=[];
//   private localStorageApplianceSent:object[]=[];
//   private onPageApplianceSent:object[]=[];
//  showApp:object[]=[];
//    showAppliance:boolean=false;
//    private checkboxFlag:string;
//    private getAddStatusFlag:string;
//    private localStorageDefault:object[]=[];
//      displayErrors: any = []; 
//    showmessage:boolean=false;
//    appliancesListTemp: any = [];
//    utcNames=["(GMT-12:00) International Date Line West",
//    "(GMT-11:00) Midway Island, Samoa",
//    "(GMT-12:00) Tijuana, Baja California",
// "(GMT-12:00) Bogota, Lima, Quito, Rio Branco",
//   "(GMT-12:00) Eastern Time",
//    "(GMT+05:30) Chennai, Kolkata, Mumbai, New Delhi",
//    "(GMT+07:00) Bangkok, Hanoi, Jakarta",
//    "(GMT+05:30) Sri Jayawardenapura",
//    "(GMT+08:00) Beijing, Chongqing, Hong Kong, Urumqi",
//   "(GMT+12:00) Fiji, Kamchatka, Marshall Is.",
//    "(GMT+12:00) Auckland, Wellington"
// ]
   
    

//   constructor(
//     private _fieldErrorDisplayService: FieldErrorDisplayService,
//     private _addApplianceService :AddApplianceService,
//     private chRef: ChangeDetectorRef,
//     private router:Router,
//     private builder: FormBuilder) { }
  
//   ngOnInit() {
//     debugger;
//     this.createForm();
//     this.getTempdata();
    
//    /*if("applianceArray1" in localStorage){

//     debugger;
//     this.showAppliance=true;
//     debugger;
//     var temp=[];
    
    
//     temp.push(JSON.parse(localStorage.getItem("applianceArray1")));
//     if(temp.length>0){
//     for(var i=0;i<temp.length;i++){
//      // console.log(localStorage.getItem("applianceArray1")[i]);
//       this.getValidateRes1=temp[i];
//     }
//   }
//     //this.getValidateRes1.push(JSON.parse(localStorage.getItem("applianceArray1")));
//      console.log(this.getValidateRes1); 

//    }*/
    
//   }

//  getRdirecttoListApp(){

//  this.router.navigateByUrl("/listAppliance");
// } 

//   getTempdata(){
//     this._addApplianceService.getAllTempAppliances().subscribe(
//       res => {
//         this.appliancesListTemp = res;

//         console.log("hello", this.appliancesListTemp);
        
//       },
//       error => {
//         console.log(error);
//       },

//     );

//   }
//   toggle(){
//     this.showlist = true;
//   }
//   toggle1(){
//     this.showlist = false;
//   }

//   createForm() {
      
//       this.form = this.builder.group({
//       applianceName: ['', Validators.required],
//       authID: ['CaviumLiquidSA', Validators.required],
//       serialNumber: ['', Validators.required],
//       networkTimezone: [''],
//       ipAddress: ['', Validators.required],  
//       gatewayIp: [''],
//       subnetMask: [''],
//       networkMode: [''],    
//       hostName: [''],
//       ipmiIP: ['',Validators.required],
//       userName: ['',Validators.required],    
//       userPassword: ['',Validators.required],
//       cityName:['',Validators.required]

//     });
//   }

//   /* onSubmit function is to create users*/
  

//   onSuccessOperation(res) {
//     let response = JSON.parse(res['_body']);
//     console.log(response);
//     this.successMessage = response.responseMessage;
//   }

//   onErrorOperation(errResp) {
//   }

//    // create a form errors
//    public formValidationFields = {
//     "applianceName": '',
//     "authID": '',
//     "serialNumber": '',
//     // "network": '',
//      "ipAddress": '',
//     // "gatewayIP": '',
//     // "subnetMask": '',
//     // "networkMode": '',
//     // "hostname": '',
//     "ipmiIP": '',
//     "userName": '',
//     "userPassword": '',
//     "cityName" :''
//   }

//   isFieldValid(field: string) {
   
//     if (this.form.get(field).touched) {
//       this.formValidationFields = this._fieldErrorDisplayService.validateField(this.form, field, this.formValidationFields, "addAppliance")
//     }
//     return !this.form.get(field).valid && this.form.get(field).touched;
//   }

//   displayFieldCss(field: string) {
//     return {
//       'has-error': this.isFieldValid(field),
//       'has-feedback': this.isFieldValid(field)
//     };
//   }

//   submitApplication(isValid: boolean){
    
    
//     debugger;
//     if (isValid) {
//     this._addApplianceService.verifyAppliances(this.form).subscribe((res) => {
//       console.log("UserGroup is created");
      
//       this.getValidateRes=res;
//      console.log("Inside success");
//       console.log("this is getValidateReS"+this.getValidateRes["code"]);
//        if(this.getValidateRes["code"]=="200"){
//         this.appliancesListTemp.push(res);
//         let message = this.getValidateRes["message"]+".Appliance is verified and  is available to add.";
//         bootbox.dialog({
//           message: message,
//           buttons: {
            
//             ok: {
//               label: "Ok",
//               className: 'btn btn-primary btn-flat',
              
//             }
//           }
//         });
//           // alert(this.getValidateRes["message"]);
//            //this.showApp.push(res);

//           /* if(this.appliancesListTemp.length>0){
//               for(var i=0;i<this.appliancesListTemp.length;i++){

//                 this.showApp=this.appliancesListTemp[i];
//               }

//            }*/
           
           

          
//        }
//       else if(this.getValidateRes["code"]=="409"){
        

//         let message = this.getValidateRes["message"];
//         bootbox.dialog({
//           message: message,
//           buttons: {
            
//             ok: {
//               label: "Ok",
//               className: 'btn btn-primary btn-flat',
              
//             }
//           }
//         });
       
       
//         //this.showAppliance=true;

//         //localStorage.setItem("applianceArray1",JSON.stringify(this.getValidateRes));

       

//        }
       
  
//     },
//     (err) => {

//       let message ="Sorry! Please try to add appliance again"
//         bootbox.dialog({
//           message: message,
//           buttons: {
            
//             ok: {
//               label: "Ok",
//               className: 'btn btn-primary btn-flat',
              
//             }
//           }
//         });
//      // console.log(JSON.stringify(err._body));
//     });
   
//   }  
//   else{
//     this.formValidationFields = this._fieldErrorDisplayService.validateForm(this.form, this.formValidationFields, "addAppliance", false)
//     $("#myModal").modal("show");
//   }
//   }
// closeModal(){
//   $("#myModal").modal("hide");
  
// }
// addApplianceToList(){

//     debugger;
//     if(this.onPageApplianceSent.length>0){

//       for(var i=0;i<this.onPageApplianceSent.length;i++){
//         this.onPageApplianceSent[i]["applianceStatus"]="Active";

//         this.applianceSent.push(this.onPageApplianceSent[i]);
      
//       }
//     }
   
   
//     this._addApplianceService.addAppliance(this.applianceSent).subscribe((res) => {
//       console.log("UserGroup is created");
      
//      this.getAddStatusFlag=res;

//      if(this.getAddStatusFlag["responseCode"]=="200"){
      
//       /*for(var i=0;i<this.applianceSent.length;i++){
//         for(var j=0;j<this.getValidateRes1.length;j++){

//           if(this.getValidateRes1[j]["applianceName"]==this.applianceSent[i]["applianceName"]){

//                 let deleteIndex=j;
//                 this.getValidateRes1.splice(deleteIndex,1);
//           }
        
//         }

//       }
//       for(var i=0;i<this.applianceSent.length;i++){
//         for(var j=0;j<this.showApp.length;j++){
//           if(this.showApp[j]["applianceName"]==this.applianceSent[i]["applianceName"]){

//             let deleteIndex1=j;
//             this.showApp.splice(deleteIndex1,1);
//       }
        
//         }

//       }
//       localStorage.setItem("applianceArray1",JSON.stringify(this.getValidateRes1));*/
//       let message = "Appliances added successfully.Please click OK to continue.";
//       bootbox.dialog({
//         message: message,
//         buttons: {
          
//           ok: {
//             label: "Ok",
//             className: 'btn btn-primary btn-flat',
//             callback: () => this.getRdirecttoListApp()  
//           }
//         }
//       });
//      }
     
       
     
//     },
//     (err) => {
//       console.log(JSON.stringify(err._body));
//     });

//   }
//   reloadPage(){
//     location.reload();
// }
  
//   addApplianceEvent(event,value){

//     debugger;
//     if (event.target.checked) {
//     if(this.appliancesListTemp.length>0){
//        for(var i=0;i<this.appliancesListTemp.length;i++){
//         if(this.appliancesListTemp[i]["applianceName"]==value){
//            delete this.appliancesListTemp[i]["applianceId"];
//             this.onPageApplianceSent.push(this.appliancesListTemp[i]);

           
//        }

//        }

//     }
    
// }
//   else{
//     for(var i=0;i<this.onPageApplianceSent.length;i++){

//       if(this.onPageApplianceSent[i]["applianceName"]==value){

//         let index=i;
//         this.onPageApplianceSent.splice(index,1);
//       }
//     }
    
//     /*let index = this.onPageApplianceSent.indexOf(value);
//     this.onPageApplianceSent.splice(index);
//     let index1=this.localStorageApplianceSent.indexOf(value)
//     this.localStorageApplianceSent.splice(index);*/

//   }
//    /* if(this.onPageApplianceSent.length!=null || this.localStorageApplianceSent.length!=null)

//     this.applianceSent.push(this.getValidateRes1[i]);
//     debugger;
//     this.checkboxFlag=event;
//     console.log(this.checkboxFlag);*/

//   }
  

// }
// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-createnewpartition',
//   templateUrl: './createnewpartition.component.html',
//   styleUrls: ['./createnewpartition.component.css']
// })
// export class CreatenewpartitionComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }
import { Component, OnInit ,ChangeDetectorRef,ViewChild} from '@angular/core';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, FormControl } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { AddApplianceService } from './../../../../services/addAppliance.service';
import { Router } from '@angular/router'; 
import { TabsetComponent } from 'ngx-bootstrap';

declare var jquery:any;
declare var $ :any;
declare var bootbox: any;
@Component({
  selector: 'app-partitionhostvm',
   templateUrl: './partitionhostvm.component.html',
    styleUrls: ['./partitionhostvm.component.css']
})
export class PartitionhostvmComponent implements OnInit {
  @ViewChild('staticTabs') staticTabs: TabsetComponent;
  showlist :  boolean = true;
  showlist1:  boolean = true;
  form: FormGroup;
  public successMessage:string;
  private groupsList:string;
  getValidateRes:object[]=[];
   getValidateRes1:object[]=[];
   getValidateRes3:object[]=[];
  private applianceSent:object[]=[];
  private localStorageApplianceSent:object[]=[];
  private onPageApplianceSent:object[]=[];
 showApp:object[]=[];
   showAppliance:boolean=false;
   private checkboxFlag:string;
   private getAddStatusFlag:string;
   private localStorageDefault:object[]=[];
     displayErrors: any = []; 
   showmessage:boolean=false;
   appliancesListTemp: any = [];
   utcNames=["(GMT-12:00) International Date Line West",
   "(GMT-11:00) Midway Island, Samoa",
   "(GMT-12:00) Tijuana, Baja California",
"(GMT-12:00) Bogota, Lima, Quito, Rio Branco",
  "(GMT-12:00) Eastern Time",
   "(GMT+05:30) Chennai, Kolkata, Mumbai, New Delhi",
   "(GMT+07:00) Bangkok, Hanoi, Jakarta",
   "(GMT+05:30) Sri Jayawardenapura",
   "(GMT+08:00) Beijing, Chongqing, Hong Kong, Urumqi",
  "(GMT+12:00) Fiji, Kamchatka, Marshall Is.",
   "(GMT+12:00) Auckland, Wellington"
]
   
    

  constructor(
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _addApplianceService :AddApplianceService,
    private chRef: ChangeDetectorRef,
    private router:Router,
    private builder: FormBuilder) { }
  
  ngOnInit() {
    debugger;
    this.createForm();
    this.getTempdata();
    this.tab=="1";
   
    
  }

 getRdirecttoListApp(){

 this.router.navigateByUrl("/listAppliance");
} 

  getTempdata(){
    this._addApplianceService.getAllTempAppliances().subscribe(
      res => {
        this.appliancesListTemp = res;

        console.log("hello", this.appliancesListTemp);
        
      },
      error => {
        console.log(error);
      },

    );

  }
  toggle(){
    this.showlist = true;
  }
  toggle1(){
    this.showlist = false;
  }
  toggle2(){
    this.showlist1 = true;
  }
  toggle3(){
    this.showlist1 = false;
  }

  createForm() {
      
      this.form = this.builder.group({
        partitionName: ['', Validators.required],
        csr: ['', Validators.required],
      partitionKeys: ['', Validators.required],
      sslContext: ['',Validators.required],
      accelerationDevices: ['', Validators.required],  
      gatewayIp: [''],
      subnetMask: [''],
      ipAddress:[''],
      hostname:[''],
      staticmac:[''],
      macAddress:[''],
      vlanId:[''],
      gateway:[''],
      wrap: [false],    
      backup: [false],
      dhcp:[true],
      enable:[false],
     
//username: ['', Validators.required], 
//password: ['', Validators.required], 







     
    });
  }

  /* onSubmit function is to create users*/
  

  onSuccessOperation(res) {
    let response = JSON.parse(res['_body']);
    console.log(response);
    this.successMessage = response.responseMessage;
  }

  onErrorOperation(errResp) {
  }

   // create a form errors
   public formValidationFields = {
    "partitionName": '',
    "csr": '',
    "partitionKeys": '',
    // "network": '',
     "accelerationDevices": '',
    // "gatewayIP": '',
    // "subnetMask": '',
    // "networkMode": '',
    // "hostname": '',
   
  }

  isFieldValid(field: string) {
   
    if (this.form.get(field).touched) {
      this.formValidationFields = this._fieldErrorDisplayService.validateField(this.form, field, this.formValidationFields, "addAppliance")
    }
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  submitApplication(isValid: boolean){
    
    
    debugger;
    if (isValid) {
    this._addApplianceService.verifyAppliances(this.form).subscribe((res) => {
      console.log("UserGroup is created");
      
      this.getValidateRes=res;
     console.log("Inside success");
      console.log("this is getValidateReS"+this.getValidateRes["code"]);
       if(this.getValidateRes["code"]=="200"){
        this.appliancesListTemp.push(res);
        let message = this.getValidateRes["message"]+".Appliance is verified and  is available to add.";
        bootbox.dialog({
          message: message,
          buttons: {
            
            ok: {
              label: "Ok",
              className: 'btn btn-primary btn-flat',
              
            }
          }
        });
          // alert(this.getValidateRes["message"]);
           //this.showApp.push(res);

          /* if(this.appliancesListTemp.length>0){
              for(var i=0;i<this.appliancesListTemp.length;i++){

                this.showApp=this.appliancesListTemp[i];
              }

           }*/
           
           

          
       }
      else if(this.getValidateRes["code"]=="409"){
        

        let message = this.getValidateRes["message"];
        bootbox.dialog({
          message: message,
          buttons: {
            
            ok: {
              label: "Ok",
              className: 'btn btn-primary btn-flat',
              
            }
          }
        });
       
       
      

       

       }
       
  
    },
    (err) => {

      let message ="Sorry! Please try to add appliance again"
        bootbox.dialog({
          message: message,
          buttons: {
            
            ok: {
              label: "Ok",
              className: 'btn btn-primary btn-flat',
              
            }
          }
        });
   
    });
   
  }  
  else{
    this.formValidationFields = this._fieldErrorDisplayService.validateForm(this.form, this.formValidationFields, "addAppliance", false)
    $("#myModal").modal("show");
  }
  }
closeModal(){
  $("#myModal").modal("hide");
  
}
addApplianceToList(){

    debugger;
    if(this.onPageApplianceSent.length>0){

      for(var i=0;i<this.onPageApplianceSent.length;i++){
        this.onPageApplianceSent[i]["applianceStatus"]="Active";

        this.applianceSent.push(this.onPageApplianceSent[i]);
      
      }
    }
   
   
    this._addApplianceService.addAppliance(this.applianceSent).subscribe((res) => {
      console.log("UserGroup is created");
      
     this.getAddStatusFlag=res;

     if(this.getAddStatusFlag["responseCode"]=="200"){
      
     
      let message = "Appliances added successfully.Please click OK to continue.";
      bootbox.dialog({
        message: message,
        buttons: {
          
          ok: {
            label: "Ok",
            className: 'btn btn-primary btn-flat',
            callback: () => this.getRdirecttoListApp()  
          }
        }
      });
     }
     
       
     
    },
    (err) => {
      console.log(JSON.stringify(err._body));
    });

  }
  reloadPage(){
    location.reload();
}
  
  addApplianceEvent(event,value){

    debugger;
    if (event.target.checked) {
    if(this.appliancesListTemp.length>0){
       for(var i=0;i<this.appliancesListTemp.length;i++){
        if(this.appliancesListTemp[i]["partitionName"]==value){
           delete this.appliancesListTemp[i]["applianceId"];
            this.onPageApplianceSent.push(this.appliancesListTemp[i]);

           
       }

       }

    }
    
}
  else{
    for(var i=0;i<this.onPageApplianceSent.length;i++){

      if(this.onPageApplianceSent[i]["partitionName"]==value){

        let index=i;
        this.onPageApplianceSent.splice(index,1);
      }
    }
    
    

  }
 

  }
  

tab : string;
 
  selectTab(tab_id: string) {
    this.tab = tab_id;
  }

}









