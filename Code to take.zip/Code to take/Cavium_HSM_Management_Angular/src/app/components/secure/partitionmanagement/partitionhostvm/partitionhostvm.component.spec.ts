import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PartitionhostvmComponent } from './partitionhostvm.component';

describe('PartitionhostvmComponent', () => {
  let component: PartitionhostvmComponent;
  let fixture: ComponentFixture<PartitionhostvmComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PartitionhostvmComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PartitionhostvmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
