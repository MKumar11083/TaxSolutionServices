
import { Component, OnInit, ChangeDetectorRef, ViewChild, Input } from '@angular/core';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, FormControl, FormArray } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { Router } from '@angular/router';
import { TabsetComponent } from 'ngx-bootstrap';
import { PartitionManagementService } from './../../../../services/partitionmanagement/partitionmanagement.service';

declare var jquery: any;
declare var $: any;
declare var bootbox: any;
@Component({
  selector: 'app-createnewpartition',
  templateUrl: './createnewpartition.component.html',
  styleUrls: ['./createnewpartition.component.css']
})
export class CreatenewpartitionComponent implements OnInit {
  @ViewChild('staticTabs') staticTabs: TabsetComponent;
  @ViewChild('insideTabs') insideTabs: TabsetComponent;
  @Input() selectedApplianceList;
  form: FormGroup;
  addAdvanced: FormGroup;
  tab: string;
  staticHostIp = [];
  dnsServers = [];
  domainNames = [];
  displayError: string;
  displayError1: string;
  successMessage: string;
  classStatic: string;
  classServer: string;
  classDomain: string;
  public loading = false; 
  constructor(
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private chRef: ChangeDetectorRef,
    private router: Router,
    private builder: FormBuilder,
    private _service: PartitionManagementService) { }

  
  ngOnInit() {
    debugger;
    this.createForm();
    this.initItemRows(null,null,null);
    this.tab = "1";
    console.log(this.selectedApplianceList);
    // set the appliance details to the form.
    this.classStatic = "btn-primary";
    this.classServer = "btn-default";
    this.classDomain = "btn-default";
    this.form.get('networkStats.general.eth0.ip').disable();
    this.form.get('networkStats.general.eth0.gateway').disable();
    this.form.get('networkStats.general.eth0.subnet').disable();
    this.form.get('networkStats.general.eth0.address').disable();
    this.form.get('networkStats.general.eth1.ip').disable();
    this.form.get('networkStats.general.eth1.subnet').disable();
    this.form.get('networkStats.general.eth1.address').disable();

  }
  // create form for createpartition .
  createForm() {
    this.form = this.builder.group({
      partitionName: ['', Validators.required],
      csr: [null],
      keys: [1, Validators.required],
      sslContexts: [1, Validators.required],
      acclrDev: [1, Validators.required],
      wrap: ['', Validators.required],
      backup: ['', Validators.required],
      applianceDetailModel: this.builder.group({
        applianceId: [null],
        applianceName: [null],
        applianceStatus: [null],
        serialNumber: [null],
        networkTimezone: [null],
        gatewayIp: [null],
        ipAddress: [null],
        networkId: [null],
        subnetMask: [null],
      }),
      networkStats: this.builder.group({
        general: this.builder.group({
          eth0: this.builder.group({
            ethName: ['eth0'],
            dhcp: [true],
            ip: [null],
            gateway: [null],
            subnet: [null],
            hostname: [null],
            staticMac: [null],
            address: [null],
            vlan: [null],
          }),
          eth1: this.builder.group({
            ethName: ['eth1'],
            dhcp: [true],
            disableEth1: [true],
            ip: [null],
            gateway: [null],
            subnet: [null],
            hostname: [null],
            staticMac: [null],
            address: [null],
            vlan: [null],
            id: [null],
          })
        }),
        advanced: this.builder.group({
          staticIpToHostConfig: this.builder.group({
            add: new FormArray([]),

          }),
          dnsConfig: this.builder.group({
            dnsServers: new FormArray([]),
            searchDomainNames: new FormArray([]),
            enableService: [null]
          }),
          ip: [''],
          hostname: [''],
          alias: [''],
          id: [''],
          dnsServer: [''],
          searchDomainName: ['']
        })
      }),
      partitionCertificate: [null],
      errorMessage: [null],
      username: [null],
      password: [null]
    });
  }

  initItemRows(ip,hostname,alias) {
    return this.addAdvanced = this.builder.group({
      ip: ip,
      hostname:hostname,
      alias: alias,
      id: [null]
    });

  }

  setApplianceDataToForm() {
    debugger;
    if(this.selectedApplianceList[0]['applianceId']!=null && this.selectedApplianceList[0]['applianceId']!=""){
      this.form.get('applianceDetailModel.applianceId').setValue(this.selectedApplianceList[0]['applianceId']);
    }
    if(this.selectedApplianceList[0]['applianceName']!=null && this.selectedApplianceList[0]['applianceName']!=""){
      this.form.get('applianceDetailModel.applianceName').setValue(this.selectedApplianceList[0]['applianceName']);
    }
    if(this.selectedApplianceList[0]['applianceStatus']!=null && this.selectedApplianceList[0]['applianceStatus']!=""){
      this.form.get('applianceDetailModel.applianceStatus').setValue(this.selectedApplianceList[0]['applianceStatus']);
    }
    if(this.selectedApplianceList[0]['serialNumber']!=null && this.selectedApplianceList[0]['serialNumber']!=""){
      this.form.get('applianceDetailModel.serialNumber').setValue(this.selectedApplianceList[0]['serialNumber']);
    }
    if(this.selectedApplianceList[0]['networkTimezone']!=null && this.selectedApplianceList[0]['networkTimezone']!=""){
      this.form.get('applianceDetailModel.networkTimezone').setValue(this.selectedApplianceList[0]['networkTimezone']);
    }
    if(this.selectedApplianceList[0]['gatewayIp']!=null && this.selectedApplianceList[0]['gatewayIp']!=""){
      this.form.get('applianceDetailModel.gatewayIp').setValue(this.selectedApplianceList[0]['gatewayIp']);
    }
    if(this.selectedApplianceList[0]['ipAddress']!=null && this.selectedApplianceList[0]['ipAddress']!=""){
      this.form.get('applianceDetailModel.ipAddress').setValue(this.selectedApplianceList[0]['ipAddress']);
    }
    if(this.selectedApplianceList[0]['networkId']!=null && this.selectedApplianceList[0]['networkId']!=""){
      this.form.get('applianceDetailModel.networkId').setValue(this.selectedApplianceList[0]['networkId']);
    }
    if(this.selectedApplianceList[0]['subnetMask']!=null && this.selectedApplianceList[0]['subnetMask']!=""){
      this.form.get('applianceDetailModel.subnetMask').setValue(this.selectedApplianceList[0]['subnetMask']);
    }
    if(this.selectedApplianceList[0]['userName']!=null && this.selectedApplianceList[0]['userName']!=""){
      this.form.get('username').setValue(this.selectedApplianceList[0]['userName']);
    }
    if(this.selectedApplianceList[0]['userPassword']!=null && this.selectedApplianceList[0]['userPassword']!=""){
      this.form.get('password').setValue(this.selectedApplianceList[0]['userPassword']);
    }
  }

  onErrorOperation(errResp) {
    
  }

  // create a form errors
  public formValidationFields = {
    "partitionName": '',
    "csr": '',
    "keys": '',
    "sslContexts": '',
    "acclrDev": '',
    "wrap": '',
    "backup": ''
  }

  isFieldValid(field: string) {
    if (this.form.get(field).touched) {
      this.formValidationFields = this._fieldErrorDisplayService.validateField(this.form, field, this.formValidationFields, "createPartition")
    }
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }
 
  selectTab(tab_id: string) {
    if (tab_id == "1") {
      this.classStatic = "btn-primary";
      this.classServer = "btn-default";
      this.classDomain = "btn-default";
    } else if (tab_id == "2") {
      this.classStatic = "btn-default";
      this.classServer = "btn-primary";
      this.classDomain = "btn-default";
    } else if (tab_id == "3") {
      this.classStatic = "btn-default";
      this.classServer = "btn-default";
      this.classDomain = "btn-primary";
    }
    this.tab = tab_id;
    this.displayError="";
  }


  onSubmit(isValid) {
    debugger;
    if (isValid) {
      this.setApplianceDataToForm();
      console.log(this.form.value);
      this.loading=true;
      this._service.createPartition(this.form.value).subscribe(
        res => {
          this.loading=false;
          if (res.code == "200") {
            this.router.navigateByUrl("/listPartition");
          } else {
            this.displayError1 = res.message;
          }
        },
        error => {
          console.log(error);
        },
      );
    } else {
      this.formValidationFields = this._fieldErrorDisplayService.validateForm(this.form, this.formValidationFields, "createPartition", false)
    }

  }

  addStaticHostIp() {
    debugger;
    this.displayError = "";
    if (this.form.get('networkStats.advanced.ip').value!="" && this.form.get('networkStats.advanced.hostname').value!="") {
      if (this.staticHostIp.length < 16) {
        let ip = this.form.get('networkStats.advanced.ip').value;
        let hostname = this.form.get('networkStats.advanced.hostname').value;
        let alias = this.form.get('networkStats.advanced.alias').value;
        const control = <FormArray>this.form.get('networkStats').get('advanced').get('staticIpToHostConfig').get('add');
        let staticHostIpData = {};

        staticHostIpData['ip'] = ip;
        staticHostIpData['hostname'] = hostname;
        staticHostIpData['alias'] = alias;
        // this.addAdvanced.get('ip').setValue(ip);
        // this.addAdvanced.get('hostname').setValue(hostname);
        // this.addAdvanced.get('alias').setValue(alias);
        control.push(this.initItemRows(ip,hostname,alias));
        // if (this.staticHostIp.length == 0) {
        //   control.removeAt(1);
        // }
        this.staticHostIp.push(staticHostIpData);

        this.form.get('networkStats.advanced.ip').setValue("");
        this.form.get('networkStats.advanced.hostname').setValue("");
        this.form.get('networkStats.advanced.alias').setValue("");
      } else {
        this.displayError = "Maximum records to add is 16."
      }
    } else {
      this.displayError = "Please enter the required fields"
    }
  }

  removeStaticHostIp(index) {
    const control = <FormArray>this.form.get('networkStats').get('advanced').get('staticIpToHostConfig').get('add');
    // remove the chosen row
    control.removeAt(index);
    let indexAt = this.staticHostIp.indexOf(index);
    this.staticHostIp.splice(indexAt);
  }

  addDnsServer() {
    debugger;
    this.displayError = "";
    if (this.dnsServers.length < 4) {
      if (this.form.get('networkStats.advanced.dnsServer').value!="") {
        const control = <FormArray>this.form.get('networkStats').get('advanced').
          get('dnsConfig').get('dnsServers');
        // control.push(this.form.get('networkStats.advanced.dnsServer').value);
        control.push(new FormControl(this.form.get('networkStats.advanced.dnsServer').value));
        this.dnsServers.push(this.form.get('networkStats.advanced.dnsServer').value);
        this.form.get('networkStats.advanced.dnsServer').setValue("");
      } else {
        this.displayError = "Please enter the required field";

      }
    } else {
      this.displayError = "Maximum records to add is 4."
    }
  }


  removeDnsServers(index) {
    debugger;
    const control = <FormArray>this.form.get('networkStats').get('advanced')
      .get('dnsConfig').get('dnsServers');
    // remove the chosen row
    control.removeAt(index);
    let indexAt = this.dnsServers.indexOf(index);
    this.dnsServers.splice(indexAt);
  }

  addDomainName() {
    debugger;
    this.displayError = "";
    if (this.domainNames.length < 4) {
      if (this.form.get('networkStats.advanced.searchDomainName').value!="") {
        const control = <FormArray>this.form.get('networkStats').get('advanced').
          get('dnsConfig').get('searchDomainNames');
        // control.push(this.form.get('networkStats.advanced.dnsServer').value);
        control.push(new FormControl(this.form.get('networkStats.advanced.searchDomainName').value));
        this.domainNames.push(this.form.get('networkStats.advanced.searchDomainName').value);
        this.form.get('networkStats.advanced.searchDomainName').setValue("");
      } else {
        this.displayError = " Please enter the required field"
      }
    } else {
      this.displayError = " Maximum records to add is 4."
    }
  }

  removeSearchDomain(index) {
    debugger;
    const control = <FormArray>this.form.get('networkStats').get('advanced')
      .get('dnsConfig').get('searchDomainNames');
    // remove the chosen row
    control.removeAt(index);
    let indexAt = this.domainNames.indexOf(index);
    this.domainNames.splice(indexAt);
  }

  toggleDhcpEth0(event) {
    debugger;
    console.log(this.form.get('networkStats.general.eth0.dhcp').value);
    this.form.get('networkStats.general.eth0.ip').reset();
    this.form.get('networkStats.general.eth0.gateway').reset();
    this.form.get('networkStats.general.eth0.subnet').reset();

    if (event.checked) {
      this.form.get('networkStats.general.eth0.ip').disable();
      this.form.get('networkStats.general.eth0.gateway').disable();
      this.form.get('networkStats.general.eth0.subnet').disable();
    } else {
      this.form.get('networkStats.general.eth0.ip').enable();
      this.form.get('networkStats.general.eth0.gateway').enable();
      this.form.get('networkStats.general.eth0.subnet').enable();
    }
  }

  toggleDhcpEth1(event) {
    debugger;
    this.form.get('networkStats.general.eth1.ip').reset();
    this.form.get('networkStats.general.eth1.subnet').reset();

    if (event.checked) {
      this.form.get('networkStats.general.eth1.ip').disable();
      this.form.get('networkStats.general.eth1.subnet').disable();
    } else {
      this.form.get('networkStats.general.eth1.ip').enable();
      this.form.get('networkStats.general.eth1.subnet').enable();
    }
  }

  disableEth1Fields(event) {
    debugger;
    this.form.get('networkStats.general.eth1.dhcp').reset();
    // this.form.get('networkStats.general.eth1.ip').reset();
    // this.form.get('networkStats.general.eth1.subnet').reset();
    this.form.get('networkStats.general.eth1.hostname').reset();
    this.form.get('networkStats.general.eth1.staticMac').reset();
    this.form.get('networkStats.general.eth1.address').reset();
    this.form.get('networkStats.general.eth1.vlan').reset();
    if (event.checked) {
      this.form.get('networkStats.general.eth1.dhcp').enable();
      this.form.get('networkStats.general.eth1.dhcp').setValue(true);
      // this.form.get('networkStats.general.eth1.ip').enable();
      // this.form.get('networkStats.general.eth1.subnet').enable();
      this.form.get('networkStats.general.eth1.hostname').enable();
      this.form.get('networkStats.general.eth1.staticMac').enable();
      this.form.get('networkStats.general.eth1.address').disable();
      this.form.get('networkStats.general.eth1.vlan').enable();
    } else {
      this.form.get('networkStats.general.eth1.dhcp').disable();
      // this.form.get('networkStats.general.eth1.ip').disable();
      // this.form.get('networkStats.general.eth1.subnet').disable();
      this.form.get('networkStats.general.eth1.hostname').disable();
      this.form.get('networkStats.general.eth1.staticMac').disable();
      this.form.get('networkStats.general.eth1.address').disable();
      this.form.get('networkStats.general.eth1.vlan').disable();
    }
  }

  toggleMacAddressEth0(event) {
    if (event.checked) {
      this.form.get('networkStats.general.eth0.address').enable();
    } else {
      this.form.get('networkStats.general.eth0.address').disable();
    }
  }

  toggleMacAddressEth1(event) {
    if (event.checked) {
      this.form.get('networkStats.general.eth1.address').enable();
    } else {
      this.form.get('networkStats.general.eth1.address').disable();
    }
  }

  public OnlyNumericValues(e) {
    let input;
    if (e.metaKey || e.ctrlKey) {
      return true;
    }
    if (e.which === 32) {
      return false;
    }
    if (e.which === 0) {
      return true;
    }
    if (e.which < 33) {
      return true;
    }
    input = String.fromCharCode(e.which);
    return !!/[\d\s]/.test(input);
  }

  closeMessage(){
    this.displayError1 = "";
  }
}





