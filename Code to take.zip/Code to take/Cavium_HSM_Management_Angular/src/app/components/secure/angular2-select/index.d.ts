export * from './dist/angular2-select';
