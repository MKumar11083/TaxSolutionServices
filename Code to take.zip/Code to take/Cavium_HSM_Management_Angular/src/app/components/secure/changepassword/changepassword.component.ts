import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, FormControl } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../services/common/field-error-display.service';
import { AnonymousSubscription } from "rxjs/Subscription";
import { UserManagementService } from './../../../services/usermanagement.service';
import { Router } from '@angular/router';
import { BreadcrumbService } from './../../../services/common/breadcrumb.service';
import { CommonServices} from './../../../services/common/common.services';
@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent implements OnInit {
  form: FormGroup;
  successMessage: string;
  errorMessages: any = [];
  changePasswordSubsc: AnonymousSubscription;

  constructor(private builder: FormBuilder, 
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _userManagementService: UserManagementService, 
    private router: Router,
    private _breadcrumbService:BreadcrumbService,
    private _commonServices:CommonServices) { }

  ngOnInit() {
    this._breadcrumbService.getBreadCrumbDetails("change-password");
    this.checkpassword();
  }
  checkpassword() {
    this.form = this.builder.group({
      oldPassword: ['', Validators.required],
      newPassword: ['', Validators.required],
      ConfirmPassword: ['', Validators.required],

    });
  }
  checkIfMatchingPasswords() {
    let newPassword = this.form.get("newPassword").value;
    let ConfirmPassword = this.form.get("ConfirmPassword").value;
    if (newPassword !== ConfirmPassword) {
      return false;
    }
    else {
      return true;
    }
  }
  onSubmit(isValid: boolean) {
    debugger;
    if (isValid) {
      let checksamePassword = this.checkIfMatchingPasswords();
      if (checksamePassword) {
        this.changePasswordSubsc = this._userManagementService.changePassword(this.form.value).subscribe(
          data => this.onSuccessOperation(data),
          err => this.onErrorOperation(err)
        );
      }
      else {
        this.errorMessages.push("New Password and Confirm Password should be same");
      }

    }else {
      this.formValidationFields = this._fieldErrorDisplayService.validateForm(this.form, this.formValidationFields, "changepassword", false)
    }
  }
  onSuccessOperation(response) {
    this.successMessage = "";
    this.errorMessages = [];
    let res = response;
    if (res.responseCode == "200") {
     // this.successMessage = res.responseMessage;
     this._commonServices.clearSession();
     sessionStorage.setItem("msg",res.responseMessage);
     this.router.navigateByUrl("/login");
    } else if (res.responseCode == "409" || res.responseCode == "-230") {
      this.errorMessages.push(res.responseMessage);
    } else if (res.responseCode == "500") {
      this.errorMessages.push(res.responseMessage);
    } else {
      this.errorMessages.push(res.responseMessage);
    }
  }
  onErrorOperation(errResp) {

  }
  reset() {
    this.form.reset();
    this.successMessage = "";
    this.errorMessages = [];
  }
  public formValidationFields = {
    "oldPassword": '',
    "newPassword": '',
    "ConfirmPassword": '',

  }
  isFieldValid(field: string) {
    if (this.form.get(field).touched) {
      this.formValidationFields = this._fieldErrorDisplayService.validateField(this.form, field, this.formValidationFields, "changepassword")
    }
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }
  closeMessage(){
    this.successMessage = "";
    this.errorMessages = [];
  }
}
