import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { LoginService } from './../../../services/login.service';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { NgxPermissionsService } from 'ngx-permissions';

declare var $: any;

import { Cookie } from 'ng2-cookies';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  errorMsg: string;
  message : string;
  constructor(private _router: Router, private _formBuilder:
    FormBuilder, private _loginService: LoginService, private permissionsService: NgxPermissionsService) { }

  ngOnInit() {
    
    this.errorMsg = "";
    this.message = "";
    this.loginForm = this._formBuilder.group({
      userName: '',
      Password: ''
    });
    this.errorMsg = sessionStorage.getItem("errorMsg");
    this.message = sessionStorage.getItem("msg");
    sessionStorage.removeItem("errorMsg");
    sessionStorage.removeItem("msg");
  }

  login() {
    this._loginService.obtainAccessToken(this.loginForm).subscribe(
      data => this.saveToken(data),
      err => {
        this.errorMsg = "Invalid Credentials";
      }
    );
  }
  /* save the OAuth token into Cookie*/
  saveToken(token) {
    var expireDate = new Date().getTime() + (1000 * token.expires_in);
    Cookie.set("access_token", token.access_token, expireDate);
    Cookie.set("refresh_token", token.refresh_token, expireDate);
    console.log('Obtained Access token');
    sessionStorage.setItem("username", this.loginForm.get('userName').value);
    this._router.navigate(['/dashboard']);
  }

}
