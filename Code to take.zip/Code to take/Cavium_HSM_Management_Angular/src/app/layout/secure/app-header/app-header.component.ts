import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { Cookie } from 'ng2-cookies';
import { CommonServices} from './../../../services/common/common.services';
@Component({
  selector: 'app-header',
  templateUrl: './app-header.component.html',
  styleUrls: ['./app-header.component.css']
})
export class AppHeaderComponent implements OnInit {
  disabled : boolean ;
  constructor(private _router:Router,private _commonServices:CommonServices) { }
  username :string;
  ngOnInit() {
    this.username=sessionStorage.getItem("username");
    //this.setLeftMenuDisable();
  }
  // setLeftMenuDisable(){
  //   this._commonServices.getDisabledLeftMenu().subscribe(disabled => {
  //      this.disabled = disabled; 
  //     });
    
  // }
  logout() {
    this._commonServices.clearSession();
    this._router.navigate(['/login']);
  }
}
