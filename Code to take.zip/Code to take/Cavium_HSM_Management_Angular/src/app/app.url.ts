import { Injectable } from '@angular/core';

@Injectable()
export class AppURL {
    /* Appliance Management*/
    public readonly GET_IN_PROGRESS_ACTIVITIES="getInProgressActivity";
   /* Partition Management */
    public readonly GET_LIST_PARTITIONS_URL = 'getListOfPartitions';
    public readonly POST_PARTITION_URL = 'createPartitions';
    public readonly VALIDATE_INIT_OPERATION = 'validateInitOperationForCreatePartition';
    

}