import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { HttpServices } from './../services/common/http.services';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { AppURL } from '../app.url';
@Injectable()
export class AppliancemanagementService {
  private selectedAppliancesData = new BehaviorSubject('');
  selectedAppliances = this.selectedAppliancesData.asObservable();

  private allAppliancesData = new BehaviorSubject('');
  allAppliancesList = this.allAppliancesData.asObservable()

  constructor(private _httpServices: HttpServices, private _http: Http,
    private _restURL: AppURL) {
  }

  addAppliance(form) {
    let url = "/createUser";
    return this._httpServices.httpPost(form, url);
  }
  getAllListAppliances() {
    let url = "/listAppliance";
    return this._httpServices.httpGet(url);
  }
  getAllSnapshotDetails() {
    let url = "/getSnapshotDetails";
    return this._httpServices.httpGet(url);
  }
  setRebootActivity(form) {
    let url = "/rebootAppliance";
    return this._httpServices.httpPost(form, url);
  }
  firmwareUpgrade(form) {
    let url = "/applianceFirmwareUpgrade";
    return this._httpServices.httpPost(form, url);
  }
  setZeroise(form) {
    let url = "/zeroizeAppliance";
    return this._httpServices.httpPost(form, url);
  }
  getHostSystemInfo(ipaddress) {
    let url = "/getHostSystemInfo/" + ipaddress + "/";
    console.log(url);
    return this._httpServices.httpGet(url);
  }

  searchAppliances(model) {
    let url = "/searchAppliance ";
    return this._httpServices.httpPost(model, url);
  }

  saveInitializedata(form) {
    let url = "/initilizeAppliance";
    return this._httpServices.httpPost(form, url);
  }

  getAdminVMInfo(ipaddress) {
    let url = "/getAdminVMInfo/" + ipaddress + "/";
    return this._httpServices.httpGet(url);
  }

  submitNetworkDetails(formData) {
    let url = "/modifyAppliance";
    return this._httpServices.httpPut(formData, url);
  }

  monitorLoginForm(form) {
    let url = "/hostMonitorStats";
    return this._httpServices.httpPost(form, url);
  }
  networkSettingsDataSubmit(networkData) {

    let url = "/hostNetworkVMConfig";
    return this._httpServices.httpPost(networkData, url);
  }

  setSelectedAppliances(item: any) {
    this.selectedAppliancesData.next(item);
  }
  setAllAppliances(items: any) {
    this.allAppliancesData.next(items);
  }
  getInProgressActivities() {
    return this._httpServices.httpGet(this._restURL.GET_IN_PROGRESS_ACTIVITIES);
  }
}
