import { Injectable } from '@angular/core';
import { HttpServices } from './../../services/common/http.services';
import { AppURL } from '../../app.url';

@Injectable()
export class PartitionManagementService {
    constructor(private _httpServices: HttpServices,
        private _restURL: AppURL) {
           
    }
 
    getListOfPartition(){
        return this._httpServices.httpGet(this._restURL.GET_LIST_PARTITIONS_URL);
    }

    createPartition(form){
        return this._httpServices.httpPost(form,this._restURL.POST_PARTITION_URL);
    }


    validateInitOperation(model){
        return this._httpServices.httpPost(model,this._restURL.VALIDATE_INIT_OPERATION);
    }
}