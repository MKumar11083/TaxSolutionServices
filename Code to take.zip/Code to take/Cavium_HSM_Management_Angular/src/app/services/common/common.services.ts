import { Injectable } from '@angular/core';
import { Cookie } from 'ng2-cookies';
@Injectable()
export class CommonServices {

    constructor() {

    }
    clearSession(){
        console.log("session clear before logout.....");
        sessionStorage.clear();
        Cookie.delete('refresh_token');
        Cookie.delete('access_token');
    }
    

}

