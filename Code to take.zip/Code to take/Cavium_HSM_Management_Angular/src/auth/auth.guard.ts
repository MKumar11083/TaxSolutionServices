import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { LoginService} from './../app/services/login.service';
@Injectable()
export class AuthGuard implements CanActivate {

    constructor(private router: Router,private _loginService:LoginService) { }

    canActivate() {
        // localStorage.removeItem('currentUser');
        // if (localStorage.getItem('currentUser')) {
        //     console.log("authenticated successfully..");
        //     return true;
        // }
        if(this._loginService.checkCredentials){
            
            return true;
        }else{
           
            this.router.navigate(['/login']);
             return false;
        }
    }
}