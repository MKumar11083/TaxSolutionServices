CREATE TABLE monitor_stats_details (
      monitorstats_id MEDIUMINT UNSIGNED NOT NULL auto_increment,
      appliance_ip varchar(255),
      hours_minutes varchar(50),
      status varchar(100),
      partition_name varchar(100),
      job_id varchar(100),
      start_time varchar(100),
      message MEDIUMTEXT,
      end_time varchar(100),
      data_id varchar(100),
	operation varchar(250),
	api_name varchar(250),
	created_date DATETIME,
      PRIMARY KEY (monitorstats_id)
      );

	  CREATE TABLE monitor_stats_data_details (
      data_id MEDIUMINT UNSIGNED NOT NULL auto_increment,
      cpu_id MEDIUMINT UNSIGNED,
      pcpu_id MEDIUMINT UNSIGNED,
      memory_id MEDIUMINT UNSIGNED,
      network_id MEDIUMINT UNSIGNED,  
      PRIMARY KEY (data_id)
      );
	  
	  	  CREATE TABLE monitor_stats_cpu_details (
      cpu_id MEDIUMINT UNSIGNED NOT NULL auto_increment,
      total_usage_detail varchar(100),
      updated_time varchar(100),
	PRIMARY KEY (cpu_id)
      );
	  
		
	  	 CREATE TABLE monitor_stats_usage_info_details (
      usageinfo_id MEDIUMINT UNSIGNED NOT NULL auto_increment,
      command varchar(100),
      usage_detail varchar(100),
	  pid varchar(100),
	  mem_usage_detail varchar(100),
	  cpu_id MEDIUMINT UNSIGNED,
	PRIMARY KEY (usageinfo_id),
	  FOREIGN KEY (cpu_id) REFERENCES monitor_stats_cpu_details(cpu_id)ON DELETE CASCADE ON UPDATE CASCADE
);
	  
	  CREATE TABLE monitor_stats_pcpu_details (
      pcpu_id MEDIUMINT UNSIGNED NOT NULL auto_increment,
     PRIMARY KEY (pcpu_id)	 
      );
	  
	CREATE TABLE monitor_stats_info_details (
      info_id MEDIUMINT UNSIGNED NOT NULL auto_increment,
      thread  INTEGER,
      name varchar(100),
	  cpu_percent varchar(100),
	  cpu INTEGER, 
	pcpu_id MEDIUMINT UNSIGNED,
	PRIMARY KEY (info_id),
FOREIGN KEY (pcpu_id) REFERENCES monitor_stats_pcpu_details(pcpu_id)ON DELETE CASCADE ON UPDATE CASCADE
);
      

CREATE TABLE monitor_stats_cpus_details (
      cpus_id MEDIUMINT UNSIGNED NOT NULL auto_increment,
      cpu_name varchar(100),  
	pcpu_id MEDIUMINT UNSIGNED,
	PRIMARY KEY (cpus_id),
	FOREIGN KEY (pcpu_id) REFERENCES monitor_stats_pcpu_details(pcpu_id)ON DELETE CASCADE ON UPDATE CASCADE
);
     

CREATE TABLE monitor_stats_memory_details (
      memory_id MEDIUMINT UNSIGNED NOT NULL auto_increment,
      usage_in_percentage varchar(100),
	  updated_time varchar(100),	  
	PRIMARY KEY (memory_id)	 
      );

CREATE TABLE monitor_stats_command_details (
      details_id MEDIUMINT UNSIGNED NOT NULL auto_increment,
      cpu varchar(100),
	  command varchar(100),	 
	mem varchar(100),	
	pid varchar(100),
	memory_id MEDIUMINT UNSIGNED NOT NULL,
	PRIMARY KEY (details_id),
	FOREIGN KEY (memory_id) REFERENCES monitor_stats_memory_details(memory_id)ON DELETE CASCADE ON UPDATE CASCADE
);
      

CREATE TABLE monitor_stats_usage_details (
      usage_id MEDIUMINT UNSIGNED NOT NULL auto_increment,
      total integer,
	  shared integer,	 
	free integer,	
	cache integer,
  buffers integer,
name varchar(250),
used integer,
	memory_id MEDIUMINT UNSIGNED NOT NULL,
	PRIMARY KEY (usage_id),

	FOREIGN KEY (memory_id) REFERENCES monitor_stats_memory_details(memory_id)ON DELETE CASCADE ON UPDATE CASCADE
);
     


CREATE TABLE monitor_stats_network_details (
      network_id MEDIUMINT UNSIGNED NOT NULL auto_increment,
      lo_id MEDIUMINT UNSIGNED NOT NULL,  
sit_id MEDIUMINT UNSIGNED NOT NULL, 
eth1_id MEDIUMINT UNSIGNED NOT NULL, 
eth0_id MEDIUMINT UNSIGNED NOT NULL, 
updated_time varchar(100),
	PRIMARY KEY (network_id)	 
      );

CREATE TABLE monitor_stats_eth0_details (
      eth0_id MEDIUMINT UNSIGNED NOT NULL auto_increment,
      incoming varchar(100),  
    mac_broadcast varchar(100),  
    ipv4_netmask varchar(100),  
    ipv6_netmask varchar(100),  
    stats varchar(100),  
    ipv6_address varchar(100),  
    mac_address varchar(100),  
    ipv4_broadcast varchar(100),   
    outgoing varchar(100),  
    ipv4_address varchar(100),   
	PRIMARY KEY (eth0_id)	 
      );

CREATE TABLE monitor_stats_eth1_details (
      eth1_id MEDIUMINT UNSIGNED NOT NULL auto_increment,
      incoming varchar(100),  
    mac_broadcast varchar(100),     
    stats varchar(100),     
    mac_address varchar(100),  
    outgoing varchar(100),    
	PRIMARY KEY (eth1_id)	 
      );
CREATE TABLE monitor_stats_sit_details (
      sit_id MEDIUMINT UNSIGNED NOT NULL auto_increment,
      incoming varchar(100),      
    stats varchar(100),     
    mac_address varchar(100),  
    outgoing varchar(100),    
	PRIMARY KEY (sit_id)	 
      );

CREATE TABLE monitor_stats_lo_details (
      lo_id MEDIUMINT UNSIGNED NOT NULL auto_increment,
      incoming varchar(100), 
      ipv4_netmask varchar(100), 
     ipv6_netmask varchar(100),
    stats varchar(100),  
ipv6_address  varchar(100),
    mac_address varchar(100),  
    outgoing varchar(100),  
ipv4_address  varchar(100),  
	PRIMARY KEY (lo_id)	 
      );
 
 