package com.cavium.controller.appliance;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.appliance.InitializeApplianceDetailModel;
import com.cavium.pojo.ManageCertificatesDetails;
import com.cavium.pojo.UserAttributes;
import com.cavium.service.alerts.AlertsService;
import com.cavium.service.appliance.ApplianceService;
import com.cavium.utill.CaviumResponseModel;

/**
 * * @author MK00497144 This class handling the appliance management endpoints
 */

@RestController
@RequestMapping("rest")
public class ApplianceController {

	@Autowired
	Environment env;

	@Autowired
	private ApplianceService applianceService;

	@Autowired
	private UserAttributes userAttributes;
	@Lookup
	public CaviumResponseModel getCaviumResponseModel() {
		return null;
	}

	@Autowired
	ServletContext context;

	@Autowired
	private AlertsService alertsService;

	private Logger logger = Logger.getLogger(this.getClass());


	/***
	 * This method is used to get appliance by id.
	 */
	@RequestMapping(value = "getAppliance/{applianceId}", method = RequestMethod.GET)
	public ApplianceDetailModel getApplianceById(@PathVariable("applianceId") String applianceId) {
		ApplianceDetailModel applianceDetailModels = null;
		logger.info("inside listAppliance");
		try {
			if(!StringUtils.isEmpty(applianceId)) {
				applianceDetailModels = applianceService.getApplianceById(applianceId);
			}else {
				applianceDetailModels=new ApplianceDetailModel();
				applianceDetailModels.setMessage("ApplianceID is null or empty");
			}
		} catch (Exception e) {
			logger.error("error occured during listAppliance" + e.getMessage());
		}
		return applianceDetailModels;
	}

	/**
	 * Method is used to get list of Appliances
	 * @return
	 */
	@RequestMapping(value = "listAppliance", method = RequestMethod.GET)
	public List<ApplianceDetailModel> getListOfAppliance() {
		List<ApplianceDetailModel> listApplianceDetailModels = null;
		logger.info("inside listAppliance");
		try {
			String loggedInUser = userAttributes.getlogInUserName();
			listApplianceDetailModels = applianceService.listOfApplianceByGroupId(loggedInUser);
		} catch (Exception e) {
			logger.error("error occured during listAppliance" + e.getMessage());
		}
		return listApplianceDetailModels;

	}

	/**
	 * Method is used to create new appliance
	 * @param applianceDetailModel
	 * @return
	 */

	@RequestMapping(value = "createAppliance", method = RequestMethod.POST)
	public final CaviumResponseModel createAppliance(@RequestBody List<ApplianceDetailModel> applianceDetailModel) {
		logger.info("Creating user with the details:" + applianceDetailModel);
		CaviumResponseModel responseModel=getCaviumResponseModel();
		responseModel = applianceService.createAppliance(applianceDetailModel);
		if (responseModel.getResponseMessage() == null || responseModel.getResponseMessage().length() == 0) {
			logger.info(applianceDetailModel.toString() + " - is created successfully.");
		} else {
			logger.info(
					responseModel.toString() + " Creation Failed: Reason:" + responseModel.getResponseMessage());

		}
		return responseModel;
	}

	/**
	 * This method is used to modify the Appliance
	 * 
	 * @param applianceDetailModel
	 * @return
	 */
	@RequestMapping(value = "modifyAppliance",method = RequestMethod.PUT)
	public final CaviumResponseModel modifyAppiance(@RequestBody ApplianceDetailModel applianceDetailModel) {
		CaviumResponseModel responseModel=getCaviumResponseModel();
		try {		
			logger.info("Inside modifyAppiance method of class ApplianceController.");
			String loggedInUser = userAttributes.getlogInUserName();

			if (applianceDetailModel != null) {
				responseModel = applianceService.modifyAppliance(loggedInUser, applianceDetailModel);
			} else {
				logger.error(env.getProperty("applianceModification.failureEmpty"));
				responseModel.setResponseCode("204");
				responseModel.setResponseMessage(env.getProperty("applianceModification.failureEmpty"));
			}
		} catch (Exception e) {
			logger.error("Error occured due to" + e.getMessage());
			// TODO: handle exception
		}
		logger.info("End of modifyAppiance method");
		return responseModel;
	}

	/**
	 * Method is used to delete the particular appliance
	 * @param applianceId
	 * @return
	 */
	@RequestMapping(value = "deleteAppliance", method = RequestMethod.DELETE)
	public final List<ApplianceDetailModel> deleteAppliance(@RequestBody List<ApplianceDetailModel> listApplianceDetailModels) {
		logger.info("Start of deleteAppliance Method");
		String loggedInUser = userAttributes.getlogInUserName(); 
		List<ApplianceDetailModel> applianceDetailModels= new ArrayList<ApplianceDetailModel>();

		for (Iterator<ApplianceDetailModel> iterator = listApplianceDetailModels.iterator(); iterator.hasNext();) {
			ApplianceDetailModel applianceDetailModel = (ApplianceDetailModel) iterator.next();
			ApplianceDetailModel objApplianceDetailModel=applianceDetailModel;
			try{
				logger.info("Appliance ID " + applianceDetailModel.getApplianceId() + " is going for deletion by " + loggedInUser + "");
				applianceDetailModel = applianceService.deleteAppliance(applianceDetailModel);
				logger.info(applianceDetailModel.getApplianceName() +" :: "+ env.getProperty("applianceDeletion.success"));
				if(applianceDetailModel!=null){
					applianceDetailModels.add(applianceDetailModel);
				}
			}catch (Exception e) {
				objApplianceDetailModel.setCode("500");
				objApplianceDetailModel.setMessage(env.getProperty("applianceDeletion.failureDB"));
				logger.info(applianceDetailModel.getApplianceName() + " :: "+ env.getProperty("applianceDeletion.failureDB"));
				applianceDetailModels.add(objApplianceDetailModel);
			}


		}
		logger.info("End of deleteAppliance Method");
		return applianceDetailModels;
	}

	/**
	 * Method is used to create new appliance
	 * @param applianceDetailModel
	 * @return
	 */
	@RequestMapping(value = "validateAppliance", method = RequestMethod.POST)
	public final ApplianceDetailModel validateAppliance(@RequestBody ApplianceDetailModel applianceDetailModel) {
		logger.info("Creating user with the details:" + applianceDetailModel); 
		if(applianceDetailModel!=null) {
			applianceDetailModel = applianceService.validateAppliance(applianceDetailModel);
		}
		return applianceDetailModel;
	}


	@RequestMapping(value = "rebootAppliance", method = RequestMethod.POST)
	public final List<ApplianceDetailModel> rebootAppliance(@RequestBody List<ApplianceDetailModel>  applianceDetailModellist) {
		logger.info("Creating user with the details:" + applianceDetailModellist);
		if(applianceDetailModellist!=null) {
			applianceDetailModellist = applianceService.rebootAppliance(applianceDetailModellist);
		}
		return applianceDetailModellist;
	}


	@RequestMapping(value = "zeroizeAppliance", method = RequestMethod.POST)
	public final List<ApplianceDetailModel> zeroizeAppliance(@RequestBody List<ApplianceDetailModel> applianceDetailModellist) {
		logger.info("Creating user with the details:" + applianceDetailModellist);
		if(applianceDetailModellist!=null) {
			applianceDetailModellist = applianceService.zeroizeAppliance(applianceDetailModellist);
		}
		return applianceDetailModellist;
	}

	/*
	 * Purpose of this method is when we have one InitializeApplianceDetailModel object with multiple Appliance Object  
	 */
	/*@RequestMapping(value = "initilizeAppliance", method = RequestMethod.POST)
	public final List<ApplianceDetailModel> initilizeAppliance(@RequestBody InitializeApplianceDetailModel initializeApplianceDetailModel) {
		logger.info("Start of initilizeAppliance Method");
		List<ApplianceDetailModel> applianceDetailModels=null;
		String message="";
		try{
			if(initializeApplianceDetailModel!=null) {
				applianceDetailModels = applianceService.initilizeAppliance(initializeApplianceDetailModel);
			}
		}	 
		catch (RuntimeException e) {
			logger.error("error in Initilize Applaince :" + e.getMessage());
			if("CaviumNetworkError".equals(e.getMessage())){
				message="CaviumNetworkError" ;
			}

		}
		if(applianceDetailModels==null){
			if(initializeApplianceDetailModel.getApplianceDetailModels()!=null && initializeApplianceDetailModel.getApplianceDetailModels().size()>0){
				applianceDetailModels= new ArrayList<ApplianceDetailModel>();
				for (Iterator<ApplianceDetailModel> iterator = initializeApplianceDetailModel.getApplianceDetailModels().iterator(); iterator.hasNext();) {
					ApplianceDetailModel applianceDetailModel = (ApplianceDetailModel) iterator.next();
					if("CaviumNetworkError".equals(message)){
						applianceDetailModel.setMessage("cavium network is not approachable for appliance "+applianceDetailModel.getApplianceName());
					 }else{
						 applianceDetailModel.setMessage("Error came while performing DB operation on appliance "+ applianceDetailModel.getApplianceName());
					 }
					applianceDetailModels.add(applianceDetailModel);
				}
			}	 
		}
		return applianceDetailModels;
	}*/

	@RequestMapping(value = "initilizeAppliance", method = RequestMethod.POST)
	public final List<ApplianceDetailModel> initilizeAppliance(@RequestBody List<InitializeApplianceDetailModel> initializeApplianceDetailModels) {
		logger.info("Start of initilizeAppliance Method");
		List<ApplianceDetailModel> applianceDetailModels=null;
		List<ApplianceDetailModel> listapplianceDetailModels=new ArrayList<ApplianceDetailModel>();
		String message="";
		String loggedInUser = userAttributes.getlogInUserName();
		InitializeApplianceDetailModel initializeApplianceDetailModel =null;
		if(initializeApplianceDetailModels!=null && initializeApplianceDetailModels.size()>0) {

			for (Iterator<InitializeApplianceDetailModel> iterator = initializeApplianceDetailModels.iterator(); iterator.hasNext();) {
				initializeApplianceDetailModel = (InitializeApplianceDetailModel) iterator.next();
				synchronized (initializeApplianceDetailModel) {
					try{

						//   ResponseEntity<String>  response=restClient.invokePOSTMethodObject("https://10.89.7.150/liquidsa/upload", bodyMap);
						applianceDetailModels = applianceService.initilizeAppliance(initializeApplianceDetailModel);
						if(applianceDetailModels!=null){
							for (Iterator<ApplianceDetailModel> iterate = applianceDetailModels.iterator(); iterate.hasNext();) {
								ApplianceDetailModel applianceDetailModel = (ApplianceDetailModel) iterate.next();
								listapplianceDetailModels.add(applianceDetailModel);
							}
						}
					}

					catch (RuntimeException e) {
						logger.error("error in Initilize Applaince :" + e.getMessage());
						if("CaviumNetworkError".equals(e.getMessage())){
							message="CaviumNetworkError" ;
						}else{
							message=e.getMessage() ;
						}
					}
				}
				if(applianceDetailModels==null){
					if(initializeApplianceDetailModel.getApplianceDetailModels()!=null && initializeApplianceDetailModel.getApplianceDetailModels().size()>0){
						for (Iterator<ApplianceDetailModel> itr = initializeApplianceDetailModel.getApplianceDetailModels().iterator(); itr.hasNext();) {
							ApplianceDetailModel applianceDetailModel = (ApplianceDetailModel) itr.next();
							if("CaviumNetworkError".equals(message)){
								applianceDetailModel.setMessage("cavium network is not approachable for this appliance.");
								//alertsService.createAlert(loggedInUser,"Device "+applianceDetailModel.getApplianceName()+"  try to perofrm initialize by "+loggedInUser+ " doesnot initialize due to connection error");
								alertsService.createAlert(loggedInUser,"Device "+applianceDetailModel.getApplianceName()+"  try to perofrm initialize by "+loggedInUser+ " doesnot initialize due to connection error",applianceDetailModel.getApplianceName(),applianceDetailModel.getApplianceId());
							}else{
								if(message.contains(applianceDetailModel.getApplianceName())){
									String newmessage = message.replaceAll(applianceDetailModel.getApplianceName(),"");
									applianceDetailModel.setMessage(newmessage);
									//alertsService.createAlert(loggedInUser,"Device "+applianceDetailModel.getApplianceName()+"  try to perofrm initialize by "+loggedInUser+ " doesnot initialize due to this reason ::"+newmessage);
									alertsService.createAlert(loggedInUser,"Device "+applianceDetailModel.getApplianceName()+"  try to perofrm initialize by "+loggedInUser+ " doesnot initialize due to this reason ::"+newmessage,applianceDetailModel.getApplianceName(),applianceDetailModel.getApplianceId());
								}
								else if("FileUploadError".equals(message)) {
									applianceDetailModel.setMessage("error coming  while upload file to cavium network");
									//alertsService.createAlert(loggedInUser,"Device "+applianceDetailModel.getApplianceName()+"  try to perofrm initialize by "+loggedInUser+ " doesnot initialize due to fileUpload error");
									alertsService.createAlert(loggedInUser,"Device "+applianceDetailModel.getApplianceName()+"  try to perofrm initialize by "+loggedInUser+ " doesnot initialize due to fileUpload error",applianceDetailModel.getApplianceName(),applianceDetailModel.getApplianceId());
								}else
								{
									applianceDetailModel.setMessage("Database error is coming while performing Initilized opeartion on this appliance.");	
									//alertsService.createAlert(loggedInUser,"Device "+applianceDetailModel.getApplianceName()+"  try to perofrm initialize by "+loggedInUser+ " doesnot initialize due to database error.");
									alertsService.createAlert(loggedInUser,"Device "+applianceDetailModel.getApplianceName()+"  try to perofrm initialize by "+loggedInUser+ " doesnot initialize due to database error.",applianceDetailModel.getApplianceName(),applianceDetailModel.getApplianceId());
								}
							}
							listapplianceDetailModels.add(applianceDetailModel);
						}
					}	 
				}	

			}
		}
		return listapplianceDetailModels;
	}
	@RequestMapping(value = "applianceFirmwareUpgrade", method = RequestMethod.POST)
	public final List<ApplianceDetailModel> applianceFirmwareUpgrade(@RequestBody List<ApplianceDetailModel> applianceDetailModellist) {
		logger.info("Creating user with the details:" + applianceDetailModellist);
		if(applianceDetailModellist!=null) {
			applianceDetailModellist = applianceService.applianceFirmwareUpgrade(applianceDetailModellist);
		}
		return applianceDetailModellist;
	}

	/**
	 * Method is used to get list of Appliances
	 * @return
	 */
	@RequestMapping(value = "searchAppliance", method = RequestMethod.POST)
	public List<ApplianceDetailModel> searchAppliance(@RequestBody ApplianceDetailModel applianceDetailModel) {
		List<ApplianceDetailModel> listApplianceDetailModels = null;
		logger.info("inside listAppliance");
		try {
			listApplianceDetailModels = applianceService.searchAppliance(applianceDetailModel);
		} catch (Exception e) {
			logger.error("error occured during listAppliance" + e.getMessage());
		}
		return listApplianceDetailModels;
	}

	/**
	 * Method is used to get listOfTempAppliances
	 * @param 
	 * @return
	 */

	@RequestMapping(value = "listOfTempAppliances", method = RequestMethod.GET)
	public final List<ApplianceDetailModel> listOfTempAppliances() {
		List<ApplianceDetailModel> applianceTempModel=null;
		logger.info("Geting list of temproary appliances");
		try {
			applianceTempModel = applianceService.getListOfTempAppliances();
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Error occured during listOfTempAppliances");
		}
		return applianceTempModel;
	}

	@RequestMapping(value = "createApplianceForTesting", method = RequestMethod.POST)
	public final CaviumResponseModel createApplianceForTesting(@RequestBody List<ApplianceDetailModel> applianceDetailModel) {
		logger.info("Creating user with the details:" + applianceDetailModel);
		CaviumResponseModel responseModel=getCaviumResponseModel();
		responseModel = applianceService.createApplianceForTesting(applianceDetailModel);
		if (responseModel.getResponseMessage() == null || responseModel.getResponseMessage().length() == 0) {
			logger.info(applianceDetailModel.toString() + " - is created successfully.");
		} else {
			logger.info(
					responseModel.toString() + " Creation Failed: Reason:" + responseModel.getResponseMessage());

		}
		return responseModel;
	}

	@RequestMapping(value = "downloadCertificate", method = RequestMethod.POST)
	public final void downloadCertificate(@RequestBody ManageCertificatesDetails manageCertificatesDetails,HttpServletResponse response ) {
		logger.info(" Start of downloadCertificate method of ApplianceController");
		String certificateType=manageCertificatesDetails.getCertificateType();
		String applianceIp=manageCertificatesDetails.getApplianceIp();
		CaviumResponseModel responseModel=getCaviumResponseModel();
		responseModel = applianceService.getCertificateURL(certificateType,applianceIp);
		File file=null;
		if(responseModel!=null && "200".equals(responseModel.getResponseCode())){
			try{
				file=applianceService.getCertificateFile(responseModel.getResponseMessage(),manageCertificatesDetails.getApplianceName());
				String  mimeType = "application/octet-stream";
				// Content-Type
				// application/pdf
				response.setContentType(mimeType);

				// Content-Disposition
				response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + file.getName());

				// Content-Length
				response.setContentLength((int) file.length());

				BufferedInputStream inStream = new BufferedInputStream(new FileInputStream(file));
				BufferedOutputStream outStream = new BufferedOutputStream(response.getOutputStream());

				byte[] buffer = new byte[1024];
				int bytesRead = 0;
				while ((bytesRead = inStream.read(buffer)) != -1) {
					outStream.write(buffer, 0, bytesRead);
				}
				outStream.flush();
				inStream.close();
			} catch (IOException e) {
				logger.error("error coming while download the certificate in downloadCertificate method of Appliance controller :: "+e.getMessage());
			}
			finally {
				if(file!=null){
					try{
						Files.deleteIfExists(Paths.get(file.getAbsolutePath()));
					}catch (Exception e) {
						logger.error("Error while deleting certificate file  in downloadCertificate method of Appliance controller :: " + e.getMessage()); 
					}
				}
			}     		
		}
		if(responseModel!=null && "409".equals(responseModel.getResponseCode())){
			try{
				response.setContentType("text/html"); 
				PrintWriter pw = response.getWriter(); 
				pw.write(responseModel.getResponseMessage()); 
				pw.close();
			}
			catch (Exception e) {
				logger.error("Error coming while writing error message to response in downloadCertificate method of Appliance controller :: " + e.getMessage()); 
			}
		}
		logger.info("End of downloadCertificate method of ApplianceController");
	}	 
	@RequestMapping(value = "uploadCertificates", method = RequestMethod.POST)
	public final CaviumResponseModel uploadCertificates(@RequestBody ManageCertificatesDetails manageCertificatesDetails ) {
		logger.info(" Start of uploadCertificates method of ApplianceController");		
		CaviumResponseModel responseModel=getCaviumResponseModel();
		responseModel = applianceService.uploadCertificate(manageCertificatesDetails);
		logger.info("End of uploadCertificates method of ApplianceController");
		return responseModel;
	}

}
