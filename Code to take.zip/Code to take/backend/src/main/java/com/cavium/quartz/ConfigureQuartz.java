
package com.cavium.quartz;

import java.io.IOException;
import java.util.Properties;

import org.quartz.JobDetail;
import org.quartz.SimpleTrigger;
import org.quartz.Trigger;
import org.quartz.spi.JobFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.scheduling.quartz.SimpleTriggerFactoryBean;

/*
 * @author MK00497144
 *
 */

@Configuration
public class ConfigureQuartz {


	 @Bean
    public JobFactory jobFactory(ApplicationContext applicationContext) {
    	QuartzJobFactory jobFactory = new QuartzJobFactory();
       jobFactory.setApplicationContext(applicationContext);
       return jobFactory;
    }

    @Bean
    public SchedulerFactoryBean schedulerFactoryBean(JobFactory jobFactory,
          Trigger[] inProgressActivityTaskJobTrigger) throws IOException {
       SchedulerFactoryBean factory = new SchedulerFactoryBean();
       factory.setJobFactory(jobFactory);
       factory.setAutoStartup(true);
       factory.setQuartzProperties(quartzProperties());
       factory.setTriggers(inProgressActivityTaskJobTrigger);
  
       return factory;
    }
    
    @Bean
    public Properties quartzProperties() throws IOException {
       PropertiesFactoryBean propertiesFactoryBean = new PropertiesFactoryBean();
       propertiesFactoryBean.setLocation(new ClassPathResource(
             "/quartz.properties"));
       propertiesFactoryBean.afterPropertiesSet();
       return propertiesFactoryBean.getObject();
    }
    private static SimpleTriggerFactoryBean createTrigger(JobDetail jobDetail, long frequencyTime) {
        SimpleTriggerFactoryBean factoryBean = new SimpleTriggerFactoryBean();
        factoryBean.setJobDetail(jobDetail);
        factoryBean.setStartDelay(0L);
        factoryBean.setRepeatInterval(frequencyTime);
        factoryBean.setRepeatCount(SimpleTrigger.REPEAT_INDEFINITELY);
        return factoryBean;
    }
    
    private static JobDetailFactoryBean createJobDetail(Class jobClass) {
        JobDetailFactoryBean factoryBean = new JobDetailFactoryBean();
        factoryBean.setJobClass(jobClass);
        // job has to be durable to be stored in DB:
        factoryBean.setDurability(true);
        return factoryBean;
    }

    @Bean
    public JobDetailFactoryBean inProgressActivityTaskJobDetail() {
       return createJobDetail(InProgressActivityTask.class);
    }

    @Bean
    public SimpleTriggerFactoryBean inProgressActivityTaskJobTrigger(
          @Qualifier("inProgressActivityTaskJobDetail") JobDetail jobDetail,@Value("${inProgressactivityjob.frequency}") long frequency) {
       return createTrigger(jobDetail, frequency);
    }
   
    @Bean
    public JobDetailFactoryBean monitorStatsJobDetail() {
       return createJobDetail(MonitorStatsJob.class);
    }
    
    @Bean
    public SimpleTriggerFactoryBean monitorStatsJobTrigger(
          @Qualifier("monitorStatsJobDetail") JobDetail jobDetail,@Value("${monitorstatsjob.frequency}") long frequency) {
       return createTrigger(jobDetail, frequency);
    }
}