package com.cavium.repository.recentactivity;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cavium.model.recentactivity.RecentActivity;

@Repository
public interface RecentActivityRepository  extends JpaRepository<RecentActivity, String> {
	
	
	@Query(value="select * from recent_activites rec where rec.user_groupid= :usergroupid order by rec.created_date desc",nativeQuery=true)
	public List<RecentActivity> getRecentActivity(@Param("usergroupid") String usergroupid);
	
}
