package com.cavium.model.appliance;
public enum StoreType
{
  TEMP("TEMP"),  PERMANENT("PERMANENT");
  
   String value;
  
  private StoreType(String value)
  {
    this.value = value;
  }
}
