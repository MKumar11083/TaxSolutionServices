package com.cavium.model.partition;

import java.io.Serializable;
import java.util.List;

public class StaticSearchADD implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -996840570646845408L;
	private List<PartitionAdvanceStaticHostIps> add;
	public List<PartitionAdvanceStaticHostIps> getAdd() {
		return add;
	}
	public void setAdd(List<PartitionAdvanceStaticHostIps> add) {
		this.add = add;
	} 
}
