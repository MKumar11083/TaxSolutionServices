package com.cavium.pojo;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

@Component
public class UserAttributes {

	private Logger logger = Logger.getLogger(this.getClass());
	
public String getlogInUserName()
	{
	String currentUserName=null;
	 Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
	  if (authentication!=null && !(authentication instanceof AnonymousAuthenticationToken)) {
	        currentUserName = authentication.getName();
	  }
	  
	  return currentUserName;
}


@SuppressWarnings("unchecked")
public List<SimpleGrantedAuthority> getUserRoles(){
	 List<SimpleGrantedAuthority> authorities=null;
	 try {
		  Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		  authorities = (List<SimpleGrantedAuthority>) authentication.getAuthorities();
	} catch (Exception e) {
		// TODO: handle exception
		logger.info("Error occured during getUserRoles");
	}
	 return authorities;
}

}
