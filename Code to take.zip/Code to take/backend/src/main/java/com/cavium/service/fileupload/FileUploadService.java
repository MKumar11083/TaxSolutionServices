package com.cavium.service.fileupload;



import java.io.File;

import com.cavium.model.appliance.DualFactorAuthDetailModel;
import com.cavium.utill.CaviumResponseModel;
/**
 *  * @author RK00490847
 *  
 */
public interface FileUploadService {
	
	/**
	 * This method is used to create the appliance
	 * @param loggedInUser
	 * @param applianceDetailModel
	 * @return
	 */
	CaviumResponseModel uploadFile(File certificate,String coUsername, String coPassword,String apiName,String ApplianceIp,DualFactorAuthDetailModel dual);
	
	 
		 
}
