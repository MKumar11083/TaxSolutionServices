package com.cavium.model.partition;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

public class PartitionInformationModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -945736959914063507L;
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "partition_info_id", nullable = false)
	private Long partitionInfoId;
	@Column(name="occupied_partitions")
	private String occupiedPartitions;
	@Column(name="total_acclrdev")
	private Integer totalAcclrDev;
	@Column(name="total_keys")
	private Integer totalKeys;
	@Column(name="occupied_keys")
	private Integer occupiedKeys;
	@Column(name="occupied_acclrdev")
	private Integer occupiedAcclrDev;
	@Column(name="total_partitions")
	private Integer totalPartitions;
	@Column(name="total_contexts")
	private Integer totalContexts;
	@Column(name="occupied_contexts")
	private Integer occupiedContexts;
	@Column(name="certificate_authenticate")
	private String certificateAuthenticate;
	@Column(name="auditLogs")
	private String auditLogs;
	
	@JsonManagedReference
	@OneToOne(fetch = FetchType.LAZY,mappedBy="informationModel",cascade = CascadeType.ALL)
	private PartitionData partitionData;
	
	@OneToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name = "partition_id", nullable = false)
	@JsonBackReference
	private PartitionDetailModel partitionDetailModel;
	
	
	public String getOccupiedPartitions() {
		return occupiedPartitions;
	}
	public void setOccupiedPartitions(String occupiedPartitions) {
		this.occupiedPartitions = occupiedPartitions;
	}
	public Integer getTotalAcclrDev() {
		return totalAcclrDev;
	}
	public void setTotalAcclrDev(Integer totalAcclrDev) {
		this.totalAcclrDev = totalAcclrDev;
	}
	public Integer getTotalKeys() {
		return totalKeys;
	}
	public void setTotalKeys(Integer totalKeys) {
		this.totalKeys = totalKeys;
	}
	public Integer getOccupiedKeys() {
		return occupiedKeys;
	}
	public void setOccupiedKeys(Integer occupiedKeys) {
		this.occupiedKeys = occupiedKeys;
	}
	public Integer getOccupiedAcclrDev() {
		return occupiedAcclrDev;
	}
	public void setOccupiedAcclrDev(Integer occupiedAcclrDev) {
		this.occupiedAcclrDev = occupiedAcclrDev;
	}
	public Integer getTotalPartitions() {
		return totalPartitions;
	}
	public void setTotalPartitions(Integer totalPartitions) {
		this.totalPartitions = totalPartitions;
	}
	public Integer getTotalContexts() {
		return totalContexts;
	}
	public void setTotalContexts(Integer totalContexts) {
		this.totalContexts = totalContexts;
	}
	public Integer getOccupiedContexts() {
		return occupiedContexts;
	}
	public void setOccupiedContexts(Integer occupiedContexts) {
		this.occupiedContexts = occupiedContexts;
	}
	public String getCertificateAuthenticate() {
		return certificateAuthenticate;
	}
	public void setCertificateAuthenticate(String certificateAuthenticate) {
		this.certificateAuthenticate = certificateAuthenticate;
	}
	public String getAuditLogs() {
		return auditLogs;
	}
	public void setAuditLogs(String auditLogs) {
		this.auditLogs = auditLogs;
	}
	public Long getPartitionInfoId() {
		return partitionInfoId;
	}
	public void setPartitionInfoId(Long partitionInfoId) {
		this.partitionInfoId = partitionInfoId;
	}
	public PartitionData getPartitionData() {
		return partitionData;
	}
	public void setPartitionData(PartitionData partitionData) {
		this.partitionData = partitionData;
	}
	public PartitionDetailModel getPartitionDetailModel() {
		return partitionDetailModel;
	}
	public void setPartitionDetailModel(PartitionDetailModel partitionDetailModel) {
		this.partitionDetailModel = partitionDetailModel;
	}
	
}
