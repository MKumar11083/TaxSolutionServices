package com.cavium.repository.alerts;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cavium.model.alerts.Alerts;

@Repository
public interface AlertsRepository  extends JpaRepository<Alerts, String> {
	
	
	@Query(value="select * from alerts alert where alert.user_groupid= :usergroupid order by alert.created_date desc",nativeQuery=true)
	public List<Alerts> getAlerts(@Param("usergroupid") String usergroupid);
	
}
