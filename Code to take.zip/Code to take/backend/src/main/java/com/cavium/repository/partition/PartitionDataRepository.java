package com.cavium.repository.partition;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cavium.model.partition.PartitionData;
@Repository
public interface PartitionDataRepository extends JpaRepository<PartitionData, Long>{
	@Query(value=" select * from partition_data where partition_id=:partitionId",nativeQuery=true)
	public PartitionData getPartitionData(@Param("partitionId") String partitionId);

}
