package com.cavium.controller.partition;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.partition.PartitionDetailModel;
import com.cavium.pojo.PartitionsDetails;
import com.cavium.pojo.UserAttributes;
import com.cavium.service.appliance.ApplianceService;
import com.cavium.service.partition.PartitionService;
import com.cavium.utill.CaviumResponseModel;

/*
 * 
 */
@RestController
@RequestMapping("rest")
public class PartitionController {
	
		@Autowired
		private UserAttributes userAttributes;
		
		@Autowired
		private ApplianceService applianceService;
		
		@Autowired
		private PartitionService partitionService;
		
		@Autowired
		PartitionsDetails partitionsDetails;
		
		
		
	private Logger logger = Logger.getLogger(this.getClass());
	
	/**
	 * This method is used to get PartitionsDetails
	 * @return
	 */
	@RequestMapping(value = "getPartitionsDetails", method = RequestMethod.GET)
	public PartitionsDetails getPartitionsDetails(){
		logger.info("start of getPartitionsDetails Method");
	 List<ApplianceDetailModel>listApplianceDetailModels= new ArrayList<ApplianceDetailModel>();
	 PartitionsDetails partitionsDetails=null;
		try{	 
			String loggedInUser = userAttributes.getlogInUserName(); 
			listApplianceDetailModels = applianceService.listOfApplianceByGroupId(loggedInUser);
			for (Iterator<ApplianceDetailModel> iterator = listApplianceDetailModels.iterator(); iterator.hasNext();) {
				ApplianceDetailModel applianceDetailModel = (ApplianceDetailModel) iterator.next();
				 partitionsDetails=partitionService.getPartitionInfo(applianceDetailModel,partitionsDetails);			
			}
			
		}catch(Exception e){
			logger.error("Error occured during getPartitionsDetails method of PartitionController class"+e.getMessage());

		}
		return partitionsDetails;
	}
	
	/**
	 * This method is used to get list of all partitions
	 * @return
	 */
	@RequestMapping(value = "getListOfPartitions", method = RequestMethod.GET)
	public List<PartitionDetailModel> getListOfPartitions() {
		// TODO Auto-generated method stub
		List<PartitionDetailModel> listPartitions=new ArrayList<PartitionDetailModel>();
		try {
			String loggedInUser = userAttributes.getlogInUserName();
			listPartitions=partitionService.getListOfPartitions(loggedInUser);
			
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getListOfPartitions method of PartitionController class"+e.getMessage());
		}
		return listPartitions;
	}
	/**
	 * This method is used to create partition
	 * @param partitionDetailModels
	 * @return
	 */
	@RequestMapping(value = "createPartitions", method = RequestMethod.POST)
	public PartitionDetailModel createPartition(@RequestBody PartitionDetailModel partitionDetailModels) {
		// TODO Auto-generated method stub
		String loggedInUser = userAttributes.getlogInUserName();
		PartitionDetailModel partition=partitionService.createPartition(loggedInUser, partitionDetailModels);
		try {
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during createPartition method of PartitionController class"+e.getMessage());
		}
		return partition;
	}
	/**
	 * This method is used to modify the partition 
	 * this method is used for future use
	 * @param partitionDetailModels
	 * @return
	 */
	@RequestMapping(value = "modifyPartition", method = RequestMethod.PUT)
	public PartitionDetailModel modifyPartition(@RequestBody PartitionDetailModel partitionDetailModels) {
		// TODO Auto-generated method stub
		return null;
	}
	/**
	 * This method is used to delete the partition
	 * @param partitionDetailModels
	 * @return
	 */
	@RequestMapping(value = "deletePartition", method = RequestMethod.DELETE)
	public CaviumResponseModel deletePartition(@RequestBody PartitionDetailModel partitionDetailModels) {
		CaviumResponseModel caviumResponseModel=null;
		try {
			String loggedInUser = userAttributes.getlogInUserName();
			caviumResponseModel=partitionService.deletePartition(loggedInUser, partitionDetailModels);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getPartitionNetworkStatsInfo of class PartitionContoller"+e.getMessage());
		}
		return caviumResponseModel;
	}
	/**
	 * This method is used to validate whether the init operation performed on appliance or not
	 * @param applianceDetailModel
	 * @return
	 */
	@RequestMapping(value = "validateInitOperationForCreatePartition", method = RequestMethod.POST)
	public CaviumResponseModel validateInitOperationForCreatePartition(@RequestBody ApplianceDetailModel applianceDetailModel) {
		CaviumResponseModel caviumResponse=null;
		// TODO Auto-generated method stub
		try {
			caviumResponse=partitionService.validateInitOperationForCreatePartition(applianceDetailModel);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during validateInitOperationForCreatePartition"+e.getMessage());
		}
		return caviumResponse;
	}
	/**
	 * This method is used to get partition info
	 * @param partitionDetailModels
	 * @return
	 */
	@RequestMapping(value = "getPartitionInfo", method = RequestMethod.POST)
	public CaviumResponseModel getPartitionInfo(@RequestBody PartitionDetailModel partitionDetailModels) {
		CaviumResponseModel caviumResponseModel=null;
		try {
			caviumResponseModel=partitionService.getPartitionInfo(partitionDetailModels);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getPartitionInfo of class PartitionContoller"+e.getMessage());
		}
		return caviumResponseModel;
	}
	
	/**
	 * This method is used to get partition stats
	 * @param partitionDetailModels
	 * @return
	 */
	@RequestMapping(value = "getPartitionStats", method = RequestMethod.POST)
	public CaviumResponseModel getPartitionStatsInfo(@RequestBody PartitionDetailModel partitionDetailModels) {
		CaviumResponseModel caviumResponseModel=null;
		try {
			caviumResponseModel=partitionService.getPartitionStatsInfo(partitionDetailModels);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getPartitionStats of class PartitionContoller"+e.getMessage());
		}
		return caviumResponseModel;
	}
	/**
	 * This method is used to get partition network stats 
	 * @param partitionDetailModels
	 * @return
	 */
	@RequestMapping(value = "getPartitionNetworkStats", method = RequestMethod.POST)
	public CaviumResponseModel getPartitionNetworkStatsInfo(@RequestBody PartitionDetailModel partitionDetailModels) {
		CaviumResponseModel caviumResponseModel=null;
		try {
			caviumResponseModel=partitionService.getPartitionNetworkStatsInfo(partitionDetailModels);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getPartitionNetworkStatsInfo of class PartitionContoller"+e.getMessage());
		}
		return caviumResponseModel;
	}
	
	@RequestMapping(value = "closeSessionForPartition", method = RequestMethod.PUT)
	public CaviumResponseModel closeSessionForPartition(@RequestBody PartitionDetailModel partitionDetailModels) {
		CaviumResponseModel caviumResponseModel=null;
		try {
			caviumResponseModel=partitionService.closeSessionForPartition(partitionDetailModels);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during closeSessionForPartition of class PartitionContoller"+e.getMessage());
		}
		return caviumResponseModel;
	}
	
	@RequestMapping(value = "resetPartition", method = RequestMethod.PUT)
	public CaviumResponseModel resetPartition(@RequestBody PartitionDetailModel partitionDetailModels) {
		CaviumResponseModel caviumResponseModel=null;
		String loggedInUser = userAttributes.getlogInUserName();
		try {
			caviumResponseModel=partitionService.resetPartition(loggedInUser, partitionDetailModels);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during resetPartition of class PartitionContoller"+e.getMessage());
		}
		return caviumResponseModel;
	}
	
}
