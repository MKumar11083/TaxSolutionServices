package com.cavium.pojo;

import org.springframework.stereotype.Component;

@Component
public class ManageCertificatesDetails {
	

	private String operationUsername;
	private String operationPassword;
	private String applianceIp;
	private String applianceName;
	private String certificateType;
	private String signedHSMfileContent;
	private String signedHSMfileName;
	private String signedHSMfileExtension;
	private String HSMfileContent;
	private String HSMfileName;
	private String HSMfileExtension;
	private long applianceId;
	/**
	 * @return the operationUsername
	 */
	public String getOperationUsername() {
		return operationUsername;
	}
	/**
	 * @param operationUsername the operationUsername to set
	 */
	public void setOperationUsername(String operationUsername) {
		this.operationUsername = operationUsername;
	}
	/**
	 * @return the operationPassword
	 */
	public String getOperationPassword() {
		return operationPassword;
	}
	/**
	 * @param operationPassword the operationPassword to set
	 */
	public void setOperationPassword(String operationPassword) {
		this.operationPassword = operationPassword;
	}
	 
 
	/**
	 * @return the applianceName
	 */
	public String getApplianceName() {
		return applianceName;
	}
	/**
	 * @param applianceName the applianceName to set
	 */
	public void setApplianceName(String applianceName) {
		this.applianceName = applianceName;
	}
	/**
	 * @return the certificateType
	 */
	public String getCertificateType() {
		return certificateType;
	}
	/**
	 * @param certificateType the certificateType to set
	 */
	public void setCertificateType(String certificateType) {
		this.certificateType = certificateType;
	}
	/**
	 * @return the signedHSMfileContent
	 */
	public String getSignedHSMfileContent() {
		return signedHSMfileContent;
	}
	/**
	 * @param signedHSMfileContent the signedHSMfileContent to set
	 */
	public void setSignedHSMfileContent(String signedHSMfileContent) {
		this.signedHSMfileContent = signedHSMfileContent;
	}
	/**
	 * @return the signedHSMfileName
	 */
	public String getSignedHSMfileName() {
		return signedHSMfileName;
	}
	/**
	 * @param signedHSMfileName the signedHSMfileName to set
	 */
	public void setSignedHSMfileName(String signedHSMfileName) {
		this.signedHSMfileName = signedHSMfileName;
	}
	/**
	 * @return the signedHSMfileExtension
	 */
	public String getSignedHSMfileExtension() {
		return signedHSMfileExtension;
	}
	/**
	 * @param signedHSMfileExtension the signedHSMfileExtension to set
	 */
	public void setSignedHSMfileExtension(String signedHSMfileExtension) {
		this.signedHSMfileExtension = signedHSMfileExtension;
	}
	/**
	 * @return the hSMfileContent
	 */
	public String getHSMfileContent() {
		return HSMfileContent;
	}
	/**
	 * @param hSMfileContent the hSMfileContent to set
	 */
	public void setHSMfileContent(String hSMfileContent) {
		HSMfileContent = hSMfileContent;
	}
	/**
	 * @return the hSMfileName
	 */
	public String getHSMfileName() {
		return HSMfileName;
	}
	/**
	 * @param hSMfileName the hSMfileName to set
	 */
	public void setHSMfileName(String hSMfileName) {
		HSMfileName = hSMfileName;
	}
	/**
	 * @return the hSMfileExtension
	 */
	public String getHSMfileExtension() {
		return HSMfileExtension;
	}
	/**
	 * @param hSMfileExtension the hSMfileExtension to set
	 */
	public void setHSMfileExtension(String hSMfileExtension) {
		HSMfileExtension = hSMfileExtension;
	}
	/**
	 * @return the applianceIp
	 */
	public String getApplianceIp() {
		return applianceIp;
	}
	/**
	 * @param applianceIp the applianceIp to set
	 */
	public void setApplianceIp(String applianceIp) {
		this.applianceIp = applianceIp;
	}
	/**
	 * @return the applianceId
	 */
	public long getApplianceId() {
		return applianceId;
	}
	/**
	 * @param applianceId the applianceId to set
	 */
	public void setApplianceId(long applianceId) {
		this.applianceId = applianceId;
	}
 
 

}
