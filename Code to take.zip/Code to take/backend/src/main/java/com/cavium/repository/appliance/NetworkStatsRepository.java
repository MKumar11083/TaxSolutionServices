package com.cavium.repository.appliance;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cavium.model.partition.NetworkStatsModel;

@Repository
public interface NetworkStatsRepository extends JpaRepository<NetworkStatsModel, Long> {

}
