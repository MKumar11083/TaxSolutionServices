package com.cavium.model.user;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

/*
 * DesignationApplianceModel Model class hold the relationship between Group and Appliances
 * author : RK00490847
 */
@Entity
@Table(name="designation_appliance")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class DesignationApplianceModel
implements Serializable
{
	private static final long serialVersionUID = 4692301322760007284L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	@Column(name="design_id")
	@JsonProperty(access = Access.WRITE_ONLY)
	private Long designationId;
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "appliance_id",nullable = false)
	private ApplianceDetailModel objApplianceDetailModel;
	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * @return the designationId
	 */
	public Long getDesignationId() {
		return designationId;
	}
	/**
	 * @param designationId the designationId to set
	 */
	public void setDesignationId(Long designationId) {
		this.designationId = designationId;
	}
	/**
	 * @return the objApplianceDetailModel
	 */
	public ApplianceDetailModel getObjApplianceDetailModel() {
		return objApplianceDetailModel;
	}
	/**
	 * @param objApplianceDetailModel the objApplianceDetailModel to set
	 */
	public void setObjApplianceDetailModel(ApplianceDetailModel objApplianceDetailModel) {
		this.objApplianceDetailModel = objApplianceDetailModel;
	}

}
