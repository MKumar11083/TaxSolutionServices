package com.cavium.service.fileupload;

import java.io.File;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;

import com.cavium.model.appliance.DualFactorAuthDetailModel;
import com.cavium.utill.CaviumResponseModel;
import com.cavium.utill.CaviumUtil;
import com.cavium.utill.RestClient;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
/**
 *  * @author RK00490847
 * 
 */
@Component
public class FileUploadServiceImpl implements FileUploadService {
	private Logger logger = Logger.getLogger(this.getClass());
 

	/**
	 * This class is used to set the response attributes for incoming requests
	 */
	@Lookup
	public CaviumResponseModel getCaviumResponseModel() {
		return null;
	}
 
	@Autowired
	RestClient restClient;

   
	@Override
	public CaviumResponseModel uploadFile(File certificate,String coUsername,String coPassword,String apiName,String ApplianceIp,DualFactorAuthDetailModel dualAuthModel) {
		logger.info("start of uploadFile method of FileUploadServiceImpl class");
		CaviumResponseModel caviumResponseModel=getCaviumResponseModel();
		MultiValueMap<String, Object> bodyMap = new LinkedMultiValueMap<>();
     try{
        bodyMap.add("file", CaviumUtil.getUserFileResource(certificate));
        bodyMap.add("username",coUsername);
        bodyMap.add("password", coPassword);
        bodyMap.add("type",apiName);
        if(dualAuthModel!=null) {
        	 String dualFactorHostname = dualAuthModel.getDualFactorAuthServerAddress();
			 Integer dualFactorPort  =dualAuthModel.getDualFactorAuthServerPortNo();
			 String dualFactorCertificate  = dualAuthModel.getDualFactorAuthServerCertId();
			 bodyMap.add("dualFactorHostname",dualFactorHostname);
			 bodyMap.add("dualFactorPort",dualFactorPort);
			 bodyMap.add("dualFactorCertificate",dualFactorCertificate);
        }
         ResponseEntity<String> response=restClient.invokePOSTMethodObject("https://"+ApplianceIp+"/liquidsa/upload", bodyMap);
         if(response!=null && response.getBody()!=null){
			ObjectMapper mapper = new ObjectMapper();
			JsonNode root = mapper.readTree(response.getBody());
			if(!root.isNull() && root.isArray()){
				for(int i=0;i<root.size();i++){
				JsonNode errors = root.get(i).path("errors");
				String status = root.get(i).path("status").asText();
				if(!errors.isNull() && errors.size()>0){
					if(!errors.isNull() && errors.size()>0){
						String encodeMessage = root.path("message").asText();
						Iterator<JsonNode> itr = errors.elements();                           
						while (itr.hasNext()) { 
						//	JsonNode temp = itr.next();
							 if(StringUtils.isEmpty(encodeMessage)){
								 caviumResponseModel.setResponseCode("409");
								 caviumResponseModel.setResponseMessage("error is coming while getting file upload Id from cavium Network.");
							}
							 else{
								 caviumResponseModel.setResponseCode("409");
								 caviumResponseModel.setResponseMessage(CaviumUtil.decodeMessageBase64(encodeMessage));
							 }   
						}
					}
				}
				 if(status.equalsIgnoreCase("Success")){
				String  uploadedFileID= root.get(i).path("uploadedFileID").asText();
				 caviumResponseModel.setResponseCode("200");
				 caviumResponseModel.setResponseMessage(uploadedFileID);
				 }
			 }
			}
		}else{
			 caviumResponseModel.setResponseCode("409");
			 caviumResponseModel.setResponseMessage("error is coming while getting file upload Id from cavium Network.");	
		}
  }catch (Exception e) {
	  logger.error("Error coming while upload file in uploadFile method of FileUploadServiceImpl class"+e.getMessage());
	}
 	logger.info("end of uploadFile method of FileUploadServiceImpl class");
  	return caviumResponseModel;
	}
}

