package com.cavium.controller.acl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.user.UserACLDetailsModel;
import com.cavium.service.user.UserService;

/*
 * This ListUserACLController class is used for display the list of all ACLs.
 *  @author RK00490847
 */
@RestController
@RequestMapping("rest")
public class ListUserACLController {

	// logger - instance of application log.
	private Logger logger = Logger.getLogger(this.getClass());

	// userService - Service class provide the interface for the Repository Operation.
	@Autowired
	private UserService userService;

	/*
	 * This getListACLs method will return all the Users.   
	 *  @return	
	 *  		- The List of All ACLs
	 */

	@RequestMapping(value = "listACLDetails" ,method = RequestMethod.GET)
	public final  List<UserACLDetailsModel> getListACLs(){
		logger.info("Entered in getListACLs method");
		UserACLDetailsModel userACLDetailsModel= new UserACLDetailsModel();
		List<UserACLDetailsModel> aclDetails= new ArrayList<UserACLDetailsModel>();
		aclDetails = userService.getACLDetails(userACLDetailsModel);
		logger.info("End of getListACLs mthod");
		return aclDetails;		
	}
}
