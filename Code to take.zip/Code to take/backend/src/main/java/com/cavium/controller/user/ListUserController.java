package com.cavium.controller.user;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.user.UserDetailModel;
import com.cavium.pojo.UserAttributes;
import com.cavium.service.user.UserService;

/*
 * This ListUserController class is used for display the list of users.
 *  @author RK00490847
 */
@RestController
@RequestMapping("rest")
public class ListUserController
{
	// logger - instance of application log.
	private Logger logger = Logger.getLogger(this.getClass());

	// userService - Service class provide the interface for the Repository Operation.
	@Autowired
	private UserService userService;
	@Autowired
	private UserAttributes userAttributes;

	/**
	 * This Interface is used to get the values from the property file
	 */
	@Autowired
	Environment env;

	/*
	 * This getListUser method will return all the Users. 
	 *  @return	
	 *  		- The List of All Users
	 */
	@RequestMapping(value = "listUsers" ,method = RequestMethod.GET)
	public List<UserDetailModel> getListUsers()
	{
		logger.info("Entered in getListUsers Method:");
		UserDetailModel  userDetailModel = new UserDetailModel();

		String loggedInUser = userAttributes.getlogInUserName();	
		List<UserDetailModel> userDetailsModel =new ArrayList<UserDetailModel>(); 
		UserDetailModel	objUserDetailModel=this.userService.getUserDetails(loggedInUser);
		if(objUserDetailModel.getObjUserACLDetailsModel()==null || !env.getProperty("user.superadmin").equals(objUserDetailModel.getObjUserACLDetailsModel().getAclName())) {
			if(objUserDetailModel.getObjUserGroupModel()!=null) {
				//userDetailModel.setUserGroupId(String.valueOf(objUserDetailModel.getObjUserGroupModel().getId()));
				userDetailsModel = this.userService.listUsers(userDetailModel,String.valueOf(objUserDetailModel.getObjUserGroupModel().getId()),loggedInUser);
			}
		}else {
			String groupId="%";
			userDetailsModel = this.userService.listUsers(userDetailModel,groupId,loggedInUser);
		}
		for (Iterator<UserDetailModel> iterator = userDetailsModel.iterator(); iterator.hasNext();) {
			UserDetailModel objuserDetailModel = (UserDetailModel) iterator.next();
			if(objuserDetailModel.getUserName().equals(loggedInUser) || objuserDetailModel.getObjUserACLDetailsModel().getAclName().equals(env.getProperty("user.superadmin")))
				iterator.remove();
		}
		logger.info("End of getListUsers mthod");

		return userDetailsModel;
	}
}
