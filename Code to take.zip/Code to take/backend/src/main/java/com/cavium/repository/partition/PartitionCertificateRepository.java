package com.cavium.repository.partition;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cavium.model.partition.PartitionCertificate;
@Repository
public interface PartitionCertificateRepository extends JpaRepository<PartitionCertificate, Long> {

}
