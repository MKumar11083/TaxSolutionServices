package com.cavium.controller.user;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.user.UserACLDetailsModel;
import com.cavium.model.user.UserDetailModel;
import com.cavium.model.user.UserGroupModel;
import com.cavium.model.user.UserWithGroupACLDetailsModel;
import com.cavium.pojo.UserAttributes;
import com.cavium.service.alerts.AlertsService;
import com.cavium.service.user.UserService;
import com.cavium.utill.CaviumResponseModel;
import com.cavium.utill.CaviumUtil;

/*
 * This ModifyUserController class is used for Modify the existing User.
 */
@RestController
@RequestMapping("rest")
public class ModifyUserController {
	private Logger logger = Logger.getLogger(getClass());
	// userService - Service class provide the interface for the Repository
	// Operation.
	@Autowired
	private UserService userService;

	@Lookup
	public CaviumResponseModel getCaviumResponseModel() {
		return null;
	}

	/**
	 * This Interface is used to get the values from the property file
	 */
	@Autowired
	Environment env;
	
	
	@Autowired
	private UserAttributes userAttributes;
	
	@Autowired
	private AlertsService alertsService;
	
	/*
	 * This getUserDetails method will get UserId from request and return the
	 * userDetails.
	 * 
	 * @param PathVariable - UserId
	 * 
	 * @return - The UserDetails associated with GroupDetails and ACL Details
	 */

	@RequestMapping(method = RequestMethod.GET, value = "getUserDetail/{userId}")
	public final UserWithGroupACLDetailsModel getUserDetails(@PathVariable("userId") String userId) {
		logger.info("Start of getUserDetails Method");
		UserWithGroupACLDetailsModel objModifyUserDetails = new UserWithGroupACLDetailsModel();
		try {
			logger.info("userid :: " + userId);
			if (StringUtils.isNotEmpty(userId)) {
				UserDetailModel userDetailModel = this.userService.getUserDetails(userId);
				if (userDetailModel != null) {
					List<UserGroupModel> listUserGroupModel = new ArrayList<UserGroupModel>();
					listUserGroupModel = this.userService.getUserGroups();
					List<UserACLDetailsModel> listUserACLDetailsModel = new ArrayList<UserACLDetailsModel>();
					listUserACLDetailsModel = userService.getAllACLDetails();
					String loggedInUser = userAttributes.getlogInUserName();
					UserDetailModel loginUserDetailModel = this.userService.getUserDetails(loggedInUser);
					if(loginUserDetailModel.getObjUserACLDetailsModel()==null || !env.getProperty("user.superadmin").equals(loginUserDetailModel.getObjUserACLDetailsModel().getAclName())) {
						if(listUserGroupModel!=null) {
							for (Iterator<UserGroupModel> iterator = listUserGroupModel.iterator(); iterator.hasNext();) {
								UserGroupModel userGroupModel = (UserGroupModel) iterator.next();							 	
								if(userDetailModel.getObjUserGroupModel()!=null) {
									if((!userDetailModel.getObjUserGroupModel().getRoleName().equals(userGroupModel.getRoleName())) && (!userId.equals(userGroupModel.getUsername()))) {
										iterator.remove();
									}
								}else {
									iterator.remove();
								}
							} 
						}		
					}
					if(listUserACLDetailsModel!=null) {
						for (Iterator<UserACLDetailsModel> iterator = listUserACLDetailsModel.iterator(); iterator.hasNext();) {
							UserACLDetailsModel aclDetailModel = (UserACLDetailsModel) iterator.next();
							if(env.getProperty("user.superadmin").equals(aclDetailModel.getAclName()) || loginUserDetailModel.getObjUserACLDetailsModel().getAclName().equals(aclDetailModel.getAclName())) {
								iterator.remove();
							}				
						} 
					}
					objModifyUserDetails.setListUserACLDetailsModel(listUserACLDetailsModel);
					objModifyUserDetails.setListUserGroupModel(listUserGroupModel);
					objModifyUserDetails.setUserDetailModel(userDetailModel);
				} else {
					logger.info("userid doesnot Exist in DataBase");
				}
			} else {
				logger.info("userid is coming as blank");
			}
		} catch (Exception exp) {
			logger.info("Some Error is coming while performing Opeartion:: " + exp.getMessage());
		}
		logger.info("End of getUserDetails Method");
		return objModifyUserDetails;
	}

	/*
	 * This method will update the UserDetails and return the success message or
	 * error message.
	 * 
	 * @param RequestBody - UserDetailModel from Request
	 * 
	 * @return responseModel - CaviumResponseModel Object
	 */
	@RequestMapping(method = RequestMethod.PUT, value = "modifyUser")
	public final CaviumResponseModel modifyUser(@RequestBody UserDetailModel userModel) {
		logger.info("Entered in modifyUser Method");
		CaviumResponseModel responseModel=getCaviumResponseModel();
		String loggedInUser = userAttributes.getlogInUserName();
		try {
			if (userModel != null) {
				responseModel = this.userService.modifyUser(userModel);
			} else {
				logger.error("user Details Empty");
				responseModel.setResponseCode("204");
				responseModel.setResponseMessage("user Details Empty");
			}
			logger.info("ResponseModel for modifyUser :: " + responseModel.toString());
			logger.info("End of modifyUser Method");
		} catch (Exception e) {
			responseModel.setResponseCode("500");
			responseModel.setResponseMessage("User is not able to modify");
			alertsService.createAlert(loggedInUser,"Error is coming while modify existing user "+userModel.getUserName()+" by "+loggedInUser +"");
		}
		return responseModel;
	}

}
