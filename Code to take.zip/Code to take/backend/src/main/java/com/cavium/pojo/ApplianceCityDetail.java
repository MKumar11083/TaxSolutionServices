package com.cavium.pojo;

public class ApplianceCityDetail {
	
	String cityName;
	/**
	 * @return the cityName
	 */
	public String getCityName() {
		return cityName;
	}
	/**
	 * @param cityName the cityName to set
	 */
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
 
	ApplianceStatus ApplianceStatus = new ApplianceStatus();
	/**
	 * @return the applianceStatus
	 */
	public ApplianceStatus getApplianceStatus() {
		return ApplianceStatus;
	}
	/**
	 * @param applianceStatus the applianceStatus to set
	 */
	public void setApplianceStatus(ApplianceStatus applianceStatus) {
		ApplianceStatus = applianceStatus;
	}

}
