package com.cavium.model.partition;

import java.io.Serializable;

public class PartitionInterfacesGeneral implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3106118667376486616L;
	
	private PartitionETH eth0;
	private PartitionETH eth1;
	public PartitionETH getEth0() {
		return eth0;
	}
	public void setEth0(PartitionETH eth0) {
		this.eth0 = eth0;
	}
	public PartitionETH getEth1() {
		return eth1;
	}
	public void setEth1(PartitionETH eth1) {
		this.eth1 = eth1;
	}
}
