package com.cavium.repository.appliance;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cavium.model.appliance.InitializeApplianceDetailModel;

@Repository
public interface InitializeRepository extends JpaRepository<InitializeApplianceDetailModel, Long> {

}
