package com.cavium.model.appliance;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.sql.Blob;


@Entity
@Table(name="dual_factor_auth")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class DualFactorAuthDetailModel implements Serializable {
	private static final long serialVersionUID = 8893200516025118371L;
 
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	@Column(name="dual_factor_auth_server_address")
	private String dualFactorAuthServerAddress;
	@Column(name="dual_factor_auth_server_port_no")
	private Integer dualFactorAuthServerPortNo;
	@Column(name="dual_factor_auth_server_cert_id")
	private String dualFactorAuthServerCertId;
	@Transient
	private String fileContent;
	@Transient
	private String fileName;
	@Transient
	private String fileExtension;
	
	@Transient
	private MultipartFile dualFactorCertificate;
	
	@OneToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name = "initialize_id", nullable = false)
	@JsonBackReference
	private InitializeApplianceDetailModel initializeApplianceDetailModel;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getDualFactorAuthServerAddress() {
		return dualFactorAuthServerAddress;
	}
	public void setDualFactorAuthServerAddress(String dualFactorAuthServerAddress) {
		this.dualFactorAuthServerAddress = dualFactorAuthServerAddress;
	}
 
 
	public InitializeApplianceDetailModel getInitializeApplianceDetailModel() {
		return initializeApplianceDetailModel;
	}
	public void setInitializeApplianceDetailModel(InitializeApplianceDetailModel initializeApplianceDetailModel) {
		this.initializeApplianceDetailModel = initializeApplianceDetailModel;
	}
	/**
	 * @return the dualFactorCertificate
	 */
	public MultipartFile getDualFactorCertificate() {
		return dualFactorCertificate;
	}
	/**
	 * @param dualFactorCertificate the dualFactorCertificate to set
	 */
	public void setDualFactorCertificate(MultipartFile dualFactorCertificate) {
		this.dualFactorCertificate = dualFactorCertificate;
	}
 
 
	/**
	 * @return the dualFactorAuthServerCertId
	 */
	public String getDualFactorAuthServerCertId() {
		return dualFactorAuthServerCertId;
	}
	/**
	 * @param dualFactorAuthServerCertId the dualFactorAuthServerCertId to set
	 */
	public void setDualFactorAuthServerCertId(String dualFactorAuthServerCertId) {
		this.dualFactorAuthServerCertId = dualFactorAuthServerCertId;
	}
	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}
	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	/**
	 * @return the fileExtension
	 */
	public String getFileExtension() {
		return fileExtension;
	}
	/**
	 * @param fileExtension the fileExtension to set
	 */
	public void setFileExtension(String fileExtension) {
		this.fileExtension = fileExtension;
	}
	/**
	 * @return the fileContent
	 */
	public String getFileContent() {
		return fileContent;
	}
	/**
	 * @param fileContent the fileContent to set
	 */
	public void setFileContent(String fileContent) {
		this.fileContent = fileContent;
	}
	/**
	 * @return the dualFactorAuthServerPortNo
	 */
	public Integer getDualFactorAuthServerPortNo() {
		return dualFactorAuthServerPortNo;
	}
	/**
	 * @param dualFactorAuthServerPortNo the dualFactorAuthServerPortNo to set
	 */
	public void setDualFactorAuthServerPortNo(Integer dualFactorAuthServerPortNo) {
		this.dualFactorAuthServerPortNo = dualFactorAuthServerPortNo;
	}
 
	
}
