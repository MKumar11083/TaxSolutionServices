package com.cavium.pojo.hostadminvm;

public class AuthMode
{
    private String encryption;

    private String password;

    public void setEncryption(String encryption){
        this.encryption = encryption;
    }
    public String getEncryption(){
        return this.encryption;
    }
    public void setPassword(String password){
        this.password = password;
    }
    public String getPassword(){
        return this.password;
    }
}
