package com.cavium.mail;

import java.util.Date;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.mail.MailException;
import org.springframework.mail.MailPreparationException;
import org.springframework.stereotype.Component;

/**
 * Manages the mail data and sending
 * 
 * @author RK00490847
 * 
 */
@Component
public class MailUtil {
	/**
	 * Handles notifications through mail
	 */
	@Autowired
	private MailService mailService;
	private Logger logger = Logger.getLogger(this.getClass());

	// get Property Value from mail property File
	@Autowired
	Environment env;

	@Value("${senderName}")
	private String defaultFromAddress;

	/**
	 * Default from name
	 */
	@Value("${senderAddress}")
	private String defaultFromName;

	public void mailNotificationToUser(String userId, final Map<String, String> toAddresses,
			final Map<String, String> ccAddresses, String templateKey, String subjectKey, String newPassword,String firstName) throws MailException,MailPreparationException,Exception{

		VelocityContext context = new VelocityContext();
		context.put("currentDate", new Date().toString());
		if(firstName!=null)
		context.put("firstName", firstName);
		context.put("newpass", newPassword);
		context.put("userid", userId);

		logger.info("To addresses" + toAddresses);
		
			String subject = subjectKey;
			String template = templateKey;

			mailService.sendMail(defaultFromName, defaultFromAddress, toAddresses, ccAddresses, null, subject, context,
					template);		 
	}
	
	
 
	
	

	/**
	 * @return the mailSender
	 */
	public final MailService getMailSender() {
		return mailService;
	}

	/**
	 * @param mailSender
	 *            the mailSender to set
	 */
	public final void setMailSender(MailService mailService) {
		this.mailService = mailService;
	}

}
