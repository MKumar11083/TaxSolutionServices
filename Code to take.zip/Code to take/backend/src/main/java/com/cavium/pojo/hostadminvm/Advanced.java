package com.cavium.pojo.hostadminvm;

import java.util.ArrayList;
import java.util.List;
public class Advanced
{
    private List<String> searchDomainNames;

    private List<StaticIpToHostConfig> staticIpToHostConfig;
    
    private List<String> removedHostIPs;

    private List<String> dnsServers;
    
    private Boolean enableDNSService;

	/**
	 * @return the searchDomainNames
	 */
	public List<String> getSearchDomainNames() {
		return searchDomainNames;
	}

	/**
	 * @param searchDomainNames the searchDomainNames to set
	 */
	public void setSearchDomainNames(List<String> searchDomainNames) {
		this.searchDomainNames = searchDomainNames;
	}

	/**
	 * @return the staticIpToHostConfig
	 */
	public List<StaticIpToHostConfig> getStaticIpToHostConfig() {
		return staticIpToHostConfig;
	}

	/**
	 * @param staticIpToHostConfig the staticIpToHostConfig to set
	 */
	public void setStaticIpToHostConfig(List<StaticIpToHostConfig> staticIpToHostConfig) {
		this.staticIpToHostConfig = staticIpToHostConfig;
	}

	/**
	 * @return the removedHostIPs
	 */
	public List<String> getRemovedHostIPs() {
		return removedHostIPs;
	}

	/**
	 * @param removedHostIPs the removedHostIPs to set
	 */
	public void setRemovedHostIPs(List<String> removedHostIPs) {
		this.removedHostIPs = removedHostIPs;
	}

	/**
	 * @return the dnsServers
	 */
	public List<String> getDnsServers() {
		return dnsServers;
	}

	/**
	 * @param dnsServers the dnsServers to set
	 */
	public void setDnsServers(List<String> dnsServers) {
		this.dnsServers = dnsServers;
	}

	/**
	 * @return the enableDNSService
	 */
	public Boolean getEnableDNSService() {
		return enableDNSService;
	}

	/**
	 * @param enableDNSService the enableDNSService to set
	 */
	public void setEnableDNSService(Boolean enableDNSService) {
		this.enableDNSService = enableDNSService;
	}

    
}