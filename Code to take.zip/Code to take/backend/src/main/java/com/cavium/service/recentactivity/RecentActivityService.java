package com.cavium.service.recentactivity;

import java.util.List;

import com.cavium.model.recentactivity.RecentActivity;


public interface RecentActivityService {
	
	/**
	 * Create recent activity
	 * @return
	 */
	public void createRecentActivity(String loggedInUser, String message);
	/**
	 * Get recent activity
	 * @return
	 */
	public List<RecentActivity> getRecentActivity(String groupId);

}
