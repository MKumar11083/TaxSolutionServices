package com.cavium.service.hostadminvm;



import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.hostadminvm.monitorstats.MonitorStats;
import com.cavium.pojo.hostadminvm.AdminSNMPConfig;
import com.cavium.pojo.hostadminvm.AdminVMConfig;
import com.cavium.pojo.hostadminvm.AdminVMData;
import com.cavium.pojo.hostadminvm.HostStats;
import com.cavium.utill.CaviumResponseModel;
/**
 *  * @author RK00490847
 *  This interface holds all the necessary operations for Host/Admin VM Screen
 */
public interface HostAdminVMService {
 
	HostStats GetHostAdminVMStats(ApplianceDetailModel applianceDetailModel ,HostStats hostStats,String apiName);
	
	AdminVMConfig GetAdminVMConfig(ApplianceDetailModel applianceDetailModel ,AdminVMConfig adminVMConfig);
	
	AdminSNMPConfig GetAdminSNMPConfig(ApplianceDetailModel applianceDetailModel ,AdminSNMPConfig adminSNMPConfig);
	
	CaviumResponseModel hostMonitorStats(@RequestBody ApplianceDetailModel applianceDetailModel, String apiName);
  
	CaviumResponseModel setHostNetorkVmConfig(String applianceIp,AdminVMData adminVMData);
	
	List<MonitorStats> getMonitorStats(String applianceIp,String apiName);

  void createMonitorStats(String applianceIp,String apiName,MonitorStats monitorStats);
  

   
		 
}
