package com.cavium.utill;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.CharacterIterator;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.text.StringCharacterIterator;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

/**
 * Handling the utility methods for the application.
 * 
 * @author PK0041117
 * @version 1.0
 * @since 0.1
 */
public class CaviumUtil {
	/**
	 * The constructor create the instance of PortalUtil class.
	 */
	private CaviumUtil() {
	}

	public static final int PAGESIZE = 50;
	public static final String PAGEEXPORTSTART = "0";
	public static final String PAGEEXPORTSIZE = "100";
	public static final String notPresent = "NotPresent";
	public static final String success = "0";
	public static final String failure = "1";
	public static final String warning = "2";
	public static final String error = "error";
	private static final int MINUTES_IN_AN_HOUR = 60;
	private static final int SECONDS_IN_A_MINUTE = 60;
	private static final String DAYS = "days";
	private static final String DAY = "day";
	private static final String HOURS = "hours";
	private static final String HOUR = "hour";
	private static final String SECOND = "second";
	private static final String SECONDS = "seconds";
	private static final String MINUTES = "minutes";
	private static final String MINUTE = "minute";
	private static final String SECRET_KEY = "Cavium@SecretKey"; // 128 bit key
	private static final String INITVECTOR = "RandomInitVector"; // 16 bytes IV

	 

	private static Logger logger = Logger.getLogger(CaviumUtil.class);

	// ~ Methods
	// --------------------------------------------------------------------------

	/**
	 * This method formats the date to "yyyy-MM-dd" format
	 * 
	 * @param stringDate
	 *            Date in string
	 * @return Date - Date object in "yyyy-MM-dd" format
	 */
	public static Date formatDate(String stringDate) {
		// Date format is updated as yyyy-MM-dd"
		SimpleDateFormat inputFormatter = new SimpleDateFormat("yyyy-MM-dd");
		Date dateFormatted = null;
		String strDate = stringDate;
		// create new date if string Date is empty
		if ("".equals(strDate)) {
			strDate = inputFormatter.format(new Date());
		}
		try {
			dateFormatted = inputFormatter.parse(strDate);
			// dateFormatted = formatter.parse(formatter.format(date));
		} catch (ParseException e) {
			// e.printStackTrace();
		}
		return dateFormatted;
	}

	/**
	 * This method get the formated data
	 * 
	 * @param strDate
	 *            Date in string
	 * @return Date - Date object in "yyyy-MM-dd" format
	 */
	public static Date getFormattedDate(String strDate) {
		SimpleDateFormat inputFormatter = new SimpleDateFormat("yyyy-MM-dd");
		Date dateFormatted = null;
		if (strDate != null && strDate.length() > 0) {
			try {
				dateFormatted = inputFormatter.parse(strDate);
				// dateFormatted = formatter.parse(formatter.format(date));
			} catch (ParseException e) {
				logger.error("Exception" + e.getStackTrace());
			}
		}
		return dateFormatted;
	}

	/**
	 * convert the given format date string to a date object
	 * 
	 * @param stringDate
	 *            as a string
	 * @param strInputDtFormat
	 *            as a string
	 * @return equivalent date string, return current date input string is empty
	 */
	public static Date formatDate(String stringDate, final String strInputDtFormat) {
		final SimpleDateFormat inputFormatter = new SimpleDateFormat(strInputDtFormat);
		Date dateFormatted = null;
		String strDate = stringDate;
		if ("".equals(strDate)) {
			strDate = inputFormatter.format(new Date());
		}
		try {
			dateFormatted = inputFormatter.parse(strDate);
		} catch (ParseException e) {
			logger.error("Exception" + e.getStackTrace());
		}
		return dateFormatted;
	}

	/**
	 * Method check string for null and returns empty string
	 * 
	 * @param objInput
	 *            : Input integer string
	 * 
	 * @return : int value corresponding to input string, o for null or empty
	 *         input.
	 */
	public static int getIntValue(final String objInput) {
		int intValue = 0;

		if (objInput != null && !"".equals(objInput.trim()) && !"null".equals(objInput)) {
			try {
				intValue = Integer.parseInt(objInput);
			} catch (NumberFormatException objNFException) {
				intValue = 0;
			}
		}
		return intValue;
	}

	/**
	 * Method check string for null and returns empty string
	 * 
	 * @param objInput
	 *            : Input integer string
	 * 
	 * @return : Integer corresponding to input string, null for empty input
	 *         string.
	 */
	public static Integer getInteger(final String objInput) {
		Integer integerValue = null;

		if (objInput != null && !"".equals(objInput.trim()) && !"null".equals(objInput)) {
			try {
				integerValue = new Integer(objInput.trim());
			} catch (NumberFormatException objNFException) {
				logger.error("Exception" + objNFException.getStackTrace());
			}
		}
		return integerValue;
	}

	/**
	 * Method check string for null and returns empty string
	 * 
	 * @param objInput
	 *            : Input integer string
	 * 
	 * @return : int value corresponding to input string, o for null or empty
	 *         input.
	 */
	public static int getStringTOIntValue(final String objInput) {
		Float val = 0.0f;
		if (objInput != null && !"".equals(objInput.trim()) && !"null".equals(objInput)) {
			try {
				val = Float.parseFloat(objInput);
			} catch (NumberFormatException e) {
				logger.error("Exception" + e.getStackTrace());
			}
		}
		return val.intValue();
	}

	/**
	 * Added to create the string representation of the date based on the
	 * incoming system
	 * 
	 * @param incomingTS
	 *            : calendar
	 * @param dateFormat
	 *            : date format
	 * @return string value of converted dateTime
	 */

	public static String convertTimeStamp(Calendar incomingTS, String dateFormat) {
		return convertTimeStamp(incomingTS, dateFormat, null);
	}

	/**
	 * Added to create the string representation of the date based on the
	 * incoming system
	 * 
	 * @param incomingTS
	 *            : calendar
	 * @param dateFormat
	 *            : date format
	 * @param localeString
	 *            : data for set the Time zone.
	 * @return string : converted dateTime
	 */

	public static String convertTimeStamp(Calendar incomingTS, String dateFormat, String localeString) {
		String outboundTS = "";
		SimpleDateFormat sdfTimeStamp;
		String locale = localeString;

		if (!getNVL(dateFormat).equals("")) {
			sdfTimeStamp = new SimpleDateFormat(dateFormat);
		} else {
			sdfTimeStamp = new SimpleDateFormat("yyyy-MM-dd");
		}
		/** Need to format the incoming timestamp to UTC format **/
		try {
			if (getNVL(locale).equals("")) {
				locale = "America/Chicago";
			}
			sdfTimeStamp.setTimeZone(TimeZone.getTimeZone(locale));
			outboundTS = sdfTimeStamp.format(incomingTS.getTime());
		} catch (Exception e) {
			logger.error("Exception" + e.getStackTrace());
		}

		return outboundTS;
	}

	/**
	 * Method check string for null and returns empty string
	 * 
	 * @param objInput
	 *            : an object of type string
	 * 
	 * @return : an object of type string
	 */
	public static String getNVL(final String objInput) {
		String strNVL = objInput;
		if (objInput == null || "null".equals(objInput.trim())) {
			strNVL = "";
		}
		return strNVL.trim();
	}

	/**
	 * This method get the lower limit for pagination return the string hold the
	 * lower value
	 * 
	 * @param page
	 *            current page number.
	 * @param pageSize
	 *            current page size.
	 * 
	 */
	// DB - Pagination - START
	public static String getLowerLimit(final int page, final int pageSize) {
		String lowerLimit = "0";
		int lowerLimitI = 0;
		lowerLimitI = page * pageSize;
		lowerLimit = Integer.toString(lowerLimitI);
		logger.info("=======lowerLimit===========:" + lowerLimit + ":");
		return lowerLimit;
	}

	/**
	 * This method get the Upper limit for pagination return the string hold the
	 * upper value
	 * 
	 * @param page
	 *            current page number.
	 * @param pageSize
	 *            current page size.
	 * 
	 */
	public static String getUpperLimit(final int page, final int pageSize) {
		String upperLimit = "10";
		int upperLimitI = 0;
		upperLimitI = (page + 1) * pageSize;
		upperLimit = Integer.toString(upperLimitI);
		logger.info("=======lowerLimit===========:" + upperLimit + ":");
		return upperLimit;
	}

	// DB - Pagination - END

	/**
	 * This method check Null String .
	 * 
	 * @param value
	 *            as string .
	 * @return value of String if not null else null
	 * 
	 */

	public static String checkNullString(String value) {
		if (value != null && value.trim().length() > 0) {
			return value;
		} else {
			return null;
		}
	}

	/**
	 * This method check Null String without trim.
	 * 
	 * @param value
	 *            as string .
	 * @return value of String if not null else null
	 * 
	 */

	public static String checkNullStringWithSpaces(String value) {
		if (value != null && value.trim().length() > 0) {
			return value;
		} else {
			return null;
		}
	}

	/**
	 * This method Convert Date format from dd-MM-YYYY HH:mm:ss to yyyy:MM:dd
	 * HH:mm:ss.
	 * 
	 * @param dateStr
	 *            date in String format.
	 * @return String in format yyyy:MM:dd HH:mm:ss
	 * 
	 */

	public static String formatDateTime(String dateStr) {
		if (dateStr != null && dateStr.trim().length() > 0) {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			Date date;
			String formattedDate = "";
			try {
				date = formatter.parse(dateStr);
				formattedDate = dateFormat.format(date);

			} catch (ParseException e) {
				// TODO Auto-generated catch block
				logger.error("ParseException " + e);
			}
			return formattedDate;
		} else {
			return null;
		}
	}

	public static String forXML(String aText) {
		final StringBuilder result = new StringBuilder();
		final StringCharacterIterator iterator = new StringCharacterIterator(aText);
		char character = iterator.current();
		while (character != CharacterIterator.DONE) {
			if (character == '<') {
				result.append("&lt;");
			} else if (character == '>') {
				result.append("&gt;");
			} else if (character == '\"') {
				result.append("&quot;");
			} else if (character == '\'') {
				result.append("&#039;");
			} else if (character == '&') {
				result.append("&amp;");
			} else {
				// the char is not a special one
				// add it to the result as is
				result.append(character);
			}
			character = iterator.next();
		}
		return result.toString();
	}
	public static String getRandomText() {
		return RandomStringUtils.random(8, true, true);
	}


	public static String formatDatefromLong(long input){
		Date date = new Date(input);
		Calendar cal = new GregorianCalendar();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MMM/dd hh:mm:ss z");
		sdf.setCalendar(cal);
		cal.setTime(date);
		return sdf.format(date);

	}
	/*
	 * Convert Long into Days,Hours,Minutes and Seconds Format
	 */
	public static String timeInDaysHoursFormat(long seconds) {
		String daysConstant=DAYS;
		String hoursConstant=HOURS;
		String secondsConstant=SECONDS;
		String minutesConstant=MINUTES;

		StringBuffer formatedDate= new StringBuffer();
		int days = (int)TimeUnit.SECONDS.toDays(seconds);        
		long hours = TimeUnit.SECONDS.toHours(seconds) - (days *24);
		long minutes = TimeUnit.SECONDS.toMinutes(seconds) - (TimeUnit.SECONDS.toHours(seconds)* 60);
		long second = TimeUnit.SECONDS.toSeconds(seconds) - (TimeUnit.SECONDS.toMinutes(seconds) *60);
		if(days==1){
			daysConstant=DAY; 
		} 
		if(hours==1){
			hoursConstant=HOUR;
		}
		if(minutes==1){
			minutesConstant=MINUTE;
		}
		if(second==1){
			secondsConstant=SECOND; 
		}
		if(days!=0){
			formatedDate.append(days +" "+daysConstant+" ");
		}
		if(hours!=0){
			formatedDate.append(hours + " "+ hoursConstant+" ");
		}
		if(minutes!=0){
			formatedDate.append(minutes+ " " +minutesConstant + " ");
		}
		if(second!=0){
			formatedDate.append(second+" "+secondsConstant);
		}
		return formatedDate.toString();
	}

	public static long hoursToSeconds(long hours) {
		return hours * MINUTES_IN_AN_HOUR * SECONDS_IN_A_MINUTE;
	}

	public static long minutesToSeconds(long minutes) {
		return minutes * SECONDS_IN_A_MINUTE;
	}


	public static String decodebase64Message(String encodedMessage){
		String decodedMessage="";
		if(StringUtils.isNotEmpty(encodedMessage)){
			byte[] byteArray = Base64.decodeBase64(encodedMessage);
			decodedMessage = new String(byteArray);	
		}
		return decodedMessage;
	}
	
	public static double calculatePercetage(double total, double used){	
		double usedPercentage=0.0;
		if(!(total==0.0 && used==0.0)){
		DecimalFormat f = new DecimalFormat("##.00");
		usedPercentage=(used/total)*100;
		usedPercentage=Double.parseDouble(f.format(usedPercentage));
		} 
		return usedPercentage;
	}
	

	  public static String encrypt(String password) {
	        try {
	            IvParameterSpec iv = new IvParameterSpec(INITVECTOR.getBytes("UTF-8"));
	            SecretKeySpec skeySpec = new SecretKeySpec(SECRET_KEY.getBytes("UTF-8"), "AES");

	            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
	            cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);

	            byte[] encrypted = cipher.doFinal(password.getBytes());
	            
	            return Base64.encodeBase64String(encrypted);
	        } catch (Exception ex) {
	          logger.error("encrypt Exception " + ex.getMessage());
	        }
	        return "";
	    }

	    public static String decrypt(String encryptedPassword) {
	        try {
	            IvParameterSpec iv = new IvParameterSpec(INITVECTOR.getBytes("UTF-8"));
	            SecretKeySpec skeySpec = new SecretKeySpec(SECRET_KEY.getBytes("UTF-8"), "AES");

	            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
	            cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);

	            byte[] original = cipher.doFinal(Base64.decodeBase64(encryptedPassword));

	            return new String(original);
	        } catch (Exception ex) {
	        	logger.error("decrypt Exception " + ex.getMessage());
	        }

	        return "";
	    }
	    
	    /*
	     * Decode the message that are coming from cavium rest Call
	     */
	    public static String decodeMessageBase64(String encryptedMessage) {
	    	String decodeMessage="";
	        try {
	        	if(encryptedMessage!=null){
	        	byte[] byteArray = Base64.decodeBase64(encryptedMessage.getBytes());
	        	 decodeMessage = new String(byteArray);
	        	}	        
	        } catch (Exception ex) {
	        	logger.error("decrypt Exception " + ex.getMessage());
	        }
	        return decodeMessage;
	    }
	    /*
	     * format the current date into Date with TimeStamp
	     */
		public static String formatDateTimeFromCurrenDate(Date date) {
				DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
				String formattedDate = "";
				if(date!=null){
				formattedDate = formatter.format(date);
				}
				return formattedDate;
		}
		
	    public static Resource getUserFileResource(File convertedfile) throws IOException {
	        return new FileSystemResource(convertedfile);     
	      }
	     
	      
	      public static File createFile(String name, String extenstion,String content) throws IOException {
	    	  
	        String dir = System.getProperty("java.io.tmpdir");
	        String fileName="";
	        if(!StringUtils.isEmpty(extenstion)) {
	        	 fileName=name+"."+extenstion;
	        }else {
	        	 fileName=name;
	        }
	      	 String filedir =dir+"/"+fileName;
	         File file = new File(filedir);
	         file.createNewFile();
	         FileOutputStream fos = new FileOutputStream(file);
	         fos.write(content.getBytes());
	         fos.close();
	         return file;
	      }
	  
}

