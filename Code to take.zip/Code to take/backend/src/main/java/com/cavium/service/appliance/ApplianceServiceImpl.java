package com.cavium.service.appliance;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.appliance.DualFactorAuthDetailModel;
import com.cavium.model.appliance.InitializeApplianceDetailModel;
import com.cavium.model.appliance.InitializeAppliancesRelationshipModel;
import com.cavium.model.appliance.StoreType;
import com.cavium.model.recentactivity.InProgressActivity;
import com.cavium.model.user.DesignationApplianceModel;
import com.cavium.model.user.UserDetailModel;
import com.cavium.model.user.UserGroupModel;
import com.cavium.pojo.ApplianceCityDetail;
import com.cavium.pojo.ApplianceInfo;
import com.cavium.pojo.HSMInfo;
import com.cavium.pojo.ManageCertificatesDetails;
import com.cavium.pojo.UserAttributes;
import com.cavium.pojo.hostadminvm.AdminVMData;
import com.cavium.pojo.hostadminvm.Data;
import com.cavium.pojo.hostadminvm.DrvReqIdQueue;
import com.cavium.pojo.hostadminvm.FwReqIdQueue;
import com.cavium.pojo.hostadminvm.HostStats;
import com.cavium.pojo.hostadminvm.RamStats;
import com.cavium.pojo.hostadminvm.RxQueue;
import com.cavium.pojo.hostadminvm.StaticIpToHostConfig;
import com.cavium.pojo.hostadminvm.SwapStats;
import com.cavium.pojo.hostadminvm.SystemUpTime;
import com.cavium.pojo.hostadminvm.TxQueue;
import com.cavium.pojo.hostadminvm.Vmstats;
import com.cavium.repository.appliance.ApplianceRepository;
import com.cavium.repository.appliance.DesignationAppliance;
import com.cavium.repository.appliance.InitializeAppliancesRelationshipReposiotry;
import com.cavium.repository.appliance.InitializeRepository;
import com.cavium.repository.user.UserGroupRepository;
import com.cavium.repository.user.UserRepository;
import com.cavium.service.alerts.AlertsService;
import com.cavium.service.fileupload.FileUploadService;
import com.cavium.service.recentactivity.InProgressActivityService;
import com.cavium.service.recentactivity.RecentActivityServiceImpl;
import com.cavium.utill.CaviumResponseModel;
import com.cavium.utill.CaviumUtil;
import com.cavium.utill.RestClient;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
/**
 *  * @author MK00497144
 *  Class is used as a service implementation for Appliance Management
 */
@Component
public class ApplianceServiceImpl implements ApplianceService {
	private Logger logger = Logger.getLogger(this.getClass());

	/**
	 * ApplicationRepository - Repository class for perform Database operation on ApplicationDetailModel
	 */
	@Autowired
	private ApplianceRepository applianceRepository;


	@Autowired
	private InitializeRepository initializeRepository;

	@Autowired
	private FileUploadService fileUploadService;

	@Autowired
	private InitializeAppliancesRelationshipReposiotry initializeAppliancesRelationshipReposiotry;

	/**
	 * This class is used to set the response attributes for incoming requests
	 */
	@Lookup
	public CaviumResponseModel getCaviumResponseModel() {
		return null;
	}

	/**
	 * This Interface is used to get the values from the property file
	 */
	@Autowired
	Environment env;
	/*
	 * getAllAppliancesDetails method is used for fetch All appliances Details.
	 * 
	 * @return listApplianceDetailModel - List of ApplianceDetailModel Object.
	 * 
	 */

	@Autowired
	RestClient restClient;

	@Autowired
	DesignationAppliance designationAppliance;

	@Autowired
	UserGroupRepository userGroupRepository;

	@Autowired
	private UserAttributes userAttributes;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private RecentActivityServiceImpl recentActivityServiceImpl;

	@Autowired
	private AlertsService alertsService;

	@Autowired
	private HSMInfo hsmInfo;

	@Autowired
	private InProgressActivityService inProgressActivityService;

	@Override
	@Transactional
	public List<ApplianceDetailModel> getListOfAppliances() {
		List<ApplianceDetailModel> listApplianceDetailModel = null;
		CaviumResponseModel responseModel=getCaviumResponseModel();
		try {	
			listApplianceDetailModel = applianceRepository.findAll();
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured due to db error inside getListOfAppliances Method of class ApplianceServiceImpl ::" + e.getMessage());
			responseModel.setResponseCode("500");
			responseModel.setResponseMessage(env.getProperty("applianceList.failureDB"));
		}
		return listApplianceDetailModel;
	}


	@Override
	@Transactional
	public CaviumResponseModel createAppliance(List<ApplianceDetailModel> applianceDetailModel) {

		// TODO Auto-generated method stub
		CaviumResponseModel responseModel=getCaviumResponseModel();	 
		String loggedInUser = userAttributes.getlogInUserName();
		if (applianceDetailModel != null && applianceDetailModel.size() > 0) {

			for(ApplianceDetailModel app : applianceDetailModel) {
				try{
					List<ApplianceDetailModel> tempApplianceDetailmodel=applianceRepository.getApplianceExists(app.getIpAddress());
					if(tempApplianceDetailmodel.size() == 1 ) {
						ApplianceDetailModel tempAppliance=tempApplianceDetailmodel.get(0);
						if(tempAppliance!=null && tempAppliance.getStoreType().equals(StoreType.TEMP)) {
							tempAppliance.setCreatedBy(loggedInUser);
							tempAppliance.setCreatedDate(new Date());
							tempAppliance.setStoreType(StoreType.PERMANENT);
							tempAppliance.setApplianceStatus("Active");
							if(StringUtils.isEmpty(tempAppliance.getAuthId())) {
								tempAppliance.setAuthId("1234");
							}
							ApplianceDetailModel applianceTemp=applianceRepository.save(tempAppliance);
							if(applianceTemp!=null) {
								List<UserGroupModel> usg=userGroupRepository.findGroupDetailsForGroupName(env.getProperty("user.defaultusergroup")); 
								if(!usg.isEmpty()) {
									UserGroupModel userGroupModel=(UserGroupModel)usg.get(0);
									DesignationApplianceModel designationApplianceModel=new DesignationApplianceModel();
									designationApplianceModel.setDesignationId(userGroupModel.getId());
									designationApplianceModel.setObjApplianceDetailModel(applianceTemp);
									designationAppliance.save(designationApplianceModel);
								}
							}
							responseModel.setResponseCode("200");
							responseModel.setResponseMessage(env.getProperty("applianceCreation.success"));
							recentActivityServiceImpl.createRecentActivity(loggedInUser, "New device "+app.getApplianceName()+" added by "+loggedInUser);
						}
					}else {
						//alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+" added by "+loggedInUser+" does not exists into the cavium networks");
						alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+" added by "+loggedInUser+" does not exists into the cavium networks",app.getApplianceName(),app.getApplianceId());
						responseModel.setResponseCode("409");
						responseModel.setResponseMessage(env.getProperty("appliance.notexists.cavium.network"));
					}
				} catch (Exception e) {
					logger.error("Error occured due to db error inside createAppliance Method of class ApplianceServiceImpl ::" + e.getMessage());
					responseModel.setResponseCode("500");
					responseModel.setResponseMessage(env.getProperty("applianceCreation.failureDB"));
					//alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+" added by "+loggedInUser+" does not exists into the cavium networks");
					alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+" added by "+loggedInUser+" does not exists into the cavium networks",app.getApplianceName(),app.getApplianceId());
				}
			}
		} else {
			logger.error("ApplianceDetailModel is empty or null ::");
			responseModel.setResponseCode("204");
			responseModel.setResponseMessage(env.getProperty("applianceCreation.failureEmpty"));
		}

		return responseModel;
	}

	/*
	 * This method is used to modify the appliance 
	 * (non-Javadoc)
	 * @see com.cavium.service.appliance.ApplianceService#modifyAppliance(java.lang.String, com.cavium.model.appliance.ApplianceDetailModel)
	 */
	@Override
	@Transactional
	public CaviumResponseModel modifyAppliance(String loggedInUser, ApplianceDetailModel applianceDetailModel) {
		CaviumResponseModel responseModel=getCaviumResponseModel();
		try	{
			if(applianceDetailModel!=null && applianceDetailModel.getApplianceId()!=null && applianceDetailModel.getApplianceId().longValue() > 0) {
				applianceRepository.save(applianceDetailModel);
				responseModel.setResponseCode("200");
				responseModel.setResponseMessage(env.getProperty("applianceModification.success"));
				recentActivityServiceImpl.createRecentActivity(loggedInUser,"Device "+applianceDetailModel.getApplianceName()+" modified by "+loggedInUser);

				/*	ApplianceDetailModel applianceDetailFromDBModel=applianceRepository.findOne(applianceDetailModel.getApplianceId());
				if(applianceDetailFromDBModel!=null && applianceDetailFromDBModel.getApplianceId().longValue() > 0) {
					applianceDetailFromDBModel.setApplianceName(applianceDetailModel.getApplianceName());
					applianceDetailFromDBModel.setApplianceStatus(applianceDetailModel.getApplianceStatus());
					applianceDetailFromDBModel.setGatewayIp(applianceDetailModel.getGatewayIp());
					applianceDetailFromDBModel.setIpAddress(applianceDetailModel.getIpAddress());
					applianceDetailFromDBModel.setNetworkMode(applianceDetailModel.getNetworkMode());
					applianceDetailFromDBModel.setModifiedBy(loggedInUser);
					applianceDetailFromDBModel.setModifiedDate(new Date());
					if(!applianceDetailModel.getPartitionDetailModels().isEmpty()) {
						List<PartitionDetailModel> partitionResquestDetailModel=applianceDetailModel.getPartitionDetailModels();
						List<PartitionDetailModel> partitionDBDetailModel=applianceDetailFromDBModel.getPartitionDetailModels();
						int count=0;
						for(PartitionDetailModel db : partitionDBDetailModel){
							PartitionDetailModel req=partitionResquestDetailModel.get(count);
							db.setPartitionAvailableSize(req.getPartitionAvailableSize());
							db.setPartitionType(req.getPartitionType());
							count++;
						}
					}
					applianceRepository.save(applianceDetailFromDBModel);
					responseModel.setResponseCode("200");
					responseModel.setResponseMessage(env.getProperty("applianceModification.success"));
					recentActivityServiceImpl.createRecentActivity(loggedInUser, "Device "+applianceDetailFromDBModel.getApplianceName()+" modified by "+loggedInUser+" at "+ CaviumUtil.formatDateTimeFromCurrenDate(new Date()));
				}else {
					alertsService.createAlert(loggedInUser,"Device "+applianceDetailFromDBModel.getApplianceName()+" modified by "+loggedInUser+ " at "+CaviumUtil.formatDateTimeFromCurrenDate(new Date()) +"does not exists into the cavium networks");
					responseModel.setResponseCode("409");
					responseModel.setResponseMessage(env.getProperty("applianceModification.failureNotExist"));
				}*/
			}

		}catch (Exception e) {
			logger.error("Error occured during Appliance modification :: "+ e.getMessage());
			responseModel.setResponseCode("-230");
			responseModel.setResponseMessage("Failed to execute the request at the backend");	 
		}
		return responseModel;	 
	}

	/**
	 * Method is used to delete the particular appliance
	 */
	@Override
	public ApplianceDetailModel deleteAppliance(ApplianceDetailModel applianceDetailModel) {

		try {
			String loggedInUser = userAttributes.getlogInUserName();
			/*ApplianceDetailModel appliance=applianceRepository.findOne(Long.parseLong(applianceID));
			if(appliance!=null) { */
			// delete from Group and appliance Relationship
			applianceRepository.delete(applianceDetailModel.getApplianceId());
			applianceDetailModel.setCode("200");
			applianceDetailModel.setMessage(env.getProperty("applianceDeletion.success"));
			recentActivityServiceImpl.createRecentActivity(loggedInUser, "Device "+applianceDetailModel.getApplianceName()+" deleted by "+loggedInUser);

			/*int deleted=designationApplianceRepository.deleteApplianceFromDesignationAppliance(applianceId);
			if(deleted>0){
				InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(applianceId);
				if(initmodel!=null){
					initializeRepository.delete(initmodel.getInitializeId());
					initializeAppliancesRelationshipReposiotry.delete(initmodel.getId());
				}
				applianceRepository.delete(applianceId);
				responseModel.setResponseCode("200");
				responseModel.setResponseMessage("<b>"+applianceName+"</b> :: "+env.getProperty("applianceDeletion.success"));
				recentActivityServiceImpl.createRecentActivity(loggedInUser, "Device "+applianceName+" deleted by "+loggedInUser+ " at "+ CaviumUtil.formatDateTimeFromCurrenDate(new Date()));
			}else{
				responseModel.setResponseCode("500");
				responseModel.setResponseMessage("<b>"+applianceName+"</b> :: "+env.getProperty("applianceDeletion.failureDB"));
			}*/
		} catch (Exception e) {
			logger.error("Error occured due to db error inside deleteAppliance Method of class ApplianceServiceImpl for "+ applianceDetailModel.getApplianceName() +" :: "
					+ e.getMessage());
			applianceDetailModel.setCode("500");
			applianceDetailModel.setMessage(env.getProperty("applianceDeletion.failureDB"));
		}
		return applianceDetailModel; 
	}

	/***
	 * This method is used to validate the appliance whether exists or not
	 */
	@Override
	public ApplianceDetailModel validateAppliance(ApplianceDetailModel applianceDetailModel) {
		// TODO Auto-generated method stub
		try {
			String loggedInUser = userAttributes.getlogInUserName();
			List<ApplianceDetailModel> isAvailable=applianceRepository.getApplianceExists(applianceDetailModel.getIpAddress());
			if(isAvailable.isEmpty()) {
				ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/appliance_info");
				if(response !=null && response.getStatusCode().name().equals("OK")) {
					// Appliance can be add to list
					applianceDetailModel.setCode("200");
					applianceDetailModel.setMessage("Success");
					applianceDetailModel.setCreatedBy(loggedInUser);
					applianceDetailModel.setStoreType(StoreType.TEMP);
					applianceDetailModel.setApplianceStatus("Active");
					try {
						hsmInfo=getHSMInfo(applianceDetailModel, hsmInfo);
						applianceDetailModel.setMaxPwdLen(hsmInfo.getMaxPswdLen());
						applianceDetailModel.setMinPwdLen(hsmInfo.getMinPswdLen());
						applianceDetailModel.setCoLoginFailureCount(hsmInfo.getCoLoginFailure());	
					}catch(Exception e) {
						logger.info("Error occured during getHSMInfo"+e.getMessage());
					}
					applianceRepository.save(applianceDetailModel);
				}else {
					applianceDetailModel.setCode("409");
					applianceDetailModel.setMessage(env.getProperty("appliance.notexists.cavium.network"));
					//alertsService.createAlert(loggedInUser,"Device "+applianceDetailModel.getApplianceName()+" added by "+loggedInUser+" does not exists into the cavium networks");
					// Appliance not found hence can't add to list
					alertsService.createAlert(loggedInUser,"Device "+applianceDetailModel.getApplianceName()+" added by "+loggedInUser+" does not exists into the cavium networks",applianceDetailModel.getApplianceName(),applianceDetailModel.getApplianceId());
				}
			}else {
				applianceDetailModel.setCode("409");
				applianceDetailModel.setMessage(env.getProperty("applianceCreation.failureExist"));
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Error occured during appliance validation.. into validateAppliance of class ApplianceServiceIMPL");
		}
		return applianceDetailModel;
	}

	/***
	 * This method is used to get appliance by id.
	 */
	@Override
	public ApplianceDetailModel getApplianceById(String applianceID) {
		// TODO Auto-generated method stub
		ApplianceDetailModel applianceDetailModel = null;
		CaviumResponseModel responseModel=getCaviumResponseModel();

		try {	
			applianceDetailModel = applianceRepository.getApplianceById(Long.parseLong(applianceID), StoreType.PERMANENT);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured due to db error inside getListOfAppliances Method of class ApplianceServiceImpl ::" + e.getMessage());
			responseModel.setResponseCode("500");
			responseModel.setResponseMessage(env.getProperty("applianceList.failureDB"));
		}
		return applianceDetailModel;
	}

	/***
	 * This method is used to get appliance by id.
	 */
	@Override
	public List<ApplianceDetailModel> listOfApplianceByGroupId(String loggedInUser) {
		// TODO Auto-generated method stub
		List<ApplianceDetailModel>  applianceDetailModel = null;
		CaviumResponseModel responseModel=getCaviumResponseModel();
		try {
			UserDetailModel objUserDetailModel=userRepository.findOne(loggedInUser);
			if(objUserDetailModel!=null && objUserDetailModel.getObjUserACLDetailsModel().getAclName().equals(env.getProperty("user.superadmin"))) {
				applianceDetailModel = applianceRepository.getAllListOfAppliances(StoreType.PERMANENT);
			}else {
				applianceDetailModel = applianceRepository.getListOfApplianceByGroupId(loggedInUser);
			}

		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured due to db error inside getListOfAppliances Method of class ApplianceServiceImpl ::" + e.getMessage());
			responseModel.setResponseCode("500");
			responseModel.setResponseMessage(env.getProperty("applianceList.failureDB"));
		}
		return applianceDetailModel;
	}

	/***
	 * This method is used to reboot the appliance and update last operation performed column in db
	 */

	@Override
	public List<ApplianceDetailModel> rebootAppliance(List<ApplianceDetailModel> applianceDetailModellist) {
		// TODO Auto-generated method stub

		// TODO Auto-generated method stub
		String loggedInUser = userAttributes.getlogInUserName();
		List<ApplianceDetailModel> responseList=new ArrayList<ApplianceDetailModel>();
		try {
			if(applianceDetailModellist.size() > 0) {
				Iterator<ApplianceDetailModel> itr=applianceDetailModellist.iterator();
				while(itr.hasNext()) {
					ResponseEntity<String> response = null;
					ApplianceDetailModel app=(ApplianceDetailModel)itr.next();
					ApplianceDetailModel dbAppliance=applianceRepository.findOne(app.getApplianceId()); 
					if(dbAppliance!=null) {
						long applianceId=app.getApplianceId();
						/*MultiValueMap json = new MultiValueMa
						json.add("username", app.getUserName());
						json.add("password", app.getUserPassword());*/
						MultiValueMap<String, Object> body = new LinkedMultiValueMap<String, Object>();     
						InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(applianceId);
						if(initmodel!=null) {
							InitializeApplianceDetailModel initAppDetailModel = initializeRepository.findOne(initmodel.getInitializeId());
							/*if(app.isCredentialSaved()){
								initmodel.setOperationPerformUserName(app.getOperationUsername());
								initmodel.setOperationPerformPassword(CaviumUtil.encrypt(app.getOperationPassword()));
								initmodel.setInitializeId(initAppDetailModel.getInitialize_id());
								initmodel.setApplianceDetailModel(dbAppliance);
								initializeAppliancesRelationshipReposiotry.save(initmodel);
							}*/
							DualFactorAuthDetailModel dualAuthModel=initAppDetailModel.getDualFactorAuthDetailModel();
							if(!StringUtils.isEmpty(app.getOperationUsername()) && !StringUtils.isEmpty(app.getOperationPassword())) {
								if(initAppDetailModel.getAuthenticationLevel()==0) {
									body.add("username", app.getOperationUsername());
									body.add("password", app.getOperationPassword());
								}if(initAppDetailModel.getAuthenticationLevel()==1 && dualAuthModel!=null) {
									body.add("username", app.getOperationUsername());
									body.add("password", app.getOperationPassword());
									body.add("dualFactorHostname", dualAuthModel.getDualFactorAuthServerAddress());
									body.add("dualFactorPort", dualAuthModel.getDualFactorAuthServerPortNo());
									body.add("dualFactorCertificate", dualAuthModel.getDualFactorAuthServerCertId());
								}
							}else {
								if(initAppDetailModel.getAuthenticationLevel()==0) {
									body.add("username", initmodel.getOperationPerformUserName());
									body.add("password", CaviumUtil.decrypt(initmodel.getOperationPerformPassword()));
								}if(initAppDetailModel.getAuthenticationLevel()==1 && dualAuthModel!=null) {
									body.add("username", initmodel.getOperationPerformUserName());
									body.add("password", CaviumUtil.decrypt(initmodel.getOperationPerformPassword()));
									body.add("dualFactorHostname", dualAuthModel.getDualFactorAuthServerAddress());
									body.add("dualFactorPort", dualAuthModel.getDualFactorAuthServerPortNo());
									body.add("dualFactorCertificate", dualAuthModel.getDualFactorAuthServerCertId());
								}
							}
							response=restClient.invokePOSTMethod("https://"+app.getIpAddress()+"/liquidsa/admin_vm_reboot", body);

						}else {
							if(!StringUtils.isEmpty(app.getOperationUsername()) && !StringUtils.isEmpty(app.getOperationPassword())) {
								body.add("username", app.getOperationUsername());
								body.add("password", app.getOperationPassword());
								response=restClient.invokePOSTMethod("https://"+app.getIpAddress()+"/liquidsa/admin_vm_reboot", body);
							}else {
								app.setMessage("Appliance not rebooted due to credentials not available");
								alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+"  try to perofrm reboot by "+loggedInUser+" does not reboot due to credentials not available.");
							}
						}
						if(response!=null && response.getBody()!=null)
						{
							ObjectMapper mapper = new ObjectMapper();
							JsonNode root = mapper.readTree(response.getBody());
							if(!root.isNull()){
								JsonNode errors = root.path("errors");
								if(!errors.isNull() && errors.size()>0){
									Iterator<JsonNode> iterator = errors.elements();                           
									while (iterator.hasNext()) {
										app.setCode("409");
										app.setMessage("some error is coming while performing reboot operation");
									}
								}
								if(response!=null && response.getBody()!=null && response.getBody().contains("success")) { 
									dbAppliance.setOperationPerformed(env.getProperty("appliance.reboot"));
									dbAppliance.setApplianceinitialized(app.isApplianceinitialized());
									applianceRepository.save(dbAppliance);
									InProgressActivity activity = new InProgressActivity();
									activity.setCreatedBy(loggedInUser);
									activity.setIpAddress(dbAppliance.getIpAddress());
									Integer jobId = 0;
									if (!root.path("jobId").isNull()) {
										jobId = root.path("jobId").asInt();
									} else {
										jobId = 000;
									}
									activity.setJobId(jobId);
									activity.setOperationName(root.path("operation").asText());
									activity.setStatus("busy");
									inProgressActivityService.createInProgressActivity(activity);

									app.setOperationPerformed(env.getProperty("appliance.reboot"));
									app.setCode("200");
									app.setMessage(env.getProperty("appliance.reboot.success"));
									recentActivityServiceImpl.createRecentActivity(loggedInUser, "Device "+app.getApplianceName()+" rebooted by "+loggedInUser);
								}
								else {
									if(response!=null && response.getBody()!=null && response.getBody().contains("busy")) {
										String operation = root.path("operation").asText();
										app.setCode("409");
										app.setMessage("Appliance is busy due to operation "+operation+" is being performed");
										alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+"  try to perofrm reboot by "+loggedInUser+" does not reboot due to operation "+operation+" is already in progress.");

									}
								}
								if(response!=null && response.getBody()!=null && response.getBody().contains("bad credentials")) {
									app.setCode("409");
									app.setMessage(env.getProperty("appliance.badcredentials.cavium"));
									alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+"  try to perofrm reboot by "+loggedInUser+" does not reboot due to invalid credentials.");
								}if(response!=null && response.getStatusCodeValue()== 408){
									app.setCode("408");
									app.setMessage(env.getProperty("appliance.connectionerror.cavium"));
									alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+"  try to perofrm reboot by "+loggedInUser+" does not reboot due to connection issue.");
								}if(response!=null && response.getBody()!=null && response.getBody().contains("11008")) {
									app.setCode("11008");
									app.setMessage(env.getProperty("appliance.badcredentials.cavium"));
									alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+"  try to perofrm reboot by "+loggedInUser+" does not reboot due to invalid credentials.");
								}
								if(response!=null && response.getBody()!=null && response.getBody().contains("10010")) {
									app.setCode("10010");
									app.setMessage(env.getProperty("appliance.emptycredentials.cavium"));
									alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+"  try to perofrm reboot by "+loggedInUser+" does not reboot due to empty credentials.");
								}
							}

						}
						if(response!=null && response.getStatusCodeValue()== 408){
							app.setCode("408");
							app.setMessage(env.getProperty("appliance.connectionerror.cavium"));
							alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+"  try to perofrm reboot by "+loggedInUser+" does not reboot due to connection issue.");
						}

						if(response==null) {
							app.setCode("409");
							app.setMessage(env.getProperty("appliance.applainceinternalerror.cavium"));
							alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+"  try to perofrm reboot by "+loggedInUser+" does not reboot due to appliance internal error");
						}
					}
					else {
						app.setCode("409");
						app.setMessage(env.getProperty("appliance.notexists.cavium"));
						alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+"  try to perofrm reboot by "+loggedInUser+" does not exist in cavium netwoork.");
					}
					responseList.add(app); 

				}
			}
		}catch (Exception e) {
			// TODO: handle exception
			logger.info("Error occured during appliance rebootAppliance.. into rebootAppliance of class ApplianceServiceIMPL");
		}
		return responseList;
	}

	/***
	 * This method is used to reboot the appliance and update last operation performed column in db
	 */
	@Override
	public List<ApplianceDetailModel> zeroizeAppliance(List<ApplianceDetailModel> applianceDetailModellist) {
		// TODO Auto-generated method stub
		List<ApplianceDetailModel> responseList=new ArrayList<ApplianceDetailModel>();
		String loggedInUser = userAttributes.getlogInUserName();
		// TODO Auto-generated method stub
		try {
			if(applianceDetailModellist.size() > 0) {
				Iterator<ApplianceDetailModel> itr=applianceDetailModellist.iterator();
				while(itr.hasNext()) {
					ResponseEntity<String> response=null;
					ApplianceDetailModel app=(ApplianceDetailModel)itr.next();
					ApplianceDetailModel dbAppliance=applianceRepository.findOne(app.getApplianceId()); 
					Map<String,Object> map=new HashMap<>();
					JSONObject json = new JSONObject(); 
					if(dbAppliance!=null) {
						long applianceId=dbAppliance.getApplianceId();
						InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(applianceId);
						if(initmodel!=null) {
							InitializeApplianceDetailModel initAppDetailModel = initializeRepository.findOne(initmodel.getInitializeId());
							DualFactorAuthDetailModel dualAuthModel=initAppDetailModel.getDualFactorAuthDetailModel();
							if(!StringUtils.isEmpty(app.getOperationUsername()) && !StringUtils.isEmpty(app.getOperationPassword())) {
								if(initAppDetailModel.getAuthenticationLevel()==0) {
									map.put("username", app.getOperationUsername());
									map.put("password", app.getOperationPassword());
								}if(initAppDetailModel.getAuthenticationLevel()==1 && dualAuthModel!=null) {
									map.put("username", app.getOperationUsername());
									map.put("password", app.getOperationPassword());
									map.put("dualFactorHostname", dualAuthModel.getDualFactorAuthServerAddress());
									map.put("dualFactorPort", dualAuthModel.getDualFactorAuthServerPortNo());
									map.put("dualFactorCertificate", dualAuthModel.getDualFactorAuthServerCertId());
								}
								json.put("mcoLoginInfo", map);
							}else {
								if(initAppDetailModel.getAuthenticationLevel()==0) {
									map.put("username", initmodel.getOperationPerformUserName());
									map.put("password", CaviumUtil.decrypt(initmodel.getOperationPerformPassword()));
								}if(initAppDetailModel.getAuthenticationLevel()==1 && dualAuthModel!=null) {
									map.put("username", initmodel.getOperationPerformUserName());
									map.put("password", CaviumUtil.decrypt(initmodel.getOperationPerformPassword()));
									map.put("dualFactorHostname", dualAuthModel.getDualFactorAuthServerAddress());
									map.put("dualFactorPort", dualAuthModel.getDualFactorAuthServerPortNo());
									map.put("dualFactorCertificate", dualAuthModel.getDualFactorAuthServerCertId());
								}
								json.put("mcoLoginInfo", map);
							}
							response=restClient.invokePOSTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/zeroize",json);
						}else {
							if(!StringUtils.isEmpty(app.getOperationUsername()) && !StringUtils.isEmpty(app.getOperationPassword())) {
								map.put("username", app.getOperationUsername());
								map.put("password", app.getOperationPassword());
								json.put("mcoLoginInfo", map);
								response=restClient.invokePOSTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/zeroize",json);
							}else {
								app.setMessage("Appliance not rebooted due to credentials not available");
								alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+"  try to perofrm zeroize by "+loggedInUser+" does not zeroize.");
							}
						}

						if(response!=null && response.getBody()!=null)
						{
							ObjectMapper mapper = new ObjectMapper();
							JsonNode root = mapper.readTree(response.getBody());
							if(!root.isNull()){
								JsonNode errors = root.path("errors");
								if(!errors.isNull() && errors.size()>0){							 
									Iterator<JsonNode> iterator = errors.elements();                           
									while (iterator.hasNext()) {
										app.setCode("409");
										app.setMessage("some error is coming while performing zeroize operation");
										alertsService.createAlert(loggedInUser,"Error coming in device "+app.getApplianceName()+" while tring to perofrm zeroize by "+loggedInUser);
									}
								}
								if(response!=null && response.getBody()!=null && response.getBody().contains("success")) { 
									dbAppliance.setOperationPerformed(env.getProperty("appliance.zeroize"));
									dbAppliance.setApplianceinitialized(app.isApplianceinitialized());
									applianceRepository.save(dbAppliance);
									InProgressActivity activity = new InProgressActivity();
									activity.setCreatedBy(loggedInUser);
									activity.setIpAddress(dbAppliance.getIpAddress());
									Integer jobId = 0;
									if (!root.path("jobId").isNull()) {
										jobId = root.path("jobId").asInt();
									} else {
										jobId = 000;
									}
									activity.setJobId(jobId);
									activity.setOperationName(root.path("operation").asText());
									activity.setStatus("busy");
									inProgressActivityService.createInProgressActivity(activity);

									app.setOperationPerformed(env.getProperty("appliance.zeroize"));										
									app.setCode("200");
									app.setMessage(env.getProperty("appliance.zeroize.success"));
									recentActivityServiceImpl.createRecentActivity(loggedInUser, "Device "+app.getApplianceName()+" zeroize by "+loggedInUser);
								}else {
									if(response!=null && response.getBody()!=null && response.getBody().contains("busy")) {

										if(!root.isNull()){
											String operation = root.path("operation").asText();
											app.setCode("409");
											app.setMessage("Appliance is busy due to operation "+operation+" is being performed");
											alertsService.createAlert(loggedInUser,"Opeartion zeroize  on appliance "+app.getApplianceName()+" by "+loggedInUser+ "is not performed due to another operation "+operation+" is in progress.");
										}
									}if(response!=null && response.getBody()!=null && response.getBody().contains("bad credentials")) {
										app.setCode("409");
										app.setMessage(env.getProperty("appliance.badcredentials.cavium"));
										alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+"  try to perofrm zeroize by "+loggedInUser+" does not zeroize due to invalid credentials");
									}if(response!=null && response.getBody()!=null && response.getBody().contains("11008")) {
										app.setCode("409");
										app.setMessage(env.getProperty("appliance.badcredentials.cavium"));
										alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+"  try to perofrm zeroize by "+loggedInUser+" does not zeroize due to invalid credentials");
									}
									if(response!=null && response.getBody()!=null && response.getBody().contains("10010")) {
										app.setCode("10010");
										app.setMessage(env.getProperty("appliance.emptycredentials.cavium"));
										alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+"  try to perofrm zeroize by "+loggedInUser+" does not zeroize due to empty credentials.");
									}
								}	
							}
						}
						if(response!=null && response.getStatusCodeValue()== 408){
							app.setCode("408");
							app.setMessage(env.getProperty("appliance.connectionerror.cavium"));
							alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+"  try to perofrm zeroize by "+loggedInUser+" does not zeroize due to connection error.");
						}
						if(response==null) {
							app.setCode("409");
							app.setMessage(env.getProperty("appliance.applainceinternalerror.cavium"));
							alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+"  try to perofrm zeroize by "+loggedInUser+ " does not zeroize due to connection error.");
						}
					}	else {
						app.setCode("409");
						app.setMessage(env.getProperty("appliance.notexists.cavium"));
						alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+"  try to perofrm zeroize by "+loggedInUser+" does not exist in cavium network.");
					}
					responseList.add(app);
				}
			}

		}catch (Exception e) {
			// TODO: handle exception
			logger.info("Error occured during appliance zeroizeAppliance.. into zeroizeAppliance of class ApplianceServiceIMPL");
		}
		return responseList;
	}

	/***
	 * This method is used to reboot the appliance and update last operation performed column in db
	 */
	@Override
	public List<ApplianceDetailModel> applianceFirmwareUpgrade(List<ApplianceDetailModel> applianceDetailModellist) {
		// TODO Auto-generated method stub
		List<ApplianceDetailModel> responseList=new ArrayList<ApplianceDetailModel>();
		String loggedInUser = userAttributes.getlogInUserName();
		// TODO Auto-generated method stub
		try {
			if(applianceDetailModellist.size() > 0) {
				Iterator<ApplianceDetailModel> itr=applianceDetailModellist.iterator();
				while(itr.hasNext()) {
					ResponseEntity<String> response = null;
					ApplianceDetailModel app=(ApplianceDetailModel)itr.next();
					ApplianceDetailModel dbAppliance=applianceRepository.findOne(app.getApplianceId()); 
					JSONObject json = new JSONObject(); 
					if(dbAppliance!=null) {
						long applianceId=app.getApplianceId();
						InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(applianceId);
						if(initmodel!=null) {
							InitializeApplianceDetailModel initAppDetailModel = initializeRepository.findOne(initmodel.getInitializeId());
							DualFactorAuthDetailModel dualAuthModel=initAppDetailModel.getDualFactorAuthDetailModel();
							if(!StringUtils.isEmpty(app.getOperationUsername()) && !StringUtils.isEmpty(app.getOperationPassword())) {
								if(initAppDetailModel.getAuthenticationLevel()==0) {
									HashMap<String,String> map=getUploadedFileNames(app, app.getOperationUsername(), app.getOperationPassword(), null);
									if(map!=null && map.containsKey("imageFilePath") &&  map.containsKey("signFilePath")) {
										json.put("username", app.getOperationUsername());
										json.put("password", app.getOperationPassword());
										json.put("hsmFirmwareType", app.getFirmwareUpgradeDetailModel().getHsmFirmwareType());
										json.put("imageFilePath", map.get("imageFilePath"));
										json.put("signFilePath", map.get("signFilePath"));
										if(!StringUtils.isEmpty(app.getFirmwareUpgradeDetailModel().isZeroize())) {
											json.put("zeroize", app.getFirmwareUpgradeDetailModel().isZeroize());
										}
									}
								}if(initAppDetailModel.getAuthenticationLevel()==1 && dualAuthModel!=null) {
									HashMap<String,String> map=getUploadedFileNames(app, app.getOperationUsername(), app.getOperationPassword(), dualAuthModel);
									if(map!=null && map.containsKey("imageFilePath") &&  map.containsKey("signFilePath")) {
										json.put("username", app.getOperationUsername());
										json.put("password", app.getOperationPassword());
										json.put("dualFactorHostname", dualAuthModel.getDualFactorAuthServerAddress());
										json.put("dualFactorPort", dualAuthModel.getDualFactorAuthServerPortNo());
										json.put("dualFactorCertificate", dualAuthModel.getDualFactorAuthServerCertId());
										json.put("hsmFirmwareType", app.getFirmwareUpgradeDetailModel().getHsmFirmwareType());
										json.put("imageFilePath", map.get("imageFilePath"));
										json.put("signFilePath", map.get("signFilePath"));
										if(!StringUtils.isEmpty(app.getFirmwareUpgradeDetailModel().isZeroize())) {
											json.put("zeroize", app.getFirmwareUpgradeDetailModel().isZeroize());
										}
									}
								}
							}else {
								if(initAppDetailModel.getAuthenticationLevel()==0) {
									HashMap<String,String> map=getUploadedFileNames(app, initmodel.getOperationPerformUserName(), CaviumUtil.decrypt(initmodel.getOperationPerformPassword()), null);
									if(map!=null && map.containsKey("imageFilePath") &&  map.containsKey("signFilePath")) {
										json.put("username", initmodel.getOperationPerformUserName());
										json.put("password", CaviumUtil.decrypt(initmodel.getOperationPerformPassword()));
										json.put("hsmFirmwareType", app.getFirmwareUpgradeDetailModel().getHsmFirmwareType());
										json.put("imageFilePath", map.get("imageFilePath"));
										json.put("signFilePath", map.get("signFilePath"));
										if(!StringUtils.isEmpty(app.getFirmwareUpgradeDetailModel().isZeroize())) {
											json.put("zeroize", app.getFirmwareUpgradeDetailModel().isZeroize());
										}
									}

								}if(initAppDetailModel.getAuthenticationLevel()==1 && dualAuthModel!=null) {
									HashMap<String,String> map=getUploadedFileNames(app, initmodel.getOperationPerformUserName(), CaviumUtil.decrypt(initmodel.getOperationPerformPassword()), dualAuthModel);
									if(map!=null && map.containsKey("imageFilePath") &&  map.containsKey("signFilePath")) {
										json.put("username", initmodel.getOperationPerformUserName());
										json.put("password", CaviumUtil.decrypt(initmodel.getOperationPerformPassword()));
										json.put("dualFactorHostname", dualAuthModel.getDualFactorAuthServerAddress());
										json.put("dualFactorPort", dualAuthModel.getDualFactorAuthServerPortNo());
										json.put("dualFactorCertificate", dualAuthModel.getDualFactorAuthServerCertId());
										json.put("hsmFirmwareType", app.getFirmwareUpgradeDetailModel().getHsmFirmwareType());
										json.put("imageFilePath", map.get("imageFilePath"));
										json.put("signFilePath", map.get("signFilePath"));
										if(!StringUtils.isEmpty(app.getFirmwareUpgradeDetailModel().isZeroize())) {
											json.put("zeroize", app.getFirmwareUpgradeDetailModel().isZeroize());
										}
									}

								}
							}
							response=restClient.invokePOSTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/firmware_upgrade", json);
						}else {
							if(!StringUtils.isEmpty(app.getOperationUsername()) && !StringUtils.isEmpty(app.getOperationPassword())) {
								HashMap<String,String> map=getUploadedFileNames(app, app.getOperationUsername(), app.getOperationPassword(), null);
								if(map!=null && map.containsKey("imageFilePath") &&  map.containsKey("signFilePath")) {
									json.put("username", app.getOperationUsername());
									json.put("password", app.getOperationPassword());
									json.put("hsmFirmwareType", app.getFirmwareUpgradeDetailModel().getHsmFirmwareType());
									json.put("imageFilePath", map.get("imageFilePath"));
									json.put("signFilePath", map.get("signFilePath"));
									if(!StringUtils.isEmpty(app.getFirmwareUpgradeDetailModel().isZeroize())) {
										json.put("zeroize", app.getFirmwareUpgradeDetailModel().isZeroize());
									}
								}
								response=restClient.invokePOSTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/firmware_upgrade", json);
							}else {
								app.setMessage("Appliance not rebooted due to credentials not available");
								alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+"  try to perofrm firmware upgrade by "+loggedInUser+" does not firmware upgrade.");
							}
						}

						if(response!=null && response.getBody()!=null && response.getBody().contains("success")) { 
							dbAppliance.setOperationPerformed("FirmwareUpgrade");
							applianceRepository.save(dbAppliance);
							ObjectMapper mapper = new ObjectMapper();
							JsonNode root = mapper.readTree(response.getBody());
							if(!root.isNull()){
								InProgressActivity activity = new InProgressActivity();
								activity.setCreatedBy(loggedInUser);
								activity.setIpAddress(dbAppliance.getIpAddress());
								Integer jobId = 0;
								if (!root.path("jobId").isNull()) {
									jobId = root.path("jobId").asInt();
								} else {
									jobId = 000;
								}
								activity.setJobId(jobId);
								activity.setOperationName(root.path("operation").asText());
								activity.setStatus("busy");
								inProgressActivityService.createInProgressActivity(activity);
							}
							app.setOperationPerformed("FirmwareUpgarde");
							app.setCode("200");
							app.setMessage(env.getProperty("appliance.firmwareupgrade.success"));
							recentActivityServiceImpl.createRecentActivity(loggedInUser, "Device "+app.getApplianceName()+" firmware upgrade by "+loggedInUser);
						}else {
							if(response!=null && response.getBody()!=null && response.getBody().contains("busy")) {
								ObjectMapper mapper = new ObjectMapper();
								JsonNode root = mapper.readTree(response.getBody());
								if(!root.isNull()){
									String operation = root.path("operation").asText();
									app.setCode("409");
									app.setMessage("Appliance is busy due to operation "+operation+" is being performed");
								}
							}if(response!=null && response.getBody()!=null && response.getBody().contains("bad credentials")) {
								app.setCode("409");
								app.setMessage(env.getProperty("appliance.badcredentials.cavium"));
								alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+"  try to perofrm firmware upgrade by "+loggedInUser+ " does not firmware upgrade.");
							}if(response!=null && response.getStatusCodeValue()== 408){
								app.setCode("408");
								app.setMessage(env.getProperty("appliance.connectionerror.cavium"));
								alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+"  try to perofrm firmware upgrade by "+loggedInUser+ " does not firmware upgrade.");
							}if(response!=null && response.getBody()!=null && response.getBody().contains("11008")) {
								app.setCode("11008");
								app.setMessage(env.getProperty("appliance.badcredentials.cavium"));
								alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+"  try to perofrm firmware upgrade by "+loggedInUser+ " does not firmware upgrade.");
							}if(response==null) {
								app.setCode("409");
								app.setMessage(env.getProperty("appliance.applainceinternalerror.cavium"));
								alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+"  try to perofrm firmware upgrade by "+loggedInUser+ " does not firmware upgrade.");
							}
							if(response!=null && response.getBody()!=null && response.getBody().contains("10010")) {
								app.setCode("10010");
								app.setMessage(env.getProperty("appliance.emptycredentials.cavium"));
								alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+"  try to perofrm firmware upgrade by "+loggedInUser+" does not firmware upgrade due to empty credentials.");
							}
						}
					}else {
						app.setCode("409");
						app.setMessage(env.getProperty("appliance.notexists.cavium"));
						alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+"  try to perofrm firmware upgrade by "+loggedInUser+ " does not exist.");
					}
					responseList.add(app);
				}
			}} catch (Exception e) {
				// TODO: handle exception
				logger.info("Error occured during appliance applianceFirmwareUpgrade.. into applianceFirmwareUpgrade of class ApplianceServiceIMPL");
			}
		return responseList;
	}

	/***
	 * This method is used to initilizeAppliance the appliance and update last operation performed column in db
	 */
	@Override
	@Transactional
	public List<ApplianceDetailModel> initilizeAppliance(InitializeApplianceDetailModel initializeApplianceDetailModel) throws RuntimeException{
		logger.error("Start of initilizeAppliance method"); 
		List<ApplianceDetailModel> listApplianceDetailModel= new ArrayList<ApplianceDetailModel>();	
		synchronized (initializeApplianceDetailModel) {
			ApplianceDetailModel objApplianceDetailModel=null;
			CaviumResponseModel caviumResponseModel=null;			
			if(initializeApplianceDetailModel.getAuthenticationLevel()!=null){
				if(initializeApplianceDetailModel.getApplianceDetailModels()!=null && initializeApplianceDetailModel.getApplianceDetailModels().size()>0 ){
					Iterator<ApplianceDetailModel> applianceDetailModel=initializeApplianceDetailModel.getApplianceDetailModels().iterator();
					while(applianceDetailModel.hasNext()) {
						ApplianceDetailModel appliance=(ApplianceDetailModel)applianceDetailModel.next();
						try{
							if(initializeApplianceDetailModel.getAuthenticationLevel()==1){
								File convertedFile=null;
								String coPassword=initializeApplianceDetailModel.getConfirmCryptoOfficerpassword();
								String coUsername=initializeApplianceDetailModel.getCryptoOfficerName();
								String fileName=initializeApplianceDetailModel.getDualFactorAuthDetailModel().getFileName();
								String fileExtension=initializeApplianceDetailModel.getDualFactorAuthDetailModel().getFileExtension();
								String fileContent=initializeApplianceDetailModel.getDualFactorAuthDetailModel().getFileContent();
								try{
									convertedFile= CaviumUtil.createFile(fileName,fileExtension,fileContent);
								}catch (IOException e) {
									logger.error("Error while creating file in initilizeAppliance method"); 
									throw new RuntimeException("FileUploadError");
								}
								caviumResponseModel=fileUploadService.uploadFile(convertedFile,coUsername,coPassword,"InitHSM",appliance.getIpAddress(),null);
								if(convertedFile!=null){
									Files.deleteIfExists(Paths.get(convertedFile.getAbsolutePath()));
								}					         
							}
							if(caviumResponseModel!=null && "200".equals(caviumResponseModel.getResponseCode()) || initializeApplianceDetailModel.getAuthenticationLevel()==0 ){
								initializeApplianceDetailModel.setConfirmCryptoOfficerpassword(CaviumUtil.encrypt(initializeApplianceDetailModel.getConfirmCryptoOfficerpassword()));
								initializeApplianceDetailModel.setCryptoOfficerPassword(CaviumUtil.encrypt(initializeApplianceDetailModel.getCryptoOfficerPassword()));
								if(caviumResponseModel!=null && initializeApplianceDetailModel.getDualFactorAuthDetailModel()!=null){
									initializeApplianceDetailModel.getDualFactorAuthDetailModel().setDualFactorAuthServerCertId(caviumResponseModel.getResponseMessage());
								}
								InitializeApplianceDetailModel dbinitializeApplianceDetailModel=initializeRepository.save(initializeApplianceDetailModel);
								Long initializeId=dbinitializeApplianceDetailModel.getInitialize_id();
								long applianceId=appliance.getApplianceId();
								InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(applianceId);
								if(initmodel!=null){
									initializeRepository.delete(initmodel.getInitializeId());
									initializeAppliancesRelationshipReposiotry.delete(initmodel.getId());
								}
								objApplianceDetailModel= initilizeApplianceRelationship(appliance,initializeApplianceDetailModel,initializeId,caviumResponseModel);
								listApplianceDetailModel.add(objApplianceDetailModel);
								logger.info("Appliance Initilized Succesfully"); 
							}else{
								logger.error("Error while sending file to cavium network"); 
								throw new RuntimeException("FileUploadError");
							}
						}
						catch (Exception e) {
							logger.error("Error coming while initilize Appliance in initilizeAppliance method"+e.getMessage()); 
							throw new RuntimeException(e.getMessage());

						}
					}
				}
			}
		}
		logger.info("End of initilizeAppliance method"); 
		return listApplianceDetailModel;
	}
	@Override
	@Transactional
	public ApplianceDetailModel  initilizeApplianceRelationship(ApplianceDetailModel applianceDetailModel, InitializeApplianceDetailModel initializeApplianceDetailModel,Long initializeId,CaviumResponseModel caviumResponseModel) throws RuntimeException{
		synchronized (initializeApplianceDetailModel) {
			String loggedInUser = userAttributes.getlogInUserName();
			ApplianceDetailModel dbAppliance=applianceRepository.findOne(applianceDetailModel.getApplianceId()); 
			if(dbAppliance!=null) {
				dbAppliance.setOperationPerformed("initialized");
				dbAppliance.setCode("200");
				dbAppliance.setMessage("Appliance Initilize successfully");
				dbAppliance.setCredentialSaved(initializeApplianceDetailModel.isCredentialSaved());
				dbAppliance.setApplianceinitialized(true);

				applianceRepository.save(dbAppliance);
				InitializeAppliancesRelationshipModel initializeAppliancesRelationshipModel=new InitializeAppliancesRelationshipModel();
				initializeAppliancesRelationshipModel.setInitializeId(initializeId);
				initializeAppliancesRelationshipModel.setApplianceDetailModel(dbAppliance);
				if(initializeApplianceDetailModel.isCredentialSaved()){
					initializeAppliancesRelationshipModel.setOperationPerformUserName(initializeApplianceDetailModel.getUserName());
					initializeAppliancesRelationshipModel.setOperationPerformPassword(CaviumUtil.encrypt(initializeApplianceDetailModel.getPassword()));
				}
				initializeAppliancesRelationshipReposiotry.save(initializeAppliancesRelationshipModel);                   
				JSONObject json = new JSONObject(); 
				Map<String,Object> initData= new HashMap<String,Object>();
				json.put("username",initializeApplianceDetailModel.getUserName());
				json.put("password",initializeApplianceDetailModel.getPassword());


				//Map<String,String> certificateList= new HashMap<String, String>();
				//certificateList.put("c1", "uploaderFileID1");
				//certificateList.put("c2", "uploaderFileID2");
				//json.put("certificateList", certificateList);
				initData.put("cryptoOfficerName",initializeApplianceDetailModel.getCryptoOfficerName());
				initData.put("cryptoOfficerPassword",CaviumUtil.decrypt(initializeApplianceDetailModel.getCryptoOfficerPassword()));
				initData.put("authenticationLevel",initializeApplianceDetailModel.getAuthenticationLevel());
				initData.put("fipsState",initializeApplianceDetailModel.getFipsState());
				initData.put("hsmAuditLog",initializeApplianceDetailModel.isHsmAuditLog());
				initData.put("certAuth",initializeApplianceDetailModel.getCertAuthentication());
				initData.put("loginFailCount",initializeApplianceDetailModel.getLoginFailureCount());               
				initData.put("maxPasswordLength",initializeApplianceDetailModel.getMaximumPasswordLength());
				initData.put("minPasswordLength",initializeApplianceDetailModel.getMinimumPasswordLength());                           
				initData.put("label",initializeApplianceDetailModel.getHsmLabel());
				if(initializeApplianceDetailModel.getDualFactorAuthDetailModel()!=null){
					if(caviumResponseModel!=null){
						initData.put("dfCertificate",caviumResponseModel.getResponseMessage());
					}
					initData.put("dfHostname",initializeApplianceDetailModel.getDualFactorAuthDetailModel().getDualFactorAuthServerAddress());
					initData.put("dfPort",initializeApplianceDetailModel.getDualFactorAuthDetailModel().getDualFactorAuthServerPortNo());
				}

				Map<String,Object> eth0Map= new HashMap<String,Object>();
				Map<String,Object> eth1Map= new HashMap<String,Object>();
				// for the time being  till requirement not clear from cavium
				eth0Map.put("dhcp",true);
				eth1Map.put("dhcp",true);
				eth1Map.put("disableEth1",true);
				Map<String,Map<String, Object>> networkStats= new HashMap<String, Map<String, Object>>();
				// commented for the time being  till requirement not clear from cavium
				/*                  if(initializeApplianceDetailModel.getNetworkStatsModels()!=null && initializeApplianceDetailModel.getNetworkStatsModels().size()>0){

                        for (Iterator<NetworkStatsModel> iterator = initializeApplianceDetailModel.getNetworkStatsModels().iterator(); iterator.hasNext();) {
                               NetworkStatsModel networkStatsModel = (NetworkStatsModel) iterator.next();
                               if("eth0".equals(networkStatsModel.getNetworkStatId())) {
                                      eth0Map.put("dhcp", networkStatsModel.isDhcp());
                                      eth0Map.put("ip",networkStatsModel.getIpAddress() );
                                      eth0Map.put("gateway",networkStatsModel.getGateway());
                                      eth0Map.put("subnet", networkStatsModel.getSubnet());
                                      eth0Map.put("vlan", networkStatsModel.getVlanId());
                               }
                               if("eth1".equals(networkStatsModel.getNetworkStatId())){
                                      eth1Map.put("dhcp", networkStatsModel.isDhcp());
                                      eth1Map.put("ip",networkStatsModel.getIpAddress() );
                                      eth1Map.put("gateway",networkStatsModel.getGateway());
                                      eth1Map.put("subnet", networkStatsModel.getSubnet());
                                      eth1Map.put("vlan", networkStatsModel.getVlanId());
                                      eth1Map.put("disableEth1", networkStatsModel.isDisableEth1());
                               }                                        
                        }
                  }*/

				networkStats.put("eth0", eth0Map);
				networkStats.put("eth1", eth1Map);
				json.put("initData", initData);
				//json.put("networkStats", networkStats);
				try{
					ResponseEntity<String> response=restClient.invokePOSTMethodForOperations("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/initialize", json);
					if(response!=null && response.getStatusCode().name().equals("OK")) {
						if(response.getBody()!=null){
							ObjectMapper mapper = new ObjectMapper();
							JsonNode root = mapper.readTree(response.getBody());
							if(!root.isNull()){
								JsonNode errors = root.path("errors");

								if(!errors.isNull() && errors.size()>0){
									String encodeMessage = root.path("message").asText();
									Iterator<JsonNode> itr = errors.elements();                           
									while (itr.hasNext()) {
										//JsonNode temp = itr.next();  
										JsonNode temp = itr.next();
										if(StringUtils.isEmpty(encodeMessage)){
											dbAppliance.setCode("409");
											if(temp.asInt()==11004)
											{ 
												encodeMessage="This Appliance is already initialized.";
												throw new RuntimeException(applianceDetailModel.getApplianceName()+ encodeMessage);
											}else{
												throw new RuntimeException(applianceDetailModel.getApplianceName()+"some error is coming while Initializing.");
											}
										}
										//dbAppliance.setMessage(dbAppliance.getApplianceName() + " appliance doesn't Initialize from Cavium");
										//	dbAppliance.setMessage(dbAppliance.getApplianceName() + CaviumUtil.decodeMessageBase64(encodeMessage));
										else{
											throw new RuntimeException(applianceDetailModel.getApplianceName()+CaviumUtil.decodeMessageBase64(encodeMessage));
										}   
									}
								}
								if(response!=null && response.getBody()!=null && response.getBody().contains("busy")) {
									String operation = root.path("operation").asText();
									dbAppliance.setCode("409");
									dbAppliance.setMessage("Appliance is busy due to operation "+operation+" is being performed.");
									throw new RuntimeException(applianceDetailModel.getApplianceName()+dbAppliance.getMessage());
								}
								if(response!=null && response.getBody()!=null && response.getBody().contains("success")) {
									dbAppliance.setCode("200");
									dbAppliance.setMessage("appliance Initialize Suceessfully.");
									recentActivityServiceImpl.createRecentActivity(loggedInUser,"Device "+applianceDetailModel.getApplianceName()+" initialized by "+loggedInUser);
									InProgressActivity activity = new InProgressActivity();
									activity.setCreatedBy(loggedInUser);
									activity.setIpAddress(dbAppliance.getIpAddress());
									Integer jobId = 0;
									if (!root.path("jobId").isNull()) {
										jobId = root.path("jobId").asInt();
									} else {
										jobId = 000;
									}
									activity.setJobId(jobId);
									activity.setOperationName(root.path("operation").asText());
									activity.setStatus("busy");
									inProgressActivityService.createInProgressActivity(activity);
								}
							}
						}

					}else {
						dbAppliance.setCode("400");
						dbAppliance.setMessage("Request not processed.");
						alertsService.createAlert(loggedInUser,"Device "+dbAppliance.getApplianceName()+"  try to perofrm initialize by "+loggedInUser+ " does not initialize.");
						throw new RuntimeException("CaviumNetworkError");
					}
				}catch (KeyManagementException e) {
					alertsService.createAlert(loggedInUser,"Device "+dbAppliance.getApplianceName()+"  try to perofrm initialize by "+loggedInUser+ " does not initialize.");
					throw new RuntimeException("CaviumNetworkError");
				}
				catch (KeyStoreException e) {
					alertsService.createAlert(loggedInUser,"Device "+dbAppliance.getApplianceName()+"  try to perofrm initialize by "+loggedInUser+ " does not initialize.");
					throw new RuntimeException("CaviumNetworkError");
				}
				catch (NoSuchAlgorithmException e) {
					alertsService.createAlert(loggedInUser,"Device "+dbAppliance.getApplianceName()+"  try to perofrm initialize by "+loggedInUser+ " does not initialize.");
					throw new RuntimeException("CaviumNetworkError");
				}catch(JsonProcessingException exp){
					alertsService.createAlert(loggedInUser,"Device "+dbAppliance.getApplianceName()+"  try to perofrm initialize by "+loggedInUser+ " does not initialize.");
					logger.error("Error occured during initlize  appliance in initilizeApplianceRelationship method");
					throw new RuntimeException(applianceDetailModel.getApplianceName()+	" Json Parsing Error.");
				} catch (IOException e) {
					alertsService.createAlert(loggedInUser,"Device "+dbAppliance.getApplianceName()+"  try to perofrm initialize by "+loggedInUser+ " does not initialize.");
					logger.error("Error occured during initlize  appliance in initilizeApplianceRelationship method");
					throw new RuntimeException(applianceDetailModel.getApplianceName()+" Input Output Error.");
				}
			}else {
				dbAppliance=applianceDetailModel;
				dbAppliance.setCode("409");
				dbAppliance.setMessage("appliance does not exists into the system");
				alertsService.createAlert(loggedInUser,"Device "+dbAppliance.getApplianceName()+"  try to perofrm initialize by "+loggedInUser+ " does not exist in cavium network.");
			}
			return dbAppliance;
		}
	}

	/*
	 * This method is used to get AdminHost Details from Cavium REST API
	 * 
	 */
	public HostStats GetHostAdminVMStats(ApplianceDetailModel applianceDetailModel,HostStats hostStats,String apiName){
		try{
			ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/"+apiName);
			if(response!=null && response.getStatusCode().name().equals("OK")) {
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						String status = root.path("status").asText();
						String operation = root.path("operation").asText();
						String partitionName = root.path("partitionName").asText();
						long startTime = root.path("startTime").asLong();
						long endTime = root.path("endTime").asLong();
						String startDateTime=CaviumUtil.formatDatefromLong(startTime);
						String endDateTime=CaviumUtil.formatDatefromLong(endTime);
						String message = root.path("message").asText();
						String jobId = root.path("jobId").asText();
						JsonNode dataNode = root.path("data");
						hostStats.setStatus(status);
						hostStats.setEndTime(endDateTime);
						hostStats.setStartTime(startDateTime);
						hostStats.setOperation(operation);
						hostStats.setPartitionName(partitionName);
						hostStats.setMessage(message);
						hostStats.setJobId(jobId);						 
						/*	if(!errors.isNull()){
							Iterator<JsonNode> itr = errors.elements();					         
							while (itr.hasNext()) {
								JsonNode temp = itr.next();
							}
						}*/
						if(!dataNode.isNull()){
							if(dataNode.has("vmstats")){
								Data data = new Data();
								hostStats.setDataObject(data);
								JsonNode vmstatsNode = dataNode.path("vmstats");
								if(!vmstatsNode.isNull()){
									Vmstats vmstats= new Vmstats();
									data.setVmstatsObject(vmstats);
									if(vmstatsNode.has("cavServerStatus")){										
										double cavServerStatus=vmstatsNode.path("cavServerStatus").asDouble();
										vmstats.setCavServerStatus(cavServerStatus);
									}
									if(vmstatsNode.has("systemUpTime")){										
										JsonNode systemUpTimeNode = vmstatsNode.path("systemUpTime");
										if(!systemUpTimeNode.isNull()){
											long totalSeconds=0;
											SystemUpTime systemUpTime= new SystemUpTime();
											vmstats.setSystemUpTimeObject(systemUpTime);
											if(systemUpTimeNode.has("hours")){
												long hours=systemUpTimeNode.path("hours").asLong();
												systemUpTime.setHours(hours);
												totalSeconds=totalSeconds+CaviumUtil.hoursToSeconds(hours);
											}
											if(systemUpTimeNode.has("minutes")){
												long minutes=systemUpTimeNode.path("minutes").asLong();
												systemUpTime.setMinutes(minutes);
												totalSeconds=totalSeconds+CaviumUtil.minutesToSeconds(minutes);
											}
											if(systemUpTimeNode.has("seconds")){
												long seconds=systemUpTimeNode.path("seconds").asLong();
												systemUpTime.setSeconds(seconds);
												totalSeconds=totalSeconds+seconds;
											}
											systemUpTime.setFormatedDate(CaviumUtil.timeInDaysHoursFormat(totalSeconds));
										}
									}
									if(vmstatsNode.has("rxQueue")){
										JsonNode rxQueueNode = vmstatsNode.path("rxQueue");
										if(!rxQueueNode.isNull()){
											RxQueue rxQueue= new RxQueue();
											vmstats.setRxQueueObject(rxQueue);
											if(rxQueueNode.has("rdt")){
												double rdt=rxQueueNode.path("rdt").asDouble();
												rxQueue.setRdt(rdt);
											}
											if(rxQueueNode.has("rdh")){
												double rdh=rxQueueNode.path("rdh").asDouble();
												rxQueue.setRdh(rdh);
											}						 
										}
									}
									if(vmstatsNode.has("drvReqIdQueue")){
										JsonNode drvReqIdQueueNode = vmstatsNode.path("drvReqIdQueue");
										if(!drvReqIdQueueNode.isNull()){
											DrvReqIdQueue drvReqIdQueue = new DrvReqIdQueue();
											vmstats.setDrvReqIdQueueObject(drvReqIdQueue);
											if(drvReqIdQueueNode.has("head")){
												double head=drvReqIdQueueNode.path("head").asDouble();
												drvReqIdQueue.setHead(head);
											}
											if(drvReqIdQueueNode.has("tail")){
												double tail=drvReqIdQueueNode.path("tail").asDouble();
												drvReqIdQueue.setTail(tail);
											}						 
										}
									}
									if(vmstatsNode.has("ramStats(mb)")){
										JsonNode ramStatsNode = vmstatsNode.path("ramStats(mb)");
										if(!ramStatsNode.isNull()){
											RamStats ramStats= new RamStats();
											vmstats.setRamStats(ramStats);
											if(ramStatsNode.has("total")){
												double total=ramStatsNode.path("total").asDouble();
												ramStats.setTotal(total);
											}
											if(ramStatsNode.has("free")){
												double free=ramStatsNode.path("free").asDouble();
												ramStats.setFree(free);
											}	
											ramStats.setUsed(ramStats.getTotal()-ramStats.getFree());
											ramStats.setUsedPercentage(CaviumUtil.calculatePercetage(ramStats.getTotal(),ramStats.getUsed()));
										}
									}		
									if(vmstatsNode.has("txQueue")){
										JsonNode txQueueNode = vmstatsNode.path("txQueue");
										if(!txQueueNode.isNull()){
											TxQueue txQueue= new TxQueue();
											vmstats.setTxQueueObject(txQueue);
											if(txQueueNode.has("tdh")){
												double tdh=txQueueNode.path("tdh").asDouble();
												txQueue.setTdh(tdh);
											}
											if(txQueueNode.has("tdt")){
												double tdt=txQueueNode.path("tdt").asDouble();
												txQueue.setTdt(tdt);
											}						 
										}
									}
									if(vmstatsNode.has("fwReqIdQueue")){
										JsonNode fwReqIdQueueNode = vmstatsNode.path("fwReqIdQueue");
										if(!fwReqIdQueueNode.isNull()){
											FwReqIdQueue fwReqIdQueue= new FwReqIdQueue();
											vmstats.setFwReqIdQueueObject(fwReqIdQueue);
											if(fwReqIdQueueNode.has("head")){
												double head=fwReqIdQueueNode.path("head").asDouble();
												fwReqIdQueue.setHead(head);
											}
											if(fwReqIdQueueNode.has("tail")){
												double tail=fwReqIdQueueNode.path("tail").asDouble();
												fwReqIdQueue.setTail(tail);
											}						 
										}
									}
									if(vmstatsNode.has("swapStats(mb)")){
										JsonNode swapStatsNode = vmstatsNode.path("swapStats(mb)");
										if(!swapStatsNode.isNull()){
											SwapStats swapStats= new SwapStats();
											vmstats.setSwapStats(swapStats);
											if(swapStatsNode.has("total")){
												double total=swapStatsNode.path("total").asDouble();
												swapStats.setTotal(total);
											}
											if(swapStatsNode.has("free")){
												double free=swapStatsNode.path("free").asDouble();
												swapStats.setFree(free);
											}

											swapStats.setUsedPercentage(CaviumUtil.calculatePercetage(swapStats.getTotal(),swapStats.getUsed()));
										}
									}							
									if(vmstatsNode.has("linkStatus(eth0)")){
										double linkStatusEth0=vmstatsNode.path("linkStatus(eth0)").asDouble();
										vmstats.setLinkStatusEth0(linkStatusEth0);
									}
									if(vmstatsNode.has("cpuUsage(%)")){
										double cpuUsage=vmstatsNode.path("cpuUsage(%)").asDouble();	
										vmstats.setCpuUsage(cpuUsage);
									}
									if(vmstatsNode.has("linkStatus(eth1)")){
										double linkStatusEth01=vmstatsNode.path("linkStatus(eth1)").asDouble();
										vmstats.setLinkStatusEth1(linkStatusEth01);
									}
									if(vmstatsNode.has("processCount")){
										double processCount=vmstatsNode.path("processCount").asDouble();
										vmstats.setProcessCount(processCount);
									}
									if(vmstatsNode.has("freeSpace(mb)")){
										double freeSpace=vmstatsNode.path("freeSpace(mb)").asDouble();
										vmstats.setFreeSpace(freeSpace);									 
									}
									if(vmstatsNode.has("driverStatus")){
										double driverStatus=vmstatsNode.path("driverStatus").asDouble();
										vmstats.setDriverStatus(driverStatus);		
										if(driverStatus==0){
											vmstats.setDriverStatusStr("down");
										}
										if(driverStatus==1){
											vmstats.setDriverStatusStr("Up");
										}
									}		
								}

							}
						}
					}
				}
			}
		}catch(Exception exp){
			logger.error("Error occured during fetch AdminHostStats Info of class ApplianceServiceImpl ::" + exp.getMessage());
		}
		return hostStats;
	}
	/*
	 * This method is used to get Appliance Information from Cavium REST API 
	 *
	 */
	public ApplianceInfo GetApplianceInfo(ApplianceDetailModel applianceDetailModel ,ApplianceInfo applianceInfo){
		try{
			ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/appliance_info");
			if(response!=null && response.getStatusCode().name().equals("OK")) {
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						String status = root.path("status").asText();
						//JsonNode errors = root.path("errors");
						String operation = root.path("operation").asText();
						long startTime = root.path("startTime").asLong();
						long endTime = root.path("endTime").asLong();
						String startDateTime=CaviumUtil.formatDatefromLong(startTime);
						String endDateTime=CaviumUtil.formatDatefromLong(endTime);
						String message = root.path("message").asText();
						applianceInfo.setStatus(status);
						applianceInfo.setOperation(operation);
						applianceInfo.setStartTime(startDateTime);
						applianceInfo.setEndTime(endDateTime);
						applianceInfo.setErrorMessage(message);
						/*	if(!errors.isNull()){
							Iterator<JsonNode> itr = errors.elements();					         
							while (itr.hasNext()) {
								JsonNode temp = itr.next();    
							}
						}	*/					
						JsonNode dataNode = root.path("data");
						if(!dataNode.isNull()){
							if(dataNode.has("linuxVersion")) {
								String linuxVersion = dataNode.path("linuxVersion").asText();
								applianceInfo.setLinuxVersion(linuxVersion);
							}
							if(dataNode.has("serialNum")) {
								String serialNum = dataNode.path("serialNum").asText();
								applianceInfo.setSerialNum(serialNum);
							}
							if(dataNode.has("firmwareVersion")) {
								String firmwareVersion = dataNode.path("firmwareVersion").asText();
								applianceInfo.setFirmwareVersion(firmwareVersion);
							}
						}
					}
				}
			}		
		}catch(Exception exp){
			logger.error("Error occured during fetch Appliance Info of class ApplianceServiceImpl ::" + exp.getMessage());	
		}
		return applianceInfo;
	}

	/*
	 * This method is used to get HSM Information from Cavium REST API 
	 *  
	 */

	public HSMInfo getHSMInfo(ApplianceDetailModel applianceDetailModel,HSMInfo objHSMInfo){
		try{

			ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/info");
			if(response!=null && response.getStatusCode().name().equals("OK")) {
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						String status = root.path("status").asText();
						//JsonNode errors = root.path("errors");
						String operation = root.path("operation").asText();
						String partitionName = root.path("partitionName").asText();
						long startTime = root.path("startTime").asLong();
						long endTime = root.path("endTime").asLong();
						String startDateTime=CaviumUtil.formatDatefromLong(startTime);
						String endDateTime=CaviumUtil.formatDatefromLong(endTime);
						String message = root.path("message").asText();
						int jobId = root.path("jobId").asInt();
						JsonNode dataNode = root.path("data");
						objHSMInfo.setStatus(status);
						objHSMInfo.setOperation(operation);
						objHSMInfo.setPartitionName(partitionName);
						objHSMInfo.setStartTime(startDateTime);
						objHSMInfo.setEndTime(endDateTime);
						objHSMInfo.setErrorMessage(message);
						objHSMInfo.setJobId(jobId);
						/*	if(!errors.isNull()){
							Iterator<JsonNode> itr = errors.elements();                                       
							while (itr.hasNext()) {
								JsonNode temp = itr.next();                                              
							}
						}*/
						if(!dataNode.isNull()){
							if(dataNode.has("totalPublicMemory(KB)")) {
								int totalPublicMemory = dataNode.path("totalPublicMemory(KB)").asInt();
								objHSMInfo.setTotalPublicMemory(totalPublicMemory);
							}
							if(dataNode.has("mwVersion")) {
								String mwVersion = dataNode.path("mwVersion").asText();
								objHSMInfo.setMwVersion(mwVersion);
							}
							if(dataNode.has("hardwareMinor")) {
								String hardwareMinor = dataNode.path("hardwareMinor").asText();
								objHSMInfo.setHardwareMinor(hardwareMinor);
							}
							if(dataNode.has("systemVendorId")) {
								String systemVendorId = dataNode.path("systemVendorId").asText();
								objHSMInfo.setSystemVendorId(systemVendorId);
							}
							if(dataNode.has("cuLoginFailure")) {
								int cuLoginFailure = dataNode.path("cuLoginFailure").asInt();
								objHSMInfo.setCuLoginFailure(cuLoginFailure);
							}
							if(dataNode.has("rwSessionCount")) {
								int rwSessionCount = dataNode.path("rwSessionCount").asInt();
								objHSMInfo.setRwSessionCount(rwSessionCount);
							}
							if(dataNode.has("coLoginFailure")) {
								int coLoginFailure = dataNode.path("coLoginFailure").asInt();
								objHSMInfo.setCoLoginFailure(coLoginFailure);
							}
							if(dataNode.has("freePrivateMemory(KB)")) {
								int freePrivateMemory = dataNode.path("freePrivateMemory(KB)").asInt();
								objHSMInfo.setFreePrivateMemory(freePrivateMemory);
							}
							if(dataNode.has("slaveConfig")) {
								String slaveConfig = dataNode.path("slaveConfig").asText();
								objHSMInfo.setSlaveConfig(slaveConfig);
							}
							if(dataNode.has("temperature")) {
								String temperature = dataNode.path("temperature").asText();
								objHSMInfo.setTemperature(temperature);
							}
							if(dataNode.has("firmwareMajor")) {
								String firmwareMajor = dataNode.path("firmwareMajor").asText();
								objHSMInfo.setFirmwareMajor(firmwareMajor);;
							}
							if(dataNode.has("label")) {
								String label = dataNode.path("label").asText();
								objHSMInfo.setLabel(label);
							}
							if(dataNode.has("subSystemId")) {
								String subSystemId = dataNode.path("subSystemId").asText();
								objHSMInfo.setSubSystemId(subSystemId);
							}
							if(dataNode.has("manufacturerId")) {
								String manufacturerId = dataNode.path("manufacturerId").asText();
								objHSMInfo.setManufacturerId(manufacturerId);
							}
							if(dataNode.has("masterConfig")) {
								String masterConfig = dataNode.path("masterConfig").asText();
								objHSMInfo.setMasterConfig(masterConfig);
							}
							if(dataNode.has("authenticationPath")) {
								int authenticationPath = dataNode.path("authenticationPath").asInt();
								objHSMInfo.setAuthenticationPath(authenticationPath);

							}
							if(dataNode.has("classCode")) {
								int classCode = dataNode.path("classCode").asInt();
								objHSMInfo.setClassCode(classCode);
							}
							if(dataNode.has("maxSessionCount")) {
								int maxSessionCount = dataNode.path("maxSessionCount").asInt();
								objHSMInfo.setMaxSessionCount(maxSessionCount);
							}
							if(dataNode.has("manufacturerId")) {
								String manufacturerId = dataNode.path("manufacturerId").asText();
								objHSMInfo.setManufacturerId(manufacturerId);
							}
							if(dataNode.has("sessionCount")) {
								int sessionCount = dataNode.path("sessionCount").asInt();
								objHSMInfo.setSessionCount(sessionCount);
							}
							if(dataNode.has("firmwareId")) {
								String firmwareId = dataNode.path("firmwareId").asText();
								objHSMInfo.setFirmwareId(firmwareId);
							}
							if(dataNode.has("maxRwSessionCount")) {
								int maxRwSessionCount = dataNode.path("maxRwSessionCount").asInt();
								objHSMInfo.setMaxRwSessionCount(maxRwSessionCount);
							}
							if(dataNode.has("buildNumber")) {
								String buildNumber = dataNode.path("buildNumber").asText();
								objHSMInfo.setBuildNumber(buildNumber);
							}
							if(dataNode.has("hardwareMajor")) {
								String hardwareMajor = dataNode.path("hardwareMajor").asText();
								objHSMInfo.setHardwareMajor(hardwareMajor);
							}
							if(dataNode.has("minPswdLen")) {
								int minPswdLen = dataNode.path("minPswdLen").asInt();
								objHSMInfo.setMinPswdLen(minPswdLen);
							}
							if(dataNode.has("maxPswdLen")) {
								int maxPswdLen = dataNode.path("maxPswdLen").asInt();
								objHSMInfo.setMaxPswdLen(maxPswdLen);
							}
							if(dataNode.has("totalPrivateMemory(KB)")) {
								int totalPrivateMemory = dataNode.path("totalPrivateMemory(KB)").asInt();
								objHSMInfo.setTotalPrivateMemory(totalPrivateMemory);
							}
							if(dataNode.has("firmwareMinor")) {
								String firmwareMinor = dataNode.path("firmwareMinor").asText();
								objHSMInfo.setFirmwareMinor(firmwareMinor);
							}
							if(dataNode.has("partNumber")) {
								String partNumber = dataNode.path("partNumber").asText();
								objHSMInfo.setPartNumber(partNumber);
							}
							if(dataNode.has("freePublicMemory(KB)")) {
								int freePublicMemory = dataNode.path("freePublicMemory(KB)").asInt();
								objHSMInfo.setFreePublicMemory(freePublicMemory);
							}
							if(dataNode.has("serialNumber")){
								String serialNumber = dataNode.path("serialNumber").asText();
								objHSMInfo.setSerialNumber(serialNumber);
							}
							if(dataNode.has("fipsState")) {
								String fipsState = dataNode.path("fipsState").asText();
								objHSMInfo.setFipsState(fipsState);                                      
							}
							if(dataNode.has("hsmFlags")) {
								int hsmFlags = dataNode.path("hsmFlags").asInt();
								objHSMInfo.setHsmFlags(hsmFlags);
							}
							if(dataNode.has("model")) {
								String model = dataNode.path("model").asText();
								objHSMInfo.setModel(model);
							}
							if(dataNode.has("deviceId")) {
								String deviceId = dataNode.path("deviceId").asText();
								objHSMInfo.setDeviceId(deviceId);
							}
							StringBuffer firmwareVersion= new StringBuffer();
							if(objHSMInfo.getFirmwareMajor()!=null){
								firmwareVersion=firmwareVersion.append(objHSMInfo.getFirmwareMajor()+":");
							}
							if(objHSMInfo.getFirmwareMinor()!=null){
								firmwareVersion=firmwareVersion.append(objHSMInfo.getFirmwareMinor()+":");
							}
							if(objHSMInfo.getBuildNumber()!=null){
								firmwareVersion=firmwareVersion.append(objHSMInfo.getBuildNumber());
							}
							objHSMInfo.setFirmwareVersion(firmwareVersion.toString());
						}
					}
				}
			}
		}catch(Exception exp){
			logger.error("Error occured during fetch HSM Info of class ApplianceServiceImpl ::" + exp.getMessage()); 
		}
		return objHSMInfo;
	}


	/***
	 * This method is used for search operation as normal and advanced search
	 */
	@Override
	public List<ApplianceDetailModel> searchAppliance(ApplianceDetailModel applianceDetailModel) {
		List<ApplianceDetailModel> serachApplianceDetailModel=null;
		try {
			String applianceName = applianceDetailModel.getApplianceName();
			String applianceStatus = applianceDetailModel.getApplianceStatus();
			String ipAddress = applianceDetailModel.getIpAddress();
			String hostName = applianceDetailModel.getHostName();
			String ipmiIp = applianceDetailModel.getIpmiIp();

			if (applianceName == null) {
				applianceName = "";
			}
			if (applianceStatus == null) {
				applianceStatus = "";
			}
			if (ipAddress == null) {
				ipAddress = "";
			}

			if (hostName == null) {
				hostName = "";
			}
			if (ipmiIp == null) {
				ipmiIp = "";
			}
			serachApplianceDetailModel=applianceRepository.serchAppliance(applianceName,applianceStatus,ipAddress,hostName,ipmiIp,StoreType.PERMANENT);

		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Error occured during serach operation on appliance inside method searchAppliance of class ApplianceDetailModel ");
		}
		// TODO Auto-generated method stub
		return serachApplianceDetailModel;
	}

	@Override
	public List<ApplianceDetailModel> getListOfTempAppliances() {
		String loggedInUser = userAttributes.getlogInUserName();
		List<ApplianceDetailModel> applianceTempModel=null;
		try {
			applianceTempModel=applianceRepository.getListOfTempAppliancesByUserId(loggedInUser,StoreType.TEMP);
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Error occured during fetch of the temporary list of appliances");
		}
		// TODO Auto-generated method stub
		return applianceTempModel;
	}


	@Override
	public CaviumResponseModel createApplianceForTesting(List<ApplianceDetailModel> applianceDetailModel) {

		// TODO Auto-generated method stub
		CaviumResponseModel responseModel=getCaviumResponseModel();
		try {
			if (applianceDetailModel != null && applianceDetailModel.size() > 0) {
				String loggedInUser = userAttributes.getlogInUserName();
				for(ApplianceDetailModel app : applianceDetailModel) {
					List<ApplianceDetailModel> tempApplianceDetailmodel=applianceRepository.getApplianceExists(app.getIpAddress());
					if(tempApplianceDetailmodel.size() == 0) {
						app.setCreatedBy(loggedInUser);
						app.setCreatedDate(new Date());
						app.setStoreType(StoreType.PERMANENT);
						app.setApplianceStatus("Active");
						if(StringUtils.isEmpty(app.getAuthId())) {
							app.setAuthId("1234");
						}
						ApplianceDetailModel applianceTemp=applianceRepository.save(app);
						if(applianceTemp!=null) {
							List<UserGroupModel> usg=userGroupRepository.findGroupDetailsForGroupName(env.getProperty("user.defaultusergroup")); 
							if(!usg.isEmpty()) {
								UserGroupModel userGroupModel=(UserGroupModel)usg.get(0);
								DesignationApplianceModel designationApplianceModel=new DesignationApplianceModel();
								designationApplianceModel.setDesignationId(userGroupModel.getId());
								designationApplianceModel.setObjApplianceDetailModel(applianceTemp);
								designationAppliance.save(designationApplianceModel);
							}
						}
						responseModel.setResponseCode("200");
						responseModel.setResponseMessage(env.getProperty("applianceCreation.success"));
						recentActivityServiceImpl.createRecentActivity(loggedInUser, "New device "+app.getApplianceName()+" added by "+loggedInUser);

					}else {
						responseModel.setResponseCode("409");
						responseModel.setResponseMessage("Failed to create as already available");
					}
				}
			} else {
				logger.error("ApplianceDetailModel is empty or null ::");
				responseModel.setResponseCode("204");
				responseModel.setResponseMessage(env.getProperty("applianceCreation.failureEmpty"));
			}
		} catch (Exception e) {
			logger.error("Error occured due to db error inside createAppliance Method of class ApplianceServiceImpl ::" + e.getMessage());
			responseModel.setResponseCode("500");
			responseModel.setResponseMessage(env.getProperty("applianceCreation.failureDB"));
		}
		return responseModel;
	}

	public List<ApplianceCityDetail>listAppliancesDetailCityWise(List<ApplianceDetailModel> listApplianceDetailModels){
		TreeMap<String,ApplianceCityDetail> cityNameMap= new TreeMap<String, ApplianceCityDetail>(String.CASE_INSENSITIVE_ORDER);
		ApplianceCityDetail objApplianceCityDetail= null;	
		List<ApplianceCityDetail> listApplianceToplology=null;
		for (Iterator<ApplianceDetailModel> iterator = listApplianceDetailModels.iterator(); iterator.hasNext();) {
			ApplianceDetailModel applianceDetailModel = (ApplianceDetailModel) iterator.next();
			String cityName=applianceDetailModel.getCityName();
			logger.info("cityName :: Appliance Status "+cityName +"::"+applianceDetailModel.getApplianceStatus());	 
			if("Active".equals(applianceDetailModel.getApplianceStatus())){

				if(!cityNameMap.containsKey(cityName)){
					objApplianceCityDetail= new ApplianceCityDetail();
					objApplianceCityDetail.setCityName(cityName);
					cityNameMap.put(cityName,objApplianceCityDetail);	
				}					 					
				if(cityNameMap.containsKey(cityName)){
					objApplianceCityDetail=cityNameMap.get(cityName);
					objApplianceCityDetail.getApplianceStatus().setActiveStatus((objApplianceCityDetail.getApplianceStatus().getActiveStatus()+1));
				}
			}
			if("Inactive".equals(applianceDetailModel.getApplianceStatus())){
				if(!cityNameMap.containsKey(cityName)){		
					objApplianceCityDetail= new ApplianceCityDetail();
					objApplianceCityDetail.setCityName(cityName);
					cityNameMap.put(cityName,objApplianceCityDetail);
				}					 					
				if(cityNameMap.containsKey(cityName)){
					objApplianceCityDetail=cityNameMap.get(cityName);
					objApplianceCityDetail.getApplianceStatus().setInactiveStatus((objApplianceCityDetail.getApplianceStatus().getInactiveStatus()+1));
				}
			}
			if("Suspended".equals(applianceDetailModel.getApplianceStatus())){
				if(!cityNameMap.containsKey(cityName)){
					objApplianceCityDetail= new ApplianceCityDetail();
					objApplianceCityDetail.setCityName(cityName);
					cityNameMap.put(cityName,objApplianceCityDetail);	
				}					 					
				if(cityNameMap.containsKey(cityName)){
					objApplianceCityDetail=cityNameMap.get(cityName);
					objApplianceCityDetail.getApplianceStatus().setSuspendedStatus((objApplianceCityDetail.getApplianceStatus().getSuspendedStatus()+1));
				}
			}
		}
		listApplianceToplology = new ArrayList<ApplianceCityDetail>(cityNameMap.values());
		return listApplianceToplology;
	}
	/*
	 * setHostNetorkVmConfig is used to send the network Data in Cavium Rest API 
	 * @ requestParam : adminVMData
	 *  
	 */
	public CaviumResponseModel setHostNetorkVmConfig(String applianceIp,AdminVMData adminVMData){
		CaviumResponseModel responseModel=getCaviumResponseModel();
		try{
			JSONObject json = new JSONObject(); 
			ApplianceDetailModel dbAppliance=applianceRepository.findOne(Long.parseLong(adminVMData.getApplianceId())); 
			if(dbAppliance!=null) {
				long applianceId=dbAppliance.getApplianceId();  
				InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(applianceId);
				if(initmodel!=null) {
					InitializeApplianceDetailModel initAppDetailModel = initializeRepository.findOne(initmodel.getInitializeId());
					DualFactorAuthDetailModel dualAuthModel=initAppDetailModel.getDualFactorAuthDetailModel();
					if(!StringUtils.isEmpty(adminVMData.getUsername()) && !StringUtils.isEmpty(adminVMData.getPassword())) {
						if(initAppDetailModel.getAuthenticationLevel()==0) {
							json.put("username", adminVMData.getUsername());
							json.put("password", adminVMData.getPassword());
						}if(initAppDetailModel.getAuthenticationLevel()==1 && dualAuthModel!=null) {
							json.put("username", adminVMData.getUsername());
							json.put("password", adminVMData.getPassword());
							json.put("dualFactorHostname", dualAuthModel.getDualFactorAuthServerAddress());
							json.put("dualFactorPort", dualAuthModel.getDualFactorAuthServerPortNo());
							json.put("dualFactorCertificate", dualAuthModel.getDualFactorAuthServerCertId());
						}
					}else {
						if(initAppDetailModel.getAuthenticationLevel()==0) {
							json.put("username", initmodel.getOperationPerformUserName());
							json.put("password", CaviumUtil.decrypt(initAppDetailModel.getCryptoOfficerPassword()));
						}if(initAppDetailModel.getAuthenticationLevel()==1 && dualAuthModel!=null) {
							json.put("username", initAppDetailModel.getCryptoOfficerName());
							json.put("password", CaviumUtil.decrypt(initAppDetailModel.getCryptoOfficerPassword()));
							json.put("dualFactorHostname", dualAuthModel.getDualFactorAuthServerAddress());
							json.put("dualFactorPort", dualAuthModel.getDualFactorAuthServerPortNo());
							json.put("dualFactorCertificate", dualAuthModel.getDualFactorAuthServerCertId());
						}
					}
				}else {
					if(!StringUtils.isEmpty(adminVMData.getUsername()) && !StringUtils.isEmpty(adminVMData.getUsername())) {
						json.put("username", adminVMData.getUsername());
						json.put("password", adminVMData.getUsername());
					}else {
						responseModel.setResponseCode("409");
						responseModel.setResponseMessage("Host Network data not saved due to credentials not available");
						return responseModel;
						//	alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+"  try to perofrm reboot by "+loggedInUser+ " at "+CaviumUtil.formatDateTimeFromCurrenDate(new Date()) +" doesnot reboot.");
					}
				}


				Map<String,Object> general= new HashMap<String,Object>();
				general.put("gateway", adminVMData.getGeneral().getGateway());
				general.put("ip",adminVMData.getGeneral().getIp());
				general.put("subnetMask", adminVMData.getGeneral().getSubnet());
				general.put("dhcp", adminVMData.getGeneral().getDhcp());
				general.put("vlan", adminVMData.getGeneral().getVlan());	
				Map<String,Object> mac= new HashMap<String,Object>();
				mac.put("staticMac", adminVMData.getGeneral().getMacStatic());
				mac.put("address", adminVMData.getGeneral().getMacAddress());
				general.put("mac", mac);
				json.put("general",general);
				Map<String,Object> advanced= new HashMap<String,Object>();
				Map<String,Object> dnsConfig= new HashMap<String,Object>();
				if(adminVMData.getAdvanced()!=null){
					dnsConfig.put("enableService",adminVMData.getAdvanced().getEnableDNSService());
					dnsConfig.put("searchDomainNames", adminVMData.getAdvanced().getSearchDomainNames());
					dnsConfig.put("dnservers", adminVMData.getAdvanced().getDnsServers());
					advanced.put("dnsConfig", dnsConfig);
					json.put("advanced",advanced);
					if(adminVMData.getAdvanced().getRemovedHostIPs()!=null && adminVMData.getAdvanced().getRemovedHostIPs().size()>0){
						json.put("remove",adminVMData.getAdvanced().getRemovedHostIPs());
					}
					Map<String,Object> staticIpToHostConfig= new HashMap<String,Object>();
					List<Map<String,Object>> addList= new ArrayList<Map<String,Object>>();
					if(adminVMData.getAdvanced().getStaticIpToHostConfig()!=null){
						for (Iterator<StaticIpToHostConfig> iterator = adminVMData.getAdvanced().getStaticIpToHostConfig().iterator(); iterator.hasNext();) {
							StaticIpToHostConfig  obj = (StaticIpToHostConfig) iterator.next();
							Map<String,Object> staticIpToHostConfigMap= new HashMap<String,Object>();
							staticIpToHostConfigMap.put("ip", obj.getIp());
							staticIpToHostConfigMap.put("hostname", obj.getHostname());
							staticIpToHostConfigMap.put("alias", obj.getAlias());
							addList.add(staticIpToHostConfigMap);
						}
						staticIpToHostConfig.put("add",addList);
						json.put("staticIpToHostConfig",staticIpToHostConfig);
					}
				}
				ResponseEntity<String> response=restClient.invokePOSTMethodForOperations("https://"+applianceIp+"/liquidsa/admin_vm_config", json);
				if(response!=null && response.getStatusCode().name().equals("OK")) {
					ObjectMapper mapper = new ObjectMapper();
					if(response.getBody()!=null){
						JsonNode root = mapper.readTree(response.getBody());
						if(!root.isNull()){
							String status = root.path("status").asText();
							if("success".equalsIgnoreCase(status)){
								responseModel.setResponseCode("200");
								responseModel.setResponseMessage("data saved successfully");
							}
							JsonNode errors = root.path("errors");
							if(!errors.isNull() && errors.size()>0){
								String encodeMessage = root.path("message").asText();
								Iterator<JsonNode> itr = errors.elements();                           
								while (itr.hasNext()) { 
									//	JsonNode temp = itr.next();
									if(StringUtils.isEmpty(encodeMessage)){
										responseModel.setResponseCode("409");
										responseModel.setResponseMessage("error is coming while saving data to cavium Network.");
									}
									else{
										responseModel.setResponseCode("409");
										responseModel.setResponseMessage(CaviumUtil.decodeMessageBase64(encodeMessage));
									}   
								}
							}
						}
					} 
				}
			}else {
				responseModel.setResponseCode("409");
				responseModel.setResponseMessage(env.getProperty("appliance.notexists.cavium"));
				//alertsService.createAlert(loggedInUser,"Device "+app.getApplianceName()+"  try to perofrm reboot by "+loggedInUser+ " at "+CaviumUtil.formatDateTimeFromCurrenDate(new Date()) +" doesnot exist in cavium netwoork.");
			}
		}			
		catch (Exception e) {
			logger.error("Error occured during saving data in cavium network in setHostNetorkVmConfig method."+e.getMessage());
		}

		return responseModel;
	}
	/**
	 * This method will upload the files for firmware upgrade
	 * @param app
	 * @param coUsername
	 * @param coPassword
	 * @param dualAuthModel
	 * @return
	 */
	private HashMap<String,String> getUploadedFileNames(ApplianceDetailModel app,String coUsername,String coPassword,DualFactorAuthDetailModel dualAuthModel){
		HashMap<String,String> map=new HashMap<>();
		File imageFileConvertedFile = null;
		File signFileConvertedFile = null;
		try {
			if(app.getFirmwareUpgradeDetailModel()!=null) {
				String imageFilename=app.getFirmwareUpgradeDetailModel().getImageFileDeatils().getFileName();
				String imageFileContent=app.getFirmwareUpgradeDetailModel().getImageFileDeatils().getFileContent();

				String signFilename=app.getFirmwareUpgradeDetailModel().getSignFileDeatils().getFileName();
				String signFileExtention=app.getFirmwareUpgradeDetailModel().getSignFileDeatils().getFileExtension();
				String signFileContent=app.getFirmwareUpgradeDetailModel().getSignFileDeatils().getFileContent();
				imageFileConvertedFile = CaviumUtil.createFile(imageFilename,"",imageFileContent);
				signFileConvertedFile = CaviumUtil.createFile(signFilename,signFileExtention,signFileContent);
			}

			if(dualAuthModel!=null) {
				if(imageFileConvertedFile!=null && signFileConvertedFile!=null) {
					CaviumResponseModel	imageFilePath=fileUploadService.uploadFile(imageFileConvertedFile,coUsername,coPassword,"FirmwareUpgrade",app.getIpAddress(),dualAuthModel);
					CaviumResponseModel	signFilePath=fileUploadService.uploadFile(signFileConvertedFile,coUsername,coPassword,"FirmwareUpgrade",app.getIpAddress(),dualAuthModel);
					map.put("imageFilePath", imageFilePath.getResponseMessage());
					map.put("signFilePath", signFilePath.getResponseMessage());
				}
			}else {
				if(imageFileConvertedFile!=null && signFileConvertedFile!=null) {
					CaviumResponseModel	imageFilePath=fileUploadService.uploadFile(imageFileConvertedFile,coUsername,coPassword,"FirmwareUpgrade",app.getIpAddress(),null);
					CaviumResponseModel	signFilePath=fileUploadService.uploadFile(signFileConvertedFile,coUsername,coPassword,"FirmwareUpgrade",app.getIpAddress(),null);
					map.put("imageFilePath", imageFilePath.getResponseMessage());
					map.put("signFilePath", signFilePath.getResponseMessage());
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getUploadedFileNames");
		}
		return map;
	}



	public CaviumResponseModel getCertificateURL(String certificateType, String applianceIp) {

		String certificateUrl=null;
		String	errorMessage=null;
		CaviumResponseModel responseModel=getCaviumResponseModel();
		try{
			ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceIp+"/liquidsa/"+certificateType);
			if(response!=null && response.getStatusCode().name().equals("OK")) {
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						String status = root.path("status").asText();
				 
						if("success".equalsIgnoreCase(status)){
							JsonNode dataNode = root.path("data");
							if(!dataNode.isNull() && dataNode.size()>0){
								if(dataNode.has("downloadCaviumCertificateUrlAddr")) {
									certificateUrl = dataNode.path("downloadCaviumCertificateUrlAddr").asText();
									responseModel.setResponseCode("200");
									responseModel.setResponseMessage("certificateUrl");
								}	 
							}
						}
						 if("error".equalsIgnoreCase(status)){
								JsonNode errors = root.path("errors");
								if(!errors.isNull() && errors.size()>0){
									Iterator<JsonNode> itr = errors.elements();                           
									while (itr.hasNext()) {
										JsonNode temp = itr.next();
										if(temp.asInt()==11095)
											{ 
											errorMessage="HSM owner certificate is not installed."; 
									  }
										if(temp.asInt()==11096)
										{ 
											errorMessage="HSM Certificate issued by HO is not installed."; 
										 }
										if(temp.asInt()==11097)
										{ 
											errorMessage="HSM owner certificate is not installed.";
										 
										}
									 }
									responseModel.setResponseMessage(errorMessage);	  
									responseModel.setResponseCode("409");	  
									}
								}
						 }
					 }
				}				 
		}catch (Exception e) {
			logger.error("Error occured in  getCertificateURL Method :: "+e.getMessage());
		}
		return responseModel;
	}

	public CaviumResponseModel uploadCertificate(ManageCertificatesDetails manageCertificatesDetails) {

		CaviumResponseModel responseModel=getCaviumResponseModel();
		String hsmFileUploadedId=null;
		String signedHsmFileUploadedId=null;
		String username=null;
		String password=null;
		String dualFactorHostname=null;
		Integer dualFactorPort=null;
		String dualFactorCertificate=null;
		try{
			File hsmFile=null;
			File signedHsmFile=null;
			if(manageCertificatesDetails.getHSMfileContent()!=null && manageCertificatesDetails.getHSMfileExtension()!=null  && manageCertificatesDetails.getHSMfileName()!=null){
				hsmFile = CaviumUtil.createFile(manageCertificatesDetails.getHSMfileName(),manageCertificatesDetails.getHSMfileExtension(),manageCertificatesDetails.getHSMfileContent());
			}
			if(manageCertificatesDetails.getSignedHSMfileName()!=null && manageCertificatesDetails.getSignedHSMfileExtension()!=null && manageCertificatesDetails.getSignedHSMfileContent()!=null){
				signedHsmFile = CaviumUtil.createFile(manageCertificatesDetails.getSignedHSMfileName(),manageCertificatesDetails.getSignedHSMfileExtension(),manageCertificatesDetails.getSignedHSMfileContent());
			}
			InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(manageCertificatesDetails.getApplianceId());
			if(initmodel!=null) {
				String operationPerformedPassword= CaviumUtil.decrypt(initmodel.getOperationPerformPassword());
				String operationPerformedUserName=initmodel.getOperationPerformUserName();
				InitializeApplianceDetailModel initAppDetailModel = initializeRepository.findOne(initmodel.getInitializeId());
				DualFactorAuthDetailModel dualAuthModel=initAppDetailModel.getDualFactorAuthDetailModel();
				username=operationPerformedUserName;
				password=operationPerformedPassword;
				if(dualAuthModel!=null) {
					dualFactorHostname=dualAuthModel.getDualFactorAuthServerAddress();
					dualFactorPort=dualAuthModel.getDualFactorAuthServerPortNo();
					dualFactorCertificate=dualAuthModel.getDualFactorAuthServerCertId();

					if(hsmFile!=null){
						responseModel=fileUploadService.uploadFile(hsmFile,operationPerformedUserName,operationPerformedPassword,"StoreHSMOwnerCerts",manageCertificatesDetails.getApplianceIp(),dualAuthModel);
						hsmFileUploadedId=responseModel.getResponseMessage();
					}
					if(signedHsmFile!=null){
						responseModel=fileUploadService.uploadFile(signedHsmFile,operationPerformedUserName,operationPerformedPassword,"StoreHSMOwnerCerts",manageCertificatesDetails.getApplianceIp(),dualAuthModel);
						signedHsmFileUploadedId=responseModel.getResponseMessage();
					}
				}
			}else{
				username=manageCertificatesDetails.getOperationUsername();
				password=manageCertificatesDetails.getOperationPassword();
				if(hsmFile!=null){
					responseModel=fileUploadService.uploadFile(hsmFile,manageCertificatesDetails.getOperationUsername(),manageCertificatesDetails.getOperationPassword(),"StoreHSMOwnerCerts",manageCertificatesDetails.getApplianceIp(),null);
					hsmFileUploadedId=responseModel.getResponseMessage();
				}
				if(signedHsmFile!=null){
					responseModel=fileUploadService.uploadFile(signedHsmFile,manageCertificatesDetails.getOperationUsername(),manageCertificatesDetails.getOperationPassword(),"StoreHSMOwnerCerts",manageCertificatesDetails.getApplianceIp(),null);
					signedHsmFileUploadedId=responseModel.getResponseMessage();
				}
			}
			if(hsmFileUploadedId!=null && signedHsmFileUploadedId!=null && username!=null && password!=null){
				JSONObject json = new JSONObject(); 	
				json.put("username",username);
				json.put("password",password);
				if(dualFactorHostname!=null && dualFactorPort!=null && dualFactorCertificate!=null){
					json.put("dualFactorHostname",dualFactorHostname);
					json.put("dualFactorPort",dualFactorPort);
					json.put("dualFactorCertificate",dualFactorCertificate);
				}
				json.put("hsmOwnerCertFileId",hsmFileUploadedId);
				json.put("hsmOwnerSignedCertFileId",signedHsmFileUploadedId);
				ResponseEntity<String> response=restClient.invokePOSTMethodForOperations("https://"+manageCertificatesDetails.getApplianceIp()+"/liquidsa/import_hsm_owner_certificates", json);
				if(response!=null && response.getStatusCode().name().equals("OK")) {	
					responseModel.setResponseCode("200");
					responseModel.setResponseMessage("Certificates uploaded succeessfully.");
				}
				else{
					responseModel.setResponseCode("409");
					responseModel.setResponseMessage("error coming while import certificates."); 
				}
			}else{
				responseModel.setResponseCode("200");
				responseModel.setResponseMessage("required attribute missing"); 
			}
		}catch (Exception e) {
			logger.error("Error occured in  uploadCertificate Method :: "+e.getMessage());
		}
		return responseModel;
	}

	public File	getCertificateFile(String certificateUrl,String applianceName){
		File file=null;
		String fileName=null;
		try{
			ResponseEntity<byte[]> response=restClient.invokeGETMethodForFileDownload(certificateUrl);
			if(response!=null && response.getStatusCode().name().equals("OK") ) {
				String finalfileName=null;
				List<String> CONTENT_DISPOSITION=response.getHeaders().get("Content-Disposition");
				for (Iterator<String> iterator = CONTENT_DISPOSITION.iterator(); iterator.hasNext();) {
					String contentDisposition = (String) iterator.next();
					String fileNameSplit[]=contentDisposition.split("=");
					if(fileNameSplit.length>0){
						fileName=fileNameSplit[1];
					}
				}				
				finalfileName = applianceName+"-"+CaviumUtil.getRandomText()+"-"+fileName;
				file = CaviumUtil.createFile(finalfileName,null,"");
				Files.write(Paths.get(file.getAbsolutePath()), response.getBody());		
			}		 
		}catch (Exception e) {
			logger.error("Error occured in  getCertificateFile Method :: "+e.getMessage());
		}
		return file;
	}


}

