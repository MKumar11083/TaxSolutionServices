package com.cavium.repository.partition;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cavium.model.partition.PartitionAdvanceStaticHostIps;
@Repository
public interface PartitionAdvanceStaticHostIpsRepository extends JpaRepository<PartitionAdvanceStaticHostIps, Long> {
	@Query(value=" select * from partition_interface_advance_static_host_ip where partition_id=:partitionId",nativeQuery=true)
	public List<PartitionAdvanceStaticHostIps> getStaticIpHostList(@Param("partitionId") String partitionId);
}
