package com.cavium.model.hostadminvm.monitorstats;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="monitor_stats_details")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class MonitorStats {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "monitorstats_id", nullable = false)
	private Long monitorStatsId;
	@Column(name="appliance_ip")
	private String applianceIp;
	@Column(name="hours_minutes")
	private String hoursminutes;
	@Column(name="status")
	private String status;
	@Transient
	ArrayList<Object > errors = new ArrayList < Object > ();
	@Column(name="partition_name")
	private String partitionName = null;
	@Column(name="job_id")
	private String jobId = null;
	@Column(name="start_time")
	private String startTime = null;
	@Transient
	private String message;
	@Column(name="end_time")
	private String endTime = null;
	@OneToOne(cascade=CascadeType.ALL,fetch = FetchType.LAZY)
	@JoinColumn(name = "data_id",nullable = false)	
	private Data Data;
	@Column(name="operation")
	private String operation;
	@Column(name="api_name")
	private String apiName;
	@Column(name = "created_date", columnDefinition = "DATETIME")
	private Date createdDate;


	@Transient
    private List<UsageInfo> usageInfo;

 	@Transient
    private List<Info> info;
	
 	@Transient
    private List<Cpus> listCpus = new ArrayList<Cpus>();

 	@Transient
    private List<Details> details;
	
  	@Transient
    private List<Usage> usage;
  	
  	@Transient
    private Lo lo;

 	@Transient
    private Sit sit0;

 	@Transient
    private Eth1 eth1;

 	@Transient
    private Eth0 eth0;
  	
 

 	 
	// Getter Methods 

	public String getStatus() {
		return status;
	}

	public String getPartitionName() {
		return partitionName;
	}

	public String getJobId() {
		return jobId;
	}

	public String getStartTime() {
		return startTime;
	}

	public String getMessage() {
		return message;
	}

	public String getEndTime() {
		return endTime;
	}



	public String getOperation() {
		return operation;
	}

	// Setter Methods 

	public void setStatus(String status) {
		this.status = status;
	}

	public void setPartitionName(String partitionName) {
		this.partitionName = partitionName;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}


	public void setOperation(String operation) {
		this.operation = operation;
	}

	/**
	 * @return the errors
	 */
	public ArrayList<Object> getErrors() {
		return errors;
	}

	/**
	 * @param errors the errors to set
	 */
	public void setErrors(ArrayList<Object> errors) {
		this.errors = errors;
	}

	/**
	 * @return the data
	 */
	public Data getData() {
		return Data;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(Data data) {
		Data = data;
	}


	/**
	 * @return the hoursminutes
	 */
	public String getHoursminutes() {
		return hoursminutes;
	}

	/**
	 * @param hoursminutes the hoursminutes to set
	 */
	public void setHoursminutes(String hoursminutes) {
		this.hoursminutes = hoursminutes;
	}

 

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the applianceIp
	 */
	public String getApplianceIp() {
		return applianceIp;
	}

	/**
	 * @param applianceIp the applianceIp to set
	 */
	public void setApplianceIp(String applianceIp) {
		this.applianceIp = applianceIp;
	}

	/**
	 * @return the monitorStatsId
	 */
	public Long getMonitorStatsId() {
		return monitorStatsId;
	}

	/**
	 * @param monitorStatsId the monitorStatsId to set
	 */
	public void setMonitorStatsId(Long monitorStatsId) {
		this.monitorStatsId = monitorStatsId;
	}

	/**
	 * @return the apiName
	 */
	public String getApiName() {
		return apiName;
	}

	/**
	 * @param apiName the apiName to set
	 */
	public void setApiName(String apiName) {
		this.apiName = apiName;
	}

	/**
	 * @return the usageInfo
	 */
	public List<UsageInfo> getUsageInfo() {
		return usageInfo;
	}

	/**
	 * @param usageInfo the usageInfo to set
	 */
	public void setUsageInfo(List<UsageInfo> usageInfo) {
		this.usageInfo = usageInfo;
	}

	/**
	 * @return the info
	 */
	public List<Info> getInfo() {
		return info;
	}

	/**
	 * @param info the info to set
	 */
	public void setInfo(List<Info> info) {
		this.info = info;
	}

	/**
	 * @return the listCpus
	 */
	public List<Cpus> getListCpus() {
		return listCpus;
	}

	/**
	 * @param listCpus the listCpus to set
	 */
	public void setListCpus(List<Cpus> listCpus) {
		this.listCpus = listCpus;
	}

	/**
	 * @return the details
	 */
	public List<Details> getDetails() {
		return details;
	}

	/**
	 * @param details the details to set
	 */
	public void setDetails(List<Details> details) {
		this.details = details;
	}

	/**
	 * @return the usage
	 */
	public List<Usage> getUsage() {
		return usage;
	}

	/**
	 * @param usage the usage to set
	 */
	public void setUsage(List<Usage> usage) {
		this.usage = usage;
	}

	/**
	 * @return the lo
	 */
	public Lo getLo() {
		return lo;
	}

	/**
	 * @param lo the lo to set
	 */
	public void setLo(Lo lo) {
		this.lo = lo;
	}

	/**
	 * @return the sit0
	 */
	public Sit getSit0() {
		return sit0;
	}

	/**
	 * @param sit0 the sit0 to set
	 */
	public void setSit0(Sit sit0) {
		this.sit0 = sit0;
	}

	/**
	 * @return the eth1
	 */
	public Eth1 getEth1() {
		return eth1;
	}

	/**
	 * @param eth1 the eth1 to set
	 */
	public void setEth1(Eth1 eth1) {
		this.eth1 = eth1;
	}

	/**
	 * @return the eth0
	 */
	public Eth0 getEth0() {
		return eth0;
	}

	/**
	 * @param eth0 the eth0 to set
	 */
	public void setEth0(Eth0 eth0) {
		this.eth0 = eth0;
	}
 


}