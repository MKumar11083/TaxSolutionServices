package com.cavium.model.partition;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.appliance.InitializeApplianceDetailModel;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Table(name = "network_stats")
public class NetworkStatsModel implements Serializable{
  
	private static final long serialVersionUID = -5177577930120382301L;
	@Id
	@Column(name="network_stat_id",nullable = false)
	private String networkStatId;
	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name = "initialize_id", nullable = false)
	@JsonBackReference
	private InitializeApplianceDetailModel initializeApplianceDetailModel;
	@Column(name="dhcp")
	 private boolean dhcp;
	 @Column(name="ip_address")
	private String ipAddress;
	 @Column(name="gateway")
	private String gateway;
	 @Column(name="subnet")
	private String subnet;
	@Column(name="vlan_id")
	private Integer vlanId;
	@Column(name="disable_eth1")
	private boolean disableEth1;
	/**
	 * @return the networkStatId
	 */
	public String getNetworkStatId() {
		return networkStatId;
	}
	/**
	 * @param networkStatId the networkStatId to set
	 */
	public void setNetworkStatId(String networkStatId) {
		this.networkStatId = networkStatId;
	}
	/**
	 * @return the dhcp
	 */
	public boolean isDhcp() {
		return dhcp;
	}
	/**
	 * @param dhcp the dhcp to set
	 */
	public void setDhcp(boolean dhcp) {
		this.dhcp = dhcp;
	}
	/**
	 * @return the ipAddress
	 */
	public String getIpAddress() {
		return ipAddress;
	}
	/**
	 * @param ipAddress the ipAddress to set
	 */
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	/**
	 * @return the gateway
	 */
	public String getGateway() {
		return gateway;
	}
	/**
	 * @param gateway the gateway to set
	 */
	public void setGateway(String gateway) {
		this.gateway = gateway;
	}
	/**
	 * @return the subnet
	 */
	public String getSubnet() {
		return subnet;
	}
	/**
	 * @param subnet the subnet to set
	 */
	public void setSubnet(String subnet) {
		this.subnet = subnet;
	}
	/**
	 * @return the vlanId
	 */
	public Integer getVlanId() {
		return vlanId;
	}
	/**
	 * @param vlanId the vlanId to set
	 */
	public void setVlanId(Integer vlanId) {
		this.vlanId = vlanId;
	}
	/**
	 * @return the disableEth1
	 */
	public boolean isDisableEth1() {
		return disableEth1;
	}
	/**
	 * @param disableEth1 the disableEth1 to set
	 */
	public void setDisableEth1(boolean disableEth1) {
		this.disableEth1 = disableEth1;
	}
	 	 
}
