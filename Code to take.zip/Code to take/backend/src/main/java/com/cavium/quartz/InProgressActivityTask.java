package com.cavium.quartz;

import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.cavium.repository.appliance.ApplianceRepository;
import com.cavium.repository.partition.PartitionRepository;
import com.cavium.repository.recentactivity.InProgressActivityRepository;
import com.cavium.utill.RestClient;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.partition.PartitionDetailModel;
import com.cavium.model.recentactivity.InProgressActivity;

@Component
public class InProgressActivityTask implements Job {
	private Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	private InProgressActivityRepository inProgressActivityRepository;
	@Autowired
	RestClient restClient;
	@Autowired
	private PartitionRepository partitionRepository;
	@Autowired 
	private ApplianceRepository applianceRepository;
	
	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		// TODO Auto-generated method stub
		logger.info("Start InProgressActivityJob");
		List<InProgressActivity> listInp=null;
		ResponseEntity<String> response=null;
		try {
			listInp=inProgressActivityRepository.findAll();
			if(listInp!=null && listInp.size() > 0) {
				for(InProgressActivity in: listInp) {
					if(in.getJobId()!=null && in.getJobId()!=000) {
						 response=restClient.invokeGETMethod("https://"+in.getIpAddress()+"/liquidsa/notification/"+in.getJobId()+"");
						if(response!=null) {
							ObjectMapper mapper = new ObjectMapper();
							JsonNode root = mapper.readTree(response.getBody());
							if(!root.isNull()){
								if(!root.path("status").isNull() && root.path("status").asText().equals("success")) {
									in.setStatus(root.path("status").asText());
									if(in.getPartitionId() > 0) {
										PartitionDetailModel partitionDetailModel=partitionRepository.findOne(in.getPartitionId());
										partitionDetailModel.setStatus("Completed");
										partitionDetailModel.setErrorMessage("");
										partitionRepository.save(partitionDetailModel);
									}if(in.getApplianceID() > 0) {
										ApplianceDetailModel app=applianceRepository.findOne(in.getApplianceID());
										app.setApplianceStatus("Completed");
										applianceRepository.save(app);
									}
								}else {
									if(!root.path("status").isNull() && root.path("status").asText().equals("error")) {
										JsonNode errors = root.path("errors");
										if(!errors.isNull()){
											 Iterator<JsonNode> itr = errors.elements();					         
									            while (itr.hasNext()) {
									                JsonNode temp = itr.next();
									                if(temp.asInt()==11032) {
									                	if(in.getPartitionId()!=null && in.getPartitionId() > 0) {
															PartitionDetailModel partitionDetailModel=partitionRepository.findOne(in.getPartitionId());
															partitionDetailModel.setErrorMessage("Session Exists, Please close the session");
															partitionDetailModel.setStatus("Failed");
															partitionDetailModel.setLastOperationPerformed(in.getOperationName());
															partitionRepository.save(partitionDetailModel);
														}if(in.getApplianceID() !=null && in.getApplianceID() > 0) {
															ApplianceDetailModel app=applianceRepository.findOne(in.getApplianceID());
															app.setApplianceStatus("Failed");
															app.setOperationPerformed(in.getOperationName());
															applianceRepository.save(app);
														}
									                }
									            }
										}	
									}
								}
							}
						}
					}else {
						if(in.getJobId()!=null && in.getJobId()==000) {
							 response=restClient.invokeGETMethod("https://"+in.getIpAddress()+"/liquidsa/notification");
							 if(response!=null) {
									ObjectMapper mapper = new ObjectMapper();
									JsonNode root = mapper.readTree(response.getBody());
									if(!root.isNull()){
										if(!root.path("status").isNull() && root.path("status").asText().equals("success")) {
											in.setStatus(root.path("status").asText());
											if(in.getPartitionId() > 0) {
												PartitionDetailModel partitionDetailModel=partitionRepository.findOne(in.getPartitionId());
												partitionDetailModel.setErrorMessage("");
												partitionDetailModel.setStatus("Completed");
											}if(in.getApplianceID() > 0) {
												ApplianceDetailModel app=applianceRepository.findOne(in.getApplianceID());
												app.setApplianceStatus("Completed");
											}
										}else {

											if(!root.path("status").isNull() && root.path("status").asText().equals("error")) {
												JsonNode errors = root.path("errors");
												if(!errors.isNull()){
													 Iterator<JsonNode> itr = errors.elements();					         
											            while (itr.hasNext()) {
											                JsonNode temp = itr.next();
											                if(temp.asInt()==11032) {
											                	if(in.getPartitionId()!=null && in.getPartitionId() > 0) {
																	PartitionDetailModel partitionDetailModel=partitionRepository.findOne(in.getPartitionId());
																	partitionDetailModel.setErrorMessage("Session Exists, Please close the session");
																	partitionDetailModel.setStatus("Failed");
																	partitionDetailModel.setLastOperationPerformed(in.getOperationName());
																	partitionRepository.save(partitionDetailModel);
											                	}if(in.getApplianceID() !=null && in.getApplianceID() > 0) {
																	ApplianceDetailModel app=applianceRepository.findOne(in.getApplianceID());
																	app.setApplianceStatus("Failed");
																	app.setOperationPerformed(in.getOperationName());
																	applianceRepository.save(app);
																}
											                }
											            }
												}	
											}
										
										}
									}
								}
						}
					}
					inProgressActivityRepository.save(in);
				}
			}
			
		} catch (Exception e) {
			logger.error("Error occured duringInProgressActivityJob"+e.getMessage());
			// TODO: handle exception
		}
		logger.info("End InProgressActivityJob");
	}
	
	

}
