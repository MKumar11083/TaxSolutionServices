package com.cavium.model.appliance;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="initialize_appliances")
public class InitializeAppliancesRelationshipModel 	implements Serializable
	 {
	   private static final long serialVersionUID = 4692301322760007284L;
	   @Id
	   @GeneratedValue(strategy=GenerationType.IDENTITY)
	   private Long id;
	   @Column(name="initialize_id")
	   private Long initializeId;
	   @Column(name="operation_perform_username")
	   private String operationPerformUserName;
	   @Column(name="operation_perform_password")
	   private String operationPerformPassword;
	   @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	 	@OneToOne(fetch=FetchType.LAZY)
	 	 @JoinColumn(name = "appliance_id",nullable = false)
	 	 private ApplianceDetailModel applianceDetailModel;
	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * @return the initializeId
	 */
	public Long getInitializeId() {
		return initializeId;
	}
	/**
	 * @param initializeId the initializeId to set
	 */
	public void setInitializeId(Long initializeId) {
		this.initializeId = initializeId;
	}
	/**
	 * @return the applianceDetailModel
	 */
	public ApplianceDetailModel getApplianceDetailModel() {
		return applianceDetailModel;
	}
	/**
	 * @param applianceDetailModel the applianceDetailModel to set
	 */
	public void setApplianceDetailModel(ApplianceDetailModel applianceDetailModel) {
		this.applianceDetailModel = applianceDetailModel;
	}
	/**
	 * @return the operationPerformUserName
	 */
	public String getOperationPerformUserName() {
		return operationPerformUserName;
	}
	/**
	 * @param operationPerformUserName the operationPerformUserName to set
	 */
	public void setOperationPerformUserName(String operationPerformUserName) {
		this.operationPerformUserName = operationPerformUserName;
	}
	/**
	 * @return the operationPerformPassword
	 */
	public String getOperationPerformPassword() {
		return operationPerformPassword;
	}
	/**
	 * @param operationPerformPassword the operationPerformPassword to set
	 */
	public void setOperationPerformPassword(String operationPerformPassword) {
		this.operationPerformPassword = operationPerformPassword;
	}
	 

}
