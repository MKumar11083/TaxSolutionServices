package com.cavium.model.partition;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
/**
 *  * @author MK00497144
 * Class is used as a partition entity having association with Appliance entity
 */
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Table(name = "partition_configuration")
public class PartitionDetailModel implements Serializable {

	private static final long serialVersionUID = -3840562434180092945L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "partition_id", nullable = false)
	private Long partitionId;
	@Column(name = "partition_name")
	private String partitionName;
	@Column(name = "csr")
	private String csr;
	@Column(name = "partition_keys")
	private Integer keys = 0;
	@Column(name = "ssl_context")
	private Integer sslContexts = 0;
	@Column(name = "acceleration_devices")
	private Integer acclrDev = 0;
	@Column(name = "wrap")
	private boolean wrap;
	@Column(name = "backup")
	private boolean backup;
	@Column(name = "created_date", columnDefinition = "DATETIME")
	private Date createdDate;
	@Column(name = "modified_date", columnDefinition = "DATETIME")
	private Date modifiedDate;
	@Column(name = "created_by")
	private String createdBy;
	@Column(name = "modified_by")
	private String modifiedBy;
	@Column(name="status")
	private String status;
	
	
	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name = "appliance_id", nullable = false)
	@JsonBackReference
	@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
	private ApplianceDetailModel applianceDetailModel;
	
	@Transient
	private PartitionData partitionData;
	
	@Transient
	private PartitionInterfaces networkStats;
	
	@Transient
	private List<PartitionCertificate> partitionCertificate;
	
	@Transient
	private String message;
	@Transient
	private String code;
	
	
	@Transient
	private String username;
	@Transient
	private String password;
	
	@Column(name="last_operation_performed")
	private String lastOperationPerformed;
	@Column(name="error_message")
	private String errorMessage;
	
	
	public Long getPartitionId() {
		return partitionId;
	}
	public void setPartitionId(Long partitionId) {
		this.partitionId = partitionId;
	}
	public String getPartitionName() {
		return partitionName;
	}
	public void setPartitionName(String partitionName) {
		this.partitionName = partitionName;
	}
	public String getCsr() {
		return csr;
	}
	public void setCsr(String csr) {
		this.csr = csr;
	}
	
	public Integer getKeys() {
		return keys;
	}
	public void setKeys(Integer keys) {
		this.keys = keys;
	}
	
	public Integer getSslContexts() {
		return sslContexts;
	}
	public void setSslContexts(Integer sslContexts) {
		this.sslContexts = sslContexts;
	}
	public Integer getAcclrDev() {
		return acclrDev;
	}
	public void setAcclrDev(Integer acclrDev) {
		this.acclrDev = acclrDev;
	}
	public boolean isWrap() {
		return wrap;
	}
	public void setWrap(boolean wrap) {
		this.wrap = wrap;
	}
	public boolean isBackup() {
		return backup;
	}
	public void setBackup(boolean backup) {
		this.backup = backup;
	}
	public ApplianceDetailModel getApplianceDetailModel() {
		return applianceDetailModel;
	}
	public void setApplianceDetailModel(ApplianceDetailModel applianceDetailModel) {
		this.applianceDetailModel = applianceDetailModel;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public PartitionInterfaces getNetworkStats() {
		return networkStats;
	}
	public void setNetworkStats(PartitionInterfaces networkStats) {
		this.networkStats = networkStats;
	}
	public List<PartitionCertificate> getPartitionCertificate() {
		return partitionCertificate;
	}
	public void setPartitionCertificate(List<PartitionCertificate> partitionCertificate) {
		this.partitionCertificate = partitionCertificate;
	}
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public PartitionData getPartitionData() {
		return partitionData;
	}
	public void setPartitionData(PartitionData partitionData) {
		this.partitionData = partitionData;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getLastOperationPerformed() {
		return lastOperationPerformed;
	}
	public void setLastOperationPerformed(String lastOperationPerformed) {
		this.lastOperationPerformed = lastOperationPerformed;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
}
