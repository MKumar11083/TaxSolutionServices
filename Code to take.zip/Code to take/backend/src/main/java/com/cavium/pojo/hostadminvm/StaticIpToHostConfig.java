package com.cavium.pojo.hostadminvm;

public class StaticIpToHostConfig
{
    private String alias;

    private String hostname;

    private String ip;
    


    public void setAlias(String alias){
        this.alias = alias;
    }
    public String getAlias(){
        return this.alias;
    }
    public void setHostname(String hostname){
        this.hostname = hostname;
    }
    public String getHostname(){
        return this.hostname;
    }
    public void setIp(String ip){
        this.ip = ip;
    }
    public String getIp(){
        return this.ip;
    }
	
}
