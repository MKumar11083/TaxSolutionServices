package com.cavium.model.partition;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Table(name = "partition_interface_advance_static_host_ip")
public class PartitionAdvanceStaticHostIps implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7611519151321448606L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	private Long Id;
	@Column(name="ip_address")
	private String ip;
	@Column(name="hostname")
	private String hostname;
	@Column(name="alias")
	private String alias;
	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name = "partition_id", nullable = false)
	@JsonBackReference
	private PartitionDetailModel partitionDetailModel;
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	public String getHostname() {
		return hostname;
	}
	public void setHostname(String hostname) {
		this.hostname = hostname;
	}
	public String getAlias() {
		return alias;
	}
	public void setAlias(String alias) {
		this.alias = alias;
	}
	public PartitionDetailModel getPartitionDetailModel() {
		return partitionDetailModel;
	}
	public void setPartitionDetailModel(PartitionDetailModel partitionDetailModel) {
		this.partitionDetailModel = partitionDetailModel;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
}
