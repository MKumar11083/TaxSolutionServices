package com.cavium.pojo;

import java.util.List;

import org.springframework.stereotype.Component;

import com.cavium.model.alerts.Alerts;
import com.cavium.model.recentactivity.RecentActivity;

@Component
public class SnapshotDetails {

	 PartitionsDetails partitionsDetails=null;
		List<RecentActivity> recentActivity = null;
		List<ApplianceCityDetail> listApplianceToplology=null;
		List<Alerts> alerts=null;
		/**
		 * @return the partitionsDetails
		 */
		public PartitionsDetails getPartitionsDetails() {
			return partitionsDetails;
		}
		/**
		 * @param partitionsDetails the partitionsDetails to set
		 */
		public void setPartitionsDetails(PartitionsDetails partitionsDetails) {
			this.partitionsDetails = partitionsDetails;
		}
		/**
		 * @return the recentActivity
		 */
		public List<RecentActivity> getRecentActivity() {
			return recentActivity;
		}
		/**
		 * @param recentActivity the recentActivity to set
		 */
		public void setRecentActivity(List<RecentActivity> recentActivity) {
			this.recentActivity = recentActivity;
		}
		/**
		 * @return the listApplianceToplology
		 */
		public List<ApplianceCityDetail> getListApplianceToplology() {
			return listApplianceToplology;
		}
		/**
		 * @param listApplianceToplology the listApplianceToplology to set
		 */
		public void setListApplianceToplology(List<ApplianceCityDetail> listApplianceToplology) {
			this.listApplianceToplology = listApplianceToplology;
		}
		/**
		 * @return the alerts
		 */
		public List<Alerts> getAlerts() {
			return alerts;
		}
		/**
		 * @param alerts the alerts to set
		 */
		public void setAlerts(List<Alerts> alerts) {
			this.alerts = alerts;
		}
	
}
