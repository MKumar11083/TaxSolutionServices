package com.cavium.model.appliance;

public class FirmwareUpgradeDetailModel {
	
	private String hsmFirmwareType;
	private boolean zeroize;
	private FirmwareUpgradeFiles imageFileDeatils;
	private FirmwareUpgradeFiles signFileDeatils;
	public String getHsmFirmwareType() {
		return hsmFirmwareType;
	}
	public void setHsmFirmwareType(String hsmFirmwareType) {
		this.hsmFirmwareType = hsmFirmwareType;
	}
	public boolean isZeroize() {
		return zeroize;
	}
	public void setZeroize(boolean zeroize) {
		this.zeroize = zeroize;
	}
	public FirmwareUpgradeFiles getImageFileDeatils() {
		return imageFileDeatils;
	}
	public void setImageFileDeatils(FirmwareUpgradeFiles imageFileDeatils) {
		this.imageFileDeatils = imageFileDeatils;
	}
	public FirmwareUpgradeFiles getSignFileDeatils() {
		return signFileDeatils;
	}
	public void setSignFileDeatils(FirmwareUpgradeFiles signFileDeatils) {
		this.signFileDeatils = signFileDeatils;
	}
	
	
}
