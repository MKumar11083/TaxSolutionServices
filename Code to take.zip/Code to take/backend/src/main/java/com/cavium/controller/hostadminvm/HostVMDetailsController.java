package com.cavium.controller.hostadminvm;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.hostadminvm.monitorstats.MonitorStats;
import com.cavium.pojo.ApplianceInfo;
import com.cavium.pojo.HSMInfo;
import com.cavium.pojo.PartitionsDetails;
import com.cavium.pojo.hostadminvm.AdminVMConfig;
import com.cavium.pojo.hostadminvm.AdminVMData;
import com.cavium.pojo.hostadminvm.HostStats;
import com.cavium.pojo.hostadminvm.HostSystemInfo;
import com.cavium.service.appliance.ApplianceService;
import com.cavium.service.hostadminvm.HostAdminVMService;
import com.cavium.service.partition.PartitionService;
import com.cavium.utill.CaviumResponseModel;

@RestController
@RequestMapping("rest")
public class HostVMDetailsController {
	
	@Autowired
	private HostAdminVMService hostAdminVMService;
	
	@Lookup
	public CaviumResponseModel getCaviumResponseModel() {
		return null;
	}
	 
	@Autowired
	private ApplianceService applianceService;
	
 
	@Autowired
	private PartitionService partitionService;
 
	@Lookup
	public HostStats getHostStats() {
		return null;
	}
	 
	@Lookup
	public PartitionsDetails getPartitionsDetails() {
		return null;
	}
	
	@Lookup
	public ApplianceInfo getApplianceInfo() {
		return null;
	}
	
	@Lookup
	public HostSystemInfo getHostSystemInfo() {
		return null;
	}
	@Lookup
	public HSMInfo getHSMInfo() {
		return null;
	}
	@Lookup
	public AdminVMConfig getAdminVMConfig() {
		return null;
	}
	
	private Logger logger = Logger.getLogger(this.getClass());
	
	@RequestMapping(value = "hostNetworkVMConfig", method = RequestMethod.POST)
	public final CaviumResponseModel saveHostNetworkData(@RequestBody AdminVMData adminVMData) {
	//	logger.info("Start of createUser method:");
	String applianceIp=adminVMData.getApplianceIp();
	CaviumResponseModel caviumResponseModel=getCaviumResponseModel();
	caviumResponseModel=hostAdminVMService.setHostNetorkVmConfig(applianceIp,adminVMData);
	return caviumResponseModel;
}
	
	@RequestMapping(value = "getHostSystemInfo/{applianceId}", method = RequestMethod.GET)
	public HostSystemInfo getHostSystemInfo(@PathVariable("applianceId") String applianceId){
		logger.info("start of getHostSystemInfo Method");
		ApplianceDetailModel applianceDetailModel = new ApplianceDetailModel() ;
	//	applianceDetailModel.setIpAddress(applianceIPAddress);
		PartitionsDetails  partitionsDetails=getPartitionsDetails();
		String apiName="admin_host_stats";
		HostSystemInfo	hostSystemInfo=getHostSystemInfo();
		try{	 
			applianceDetailModel=applianceService.getApplianceById(applianceId);		 
			partitionsDetails=partitionService.getPartitionInfo(applianceDetailModel,partitionsDetails);		
			HostStats hostStats=hostAdminVMService.GetHostAdminVMStats(applianceDetailModel,getHostStats(),apiName);		
			ApplianceInfo	applianceInfo=applianceService.GetApplianceInfo(applianceDetailModel,getApplianceInfo());
			AdminVMConfig	adminVMConfig=hostAdminVMService.GetAdminVMConfig(applianceDetailModel,getAdminVMConfig());
			HSMInfo	hsmInfo=applianceService.getHSMInfo(applianceDetailModel,getHSMInfo());
			hostSystemInfo.setApplianceInfo(applianceInfo);
			hostSystemInfo.setHostStats(hostStats);
			hostSystemInfo.setPartitionsDetails(partitionsDetails);
			hostSystemInfo.setHsmInfo(hsmInfo);
			hostSystemInfo.setAdminVMConfig(adminVMConfig);	
			hostSystemInfo.setApplianceDetailModel(applianceDetailModel);
			logger.info("end of getHostSystemInfo Method");
		}catch(Exception exp){
			logger.error("error while HostSystemInfo ::"+exp.getMessage());
		}
		return hostSystemInfo;
	}
	
/*	@RequestMapping(value = "hostMonitorStats", method = RequestMethod.POST)
	public final CaviumResponseModel hostMonitorStats(@RequestBody ApplianceDetailModel applianceDetailModel) {
		CaviumResponseModel responseModel=getCaviumResponseModel();
		try {
			if(applianceDetailModel!=null) {
				responseModel=hostAdminVMService.hostMonitorStats(applianceDetailModel);
			}
		} catch (Exception e) {
			logger.error("error while hostMonitorStats ::"+e.getMessage());
		}
		return responseModel;
	}*/
	
	@RequestMapping(value = "hostMonitorStats", method = RequestMethod.POST)
	public final List<MonitorStats> getHostMonitorStats(@RequestBody ApplianceDetailModel applianceDetailModel) {
		List<MonitorStats> monitorStatsList= new ArrayList<MonitorStats>();
		try {
			String apiName="host";
			monitorStatsList=hostAdminVMService.getMonitorStats(applianceDetailModel.getIpAddress(), apiName);
			
			for (Iterator<MonitorStats> iterator = monitorStatsList.iterator(); iterator.hasNext();) {
				MonitorStats monitorStats = (MonitorStats) iterator.next();
				monitorStats.setUsageInfo(monitorStats.getData().getCpu().getUsageInfo());
				monitorStats.setInfo(monitorStats.getData().getPcpu().getInfo());
				monitorStats.setListCpus(monitorStats.getData().getPcpu().getListCpus());
				monitorStats.setDetails(monitorStats.getData().getMemory().getDetails());
				monitorStats.setUsage(monitorStats.getData().getMemory().getUsage());
				monitorStats.setData(null);
		  }
			}
		 catch (Exception e) {
			 logger.error("error while getHostMonitorStats ::"+e.getMessage());
		}
		return monitorStatsList;
	}
}
