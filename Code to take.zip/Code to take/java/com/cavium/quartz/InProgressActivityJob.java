package com.cavium.quartz;

import java.util.List;

import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;
import org.springframework.stereotype.Component;

import com.cavium.model.recentactivity.InProgressActivity;
import com.cavium.repository.recentactivity.InProgressActivityRepository;
import com.cavium.utill.RestClient;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class InProgressActivityJob implements Job {
	private Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	private InProgressActivityRepository inProgressActivityRepository;
	@Autowired
	RestClient restClient;
 
	
	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		// TODO Auto-generated method stub
		logger.info("Start InProgressActivityJob");
		List<InProgressActivity> listInp=null;
		ResponseEntity<String> response=null;
		try {
			listInp=inProgressActivityRepository.findAll();
			if(listInp!=null && listInp.size() > 0) {
				for(InProgressActivity in: listInp) {
					if(in.getJobId()!=null && in.getJobId()!=000) {
						 response=restClient.invokeGETMethod("https://"+in.getIpAddress()+"/liquidsa/notification/"+in.getJobId()+"");
						if(response!=null) {
							ObjectMapper mapper = new ObjectMapper();
							JsonNode root = mapper.readTree(response.getBody());
							if(!root.isNull()){
								if(!root.path("status").isNull()) {
									in.setStatus(root.path("status").asText());
								}
							}
						}
					}else {
						if(in.getJobId()!=null && in.getJobId()==000) {
							 response=restClient.invokeGETMethod("https://"+in.getIpAddress()+"/liquidsa/notification");
							 if(response!=null) {
									ObjectMapper mapper = new ObjectMapper();
									JsonNode root = mapper.readTree(response.getBody());
									if(!root.isNull()){
										if(!root.path("status").isNull()) {
											in.setStatus(root.path("status").asText());
										}
									}
								}
						}
					}
				}
			}
			
		} catch (Exception e) {
			logger.error("Error occured duringInProgressActivityJob"+e.getMessage());
			// TODO: handle exception
		}
		logger.info("End InProgressActivityJob");
	}
	
	

}
