package com.cavium.quartz;

/*
 * Created by RK00490847. For MemoryStats Graphs for Appliances
 */

import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;
import org.springframework.scheduling.quartz.SimpleTriggerFactoryBean;
import org.springframework.stereotype.Component;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.repository.appliance.ApplianceRepository;
import com.cavium.service.hostadminvm.HostAdminVMService;
import com.cavium.utill.CaviumResponseModel;


@Component
public class MonitorStatsJob implements Job {
 
	@Autowired
	private HostAdminVMService hostAdminVMService;
	
	
	@Autowired
	private ApplianceRepository applianceRepository;
	
	
	/**
	 * This class is used to set the response attributes for incoming requests
	 */
	@Lookup
	public CaviumResponseModel getCaviumResponseModel() {
		return null;
	}
	
	private Logger logger = Logger.getLogger(this.getClass());
	
    public void execute(JobExecutionContext context) throws JobExecutionException {
    	logger.info("start of MonitorStatsJob Scheduler");
     	
    List<ApplianceDetailModel> applianceDetailModels=	applianceRepository.findAll();
		try {
			
			for (Iterator<ApplianceDetailModel> iterator = applianceDetailModels.iterator(); iterator.hasNext();) {
				ApplianceDetailModel applianceDetailModel = (ApplianceDetailModel) iterator.next();
				if(applianceDetailModel!=null) {
					applianceDetailModel.setOperationUsername("co2");
					applianceDetailModel.setOperationPassword("welcome123");
					synchronized (applianceDetailModel) {
					hostAdminVMService.hostMonitorStats(applianceDetailModel,"host");
					}
					synchronized (applianceDetailModel) {
					hostAdminVMService.hostMonitorStats(applianceDetailModel,"admin");
					}
			 }
			}
		} catch (Exception e) {
			logger.error("error while running scheduler ::"+e.getMessage());
		}	
		logger.info("end of MonitorStatsJob Scheduler");
   //     jobService.executeSampleJob();
    }
    
 
}