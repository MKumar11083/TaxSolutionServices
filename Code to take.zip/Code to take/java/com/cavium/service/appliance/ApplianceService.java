package com.cavium.service.appliance;

import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.appliance.InitializeApplianceDetailModel;
import com.cavium.pojo.ApplianceCityDetail;
import com.cavium.pojo.ApplianceInfo;
import com.cavium.pojo.HSMInfo;
import com.cavium.pojo.hostadminvm.AdminSNMPConfig;
import com.cavium.pojo.hostadminvm.AdminVMConfig;
import com.cavium.pojo.hostadminvm.AdminVMData;
import com.cavium.pojo.hostadminvm.HostStats;
import com.cavium.utill.CaviumResponseModel;
/**
 *  * @author MK00497144
 *  This interface holds all the necessary operations for Appliance Management
 */
public interface ApplianceService {
	
	/**
	 * This method is used to create the appliance
	 * @param loggedInUser
	 * @param applianceDetailModel
	 * @return
	 */
	CaviumResponseModel createAppliance(List<ApplianceDetailModel> applianceDetailModel);
	/**
	 * This method is used to modify the appliance
	 * @param loggedInUser
	 * @param applianceDetailModel
	 * @return
	 */
	CaviumResponseModel modifyAppliance(String loggedInUser, ApplianceDetailModel applianceDetailModel);
	/**
	 * This method is used 
	 * @param userId
	 * @return
	 */
	ApplianceDetailModel deleteAppliance(ApplianceDetailModel applianceDetailModel);

	/**
	 * This method is used get list of appliances
	 * @return
	 */
	List<ApplianceDetailModel> getListOfAppliances();
	
	/**
	 * This method is used to validate the appliance exists or not
	 * @param applianceDetailModel
	 * @return
	 */
	
	ApplianceDetailModel validateAppliance(ApplianceDetailModel applianceDetailModel);
	
	/***
	 * This method is used to get appliance by id.
	 */
	ApplianceDetailModel getApplianceById(String applianceID);
	/**
	 * 
	 * @param loggedInUser
	 * @return
	 */
	List<ApplianceDetailModel> listOfApplianceByGroupId(String loggedInUser);
	/**
	 * This method is used to reboot the appliance
	 * @param applianceDetailModel
	 * @return
	 */
	List<ApplianceDetailModel>  rebootAppliance(List<ApplianceDetailModel>  applianceDetailModel);
	/**
	 * This method is used to zeroize the appliance
	 * @param applianceDetailModel
	 * @return
	 */
	List<ApplianceDetailModel> zeroizeAppliance(List<ApplianceDetailModel> applianceDetailModellist);
	/**
	 * 
	 * @param applianceDetailModel
	 * @return
	 */
	List<ApplianceDetailModel> applianceFirmwareUpgrade(List<ApplianceDetailModel> applianceDetailModellist);
	/**
	 * 
	 * @param applianceDetailModel
	 * @return
	 * @throws Exception 
	 */
	List<ApplianceDetailModel> initilizeAppliance(InitializeApplianceDetailModel initializeApplianceDetailModel) throws RuntimeException;
	
	
	/**
	 * 
	 * @param applianceDetailModel
	 * @return ApplianceInfo
	 */
	ApplianceInfo GetApplianceInfo(ApplianceDetailModel applianceDetailModel,ApplianceInfo applianceInfo);
	
	/**
	 * 
	 * @param applianceDetailModel
	 * @return HSMInfo
	 */
	HSMInfo getHSMInfo(ApplianceDetailModel applianceDetailModel,HSMInfo objHSMInfo) ;
	
	/***
	 * 
	 * @param applianceDetailModel
	 * @return
	 */
	List<ApplianceDetailModel> searchAppliance(ApplianceDetailModel applianceDetailModel);
	
	
	ApplianceDetailModel initilizeApplianceRelationship(ApplianceDetailModel applianceDetailModel, InitializeApplianceDetailModel initializeApplianceDetailModel,Long initializeId,CaviumResponseModel caviumResponseModel) throws RuntimeException;
	/***
	 * This method is used to fecth the temporary applainces 
	 * @return
	 */
	List<ApplianceDetailModel> getListOfTempAppliances();
	

	CaviumResponseModel createApplianceForTesting(List<ApplianceDetailModel> applianceDetailModel);
	
 
	List<ApplianceCityDetail> listAppliancesDetailCityWise(List<ApplianceDetailModel> listApplianceDetailModels);
	
 
		 
}
