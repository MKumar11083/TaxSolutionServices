package com.cavium.service.alerts;



import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.cavium.model.alerts.Alerts;
import com.cavium.model.recentactivity.RecentActivity;
import com.cavium.repository.alerts.AlertsRepository;
import com.cavium.repository.recentactivity.RecentActivityRepository;
import com.cavium.repository.user.UserRepository;

@Component
public class AlertsServiceImpl implements AlertsService {

	@Autowired
	private AlertsRepository alertsRepository;
	@Autowired
	private UserRepository userrepository;
	private Logger logger = Logger.getLogger(this.getClass());
	
	public void createAlert(String loggedInUser, String message) {
		// TODO Auto-generated method stub
		try {
			String roleid=userrepository.getRoleID(loggedInUser);
			List<Alerts> alertList= getAlerts(loggedInUser);
			if(alertList.size() == 10) {
				Alerts alert=alertList.get(9);
				alert.setUserGroupId(roleid);
				alert.setMessage(message);
				alert.setCreatedDate(new Date());
				alertsRepository.save(alert);
			}else {
				if(!StringUtils.isEmpty(roleid)) {
					Alerts alert=new Alerts();
					alert.setUserGroupId(roleid);
					alert.setMessage(message);
					alert.setCreatedDate(new Date());
					alertsRepository.save(alert);
				}
			}
			
		} catch (Exception e) {
			logger.error("Error occured due to db error inside createAlert ::" + e.getMessage());
			// TODO: handle exception
		}
	}

	
	public void createAlert(String loggedInUser, String message,String applianceName,long applianceId) {
		// TODO Auto-generated method stub
		try {
			String roleid=userrepository.getRoleID(loggedInUser);
			List<Alerts> alertList= getAlerts(loggedInUser);
			if(alertList.size() == 10) {
				Alerts alert=alertList.get(9);
				alert.setUserGroupId(roleid);
				alert.setMessage(message);
				alert.setCreatedDate(new Date());
				alert.setApplianceId(applianceId);
				alert.setApplianceName(applianceName);
				alertsRepository.save(alert);
			}else {
				if(!StringUtils.isEmpty(roleid)) {
					Alerts alert=new Alerts();
					alert.setUserGroupId(roleid);
					alert.setMessage(message);
					alert.setCreatedDate(new Date());
					alert.setApplianceId(applianceId);
					alert.setApplianceName(applianceName);
					alertsRepository.save(alert);
				}
			}
			
		} catch (Exception e) {
			logger.error("Error occured due to db error inside createAlert ::" + e.getMessage());
			// TODO: handle exception
		}
	}
	
	@Override
	public List<Alerts> getAlerts(String roleId) {
		// TODO Auto-generated method stub
		List<Alerts> alerts=null;
		try {
			String groupid=userrepository.getRoleID(roleId);
			alerts=alertsRepository.getAlerts(groupid);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured due to db error inside getAlerts ::" + e.getMessage());
		}
		return alerts;
	}
	
	
}
