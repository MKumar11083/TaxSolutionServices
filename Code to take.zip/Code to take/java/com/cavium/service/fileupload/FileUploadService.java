package com.cavium.service.fileupload;



import java.io.File;
import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.appliance.InitializeApplianceDetailModel;
import com.cavium.pojo.ApplianceCityDetail;
import com.cavium.pojo.ApplianceInfo;
import com.cavium.pojo.HSMInfo;
import com.cavium.pojo.hostadminvm.AdminSNMPConfig;
import com.cavium.pojo.hostadminvm.AdminVMConfig;
import com.cavium.pojo.hostadminvm.AdminVMData;
import com.cavium.pojo.hostadminvm.HostStats;
import com.cavium.utill.CaviumResponseModel;
/**
 *  * @author RK00490847
 *  
 */
public interface FileUploadService {
	
	/**
	 * This method is used to create the appliance
	 * @param loggedInUser
	 * @param applianceDetailModel
	 * @return
	 */
	CaviumResponseModel uploadFile(File certificate,String coUsername, String coPassword,String apiName,String ApplianceIp);
	 
		 
}
