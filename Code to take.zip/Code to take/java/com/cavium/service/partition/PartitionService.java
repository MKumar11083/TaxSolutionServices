package com.cavium.service.partition;

import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.partition.PartitionDetailModel;
import com.cavium.model.partition.PartitionInformationModel;
import com.cavium.pojo.PartitionsDetails;
import com.cavium.utill.CaviumResponseModel;

/**
 *  * @author RK00490847
 *  This interface holds all the necessary operations for Partitions
 */
public interface PartitionService {
	
	public PartitionsDetails getPartitionInfo(ApplianceDetailModel applianceDetailModel,PartitionsDetails partitionsDetails);
	
	/***
	 * This method is used to get list of all partitions 
	 * @param loggedInUser
	 * @return
	 */
	public List<PartitionDetailModel> getListOfPartitions(String loggedInUser);
	/***
	 * This method is used to create partitions
	 * @param loggedInUser
	 * @param partitionDetailModels
	 * @return
	 */
	public PartitionDetailModel createPartition(String loggedInUser,PartitionDetailModel partitionDetailModels);
	/***
	 * This method is used to modify Partitions
	 * @param loggedInUser
	 * @param partitionDetailModels
	 * @return
	 */
	public PartitionDetailModel modifyPartition(String loggedInUser,PartitionDetailModel partitionDetailModels);
	/***
	 * This method is used to delete partions
	 * @param loggedInUser
	 * @param partitionDetailModels
	 * @return
	 */
	
	public PartitionDetailModel deletePartition(String loggedInUser,PartitionDetailModel partitionDetailModels);
	/**
	 * 
	 * @param applianceDetailModel
	 * @return
	 */
	public CaviumResponseModel validateInitOperationForCreatePartition(ApplianceDetailModel applianceDetailModel);
	
	public void getPartitionInformationModel(PartitionDetailModel partitionDetailModel);
}
