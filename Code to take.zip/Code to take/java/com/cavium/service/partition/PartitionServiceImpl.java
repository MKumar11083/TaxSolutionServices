package com.cavium.service.partition;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.util.StringUtils;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.appliance.DualFactorAuthDetailModel;
import com.cavium.model.appliance.InitializeApplianceDetailModel;
import com.cavium.model.appliance.InitializeAppliancesRelationshipModel;
import com.cavium.model.appliance.StoreType;
import com.cavium.model.partition.PartitionAdvanceDNSServers;
import com.cavium.model.partition.PartitionAdvanceSearchDomainNames;
import com.cavium.model.partition.PartitionAdvanceStaticHostIps;
import com.cavium.model.partition.PartitionData;
import com.cavium.model.partition.PartitionDetailModel;
import com.cavium.model.partition.PartitionDnsConfig;
import com.cavium.model.partition.PartitionETH;
import com.cavium.model.partition.PartitionInterfaces;
import com.cavium.model.partition.PartitionInterfacesAdvance;
import com.cavium.model.partition.PartitionInterfacesGeneral;
import com.cavium.model.partition.StaticSearchADD;
import com.cavium.model.user.UserDetailModel;
import com.cavium.pojo.PartitionsDetails;
import com.cavium.pojo.UserAttributes;
import com.cavium.repository.appliance.ApplianceRepository;
import com.cavium.repository.appliance.InitializeAppliancesRelationshipReposiotry;
import com.cavium.repository.appliance.InitializeRepository;
import com.cavium.repository.partition.PartitionAdvanceDNSServersRepository;
import com.cavium.repository.partition.PartitionAdvanceSearchDomainNamesRepository;
import com.cavium.repository.partition.PartitionAdvanceStaticHostIpsRepository;
import com.cavium.repository.partition.PartitionCertificateRepository;
import com.cavium.repository.partition.PartitionDataRepository;
import com.cavium.repository.partition.PartitionETHRepository;
import com.cavium.repository.partition.PartitionRepository;
import com.cavium.repository.user.UserRepository;
import com.cavium.service.alerts.AlertsService;
import com.cavium.service.recentactivity.RecentActivityServiceImpl;
import com.cavium.utill.CaviumResponseModel;
import com.cavium.utill.CaviumUtil;
import com.cavium.utill.RestClient;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 *  * @author RK00490847
 *  Class is used as a service implementation for Partitions 
 */
@Component
public class PartitionServiceImpl implements PartitionService {
	private Logger logger = Logger.getLogger(this.getClass());



	/**
	 * This class is used to set the response attributes for incoming requests
	 */
	@Lookup
	public CaviumResponseModel getCaviumResponseModel() {
		return null;
	}

	/**
	 * This Interface is used to get the values from the property file
	 */
	@Autowired
	Environment env;


	/*
	 * getAllAppliancesDetails method is used for fetch All appliances Details.
	 * 
	 * @return listApplianceDetailModel - List of ApplianceDetailModel Object.
	 * 
	 */

	@Autowired
	RestClient restClient;
	@Autowired
	private UserAttributes userAttributes;
	@Autowired
	private PartitionRepository partitionRepository;
	@Autowired
	private PartitionAdvanceDNSServersRepository advanceDNSServersRepository;
	@Autowired
	private PartitionAdvanceSearchDomainNamesRepository advanceSearchDomainNamesRepository;
	@Autowired
	private PartitionAdvanceStaticHostIpsRepository advanceStaticHostIpsRepository;
	@Autowired
	private PartitionCertificateRepository certificateRepository;
	@Autowired
	private PartitionETHRepository partitionETHRepository;
	@Autowired
	private ApplianceRepository applianceRepository;
	@Autowired
	private InitializeRepository initializeRepository;
	@Autowired
	private InitializeAppliancesRelationshipReposiotry initializeAppliancesRelationshipReposiotry;
	@Autowired
	private RecentActivityServiceImpl recentActivityServiceImpl;
	@Autowired
	private AlertsService alertsService;
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private PartitionDataRepository partitionDataRepository;
	
	

	/***
	 * This method is used to validate the appliance whether exists or not
	 */
	@Override
	public PartitionsDetails getPartitionInfo(ApplianceDetailModel applianceDetailModel, PartitionsDetails partitionsDetails) {
		// TODO Auto-generated method stub
		try {
			// for testing purpose use this IP ::10.89.7.150
			//	ResponseEntity<String> response=restClient.invokeGETMethod("https://"+"10.89.7.150"+"/liquidsa/partitions");
			ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/partitions");
			if(response!=null && response.getStatusCode().name().equals("OK")) {
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());

					
					if(!root.isNull()){
						// read Status attribute from response
						//	JsonNode name = root.path("status");
						//read errors from response
						JsonNode errors = root.path("errors");
						if(!errors.isNull()){
							 Iterator<JsonNode> itr = errors.elements();					         
					            while (itr.hasNext()) {
					                JsonNode temp = itr.next();
					                System.out.println(temp.asInt());        
					            }
						}						
						JsonNode dataNode = root.path("data");
						if(!dataNode.isNull()){
							if(dataNode.has("totalKeys")) {
								int totalKeys = dataNode.path("totalKeys").asInt();
								partitionsDetails.setTotalKeys(partitionsDetails.getTotalKeys()+totalKeys);
							}
							if(dataNode.has("occupiedKeys")){
								int occupiedKeys = dataNode.path("occupiedKeys").asInt();
								partitionsDetails.setOccupiedKeys(partitionsDetails.getOccupiedKeys()+occupiedKeys);
							}
							if(dataNode.has("totalAcclrDev")) {
								int totalAcclrDev = dataNode.path("totalAcclrDev").asInt();
								partitionsDetails.setTotalAcclrDev(partitionsDetails.getTotalAcclrDev()+ totalAcclrDev);
							}
							if(dataNode.has("occupiedAcclrDev")) {
								int occupiedAcclrDev = dataNode.path("occupiedAcclrDev").asInt();
								partitionsDetails.setOccupiedAcclrDev(partitionsDetails.getOccupiedAcclrDev()+ occupiedAcclrDev);
							}
							if(dataNode.has("totalContexts")){
								int totalContexts = dataNode.path("totalContexts").asInt();
								partitionsDetails.setTotalContexts(partitionsDetails.getTotalContexts()+totalContexts);
							}
							if(dataNode.has("occupiedContexts")){
								int occupiedContexts = dataNode.path("occupiedContexts").asInt();
								partitionsDetails.setOccupiedContexts(partitionsDetails.getOccupiedContexts()+ occupiedContexts);
							}					 
						}
						// read header Data
						//response.getHeaders().get("Server");
					} 
				}
			}
		} catch (Exception e) {
			logger.error("Error occured during fetch  resource usag into getPartitionInfo of class PartitionServiceImpl ::" + e.getMessage());		 
		}
		return partitionsDetails;
	}

	@Override
	@Transactional
	public PartitionDetailModel createPartition(String loggedInUser,PartitionDetailModel partitionDetailModels) {
		// TODO Auto-generated method stub
			
		try {
			 
			if(partitionDetailModels!=null && partitionDetailModels.getApplianceDetailModel()!=null && partitionDetailModels.getApplianceDetailModel().getIpAddress()!=null) {
				ResponseEntity<String> response=createPartitionViaCaviumExtenalAPI(partitionDetailModels);
				if(response!=null && response.getBody()!=null)
				{
					ObjectMapper mapper = new ObjectMapper();
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						JsonNode errors = root.path("errors");
						if(!errors.isNull() && errors.size() > 0){
							String encodeMessage = root.path("message").asText();
							    partitionDetailModels.setCode("409");
								partitionDetailModels.setMessage(CaviumUtil.decodeMessageBase64(encodeMessage));
							}
						
							if(response!=null && response.getBody()!=null && response.getBody().contains("success")) { 
								/**
								 * Saving partition
								 */
								partitionDetailModels.setCreatedBy(loggedInUser);
								partitionDetailModels.setCreatedDate(new Date());
								try {
									ApplianceDetailModel applianceDetailModel=applianceRepository.getApplianceById(partitionDetailModels.getApplianceDetailModel().getApplianceId(), StoreType.PERMANENT);
									partitionDetailModels.setApplianceDetailModel(applianceDetailModel);
									partitionDetailModels.setStatus("In-Progress");
									partitionRepository.save(partitionDetailModels);
									if(partitionDetailModels!=null && partitionDetailModels.getPartitionId() > 0) {
										/**
										 * Saving ETH0 and ETH1	
										 */
										 PartitionETH eth0=partitionDetailModels.getNetworkStats().getGeneral().getEth0();
										 PartitionETH eth1=partitionDetailModels.getNetworkStats().getGeneral().getEth1();
										 eth0.setEthName("eth0");
										 eth1.setEthName("eth1");
										 eth0.setPartitionDetailModel(partitionDetailModels);
										 eth1.setPartitionDetailModel(partitionDetailModels);
										 partitionETHRepository.save(eth0);
										 partitionETHRepository.save(eth1);
										 
										 								 
										 /**
										  * Save partition_inetrface_advance_static_host_ip
										  */
										 List<PartitionAdvanceStaticHostIps> StaticHostIps=partitionDetailModels.getNetworkStats().getAdvanced().getStaticIpToHostConfig().getAdd();
										 if(StaticHostIps!=null && StaticHostIps.size() > 0) {
											 for(PartitionAdvanceStaticHostIps ips : StaticHostIps) {
												 ips.setPartitionDetailModel(partitionDetailModels);
											 }
											 advanceStaticHostIpsRepository.save(StaticHostIps);
										 }
										 
										 /**
										  * Save partition_inetrface_advance_dns_servers
										  */
										 String[] dnsServers=partitionDetailModels.getNetworkStats().getAdvanced().getDnsConfig().getDnsServers();
										 if(dnsServers!=null && dnsServers.length > 0) {
											 List<PartitionAdvanceDNSServers> listDNSServers=new ArrayList<PartitionAdvanceDNSServers>();
											 for(String dns : dnsServers) {
												 PartitionAdvanceDNSServers dnsser=new PartitionAdvanceDNSServers();
												 dnsser.setDnsAddress(dns);
												 dnsser.setPartitionDetailModel(partitionDetailModels);
												 listDNSServers.add(dnsser);
											 }
											 advanceDNSServersRepository.save(listDNSServers);
										 }
										 
										 
										 /**
										  * Save partition_inetrface_advance_serach_domain_names
										  */
										 String[] domainNames= partitionDetailModels.getNetworkStats().getAdvanced().getDnsConfig().getSearchDomainNames();
										 if(domainNames!=null && domainNames.length > 0) {
											 List<PartitionAdvanceSearchDomainNames> listSerachDomains=new ArrayList<PartitionAdvanceSearchDomainNames>();;
											 for(String domainName : domainNames) {
												 PartitionAdvanceSearchDomainNames domain=new PartitionAdvanceSearchDomainNames();
												 domain.setDomainNames(domainName);
												 domain.setPartitionDetailModel(partitionDetailModels);
												 listSerachDomains.add(domain);
											 }
											 advanceSearchDomainNamesRepository.save(listSerachDomains);
										 }
										
										}
									partitionDetailModels.setMessage("success");
									partitionDetailModels.setCode("200");
									getPartitionInformationModel(partitionDetailModels);
									recentActivityServiceImpl.createRecentActivity(loggedInUser, "Partition "+partitionDetailModels.getPartitionName()+" created for applaince "+partitionDetailModels.getApplianceDetailModel().getApplianceName()+" "+loggedInUser);
								} catch (Exception e) {
									partitionDetailModels.setCode("408");
									partitionDetailModels.setMessage(env.getProperty("partition.dberror"));
									// TODO: handle exception
								}
							}
							else {
								if(response!=null && response.getBody()!=null && response.getBody().contains("busy")) {
									String operation = root.path("operation").asText();
									partitionDetailModels.setCode("409");
									partitionDetailModels.setMessage("Appliance is busy due to operation "+operation+" is being performed");
									alertsService.createAlert(loggedInUser,"Device "+partitionDetailModels.getApplianceDetailModel().getApplianceName()+"  try to perofrm create partition by "+loggedInUser+" doesnot create partition due to operation "+operation+" is already in progress.");
								}
							}if(response!=null && response.getBody()!=null && response.getBody().contains("bad credentials")) {
								partitionDetailModels.setCode("409");
								partitionDetailModels.setMessage(env.getProperty("partition.badcredentials.cavium"));
								alertsService.createAlert(loggedInUser,"Device "+partitionDetailModels.getApplianceDetailModel().getApplianceName()+"  try to perofrm create partition by "+loggedInUser+" doesnot create partition due to invalid credentials.");
							}if(response!=null && response.getStatusCodeValue()== 408){
								partitionDetailModels.setCode("408");
								partitionDetailModels.setMessage(env.getProperty("partition.connectionerror.cavium"));
								alertsService.createAlert(loggedInUser,"Device "+partitionDetailModels.getApplianceDetailModel().getApplianceName()+"  try to perofrm create partition by "+loggedInUser+" doesnot create partition due to connection issue.");
							}if(response!=null && response.getBody()!=null && response.getBody().contains("11008")) {
								partitionDetailModels.setCode("409");
								partitionDetailModels.setMessage(env.getProperty("partition.badcredentials.cavium"));
								alertsService.createAlert(loggedInUser,"Device "+partitionDetailModels.getApplianceDetailModel().getApplianceName()+"  try to perofrm create partition by "+loggedInUser+" doesnot create partition due to invalid credentials.");
							}if(response!=null && response.getStatusCodeValue() == 404) {
								partitionDetailModels.setCode("404");
								partitionDetailModels.setMessage(env.getProperty("partition.notexists.cavium.network"));
							}
						}

					}
				if(response!=null && response.getStatusCodeValue()== 408){
					partitionDetailModels.setCode("408");
					partitionDetailModels.setMessage(env.getProperty("partition.connectionerror.cavium"));
					alertsService.createAlert(loggedInUser,"Device "+partitionDetailModels.getApplianceDetailModel().getApplianceName()+"  try to perofrm create partition by "+loggedInUser+" doesnot create partition due to connection issue.");
				}
				
				if(response==null) {
					partitionDetailModels.setCode("409");
					partitionDetailModels.setMessage(env.getProperty("partition.applainceinternalerror.cavium"));
					alertsService.createAlert(loggedInUser,"Device "+partitionDetailModels.getApplianceDetailModel().getApplianceName()+"  try to perofrm create partition by "+loggedInUser+" doesnot create partition due to appliance internal error");
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error(e.getMessage());
		}
		
		return partitionDetailModels;
	}


	@Override
	public PartitionDetailModel modifyPartition(String loggedInUser,PartitionDetailModel partitionDetailModels) {
		// TODO Auto-generated method stub
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return partitionDetailModels;
	}


	@Override
	public PartitionDetailModel deletePartition(String loggedInUser,PartitionDetailModel partitionDetailModels) {
		// TODO Auto-generated method stub
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return partitionDetailModels;
	}

	@Override
	public List<PartitionDetailModel> getListOfPartitions(String loggedInUser) {
		// TODO Auto-generated method stub
		List<PartitionDetailModel> listPartitions = null;
		try {
			UserDetailModel objUserDetailModel=userRepository.findOne(loggedInUser);
			if(objUserDetailModel!=null && objUserDetailModel.getObjUserACLDetailsModel().getAclName().equals(env.getProperty("user.superadmin"))) {
				listPartitions = partitionRepository.findAll();
			}else {
				listPartitions = partitionRepository.getListOfApplianceByLoggedInUser(loggedInUser);
			}
			listPartitions=setObjectsInPartitionDetailModel(listPartitions);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return listPartitions;
	}
	
	private ResponseEntity<String> createPartitionViaCaviumExtenalAPI(PartitionDetailModel partitionDetailModels) {
		ResponseEntity<String> response=null;
		try {
			ApplianceDetailModel app=partitionDetailModels.getApplianceDetailModel();
			ApplianceDetailModel dbAppliance=applianceRepository.findOne(app.getApplianceId()); 
			JSONObject jsonObject=new JSONObject(partitionDetailModels);
			jsonObject=removeNullsAndKeysFrom(jsonObject);
			if(dbAppliance!=null) {
				long applianceId=app.getApplianceId();
				InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(applianceId);
				if(initmodel!=null) {
					InitializeApplianceDetailModel initAppDetailModel = initializeRepository.findOne(initmodel.getInitializeId());
					DualFactorAuthDetailModel dualAuthModel=initAppDetailModel.getDualFactorAuthDetailModel();
					if(!StringUtils.isEmpty(partitionDetailModels.getUsername()) && !StringUtils.isEmpty(partitionDetailModels.getPassword())) {
						if(initAppDetailModel.getAuthenticationLevel()==0) {
							jsonObject.put("username", partitionDetailModels.getUsername());
							jsonObject.put("password", partitionDetailModels.getPassword());
						}if(initAppDetailModel.getAuthenticationLevel()==1 && dualAuthModel!=null) {
							jsonObject.put("username", partitionDetailModels.getUsername());
							jsonObject.put("password", partitionDetailModels.getPassword());
							jsonObject.put("dualFactorHostname", dualAuthModel.getDualFactorAuthServerAddress());
							jsonObject.put("dualFactorPort", dualAuthModel.getDualFactorAuthServerPortNo());
							jsonObject.put("dualFactorCertificate", dualAuthModel.getDualFactorAuthServerCertId());
						}
					}else {
						if(initAppDetailModel.getAuthenticationLevel()==0) {
							jsonObject.put("username", initmodel.getOperationPerformUserName());
							jsonObject.put("password", CaviumUtil.decrypt(initmodel.getOperationPerformPassword()));
						}if(initAppDetailModel.getAuthenticationLevel()==1 && dualAuthModel!=null) {
							jsonObject.put("username", initmodel.getOperationPerformUserName());
							jsonObject.put("password", CaviumUtil.decrypt(initmodel.getOperationPerformPassword()));
							jsonObject.put("dualFactorHostname", dualAuthModel.getDualFactorAuthServerAddress());
							jsonObject.put("dualFactorPort", dualAuthModel.getDualFactorAuthServerPortNo());
							jsonObject.put("dualFactorCertificate", dualAuthModel.getDualFactorAuthServerCertId());
						}
					}
					response=restClient.invokePOSTMethodForOperations("https://"+app.getIpAddress()+"/liquidsa/partition",jsonObject);
				}else {
					response=new ResponseEntity<>(HttpStatus.valueOf(env.getProperty("partition.initializenotdone")));
					}
			}else {
				response=new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return response;
	}
	
 private JSONObject removeNullsAndKeysFrom(JSONObject object) throws JSONException {
		 
		try {
			if (object != null) {
				
				Iterator<String> iterator = object.keys();
				while (iterator.hasNext()) {
					String key = iterator.next();
					Object o = object.get(key);
					if(key.equalsIgnoreCase("applianceDetailModel")) {
						iterator.remove(); 
					}if(key.equalsIgnoreCase("partitionInformationModel")) {
						iterator.remove(); 
					}
					if (key.equals("networkStats")) {
						JSONObject general = (JSONObject) o;
						JSONObject gen = (JSONObject) general.get("general");
						/**
						 * Eth0 modification
						 */
						JSONObject eth0 = (JSONObject) gen.get("eth0");
						eth0.remove("id");
						eth0.remove("ethName");
						eth0.remove("disableEth1");
						Map<String, Object> staticmac = new HashMap<>();
						staticmac.put("staticMac", eth0.get("staticMac"));
						boolean  staticMac=(boolean)eth0.get("staticMac");
						if(staticMac==true) {
							staticmac.put("address", eth0.get("address"));
							eth0.remove("staticMac");
							eth0.remove("address");
						}else {
							eth0.remove("staticMac");
							//staticmac.put("address", eth0.get("address"));
						}
						
						eth0.put("mac", staticmac);

						/**
						 * Eth1 modification
						 */

						JSONObject eth1 = (JSONObject) gen.get("eth1");
						eth1.remove("id");
						eth1.remove("ethName");
						eth1.remove("gateway");
						Map<String, Object> staticmaceth1 = new HashMap<>();
						staticmaceth1.put("staticMac", eth1.get("staticMac"));
						boolean  staticMaceth1=(boolean)eth1.get("staticMac");
						if(staticMaceth1==true) {
							staticmaceth1.put("address", eth0.get("address"));
							eth1.remove("staticMac");
							eth1.remove("address");
						}else {
							eth1.remove("staticMac");
							//staticmac.put("address", eth0.get("address"));
						}
					}
					if (o == null || o == JSONObject.NULL) {
						iterator.remove();
					}
				}
				
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		 return object;
	 }
 
    private List<PartitionDetailModel> setObjectsInPartitionDetailModel(List<PartitionDetailModel> listPartitionDetailModel){
    	
    	try {
    		for(PartitionDetailModel pdm: listPartitionDetailModel){
    			/**
    			 * Merging eth into partition detail model
    			 */
    			List<PartitionETH> ethlist=partitionETHRepository.getPartitionETHList(String.valueOf(pdm.getPartitionId()));
    			PartitionInterfaces interfaces=new PartitionInterfaces();
				PartitionInterfacesGeneral general=new PartitionInterfacesGeneral();
    			for(PartitionETH eth:ethlist) {
    				if(!StringUtils.isEmpty(eth.getEthName()) && eth.getEthName().equals("eth0")) {
    					general.setEth0(eth);
    					interfaces.setGeneral(general);
    					pdm.setNetworkStats(interfaces);
    				}if(!StringUtils.isEmpty(eth.getEthName()) && eth.getEthName().equals("eth1")) {
    					general.setEth1(eth);
    					interfaces.setGeneral(general);
    					pdm.setNetworkStats(interfaces);
    				}
    			}
    			
    			/**
    			 * Merging dnsServers into the partition object under advance child object
    			 */
    			
    			List<PartitionAdvanceDNSServers> dnsServers=advanceDNSServersRepository.getDNSServersList(String.valueOf(pdm.getPartitionId()));
    			PartitionInterfacesAdvance advanced=new PartitionInterfacesAdvance();
    			PartitionDnsConfig dnsconfig=new PartitionDnsConfig();
    			String[] dnsarray=new String[dnsServers.size()];
    			int count=0;
    			for(PartitionAdvanceDNSServers dns:dnsServers) {
    				dnsarray[count]=dns.getDnsAddress();
    				count++;
    			}
    			dnsconfig.setDnsServers(dnsarray);
    			
    			
    			/**
    			 * Merging domainNames into partition object  under advance child object
    			 */
    			
    			List<PartitionAdvanceSearchDomainNames> domainNames=advanceSearchDomainNamesRepository.getDomainNamesList(String.valueOf(pdm.getPartitionId()));
    			String[] domainNamesarray=new String[dnsServers.size()];
    			int countt=0;
    			for(PartitionAdvanceSearchDomainNames dn:domainNames) {
    				domainNamesarray[countt]=dn.getDomainNames();
    				countt++;
    			}
    			dnsconfig.setSearchDomainNames(domainNamesarray);
    			advanced.setDnsConfig(dnsconfig);
    			
    			/**
    			 * Merging staticIpHost into partition object  under advance child object
    			 */
    			List<PartitionAdvanceStaticHostIps> staticipHost=advanceStaticHostIpsRepository.getStaticIpHostList(String.valueOf(pdm.getPartitionId()));
    			StaticSearchADD add=new StaticSearchADD();
    			add.setAdd(staticipHost);
    			advanced.setStaticIpToHostConfig(add);
    			interfaces.setAdvanced(advanced);
    			/**
    			 * Merging Appliance Object into partition object
    			 */
    			/*ApplianceDetailModel applianceDetailModel = pdm.getApplianceDetailModel();
    			pdm.setApplianceDetailModel(applianceDetailModel);*/
    			PartitionData data=partitionDataRepository.getPartitionData(String.valueOf(pdm.getPartitionId()));
    			if(data!=null) {
    				Integer keys=data.getMaxKeys()-data.getOccupiedSessionKeys()-data.getOccupiedTokenKeys();
    				data.setKeysUsage(keys);
    				pdm.setPartitionData(data);
    			}
    			
    		}
    		
		} catch (Exception e) {
			// TODO: handle exception
		}
    	
    	return listPartitionDetailModel;
    }

	@Override
	public CaviumResponseModel validateInitOperationForCreatePartition(ApplianceDetailModel applianceDetailModel) {
		// TODO Auto-generated method stub
		CaviumResponseModel response=new CaviumResponseModel();
		try {
			if(applianceDetailModel!=null) {
				long applianceId=applianceDetailModel.getApplianceId();
				InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(applianceId);
				if(initmodel!=null) {
					response.setResponseCode("200");
					response.setResponseMessage("success");
				}else {
					response.setResponseCode("401");
					response.setResponseMessage("failed");
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return response;
	}
	
	@Override
	@Transactional
	public void getPartitionInformationModel(PartitionDetailModel partitionDetailModel) {
		
		logger.info("Asynchronous task started successfully..");
		try {
			new Thread(new Runnable() {
				PartitionData partitionData=new PartitionData();
				ResponseEntity<String> response=null;
				@Override
				public void run() {
					// TODO Auto-generated method stub
					try {
						TimeUnit.MINUTES.sleep(1);
					} catch (InterruptedException e1) {
						// TODO Auto-generated catch block
						logger.error("Error occured during restClient call for partitioninfo"+e1.getMessage());
					}
					if(partitionDetailModel!=null && partitionDetailModel.getApplianceDetailModel().getIpAddress()!=null) {
						try {
							response=restClient.invokeGETMethod("https://"+partitionDetailModel.getApplianceDetailModel().getIpAddress()+"/liquidsa/partition/"+partitionDetailModel.getPartitionName()+"");
						} catch (KeyManagementException e) {
							// TODO Auto-generated catch block
							logger.error("Error occured during restClient call for partitioninfo"+e.getMessage());
						} catch (KeyStoreException e) {
							// TODO Auto-generated catch block
							logger.error("Error occured during restClient call for partitioninfo"+e.getMessage());
						} catch (NoSuchAlgorithmException e) {
							// TODO Auto-generated catch block
							logger.error("Error occured during restClient call for partitioninfo"+e.getMessage());
						}
						JSONObject jsonObject=new JSONObject(response.getBody());
						partitionData=validatePartitionInformationModel(jsonObject);
						 if(partitionData!=null) {
							 partitionData.setPartitionId(Integer.valueOf(String.valueOf(partitionDetailModel.getPartitionId())));
							 partitionDataRepository.save(partitionData);
							 if(partitionDetailModel!=null && partitionDetailModel.getPartitionId()!=0) {
								 PartitionDetailModel pd=partitionRepository.findOne(partitionDetailModel.getPartitionId());
								 pd.setStatus("Completed");
								 partitionRepository.save(pd);
							 }
						 }
					}
					logger.info("Asynchronous task completed successfully..");
				}
			}).start();
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during execution of Asynchronous task for partition");
		}
	}
	
	private PartitionData validatePartitionInformationModel(JSONObject object) {
		PartitionData partitionInformationModel=new PartitionData();
			try {
				if (object != null) {
					Iterator<String> iterator = object.keys();
					while (iterator.hasNext()) {
						String key = iterator.next();
						Object o = object.get(key);
						if (key.equals("data")) {
							JSONObject data = (JSONObject) o;
							//JSONObject partitions = (JSONObject) data.get("partitions");
							data.put("mValueCloning", data.get("mValue[cloning]"));
							data.put("mValueMiscCO", data.get("mValue[miscCO]"));
							data.put("mValueBackupByCO", data.get("mValue[backupByCO]"));
							data.put("mValueUserMgmt", data.get("mValue[userMgmt]"));
							data.put("exportWithUserKeysOtherThanKEK", data.get("exportWithUserKeys(OtherThanKEK)"));
							data.remove("mValue[cloning]");
							data.remove("mValue[miscCO]");
							data.remove("mValue[backupByCO]");
							data.remove("mValue[userMgmt]");
							data.remove("exportWithUserKeys(OtherThanKEK)");
							ObjectMapper objectMapper = new ObjectMapper();
							try {
								partitionInformationModel=objectMapper.readValue(data.toString(),PartitionData.class);
							} catch (Exception e) {
								logger.error("Error occured during"+e.getMessage());
								// TODO: handle exception
							}
						
							return partitionInformationModel;
						}
						if (o == null || o == JSONObject.NULL) {
							iterator.remove();
						}
					}
				}
		} catch (Exception e) {
			logger.error("Error occured during"+e.getMessage());
			// TODO: handle exception
		}
		return partitionInformationModel;
	}
}
