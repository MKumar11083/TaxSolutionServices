package com.cavium.repository.recentactivity;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cavium.model.recentactivity.InProgressActivity;
@Repository
public interface InProgressActivityRepository extends JpaRepository<InProgressActivity, Long>{
	
	@Modifying
	@Query("update InProgressActivity inpa set inpa.status=:status where inpa.createdBy=:createdBy and inpa.jobId=:jobId")
	public InProgressActivity updateInProgressActivity(@Param("status") String status,@Param("createdBy") String createdBy,@Param("jobId") Integer jobId);
	
	@Query("select inpa from InProgressActivity inpa where inpa.createdBy=:createdBy")
	public List<InProgressActivity> getListInProgressActivity(@Param("createdBy") String createdBy);

}
