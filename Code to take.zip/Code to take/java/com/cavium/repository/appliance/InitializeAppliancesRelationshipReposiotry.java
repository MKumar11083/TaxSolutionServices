package com.cavium.repository.appliance;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.appliance.InitializeAppliancesRelationshipModel;

public interface InitializeAppliancesRelationshipReposiotry extends JpaRepository<InitializeAppliancesRelationshipModel, Long>{
	
	@Query("select initmodel from InitializeAppliancesRelationshipModel initmodel where initmodel.applianceDetailModel.applianceId=:applianceId")
	public InitializeAppliancesRelationshipModel getInitializeIdByApplianceId(@Param("applianceId") long applianceId);
 

}
