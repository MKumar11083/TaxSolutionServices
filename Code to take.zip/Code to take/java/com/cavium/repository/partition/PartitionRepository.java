package com.cavium.repository.partition;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cavium.model.partition.PartitionDetailModel;

@Repository
public interface PartitionRepository extends JpaRepository<PartitionDetailModel, Long> {

	@Query(value="select  * from partition_configuration p join appliance_details a on \r\n" + 
			"  a.appliance_id=p.appliance_id where p.created_by=:userName",nativeQuery=true)
	public List<PartitionDetailModel> getListOfApplianceByLoggedInUser(@Param("userName") String userName);
	
	@Modifying
  	@Query("update PartitionDetailModel part set part.status=:status where part.partitionId=:partitionId")
  	public int updateStatus(@Param("status") String status,@Param("partitionId") Long partitionId);
}
