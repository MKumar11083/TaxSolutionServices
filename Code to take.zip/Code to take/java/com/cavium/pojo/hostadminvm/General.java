package com.cavium.pojo.hostadminvm;

public class General
{
    private String subnet;

    private Integer vlan;

    private String macAddress;

    private String ip;

    private Boolean macStatic;

    private String hostname;

    private String type;

    private String gateway;
    
    private Boolean dhcp;

	/**
	 * @return the subnet
	 */
	public String getSubnet() {
		return subnet;
	}

	/**
	 * @param subnet the subnet to set
	 */
	public void setSubnet(String subnet) {
		this.subnet = subnet;
	}

	/**
	 * @return the vlan
	 */
	public Integer getVlan() {
		return vlan;
	}

	/**
	 * @param vlan the vlan to set
	 */
	public void setVlan(Integer vlan) {
		this.vlan = vlan;
	}

	/**
	 * @return the macAddress
	 */
	public String getMacAddress() {
		return macAddress;
	}

	/**
	 * @param macAddress the macAddress to set
	 */
	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}

	/**
	 * @return the ip
	 */
	public String getIp() {
		return ip;
	}

	/**
	 * @param ip the ip to set
	 */
	public void setIp(String ip) {
		this.ip = ip;
	}

	/**
	 * @return the macStatic
	 */
	public Boolean getMacStatic() {
		return macStatic;
	}

	/**
	 * @param macStatic the macStatic to set
	 */
	public void setMacStatic(Boolean macStatic) {
		this.macStatic = macStatic;
	}

	/**
	 * @return the hostname
	 */
	public String getHostname() {
		return hostname;
	}

	/**
	 * @param hostname the hostname to set
	 */
	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the gateway
	 */
	public String getGateway() {
		return gateway;
	}

	/**
	 * @param gateway the gateway to set
	 */
	public void setGateway(String gateway) {
		this.gateway = gateway;
	}

	/**
	 * @return the dhcp
	 */
	public Boolean getDhcp() {
		return dhcp;
	}

	/**
	 * @param dhcp the dhcp to set
	 */
	public void setDhcp(Boolean dhcp) {
		this.dhcp = dhcp;
	}

   
}
