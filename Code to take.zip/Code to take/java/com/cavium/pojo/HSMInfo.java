package com.cavium.pojo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;
@Component
public class HSMInfo {
                private String status;
                private List <String> errors = new ArrayList<String>();
                private String partitionName;
                private int jobId;
                private String startTime;
                private String errorMessage;
                private String endTime;
                private int totalPublicMemory;
                private String mwVersion;
                private String hardwareMinor;
                private String systemVendorId;
                private int cuLoginFailure;
                private int rwSessionCount;
                private int coLoginFailure;
                private int freePrivateMemory;
                private String slaveConfig;
                private String temperature;
                private String firmwareMajor;
                private String label;
                private String subSystemId;
                private String manufacturerId;
                private String masterConfig;
                private int authenticationPath;
                private int classCode;
                private int maxSessionCount;
                private int sessionCount;
                private String firmwareId;
                private int maxRwSessionCount;
                private String buildNumber;
                private String hardwareMajor;
                private int minPswdLen;
                private int maxPswdLen;
                private int totalPrivateMemory;
                private String firmwareMinor;
                private String partNumber;
                private int freePublicMemory;
                private String serialNumber;
                private String fipsState;
                private int hsmFlags;
                private String model;
                private String deviceId;
                private String operation;
                private String firmwareVersion;
                /**
                * @return the status
                */
                public String getStatus() {
                                return status;
                }
                /**
                * @param status the status to set
                */
                public void setStatus(String status) {
                                this.status = status;
                }
                /**
                * @return the errors
                */
                public List<String> getErrors() {
                                return errors;
                }
                /**
                * @param errors the errors to set
                */
                public void setErrors(List<String> errors) {
                                this.errors = errors;
                }
                /**
                * @return the partitionName
                */
                public String getPartitionName() {
                                return partitionName;
                }
                /**
                * @param partitionName the partitionName to set
                */
                public void setPartitionName(String partitionName) {
                                this.partitionName = partitionName;
                }
                /**
                * @return the jobId
                */
                public int getJobId() {
                                return jobId;
                }
                /**
                * @param jobId the jobId to set
                */
                public void setJobId(int jobId) {
                                this.jobId = jobId;
                }
                /**
                * @return the startTime
                */
                public String getStartTime() {
                                return startTime;
                }
                /**
                * @param startTime the startTime to set
                */
                public void setStartTime(String startTime) {
                                this.startTime = startTime;
                }
                /**
                * @return the errorMessage
                */
                public String getErrorMessage() {
                                return errorMessage;
                }
                /**
                * @param errorMessage the errorMessage to set
                */
                public void setErrorMessage(String errorMessage) {
                                this.errorMessage = errorMessage;
                }
                /**
                * @return the endTime
                */
                public String getEndTime() {
                                return endTime;
                }
                /**
                * @param endTime the endTime to set
                */
                public void setEndTime(String endTime) {
                                this.endTime = endTime;
                }
                /**
                * @return the totalPublicMemory
                */
                public int getTotalPublicMemory() {
                                return totalPublicMemory;
                }
                /**
                * @param totalPublicMemory the totalPublicMemory to set
                */
                public void setTotalPublicMemory(int totalPublicMemory) {
                                this.totalPublicMemory = totalPublicMemory;
                }
                /**
                * @return the mwVersion
                */
                public String getMwVersion() {
                                return mwVersion;
                }
                /**
                * @param mwVersion the mwVersion to set
                */
                public void setMwVersion(String mwVersion) {
                                this.mwVersion = mwVersion;
                }
                /**
                * @return the hardwareMinor
                */
                public String getHardwareMinor() {
                                return hardwareMinor;
                }
                /**
                * @param hardwareMinor the hardwareMinor to set
                */
                public void setHardwareMinor(String hardwareMinor) {
                                this.hardwareMinor = hardwareMinor;
                }
                /**
                * @return the systemVendorId
                */
                public String getSystemVendorId() {
                                return systemVendorId;
                }
                /**
                * @param systemVendorId the systemVendorId to set
                */
                public void setSystemVendorId(String systemVendorId) {
                                this.systemVendorId = systemVendorId;
                }
                /**
                * @return the cuLoginFailure
                */
                public int getCuLoginFailure() {
                                return cuLoginFailure;
                }
                /**
                * @param cuLoginFailure the cuLoginFailure to set
                */
                public void setCuLoginFailure(int cuLoginFailure) {
                                this.cuLoginFailure = cuLoginFailure;
                }
                /**
                * @return the rwSessionCount
                */
                public int getRwSessionCount() {
                                return rwSessionCount;
                }
                /**
                * @param rwSessionCount the rwSessionCount to set
                */
                public void setRwSessionCount(int rwSessionCount) {
                                this.rwSessionCount = rwSessionCount;
                }
                /**
                * @return the coLoginFailure
                */
                public int getCoLoginFailure() {
                                return coLoginFailure;
                }
                /**
                * @param coLoginFailure the coLoginFailure to set
                */
                public void setCoLoginFailure(int coLoginFailure) {
                                this.coLoginFailure = coLoginFailure;
                }
                /**
                * @return the freePrivateMemory
                */
                public int getFreePrivateMemory() {
                                return freePrivateMemory;
                }
                /**
                * @param freePrivateMemory the freePrivateMemory to set
                */
                public void setFreePrivateMemory(int freePrivateMemory) {
                                this.freePrivateMemory = freePrivateMemory;
                }
                /**
                * @return the slaveConfig
                */
                public String getSlaveConfig() {
                                return slaveConfig;
                }
                /**
                * @param slaveConfig the slaveConfig to set
                */
                public void setSlaveConfig(String slaveConfig) {
                                this.slaveConfig = slaveConfig;
                }
                /**
                * @return the temperature
                */
                public String getTemperature() {
                                return temperature;
                }
                /**
                * @param temperature the temperature to set
                */
                public void setTemperature(String temperature) {
                                this.temperature = temperature;
                }
                /**
                * @return the firmwareMajor
                */
                public String getFirmwareMajor() {
                                return firmwareMajor;
                }
                /**
                * @param firmwareMajor the firmwareMajor to set
                */
                public void setFirmwareMajor(String firmwareMajor) {
                                this.firmwareMajor = firmwareMajor;
                }
                /**
                * @return the label
                */
                public String getLabel() {
                                return label;
                }
                /**
                * @param label the label to set
                */
                public void setLabel(String label) {
                                this.label = label;
                }
                /**
                * @return the subSystemId
                */
                public String getSubSystemId() {
                                return subSystemId;
                }
                /**
                * @param subSystemId the subSystemId to set
                */
                public void setSubSystemId(String subSystemId) {
                                this.subSystemId = subSystemId;
                }
                /**
                * @return the manufacturerId
                */
                public String getManufacturerId() {
                                return manufacturerId;
                }
                /**
                * @param manufacturerId the manufacturerId to set
                */
                public void setManufacturerId(String manufacturerId) {
                                this.manufacturerId = manufacturerId;
                }
                /**
                * @return the masterConfig
                */
                public String getMasterConfig() {
                                return masterConfig;
                }
                /**
                * @param masterConfig the masterConfig to set
                */
                public void setMasterConfig(String masterConfig) {
                                this.masterConfig = masterConfig;
                }
                /**
                * @return the authenticationPath
                */
                public int getAuthenticationPath() {
                                return authenticationPath;
                }
                /**
                * @param authenticationPath the authenticationPath to set
                */
                public void setAuthenticationPath(int authenticationPath) {
                                this.authenticationPath = authenticationPath;
                }
                /**
                * @return the classCode
                */
                public int getClassCode() {
                                return classCode;
                }
                /**
                * @param classCode the classCode to set
                */
                public void setClassCode(int classCode) {
                                this.classCode = classCode;
                }
                /**
                * @return the maxSessionCount
                */
                public int getMaxSessionCount() {
                                return maxSessionCount;
                }
                /**
                * @param maxSessionCount the maxSessionCount to set
                */
                public void setMaxSessionCount(int maxSessionCount) {
                                this.maxSessionCount = maxSessionCount;
                }
                /**
                * @return the sessionCount
                */
                public int getSessionCount() {
                                return sessionCount;
                }
                /**
                * @param sessionCount the sessionCount to set
                */
                public void setSessionCount(int sessionCount) {
                                this.sessionCount = sessionCount;
                }
                /**
                * @return the firmwareId
                */
                public String getFirmwareId() {
                                return firmwareId;
                }
                /**
                * @param firmwareId the firmwareId to set
                */
                public void setFirmwareId(String firmwareId) {
                                this.firmwareId = firmwareId;
                }
                /**
                * @return the maxRwSessionCount
                */
                public int getMaxRwSessionCount() {
                                return maxRwSessionCount;
                }
                /**
                * @param maxRwSessionCount the maxRwSessionCount to set
                */
                public void setMaxRwSessionCount(int maxRwSessionCount) {
                                this.maxRwSessionCount = maxRwSessionCount;
                }
                /**
                * @return the buildNumber
                */
                public String getBuildNumber() {
                                return buildNumber;
                }
                /**
                * @param buildNumber the buildNumber to set
                */
                public void setBuildNumber(String buildNumber) {
                                this.buildNumber = buildNumber;
                }
                /**
                * @return the hardwareMajor
                */
                public String getHardwareMajor() {
                                return hardwareMajor;
                }
                /**
                * @param hardwareMajor the hardwareMajor to set
                */
                public void setHardwareMajor(String hardwareMajor) {
                                this.hardwareMajor = hardwareMajor;
                }
                /**
                * @return the minPswdLen
                */
                public int getMinPswdLen() {
                                return minPswdLen;
                }
                /**
                * @param minPswdLen the minPswdLen to set
                */
                public void setMinPswdLen(int minPswdLen) {
                                this.minPswdLen = minPswdLen;
                }
                /**
                * @return the maxPswdLen
                */
                public int getMaxPswdLen() {
                                return maxPswdLen;
                }
                /**
                * @param maxPswdLen the maxPswdLen to set
                */
                public void setMaxPswdLen(int maxPswdLen) {
                                this.maxPswdLen = maxPswdLen;
                }
                /**
                * @return the totalPrivateMemory
                */
                public int getTotalPrivateMemory() {
                                return totalPrivateMemory;
                }
                /**
                * @param totalPrivateMemory the totalPrivateMemory to set
                */
                public void setTotalPrivateMemory(int totalPrivateMemory) {
                                this.totalPrivateMemory = totalPrivateMemory;
                }
                /**
                * @return the firmwareMinor
                */
                public String getFirmwareMinor() {
                                return firmwareMinor;
                }
                /**
                * @param firmwareMinor the firmwareMinor to set
                */
                public void setFirmwareMinor(String firmwareMinor) {
                                this.firmwareMinor = firmwareMinor;
                }
                /**
                * @return the partNumber
                */
                public String getPartNumber() {
                                return partNumber;
                }
                /**
                * @param partNumber the partNumber to set
                */
                public void setPartNumber(String partNumber) {
                                this.partNumber = partNumber;
                }
                /**
                * @return the freePublicMemory
                */
                public int getFreePublicMemory() {
                                return freePublicMemory;
                }
                /**
                * @param freePublicMemory the freePublicMemory to set
                */
                public void setFreePublicMemory(int freePublicMemory) {
                                this.freePublicMemory = freePublicMemory;
                }
                /**
                * @return the serialNumber
                */
                public String getSerialNumber() {
                                return serialNumber;
                }
                /**
                * @param serialNumber the serialNumber to set
                */
                public void setSerialNumber(String serialNumber) {
                                this.serialNumber = serialNumber;
                }
                /**
                * @return the fipsState
                */
                public String getFipsState() {
                                return fipsState;
                }
                /**
                * @param fipsState the fipsState to set
                */
                public void setFipsState(String fipsState) {
                                this.fipsState = fipsState;
                }
                /**
                * @return the hsmFlags
                */
                public int getHsmFlags() {
                                return hsmFlags;
                }
                /**
                * @param hsmFlags the hsmFlags to set
                */
                public void setHsmFlags(int hsmFlags) {
                                this.hsmFlags = hsmFlags;
                }
                /**
                * @return the model
                */
                public String getModel() {
                                return model;
                }
                /**
                * @param model the model to set
                */
                public void setModel(String model) {
                                this.model = model;
                }
                /**
                * @return the deviceId
                */
                public String getDeviceId() {
                                return deviceId;
                }
                /**
                * @param deviceId the deviceId to set
                */
                public void setDeviceId(String deviceId) {
                                this.deviceId = deviceId;
                }
                /**
                * @return the operation
                */
                public String getOperation() {
                                return operation;
                }
                /**
                * @param operation the operation to set
                */
                public void setOperation(String operation) {
                                this.operation = operation;
                }
				/**
				 * @return the firmwareVersion
				 */
				public String getFirmwareVersion() {
					return firmwareVersion;
				}
				/**
				 * @param firmwareVersion the firmwareVersion to set
				 */
				public void setFirmwareVersion(String firmwareVersion) {
					this.firmwareVersion = firmwareVersion;
				}
				 
                
}
