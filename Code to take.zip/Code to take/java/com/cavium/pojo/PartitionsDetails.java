package com.cavium.pojo;

import org.springframework.stereotype.Component;

@Component
public class PartitionsDetails {
	
	private int totalAcclrDev;
	private int occupiedAcclrDev;
	private int totalKeys;
	private int occupiedKeys;
	private int totalContexts;
	private int occupiedContexts;	
	private int freeAcclrDev;
	private int freeKeys;
	private int freeContexts;
	/**
	 * @return the totalAcclrDev
	 */
	public int getTotalAcclrDev() {
		return totalAcclrDev;
	}
	/**
	 * @param totalAcclrDev the totalAcclrDev to set
	 */
	public void setTotalAcclrDev(int totalAcclrDev) {
		this.totalAcclrDev = totalAcclrDev;
	}
	/**
	 * @return the occupiedAcclrDev
	 */
	public int getOccupiedAcclrDev() {
		return occupiedAcclrDev;
	}
	/**
	 * @param occupiedAcclrDev the occupiedAcclrDev to set
	 */
	public void setOccupiedAcclrDev(int occupiedAcclrDev) {
		this.occupiedAcclrDev = occupiedAcclrDev;
	}
	/**
	 * @return the totalKeys
	 */
	public int getTotalKeys() {
		return totalKeys;
	}
	/**
	 * @param totalKeys the totalKeys to set
	 */
	public void setTotalKeys(int totalKeys) {
		this.totalKeys = totalKeys;
	}
	/**
	 * @return the occupiedKeys
	 */
	public int getOccupiedKeys() {
		return occupiedKeys;
	}
	/**
	 * @param occupiedKeys the occupiedKeys to set
	 */
	public void setOccupiedKeys(int occupiedKeys) {
		this.occupiedKeys = occupiedKeys;
	}
	/**
	 * @return the totalContexts
	 */
	public int getTotalContexts() {
		return totalContexts;
	}
	/**
	 * @param totalContexts the totalContexts to set
	 */
	public void setTotalContexts(int totalContexts) {
		this.totalContexts = totalContexts;
	}
	/**
	 * @return the occupiedContexts
	 */
	public int getOccupiedContexts() {
		return occupiedContexts;
	}
	/**
	 * @param occupiedContexts the occupiedContexts to set
	 */
	public void setOccupiedContexts(int occupiedContexts) {
		this.occupiedContexts = occupiedContexts;
	}
	/**
	 * @return the freeAcclrDev
	 */
	public int getFreeAcclrDev() {
		return getTotalAcclrDev()-getOccupiedAcclrDev();
	}
	/**
	 * @param freeAcclrDev the freeAcclrDev to set
	 */
	public void setFreeAcclrDev(int freeAcclrDev) {
		this.freeAcclrDev = freeAcclrDev;
	}
	/**
	 * @return the freeKeys
	 */
	public int getFreeKeys() {
		return getTotalKeys()-getOccupiedKeys();
	}
	/**
	 * @param freeKeys the freeKeys to set
	 */
	public void setFreeKeys(int freeKeys) {
		this.freeKeys = freeKeys;
	}
	/**
	 * @return the freeContexts
	 */
	public int getFreeContexts() {
		return getTotalContexts()-getOccupiedContexts();
	}
	/**
	 * @param freeContexts the freeContexts to set
	 */
	public void setFreeContexts(int freeContexts) {
		this.freeContexts = freeContexts;
	}
	 

}
