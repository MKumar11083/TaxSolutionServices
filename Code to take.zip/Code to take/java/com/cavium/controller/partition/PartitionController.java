package com.cavium.controller.partition;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.partition.PartitionDetailModel;
import com.cavium.model.partition.PartitionInformationModel;
import com.cavium.pojo.PartitionsDetails;
import com.cavium.pojo.UserAttributes;
import com.cavium.service.appliance.ApplianceService;
import com.cavium.service.partition.PartitionService;
import com.cavium.utill.CaviumResponseModel;

/*
 * 
 */
@RestController
@RequestMapping("rest")
public class PartitionController {
	
		@Autowired
		private UserAttributes userAttributes;
		
		@Autowired
		private ApplianceService applianceService;
		
		@Autowired
		private PartitionService partitionService;
		
		@Autowired
		PartitionsDetails partitionsDetails;
		
		
		
	private Logger logger = Logger.getLogger(this.getClass());

	@RequestMapping(value = "getPartitionsDetails", method = RequestMethod.GET)
	public PartitionsDetails getPartitionsDetails(){
		logger.info("start of getPartitionsDetails Method");
	 List<ApplianceDetailModel>listApplianceDetailModels= new ArrayList<ApplianceDetailModel>();
	 PartitionsDetails partitionsDetails=null;
		try{	 
			String loggedInUser = userAttributes.getlogInUserName(); 
			listApplianceDetailModels = applianceService.listOfApplianceByGroupId(loggedInUser);
			for (Iterator<ApplianceDetailModel> iterator = listApplianceDetailModels.iterator(); iterator.hasNext();) {
				ApplianceDetailModel applianceDetailModel = (ApplianceDetailModel) iterator.next();
				 partitionsDetails=partitionService.getPartitionInfo(applianceDetailModel,partitionsDetails);			
			}
			
		}catch(Exception exp){

		}
		return partitionsDetails;
	}
	
	@RequestMapping(value = "getListOfPartitions", method = RequestMethod.GET)
	public List<PartitionDetailModel> getListOfPartitions() {
		// TODO Auto-generated method stub
		List<PartitionDetailModel> listPartitions=new ArrayList<PartitionDetailModel>();
		try {
			String loggedInUser = userAttributes.getlogInUserName();
			listPartitions=partitionService.getListOfPartitions(loggedInUser);
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return listPartitions;
	}
	@RequestMapping(value = "createPartitions", method = RequestMethod.POST)
	public PartitionDetailModel createPartition(@RequestBody PartitionDetailModel partitionDetailModels) {
		// TODO Auto-generated method stub
		String loggedInUser = userAttributes.getlogInUserName();
		PartitionDetailModel partition=partitionService.createPartition(loggedInUser, partitionDetailModels);
		try {
		} catch (Exception e) {
			// TODO: handle exception
		}
		return partition;
	}
	@RequestMapping(value = "modifyPartition", method = RequestMethod.PUT)
	public PartitionDetailModel modifyPartition(@RequestBody PartitionDetailModel partitionDetailModels) {
		// TODO Auto-generated method stub
		return null;
	}
	@RequestMapping(value = "deletePartition", method = RequestMethod.DELETE)
	public PartitionDetailModel deletePartition(@RequestBody List<PartitionDetailModel> partitionDetailModels) {
		// TODO Auto-generated method stub
		return null;
	}
	@RequestMapping(value = "validateInitOperationForCreatePartition", method = RequestMethod.POST)
	public CaviumResponseModel validateInitOperationForCreatePartition(@RequestBody ApplianceDetailModel applianceDetailModel) {
		CaviumResponseModel caviumResponse=null;
		// TODO Auto-generated method stub
		try {
			caviumResponse=partitionService.validateInitOperationForCreatePartition(applianceDetailModel);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during validateInitOperationForCreatePartition"+e.getMessage());
		}
		return caviumResponse;
	}
	@RequestMapping(value = "getPartitionInfo", method = RequestMethod.GET)
	public PartitionInformationModel getPartitionInfo(@RequestBody PartitionDetailModel partitionDetailModels) {
		PartitionInformationModel partitionInformationModel=null;
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return partitionInformationModel;
	}
	
}
