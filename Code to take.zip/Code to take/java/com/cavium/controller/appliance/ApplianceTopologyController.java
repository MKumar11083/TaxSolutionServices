package com.cavium.controller.appliance;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.pojo.ApplianceCityDetail;
import com.cavium.pojo.UserAttributes;
import com.cavium.service.appliance.ApplianceService;

/*
 * 
 */
@RestController
@RequestMapping("rest")
public class ApplianceTopologyController {

	@Autowired
	private ApplianceService applianceService;
	@Autowired
	private UserAttributes userAttributes;
	 

	private Logger logger = Logger.getLogger(this.getClass());

	@RequestMapping(value = "getTopologyDetails", method = RequestMethod.GET)
	public List<ApplianceCityDetail>getTopologyDetails(){
		logger.info("start of getTopologyDetails Method");
		List<ApplianceCityDetail> listApplianceToplology=null;
		try{
		
			String loggedInUser = userAttributes.getlogInUserName();
			List<ApplianceDetailModel> listApplianceDetailModels = applianceService.listOfApplianceByGroupId(loggedInUser);	
			listApplianceToplology=applianceService.listAppliancesDetailCityWise(listApplianceDetailModels);
			 logger.info("end of getTopologyDetails Method");
		}catch(Exception exp){
			 logger.error("error in getTopologyDetails Method of class ApplianceTopologyController"+exp.getMessage());
		}
		return listApplianceToplology;
	}
}
