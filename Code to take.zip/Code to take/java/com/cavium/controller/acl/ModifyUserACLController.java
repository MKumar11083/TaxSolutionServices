package com.cavium.controller.acl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.user.ACLRoleModel;
import com.cavium.model.user.ACLWithPermissionDetailsModel;
import com.cavium.model.user.ApplicationDetailModel;
import com.cavium.model.user.UserACLDetailsModel;
import com.cavium.pojo.UserAttributes;
import com.cavium.service.user.UserService;
import com.cavium.utill.CaviumResponseModel;

/*
 * This ModifyUserACLController class is used for modifying the existing ACL in Database.
 *  @author RK00490847
 */
@RestController
@RequestMapping("rest")
public class ModifyUserACLController {
	// logger - instance of application log.
	private Logger logger = Logger.getLogger(this.getClass());

	// userService - Service class provide the interface for the Repository
	// Operation.
	@Autowired
	private UserService userService;

	// userAttributes - get LogIn User Details
	@Autowired
	private UserAttributes userAttributes;

	// get Property Value from Property File
	@Autowired
	private Environment env;

	@Lookup
	public CaviumResponseModel getCaviumResponseModel() {
		return null;
	}

	/*
	 * This getPermissionDetails method will return all the Permissions and
	 * Applications Details.
	 * 
	 * @return - The List of all the Permissions and Applications Details.
	 */

	@RequestMapping(method = RequestMethod.GET, value = "getAcldetail/{aclId}")
	public final ACLWithPermissionDetailsModel getPermissionDetails(@PathVariable("aclId") String aclId) {
		ACLWithPermissionDetailsModel aclWithPermissionDetailsModel = new ACLWithPermissionDetailsModel();
		try {
			UserACLDetailsModel objUserACLDetailsModel = null;
			if (org.apache.commons.lang3.StringUtils.isNotEmpty(aclId)
					&& org.apache.commons.lang.StringUtils.isNumeric(aclId)) {
				objUserACLDetailsModel = userService.getACLDetailById(aclId);
				if (objUserACLDetailsModel != null) {
					List<ApplicationDetailModel> listApplicationDetailModel = userService.getAllPermissions();
					aclWithPermissionDetailsModel.setListApplicationDetailModel(listApplicationDetailModel);
					aclWithPermissionDetailsModel.setObjUserACLDetailsModel(objUserACLDetailsModel);
				}
			}
		} catch (Exception exp) {
			logger.info("Some Error is coming while performing Opeartion:: " + exp.getMessage());
		}
		return aclWithPermissionDetailsModel;
	}

	/*
	 * This editACL method will update the ACL Details and return the success
	 * message or error message .
	 * 
	 * @param RequestBody - userAclDetailsModel from Request
	 * 
	 * @return responseModel - CaviumResponseModel Object
	 */

	@RequestMapping(value = "modifyACL", method = RequestMethod.PUT)
	public final CaviumResponseModel editACL(@RequestBody UserACLDetailsModel userAclDetailsModel) {
		logger.info("Start of editACL Method");
		List<ACLRoleModel> listACLrole = new ArrayList<ACLRoleModel>();
		CaviumResponseModel responseModel=getCaviumResponseModel();
		try {
			if (userAclDetailsModel != null) {
				userAclDetailsModel.setListACLRoleModel(listACLrole);
				userAclDetailsModel.setUsername(userAttributes.getlogInUserName());
				responseModel = userService.modifyACL(userAclDetailsModel);
			} else {
				logger.error("ACL Details Empty");
				responseModel.setResponseCode("204");
				responseModel.setResponseMessage("ACL Details Empty");
			}
		} catch (Exception e) {
			responseModel.setResponseCode("500");
			responseModel.setResponseMessage(env.getProperty("aclModification.failure"));
		}
		logger.info("ResponseModel for Edit ACL :: " + responseModel.toString());
		logger.info("End of editACL Method");
		return responseModel;

	}

}
