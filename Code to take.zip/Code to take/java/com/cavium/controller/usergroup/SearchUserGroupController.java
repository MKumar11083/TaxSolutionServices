package com.cavium.controller.usergroup;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.user.UserDetailModel;
import com.cavium.model.user.UserGroupModel;
import com.cavium.pojo.UserAttributes;
import com.cavium.service.user.UserService;

/*
 * This SearchUserGroupController class is used for searching the Group based on input in request
 *  @author RK00490847
 */	
@RestController
@RequestMapping("rest")
public class SearchUserGroupController {

	// logger - instance of application log.
	private Logger logger = Logger.getLogger(this.getClass());

	// userService - Service class provide the interface for the Repository Operation.
	@Autowired
	private UserService userService;

	// userAttributes - get LogIn User Details
	@Autowired
	private UserAttributes userAttributes;

	/**
	 * This Interface is used to get the values from the property file
	 */
	@Autowired
	Environment env;

	/*
	 * This searchUserGroups method will return the List of Group details. 
	 *  @return	
	 *  - The List of Group Details
	 */
	@RequestMapping(value = "searchUserGroups" ,method = RequestMethod.POST)
	public final  List<UserGroupModel> searchUserGroups(@RequestBody UserGroupModel userGroupModel)
	{
		logger.info("Entered in searchUserGroups Method ::");
		List<UserGroupModel> userGroupData= new ArrayList<UserGroupModel>();

		String superAdmin="%";
		String loggedInUser = userAttributes.getlogInUserName();	
		UserDetailModel	objUserDetailModel=this.userService.getUserDetails(loggedInUser);
		if(objUserDetailModel.getObjUserACLDetailsModel()==null || !env.getProperty("user.superadmin").equals(objUserDetailModel.getObjUserACLDetailsModel().getAclName())) {
			if(objUserDetailModel.getObjUserGroupModel()!=null) {
				userGroupData = userService.getUserGroupData(userGroupModel,loggedInUser);
			}
		}else {
			userGroupData = userService.getUserGroupData(userGroupModel,superAdmin);
		}		 
		logger.info("End of listUserGroups Method ::");
		return userGroupData;	
	}
}
