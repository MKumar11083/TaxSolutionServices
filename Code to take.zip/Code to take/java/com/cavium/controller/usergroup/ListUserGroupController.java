package com.cavium.controller.usergroup;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cavium.model.user.UserDetailModel;
import com.cavium.model.user.UserGroupModel;
import com.cavium.pojo.UserAttributes;
import com.cavium.service.user.UserService;

/*
 * This ListUserGroupController class is used for display the list of all Groups.
 *  @author RK00490847
 */
@RestController
@RequestMapping("rest")
public class ListUserGroupController {

	// logger - instance of application log.
	private Logger logger = Logger.getLogger(this.getClass());

	// userService - Service class provide the interface for the Repository Operation.
	@Autowired
	private UserService userService;

	// userAttributes - get LogIn User Details
	@Autowired
	private UserAttributes userAttributes;

	/**
	 * This Interface is used to get the values from the property file
	 */
	@Autowired
	Environment env;

	/*
	 * This getListUserGroups method will return all the Groups. 	  
	 *  @return	
	 *  		- The List of All Groups
	 */
	@RequestMapping(value = "listUserGroups" ,method = RequestMethod.GET)
	public final  List<UserGroupModel> getListUserGroups()
	{
		logger.info("Entered listUserGroups Method ::");
		List<UserGroupModel> userGroupData= new ArrayList<UserGroupModel>();
		UserGroupModel userGroupModel= new UserGroupModel();
		String superAdmin="%";
		String loggedInUser = userAttributes.getlogInUserName();	
		UserDetailModel	objUserDetailModel=this.userService.getUserDetails(loggedInUser);
		if(objUserDetailModel.getObjUserACLDetailsModel()==null || !env.getProperty("user.superadmin").equals(objUserDetailModel.getObjUserACLDetailsModel().getAclName())) {
			if(objUserDetailModel.getObjUserGroupModel()!=null) {
				userGroupData = userService.getUserGroupData(userGroupModel,loggedInUser);
			}
		}else {
			userGroupData = userService.getUserGroupData(userGroupModel,superAdmin);
		}

		logger.info("End of listUserGroups Method ::");
		return userGroupData;	
	}
}
