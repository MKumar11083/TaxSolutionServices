package com.cavium.controller.recentactivity;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.recentactivity.InProgressActivity;
import com.cavium.pojo.UserAttributes;
import com.cavium.service.recentactivity.InProgressActivityService;

@RestController
@RequestMapping("rest")
public class InProgressActivityController {

	private Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	private UserAttributes userAttributes;
	@Autowired
	private InProgressActivityService inProgressActivityService;

	@RequestMapping(value = "getInProgressActivity", method = RequestMethod.GET)
	public List<InProgressActivity> getInProgressActivity() {
		List<InProgressActivity> inProgressActivity = null;
		String loggedInUser = userAttributes.getlogInUserName();
		try {
			inProgressActivityService.getListOfInProgressActivity(loggedInUser);
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("error occured inside getInProgressActivity" + e.getMessage());
		}
		return inProgressActivity;
	}
}
