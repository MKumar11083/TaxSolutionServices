package com.cavium.model.partition;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Table(name = "partition_client_certificates")
public class PartitionCertificate implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7463359010375590454L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	private Long Id;
	@Column(name="file_name")
	private String fileName;
	@Column(name="uploaded_file_id")
	private String uploadedFileId;
	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name = "partition_id", nullable = false)
	@JsonBackReference
	private PartitionDetailModel partitionDetailModel;
	
	@Transient
	private String fileContent;
	@Transient
	private String fileExtension;
	
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getUploadedFileId() {
		return uploadedFileId;
	}
	public void setUploadedFileId(String uploadedFileId) {
		this.uploadedFileId = uploadedFileId;
	}
	public PartitionDetailModel getPartitionDetailModel() {
		return partitionDetailModel;
	}
	public void setPartitionDetailModel(PartitionDetailModel partitionDetailModel) {
		this.partitionDetailModel = partitionDetailModel;
	}
	public String getFileContent() {
		return fileContent;
	}
	public void setFileContent(String fileContent) {
		this.fileContent = fileContent;
	}
	public String getFileExtension() {
		return fileExtension;
	}
	public void setFileExtension(String fileExtension) {
		this.fileExtension = fileExtension;
	}
}
