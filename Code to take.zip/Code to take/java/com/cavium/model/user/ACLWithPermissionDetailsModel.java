package com.cavium.model.user;

/*
 * ACLWithPermissionDetailsModel class hold the data of ACL Details and its associated Application/Permissions Details
 * author : RK00490847
 */
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

	public class ACLWithPermissionDetailsModel implements Serializable{
	
	private static final long serialVersionUID = 8174981617360416687L;
	
	private List<ApplicationDetailModel> listApplicationDetailModel= new ArrayList<ApplicationDetailModel>();
	
	private	UserACLDetailsModel objUserACLDetailsModel;

	/**
	 * @return the listApplicationDetailModel
	 */
	public List<ApplicationDetailModel> getListApplicationDetailModel() {
		return listApplicationDetailModel;
	}

	/**
	 * @param listApplicationDetailModel the listApplicationDetailModel to set
	 */
	public void setListApplicationDetailModel(List<ApplicationDetailModel> listApplicationDetailModel) {
		this.listApplicationDetailModel = listApplicationDetailModel;
	}

	/**
	 * @return the objUserACLDetailsModel
	 */
	public UserACLDetailsModel getObjUserACLDetailsModel() {
		return objUserACLDetailsModel;
	}

	/**
	 * @param objUserACLDetailsModel the objUserACLDetailsModel to set
	 */
	public void setObjUserACLDetailsModel(UserACLDetailsModel objUserACLDetailsModel) {
		this.objUserACLDetailsModel = objUserACLDetailsModel;
	}	 
	
  

 
	 
}
