package com.cavium.model.hostadminvm.monitorstats;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="monitor_stats_sit_details")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Sit
{
	
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "sit_id", nullable = false)
	private String sitId;
	@Column(name = "incoming")
    private String incoming;
	@Column(name = "stats")
    private String stats;
	@Column(name = "mac_address")
    private String macAddress;
	@Column(name = "outgoing")
    private String outgoing;
	/**
	 * @return the sitId
	 */
	public String getSitId() {
		return sitId;
	}
	/**
	 * @param sitId the sitId to set
	 */
	public void setSitId(String sitId) {
		this.sitId = sitId;
	}
	/**
	 * @return the incoming
	 */
	public String getIncoming() {
		return incoming;
	}
	/**
	 * @param incoming the incoming to set
	 */
	public void setIncoming(String incoming) {
		this.incoming = incoming;
	}
	/**
	 * @return the stats
	 */
	public String getStats() {
		return stats;
	}
	/**
	 * @param stats the stats to set
	 */
	public void setStats(String stats) {
		this.stats = stats;
	}
	/**
	 * @return the macAddress
	 */
	public String getMacAddress() {
		return macAddress;
	}
	/**
	 * @param macAddress the macAddress to set
	 */
	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}
	/**
	 * @return the outgoing
	 */
	public String getOutgoing() {
		return outgoing;
	}
	/**
	 * @param outgoing the outgoing to set
	 */
	public void setOutgoing(String outgoing) {
		this.outgoing = outgoing;
	}    
}
	
