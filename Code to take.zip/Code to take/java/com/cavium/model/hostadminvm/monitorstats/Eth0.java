package com.cavium.model.hostadminvm.monitorstats;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@Entity
@Table(name="monitor_stats_eth0_details")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Eth0
{
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "eth0_id", nullable = false)
	private Long Eth0_Id;
	@Column(name = "incoming")
    private String incoming;
	@Column(name = "mac_broadcast")
    private String macBroadcast;
	@Column(name = "ipv4_netmask")
    private String ipv4Netmask;
	@Column(name = "ipv6_netmask")
    private String ipv6Netmask;
	@Column(name = "stats")
    private String stats;
	@Column(name = "ipv6_address")
    private String ipv6Address;
	@Column(name = "macAddress")
    private String macAddress;
	@Column(name = "ipv4_broadcast")
    private String ipv4Broadcast;
	@Column(name = "outgoing")
    private String outgoing;
	@Column(name = "ipv4_address")
    private String ipv4Address;
	/**
	 * @return the eth0_Id
	 */
	public Long getEth0_Id() {
		return Eth0_Id;
	}
	/**
	 * @param eth0_Id the eth0_Id to set
	 */
	public void setEth0_Id(Long eth0_Id) {
		Eth0_Id = eth0_Id;
	}
	/**
	 * @return the incoming
	 */
	public String getIncoming() {
		return incoming;
	}
	/**
	 * @param incoming the incoming to set
	 */
	public void setIncoming(String incoming) {
		this.incoming = incoming;
	}
	/**
	 * @return the macBroadcast
	 */
	public String getMacBroadcast() {
		return macBroadcast;
	}
	/**
	 * @param macBroadcast the macBroadcast to set
	 */
	public void setMacBroadcast(String macBroadcast) {
		this.macBroadcast = macBroadcast;
	}
	/**
	 * @return the ipv4Netmask
	 */
	public String getIpv4Netmask() {
		return ipv4Netmask;
	}
	/**
	 * @param ipv4Netmask the ipv4Netmask to set
	 */
	public void setIpv4Netmask(String ipv4Netmask) {
		this.ipv4Netmask = ipv4Netmask;
	}
	/**
	 * @return the ipv6Netmask
	 */
	public String getIpv6Netmask() {
		return ipv6Netmask;
	}
	/**
	 * @param ipv6Netmask the ipv6Netmask to set
	 */
	public void setIpv6Netmask(String ipv6Netmask) {
		this.ipv6Netmask = ipv6Netmask;
	}
	/**
	 * @return the stats
	 */
	public String getStats() {
		return stats;
	}
	/**
	 * @param stats the stats to set
	 */
	public void setStats(String stats) {
		this.stats = stats;
	}
	/**
	 * @return the ipv6Address
	 */
	public String getIpv6Address() {
		return ipv6Address;
	}
	/**
	 * @param ipv6Address the ipv6Address to set
	 */
	public void setIpv6Address(String ipv6Address) {
		this.ipv6Address = ipv6Address;
	}
	/**
	 * @return the macAddress
	 */
	public String getMacAddress() {
		return macAddress;
	}
	/**
	 * @param macAddress the macAddress to set
	 */
	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}
	/**
	 * @return the ipv4Broadcast
	 */
	public String getIpv4Broadcast() {
		return ipv4Broadcast;
	}
	/**
	 * @param ipv4Broadcast the ipv4Broadcast to set
	 */
	public void setIpv4Broadcast(String ipv4Broadcast) {
		this.ipv4Broadcast = ipv4Broadcast;
	}
	/**
	 * @return the outgoing
	 */
	public String getOutgoing() {
		return outgoing;
	}
	/**
	 * @param outgoing the outgoing to set
	 */
	public void setOutgoing(String outgoing) {
		this.outgoing = outgoing;
	}
	/**
	 * @return the ipv4Address
	 */
	public String getIpv4Address() {
		return ipv4Address;
	}
	/**
	 * @param ipv4Address the ipv4Address to set
	 */
	public void setIpv4Address(String ipv4Address) {
		this.ipv4Address = ipv4Address;
	}

     
}
