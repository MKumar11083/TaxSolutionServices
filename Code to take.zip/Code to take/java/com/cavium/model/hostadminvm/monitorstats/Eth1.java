package com.cavium.model.hostadminvm.monitorstats;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="monitor_stats_eth1_details")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Eth1
{
 
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "eth1_id", nullable = false)
	private Long Eth1_Id;
	@Column(name = "incoming")
    private String incoming;
	@Column(name = "mac_broadcast")
    private String macBroadcast;
	@Column(name = "stats")
    private String stats;
	@Column(name = "mac_address")
    private String macAddress;
	@Column(name = "outgoing")
    private String outgoing;
	/**
	 * @return the eth1_Id
	 */
	public Long getEth1_Id() {
		return Eth1_Id;
	}
	/**
	 * @param eth1_Id the eth1_Id to set
	 */
	public void setEth1_Id(Long eth1_Id) {
		Eth1_Id = eth1_Id;
	}
	/**
	 * @return the incoming
	 */
	public String getIncoming() {
		return incoming;
	}
	/**
	 * @param incoming the incoming to set
	 */
	public void setIncoming(String incoming) {
		this.incoming = incoming;
	}
	/**
	 * @return the macBroadcast
	 */
	public String getMacBroadcast() {
		return macBroadcast;
	}
	/**
	 * @param macBroadcast the macBroadcast to set
	 */
	public void setMacBroadcast(String macBroadcast) {
		this.macBroadcast = macBroadcast;
	}
	/**
	 * @return the stats
	 */
	public String getStats() {
		return stats;
	}
	/**
	 * @param stats the stats to set
	 */
	public void setStats(String stats) {
		this.stats = stats;
	}
	/**
	 * @return the macAddress
	 */
	public String getMacAddress() {
		return macAddress;
	}
	/**
	 * @param macAddress the macAddress to set
	 */
	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}
	/**
	 * @return the outgoing
	 */
	public String getOutgoing() {
		return outgoing;
	}
	/**
	 * @param outgoing the outgoing to set
	 */
	public void setOutgoing(String outgoing) {
		this.outgoing = outgoing;
	}

}
