package com.cavium.model.hostadminvm.monitorstats;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name="monitor_stats_pcpu_details")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Pcpu
{
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "pcpu_id", nullable = false)
	private Long pcpuId;
	
	@Transient
    private  List<String> cpus;

	@JsonManagedReference
	@OneToMany(fetch = FetchType.LAZY,mappedBy="pcpu", cascade = CascadeType.ALL)
    private List<Info> info;
	
	
	@JsonManagedReference
	@OneToMany(fetch = FetchType.LAZY,mappedBy="pcpu", cascade = CascadeType.ALL)
    private List<Cpus> listCpus = new ArrayList<Cpus>();;


	/**
	 * @return the pcpuId
	 */
	public Long getPcpuId() {
		return pcpuId;
	}


	/**
	 * @param pcpuId the pcpuId to set
	 */
	public void setPcpuId(Long pcpuId) {
		this.pcpuId = pcpuId;
	}


	/**
	 * @return the cpus
	 */
	public List<String> getCpus() {
		return cpus;
	}


	/**
	 * @param cpus the cpus to set
	 */
	public void setCpus(List<String> cpus) {
		this.cpus = cpus;
	}


	/**
	 * @return the info
	 */
	public List<Info> getInfo() {
		return info;
	}


	/**
	 * @param info the info to set
	 */
	public void setInfo(List<Info> info) {
		this.info = info;
	}


	/**
	 * @return the listCpus
	 */
	public List<Cpus> getListCpus() {
		return listCpus;
	}


	/**
	 * @param listCpus the listCpus to set
	 */
	public void setListCpus(List<Cpus> listCpus) {
		this.listCpus = listCpus;
	}

 
	
}
