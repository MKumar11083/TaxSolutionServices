package com.cavium.model.hostadminvm.monitorstats;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="monitor_stats_usage_details")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Usage
{
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "usage_id", nullable = false)
	private Long usage_Id;
	@Column(name = "total")
    private int total;
	@Column(name = "shared")
    private int shared;
	@Column(name = "free")
    private int free;
	@Column(name = "cache")
    private int cache;
	@Column(name = "buffers")
    private int buffers;
	@Column(name = "name")
    private String name;
	@Column(name = "used")
    private int used;
	
	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name = "memory_id", nullable = false)
	@JsonBackReference
	private Memory memory;

	/**
	 * @return the usage_Id
	 */
	public Long getUsage_Id() {
		return usage_Id;
	}

	/**
	 * @param usage_Id the usage_Id to set
	 */
	public void setUsage_Id(Long usage_Id) {
		this.usage_Id = usage_Id;
	}

	/**
	 * @return the total
	 */
	public int getTotal() {
		return total;
	}

	/**
	 * @param total the total to set
	 */
	public void setTotal(int total) {
		this.total = total;
	}

	/**
	 * @return the shared
	 */
	public int getShared() {
		return shared;
	}

	/**
	 * @param shared the shared to set
	 */
	public void setShared(int shared) {
		this.shared = shared;
	}

	/**
	 * @return the free
	 */
	public int getFree() {
		return free;
	}

	/**
	 * @param free the free to set
	 */
	public void setFree(int free) {
		this.free = free;
	}

	/**
	 * @return the cache
	 */
	public int getCache() {
		return cache;
	}

	/**
	 * @param cache the cache to set
	 */
	public void setCache(int cache) {
		this.cache = cache;
	}

	/**
	 * @return the buffers
	 */
	public int getBuffers() {
		return buffers;
	}

	/**
	 * @param buffers the buffers to set
	 */
	public void setBuffers(int buffers) {
		this.buffers = buffers;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the used
	 */
	public int getUsed() {
		return used;
	}

	/**
	 * @param used the used to set
	 */
	public void setUsed(int used) {
		this.used = used;
	}

	/**
	 * @return the memory
	 */
	public Memory getMemory() {
		return memory;
	}

	/**
	 * @param memory the memory to set
	 */
	public void setMemory(Memory memory) {
		this.memory = memory;
	}
 
}
