package com.cavium.model.hostadminvm.monitorstats;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="monitor_stats_lo_details")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Lo
{
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "lo_id", nullable = false)
	private Long Lo_Id;
	@Column(name = "incoming")
    private String incoming;
	@Column(name = "ipv4_netmask")
    private String ipv4Netmask;
	@Column(name = "ipv6_netmask")
    private String ipv6Netmask;
	@Column(name = "stats")
    private String stats;
	@Column(name = "ipv6_address")
    private String ipv6Address;
	@Column(name = "mac_address")
    private String macAddress;
	@Column(name = "outgoing")
    private String outgoing;
	@Column(name = "ipv4_address")
    private String ipv4Address;
	/**
	 * @return the lo_Id
	 */
	public Long getLo_Id() {
		return Lo_Id;
	}
	/**
	 * @param lo_Id the lo_Id to set
	 */
	public void setLo_Id(Long lo_Id) {
		Lo_Id = lo_Id;
	}
	/**
	 * @return the incoming
	 */
	public String getIncoming() {
		return incoming;
	}
	/**
	 * @param incoming the incoming to set
	 */
	public void setIncoming(String incoming) {
		this.incoming = incoming;
	}
	/**
	 * @return the ipv4Netmask
	 */
	public String getIpv4Netmask() {
		return ipv4Netmask;
	}
	/**
	 * @param ipv4Netmask the ipv4Netmask to set
	 */
	public void setIpv4Netmask(String ipv4Netmask) {
		this.ipv4Netmask = ipv4Netmask;
	}
	/**
	 * @return the ipv6Netmask
	 */
	public String getIpv6Netmask() {
		return ipv6Netmask;
	}
	/**
	 * @param ipv6Netmask the ipv6Netmask to set
	 */
	public void setIpv6Netmask(String ipv6Netmask) {
		this.ipv6Netmask = ipv6Netmask;
	}
	/**
	 * @return the stats
	 */
	public String getStats() {
		return stats;
	}
	/**
	 * @param stats the stats to set
	 */
	public void setStats(String stats) {
		this.stats = stats;
	}
	/**
	 * @return the ipv6Address
	 */
	public String getIpv6Address() {
		return ipv6Address;
	}
	/**
	 * @param ipv6Address the ipv6Address to set
	 */
	public void setIpv6Address(String ipv6Address) {
		this.ipv6Address = ipv6Address;
	}
	/**
	 * @return the macAddress
	 */
	public String getMacAddress() {
		return macAddress;
	}
	/**
	 * @param macAddress the macAddress to set
	 */
	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}
	/**
	 * @return the outgoing
	 */
	public String getOutgoing() {
		return outgoing;
	}
	/**
	 * @param outgoing the outgoing to set
	 */
	public void setOutgoing(String outgoing) {
		this.outgoing = outgoing;
	}
	/**
	 * @return the ipv4Address
	 */
	public String getIpv4Address() {
		return ipv4Address;
	}
	/**
	 * @param ipv4Address the ipv4Address to set
	 */
	public void setIpv4Address(String ipv4Address) {
		this.ipv4Address = ipv4Address;
	}
 
 
}
