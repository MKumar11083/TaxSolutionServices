package com.cavium.model.hostadminvm.monitorstats;

import java.util.ArrayList;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="monitor_stats_details")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class MonitorStats {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "monitorstats_id", nullable = false)
	private Long monitorStatsId;
	@Column(name="appliance_ip")
	private String applianceIp;
	@Column(name="hours_minutes")
	private String hoursminutes;
	@Column(name="status")
	private String status;
	@Transient
	ArrayList<Object > errors = new ArrayList < Object > ();
	@Column(name="partition_name")
	private String partitionName = null;
	@Column(name="job_id")
	private String jobId = null;
	@Column(name="start_time")
	private String startTime = null;
	@Transient
	private String message;
	@Column(name="end_time")
	private String endTime = null;
	@OneToOne(cascade=CascadeType.ALL,fetch = FetchType.LAZY)
	 @JoinColumn(name = "data_id",nullable = false)
	private Data Data;
	@Column(name="operation")
	private String operation;
	@Column(name="api_name")
	private String apiName;
	@Column(name = "created_date", columnDefinition = "DATETIME")
	private Date createdDate;


	// Getter Methods 

	public String getStatus() {
		return status;
	}

	public String getPartitionName() {
		return partitionName;
	}

	public String getJobId() {
		return jobId;
	}

	public String getStartTime() {
		return startTime;
	}

	public String getMessage() {
		return message;
	}

	public String getEndTime() {
		return endTime;
	}



	public String getOperation() {
		return operation;
	}

	// Setter Methods 

	public void setStatus(String status) {
		this.status = status;
	}

	public void setPartitionName(String partitionName) {
		this.partitionName = partitionName;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}


	public void setOperation(String operation) {
		this.operation = operation;
	}

	/**
	 * @return the errors
	 */
	public ArrayList<Object> getErrors() {
		return errors;
	}

	/**
	 * @param errors the errors to set
	 */
	public void setErrors(ArrayList<Object> errors) {
		this.errors = errors;
	}

	/**
	 * @return the data
	 */
	public Data getData() {
		return Data;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(Data data) {
		Data = data;
	}


	/**
	 * @return the hoursminutes
	 */
	public String getHoursminutes() {
		return hoursminutes;
	}

	/**
	 * @param hoursminutes the hoursminutes to set
	 */
	public void setHoursminutes(String hoursminutes) {
		this.hoursminutes = hoursminutes;
	}

 

	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the applianceIp
	 */
	public String getApplianceIp() {
		return applianceIp;
	}

	/**
	 * @param applianceIp the applianceIp to set
	 */
	public void setApplianceIp(String applianceIp) {
		this.applianceIp = applianceIp;
	}

	/**
	 * @return the monitorStatsId
	 */
	public Long getMonitorStatsId() {
		return monitorStatsId;
	}

	/**
	 * @param monitorStatsId the monitorStatsId to set
	 */
	public void setMonitorStatsId(Long monitorStatsId) {
		this.monitorStatsId = monitorStatsId;
	}

	/**
	 * @return the apiName
	 */
	public String getApiName() {
		return apiName;
	}

	/**
	 * @param apiName the apiName to set
	 */
	public void setApiName(String apiName) {
		this.apiName = apiName;
	}

 


}