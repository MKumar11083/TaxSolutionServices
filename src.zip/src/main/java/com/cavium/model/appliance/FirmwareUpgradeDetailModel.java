package com.cavium.model.appliance;

import javax.persistence.Transient;

public class FirmwareUpgradeDetailModel {
	
	private String hsmFirmwareType;
	private boolean zeroize;
	private Integer applianceId;
	private String username;
	private String password;
	private Boolean forceReboot;
	private DualFactorUsersRelationshipModel dualFactorDetails;
	
	public String getHsmFirmwareType() {
		return hsmFirmwareType;
	}
	public void setHsmFirmwareType(String hsmFirmwareType) {
		this.hsmFirmwareType = hsmFirmwareType;
	}
	public boolean isZeroize() {
		return zeroize;
	}
	public void setZeroize(boolean zeroize) {
		this.zeroize = zeroize;
	}
	public Integer getApplianceId() {
		return applianceId;
	}
	public void setApplianceId(Integer applianceId) {
		this.applianceId = applianceId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public DualFactorUsersRelationshipModel getDualFactorDetails() {
		return dualFactorDetails;
	}
	public void setDualFactorDetails(DualFactorUsersRelationshipModel dualFactorDetails) {
		this.dualFactorDetails = dualFactorDetails;
	}
	public Boolean getForceReboot() {
		return forceReboot;
	}
	public void setForceReboot(Boolean forceReboot) {
		this.forceReboot = forceReboot;
	}
	
}
