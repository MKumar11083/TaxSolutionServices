package com.cavium.model.recentactivity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "recent_activites")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class RecentActivity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2112532259741278382L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	@Column(name = "user_groupid")
	private String userGroupId;
	@Column(name = "message")
	private String message;
	@Column(name = "created_date", columnDefinition = "DATETIME")
	private Date createdDate;
	@Column(name="module_name")
	private String moduleName;
	@Column(name = "timezone")
	private String timezone;
	@Column(name = "already_read")
	private boolean alreadyRead;
	@Transient
	private boolean moreRecords;
	
	
	public String getUserGroupId() {
		return userGroupId;
	}
	public void setUserGroupId(String userGroupId) {
		this.userGroupId = userGroupId;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy HH:mm:ss")
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	/**
	 * @return the moduleName
	 */
	public String getModuleName() {
		return moduleName;
	}
	/**
	 * @param moduleName the moduleName to set
	 */
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getTimezone() {
		return timezone;
	}
	public void setTimezone(String timezone) {
		this.timezone = timezone;
	}
	/**
	 * @return the alreadyRead
	 */
	public boolean isAlreadyRead() {
		return alreadyRead;
	}
	/**
	 * @param alreadyRead the alreadyRead to set
	 */
	public void setAlreadyRead(boolean alreadyRead) {
		this.alreadyRead = alreadyRead;
	}
	public boolean isMoreRecords() {
		return moreRecords;
	}
	public void setMoreRecords(boolean moreRecords) {
		this.moreRecords = moreRecords;
	}
	
}
