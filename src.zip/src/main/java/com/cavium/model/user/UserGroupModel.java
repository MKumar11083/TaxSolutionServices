package com.cavium.model.user;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

/*
 * UserGroupModel Model class for UserGroup Detail along with Appliances Details
 * author : RK00490847
 */

@Entity
@Table(name = "designation")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class UserGroupModel implements Serializable {

	private static final long serialVersionUID = 7197096310126213034L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(name = "descr", unique = true)
	private String roleName;
	@Column(name = "last_updated", columnDefinition = "DATETIME")
	@Temporal(TemporalType.TIMESTAMP)
	private Date lastUpdated;
	@Column(name = "user_id")
	private String username;
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY

			)
	@JoinColumn(name = "design_id")
	private List<DesignationApplianceModel> listDesignationApplianceModel = new ArrayList<DesignationApplianceModel>();
	@JsonProperty(access = Access.WRITE_ONLY)
	@Transient
	private List<String> listApplianceIds;
	@Transient
	private List<String> defaultGroupApplianceIds;
	
	
	
	 /**
	 * @return the defaultGroupApplianceIds
	 */
	public List<String> getDefaultGroupApplianceIds() {
		return defaultGroupApplianceIds;
	}

	/**
	 * @param defaultGroupApplianceIds the defaultGroupApplianceIds to set
	 */
	public void setDefaultGroupApplianceIds(List<String> defaultGroupApplianceIds) {
		this.defaultGroupApplianceIds = defaultGroupApplianceIds;
	}

	@JsonProperty(access = Access.WRITE_ONLY)
	 @Transient
	 private List<String> deletedUserGroupIds;
	
	@JsonProperty(access = Access.WRITE_ONLY)
	 @Transient
	 private List<String> deletedUserGroupNames;

	/**
	 * @return the deletedUserGroupIds
	 */
	public List<String> getDeletedUserGroupIds() {
		return deletedUserGroupIds;
	}

	/**
	 * @param deletedUserGroupIds the deletedUserGroupIds to set
	 */
	public void setDeletedUserGroupIds(List<String> deletedUserGroupIds) {
		this.deletedUserGroupIds = deletedUserGroupIds;
	}

	public List<String> getListApplianceIds() {
		return listApplianceIds;
	}

	public void setListApplianceIds(List<String> listApplianceIds) {
		this.listApplianceIds = listApplianceIds;
	}

	public List<DesignationApplianceModel> getlistDesignationApplianceModel() {
		return listDesignationApplianceModel;
	}

	public void setListDesignationApplianceModel(List<DesignationApplianceModel> listDesignationApplianceModel) {

		DesignationApplianceModel objDesignationApplianceModel = null;

		if (listApplianceIds != null && !listApplianceIds.isEmpty()) {
			for (int i = 0; i < listApplianceIds.size(); i++) {
				if (org.apache.commons.lang.StringUtils.isNumeric(listApplianceIds.get(i)) && org.apache.commons.lang.StringUtils.isNotEmpty(listApplianceIds.get(i))) {
					objDesignationApplianceModel = new DesignationApplianceModel();
					ApplianceDetailModel objApplianceDetailModel = new ApplianceDetailModel();
					objApplianceDetailModel.setApplianceId(Long.parseLong(listApplianceIds.get(i)));
					objDesignationApplianceModel.setObjApplianceDetailModel(objApplianceDetailModel);
					objDesignationApplianceModel.setDesignationId(id);
					listDesignationApplianceModel.add(objDesignationApplianceModel);
				}
			}
		}
		this.listDesignationApplianceModel = listDesignationApplianceModel;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the lastUpdated
	 */
	public Date getLastUpdated() {
		return lastUpdated;
	}

	/**
	 * @param lastUpdated
	 *            the lastUpdated to set
	 */
	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = new Date();
	}

	/**
	 * This method gets the Role Name.
	 * 
	 * @return the roleName
	 */
	public String getRoleName() {
		return roleName;
	}

	/**
	 * This method sets the Role Name.
	 * 
	 * @param roleName
	 *            - The Role Name
	 */
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * @param username
	 *            the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	public String toString() {
		return "Group id: '" + this.id + "', roleName: '" + this.roleName + "', CreatedBy: '" + this.username
				+ " listApplianceIds : " + this.listApplianceIds;

	}

	/**
	 * @return the deletedUserGroupNames
	 */
	public List<String> getDeletedUserGroupNames() {
		return deletedUserGroupNames;
	}

	/**
	 * @param deletedUserGroupNames the deletedUserGroupNames to set
	 */
	public void setDeletedUserGroupNames(List<String> deletedUserGroupNames) {
		this.deletedUserGroupNames = deletedUserGroupNames;
	}

}
