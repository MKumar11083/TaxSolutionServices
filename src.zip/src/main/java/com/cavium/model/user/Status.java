package com.cavium.model.user;

/*
 * Status Model class for User Status
 * author : RK00490847
 */
 
public enum Status
{
  ACTIVE("ACTIVE"),  SUSPENDED("SUSPENDED");
  
   String value;
  
  private Status(String value)
  {
    this.value = value;
  }
}
