package com.cavium.model.user;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/*
 * ACLRoleModel Model class hold the relationship between ACL and Permissions
 * author : RK00490847
 */
@Entity
@Table(name="acl_role")
public class ACLRoleModel
  implements Serializable
{
  private static final long serialVersionUID = 4692301322760007284L;
  @Id
  @GeneratedValue(strategy=GenerationType.IDENTITY)
  private Long id;
  @Column(name="acl_id")
  private Long aclId;
  @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	@OneToOne(fetch=FetchType.LAZY)
	 @JoinColumn(name = "permission_id",nullable = false)
	 private PermisssionDetailModel objPermisssionDetailModel;
/**
 * @return the id
 */
public Long getId() {
	return id;
}
/**
 * @param id the id to set
 */
public void setId(Long id) {
	this.id = id;
}
/**
 * @return the aclId
 */
public Long getAclId() {
	return aclId;
}
/**
 * @param aclId the aclId to set
 */
public void setAclId(Long aclId) {
	this.aclId = aclId;
}
/**
 * @return the objPermisssionDetailModel
 */
public PermisssionDetailModel getObjPermisssionDetailModel() {
	return objPermisssionDetailModel;
}
/**
 * @param objPermisssionDetailModel the objPermisssionDetailModel to set
 */
public void setObjPermisssionDetailModel(PermisssionDetailModel objPermisssionDetailModel) {
	this.objPermisssionDetailModel = objPermisssionDetailModel;
}  
}
