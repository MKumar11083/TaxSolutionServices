package com.cavium.model.user;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


/*
 * ApplianceDetailsWithGroupModel class hold the data of Group Detail and its associated the list of Appliances Details.
 * author : RK00490847
 */
	public class ApplianceDetailsWithGroupModel implements Serializable{
 
	private static final long serialVersionUID = 4596642984128297449L;
 
	private List<DesignationApplianceModel> listDesignationApplianceModel= new ArrayList<DesignationApplianceModel>();
	private	UserGroupModel objUserGroupModel;	
	 
	/**
	 * @return the listDesignationApplianceModel
	 */
	public List<DesignationApplianceModel> getListDesignationApplianceModel() {
		return listDesignationApplianceModel;
	}
	/**
	 * @param listDesignationApplianceModel the listDesignationApplianceModel to set
	 */
	public void setListDesignationApplianceModel(List<DesignationApplianceModel> listDesignationApplianceModel) {
		this.listDesignationApplianceModel = listDesignationApplianceModel;
	}
	/**
	 * @return the objUserGroupModel
	 */
	public UserGroupModel getObjUserGroupModel() {
		return objUserGroupModel;
	}
	/**
	 * @param objUserGroupModel the objUserGroupModel to set
	 */
	public void setObjUserGroupModel(UserGroupModel objUserGroupModel) {
		this.objUserGroupModel = objUserGroupModel;
	}	 
}
