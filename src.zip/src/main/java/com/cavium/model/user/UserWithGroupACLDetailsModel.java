package com.cavium.model.user;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


/*
 * UserWithGroupACLDetailsModel class holds the data for user Detail along with its associated Groups and ACLs.
 * author : RK00490847
 */
	public class UserWithGroupACLDetailsModel implements Serializable{
	
	private static final long serialVersionUID = -797470603596967201L;
	private List<UserGroupModel> listUserGroupModel= new ArrayList<UserGroupModel>();
	private	List<UserACLDetailsModel> listUserACLDetailsModel= new ArrayList<UserACLDetailsModel>();
	private UserDetailModel userDetailModel;
	 
	/**
	 * @return the userDetailModel
	 */
	public UserDetailModel getUserDetailModel() {
		return userDetailModel;
	}
	/**
	 * @param userDetailModel the userDetailModel to set
	 */
	public void setUserDetailModel(UserDetailModel userDetailModel) {
		this.userDetailModel = userDetailModel;
	}
	/**
	 * @return the listUserGroupModel
	 */
	public List<UserGroupModel> getListUserGroupModel() {
		return listUserGroupModel;
	}
	/**
	 * @param listUserGroupModel the listUserGroupModel to set
	 */
	public void setListUserGroupModel(List<UserGroupModel> listUserGroupModel) {
		this.listUserGroupModel = listUserGroupModel;
	}
	/**
	 * @return the listUserACLDetailsModel
	 */
	public List<UserACLDetailsModel> getListUserACLDetailsModel() {
		return listUserACLDetailsModel;
	}
	/**
	 * @param listUserACLDetailsModel the listUserACLDetailsModel to set
	 */
	public void setListUserACLDetailsModel(List<UserACLDetailsModel> listUserACLDetailsModel) {
		this.listUserACLDetailsModel = listUserACLDetailsModel;
	} 
}
