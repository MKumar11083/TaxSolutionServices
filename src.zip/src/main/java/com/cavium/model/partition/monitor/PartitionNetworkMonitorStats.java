package com.cavium.model.partition.monitor;

import java.io.Serializable;

public class PartitionNetworkMonitorStats implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3424503315815866849L;
	
	private String interfacename;

	public String getInterfacename() {
		return interfacename;
	}

	public void setInterfacename(String interfacename) {
		this.interfacename = interfacename;
	}
	
	

}
