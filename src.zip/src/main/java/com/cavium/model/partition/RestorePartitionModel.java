package com.cavium.model.partition;

import java.io.Serializable;
import java.util.List;

import com.cavium.model.appliance.ApplianceDetailModel;

public class RestorePartitionModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3790353132099062344L;

	private PartitionCertificates file;
	private ApplianceDetailModel backupFromPartition;
	private List<PartitionDetailModel> partitionList;
	public PartitionCertificates getFile() {
		return file;
	}
	public void setFile(PartitionCertificates file) {
		this.file = file;
	}
	public ApplianceDetailModel getBackupFromPartition() {
		return backupFromPartition;
	}
	public void setBackupFromPartition(ApplianceDetailModel backupFromPartition) {
		this.backupFromPartition = backupFromPartition;
	}
	public List<PartitionDetailModel> getPartitionList() {
		return partitionList;
	}
	public void setPartitionList(List<PartitionDetailModel> partitionList) {
		this.partitionList = partitionList;
	}
}
