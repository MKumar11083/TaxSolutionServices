package com.cavium.model.partition;

import java.io.Serializable;


public class PartitionCertificates implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7463359010375590454L;
	
	
	private byte[] fileContent;
	private String fileName;
	private String fileExtension;
	

	public byte[] getFileContent() {
		return fileContent;
	}
	public void setFileContent(byte[] fileContent) {
		this.fileContent = fileContent;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFileExtension() {
		return fileExtension;
	}
	public void setFileExtension(String fileExtension) {
		this.fileExtension = fileExtension;
	}
}
