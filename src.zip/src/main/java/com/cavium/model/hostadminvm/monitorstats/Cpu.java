package com.cavium.model.hostadminvm.monitorstats;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name="monitor_stats_cpu_details")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Cpu
{
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "cpu_id", nullable = false)
	private Long cpuId;
	
	@JsonManagedReference
	@OneToMany(fetch = FetchType.LAZY,mappedBy="cpu", cascade = CascadeType.ALL)
    private List<UsageInfo> usageInfo;

	@Column(name = "total_usage_detail")
    private String totalUsage;
	
	@Column(name = "updated_time")
    private String updatedTime;

	/**
	 * @return the cpuId
	 */
	public Long getCpuId() {
		return cpuId;
	}

	/**
	 * @param cpuId the cpuId to set
	 */
	public void setCpuId(Long cpuId) {
		this.cpuId = cpuId;
	}

	/**
	 * @return the usageInfo
	 */
	public List<UsageInfo> getUsageInfo() {
		return usageInfo;
	}

	/**
	 * @param usageInfo the usageInfo to set
	 */
	public void setUsageInfo(List<UsageInfo> usageInfo) {
		this.usageInfo = usageInfo;
	}

	/**
	 * @return the totalUsage
	 */
	public String getTotalUsage() {
		return totalUsage;
	}

	/**
	 * @param totalUsage the totalUsage to set
	 */
	public void setTotalUsage(String totalUsage) {
		this.totalUsage = totalUsage;
	}

	/**
	 * @return the updatedTime
	 */
	public String getUpdatedTime() {
		return updatedTime;
	}

	/**
	 * @param updatedTime the updatedTime to set
	 */
	public void setUpdatedTime(String updatedTime) {
		this.updatedTime = updatedTime;
	}

   
}