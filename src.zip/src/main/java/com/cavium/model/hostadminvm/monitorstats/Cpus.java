package com.cavium.model.hostadminvm.monitorstats;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="monitor_stats_cpus_details")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Cpus {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "cpus_id", nullable = false)
	private String cpusId;


	@Column(name = "cpu_name")
	private String CpuName;
	
	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name = "pcpu_id", nullable = false)
	@JsonBackReference
	private Pcpu  pcpu;

	/**
	 * @return the cpusId
	 */
	public String getCpusId() {
		return cpusId;
	}

	/**
	 * @param cpusId the cpusId to set
	 */
	public void setCpusId(String cpusId) {
		this.cpusId = cpusId;
	}

	/**
	 * @return the cpuName
	 */
	public String getCpuName() {
		return CpuName;
	}

	/**
	 * @param cpuName the cpuName to set
	 */
	public void setCpuName(String cpuName) {
		CpuName = cpuName;
	}

	/**
	 * @return the pcpu
	 */
	public Pcpu getPcpu() {
		return pcpu;
	}

	/**
	 * @param pcpu the pcpu to set
	 */
	public void setPcpu(Pcpu pcpu) {
		this.pcpu = pcpu;
	}
}
