package com.cavium.rest.model.filedownload;

import java.io.Serializable;

public class FileDownloadDetail implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -9171519735711391417L;
	
	private String downloadedUrlAddr;
	private String applianceIp;
	 
	 
	/**
	 * @return the downloadedUrlAddr
	 */
	public String getDownloadedUrlAddr() {
		return downloadedUrlAddr;
	}
	/**
	 * @param downloadedUrlAddr the downloadedUrlAddr to set
	 */
	public void setDownloadedUrlAddr(String downloadedUrlAddr) {
		this.downloadedUrlAddr = downloadedUrlAddr;
	}
	/**
	 * @return the applianceIp
	 */
	public String getApplianceIp() {
		return applianceIp;
	}
	/**
	 * @param applianceIp the applianceIp to set
	 */
	public void setApplianceIp(String applianceIp) {
		this.applianceIp = applianceIp;
	}
	 
	
}
