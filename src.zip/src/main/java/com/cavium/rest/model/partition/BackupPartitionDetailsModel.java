package com.cavium.rest.model.partition;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.appliance.DualFactorUsersRelationshipModel;

public class BackupPartitionDetailsModel {
	private Boolean nokey;
	private String userName;
	private String password;
	private Long  partitionId;
	private DualFactorUsersRelationshipModel dualFactorDetails;
	private ApplianceDetailModel applianceDetails;
	/**
	 * @return the nokey
	 */
	public Boolean getNokey() {
		return nokey;
	}
	/**
	 * @param nokey the nokey to set
	 */
	public void setNokey(Boolean nokey) {
		this.nokey = nokey;
	}
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * @return the partitionId
	 */
	public Long getPartitionId() {
		return partitionId;
	}
	/**
	 * @param partitionId the partitionId to set
	 */
	public void setPartitionId(Long partitionId) {
		this.partitionId = partitionId;
	}
	/**
	 * @return the dualFactorDetails
	 */
	public DualFactorUsersRelationshipModel getDualFactorDetails() {
		return dualFactorDetails;
	}
	/**
	 * @param dualFactorDetails the dualFactorDetails to set
	 */
	public void setDualFactorDetails(DualFactorUsersRelationshipModel dualFactorDetails) {
		this.dualFactorDetails = dualFactorDetails;
	}
	/**
	 * @return the applianceDetails
	 */
	public ApplianceDetailModel getApplianceDetails() {
		return applianceDetails;
	}
	/**
	 * @param applianceDetails the applianceDetails to set
	 */
	public void setApplianceDetails(ApplianceDetailModel applianceDetails) {
		this.applianceDetails = applianceDetails;
	}	 
}
