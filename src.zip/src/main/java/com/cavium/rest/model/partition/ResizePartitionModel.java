package com.cavium.rest.model.partition;

import java.io.Serializable;

public class ResizePartitionModel implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1536187921651480684L;
	private Integer allocatedUserKeys; 
	private Integer allocatedSSLContexts;
	private Integer allocatedAccelDevices;
	private Integer modifiedUserKeys;
	private Integer modifiedSSLContexts;
	private Integer modifiedAccelDevices;
	private Boolean incrementKeys;
	private Boolean incrementSslContexts;
	private Boolean incrementAcclrDev;
	 
	/**
	 * @return the incrementKeys
	 */
	public Boolean getIncrementKeys() {
		return incrementKeys;
	}
	/**
	 * @param incrementKeys the incrementKeys to set
	 */
	public void setIncrementKeys(Boolean incrementKeys) {
		this.incrementKeys = incrementKeys;
	}
	/**
	 * @return the incrementSslContexts
	 */
	public Boolean getIncrementSslContexts() {
		return incrementSslContexts;
	}
	/**
	 * @param incrementSslContexts the incrementSslContexts to set
	 */
	public void setIncrementSslContexts(Boolean incrementSslContexts) {
		this.incrementSslContexts = incrementSslContexts;
	}
	/**
	 * @return the incrementAcclrDev
	 */
	public Boolean getIncrementAcclrDev() {
		return incrementAcclrDev;
	}
	/**
	 * @param incrementAcclrDev the incrementAcclrDev to set
	 */
	public void setIncrementAcclrDev(Boolean incrementAcclrDev) {
		this.incrementAcclrDev = incrementAcclrDev;
	}
	/**
	 * @return the allocatedUserKeys
	 */
	public Integer getAllocatedUserKeys() {
		return allocatedUserKeys;
	}
	/**
	 * @param allocatedUserKeys the allocatedUserKeys to set
	 */
	public void setAllocatedUserKeys(Integer allocatedUserKeys) {
		this.allocatedUserKeys = allocatedUserKeys;
	}
	/**
	 * @return the allocatedSSLContexts
	 */
	public Integer getAllocatedSSLContexts() {
		return allocatedSSLContexts;
	}
	/**
	 * @param allocatedSSLContexts the allocatedSSLContexts to set
	 */
	public void setAllocatedSSLContexts(Integer allocatedSSLContexts) {
		this.allocatedSSLContexts = allocatedSSLContexts;
	}
	/**
	 * @return the allocatedAccelDevices
	 */
	public Integer getAllocatedAccelDevices() {
		return allocatedAccelDevices;
	}
	/**
	 * @param allocatedAccelDevices the allocatedAccelDevices to set
	 */
	public void setAllocatedAccelDevices(Integer allocatedAccelDevices) {
		this.allocatedAccelDevices = allocatedAccelDevices;
	}
	/**
	 * @return the modifiedUserKeys
	 */
	public Integer getModifiedUserKeys() {
		return modifiedUserKeys;
	}
	/**
	 * @param modifiedUserKeys the modifiedUserKeys to set
	 */
	public void setModifiedUserKeys(Integer modifiedUserKeys) {
		this.modifiedUserKeys = modifiedUserKeys;
	}
	/**
	 * @return the modifiedSSLContexts
	 */
	public Integer getModifiedSSLContexts() {
		return modifiedSSLContexts;
	}
	/**
	 * @param modifiedSSLContexts the modifiedSSLContexts to set
	 */
	public void setModifiedSSLContexts(Integer modifiedSSLContexts) {
		this.modifiedSSLContexts = modifiedSSLContexts;
	}
	/**
	 * @return the modifiedAccelDevices
	 */
	public Integer getModifiedAccelDevices() {
		return modifiedAccelDevices;
	}
	/**
	 * @param modifiedAccelDevices the modifiedAccelDevices to set
	 */
	public void setModifiedAccelDevices(Integer modifiedAccelDevices) {
		this.modifiedAccelDevices = modifiedAccelDevices;
	} 
}
