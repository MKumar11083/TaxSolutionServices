package com.cavium.rest.model.fileupload;

import java.io.Serializable;

public class FileUploadDetail implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -9171519735711391417L;
	
	private String username;
	private String password;
	private String filename;
	private String type;
	private String dualFactorKeyFileId;
	private String dualFactorPortNo ; 
	private String dualFactorCertificateId;
	private String applianceIp;
	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}
	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}
	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * @return the filename
	 */
	public String getFilename() {
		return filename;
	}
	/**
	 * @param filename the filename to set
	 */
	public void setFilename(String filename) {
		this.filename = filename;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	
	public String getDualFactorKeyFileId() {
		return dualFactorKeyFileId;
	}
	public void setDualFactorKeyFileId(String dualFactorKeyFileId) {
		this.dualFactorKeyFileId = dualFactorKeyFileId;
	}
	public String getDualFactorPortNo() {
		return dualFactorPortNo;
	}
	public void setDualFactorPortNo(String dualFactorPortNo) {
		this.dualFactorPortNo = dualFactorPortNo;
	}
	public String getDualFactorCertificateId() {
		return dualFactorCertificateId;
	}
	public void setDualFactorCertificateId(String dualFactorCertificateId) {
		this.dualFactorCertificateId = dualFactorCertificateId;
	}
	/**
	 * @return the applianceIp
	 */
	public String getApplianceIp() {
		return applianceIp;
	}
	/**
	 * @param applianceIp the applianceIp to set
	 */
	public void setApplianceIp(String applianceIp) {
		this.applianceIp = applianceIp;
	} 

}
