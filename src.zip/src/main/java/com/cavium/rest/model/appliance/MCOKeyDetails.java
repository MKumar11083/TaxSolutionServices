package com.cavium.rest.model.appliance;

import java.io.Serializable;

import org.springframework.stereotype.Component;

import com.cavium.model.appliance.DualFactorUsersRelationshipModel;

@Component
public class MCOKeyDetails implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8595340726026170909L;
	private String username;
	private String password;
	private String applianceId;
	private String uploadedFileId;
	private DualFactorUsersRelationshipModel dualFactorDetails;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getApplianceId() {
		return applianceId;
	}
	public void setApplianceId(String applianceId) {
		this.applianceId = applianceId;
	}
	/**
	 * @return the uploadedFileId
	 */
	public String getUploadedFileId() {
		return uploadedFileId;
	}
	/**
	 * @param uploadedFileId the uploadedFileId to set
	 */
	public void setUploadedFileId(String uploadedFileId) {
		this.uploadedFileId = uploadedFileId;
	}
	public DualFactorUsersRelationshipModel getDualFactorDetails() {
		return dualFactorDetails;
	}
	public void setDualFactorDetails(DualFactorUsersRelationshipModel dualFactorDetails) {
		this.dualFactorDetails = dualFactorDetails;
	}
	 
	 
}
