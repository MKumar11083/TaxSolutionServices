package com.cavium.rest.model.appliance;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(value=Include.NON_NULL)
public class Timezone implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2856890261145550930L;
	private String timeZone;
	public String getTimeZone() {
		return timeZone;
	}
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}
	
}
