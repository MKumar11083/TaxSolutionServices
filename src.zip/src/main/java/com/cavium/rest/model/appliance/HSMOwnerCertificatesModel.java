package com.cavium.rest.model.appliance;

import java.io.Serializable;

import com.cavium.model.appliance.DualFactorUsersRelationshipModel;

 
public class HSMOwnerCertificatesModel implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String username;
	private String password;	
	private String hsmFileUploadedId;
	private String signedHsmFileUploadedId;
	private Long applianceId;
	private String applianceIp;
	private String hsmCertificateType;
	private DualFactorUsersRelationshipModel dualFactorDetails;
	
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * @return the hsmFileUploadedId
	 */
	public String getHsmFileUploadedId() {
		return hsmFileUploadedId;
	}
	/**
	 * @param hsmFileUploadedId the hsmFileUploadedId to set
	 */
	public void setHsmFileUploadedId(String hsmFileUploadedId) {
		this.hsmFileUploadedId = hsmFileUploadedId;
	}
	/**
	 * @return the signedHsmFileUploadedId
	 */
	public String getSignedHsmFileUploadedId() {
		return signedHsmFileUploadedId;
	}
	/**
	 * @param signedHsmFileUploadedId the signedHsmFileUploadedId to set
	 */
	public void setSignedHsmFileUploadedId(String signedHsmFileUploadedId) {
		this.signedHsmFileUploadedId = signedHsmFileUploadedId;
	}
	/**
	 * @return the applianceId
	 */
	public Long getApplianceId() {
		return applianceId;
	}
	/**
	 * @param applianceId the applianceId to set
	 */
	public void setApplianceId(Long applianceId) {
		this.applianceId = applianceId;
	}
	/**
	 * @return the applianceIp
	 */
	public String getApplianceIp() {
		return applianceIp;
	}
	/**
	 * @param applianceIp the applianceIp to set
	 */
	public void setApplianceIp(String applianceIp) {
		this.applianceIp = applianceIp;
	}
	/**
	 * @return the hsmCertificateType
	 */
	public String getHsmCertificateType() {
		return hsmCertificateType;
	}
	/**
	 * @param hsmCertificateType the hsmCertificateType to set
	 */
	public void setHsmCertificateType(String hsmCertificateType) {
		this.hsmCertificateType = hsmCertificateType;
	}
	public DualFactorUsersRelationshipModel getDualFactorDetails() {
		return dualFactorDetails;
	}
	public void setDualFactorDetails(DualFactorUsersRelationshipModel dualFactorDetails) {
		this.dualFactorDetails = dualFactorDetails;
	}
   	 
}
