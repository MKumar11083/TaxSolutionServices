package com.cavium.rest.controller.partition;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.appliance.DualFactorUsersRelationshipModel;
import com.cavium.model.appliance.StoreType;
import com.cavium.model.partition.PartitionData;
import com.cavium.model.partition.PartitionDetailModel;
import com.cavium.model.partition.PartitionDnsConfig;
import com.cavium.model.partition.PartitionETH;
import com.cavium.model.partition.PartitionInterfaces;
import com.cavium.model.partition.PartitionInterfacesAdvance;
import com.cavium.model.partition.PartitionInterfacesGeneral;
import com.cavium.model.partition.RestorePartitionModel;
import com.cavium.pojo.PartitionsDetails;
import com.cavium.pojo.UserAttributes;
import com.cavium.repository.appliance.ApplianceRepository;
import com.cavium.repository.appliance.DualFactorUsersRelationshipRepository;
import com.cavium.repository.partition.PartitionRepository;
import com.cavium.rest.common.utill.Response;
import com.cavium.rest.model.appliance.ApplianceModel;
import com.cavium.rest.model.appliance.InitializeApplianceModel;
import com.cavium.rest.model.partition.ListPartitionModel;
import com.cavium.rest.model.partition.PartitionModel;
import com.cavium.service.appliance.ApplianceService;
import com.cavium.service.partition.PartitionService;
import com.cavium.utill.CaviumConstant;
import com.cavium.utill.CaviumResponseModel;

@RestController
@RequestMapping("rest")
public class PartitionManagementController {


	@Autowired
	private UserAttributes userAttributes;



	@Autowired
	private PartitionService partitionService;
	@Autowired
	private ApplianceService applianceService;
	@Autowired
	private PartitionRepository partitionRepository;
	
	@Autowired
	private ApplianceRepository applianceRepository;
	@Autowired
	private DualFactorUsersRelationshipRepository dfUsersRelationshipRepository;

	@Lookup
	public PartitionsDetails getPartitionsDetails() {
		return null;
	}
	@Lookup
	public CaviumResponseModel getCaviumResponseModel() {
		return null;
	}


	private Logger logger = Logger.getLogger(this.getClass());

	/**
	 * This method is used to get list of all partitions
	 * @return
	 */
	@RequestMapping(value = "listOfPartitions", method = RequestMethod.GET)
	public Response getListOfPartitions() {
		List<PartitionDetailModel> listPartitions=new ArrayList<PartitionDetailModel>();
		Response response=new Response();
		try {
			String loggedInUser = userAttributes.getlogInUserName();
			listPartitions=partitionService.getListOfPartitions(loggedInUser);
			List<Object> partitionDataDetails=new ArrayList<>();
			for(PartitionDetailModel pdm : listPartitions){

				if(pdm!=null && pdm.getPartitionData()!=null){
					ListPartitionModel partitionDetail= new ListPartitionModel();
					partitionDetail.setPartitionId(pdm.getPartitionId());					 
					partitionDetail.setCertAuth(pdm.getPartitionData().getCertAuth());
					partitionDetail.setPcoFixedKeyFingerPrint(pdm.getPartitionData().getPcoFixedKeyFingerPrint());
					partitionDetail.setMaxKeys(pdm.getPartitionData().getMaxKeys());
					partitionDetail.setCloningMethod(pdm.getPartitionData().getCloningMethod());
					partitionDetail.setTotalSslCtxs(pdm.getPartitionData().getTotalSslCtxs());
					partitionDetail.setmValueCloning(pdm.getPartitionData().getmValueCloning());
					partitionDetail.setKekMethod(pdm.getPartitionData().getKekMethod());
					partitionDetail.setAuditLogStatus(pdm.getPartitionData().getAuditLogStatus());
					partitionDetail.setBlockDeleteUserWithKeys(pdm.getPartitionData().getBlockDeleteUserWithKeys());
					partitionDetail.setCavServerStatus(pdm.getPartitionData().getCavServerStatus());
					partitionDetail.setNodeId(pdm.getPartitionData().getNodeId());
					partitionDetail.setmValueMiscCO(pdm.getPartitionData().getmValueMiscCO());
					partitionDetail.setMaxAcclrDevCount(pdm.getPartitionData().getMaxAcclrDevCount());
					partitionDetail.setKeyImport(pdm.getPartitionData().getKeyImport());
					partitionDetail.setKeyExport(pdm.getPartitionData().getKeyExport());
					partitionDetail.setOccupiedSessionKeys(pdm.getPartitionData().getOccupiedSessionKeys());
					partitionDetail.setExportWithUserKeysOtherThanKEK(pdm.getPartitionData().getExportWithUserKeysOtherThanKEK());
					partitionDetail.setStatus(pdm.getPartitionData().getStatus());
					partitionDetail.setmValueBackupByCO(pdm.getPartitionData().getmValueBackupByCO());
					partitionDetail.setSessionCount(pdm.getPartitionData().getSessionCount());
					partitionDetail.setTwoKeyBackup(pdm.getPartitionData().getTwoKeyBackup());
					partitionDetail.setAvailableUsers(pdm.getPartitionData().getAvailableUsers());
					partitionDetail.setMaxPswdLen(pdm.getPartitionData().getMaxPswdLen());
					partitionDetail.setMaxUsers(pdm.getPartitionData().getMaxUsers());
					partitionDetail.setGroupId(pdm.getPartitionData().getGroupId());
					partitionDetail.setVmStatus(pdm.getPartitionData().getVmStatus());
					partitionDetail.setName(pdm.getPartitionData().getName());
					partitionDetail.setnValue(pdm.getPartitionData().getnValue());
					partitionDetail.setMcoBackupRestore(pdm.getPartitionData().isMcoBackupRestore());
					partitionDetail.setOccupiedSslCtxs(pdm.getPartitionData().getOccupiedSslCtxs());
					partitionDetail.setFipsState(pdm.getPartitionData().getFipsState());
					partitionDetail.setOccupiedSessionKeys(pdm.getPartitionData().getOccupiedSessionKeys());
					partitionDetail.setmValueUserMgmt(pdm.getPartitionData().getmValueUserMgmt());
					partitionDetail.setMinPswdLen(pdm.getPartitionData().getMinPswdLen());		
					partitionDetail.setApplianceId(pdm.getApplianceId());
					partitionDataDetails.add(partitionDetail);					
				}
			}			 
			response.setCode("200");
			response.setMessage("List of Partitions");
			response.setData(partitionDataDetails);
		} catch (Exception e) {
			logger.error("Error occured during getListOfPartitions method of PartitionManagementController class :: "+e.getMessage());
		}
		return response;
	}

	@RequestMapping(value = "getPartitionDetail/{partitionId}", method = RequestMethod.GET)
	public Response getPartitionDetail() {
		Response response=new Response();
		return response;
	}

	@RequestMapping(value = "getPartitionsDetailForAppliance/{applianceId}", method = RequestMethod.GET)
	public Response getPartitionsDetailForAppliance() {
		Response response=new Response();
		return response;
	}

	@RequestMapping(value = "createPartition", method = RequestMethod.POST)
	public Response createPartition(@RequestBody PartitionModel partitionModel) {

		Response res=new Response();
		try{
			StringBuilder requireFieldsMessage=new StringBuilder();	
			checkMandatoryFieldsForCreatePartition(requireFieldsMessage,partitionModel);
			if(StringUtils.isEmpty(String.valueOf(requireFieldsMessage))){
				String loggedInUser = userAttributes.getlogInUserName();
				PartitionDetailModel partition=null;
				PartitionDetailModel pdm= new PartitionDetailModel();
				pdm.setPartitionName(partitionModel.getPartitionName());
				pdm.setCsr(partitionModel.getCsr());
				pdm.setAcclrDev(partitionModel.getAcclrDev());
				pdm.setKeys(partitionModel.getKeys());
				pdm.setSslContexts(partitionModel.getSslContexts());
				if(partitionModel.getBackup()!=null){
					pdm.setBackup(partitionModel.getBackup());
				}
				if(partitionModel.getWrap()!=null){
					pdm.setWrap(partitionModel.getWrap());
				}				 
				pdm.setApplianceId(partitionModel.getApplianceId());
				if(partitionModel.getNetworkStats()==null){
					partitionService.setDefaultValuesForNetworkStats(pdm);
				}			  
				ApplianceDetailModel appModel=applianceService.getApplianceById(String.valueOf(partitionModel.getApplianceDetails().getApplianceId()));	
				String errorMessage=null;
				if(appModel!=null){
				if(partitionModel.getDualFactorDetails()!=null) {
					errorMessage=partitionService.validateDualFactorDetails(appModel,partitionModel);
				}else {
					if(appModel.getFipsState().equalsIgnoreCase("3")) {
						errorMessage="dualFactorDetails is required";
					}
				}
				if(StringUtils.isEmpty(errorMessage)){
				partitionModel.getApplianceDetails().setIpAddress(appModel.getIpAddress());
				pdm.setApplianceDetailModel(partitionModel.getApplianceDetails());
				if(StringUtils.isNotEmpty(partitionModel.getUsername())){
					pdm.setUsername(partitionModel.getUsername());	
				}
				if(StringUtils.isNotEmpty(partitionModel.getPassword())){
					pdm.setPassword(partitionModel.getPassword());
				}
				partition=partitionService.createPartition(loggedInUser, pdm,null);

				if(StringUtils.isNotEmpty( partition.getLastOperationStatus()) && ( partition.getLastOperationStatus().equalsIgnoreCase("In-Progress") || partition.getLastOperationStatus().equalsIgnoreCase("Completed"))){
				res.setStatus("Completed");
				}else{
				res.setStatus("failed");
				}
				res.setCode(partition.getCode());
				res.setName(partition.getPartitionName());
				res.setId(partition.getPartitionId());
				if(!StringUtils.isEmpty(partition.getErrorMessage())){
					res.setMessage(partition.getErrorMessage());
				}
				if(!StringUtils.isEmpty(partition.getMessage())){
					res.setMessage(partition.getMessage());
				}
				}else{
					res.setStatus("failed");
					res.setCode("400");					 
					res.setMessage(errorMessage);	
				}
			}else{
				res.setStatus("failed");
				res.setCode("400");					 
				res.setMessage(errorMessage);	
			}
			}	
			else {
				logger.info("Mandatory fields are missing.");		 
				res.setStatus("failed");
				res.setCode("400");
				String errorMessage="Please provide mandatory fields : "+requireFieldsMessage.substring(0,requireFieldsMessage.length()-1);
				res.setMessage(errorMessage);
			}
		}catch (Exception e) {
			res.setStatus("failed");
			res.setCode("400");
			String errorMessage="Error is cominng while creating partition";
			res.setMessage(errorMessage);
			logger.error("Error occured during createPartition method of PartitionManagementController class"+e.getMessage());
		}
		return res;
	}
	public void  checkMandatoryFieldsForCreatePartition(StringBuilder requiredFieldMessage,PartitionModel partitionModel){
		logger.info("Start of checkMandatoryField Method in PartitionManagementController Class");
		if(StringUtils.isEmpty(partitionModel.getPartitionName())){
			requiredFieldMessage.append("Partition Name").append(CaviumConstant.COMMA);
		}
		if(partitionModel.getKeys()==null){
			requiredFieldMessage.append("keys").append(CaviumConstant.COMMA);
		}
		if(partitionModel.getAcclrDev()==null){
			requiredFieldMessage.append("Acceleration Devices").append(CaviumConstant.COMMA);
		}
		if(partitionModel.getSslContexts()==null){
			requiredFieldMessage.append("SSL Contexts").append(CaviumConstant.COMMA);
		}
		if(partitionModel.getApplianceDetails()==null){
			requiredFieldMessage.append("Appliance Id").append(CaviumConstant.COMMA);
		}
		if(partitionModel.getApplianceDetails()!=null && partitionModel.getApplianceDetails().getApplianceId()==null){
			requiredFieldMessage.append("Appliance Id").append(CaviumConstant.COMMA);
		}

 logger.info("End of checkMandatoryField Method in ApplianceManagementController Class");	 
	} 
	
	
	@RequestMapping(value = "removePartition", method = RequestMethod.DELETE)
	public List<Response> removePartition(@RequestBody List<PartitionModel> partitionModels) {
		List<Response> partitionsResponse=new ArrayList<Response>();
		List<PartitionDetailModel> partitionDetailModels=new ArrayList<PartitionDetailModel>();
		List<PartitionDetailModel> partitionDetailModel=null;
		try {
			String loggedInUser = userAttributes.getlogInUserName();
			 for(PartitionModel partitionModel :partitionModels){
				 Response res= new Response();
				 StringBuilder requireFieldsMessage=new StringBuilder();	
				 checkMandatoryFields(requireFieldsMessage,partitionModel);
				if(StringUtils.isEmpty(String.valueOf(requireFieldsMessage))){	
					 ApplianceDetailModel appModel=applianceRepository.getApplianceById(partitionModel.getApplianceDetails().getApplianceId(), StoreType.PERMANENT);
						if(appModel!=null) {
				 PartitionDetailModel pdm= new PartitionDetailModel();
				 if(partitionModel.getSessionClose()!=null){
				 pdm.setSessionClose(partitionModel.getSessionClose());
				}
				
				 pdm.setPartitionId(partitionModel.getPartitionId());				 
				 String errorMessage=null;
					if(!appModel.isCredentialSaved()) {
					if(partitionModel.getDualFactorDetails()!=null) {
						errorMessage=partitionService.validateDualFactorDetails(appModel,partitionModel);
					}else {
						if(appModel.getFipsState().equalsIgnoreCase("3")) {
							errorMessage="dualFactorDetails is required";
						}
					}
					 if(StringUtils.isNotEmpty(partitionModel.getUsername())){
									pdm.setUsername(partitionModel.getUsername());	
								}else{
									errorMessage="userName is required";
								}
								if(StringUtils.isNotEmpty(partitionModel.getPassword())){
									pdm.setPassword(partitionModel.getPassword());
								}else{
									errorMessage="Password is required";
								}
						}
					else{
						errorMessage=checkSavedDetailsExist(appModel,partitionModel);			
					 }
				if(StringUtils.isEmpty(errorMessage)){
				partitionModel.getApplianceDetails().setIpAddress(appModel.getIpAddress());
				pdm.setApplianceDetailModel(partitionModel.getApplianceDetails());
				partitionDetailModels.add(pdm);
				}else{
						 logger.info(errorMessage);		 
						 res.setStatus("failed");
						 res.setCode("400");						 
						 res.setMessage(errorMessage);
						 partitionsResponse.add(res);	
					}
				 }else{
						res.setStatus("failed");
						res.setCode("404");
						res.setMessage("Appliance does not exist.");
						 partitionsResponse.add(res);
					 }
			 }
			 else {
				 logger.info("Mandatory fields are missing.");		 
				 res.setStatus("failed");
				 res.setCode("400");
				 String errorMessage="Please provide mandatory fields : "+requireFieldsMessage.substring(0,requireFieldsMessage.length()-1);
				 res.setMessage(errorMessage);
				 partitionsResponse.add(res);
				}
			 }
			 if(partitionDetailModels!=null && partitionDetailModels.size()>0){
				 partitionDetailModel= partitionService.deletePartition(loggedInUser, partitionDetailModels);			 
			for(PartitionDetailModel partitionDetail: partitionDetailModel){
				 Response res= new Response();
				 res.setId(partitionDetail.getPartitionId());
					res.setCode(partitionDetail.getCode());
				if(StringUtils.isNotEmpty(partitionDetail.getMessage())){
					res.setMessage(partitionDetail.getMessage());
				}
				if(StringUtils.isNotEmpty(partitionDetail.getErrorMessage())){
					res.setMessage(partitionDetail.getErrorMessage());		
				 }
				if(StringUtils.isNotEmpty(partitionDetail.getLastOperationStatus()) && (partitionDetail.getLastOperationStatus().equalsIgnoreCase("In-Progress") || partitionDetail.getLastOperationStatus().equalsIgnoreCase("Completed"))){
					res.setStatus("Completed");
				}else{
					res.setStatus("failed");
				}
				partitionsResponse.add(res);
			}
			 } 
		} catch (Exception e) {
			logger.error("Error occured during removePartition of class PartitionManagmentContoller :: "+e.getMessage());
		}
		return partitionsResponse;
	}
	
	public void  checkMandatoryFields(StringBuilder requiredFieldMessage,PartitionModel partitionModel){
		logger.info("Start of checkMandatoryFieldForRemovePartition Method in PartitionManagementController Class");
		if(partitionModel.getPartitionId()==null){
			requiredFieldMessage.append("Partition Id").append(CaviumConstant.COMMA);
		}		 
		if(partitionModel.getApplianceDetails()!=null && partitionModel.getApplianceDetails().getApplianceId()==null){
			requiredFieldMessage.append("Appliance Id").append(CaviumConstant.COMMA);
		}		 
	}
	
	public void  checkMandatoryFieldsForCavServer(StringBuilder requiredFieldMessage,PartitionModel partitionModel){
		logger.info("Start of checkMandatoryFieldForRemovePartition Method in PartitionManagementController Class");
		if(partitionModel.getPartitionId()==null){
			requiredFieldMessage.append("Partition Id").append(CaviumConstant.COMMA);
		}		 
		if(partitionModel.getApplianceDetails()!=null && partitionModel.getApplianceDetails().getApplianceId()==null){
			requiredFieldMessage.append("Appliance Id").append(CaviumConstant.COMMA);
		}	
		if(partitionModel.getEnableCavServer()==null){
			requiredFieldMessage.append("Enable CaServer").append(CaviumConstant.COMMA);
		}	
	}
	
	public List<Response>  checkMandatoryFieldsForBackUp(List<PartitionModel> partitionModels){
		logger.info("Start of checkMandatoryFieldsForBackUp Method in PartitionManagementController Class");
		List<Response> listResponse=new ArrayList<Response>();
		for(PartitionModel partitionModel :partitionModels){
			StringBuilder requireFieldsMessage= new StringBuilder();
			Response res= new Response();
		if(partitionModel.getPartitionId()==null){
			requireFieldsMessage.append("Partition Id").append(CaviumConstant.COMMA);
		}		 
		if(partitionModel.getApplianceDetails()!=null && partitionModel.getApplianceDetails().getApplianceId()==null){
			requireFieldsMessage.append("Appliance Id").append(CaviumConstant.COMMA);
		}
		if(StringUtils.isEmpty(requireFieldsMessage)){
			 ApplianceDetailModel appModel=applianceService.getApplianceById(String.valueOf(partitionModel.getApplianceDetails().getApplianceId()));
			 String errorMessage=null;
			 if(appModel!=null){
				 if(!appModel.isCredentialSaved()) {
				if(partitionModel.getDualFactorDetails()!=null) {
					errorMessage=partitionService.validateDualFactorDetails(appModel,partitionModel);
				}else {
					if(appModel.getFipsState().equalsIgnoreCase("3")) {
						errorMessage="dualFactorDetails is required.";
					}
				}
				 if(StringUtils.isEmpty(partitionModel.getUsername())){
				 errorMessage="userName is required";
					}
					if(StringUtils.isEmpty(partitionModel.getPassword())){
				 errorMessage="Password is required";
				}
			 }
			 else{
			 errorMessage=checkSavedDetailsExist(appModel,partitionModel);			
			  }
			 }
			 else{
				 errorMessage="Appliance Id "+partitionModel.getApplianceDetails().getApplianceId() + " is not exist in Database.";
			 }
			if(StringUtils.isNotEmpty(errorMessage)){
				requireFieldsMessage.append(errorMessage).append(CaviumConstant.COMMA);
			}
		}
		if(StringUtils.isNotEmpty(requireFieldsMessage)){
		 res.setStatus("failed");
		 res.setCode("400");
		 String errorMessage="Please provide mandatory fields : "+requireFieldsMessage.substring(0,requireFieldsMessage.length()-1);
		 res.setMessage(errorMessage);
		 listResponse.add(res);
		}
		}
		return listResponse;
	}
	
	
	@RequestMapping(value = "backupPartitions", method = RequestMethod.POST)
	public final void backupPartitions(@RequestBody List<PartitionModel> partitionModels,HttpServletResponse response){

		ArrayList<File> files = new ArrayList<>();
		BufferedOutputStream bufferedOutputStream =null;
		ZipOutputStream zipOutputStream=null;
		PrintWriter pw =null;
		try {
			boolean headerSet=false;
			bufferedOutputStream = new BufferedOutputStream(response.getOutputStream());
			pw = new PrintWriter(bufferedOutputStream);
			zipOutputStream   = new ZipOutputStream(bufferedOutputStream);
			boolean isValidation=false;
			List<Response> listRespone=new ArrayList<Response>();
			for(PartitionModel partitionModel: partitionModels) {
				try {
					 if(!isValidation){
						 listRespone= checkMandatoryFieldsForBackUp(partitionModels);
					 }
					if(listRespone!=null && listRespone.size()==0){
						isValidation=true;
					 PartitionDetailModel pdm= new PartitionDetailModel();
					 if(partitionModel.getSessionClose()!=null){
					 pdm.setSessionClose(partitionModel.getSessionClose());
					}
					 if(partitionModel.getNoKey()!=null){
						 pdm.setNoKey(partitionModel.getNoKey());
					}
					 pdm.setPartitionId(partitionModel.getPartitionId());
					 ApplianceDetailModel appModel=applianceService.getApplianceById(String.valueOf(partitionModel.getApplianceDetails().getApplianceId()));
						if(StringUtils.isNotEmpty(partitionModel.getUsername())){
							pdm.setUsername(partitionModel.getUsername());	
						}
						if(StringUtils.isNotEmpty(partitionModel.getPassword())){
							pdm.setPassword(partitionModel.getPassword());
						}					
					partitionModel.getApplianceDetails().setIpAddress(appModel.getIpAddress());
					pdm.setApplianceDetailModel(partitionModel.getApplianceDetails());
					PartitionDetailModel pdmm=partitionRepository.findOne(pdm.getPartitionId());
					pdm.setPartitionName(pdmm.getPartitionName());	
					if(pdm.isSessionClose()) {
						JSONObject jsonObject=new JSONObject();
						jsonObject=partitionService.getUserNamePassword(pdm, jsonObject);
						jsonObject.put("action", "close_session");
						pdm=partitionService.closeSession(pdm, "backupPartition",jsonObject);
					}
					if(pdm.getCode()!=null && pdm.getCode().equalsIgnoreCase("200") || pdm.isSessionClose() == false) {
						CaviumResponseModel responseModel=getCaviumResponseModel();
						String operation="backup";
											
						responseModel = partitionService.downloadConfigFileURL(pdm,"backup_partition",operation);
						logger.info(" Start of backupPartition method of PartitionController");
						File file=null;
						if(!StringUtils.isEmpty(responseModel.getResponseMessage()) && responseModel.getResponseCode().equalsIgnoreCase("200")) {
						 
						
							String applianceName="";
							if(pdmm!=null && pdmm.getApplianceDetailModel()!=null && pdmm.getApplianceDetailModel().getApplianceName()!=null) {
								applianceName=pdmm.getApplianceDetailModel().getApplianceName();
							}
							file=partitionService.downloadConfigFile(responseModel.getResponseMessage(), pdm.getPartitionName(),applianceName);
							if(file!=null) {
								if(!headerSet){
									response.setContentType("application/zip");
									response.setStatus(HttpServletResponse.SC_OK);
									response.addHeader("Content-Disposition", "attachment; filename=\"backupPartitionFiles.zip\"");
									headerSet=true;
								}
								files.add(file);
							}
						}
					}							
			} 
				else{
						response.setContentType("text/html"); 				
						pw.write(StringUtils.join(listRespone, "|")); 
						pw.close();
						headerSet=true;
						break;
					}
				}catch (Exception e) {				
					logger.error("Error occured during backupPartition of class PartitionManagementContoller"+e.getMessage());
				}
			}
			if(!headerSet){
				response.setContentType("text/html"); 
				pw.write("Error occured during download file"); 
				pw.close();
			}
			for (File file : files) {
				//new zip entry and copying inputstream with file to zipOutputStream, after all closing streams
				zipOutputStream.putNextEntry(new ZipEntry(file.getName()));
				FileInputStream fileInputStream = new FileInputStream(file);

				IOUtils.copy(fileInputStream, zipOutputStream);

				fileInputStream.close();
				zipOutputStream.closeEntry();
			}
			
			try{
				if (zipOutputStream != null) {
					zipOutputStream.finish();
					zipOutputStream.flush();
					IOUtils.closeQuietly(zipOutputStream);
				}
				if(bufferedOutputStream!=null){
					IOUtils.closeQuietly(bufferedOutputStream);
				}
			}catch (Exception e) {
				logger.error("error coming while closing  zipOutputStream in downloadCavServerConfigFile method of PartitionManagementController :: "+e.getMessage());	 
			}
		}
		catch (Exception e) {	 
			logger.error("Error occured during backupPartition of class PartitionManagementController ::" +e.getMessage());
		}
		finally {

			for (File file : files) 
				if(file!=null){
					try{
						Files.deleteIfExists(Paths.get(file.getAbsolutePath()));
					}catch (Exception e) {
						logger.error("Error while deleting certificate file  in backupPartition method of PartitionManagementController :: " + e.getMessage()); 
					}
				}
			if(pw!=null){
				pw.close();
			}
			try{
				if (zipOutputStream != null) {
					zipOutputStream.finish();
					zipOutputStream.flush();
					IOUtils.closeQuietly(zipOutputStream);
				}
				if(bufferedOutputStream!=null){
					IOUtils.closeQuietly(bufferedOutputStream);
				}
			}catch (Exception e) {
				logger.error("error coming while closing  zipOutputStream in backupPartition method of PartitionManagementController :: "+e.getMessage());	 
			}
		}
	}
	
	@RequestMapping(value = "closeSession", method = RequestMethod.PUT)
	public List<Response> closeSession(@RequestBody List<PartitionModel> partitionModels) {
		List<PartitionDetailModel> partitionDetailModel=null;
		List<Response> partitionsResponse=new ArrayList<Response>();		
		List<PartitionDetailModel> partitionDetailModels=new ArrayList<PartitionDetailModel>();
		try {
			 for(PartitionModel partitionModel :partitionModels){
				 Response res= new Response();
				 StringBuilder requireFieldsMessage=new StringBuilder();	
				 checkMandatoryFields(requireFieldsMessage,partitionModel);
				if(StringUtils.isEmpty(String.valueOf(requireFieldsMessage))){	
					 PartitionDetailModel pdm= new PartitionDetailModel();
					 pdm.setPartitionId(partitionModel.getPartitionId());
					 
					 ApplianceDetailModel appModel=applianceRepository.getApplianceById(partitionModel.getApplianceDetails().getApplianceId(), StoreType.PERMANENT);
						if(appModel!=null) {
							 String errorMessage=null;
							if(!appModel.isCredentialSaved()) {
							if(partitionModel.getDualFactorDetails()!=null) {
						errorMessage=partitionService.validateDualFactorDetails(appModel,partitionModel);
						}else {
							if(appModel.getFipsState().equalsIgnoreCase("3")) {
								errorMessage="dualFactorDetails is required";
							}
						}
						if(StringUtils.isNotEmpty(partitionModel.getUsername())){
							pdm.setUsername(partitionModel.getUsername());	
						}else{
							errorMessage="userName is required";
						}
						if(StringUtils.isNotEmpty(partitionModel.getPassword())){
							pdm.setPassword(partitionModel.getPassword());
						}else{
							errorMessage="Password is required";
						}
						}else{
							checkSavedDetailsExist(appModel,partitionModel);			
						 }
					if(StringUtils.isEmpty(errorMessage)){
					partitionModel.getApplianceDetails().setIpAddress(appModel.getIpAddress());
					pdm.setApplianceDetailModel(partitionModel.getApplianceDetails());
					partitionDetailModels.add(pdm);
					}else{
							 logger.info(errorMessage);		 
							 res.setStatus("failed");
							 res.setCode("400");						 
							 res.setMessage(errorMessage);
							 partitionsResponse.add(res);	
						}
				
			 }else{
					res.setStatus("failed");
					res.setCode("404");
					res.setMessage("Appliance does not exist.");
					 partitionsResponse.add(res);
				 }
		} else {
			 logger.info("Mandatory fields are missing.");		 
			 res.setStatus("failed");
			 res.setCode("400");
			 String errorMessage="Please provide mandatory fields : "+requireFieldsMessage.substring(0,requireFieldsMessage.length()-1);
			 res.setMessage(errorMessage);
			 partitionsResponse.add(res);
			}
			}
			partitionDetailModel=partitionService.closeSessionForPartition(partitionDetailModels);
			for(PartitionDetailModel partitionDetail: partitionDetailModel){
				 Response res= new Response();
				 
				 res.setId(partitionDetail.getPartitionId());
				res.setCode(partitionDetail.getCode());
				if(StringUtils.isNotEmpty(partitionDetail.getMessage())){
					res.setMessage(partitionDetail.getMessage());
				}
				if(StringUtils.isNotEmpty(partitionDetail.getErrorMessage())){
					res.setMessage(partitionDetail.getErrorMessage());		
				 }
				if(StringUtils.isNotEmpty(partitionDetail.getLastOperationStatus()) && (partitionDetail.getLastOperationStatus().equalsIgnoreCase("In-Progress") || partitionDetail.getLastOperationStatus().equalsIgnoreCase("Completed"))){
					res.setStatus("Completed");
				}else{
					res.setStatus("failed");
				}
				partitionsResponse.add(res);
			}
		}catch (Exception e) {
			 
			logger.error("Error occured during closeSession of class PartitionManagementController"+e.getMessage());
		}
		return partitionsResponse;
	}
	
	
	@RequestMapping(value = "reboot", method = RequestMethod.PUT)
	public List<Response> reboot(@RequestBody List<PartitionModel> partitionModels) {
		List<Response> partitionsResponse=new ArrayList<Response>();
		List<PartitionDetailModel> partitionDetailModels=new ArrayList<PartitionDetailModel>();
		List<PartitionDetailModel> partitionDetailModel=null;
		try {
			String loggedInUser = userAttributes.getlogInUserName();
			 for(PartitionModel partitionModel :partitionModels){
				 Response res= new Response();
				 StringBuilder requireFieldsMessage=new StringBuilder();	
				 checkMandatoryFields(requireFieldsMessage,partitionModel);
				 if(StringUtils.isEmpty(String.valueOf(requireFieldsMessage))){		
					 ApplianceDetailModel appModel=applianceRepository.getApplianceById(partitionModel.getApplianceDetails().getApplianceId(), StoreType.PERMANENT);
						if(appModel!=null) {
				 PartitionDetailModel pdm= new PartitionDetailModel();
				 if(partitionModel.getSessionClose()!=null){
				 pdm.setSessionClose(partitionModel.getSessionClose());
				}
				
				 pdm.setPartitionId(partitionModel.getPartitionId());
				 
				 String errorMessage=null;
					if(!appModel.isCredentialSaved()) {
					if(partitionModel.getDualFactorDetails()!=null) {
						errorMessage=partitionService.validateDualFactorDetails(appModel,partitionModel);
					}else {
						if(appModel.getFipsState().equalsIgnoreCase("3")) {
							errorMessage="dualFactorDetails is required";
						}
					}
					 if(StringUtils.isNotEmpty(partitionModel.getUsername())){
							pdm.setUsername(partitionModel.getUsername());	
						}else{
							errorMessage="userName is required";
						}
						if(StringUtils.isNotEmpty(partitionModel.getPassword())){
							pdm.setPassword(partitionModel.getPassword());
						}else{
							errorMessage="Password is required";
						}
					}
					else{
						errorMessage=checkSavedDetailsExist(appModel,partitionModel);			
					 }
				if(StringUtils.isEmpty(errorMessage)){
				partitionModel.getApplianceDetails().setIpAddress(appModel.getIpAddress());
				pdm.setApplianceDetailModel(partitionModel.getApplianceDetails());
				partitionDetailModels.add(pdm);
				}else{
						 logger.info(errorMessage);		 
						 res.setStatus("failed");
						 res.setCode("400");						 
						 res.setMessage(errorMessage);
						 partitionsResponse.add(res);	
					}
				}else{
					res.setStatus("failed");
					res.setCode("404");
					res.setMessage("Appliance does not exist.");
					 partitionsResponse.add(res);
				 }
			 }
			 else {
				 logger.info("Mandatory fields are missing.");		 
				 res.setStatus("failed");
				 res.setCode("400");
				 String errorMessage="Please provide mandatory fields : "+requireFieldsMessage.substring(0,requireFieldsMessage.length()-1);
				 res.setMessage(errorMessage);
				 partitionsResponse.add(res);
				}
			 }
			 if(partitionDetailModels!=null && partitionDetailModels.size()>0){
				 partitionDetailModel= partitionService.rebootPartition(loggedInUser, partitionDetailModels);
			for(PartitionDetailModel partitionDetail: partitionDetailModel){
				 Response res= new Response();
				 res.setId(partitionDetail.getPartitionId());
					res.setCode(partitionDetail.getCode());
				if(StringUtils.isNotEmpty(partitionDetail.getMessage())){
					res.setMessage(partitionDetail.getMessage());
				}
				if(StringUtils.isNotEmpty(partitionDetail.getErrorMessage())){
					res.setMessage(partitionDetail.getErrorMessage());		
				 }
				if(StringUtils.isNotEmpty(partitionDetail.getLastOperationStatus()) && (partitionDetail.getLastOperationStatus().equalsIgnoreCase("In-Progress") || partitionDetail.getLastOperationStatus().equalsIgnoreCase("Completed"))){
					res.setStatus("Completed");
				}else{
					res.setStatus("failed");
				}
				partitionsResponse.add(res);
			}
		}	 
		} catch (Exception e) {
			logger.error("Error occured during reboot of class PartitionManagmentContoller :: "+e.getMessage());
		}
		return partitionsResponse;
	}
	
	@RequestMapping(value = "selfTestReportForPartition", method = RequestMethod.POST)
	public List<Response> selfTestReportForPartition(@RequestBody List<PartitionModel> partitionModels) {
		List<Response> partitionsResponse=new ArrayList<Response>();
		try {		 
			 for(PartitionModel partitionModel :partitionModels){
				 CaviumResponseModel caviumResponseModel=null;
				 StringBuilder requireFieldsMessage=new StringBuilder();	
				 checkMandatoryFields(requireFieldsMessage,partitionModel);
				if(StringUtils.isEmpty(String.valueOf(requireFieldsMessage))){	
					 ApplianceDetailModel appModel=applianceRepository.getApplianceById(partitionModel.getApplianceDetails().getApplianceId(), StoreType.PERMANENT);
						if(appModel!=null) {				 
				   partitionModel.getApplianceDetails().setApplianceName(appModel.getApplianceName());
				   partitionModel.getApplianceDetails().setIpAddress(appModel.getIpAddress());
				   partitionModel.getApplianceDetails().setSelfReportType("Partition");
				 PartitionDetailModel pdm=partitionRepository.findOne(partitionModel.getPartitionId());
				 List<PartitionDetailModel> partitionDetailModels= new ArrayList<PartitionDetailModel>();
				 partitionDetailModels.add(pdm);
				 partitionModel.getApplianceDetails().setPartitionDetailModels(partitionDetailModels);
				 caviumResponseModel=applianceService.getSelfReportData(partitionModel.getApplianceDetails());
				 Response res= new Response();
				 res.setStatus("success");
				 res.setId(partitionModel.getPartitionId());
				 res.setCode(caviumResponseModel.getResponseCode());				 
				 res.setMessage(caviumResponseModel.getResponseMessage());
				 partitionsResponse.add(res);
				}else{
					Response res= new Response();
					res.setStatus("failed");
					res.setCode("404");
					res.setMessage("Appliance does not exist.");
					 partitionsResponse.add(res);
				 }
				  }			 
			 else {
				 logger.info("Mandatory fields are missing.");	
				 Response res= new Response();
				 res.setStatus("failed");
				 res.setCode("400");
				 String errorMessage="Please provide mandatory fields : "+requireFieldsMessage.substring(0,requireFieldsMessage.length()-1);
				 res.setMessage(errorMessage);
				 partitionsResponse.add(res);
				}
			 }
		} catch (Exception e) {
			logger.error("Error occured during resize method  of  PartitionManagmentContoller :: "+e.getMessage());
		}
		return partitionsResponse;
	}
	
	@RequestMapping(value = "resize", method = RequestMethod.PUT)
	public List<Response> resize(@RequestBody List<PartitionModel> partitionModels) {
		List<Response> partitionsResponse=new ArrayList<Response>();
		try {		 
			 for(PartitionModel partitionModel :partitionModels){
				
				 StringBuilder requireFieldsMessage=new StringBuilder();	
				 checkMandatoryFields(requireFieldsMessage,partitionModel);
				if(StringUtils.isEmpty(String.valueOf(requireFieldsMessage))){
					 ApplianceDetailModel appModel=applianceRepository.getApplianceById(partitionModel.getApplianceDetails().getApplianceId(), StoreType.PERMANENT);
						if(appModel!=null) {
				 PartitionDetailModel pdm= new PartitionDetailModel();
				 
				 if(partitionModel.getSessionClose()!=null){
				 pdm.setSessionClose(partitionModel.getSessionClose());
				}
				pdm.setPartitionId(partitionModel.getPartitionId());
				 String errorMessage=null;
					if(!appModel.isCredentialSaved()) {
					if(partitionModel.getDualFactorDetails()!=null) {
						errorMessage=partitionService.validateDualFactorDetails(appModel,partitionModel);
					}else {
						if(appModel.getFipsState().equalsIgnoreCase("3")) {
							errorMessage="dualFactorDetails is required";
						}
					}
					 if(StringUtils.isNotEmpty(partitionModel.getUsername())){
							pdm.setUsername(partitionModel.getUsername());	
						}else{
							errorMessage="userName is required";
							}
						if(StringUtils.isNotEmpty(partitionModel.getPassword())){
							pdm.setPassword(partitionModel.getPassword());
						}else{
						errorMessage="Password is required";
						}
					}
					else{
						errorMessage=checkSavedDetailsExist(appModel,partitionModel);			
					 }
				if(StringUtils.isEmpty(errorMessage)){
				partitionModel.getApplianceDetails().setIpAddress(appModel.getIpAddress());
				pdm.setApplianceDetailModel(partitionModel.getApplianceDetails());
			
				 if(partitionModel.getResizeDetails()!=null){
					 PartitionData partData= new PartitionData();
					 boolean changesExist=false;
					 if(partitionModel.getResizeDetails().getModifiedUserKeys()!=null && partitionModel.getResizeDetails().getModifiedUserKeys()!=0){
					 partData.setModifiedUserKeys(partitionModel.getResizeDetails().getModifiedUserKeys());
					 partData.setIncrementKeys(true);
					 changesExist=true;
					 }
					 if(partitionModel.getResizeDetails().getModifiedSSLContexts()!=null && partitionModel.getResizeDetails().getModifiedSSLContexts()!=0 ){
					 partData.setModifiedSSLContexts(partitionModel.getResizeDetails().getModifiedSSLContexts());
					 partData.setIncrementSslContexts(true);
					 changesExist=true;
					 }
					 if(partitionModel.getResizeDetails().getModifiedAccelDevices()!=null && partitionModel.getResizeDetails().getModifiedAccelDevices()!=0){
					 partData.setModifiedAccelDevices(partitionModel.getResizeDetails().getModifiedAccelDevices());
					 partData.setIncrementAcclrDev(true);
					 changesExist=true;
					 }
					 if(changesExist){
						 if(partitionModel.getBackup()!=null){
								partData.setBackup(partitionModel.getBackup());
						} 
					pdm.setPartitionData(partData);
					}		 
				 }
				 PartitionDetailModel partitionDetail= partitionService.resizePartitions(pdm);
				 Response res= new Response();
					res.setCode(partitionDetail.getCode());
					 res.setId(partitionDetail.getPartitionId());
				if(StringUtils.isNotEmpty(partitionDetail.getMessage())){
					res.setMessage(partitionDetail.getMessage());
				}
				if(StringUtils.isNotEmpty(partitionDetail.getErrorMessage())){
					res.setMessage(partitionDetail.getErrorMessage());		
				 }
				if(StringUtils.isNotEmpty(partitionDetail.getLastOperationStatus()) && (partitionDetail.getLastOperationStatus().equalsIgnoreCase("In-Progress") || partitionDetail.getLastOperationStatus().equalsIgnoreCase("Completed"))){
					res.setStatus("Completed");
				}else{
					res.setStatus("failed");
				}
				 partitionsResponse.add(res);
				}else{
					Response res= new Response();
					logger.info(errorMessage);		 
					res.setStatus("failed");
					res.setCode("400");						 
					res.setMessage(errorMessage);
					partitionsResponse.add(res);	
					}
				}else{
					Response res= new Response();
					res.setStatus("failed");
					res.setCode("404");
					res.setMessage("Appliance does not exist.");
					 partitionsResponse.add(res);
				 }		
			 }
			 else {
				 logger.info("Mandatory fields are missing.");	
				 Response res= new Response();
				 res.setStatus("failed");
				 res.setCode("400");
				 String errorMessage="Please provide mandatory fields : "+requireFieldsMessage.substring(0,requireFieldsMessage.length()-1);
				 res.setMessage(errorMessage);
				 partitionsResponse.add(res);
				}
			 }
		} catch (Exception e) {
			logger.error("Error occured during resize of class PartitionManagmentContoller :: "+e.getMessage());
		}
		return partitionsResponse;
	}
	@RequestMapping(value = "setNetworkConfiguration", method = RequestMethod.POST)
	public List<Response> setNetworkConfiguration(@RequestBody List<PartitionModel> partitionModels) {
		List<PartitionDetailModel> partitionDetailModels=new ArrayList<PartitionDetailModel>();;
		List<Response> partitionsResponse=new ArrayList<Response>();
		String loggedInUser = userAttributes.getlogInUserName();
		try {
			for(PartitionModel partitionModel : partitionModels){
				 Response res= new Response();
				PartitionDetailModel pdm=new PartitionDetailModel();
				StringBuilder requireFieldsMessage=new StringBuilder();	
				checkMandatoryFieldsForNetworkConfig(requireFieldsMessage,partitionModel);
				if(StringUtils.isEmpty(String.valueOf(requireFieldsMessage))){	
					 if(partitionModel.getSessionClose()!=null){
						 pdm.setSessionClose(partitionModel.getSessionClose());
						}
						
						 pdm.setPartitionId(partitionModel.getPartitionId());
						 ApplianceDetailModel appModel=applianceService.getApplianceById(String.valueOf(partitionModel.getApplianceDetails().getApplianceId()));
						 String errorMessage=null;
							if(partitionModel.getDualFactorDetails()!=null) {
								errorMessage=partitionService.validateDualFactorDetails(appModel,partitionModel);
							}else {
								if(appModel.getFipsState().equalsIgnoreCase("3")) {
									errorMessage="dualFactorDetails is required";
								}
							}
							if(StringUtils.isNotEmpty(partitionModel.getUsername())){
								pdm.setUsername(partitionModel.getUsername());	
							}
							if(StringUtils.isNotEmpty(partitionModel.getPassword())){
								pdm.setPassword(partitionModel.getPassword());
							}
						if(StringUtils.isEmpty(errorMessage)){
						partitionModel.getApplianceDetails().setIpAddress(appModel.getIpAddress());
						pdm.setApplianceDetailModel(partitionModel.getApplianceDetails());
						// this is for specific to our Service
						if(partitionModel.getNetworkStats().getAdvanced()==null){
							PartitionDnsConfig dnsConfig= new PartitionDnsConfig();
							dnsConfig.setDnsServers(new String[]{});
							dnsConfig.setSearchDomainNames(new String[]{});
							PartitionInterfacesAdvance advanced = new PartitionInterfacesAdvance();
							advanced.setDnsConfig(dnsConfig);
							partitionModel.getNetworkStats().setAdvanced(advanced);
						}
						pdm.setNetworkStats(partitionModel.getNetworkStats());	
						PartitionDetailModel partitionDetailModel=partitionRepository.findOne(partitionModel.getPartitionId());
						pdm.setPartitionName(partitionDetailModel.getPartitionName());
						partitionDetailModels.add(pdm);
						}else{
								 logger.info("Dual Factor Details Error.");		 
								 res.setStatus("failed");
								 res.setCode("400");						 
								 res.setMessage(errorMessage);
								 partitionsResponse.add(res);	
						}
			
			} else {
				 logger.info("Mandatory fields are missing.");		 
				 res.setStatus("failed");
				 res.setCode("400");
				 String errorMessage="Please provide mandatory fields : "+requireFieldsMessage.substring(0,requireFieldsMessage.length()-1);
				 res.setMessage(errorMessage);
				 partitionsResponse.add(res);
				}
			}
			if(partitionDetailModels!=null && partitionDetailModels.size()>0){
			partitionDetailModels=partitionService.setNetworkConfiguration(loggedInUser,partitionDetailModels);			
			for(PartitionDetailModel partitionDetail: partitionDetailModels){
				 Response res= new Response();
					res.setCode(partitionDetail.getCode());
				if(StringUtils.isNotEmpty(partitionDetail.getMessage())){
					res.setMessage(partitionDetail.getMessage());
				}
				if(StringUtils.isNotEmpty(partitionDetail.getErrorMessage())){
					res.setMessage(partitionDetail.getErrorMessage());		
				 }
				if(StringUtils.isNotEmpty(partitionDetail.getLastOperationStatus()) && (partitionDetail.getLastOperationStatus().equalsIgnoreCase("In-Progress") || partitionDetail.getLastOperationStatus().equalsIgnoreCase("Completed"))){
					res.setStatus("Completed");
				}else{
					res.setStatus("failed");
				}
				partitionsResponse.add(res);
			}
			}
		} catch (Exception e) {
			logger.error("Error occured during setPartitionNetworkConfiguration of class PartitionContoller"+e.getMessage());
		}
		return partitionsResponse;
	}
	
	public void  checkMandatoryFieldsForNetworkConfig(StringBuilder requiredFieldMessage,PartitionModel partitionModel){

		// required Fields
		if(partitionModel!=null && partitionModel.getNetworkStats()!=null && partitionModel.getNetworkStats().getGeneral()!=null){
			boolean interfaceDetailsAvaliable=false;
			if(partitionModel.getNetworkStats().getGeneral().getEth0()!=null)
			{
				interfaceDetailsAvaliable=true;
				if(!partitionModel.getNetworkStats().getGeneral().getEth0().isDhcp())
				{
					if(StringUtils.isEmpty(partitionModel.getNetworkStats().getGeneral().getEth0().getIp()))
					{
						requiredFieldMessage.append("Eth0 Ip Required").append(CaviumConstant.COMMA);						 
					}
				}
				if(partitionModel.getNetworkStats().getGeneral().getEth0().isStaticMac())
				{
					if(StringUtils.isEmpty(partitionModel.getNetworkStats().getGeneral().getEth0().getAddress()))
					{
						requiredFieldMessage.append("Mac Address is required for Eth0 Interface").append(CaviumConstant.COMMA);
					}
				}
			}
			if(partitionModel.getNetworkStats().getGeneral().getEth1()!=null && partitionModel.getNetworkStats().getGeneral().getEth1().isDisableEth1()){
				interfaceDetailsAvaliable=true;
				if(!partitionModel.getNetworkStats().getGeneral().getEth1().isDhcp())
				{
					if(StringUtils.isEmpty(partitionModel.getNetworkStats().getGeneral().getEth1().getIp()))
					{
						requiredFieldMessage.append("Eth01 Ip Required").append(CaviumConstant.COMMA);
					}
				}
				if(partitionModel.getNetworkStats().getGeneral().getEth1().isStaticMac())
				{
					if(StringUtils.isEmpty(partitionModel.getNetworkStats().getGeneral().getEth1().getAddress()))
					{
						requiredFieldMessage.append("Mac Address is required for ETH1 interface").append(CaviumConstant.COMMA);
					}
				}
		} 
			if(!interfaceDetailsAvaliable)
			{
				requiredFieldMessage.append("Either Eth0 or ETH1 is required").append(CaviumConstant.COMMA);
			}
		}else{
				requiredFieldMessage.append("General Tab is Required").append(CaviumConstant.COMMA);
		}
	}
	
	@RequestMapping(value = "getNetworkConfiguration/{partitionId}", method = RequestMethod.GET)
	public Response getPartitionNetworkStatsInfo(@PathVariable("partitionId") String partitionId) {
		PartitionDetailModel partitionDetailModel = new PartitionDetailModel();
		Response response= new Response();
		try {
			partitionDetailModel.setPartitionId(Long.valueOf(partitionId));
			partitionDetailModel=partitionService.getPartitionNetworkStatsInfo(partitionDetailModel);
		
		if(partitionDetailModel!=null && "200".equals(partitionDetailModel.getCode())){
		response.setCode("200");
		response.setMessage("success");
		List<Object> config=new ArrayList<Object>();
		config.add(partitionDetailModel.getMessage());
		response.setId(Long.valueOf(partitionId));
		response.setData(config);
		}else{
			response.setCode(partitionDetailModel.getCode());
			response.setMessage(partitionDetailModel.getErrorMessage());
			response.setId(Long.valueOf(partitionId));		 	
		}
		} catch (Exception e) {
			logger.error("Error occured during getNetworkConfiguration of class PartitionManagementContoller :: "+e.getMessage());
		}
		return response;
	}
	
	@RequestMapping(value = "restore", method = RequestMethod.POST)
	public List<Response> restore(@RequestBody List<PartitionModel> partitionModels){
		List<Response> partitionsResponse=new ArrayList<Response>();
		List<PartitionDetailModel> partitionDetailModels=new ArrayList<PartitionDetailModel>();
		List<PartitionDetailModel> partitionDetailModel=null;
		PartitionDetailModel backpdm=null;
		try {
			 for(PartitionModel partitionModel :partitionModels){
				 Response res= new Response();
				  StringBuilder requireFieldsMessage=new StringBuilder();	
				 checkMandatoryFieldsForRestore(requireFieldsMessage,partitionModel);
				if(StringUtils.isEmpty(String.valueOf(requireFieldsMessage))){
					 ApplianceDetailModel appModel=applianceRepository.getApplianceById(partitionModel.getApplianceDetails().getApplianceId(), StoreType.PERMANENT);
						if(appModel!=null) {
				 PartitionDetailModel pdm= new PartitionDetailModel();
				 if(partitionModel.getSessionClose()!=null){
				 pdm.setSessionClose(partitionModel.getSessionClose());
				}
				 pdm.setNodeId(partitionModel.getNodeId());
				 pdm.setPartitionId(partitionModel.getPartitionId());
				 String errorMessage=null;
					if(!appModel.isCredentialSaved()) {
					if(partitionModel.getDualFactorDetails()!=null) {
						errorMessage=partitionService.validateDualFactorDetails(appModel,partitionModel);
					}else {
						if(appModel.getFipsState().equalsIgnoreCase("3")) {
							errorMessage="dualFactorDetails is required";
						}
					}
					  if(StringUtils.isNotEmpty(partitionModel.getUsername())){
						pdm.setUsername(partitionModel.getUsername());	
					}else{
						errorMessage="userName is required";
						}
					if(StringUtils.isNotEmpty(partitionModel.getPassword())){
						pdm.setPassword(partitionModel.getPassword());
					}else{
					errorMessage="Password is required";
					}
				}
					else{
						errorMessage=checkSavedDetailsExist(appModel,partitionModel);			
					 }
					if(partitionModel.getCheckIntegrity()!=null){
					pdm.setCheckIntegrity(partitionModel.getCheckIntegrity());
					}
				if(StringUtils.isEmpty(errorMessage)){
				partitionModel.getApplianceDetails().setIpAddress(appModel.getIpAddress());
				pdm.setApplianceDetailModel(partitionModel.getApplianceDetails());
				boolean requiredDetails=false;
				
				if(StringUtils.isNotEmpty(partitionModel.getBackupFileId())){
				pdm.setMessage(partitionModel.getBackupFileId());
				pdm.setCode("200");
				partitionDetailModels.add(pdm);
				requiredDetails=true;
				}
				else{
					  requiredDetails=true;
					 String errorMessageForBackup=null;
					  if(partitionModel.getBackupPartitionDetails().getApplianceDetails()!=null){
						  ApplianceDetailModel backupApplainceModel=applianceService.getApplianceById(String.valueOf(partitionModel.getBackupPartitionDetails().getApplianceDetails().getApplianceId()));
							if(partitionModel.getBackupPartitionDetails().getDualFactorDetails()!=null) {
								partitionModel.setDualFactorDetails(null);
								partitionModel.setDualFactorDetails(partitionModel.getBackupPartitionDetails().getDualFactorDetails());
								errorMessageForBackup=partitionService.validateDualFactorDetails(backupApplainceModel,partitionModel);
							}else{
								if(backupApplainceModel.getFipsState().equalsIgnoreCase("3")){
									errorMessageForBackup="dualFactorDetails is required";
								}
							} 
						}
					  if(StringUtils.isEmpty(errorMessageForBackup)) {
						 boolean backupPartionId=true;
					  backpdm= new PartitionDetailModel();
					  if(partitionModel.getBackupPartitionDetails()!=null){
					  backpdm.setFromRestoreUsername(partitionModel.getBackupPartitionDetails().getUserName());
					  backpdm.setFromRestorePassword(partitionModel.getBackupPartitionDetails().getPassword());
					  if(partitionModel.getBackupPartitionDetails().getPartitionId()==null){
						  backupPartionId=false;
					  }else{
					  backpdm.setFromPartitionId(String.valueOf(partitionModel.getBackupPartitionDetails().getPartitionId()));
					  if(partitionModel.getBackupPartitionDetails().getNokey()!=null){
					  backpdm.setNoKey(partitionModel.getBackupPartitionDetails().getNokey());
					  }
					 }
				   }
					  if(!backupPartionId){
							res.setStatus("failed");
							 res.setCode("400");						 
							 res.setMessage("Partition BackUp Id required");
							 partitionsResponse.add(res);		
						}else{
							partitionDetailModels.add(pdm);
						}
				} 
					  else{
							 logger.info("Dual Factor Details Error.");		 
							 res.setStatus("failed");
							 res.setCode("400");						 
							 res.setMessage(errorMessage);
							 partitionsResponse.add(res);	
						}
			}
				if(!requiredDetails){
					res.setStatus("failed");
					 res.setCode("400");						 
					 res.setMessage("Either BackUpFile Id missing or BackUp Partition Detail missing");
					 partitionsResponse.add(res);		
				}
				
				
		}else{
						 logger.info("Dual Factor Details Error.");		 
						 res.setStatus("failed");
						 res.setCode("400");						 
						 res.setMessage(errorMessage);
						 partitionsResponse.add(res);	
					}
				}else{
					res.setStatus("failed");
					res.setCode("404");
					res.setMessage("Appliance does not exist.");
					 partitionsResponse.add(res);
				 }
			 }
			 else {
				 logger.info("Mandatory fields are missing.");		 
				 res.setStatus("failed");
				 res.setCode("400");
				 String errorMessage="Please provide mandatory fields : "+requireFieldsMessage.substring(0,requireFieldsMessage.length()-1);
				 res.setMessage(errorMessage);
				 partitionsResponse.add(res);
				}
			 }
			 if(partitionDetailModels!=null && partitionDetailModels.size()>0){
				 partitionDetailModel=partitionService.partitionRestore(partitionDetailModels, backpdm, null);	 
			for(PartitionDetailModel partitionDetail: partitionDetailModel){
				 Response res= new Response();
				 res.setId(partitionDetail.getPartitionId());
					res.setCode(partitionDetail.getCode());
				if(StringUtils.isNotEmpty(partitionDetail.getMessage())){
					res.setMessage(partitionDetail.getMessage());
				}
				if(StringUtils.isNotEmpty(partitionDetail.getErrorMessage())){
					res.setMessage(partitionDetail.getErrorMessage());		
				 }
				if(StringUtils.isNotEmpty(partitionDetail.getLastOperationStatus()) && (partitionDetail.getLastOperationStatus().equalsIgnoreCase("In-Progress") || partitionDetail.getLastOperationStatus().equalsIgnoreCase("Completed"))){
					res.setStatus("Completed");
				}else{
					res.setStatus("failed");
				}
				partitionsResponse.add(res);
			}
		 }
		} catch (Exception e) {
			logger.error("Error occured during removePartition of class PartitionManagmentContoller :: "+e.getMessage());
		}
		return partitionsResponse;
}
	
	public void checkMandatoryFieldsForRestore(StringBuilder requiredFieldMessage,PartitionModel partitionModel){
	logger.info("Start of checkMandatoryFieldsForRestore Method in PartitionManagementController Class");
	if(partitionModel.getPartitionId()==null){
		requiredFieldMessage.append("Partition Id").append(CaviumConstant.COMMA);
	}		 
	if(partitionModel.getApplianceDetails()!=null && partitionModel.getApplianceDetails().getApplianceId()==null){
		requiredFieldMessage.append("Appliance Id").append(CaviumConstant.COMMA);
	 }
	if(partitionModel.getNodeId()==null){
		requiredFieldMessage.append("Node Id").append(CaviumConstant.COMMA);
	 }
	
	}
	
	@RequestMapping(value = "stopStartCavSever", method = RequestMethod.POST)
	public List<Response> stopStartCavSever(@RequestBody List<PartitionModel> partitionModels){
		List<Response> partitionsResponse=new ArrayList<Response>();
		List<PartitionDetailModel> partitionDetailModels=new ArrayList<PartitionDetailModel>();
		List<PartitionDetailModel> partitionDetailModel=null;
		try {
			String loggedInUser = userAttributes.getlogInUserName();
			 for(PartitionModel partitionModel :partitionModels){
				 Response res= new Response();
				 StringBuilder requireFieldsMessage=new StringBuilder();	
				 checkMandatoryFieldsForCavServer(requireFieldsMessage,partitionModel);
				if(StringUtils.isEmpty(String.valueOf(requireFieldsMessage))){	
					 ApplianceDetailModel appModel=applianceRepository.getApplianceById(partitionModel.getApplianceDetails().getApplianceId(), StoreType.PERMANENT);
						if(appModel!=null) {
				 PartitionDetailModel pdm= new PartitionDetailModel();
				 if(partitionModel.getEnableCavServer()!=null){
					 pdm.setEnableCavServer(partitionModel.getEnableCavServer());
				 }
				 pdm.setPartitionId(partitionModel.getPartitionId());			 
				 String errorMessage=null;
				 if(!appModel.isCredentialSaved()) {
					if(partitionModel.getDualFactorDetails()!=null) {
						errorMessage=partitionService.validateDualFactorDetails(appModel,partitionModel);
					}else {
						if(appModel.getFipsState().equalsIgnoreCase("3")) {
							errorMessage="dualFactorDetails is required";
						}
					}
					if(StringUtils.isNotEmpty(partitionModel.getUsername())){
						pdm.setUsername(partitionModel.getUsername());	
					}else{
						errorMessage="userName is required";
					}
					if(StringUtils.isNotEmpty(partitionModel.getPassword())){
						pdm.setPassword(partitionModel.getPassword());
					}else{
						errorMessage="Password is required";
					}
				 }
				 else{
						errorMessage=checkSavedDetailsExist(appModel,partitionModel);			
					 }
				if(StringUtils.isEmpty(errorMessage)){
				partitionModel.getApplianceDetails().setIpAddress(appModel.getIpAddress());
				pdm.setApplianceDetailModel(partitionModel.getApplianceDetails());
				partitionDetailModels.add(pdm);
				}else{
						 logger.info(errorMessage);		 
						 res.setStatus("failed");
						 res.setCode("400");						 
						 res.setMessage(errorMessage);
						 partitionsResponse.add(res);	
					}
				}else{
					res.setStatus("failed");
					res.setCode("404");
					res.setMessage("Appliance does not exist.");
					 partitionsResponse.add(res);
				 }

			 }
			 else {
				 logger.info("Mandatory fields are missing.");		 
				 res.setStatus("failed");
				 res.setCode("400");
				 String errorMessage="Please provide mandatory fields : "+requireFieldsMessage.substring(0,requireFieldsMessage.length()-1);
				 res.setMessage(errorMessage);
				 partitionsResponse.add(res);
				}
			 }
			 if(partitionDetailModels!=null && partitionDetailModels.size()>0){
				 partitionDetailModel= partitionService.stopStartPartitionCavSever(loggedInUser, partitionDetailModels);			 
			for(PartitionDetailModel partitionDetail: partitionDetailModel){
				 Response res= new Response();
				 res.setId(partitionDetail.getPartitionId());
					res.setCode(partitionDetail.getCode());
				if(StringUtils.isNotEmpty(partitionDetail.getMessage())){
					res.setMessage(partitionDetail.getMessage());
				}
				if(StringUtils.isNotEmpty(partitionDetail.getErrorMessage())){
					res.setMessage(partitionDetail.getErrorMessage());		
				 }
				if(StringUtils.isNotEmpty(partitionDetail.getLastOperationStatus()) && (partitionDetail.getLastOperationStatus().equalsIgnoreCase("In-Progress") || partitionDetail.getLastOperationStatus().equalsIgnoreCase("Completed"))){
					res.setStatus("Completed");
				}else{
					res.setStatus("failed");
				}
				partitionsResponse.add(res);
			}
			 } 
		} catch (Exception e) {
			logger.error("Error occured during stopStartCavSever of class PartitionManagmentContoller :: "+e.getMessage());
		}
		return partitionsResponse;
	}

	 

	@RequestMapping(value = "uploadPartitionCavServerConfigFile", method = RequestMethod.POST)
	public List<Response> uploadPartitionCavServerConfigFile(@RequestBody List<PartitionModel> partitionModels) {
		List<Response> partitionsResponse=new ArrayList<Response>();
		List<PartitionDetailModel> partitionDetailModels=new ArrayList<PartitionDetailModel>();
		List<PartitionDetailModel> partitionDetailModel=null;
		try {
			String loggedInUser = userAttributes.getlogInUserName();
			 for(PartitionModel partitionModel :partitionModels){
				 Response res= new Response();
				 StringBuilder requireFieldsMessage=new StringBuilder();	
				 checkMandatoryFieldsForUploadCavServer(requireFieldsMessage,partitionModel);
				if(StringUtils.isEmpty(String.valueOf(requireFieldsMessage))){	
					 ApplianceDetailModel appModel=applianceRepository.getApplianceById(partitionModel.getApplianceDetails().getApplianceId(), StoreType.PERMANENT);
						if(appModel!=null) {
				 PartitionDetailModel pdm= new PartitionDetailModel();
				 pdm.setPartitionId(partitionModel.getPartitionId());
				 String errorMessage=null;
					if(!appModel.isCredentialSaved()) {
					if(partitionModel.getDualFactorDetails()!=null) {
						errorMessage=partitionService.validateDualFactorDetails(appModel,partitionModel);
					}else {
						if(appModel.getFipsState().equalsIgnoreCase("3")) {
							errorMessage="dualFactorDetails is required";
						}
					}
					 if(StringUtils.isNotEmpty(partitionModel.getUsername())){
									pdm.setUsername(partitionModel.getUsername());	
					}else{
						errorMessage="userName is required";
								}
					if(StringUtils.isNotEmpty(partitionModel.getPassword())){
							pdm.setPassword(partitionModel.getPassword());
					}else{
						errorMessage="Password is required";
						}
					}
					else{
						errorMessage=checkSavedDetailsExist(appModel,partitionModel);			
					 }
				if(StringUtils.isEmpty(errorMessage)){
				partitionModel.getApplianceDetails().setIpAddress(appModel.getIpAddress());
				pdm.setApplianceDetailModel(partitionModel.getApplianceDetails());
				pdm.setMessage(partitionModel.getConfigFileId());
				pdm.setCode("200");
				partitionDetailModels.add(pdm);				 
				}else{
						 logger.info("Dual Factor Details Error.");		 
						 res.setStatus("failed");
						 res.setCode("400");						 
						 res.setMessage(errorMessage);
						 partitionsResponse.add(res);	
					}
				}
				 else{
					res.setStatus("failed");
					res.setCode("404");
					res.setMessage("Appliance does not exist.");
					 partitionsResponse.add(res);
				 }
			 }
			 else {
				 logger.info("Mandatory fields are missing.");		 
				 res.setStatus("failed");
				 res.setCode("400");
				 String errorMessage="Please provide mandatory fields : "+requireFieldsMessage.substring(0,requireFieldsMessage.length()-1);
				 res.setMessage(errorMessage);
				 partitionsResponse.add(res);
				}
			 }
			 if(partitionDetailModels!=null && partitionDetailModels.size()>0){
				 partitionDetailModel= partitionService.uploadCavServerConfigFile(loggedInUser, partitionDetailModels);			 
			for(PartitionDetailModel partitionDetail: partitionDetailModel){
				 Response res= new Response();
				 res.setId(partitionDetail.getPartitionId());
					res.setCode(partitionDetail.getCode());
				if(StringUtils.isNotEmpty(partitionDetail.getMessage())){
					res.setMessage(partitionDetail.getMessage());
				}
				if(StringUtils.isNotEmpty(partitionDetail.getErrorMessage())){
					res.setMessage(partitionDetail.getErrorMessage());		
				 }
				if(StringUtils.isNotEmpty(partitionDetail.getLastOperationStatus()) && (partitionDetail.getLastOperationStatus().equalsIgnoreCase("In-Progress") || partitionDetail.getLastOperationStatus().equalsIgnoreCase("Completed"))){
					res.setStatus("Completed");
				}else{
					res.setStatus("failed");
				}
				partitionsResponse.add(res);
			}
			 } 
		} catch (Exception e) {
			logger.error("Error occured during removePartition of class PartitionManagmentContoller :: "+e.getMessage());
		}
		return partitionsResponse;
	}
	@RequestMapping(value = "downloadPartitionCavServerConfigFile", method = RequestMethod.POST)
	public final void downloadPartitionCavServerConfigFile(@RequestBody List<PartitionModel> partitionModels,HttpServletResponse response){

		ArrayList<File> files = new ArrayList<>();
		BufferedOutputStream bufferedOutputStream =null;
		ZipOutputStream zipOutputStream=null;
		PrintWriter pw =null;
		try {
			boolean headerSet=false;
			bufferedOutputStream = new BufferedOutputStream(response.getOutputStream());
			pw = new PrintWriter(bufferedOutputStream);
			zipOutputStream   = new ZipOutputStream(bufferedOutputStream);
			boolean isValidation=false;
			List<Response> listRespone=new ArrayList<Response>();
			for(PartitionModel partitionModel: partitionModels) {
				try {
			  if(!isValidation){
				 listRespone= checkMandatoryFieldsForBackUp(partitionModels);
			 }
				if(listRespone!=null && listRespone.size()==0){
						isValidation=true;
					 PartitionDetailModel pdm= new PartitionDetailModel();
					  pdm.setPartitionId(partitionModel.getPartitionId());
					 ApplianceDetailModel appModel=applianceService.getApplianceById(String.valueOf(partitionModel.getApplianceDetails().getApplianceId()));
						if(StringUtils.isNotEmpty(partitionModel.getUsername())){
							pdm.setUsername(partitionModel.getUsername());	
						}
						if(StringUtils.isNotEmpty(partitionModel.getPassword())){
							pdm.setPassword(partitionModel.getPassword());
						}					
					partitionModel.getApplianceDetails().setIpAddress(appModel.getIpAddress());
					pdm.setApplianceDetailModel(partitionModel.getApplianceDetails());
					
					CaviumResponseModel responseModel=getCaviumResponseModel();
						String operation="downloaCavServerConfig";
						PartitionDetailModel pdmm=partitionRepository.findOne(pdm.getPartitionId());
						pdm.setPartitionName(pdmm.getPartitionName());
						responseModel = partitionService.downloadConfigFileURL(pdm,"download_cav_server_config",operation);
						logger.info(" Start of downloadPartitionCavServerConfigFile method of PartitionController");
						File file=null;
						if(!StringUtils.isEmpty(responseModel.getResponseMessage()) && responseModel.getResponseCode().equalsIgnoreCase("200")) {
							String applianceName="";
							if(pdmm!=null && pdmm.getApplianceDetailModel()!=null && pdmm.getApplianceDetailModel().getApplianceName()!=null) {
								applianceName=pdmm.getApplianceDetailModel().getApplianceName();
							}
							file=partitionService.downloadConfigFile(responseModel.getResponseMessage(), pdm.getPartitionName(),applianceName);
							if(file!=null) {
								if(!headerSet){
									response.setContentType("application/zip");
									response.setStatus(HttpServletResponse.SC_OK);
									response.addHeader("Content-Disposition", "attachment; filename=\"CavServerConfigFile.zip\"");
									headerSet=true;
								}
								files.add(file);
							}
						}
												
			} 
			 else{
						response.setContentType("text/html"); 				
						pw.write(StringUtils.join(listRespone, "|")); 
						pw.close();
						headerSet=true;
						break;
			 	}
				}catch (Exception e) {				
					logger.error("Error occured during downloadPartitionCavServerConfigFile of class PartitionManagementContoller"+e.getMessage());
				}
			}
			if(!headerSet){
				response.setContentType("text/html"); 
				pw.write("Error occured during download file"); 
				pw.close();
			}
			for (File file : files) {
				//new zip entry and copying inputstream with file to zipOutputStream, after all closing streams
				zipOutputStream.putNextEntry(new ZipEntry(file.getName()));
				FileInputStream fileInputStream = new FileInputStream(file);

				IOUtils.copy(fileInputStream, zipOutputStream);

				fileInputStream.close();
				zipOutputStream.closeEntry();
			}
			
			try{
				if (zipOutputStream != null) {
					zipOutputStream.finish();
					zipOutputStream.flush();
					IOUtils.closeQuietly(zipOutputStream);
				}
				if(bufferedOutputStream!=null){
					IOUtils.closeQuietly(bufferedOutputStream);
				}
			}catch (Exception e) {
				logger.error("error coming while closing  zipOutputStream in downloadCavServerConfigFile method of PartitionManagementController :: "+e.getMessage());	 
			}
		}
		catch (Exception e) {	 
			logger.error("Error occured during downloadPartitionCavServerConfigFile of class PartitionManagementController ::" +e.getMessage());
		}
		finally {

			for (File file : files) 
				if(file!=null){
					try{
						Files.deleteIfExists(Paths.get(file.getAbsolutePath()));
					}catch (Exception e) {
						logger.error("Error while deleting certificate file  in downloadPartitionCavServerConfigFile method of PartitionManagementController :: " + e.getMessage()); 
					}
				}
			if(pw!=null){
				pw.close();
			}
			try{
				if (zipOutputStream != null) {
					zipOutputStream.finish();
					zipOutputStream.flush();
					IOUtils.closeQuietly(zipOutputStream);
				}
				if(bufferedOutputStream!=null){
					IOUtils.closeQuietly(bufferedOutputStream);
				}
			}catch (Exception e) {
				logger.error("error coming while closing  zipOutputStream in downloadPartitionCavServerConfigFile method of PartitionManagementController :: "+e.getMessage());	 
			}
		}
	}
	 
	 
	
	@RequestMapping(value = "resetPartitionCavServerConfig", method = RequestMethod.POST)
	public List<Response> resetPartitionCavServerConfig(@RequestBody List<PartitionModel> partitionModels){
		List<Response> partitionsResponse=new ArrayList<Response>();
		List<PartitionDetailModel> partitionDetailModels=new ArrayList<PartitionDetailModel>();
		List<PartitionDetailModel> partitionDetailModel=null;
		try {
			String loggedInUser = userAttributes.getlogInUserName();
			 for(PartitionModel partitionModel :partitionModels){
				 Response res= new Response();
				 StringBuilder requireFieldsMessage=new StringBuilder();	
				 checkMandatoryFields(requireFieldsMessage,partitionModel);
				if(StringUtils.isEmpty(String.valueOf(requireFieldsMessage))){	
					ApplianceDetailModel appModel=applianceRepository.getApplianceById(partitionModel.getApplianceDetails().getApplianceId(), StoreType.PERMANENT);
					if(appModel!=null) {
				 PartitionDetailModel pdm= new PartitionDetailModel();
				 if(partitionModel.getEnableCavServer()!=null){
					 pdm.setEnableCavServer(partitionModel.getEnableCavServer());
				 }
				 pdm.setPartitionId(partitionModel.getPartitionId());		
				 String errorMessage=null;
					if(!appModel.isCredentialSaved()) {
						if(partitionModel.getDualFactorDetails()!=null) {
							errorMessage=partitionService.validateDualFactorDetails(appModel,partitionModel);
						}else {
							if(appModel.getFipsState().equalsIgnoreCase("3")) {
								errorMessage="dualFactorDetails is required";
							}
						}
						 if(StringUtils.isNotEmpty(partitionModel.getUsername())){
										pdm.setUsername(partitionModel.getUsername());	
						}else{
							errorMessage="userName is required";
									}
						if(StringUtils.isNotEmpty(partitionModel.getPassword())){
								pdm.setPassword(partitionModel.getPassword());
						}else{
							errorMessage="Password is required";
							}
						}
					else{
						errorMessage=checkSavedDetailsExist(appModel,partitionModel);			
					 }
				if(StringUtils.isEmpty(errorMessage)){
				partitionModel.getApplianceDetails().setIpAddress(appModel.getIpAddress());
				pdm.setApplianceDetailModel(partitionModel.getApplianceDetails());
				partitionDetailModels.add(pdm);
				}else{
						 logger.info(errorMessage);		 
						 res.setStatus("failed");
						 res.setCode("400");						 
						 res.setMessage(errorMessage);
						 partitionsResponse.add(res);	
					}
					 }else{
							res.setStatus("failed");
							res.setCode("404");
							res.setMessage("Appliance does not exist.");
							 partitionsResponse.add(res);
						 }
			 }
			 else {
				 logger.info("Mandatory fields are missing.");		 
				 res.setStatus("failed");
				 res.setCode("400");
				 String errorMessage="Please provide mandatory fields : "+requireFieldsMessage.substring(0,requireFieldsMessage.length()-1);
				 res.setMessage(errorMessage);
				 partitionsResponse.add(res);
				}
			 }
			 if(partitionDetailModels!=null && partitionDetailModels.size()>0){
				 partitionDetailModel= partitionService.resetCavServerConfig(loggedInUser, partitionDetailModels);			 
			for(PartitionDetailModel partitionDetail: partitionDetailModel){
				 Response res= new Response();
				 res.setId(partitionDetail.getPartitionId());
					res.setCode(partitionDetail.getCode());
				if(StringUtils.isNotEmpty(partitionDetail.getMessage())){
					res.setMessage(partitionDetail.getMessage());
				}
				if(StringUtils.isNotEmpty(partitionDetail.getErrorMessage())){
					res.setMessage(partitionDetail.getErrorMessage());		
				 }
				if(StringUtils.isNotEmpty(partitionDetail.getLastOperationStatus()) && (partitionDetail.getLastOperationStatus().equalsIgnoreCase("In-Progress") || partitionDetail.getLastOperationStatus().equalsIgnoreCase("Completed"))){
					res.setStatus("Completed");
				}else{
					res.setStatus("failed");
				}
				partitionsResponse.add(res);
			}
			 } 
		} catch (Exception e) {
			logger.error("Error occured during removePartition of class PartitionManagmentContoller :: "+e.getMessage());
		}
		return partitionsResponse;
	}
	
	public void  checkMandatoryFieldsForUploadCavServer(StringBuilder requiredFieldMessage,PartitionModel partitionModel){
		logger.info("Start of checkMandatoryFieldForRemovePartition Method in PartitionManagementController Class");
		if(partitionModel.getPartitionId()==null){
			requiredFieldMessage.append("Partition Id").append(CaviumConstant.COMMA);
		}		 
		if(partitionModel.getApplianceDetails()!=null && partitionModel.getApplianceDetails().getApplianceId()==null){
			requiredFieldMessage.append("Appliance Id").append(CaviumConstant.COMMA);
		}	
		if(partitionModel.getConfigFileId()==null)
		{
			requiredFieldMessage.append("ConfigFile Id").append(CaviumConstant.COMMA);
		}
	}
	
	public String checkSavedDetailsExist(ApplianceDetailModel appModel,PartitionModel partitionModel){
		String errorMessage=null;
		String loggedInUser = userAttributes.getlogInUserName();
		 if(appModel.getFipsState().equalsIgnoreCase("3")){
			 List<DualFactorUsersRelationshipModel> dfmodelList=dfUsersRelationshipRepository.getDualFactorDetails(loggedInUser, appModel.getApplianceId());								
				if(dfmodelList!=null && dfmodelList.size()==0){
					 if(partitionModel.getDualFactorDetails()==null){
						 errorMessage="please provide Dualfactor details;";
						}
						if(partitionModel.getDualFactorDetails()!=null) {
							errorMessage=partitionService.validateDualFactorDetails(appModel,partitionModel);
						 }
				}else{
					if(partitionModel.getDualFactorDetails()!=null){
						errorMessage="dualFactorDetails is not required";
					}
				}
			}
		 if(StringUtils.isNotEmpty(partitionModel.getUsername())){
			errorMessage="userName is not required";
		}
		if(StringUtils.isNotEmpty(partitionModel.getPassword())){
			errorMessage="Password is not required";
		}
	return errorMessage;
	}
}