package com.cavium.rest.controller.fileupload;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cavium.model.appliance.DualFactorUsersRelationshipModel;
import com.cavium.rest.model.fileupload.FileUploadDetail;
import com.cavium.service.fileupload.FileUploadService;
import com.cavium.utill.CaviumConstant;
import com.cavium.utill.CaviumResponseModel;
import com.cavium.utill.CaviumUtil;
import com.cavium.utill.FileUploadResponseModel;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/rest")
public class FileUploadController {


	@Autowired
	private	FileUploadService fileUploadService;

	// logger - instance of application log.
	private Logger logger = Logger.getLogger(this.getClass());

	@RequestMapping(value = "fileUpload", method = RequestMethod.POST,consumes = {"multipart/form-data"})
	public List<FileUploadResponseModel> handleFileUpload(
			@RequestParam("uploadfiles") MultipartFile[] uploadingFiles,@RequestParam("filesdetails") String uploadingFilesDetails ) throws IOException {
		List<FileUploadResponseModel> response= new ArrayList<FileUploadResponseModel>();
		FileUploadDetail fileUploadDetail=null;
		try{
			if(uploadingFiles!=null && uploadingFiles.length > 0 && uploadingFilesDetails!=null && !uploadingFilesDetails.isEmpty()) {
			ObjectMapper objectMapper = new ObjectMapper();
			JSONArray fileDetails = new JSONArray(uploadingFilesDetails);

			for (int index = 0; index < fileDetails.length(); index++)
			{ 
				FileUploadResponseModel fileUploadResponseModel= new FileUploadResponseModel();
				try{
					JSONObject fileDetail = fileDetails.getJSONObject(index);
					fileUploadDetail=objectMapper.readValue(String.valueOf(fileDetail),FileUploadDetail.class);
					StringBuilder requiredFieldMessage= new StringBuilder();
					checkMandatoryField(requiredFieldMessage,fileUploadDetail);

					if(StringUtils.isEmpty(String.valueOf(requiredFieldMessage))) {
						
						boolean isIpValid=CaviumUtil.validateIPAddress(fileUploadDetail.getApplianceIp());
						if(isIpValid){
							for(MultipartFile uploadingFile:uploadingFiles){
								if(fileUploadDetail.getFilename().equals(uploadingFile.getOriginalFilename())){
									File file=	CaviumUtil.convertMultipartFileIntoNewFile(uploadingFile);
									
									DualFactorUsersRelationshipModel dualFactor=null;
									if(!StringUtils.isEmpty(fileUploadDetail.getDualFactorPortNo()) && !StringUtils.isEmpty(fileUploadDetail.getDualFactorKeyFileId()) && !StringUtils.isEmpty(fileUploadDetail.getDualFactorCertificateId())) {
										dualFactor=new DualFactorUsersRelationshipModel();
										dualFactor.setDualFactorAuthServerPortNo(fileUploadDetail.getDualFactorPortNo());
										dualFactor.setDualFactorCertificateId(fileUploadDetail.getDualFactorCertificateId());
										dualFactor.setDualFactorKeyFileId(fileUploadDetail.getDualFactorKeyFileId());
									}
									CaviumResponseModel caviumResponseModel=fileUploadService.uploadFile(file,fileUploadDetail.getUsername(),fileUploadDetail.getPassword(),fileUploadDetail.getType(),fileUploadDetail.getApplianceIp(),dualFactor);
									if(caviumResponseModel!=null){
										if("200".equals(caviumResponseModel.getResponseCode())){
											fileUploadResponseModel.setCode(caviumResponseModel.getResponseCode());
											fileUploadResponseModel.setUploadedFileID(caviumResponseModel.getResponseMessage());
											fileUploadResponseModel.setStatus("Success");
											fileUploadResponseModel.setFilename(fileUploadDetail.getFilename());
										}
										else{
											fileUploadResponseModel.setCode(caviumResponseModel.getResponseCode());			 
											fileUploadResponseModel.setStatus(caviumResponseModel.getResponseMessage());
											fileUploadResponseModel.setFilename(fileUploadDetail.getFilename());
										}
									}
								}
							}
						}else{
							fileUploadResponseModel.setCode("400");
							fileUploadResponseModel.setStatus("Appliance Ip is not Valid for file " + fileUploadResponseModel.getFilename());
						 }
					}
					else{
						fileUploadResponseModel.setCode("400");
						if(StringUtils.isNotEmpty(fileUploadResponseModel.getFilename())){
							fileUploadResponseModel.setStatus("Mandatory fields missing : "+ requiredFieldMessage.substring(0,requiredFieldMessage.length()-1) +" for file " + fileUploadResponseModel.getFilename());	
						}else{
							fileUploadResponseModel.setStatus("Mandatory Fields missing : "+requiredFieldMessage.substring(0,requiredFieldMessage.length()-1) );		
						}
					 
					}
					response.add(fileUploadResponseModel);
				}catch (JsonParseException | JsonMappingException | JSONException e) {
					fileUploadResponseModel.setCode("400");
					fileUploadResponseModel.setStatus("Bad Request");
					response.add(fileUploadResponseModel);
					logger.error("Json Parsing error while parsing json to FileUploadDetail Object :: " + e.getMessage());
				} 
			}
		}else {
				if(uploadingFilesDetails==null || uploadingFilesDetails.isEmpty()) {
					logger.error("Please provide upload file details.");
					FileUploadResponseModel fileUploadResponseModel= new FileUploadResponseModel();
					fileUploadResponseModel.setCode("412");
					fileUploadResponseModel.setStatus("filesdetails is required.");
					response.add(fileUploadResponseModel);
				}
				if(uploadingFiles==null || uploadingFiles.length==0) {
					logger.error("Please provide file to upload");
					FileUploadResponseModel fileUploadResponseModel= new FileUploadResponseModel();
					fileUploadResponseModel.setCode("412");
					fileUploadResponseModel.setStatus("uploadfiles is required.");
					response.add(fileUploadResponseModel);
				}
			}
		}
		catch (JSONException e) {
			logger.error("Error in filesdetails Attribute of Request in handleFileUpload Method :: " + e.getMessage());
			FileUploadResponseModel fileUploadResponseModel= new FileUploadResponseModel();
			fileUploadResponseModel.setCode("400");
			fileUploadResponseModel.setStatus("Bad Request");
			response.add(fileUploadResponseModel);
		}
		catch (Exception e) {
			logger.error("Error in fileUpload Method :: " + e.getMessage());
			FileUploadResponseModel fileUploadResponseModel= new FileUploadResponseModel();
			fileUploadResponseModel.setCode("400");
			fileUploadResponseModel.setStatus("error");
			response.add(fileUploadResponseModel);
		}

		return response;
	}

	public void  checkMandatoryField(StringBuilder requiredFieldMessage,FileUploadDetail fileUploadDetail){

		if(StringUtils.isEmpty(fileUploadDetail.getFilename())){
			requiredFieldMessage.append(CaviumConstant.FILE_NAME).append(CaviumConstant.COMMA);
		}
		if(StringUtils.isEmpty(fileUploadDetail.getUsername())){
			requiredFieldMessage.append(CaviumConstant.CRYPTO_OFFICER_NAME).append(CaviumConstant.COMMA);	
		}
		if(StringUtils.isEmpty(fileUploadDetail.getPassword())){
			requiredFieldMessage.append(CaviumConstant.CRYPTO_OFFICER_PASSWORD).append(CaviumConstant.COMMA);	
		}
		if(StringUtils.isEmpty(fileUploadDetail.getType())){
			requiredFieldMessage.append(CaviumConstant.OPERATION_TYPE).append(CaviumConstant.COMMA);
		}
		if(StringUtils.isEmpty(fileUploadDetail.getApplianceIp())){
			requiredFieldMessage.append(CaviumConstant.APPLIANCE_IP).append(CaviumConstant.COMMA);
		}
	}


}