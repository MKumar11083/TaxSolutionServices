package com.cavium.rest.controller.appliance;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.core.env.Environment;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cavium.model.appliance.ApplianceDeleteFailureModel;
import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.appliance.DualFactorAuthDetailModel;
import com.cavium.model.appliance.DualFactorUsersRelationshipModel;
import com.cavium.model.appliance.FirmwareUpgradeDetailModel;
import com.cavium.model.appliance.InitializeApplianceDetailModel;
import com.cavium.model.appliance.InitializeAppliancesRelationshipModel;
import com.cavium.model.appliance.StoreType;
import com.cavium.pojo.MCOKeyCertificateDetails;
import com.cavium.pojo.ManageCertificatesDetails;
import com.cavium.pojo.UserAttributes;
import com.cavium.pojo.logs.LogsDetails;
import com.cavium.repository.appliance.ApplianceRepository;
import com.cavium.repository.appliance.DualFactorUsersRelationshipRepository;
import com.cavium.repository.appliance.InitializeAppliancesRelationshipReposiotry;
import com.cavium.repository.appliance.InitializeRepository;
import com.cavium.repository.partition.PartitionRepository;
import com.cavium.rest.common.utill.Response;
import com.cavium.rest.model.appliance.ApplianceModel;
import com.cavium.rest.model.appliance.HSMOwnerCertificatesModel;
import com.cavium.rest.model.appliance.InitializeApplianceModel;
import com.cavium.rest.model.appliance.MCOKeyDetails;
import com.cavium.rest.model.appliance.Network;
import com.cavium.rest.model.appliance.Timezone;
import com.cavium.rest.model.appliance.Zone;
import com.cavium.rest.service.appliance.ApplianceManagementService;
import com.cavium.service.alerts.AlertsService;
import com.cavium.service.appliance.ApplianceService;
import com.cavium.utill.CaviumConstant;
import com.cavium.utill.CaviumResponseModel;
import com.cavium.utill.CaviumUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.fasterxml.jackson.databind.type.TypeFactory;

@RestController
@RequestMapping("rest")
public class ApplianceManagementController {
	
	private Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	private ApplianceService applianceService;
	
	@Autowired
	private ApplianceManagementService applianceManagementService;
	
	@Autowired
	private ApplianceRepository applianceRepository;
	
	@Autowired
	private UserAttributes userAttributes;
	
	@Autowired 
	private AlertsService alertsService;
	
	@Autowired
	private InitializeAppliancesRelationshipReposiotry initializeAppliancesRelationshipReposiotry;
	
	@Autowired
	private PartitionRepository partitionRepository;
	
	@Autowired
	private InitializeRepository initializeRepository;
	@Autowired
	private DualFactorUsersRelationshipRepository dfUsersRelationshipRepository;
	
	@Lookup
	public CaviumResponseModel getCaviumResponseModel() {
		return null;
	}

	@Autowired
	Environment env;
	
	@RequestMapping(value = "addAppliance", method = RequestMethod.POST)
	public List<Response> addAppliance(@RequestBody List<ApplianceModel>  listOfApplianceModel) {
		logger.info("inside validateCredentialsByLoginHSM");
		List<Response> response=new ArrayList<>();
		List<ApplianceDetailModel> listOfApp=new ArrayList<>();
		try {
			validateGenerateCaviumResponse(listOfApplianceModel, response, listOfApp);
		} catch (Exception e) {
			logger.error("error occured during validateCredentialsByLoginHSM" + e.getMessage());
		}
		return response;

	}

	/**
	 * @param listOfApplianceModel
	 * @param response
	 * @param listOfApp
	 * @param requiredFiledNotAvailable
	 * @throws NumberFormatException
	 */
	public void validateGenerateCaviumResponse(List<ApplianceModel> listOfApplianceModel, List<Response> response,
			List<ApplianceDetailModel> listOfApp)
			throws NumberFormatException {
		String loggedInUser = userAttributes.getlogInUserName();
		for(ApplianceModel app: listOfApplianceModel) {
			StringBuilder requiredFiledNotAvailable = new StringBuilder();
			ApplianceDetailModel applianceDetailModel=new ApplianceDetailModel();
			/**
			 * Validating form fields
			 */
			applianceDetailModel=validateFiledsForAddAppliance(app, applianceDetailModel, requiredFiledNotAvailable);
			if(StringUtils.isEmpty(requiredFiledNotAvailable.toString())) {
				
				if(app.getDualFactorDetails()!=null && !StringUtils.isEmpty(app.getDualFactorDetails().getDualFactorAuthServerPortNo()) && !StringUtils.isEmpty(app.getFipsState()) && app.getFipsState().equalsIgnoreCase("3")) {
					DualFactorUsersRelationshipModel dual=app.getDualFactorDetails();
					dual.setApplianceIp(app.getNetwork().getIpAddress());
					dual.setUserId(loggedInUser);
					applianceManagementService.saveDualFactorDetails(dual);
					applianceDetailModel.setFipsState("3");
				}else {
					if(!StringUtils.isEmpty(app.getFipsState()) && app.getFipsState().equalsIgnoreCase("0")) {
						applianceDetailModel.setFipsState("0");
					}
					if(!StringUtils.isEmpty(app.getFipsState()) && app.getFipsState().equalsIgnoreCase("-1")) {
						applianceDetailModel.setFipsState("-1");
					}
				}
				applianceDetailModel = applianceService.validateAppliance(applianceDetailModel);
				Response res=new Response();
				if(!StringUtils.isEmpty(applianceDetailModel) && applianceDetailModel.getCode().equalsIgnoreCase("200")) {
					listOfApp.add(applianceDetailModel);
				}else {
					res.setStatus("Failed");
					res.setCode(applianceDetailModel.getCode());
					res.setName(applianceDetailModel.getApplianceName());
					res.setMessage(applianceDetailModel.getErrorMessage());
					response.add(res);
				}
			}else {
				Response res = generateFailedResponse(requiredFiledNotAvailable, applianceDetailModel);
				String message=res.getMessage()+".";
				res.setMessage(message);
				response.add(res);
			}
		}
		if(listOfApp!=null && listOfApp.size() > 0) {
			CaviumResponseModel	caviumres=applianceService.createAppliance(listOfApp);
			if(caviumres!=null && caviumres.getResponseCode().equalsIgnoreCase("200")) {
				verifyApplicanceCreatedSuccess(response, listOfApp);
			}
		}
	}

	/**
	 * @param requiredFiledNotAvailable
	 * @param applianceDetailModel
	 * @return
	 */
	public Response generateFailedResponse(StringBuilder requiredFiledNotAvailable,
			ApplianceDetailModel applianceDetailModel) {
		Response res=new Response();
		res.setStatus("Failed");
		res.setCode("412");
		if(!StringUtils.isEmpty(applianceDetailModel.getApplianceName())) {
			res.setName(applianceDetailModel.getApplianceName());
		}
		String message=requiredFiledNotAvailable.toString();
		res.setMessage(message);
		return res;
	}

	/**
	 * @param response
	 * @param listOfApp
	 */
	public void verifyApplicanceCreatedSuccess(List<Response> response, List<ApplianceDetailModel> listOfApp) {
		for(ApplianceDetailModel appdd: listOfApp) {
			Response res=new Response();
			List<ApplianceDetailModel> db=applianceRepository.getApplianceExists(appdd.getIpAddress());
			if(db.size() > 0) {
				ApplianceDetailModel appp=(ApplianceDetailModel)db.get(0);
				res.setStatus("success");
				res.setCode("201");
				res.setName(appp.getApplianceName());
				res.setId(appp.getApplianceId());
				res.setMessage("Appliance created successfully.");
				response.add(res);
			}
		}
	}

	/**
	 * @param requiredFiledNotAvailable
	 */
	public void generateRequiredField(StringBuilder requiredFiledNotAvailable, String fieldName) {
		if(requiredFiledNotAvailable.length() > 0) {
			requiredFiledNotAvailable.append(",");
		}
		requiredFiledNotAvailable.append(fieldName);
	}
	
	@RequestMapping(value = "initializeAppliance", method = RequestMethod.PUT)
	public List<Response> initializeAppliance(@RequestBody List<InitializeApplianceModel>  initializeApplianceModels) {
		logger.info("Start of initializeAppliance Method");
		List<ApplianceDetailModel> applianceDetailModels=null;
		List<Response> responseList=new ArrayList<Response>();
		String loggedInUser = userAttributes.getlogInUserName();
		String message="";
		for(InitializeApplianceModel initializeApplianceModel : initializeApplianceModels){

			InitializeApplianceDetailModel initializeApplianceDetailModel = new InitializeApplianceDetailModel();
			StringBuilder requireFieldsMessage=new StringBuilder();	

			checkMandatoryField(requireFieldsMessage,initializeApplianceModel);

			if(StringUtils.isEmpty(String.valueOf(requireFieldsMessage))){
				logger.info("All mandatory Fields are provided");	
				if(initializeApplianceModel.getApplianceId()!=null){
					Long id=Long.valueOf(initializeApplianceModel.getApplianceId());
					ApplianceDetailModel  applianceDetail = applianceRepository.getApplianceById(id,StoreType.PERMANENT);
					if(applianceDetail!=null) {
						if(applianceDetail.isApplianceinitialized()){
							Response res=new Response();
							res.setStatus("failed");
							res.setCode("412");
							res.setMessage("Appliance "+applianceDetail.getApplianceName()+" already initialized.");
							responseList.add(res);	
						}else{
						initializeApplianceDetailModel.setUserName(initializeApplianceModel.getUsername());
						initializeApplianceDetailModel.setPassword(initializeApplianceModel.getPassword());
						initializeApplianceDetailModel.setCryptoOfficerName(initializeApplianceModel.getInitData().getCryptoOfficerName());
						initializeApplianceDetailModel.setCryptoOfficerPassword(initializeApplianceModel.getInitData().getCryptoOfficerPassword());
						initializeApplianceDetailModel.setConfirmCryptoOfficerpassword(initializeApplianceModel.getInitData().getCryptoOfficerPassword());
						initializeApplianceDetailModel.setAuthenticationLevel(initializeApplianceModel.getInitData().getAuthenticationLevel());
						initializeApplianceDetailModel.setCertAuthentication(initializeApplianceModel.getInitData().getCertAuth());
						initializeApplianceDetailModel.setFipsState(initializeApplianceModel.getInitData().getFipsState());
						if(!StringUtils.isEmpty(initializeApplianceModel.getInitData().getHsmLabel())){
							initializeApplianceDetailModel.setHsmLabel(initializeApplianceModel.getInitData().getHsmLabel());
						}
						if(!StringUtils.isEmpty(initializeApplianceModel.getInitData().isHsmAuditLog())){
							initializeApplianceDetailModel.setHsmAuditLog(initializeApplianceModel.getInitData().isHsmAuditLog());
						}
						if(!StringUtils.isEmpty(initializeApplianceModel.getInitData().getLoginFailureCount())){
							initializeApplianceDetailModel.setLoginFailureCount(initializeApplianceModel.getInitData().getLoginFailureCount());
						}
						if(!StringUtils.isEmpty(initializeApplianceModel.getInitData().getMaximumPasswordLength())){
							initializeApplianceDetailModel.setMaximumPasswordLength(initializeApplianceModel.getInitData().getMaximumPasswordLength());
						}
						if(!StringUtils.isEmpty(initializeApplianceModel.getInitData().getMinimumPasswordLength())){
							initializeApplianceDetailModel.setMinimumPasswordLength(initializeApplianceModel.getInitData().getMinimumPasswordLength());
						}
						if(initializeApplianceModel.getDualFactorDetails()!=null && initializeApplianceModel.getInitData().getAuthenticationLevel()==1){
							
							DualFactorUsersRelationshipModel dual=initializeApplianceModel.getDualFactorDetails();
							dual.setApplianceIp(applianceDetail.getIpAddress());
							dual.setApplianceId(applianceDetail.getApplianceId());
							dual.setUserId(loggedInUser);
							applianceManagementService.saveDualFactorDetails(dual);
						}			
						initializeApplianceDetailModel.getApplianceDetailModels().add(applianceDetail);		 
						try{
							applianceDetailModels=	applianceService.initilizeAppliance(loggedInUser,initializeApplianceDetailModel);
							if(applianceDetailModels!=null){
								for (ApplianceDetailModel applianceDetailModel: applianceDetailModels) {
									Response response= new Response();
									response.setName(applianceDetailModel.getApplianceName());
									response.setId(applianceDetailModel.getApplianceId());
									if("200".equals(applianceDetailModel.getCode())){						
										response.setMessage(applianceDetailModel.getMessage());
										response.setStatus("success");
									}else{
										response.setStatus("error");
										response.setMessage(applianceDetailModel.getErrorMessage());
									}
									response.setCode(applianceDetailModel.getCode());
									responseList.add(response);
								}
							}
						}catch (RuntimeException e) {
							logger.error("error in initializeAppliance Appliance :" + e.getMessage());
							if("CaviumNetworkError".equals(e.getMessage())){
								message="CaviumNetworkError" ;
							}else{
								message=e.getMessage() ;
							}
						}
						if(applianceDetailModels==null){
							if(initializeApplianceDetailModel.getApplianceDetailModels()!=null && initializeApplianceDetailModel.getApplianceDetailModels().size()>0){
								for (Iterator<ApplianceDetailModel> itr = initializeApplianceDetailModel.getApplianceDetailModels().iterator(); itr.hasNext();) {
									ApplianceDetailModel applianceDetailModel = (ApplianceDetailModel) itr.next();
									Response response= new Response();
									response.setName(applianceDetailModel.getApplianceName());
									response.setId(applianceDetailModel.getApplianceId());
									if("CaviumNetworkError".equals(message)){
										response.setCode("408");
										response.setStatus("Error");
										response.setMessage("Appliance is not reachable.");							 
										alertsService.createAlert(loggedInUser,"Device "+applianceDetailModel.getApplianceName()+"  try to perofrm initialize by "+loggedInUser+ " did not initialize due to connection error",applianceDetailModel.getApplianceName(),applianceDetailModel.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
									}else{
										if(message.contains(applianceDetailModel.getApplianceName())){
											String newmessage = message.replaceAll(applianceDetailModel.getApplianceName(),"");
											response.setMessage(newmessage);
											response.setStatus("Error");
											response.setCode("412");							 
											alertsService.createAlert(loggedInUser,"Device "+applianceDetailModel.getApplianceName()+"  try to perofrm initialize by "+loggedInUser+ " did not initialize due to ::"+newmessage,applianceDetailModel.getApplianceName(),applianceDetailModel.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
										}
										else
										{
											response.setCode("412");
											response.setStatus("Error");
											response.setMessage("Database error is coming while performing Initilized opeartion on this appliance.");							 
											alertsService.createAlert(loggedInUser,"Device "+applianceDetailModel.getApplianceName()+"  try to perofrm initialize by "+loggedInUser+ " did not initialize due to database error.",applianceDetailModel.getApplianceName(),applianceDetailModel.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
										}
									}
									responseList.add(response);						
								}
							}	 
						}
						}
					}else{
						Response res=new Response();
						res.setStatus("failed");
						res.setCode("404");
						res.setMessage("Appliance does not exist.");
						responseList.add(res);	
					}
				}else{
					Response res=new Response();
					res.setStatus("failed");
					res.setCode("412");
					res.setMessage("ApplianceId required.");
					responseList.add(res);	
				}
			}else {
				logger.info("Mandatory fields are missing.");	
				Response res=new Response();
				res.setStatus("failed");
				res.setCode("400");
				String errorMessage="Please provide mandatory fields : "+requireFieldsMessage.substring(0,requireFieldsMessage.length()-1);
				res.setMessage(errorMessage);
				responseList.add(res);
			}
		}
		logger.info("End of initializeAppliance Method");
		return responseList;
	}

	public void  checkMandatoryField(StringBuilder requiredFieldMessage,InitializeApplianceModel initializeApplianceModel){
		logger.info("Start of checkMandatoryField Method in ApplianceManagementController Class");
		if(StringUtils.isEmpty(initializeApplianceModel.getApplianceId())){
			requiredFieldMessage.append(CaviumConstant.APPLIANCE_ID).append(CaviumConstant.COMMA);
		}
		if(StringUtils.isEmpty(initializeApplianceModel.getUsername())){
			requiredFieldMessage.append(CaviumConstant.DEFAULT_USER_NAME).append(CaviumConstant.COMMA);
		}
		if(StringUtils.isEmpty(initializeApplianceModel.getPassword())){
			requiredFieldMessage.append(CaviumConstant.DEFAULT_PASSWORD).append(CaviumConstant.COMMA);
		}
		if(StringUtils.isEmpty(initializeApplianceModel.getInitData().getCryptoOfficerName())){
			requiredFieldMessage.append(CaviumConstant.CRYPTO_OFFICER_NAME).append(CaviumConstant.COMMA);
		}
		if(StringUtils.isEmpty(initializeApplianceModel.getInitData().getCryptoOfficerPassword())){
			requiredFieldMessage.append(CaviumConstant.CRYPTO_OFFICER_PASSWORD).append(CaviumConstant.COMMA);
		}
		if(StringUtils.isEmpty(initializeApplianceModel.getInitData().getAuthenticationLevel())){
			requiredFieldMessage.append(CaviumConstant.AUTHENTICATION_LEVEL).append(CaviumConstant.COMMA);
		}else if(initializeApplianceModel.getInitData().getAuthenticationLevel()==1){
			if(StringUtils.isEmpty(initializeApplianceModel.getDualFactorDetails().getDualFactorCertificateId())){
				requiredFieldMessage.append(CaviumConstant.DF_CERTIFICATE).append(CaviumConstant.COMMA);	
			}
			if(StringUtils.isEmpty(initializeApplianceModel.getDualFactorDetails().getDualFactorAuthServerPortNo())){
				requiredFieldMessage.append(CaviumConstant.DF_PORT).append(CaviumConstant.COMMA);		
			}
			if(StringUtils.isEmpty(initializeApplianceModel.getDualFactorDetails().getDualFactorKeyFileId())){
				requiredFieldMessage.append(CaviumConstant.DF_KEY_FILE).append(CaviumConstant.COMMA);	

			}
		}
		if(StringUtils.isEmpty(initializeApplianceModel.getInitData().getFipsState())){
			requiredFieldMessage.append(CaviumConstant.FIPS_STATE).append(CaviumConstant.COMMA);
		}
		logger.info("End of checkMandatoryField Method in ApplianceManagementController Class");	 
	} 
	
	/**
	 * This method is used to validate appliance add form values
	 * @param app
	 * @param applianceDetailModel
	 * @param requiredFiledNotAvailable
	 * @return
	 */
	private ApplianceDetailModel validateFiledsForAddAppliance(ApplianceModel app, ApplianceDetailModel  applianceDetailModel, StringBuilder requiredFiledNotAvailable) {
		boolean isValidate=false;
		try {
			if(!StringUtils.isEmpty(app.getApplianceName())) {
				isValidate=CaviumUtil.validateRegexForFields(app.getApplianceName(),env.getProperty("cavium.regex.username"));
						if(isValidate) {
							applianceDetailModel.setApplianceName(app.getApplianceName());
						}else {
							generateRequiredField(requiredFiledNotAvailable, "given applianceName can contains only letter, number, underscore");
						}
			}else {
				generateRequiredField(requiredFiledNotAvailable, "applianceName is required");
			}
			if(!StringUtils.isEmpty(app.getAuthId())) {
				applianceDetailModel.setAuthId(app.getAuthId());
			}else {
				generateRequiredField(requiredFiledNotAvailable, "authId is required");
			}if(!StringUtils.isEmpty(app.getSerialNumber())) {
				isValidate=CaviumUtil.validateRegexForFields(app.getSerialNumber(),env.getProperty("cavium.regex.alphanumeric"));
				if(isValidate) {
					applianceDetailModel.setSerialNumber(app.getSerialNumber());
				}else {
					generateRequiredField(requiredFiledNotAvailable, "given serialnumber can contains only alpha numeric values");
				}
			}else {
				 generateRequiredField(requiredFiledNotAvailable, "serialnumber is required");
			}if(app.getNetwork()!=null && !StringUtils.isEmpty(app.getNetwork().getIpAddress())) {
				isValidate=CaviumUtil.validateIp(app.getNetwork().getIpAddress());
				if(isValidate) {
					applianceDetailModel.setIpAddress(app.getNetwork().getIpAddress());
				}else {
					generateRequiredField(requiredFiledNotAvailable, "given IP format is not correct");
				}
			}else {
				generateRequiredField(requiredFiledNotAvailable, "ip is required");
			}if(app.getZone()!=null && !StringUtils.isEmpty(app.getZone().getZoneId())) {
				isValidate=CaviumUtil.validateRegexForFields(app.getZone().getZoneId(),env.getProperty("cavium.regex.numberonly"));
				if(isValidate){
					applianceDetailModel.setZoneId(app.getZone().getZoneId());
				}else {
					generateRequiredField(requiredFiledNotAvailable, "given zoneId can contains only numbers");
				}
			}else {
				 generateRequiredField(requiredFiledNotAvailable, "zoneId is required");
			}if(app.getZone()!=null && !StringUtils.isEmpty(app.getZone().getZoneName())) {
				isValidate=CaviumUtil.validateRegexForFields(app.getZone().getZoneName(),env.getProperty("cavium.regex.charonly"));
				if(isValidate){
					applianceDetailModel.setCityName(app.getZone().getZoneName());
				}else {
					generateRequiredField(requiredFiledNotAvailable, "given zoneName can contains only characters");
				}
			}else {
				generateRequiredField(requiredFiledNotAvailable, "zoneName is required");
			}if(!StringUtils.isEmpty(app.getCryptoOfficerName())) {
				applianceDetailModel.setOperationUsername(app.getCryptoOfficerName());
			}else {
				generateRequiredField(requiredFiledNotAvailable, "cryptoOfficerName is required");
			}if(!StringUtils.isEmpty(app.getCryptoOfficerPassword())) {
				applianceDetailModel.setOperationPassword(app.getCryptoOfficerPassword());
			}else {
				generateRequiredField(requiredFiledNotAvailable, "cryptoOfficerPassword is required");
			}if(StringUtils.isEmpty(app.getFipsState())) {
				generateRequiredField(requiredFiledNotAvailable, "fipsState is required");
			}if(!StringUtils.isEmpty(app.getFipsState()) && app.getFipsState().equalsIgnoreCase("3")) {
				if(app.getDualFactorDetails()==null) {
					generateRequiredField(requiredFiledNotAvailable, "Dual Factor details are required");
				}else {
					if(app.getDualFactorDetails()!=null && StringUtils.isEmpty(app.getDualFactorDetails().getDualFactorAuthServerPortNo())) {
						generateRequiredField(requiredFiledNotAvailable, "dualFactorAuthServerPortNo is required");
					}
					if(app.getDualFactorDetails()!=null && StringUtils.isEmpty(app.getDualFactorDetails().getDualFactorCertificateId())) {
						generateRequiredField(requiredFiledNotAvailable, "dualFactorCertificateId is required");
					}
					if(app.getDualFactorDetails()!=null && StringUtils.isEmpty(app.getDualFactorDetails().getDualFactorKeyFileId())) {
						generateRequiredField(requiredFiledNotAvailable, "dualFactorKeyFileId is required");
					}
				}
			}
			
			if(!StringUtils.isEmpty(app.getDateTime())) {
				applianceDetailModel.setNetworkTimezone(app.getDateTime().getTimeZone());
			}if(!StringUtils.isEmpty(app.getIpmi())) {
				if(!StringUtils.isEmpty(app.getIpmi().getIp())) {
					isValidate=CaviumUtil.validateIp(app.getIpmi().getIp());
					if(isValidate) {
						applianceDetailModel.setIpmiIp(app.getIpmi().getIp());
					}else {
						generateRequiredField(requiredFiledNotAvailable, "given IpmiIP format is not correct");
					}
				}
				if(!StringUtils.isEmpty(app.getIpmi().getUserName())) {
					applianceDetailModel.setUserName(app.getIpmi().getUserName());		
				}
				if(!StringUtils.isEmpty(app.getIpmi().getUserPassword())) {
					applianceDetailModel.setUserPassword(app.getIpmi().getUserPassword());
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during validateFiledsForAddAppliance"+e.getMessage());
		}
		return applianceDetailModel;
	}
	
	/**
	 * This method is used to get list of appliances
	 * @return
	 */
	@RequestMapping(value = "listOfAppliances", method = RequestMethod.GET)
	public Response getListOfAllAppliances() {
		logger.info("inside validateCredentialsByLoginHSM");
		Response response=new Response();
		List<ApplianceDetailModel> listApplianceDetailModels=new ArrayList<>();
		String loggedInUser = userAttributes.getlogInUserName();
		List<Object> applianceModels=new ArrayList<>();
		try {
			listApplianceDetailModels = applianceService.listOfApplianceByGroupId(loggedInUser);
			for(ApplianceDetailModel applianceDetailModel : listApplianceDetailModels)
			{
				ApplianceModel app=new ApplianceModel();
				app.setApplianceId(applianceDetailModel.getApplianceId());
				app.setApplianceName(applianceDetailModel.getApplianceName());
				app.setApplianceStatus(applianceDetailModel.getApplianceStatus());
				app.setSerialNumber(applianceDetailModel.getSerialNumber());
				app.setCredentialsSaved(applianceDetailModel.isCredentialSaved());
				if(!StringUtils.isEmpty(applianceDetailModel.getNetworkTimezone())) {
					Timezone timezone=new Timezone();
					timezone.setTimeZone(applianceDetailModel.getNetworkTimezone());
					app.setDateTime(timezone);
				}
				
				
				Network network=new Network();
				network.setIpAddress(applianceDetailModel.getIpAddress());
				app.setNetwork(network);
				
				Zone zone=new Zone();
				zone.setZoneId(applianceDetailModel.getZoneId());
				zone.setZoneName(applianceDetailModel.getCityName());
				app.setZone(zone);
				
				applianceModels.add(app);
				
			}
			response.setCode("200");
			response.setMessage("List of appliances");
			response.setData(applianceModels);	
			
		} catch (Exception e) {
			logger.error("error occured during getListOfAllAppliances" + e.getMessage());
		}
		return response;
	}


	@RequestMapping(value = "StoreHSMOwnerCertificates", method = RequestMethod.PUT)
	public final List<Response> StoreHSMOwnerCertificates(@RequestBody List<HSMOwnerCertificatesModel> hsmOwnerCertificatesDetails ) {
		logger.info(" Start of StoreHSMOwnerCertificates method of ApplianceManagementController Class");		
		List<Response> responseList=new ArrayList<Response>();
		String loggedInUser = userAttributes.getlogInUserName();

		for(HSMOwnerCertificatesModel hsmOwnerCertificatesDetail : hsmOwnerCertificatesDetails){
			CaviumResponseModel responseModel=getCaviumResponseModel();
			Response res=new Response();
			StringBuilder requiredFieldsMessage=new StringBuilder();	
			ApplianceDetailModel applianceDetailModel=new ApplianceDetailModel();
			List<ApplianceDetailModel> dualListForLoginHSM=new ArrayList<>();
			  if(!StringUtils.isEmpty(hsmOwnerCertificatesDetail.getApplianceId())){
					ManageCertificatesDetails manageCertificatesDetail = new ManageCertificatesDetails();
					ApplianceDetailModel  applianceDetail = applianceRepository.getApplianceById(hsmOwnerCertificatesDetail.getApplianceId(), StoreType.PERMANENT);
					if(applianceDetail!=null) {
						InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(applianceDetail.getApplianceId());
						if(initmodel!=null && applianceDetailModel.isCredentialSaved()){
							hsmOwnerCertificatesDetail.setPassword(CaviumUtil.decrypt(initmodel.getOperationPerformPassword()));
							hsmOwnerCertificatesDetail.setUsername(initmodel.getOperationPerformUserName());
						}
						
						if(hsmOwnerCertificatesDetail.getDualFactorDetails()!=null) {
							if(applianceDetail.getFipsState().equalsIgnoreCase("3") && applianceDetail.isCredentialSaved()==false) {
							if(hsmOwnerCertificatesDetail.getDualFactorDetails()!=null && StringUtils.isEmpty(hsmOwnerCertificatesDetail.getDualFactorDetails().getDualFactorAuthServerPortNo())) {
								generateRequiredField(requiredFieldsMessage, "dualFactorAuthServerPortNo is required");
							}
							if(hsmOwnerCertificatesDetail.getDualFactorDetails()!=null && StringUtils.isEmpty(hsmOwnerCertificatesDetail.getDualFactorDetails().getDualFactorCertificateId())) {
								generateRequiredField(requiredFieldsMessage, "dualFactorCertificateId is required");
							}
							if(hsmOwnerCertificatesDetail.getDualFactorDetails()!=null && StringUtils.isEmpty(hsmOwnerCertificatesDetail.getDualFactorDetails().getDualFactorKeyFileId())) {
								generateRequiredField(requiredFieldsMessage, "dualFactorKeyFileId is required");
							}
							if(requiredFieldsMessage!=null && requiredFieldsMessage.length() == 0) {
								DualFactorUsersRelationshipModel dual=hsmOwnerCertificatesDetail.getDualFactorDetails();
								if(!StringUtils.isEmpty(hsmOwnerCertificatesDetail.getUsername())) {
									applianceDetail.setOperationUsername(hsmOwnerCertificatesDetail.getUsername());
								}if(!StringUtils.isEmpty(hsmOwnerCertificatesDetail.getPassword())) {
									applianceDetail.setOperationPassword(hsmOwnerCertificatesDetail.getPassword());
								}
								dualListForLoginHSM=applianceService.saveDualFactorDetails(dual, dualListForLoginHSM, applianceDetail, loggedInUser);
							}
						}else {
							if(applianceDetail.getFipsState().equalsIgnoreCase("3") && applianceDetail.isCredentialSaved()) {
								generateRequiredField(requiredFieldsMessage, "dual factor details input not required as credentials are saved");
							}else {
								generateRequiredField(requiredFieldsMessage, "Appliance not initialize with dual factor");
								}
							}
						}else {
							if(applianceDetail.getFipsState().equalsIgnoreCase("3")) {
								generateRequiredField(requiredFieldsMessage, "dualFactorDetails is required");
							}
						}
						
						checkMandatoryFieldForHSMCertificate(requiredFieldsMessage,hsmOwnerCertificatesDetail,applianceDetail.isCredentialSaved());
						
						
						
						if(StringUtils.isEmpty(String.valueOf(requiredFieldsMessage))){					
						manageCertificatesDetail.setApplianceId(applianceDetail.getApplianceId());
						manageCertificatesDetail.setApplianceIp(applianceDetail.getIpAddress());
						manageCertificatesDetail.setOperationUsername(hsmOwnerCertificatesDetail.getUsername());
						manageCertificatesDetail.setOperationPassword(hsmOwnerCertificatesDetail.getPassword());
						manageCertificatesDetail.setHsmFileName(hsmOwnerCertificatesDetail.getHsmFileUploadedId());
						manageCertificatesDetail.setSignedHSMfileName(hsmOwnerCertificatesDetail.getSignedHsmFileUploadedId());
						responseModel.setResponseCode("200");
						
						if(dualListForLoginHSM!=null && dualListForLoginHSM.size() > 0) {
							List<ApplianceDetailModel> errorLoginHSM = applianceService.validateCredentialsByLoginHSM(dualListForLoginHSM);
							if(errorLoginHSM!=null && !errorLoginHSM.isEmpty()) {
								ApplianceDetailModel errorApp=(ApplianceDetailModel)errorLoginHSM.get(0);
								if(!StringUtils.isEmpty(errorApp.getErrorMessage())) {
									responseModel.setResponseCode("412");
									responseModel.setResponseMessage(errorApp.getErrorMessage());
								}else {
									responseModel.setResponseCode("200");
								}
							}
						}
						if(responseModel!=null && responseModel.getResponseCode().equalsIgnoreCase("200")) {
							responseModel = applianceService.uploadCertificate(manageCertificatesDetail);
							res.setCode(responseModel.getResponseCode());
							res.setMessage(responseModel.getResponseMessage());
							res.setId(hsmOwnerCertificatesDetail.getApplianceId());
						}else {
							res.setCode(responseModel.getResponseCode());
							res.setId(hsmOwnerCertificatesDetail.getApplianceId());
							res.setMessage(responseModel.getResponseMessage());
						}
						}else {
							res.setId(hsmOwnerCertificatesDetail.getApplianceId());
							res.setMessage(requiredFieldsMessage.toString());
							res.setCode("412");
						}
					} else {
						requiredFieldsMessage.append("Appliance does not exists").append(CaviumConstant.COMMA);
						res.setId(hsmOwnerCertificatesDetail.getApplianceId());
						res.setMessage(requiredFieldsMessage.toString());
						res.setCode("412");
					}
				}else{
					res.setMessage("ApplianceId is required");
					res.setStatus("failed");
					res.setCode("412");
					res.setId(hsmOwnerCertificatesDetail.getApplianceId());
				}
			responseList.add(res);
		}
		logger.info(" End of StoreHSMOwnerCertificates method of ApplianceManagementController Class");	
		return responseList;
	}

	/*
	 *  This Method is used for Validating Mandatory fields of  InitializeApplianceModel Model
	 *  @Request param List of InitializeApplianceModel Object 
	 *
	 */
	public void  checkMandatoryFieldForHSMCertificate(StringBuilder requiredFieldMessage,HSMOwnerCertificatesModel hsmOwnerCertificatesDetail, boolean isCredentialsSaved){
		if(StringUtils.isEmpty(hsmOwnerCertificatesDetail.getApplianceId())){
			requiredFieldMessage.append(CaviumConstant.APPLIANCE_ID).append(CaviumConstant.COMMA);
		}		 
		if(StringUtils.isEmpty(hsmOwnerCertificatesDetail.getUsername()) && isCredentialsSaved==false){
			requiredFieldMessage.append(CaviumConstant.CRYPTO_OFFICER_NAME).append(CaviumConstant.COMMA);
		}
		if(StringUtils.isEmpty(hsmOwnerCertificatesDetail.getPassword()) && isCredentialsSaved==false){
			requiredFieldMessage.append(CaviumConstant.CRYPTO_OFFICER_PASSWORD).append(CaviumConstant.COMMA);
		}
		if(StringUtils.isEmpty(hsmOwnerCertificatesDetail.getHsmFileUploadedId())){
			requiredFieldMessage.append(CaviumConstant.HSM_FILE_UPLOADED_ID).append(CaviumConstant.COMMA);
		}
		if(StringUtils.isEmpty(hsmOwnerCertificatesDetail.getSignedHsmFileUploadedId())){
			requiredFieldMessage.append(CaviumConstant.SIGNED_HSM_FILE_UPLOADED_ID).append(CaviumConstant.COMMA);
		}
	}


	@RequestMapping(value = "getHSMCertificateUrl", method = RequestMethod.PUT)
	public final List<Response>  getHSMCertificateUrl(@RequestBody List<HSMOwnerCertificatesModel> hsmOwnerCertificatesDetails) {
		logger.info(" Start of getHSMCertificateUrl method of ApplianceManagementController Class ::");

		List<Response> responseList=new ArrayList<Response>();

		for(HSMOwnerCertificatesModel hsmOwnerCertificatesDetail : hsmOwnerCertificatesDetails){
			Response res = new Response();	
			try{
				StringBuilder requiredFieldsMessage=new StringBuilder();	
				checkMandatoryFieldForHSMCertificateURL(requiredFieldsMessage,hsmOwnerCertificatesDetail);
			
					if(!StringUtils.isEmpty(hsmOwnerCertificatesDetail.getApplianceId())){	
						List<Object> certificateUrls=new ArrayList<>();
						Map<String,String> url= new HashMap<String,String>();
						String certificateType=	hsmOwnerCertificatesDetail.getHsmCertificateType();
						ApplianceDetailModel  applianceDetail = applianceRepository.getApplianceById(hsmOwnerCertificatesDetail.getApplianceId(), StoreType.PERMANENT);
						if(applianceDetail!=null) {
							if(StringUtils.isEmpty(String.valueOf(requiredFieldsMessage))){	
							String applianceIp=applianceDetail.getIpAddress();
							CaviumResponseModel responseModel=getCaviumResponseModel();
							responseModel = applianceService.getCertificateURL(certificateType,applianceIp);
							res.setCode(responseModel.getResponseCode());
							if("200".equals(responseModel.getResponseCode())){
								url.put("downloadedCertificateUrlAddr", responseModel.getResponseMessage());				 
								certificateUrls.add(url);
								res.setData(certificateUrls);
								res.setApplianceIp(hsmOwnerCertificatesDetail.getApplianceIp());
								res.setStatus("success");
							}else{
								res.setStatus("failed");
								res.setApplianceIp(hsmOwnerCertificatesDetail.getApplianceIp());
								res.setMessage(responseModel.getResponseMessage());
							}
							res.setId(hsmOwnerCertificatesDetail.getApplianceId());		
							res.setName(applianceDetail.getApplianceName());
						} 
						else{
								res.setCode("412");
								res.setStatus("Failed");
								if(!StringUtils.isEmpty(String.valueOf(hsmOwnerCertificatesDetail.getApplianceIp()))){
									res.setMessage("Mandatory fields missing : "+ requiredFieldsMessage.substring(0,requiredFieldsMessage.length()-1) +" for ApplianceIp " + hsmOwnerCertificatesDetail.getApplianceIp());	
								}else{
									res.setMessage("Mandatory Fields missing : "+requiredFieldsMessage.substring(0,requiredFieldsMessage.length()-1) );		
								}

							}
						}else{
							res.setStatus("failed");
							res.setCode("404");
							res.setMessage("ApplianceId not exist");
							res.setApplianceIp(hsmOwnerCertificatesDetail.getApplianceIp());
						}
					}else{
						res.setMessage("ApplianceId is required");
						res.setStatus("failed");
						res.setCode("412");
					}

				responseList.add(res);
			}catch (Exception e) {
				logger.info(" Error coming in getHSMCertificateUrl method of ApplianceManagementController class ");	// TODO: handle exception
			}
		}
		logger.info(" End of getHSMCertificateUrl method of ApplianceManagementController Class ::");

		return responseList;

	}
 
	
	/**
	 * This method is used to reboot multiple appliances
	 * @param appModel
	 * @return
	 */
	@RequestMapping(value="applianceReboot",method=RequestMethod.PUT)
	public final List<Response> applianceReboot(@RequestBody List<ApplianceModel> appModel) {
		List<Response> responseList=new ArrayList<>();
		List<ApplianceDetailModel> listAppDetailModel=new ArrayList<>();
		String loggedInUser = userAttributes.getlogInUserName();
		try {
			if(appModel!=null && appModel.size() > 0) {
					/**
					 * We are validating required fields
					 */
					listAppDetailModel=validateForReboot(appModel, listAppDetailModel, responseList,loggedInUser);
					
					if(listAppDetailModel!=null && listAppDetailModel.size() > 0) {
						if(listAppDetailModel!=null) {
							ExecutorService executorService = Executors.newFixedThreadPool(50);
							for(ApplianceDetailModel app:listAppDetailModel) {
								
								if(StringUtils.isEmpty(app.getErrorMessage())) {
									executorService.execute(new Runnable() {
									    public void run() {
									    	applianceService.rebootAppliance(app,loggedInUser);
									    }
									});
									
									ApplianceDetailModel dbAppliance = applianceRepository.findOne(app.getApplianceId());
									dbAppliance.setLastOperationPerformed(env.getProperty("appliance.reboot"));
									dbAppliance.setLastOperationStatus("In-Progress");
									dbAppliance.setApplianceinitialized(app.isApplianceinitialized());
									dbAppliance.setCode("200");
									dbAppliance.setMessage(env.getProperty("appliance.reboot.success"));
									dbAppliance.setErrorMessage("");
									applianceRepository.save(dbAppliance);
									
									Response res=new Response();
									res.setId(dbAppliance.getApplianceId());
									res.setName(dbAppliance.getApplianceName());
									res.setStatus(app.getLastOperationPerformed());
									res.setCode("200");
									res.setMessage(env.getProperty("appliance.reboot.success"));
									responseList.add(res);
								}else {
									
									ApplianceDetailModel dbAppliance = applianceRepository.findOne(app.getApplianceId());
									dbAppliance.setLastOperationPerformed(env.getProperty("appliance.reboot"));
									dbAppliance.setLastOperationStatus("Failed");
									dbAppliance.setApplianceinitialized(app.isApplianceinitialized());
									dbAppliance.setCode("412");
									dbAppliance.setMessage("");
									dbAppliance.setErrorMessage(app.getErrorMessage());
									applianceRepository.save(dbAppliance);
									
									Response res=new Response();
									res.setId(app.getApplianceId());
									res.setName(app.getApplianceName());
									res.setStatus(app.getLastOperationPerformed());
									res.setCode("412");
									res.setMessage(app.getErrorMessage());
									responseList.add(res);
								}
							}
							executorService.shutdown();
						}
					}
			}else {
				Response res=new Response();
				res.setCode("412");
				res.setStatus("Failed");
				res.setMessage("Please provide atleast one applianceId.");
				responseList.add(res);
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Error occured during appliance reboot.."+e.getMessage());
		}
		return responseList;
	}
	
	/**
	 * 
	 * @param appModel
	 * @param listAppDetailModel
	 * @param responseList
	 * @return
	 */
	private List<ApplianceDetailModel> validateForReboot(List<ApplianceModel> appModel, List<ApplianceDetailModel> listAppDetailModel, List<Response> responseList,String loggedInUser){
		try {
			StringBuilder requiredFiledNotAvailable=null;
			List<ApplianceDetailModel> dualListForLoginHSM=null;
			for(ApplianceModel app: appModel) {
				dualListForLoginHSM=new ArrayList<>();
				 requiredFiledNotAvailable = new StringBuilder();
				ApplianceDetailModel applianceDetailModel=new ApplianceDetailModel();
				if(app!=null && !StringUtils.isEmpty(app.getApplianceId())) {
					applianceDetailModel.setApplianceId(app.getApplianceId());
					ApplianceDetailModel apdb=applianceRepository.getApplianceById(applianceDetailModel.getApplianceId(), StoreType.PERMANENT);
					if(apdb!=null) {
						if(!apdb.isCredentialSaved()) {
							if(StringUtils.isEmpty(app.getCryptoOfficerName())) {
								generateRequiredField(requiredFiledNotAvailable, "username is required");
							}else {
								applianceDetailModel.setOperationUsername(app.getCryptoOfficerName());
							}
							if(StringUtils.isEmpty(app.getCryptoOfficerPassword())) {
								generateRequiredField(requiredFiledNotAvailable, "password is required");
							}else {
								applianceDetailModel.setOperationPassword(app.getCryptoOfficerPassword());
							}
							
							if(app.getDualFactorDetails()!=null) {
								if(apdb.getFipsState().equalsIgnoreCase("3") && apdb.isCredentialSaved()==false) {
								if(app.getDualFactorDetails()!=null && StringUtils.isEmpty(app.getDualFactorDetails().getDualFactorAuthServerPortNo())) {
									generateRequiredField(requiredFiledNotAvailable, "dualFactorAuthServerPortNo is required");
								}
								if(app.getDualFactorDetails()!=null && StringUtils.isEmpty(app.getDualFactorDetails().getDualFactorCertificateId())) {
									generateRequiredField(requiredFiledNotAvailable, "dualFactorCertificateId is required");
								}
								if(app.getDualFactorDetails()!=null && StringUtils.isEmpty(app.getDualFactorDetails().getDualFactorKeyFileId())) {
									generateRequiredField(requiredFiledNotAvailable, "dualFactorKeyFileId is required");
								}
								if(requiredFiledNotAvailable!=null && requiredFiledNotAvailable.length() == 0) {
									if(!StringUtils.isEmpty(applianceDetailModel.getOperationUsername())) {
										apdb.setOperationUsername(applianceDetailModel.getOperationUsername());
									}if(!StringUtils.isEmpty(applianceDetailModel.getOperationPassword())) {
										apdb.setOperationPassword(applianceDetailModel.getOperationPassword());
									}
									DualFactorUsersRelationshipModel dual=app.getDualFactorDetails();
									dualListForLoginHSM=applianceService.saveDualFactorDetails(dual, dualListForLoginHSM, apdb, loggedInUser);
								}
							}else {
								if(apdb.getFipsState().equalsIgnoreCase("3") && apdb.isCredentialSaved()) {
									generateRequiredField(requiredFiledNotAvailable, "dual factor details input not required as credentials are saved");
								}else {
									generateRequiredField(requiredFiledNotAvailable, "Appliance not initialize with dual factor");
									}
								}
							}else {
								if(apdb.getFipsState().equalsIgnoreCase("3")) {
									generateRequiredField(requiredFiledNotAvailable, "dualFactorDetails is required");
								}
							}
						}
					}else {
						generateRequiredField(requiredFiledNotAvailable, "applianceId does not exists");
					}
					if(StringUtils.isEmpty(requiredFiledNotAvailable.toString())) {
							applianceDetailModel.setApplianceId(apdb.getApplianceId());
							applianceDetailModel.setIpAddress(apdb.getIpAddress());
							
							/**
							 * Validating loginHSM
							 */
							if(dualListForLoginHSM!=null && dualListForLoginHSM.size() > 0) {
								dualListForLoginHSM=applianceService.validateCredentialsByLoginHSM(dualListForLoginHSM);
								ApplianceDetailModel appErrors=(ApplianceDetailModel)dualListForLoginHSM.get(0);
								if(!StringUtils.isEmpty(appErrors.getErrorMessage())) {
									generateRequiredField(requiredFiledNotAvailable, appErrors.getErrorMessage());
									Response res=new Response();
									res.setCode("412");
									res.setMessage(requiredFiledNotAvailable.toString());
									res.setId(appErrors.getApplianceId());
									responseList.add(res);
									applianceDetailModel.setErrorMessage(requiredFiledNotAvailable.toString());
								}else {
									requiredFiledNotAvailable=null;
									listAppDetailModel.add(applianceDetailModel);
								}
							}else {
								listAppDetailModel.add(applianceDetailModel);
							}
					}else {
						Response res = generateFailedResponse(requiredFiledNotAvailable, applianceDetailModel);
						String message=res.getMessage()+".";
						res.setMessage(message);
						responseList.add(res);
						applianceDetailModel.setErrorMessage(message);
					}
				}else {
					Response res=new Response();
					res.setCode("412");
					generateRequiredField(requiredFiledNotAvailable, "applianceId is required");
					res.setMessage(requiredFiledNotAvailable.toString());
					responseList.add(res);
				}
				dualListForLoginHSM=null;
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during validate reboot method.");
		}
		return listAppDetailModel;
	}
	
	/**
	 * This method is used to get list of appliances by ip address
	 * @param appModel
	 * @return
	 */
	@RequestMapping(value="getApplianceStatusByName/{applianceName}",method=RequestMethod.GET)
	public final List<Response> getApplianceStatusByIP(@PathVariable("applianceName")String applianceName) {
		List<Response> response=new ArrayList<>();
		try {
				Response res=new Response();
				List<ApplianceDetailModel> isAvailable=applianceRepository.getApplianceNameByGivenName(applianceName);
				if(isAvailable!=null && isAvailable.size() > 0) {
					ApplianceDetailModel apdb=(ApplianceDetailModel)isAvailable.get(0);
					if(!StringUtils.isEmpty(apdb.getLastOperationStatus())) {
						res.setStatus(apdb.getLastOperationStatus());
					}
					
					if(!StringUtils.isEmpty(apdb.getLastOperationStatus()) && apdb.getLastOperationStatus().equalsIgnoreCase("failed")) {
						res.setCode("412");
						res.setMessage(apdb.getErrorMessage());
						if(!StringUtils.isEmpty(apdb.getLastOperationPerformed())) {
						res.setOperation(apdb.getLastOperationPerformed());
						}
					}else {
						if(!StringUtils.isEmpty(apdb.getLastOperationStatus()) && apdb.getLastOperationStatus().equalsIgnoreCase("In-Progress")) {
							res.setCode("200");
							if(!StringUtils.isEmpty(apdb.getLastOperationPerformed())) {
								res.setOperation(apdb.getLastOperationPerformed());
							}
							res.setMessage("Appliance is in progress state.");
						}else {
							res.setCode("201");
							if(!StringUtils.isEmpty(apdb.getLastOperationPerformed())) {
								res.setOperation(apdb.getLastOperationPerformed());
								res.setMessage(""+apdb.getLastOperationPerformed()+" completed successfully on appliance "+apdb.getApplianceName()+".");
							}else {
								res.setMessage("Operation completed successfully.");
							}
						}
					}
				response.add(res);
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getApplianceStatus"+e.getMessage());
		}
		return response;
	}
	
	/**
	 * This method is used to get appliance by ID
	 * @param applianceId
	 * @return
	 */
	@RequestMapping(value = "getApplianceLastOperationStatusById/{applianceId}", method = RequestMethod.GET)
	public  Response getAppliance(@PathVariable("applianceId") String applianceId) {
		ApplianceDetailModel applianceDetailModels = null;
		 Response response=new Response();
		logger.info("inside listAppliance");
		try {
			if(!StringUtils.isEmpty(applianceId)) {
				applianceDetailModels = applianceService.getApplianceById(applianceId);
				if(!StringUtils.isEmpty(applianceDetailModels.getLastOperationStatus())) {
					response.setStatus(applianceDetailModels.getLastOperationStatus());
				}
				if(!StringUtils.isEmpty(applianceDetailModels.getLastOperationStatus()) && applianceDetailModels.getLastOperationStatus().equalsIgnoreCase("failed")) {
					response.setCode("412");
					response.setMessage(applianceDetailModels.getErrorMessage());
					if(!StringUtils.isEmpty(applianceDetailModels.getLastOperationPerformed())) {
						response.setOperation(applianceDetailModels.getLastOperationPerformed());
					}
				}else {
					if(!StringUtils.isEmpty(applianceDetailModels.getLastOperationStatus()) && applianceDetailModels.getLastOperationStatus().equalsIgnoreCase("In-Progress")) {
						response.setCode("200");
						if(!StringUtils.isEmpty(applianceDetailModels.getLastOperationPerformed())) {
						response.setOperation(applianceDetailModels.getLastOperationPerformed());
						}
						response.setMessage("Appliance is in progress state.");
					}else {
						response.setCode("201");
						if(!StringUtils.isEmpty(applianceDetailModels.getLastOperationPerformed())) {
							response.setOperation(applianceDetailModels.getLastOperationPerformed());
							response.setMessage(""+applianceDetailModels.getLastOperationPerformed()+" completed successfully on appliance "+applianceDetailModels.getApplianceName()+".");
						}else {
							response.setMessage("Operation completed successfully.");
						}
					}
				}
			}else {
				response.setCode("404");
				response.setMessage("Please provide applianceId.");
			}
		} catch (Exception e) {
			logger.error("error occured during listAppliance" + e.getMessage());
		}
		return response;
	}
	
	/**
	 * This method is used to reboot multiple appliances
	 * @param appModel
	 * @return
	 */
	@RequestMapping(value="applianceZeroize",method=RequestMethod.PUT)
	public final List<Response> applianceZeroize(@RequestBody List<ApplianceModel> appModel) {
		List<Response> responseList=new ArrayList<>();
		List<ApplianceDetailModel> listAppDetailModel=new ArrayList<>();
		String loggedInUser = userAttributes.getlogInUserName();
		ExecutorService executorService = Executors.newFixedThreadPool(50);
		try {
			listAppDetailModel=validateForZeroize(appModel, listAppDetailModel, responseList,loggedInUser);
			if(listAppDetailModel!=null && listAppDetailModel.size() > 0) {
				if(listAppDetailModel!=null) {
						for(ApplianceDetailModel app: listAppDetailModel) {
								
								if(StringUtils.isEmpty(app.getErrorMessage())) {
									executorService.execute(new Runnable() {
									    public void run() {
									    	applianceService.zeroizeAppliance(loggedInUser,app);
									    }
									});
									
									ApplianceDetailModel dbAppliance = applianceRepository.findOne(app.getApplianceId());
									dbAppliance.setLastOperationPerformed(env.getProperty("appliance.zeroize"));
									dbAppliance.setLastOperationStatus("In-Progress");
									dbAppliance.setApplianceinitialized(app.isApplianceinitialized());
									dbAppliance.setCode("200");
									dbAppliance.setMessage("Zeroize initiated successfully.");
									dbAppliance.setErrorMessage("");
									applianceRepository.save(dbAppliance);
									
									Response res=new Response();
									res.setId(dbAppliance.getApplianceId());
									res.setName(dbAppliance.getApplianceName());
									res.setStatus(app.getLastOperationPerformed());
									res.setCode("200");
									res.setMessage("Zeroize initiated successfully.");
									responseList.add(res);
								}else {
									ApplianceDetailModel dbAppliance = applianceRepository.findOne(app.getApplianceId());
									dbAppliance.setLastOperationPerformed(env.getProperty("appliance.zeroize"));
									dbAppliance.setLastOperationStatus("Failed");
									dbAppliance.setApplianceinitialized(app.isApplianceinitialized());
									dbAppliance.setCode("412");
									dbAppliance.setMessage("");
									dbAppliance.setErrorMessage(app.getErrorMessage());
									applianceRepository.save(dbAppliance);
									
									Response res=new Response();
									res.setId(app.getApplianceId());
									res.setName(app.getApplianceName());
									res.setStatus(app.getLastOperationPerformed());
									res.setCode("412");
									res.setMessage(app.getErrorMessage());
									responseList.add(res);
								}
							executorService.shutdown();
						}
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.info("Error occured during applianceZeroize.."+e.getMessage());
		}
		return responseList;
	}
	
	/**
	 * 
	 * @param appModel
	 * @param listAppDetailModel
	 * @param responseList
	 * @return
	 */
	private List<ApplianceDetailModel> validateForZeroize(List<ApplianceModel> appModel, List<ApplianceDetailModel> listAppDetailModel, List<Response> responseList,String loggedInUser){
		try {
			StringBuilder requiredFiledNotAvailable=null;
			List<ApplianceDetailModel> dualListForLoginHSM=null;
			for(ApplianceModel app: appModel) {
				 requiredFiledNotAvailable = new StringBuilder();
				 dualListForLoginHSM=new ArrayList<>();
				ApplianceDetailModel applianceDetailModel=new ApplianceDetailModel();
				if(app!=null && !StringUtils.isEmpty(app.getApplianceId())) {
					
					if (!StringUtils.isEmpty(app.getType())) {
						applianceDetailModel.setType(app.getType());
					} else {
						generateRequiredField(requiredFiledNotAvailable, "type is required");
					}

					if (!StringUtils.isEmpty(app.getForceZeroize()) && !StringUtils.isEmpty(app.getType())
							&& app.getType().equalsIgnoreCase("adapter")) {
						if(!StringUtils.isEmpty(app.getForceZeroize())) {
							applianceDetailModel.setForceZeroize(app.getForceZeroize());
						}else {
							generateRequiredField(requiredFiledNotAvailable, "forceZeroize is required");
						}
						
					}
				
					
					applianceDetailModel.setApplianceId(app.getApplianceId());
					ApplianceDetailModel apdb=applianceRepository.getApplianceById(applianceDetailModel.getApplianceId(), StoreType.PERMANENT);
					if(!apdb.isCredentialSaved()) {
						if(StringUtils.isEmpty(app.getCryptoOfficerName())) {
							generateRequiredField(requiredFiledNotAvailable, "username is required");
						}else {
							applianceDetailModel.setOperationUsername(app.getCryptoOfficerName());
						}
						if(StringUtils.isEmpty(app.getCryptoOfficerPassword())) {
							generateRequiredField(requiredFiledNotAvailable, "password is required");
						}else {
							applianceDetailModel.setOperationPassword(app.getCryptoOfficerPassword());
						}
						
						if(app.getDualFactorDetails()!=null) {
							if(apdb.getFipsState().equalsIgnoreCase("3") && apdb.isCredentialSaved()==false) {
							if(app.getDualFactorDetails()!=null && StringUtils.isEmpty(app.getDualFactorDetails().getDualFactorAuthServerPortNo())) {
								generateRequiredField(requiredFiledNotAvailable, "dualFactorAuthServerPortNo is required");
							}
							if(app.getDualFactorDetails()!=null && StringUtils.isEmpty(app.getDualFactorDetails().getDualFactorCertificateId())) {
								generateRequiredField(requiredFiledNotAvailable, "dualFactorCertificateId is required");
							}
							if(app.getDualFactorDetails()!=null && StringUtils.isEmpty(app.getDualFactorDetails().getDualFactorKeyFileId())) {
								generateRequiredField(requiredFiledNotAvailable, "dualFactorKeyFileId is required");
							}
							if(requiredFiledNotAvailable!=null && requiredFiledNotAvailable.length() == 0) {
								if(!StringUtils.isEmpty(applianceDetailModel.getOperationUsername())) {
									apdb.setOperationUsername(applianceDetailModel.getOperationUsername());
								}if(!StringUtils.isEmpty(applianceDetailModel.getOperationPassword())) {
									apdb.setOperationPassword(applianceDetailModel.getOperationPassword());
								}
								DualFactorUsersRelationshipModel dual=app.getDualFactorDetails();
								dualListForLoginHSM=applianceService.saveDualFactorDetails(dual, dualListForLoginHSM, apdb, loggedInUser);
							}
						}else {
							if(apdb.getFipsState().equalsIgnoreCase("3") && apdb.isCredentialSaved()) {
								generateRequiredField(requiredFiledNotAvailable, "dual factor details input not required as credentials are saved");
							}else {
								generateRequiredField(requiredFiledNotAvailable, "Appliance not initialize with dual factor");
								}
							}
						}else {
							if(apdb.getFipsState().equalsIgnoreCase("3")) {
								generateRequiredField(requiredFiledNotAvailable, "dualFactorDetails is required");
							}
						}
					}
					if(StringUtils.isEmpty(requiredFiledNotAvailable.toString())) {
						applianceDetailModel.setApplianceId(apdb.getApplianceId());
						applianceDetailModel.setIpAddress(apdb.getIpAddress());
						/**
						 * Validating loginHSM
						 */
						if(dualListForLoginHSM!=null && dualListForLoginHSM.size() > 0) {
							dualListForLoginHSM=applianceService.validateCredentialsByLoginHSM(dualListForLoginHSM);
							ApplianceDetailModel appErrors=(ApplianceDetailModel)dualListForLoginHSM.get(0);
							if(!StringUtils.isEmpty(appErrors.getErrorMessage())) {
								generateRequiredField(requiredFiledNotAvailable, appErrors.getErrorMessage());
								Response res = new Response();
								res.setCode("412");
								res.setMessage(requiredFiledNotAvailable.toString());
								res.setId(appErrors.getApplianceId());
								responseList.add(res);
								applianceDetailModel.setErrorMessage(requiredFiledNotAvailable.toString());
							} else {
								requiredFiledNotAvailable = null;
								listAppDetailModel.add(applianceDetailModel);
							}
						} else {
							listAppDetailModel.add(applianceDetailModel);
						}
				}else {
						Response res = generateFailedResponse(requiredFiledNotAvailable, applianceDetailModel);
						String message=res.getMessage()+".";
						res.setMessage(message);
						responseList.add(res);
					}
				}else {
					Response res=new Response();
					res.setCode("412");
					generateRequiredField(requiredFiledNotAvailable, "applianceId is required");
					res.setMessage(requiredFiledNotAvailable.toString());
					responseList.add(res);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during validate Zeroized method.");
		}
		return listAppDetailModel;
	}

	@RequestMapping(value = "getSecurityLogsUrl", method = RequestMethod.PUT)
	public List<Response> getSecurityLogsUrl(@RequestBody List<LogsDetails>  logsDetailsList){
		List<Response> responseList=new ArrayList<Response>();
		try{
			for(LogsDetails logsDetails:logsDetailsList){
				Response res = new Response();	
				StringBuilder requiredFieldsMessage= new StringBuilder();
				String type="download";
				
				if(logsDetails.getApplianceId() > 0){	
						ApplianceDetailModel  appModel = applianceRepository.getApplianceById(logsDetails.getApplianceId(), StoreType.PERMANENT);
						if(appModel!=null) {
							
							List<Object> certificateUrls=new ArrayList<>();
							Map<String,String> url= new HashMap<String,String>();
							
							checkMandatoryFieldsForSecurityLogs(requiredFieldsMessage, logsDetails,type,true);
							
							if(StringUtils.isEmpty(String.valueOf(requiredFieldsMessage))){									
							logsDetails.setApplianceId(appModel.getApplianceId());
							logsDetails.setApplianceIp(appModel.getIpAddress());
							logsDetails.setApplianceName(appModel.getApplianceName());
							CaviumResponseModel responseModel=getCaviumResponseModel();
							responseModel= applianceService.getDownloadlogsURL(logsDetails);
							if(responseModel!=null){
								res.setCode(responseModel.getResponseCode());
								if("200".equals(responseModel.getResponseCode())){
									url.put("liquidSecurityLogsUrlAddr", responseModel.getResponseMessage());				 
									certificateUrls.add(url);
									res.setData(certificateUrls);
									res.setId(appModel.getApplianceId());
									res.setStatus("success");
								}else{
									res.setMessage(responseModel.getResponseMessage());
									res.setId(appModel.getApplianceId());
									res.setStatus("failed");
								}
								res.setId(appModel.getApplianceId());		
								res.setName(appModel.getApplianceName());
							}else{
								res.setStatus("failed");
								res.setCode("412");
								res.setMessage("Response is coming as a null");
								res.setId(appModel.getApplianceId());		
								res.setName(appModel.getApplianceName());
							}
						}
						else{
							res.setCode("412");
							res.setStatus("Failed");
							if(!StringUtils.isEmpty(logsDetails.getApplianceId())){
								res.setMessage("Mandatory fields missing : "+ requiredFieldsMessage.substring(0,requiredFieldsMessage.length()-1) +" for ApplianceId " + logsDetails.getApplianceId());	
						}else{
								res.setMessage("Mandatory Fields missing : "+requiredFieldsMessage.substring(0,requiredFieldsMessage.length()-1) );		
							}

						}
						}else{
							res.setStatus("failed");
							res.setCode("404");
							res.setMessage("ApplianceId not exist");	
							res.setId(logsDetails.getApplianceId());
						}
					}else {
						res.setMessage("ApplianceId is required");
						res.setStatus("failed");
						res.setCode("412");
					}
				
				responseList.add(res);

			}
		}catch (Exception e) {
			logger.info(" Error coming in getSecurityLogsUrl method of ApplianceManagementController class ");	// TODO: handle exception
		}
		return responseList;
	}

	@RequestMapping(value = "deleteSecurityLogsUrl", method = RequestMethod.PUT)
	public List<Response> deleteSecurityLogs(@RequestBody List<LogsDetails>  logsDetailsList){
		List<Response> responseList=new ArrayList<Response>();
		String loggedInUser = userAttributes.getlogInUserName();
		List<ApplianceDetailModel> dualListForLoginHSM=new ArrayList<>();
		try{
			for(LogsDetails logsDetails:logsDetailsList){
				Response res = new Response();	
				StringBuilder requiredFieldsMessage= new StringBuilder();
				String type="delete";
				ApplianceDetailModel applianceDetailModel=new ApplianceDetailModel();
				if(logsDetails.getApplianceId() > 0){
						ApplianceDetailModel  appModel = applianceRepository.getApplianceById(logsDetails.getApplianceId(), StoreType.PERMANENT);
						if(appModel!=null) {
							
							checkMandatoryFieldsForSecurityLogs(requiredFieldsMessage, logsDetails,type,appModel.isCredentialSaved());
							
							if(StringUtils.isEmpty(String.valueOf(requiredFieldsMessage))){	
								if(!StringUtils.isEmpty(logsDetails.getUsername()) && !StringUtils.isEmpty(logsDetails.getPassword())) {
									logsDetails.setOperationPassword(logsDetails.getPassword());
									logsDetails.setOperationUsername(logsDetails.getUsername());
									applianceDetailModel.setOperationUsername(logsDetails.getUsername());
									applianceDetailModel.setOperationPassword(logsDetails.getPassword());
								}if(logsDetails.getDualFactorDetails()!=null) {
										if(appModel.getFipsState().equalsIgnoreCase("3") && appModel.isCredentialSaved()==false) {
										if(logsDetails.getDualFactorDetails()!=null && StringUtils.isEmpty(logsDetails.getDualFactorDetails().getDualFactorAuthServerPortNo())) {
											generateRequiredField(requiredFieldsMessage, "dualFactorAuthServerPortNo is required");
										}
										if(logsDetails.getDualFactorDetails()!=null && StringUtils.isEmpty(logsDetails.getDualFactorDetails().getDualFactorCertificateId())) {
											generateRequiredField(requiredFieldsMessage, "dualFactorCertificateId is required");
										}
										if(logsDetails.getDualFactorDetails()!=null && StringUtils.isEmpty(logsDetails.getDualFactorDetails().getDualFactorKeyFileId())) {
											generateRequiredField(requiredFieldsMessage, "dualFactorKeyFileId is required");
										}
										if(requiredFieldsMessage!=null && requiredFieldsMessage.length() == 0) {
											if(!StringUtils.isEmpty(applianceDetailModel.getOperationUsername())) {
												appModel.setOperationUsername(applianceDetailModel.getOperationUsername());
											}if(!StringUtils.isEmpty(applianceDetailModel.getOperationPassword())) {
												appModel.setOperationPassword(applianceDetailModel.getOperationPassword());
											}
											DualFactorUsersRelationshipModel dual=logsDetails.getDualFactorDetails();
											dualListForLoginHSM=applianceService.saveDualFactorDetails(dual, dualListForLoginHSM, appModel, loggedInUser);
										}
									}else {
											generateRequiredField(requiredFieldsMessage, "Appliance not initialized with dual factor");
										}
									}else {
										if(appModel.getFipsState().equalsIgnoreCase("3")) {
											generateRequiredField(requiredFieldsMessage, "dualFactorDetails is required");
										}
									}
								if(StringUtils.isEmpty(String.valueOf(requiredFieldsMessage))) {
									logsDetails.setApplianceId(appModel.getApplianceId());
									logsDetails.setApplianceIp(appModel.getIpAddress());
									logsDetails.setApplianceName(appModel.getApplianceName());
									CaviumResponseModel responseModel=getCaviumResponseModel();
									responseModel.setResponseCode("200");
									List<ApplianceDetailModel> errorLoginHSM=null;
									if(dualListForLoginHSM!=null && dualListForLoginHSM.size() > 0) {
										errorLoginHSM=applianceService.validateCredentialsByLoginHSM(dualListForLoginHSM);
										if(errorLoginHSM!=null && !errorLoginHSM.isEmpty()) {
											ApplianceDetailModel errorApp=(ApplianceDetailModel)errorLoginHSM.get(0);
											if(!StringUtils.isEmpty(errorApp.getErrorMessage())) {
												responseModel.setResponseCode("412");
												responseModel.setResponseMessage(errorApp.getErrorMessage());
											}else {
												responseModel.setResponseCode("200");
											}
										}
									}
									
									if(responseModel!=null && responseModel.getResponseCode().equalsIgnoreCase("200")) {
										responseModel = applianceService.deleteAppliancelogs(logsDetails);	
										if(responseModel!=null){
											res.setCode(responseModel.getResponseCode());
											if("200".equals(responseModel.getResponseCode())){
												res.setStatus("success");
												res.setCode("200");
												res.setMessage(responseModel.getResponseMessage());	
												res.setId(logsDetails.getApplianceId());
											}else{
												res.setStatus("failed");
												res.setCode(responseModel.getResponseCode());
												res.setMessage(responseModel.getResponseMessage());
												res.setId(logsDetails.getApplianceId());
											}
											res.setId(logsDetails.getApplianceId());	
										}else{
											res.setStatus("failed");
											res.setCode("412");
											res.setMessage("Response is coming as a null");
											res.setId(logsDetails.getApplianceId());
										}
									}else {
										res.setStatus("failed");
										res.setCode("412");
										res.setMessage("LoginHSM for dual factor failed.");	
										res.setId(logsDetails.getApplianceId());
									}
									
								}else {
									res.setStatus("failed");
									res.setCode("412");
									res.setMessage(requiredFieldsMessage.toString());	
									res.setId(logsDetails.getApplianceId());
								}
						}else{
							res.setCode("412");
							res.setStatus("Failed");
							if(!StringUtils.isEmpty(logsDetails.getApplianceId())){
								res.setMessage("Mandatory fields missing : "+ requiredFieldsMessage.substring(0,requiredFieldsMessage.length()-1) +" for ApplianceId " + logsDetails.getApplianceId());	
							}else{
								res.setMessage("Mandatory Fields missing : "+requiredFieldsMessage.substring(0,requiredFieldsMessage.length()-1) );		
							}

							}
						}
						else{
							res.setStatus("failed");
							res.setCode("404");
							res.setMessage("ApplianceId not exist");	
							res.setId(logsDetails.getApplianceId());
						}
					}else{
						res.setStatus("failed");
						res.setMessage("ApplianceId is required");
						res.setCode("412");
					}

				responseList.add(res);
			}
		}catch (Exception e) {
			logger.info(" Error coming in getSecurityLogsUrl method of ApplianceManagementController class ");	// TODO: handle exception
		}
		return responseList;
	}

	public void  checkMandatoryFieldsForSecurityLogs(StringBuilder requiredFieldMessage,LogsDetails logsDetails,String type,boolean isCredentialsSaved){
		logger.info("Start of checkMandatoryField Method in ApplianceManagementController Class");

		if(!"existingLoggerType".equals(type)){
			if(StringUtils.isEmpty(logsDetails.getUsername()) && isCredentialsSaved==false){
				requiredFieldMessage.append(CaviumConstant.CRYPTO_OFFICER_NAME).append(CaviumConstant.COMMA);
			}
			if(StringUtils.isEmpty(logsDetails.getPassword()) && isCredentialsSaved==false){
				requiredFieldMessage.append(CaviumConstant.CRYPTO_OFFICER_PASSWORD).append(CaviumConstant.COMMA);
			}
		}
		if("download".equals(type) || "delete".equals(type)){
			if(logsDetails.getLogs()==null){
				requiredFieldMessage.append("Please provide required logs details.").append(CaviumConstant.COMMA);	
			}
			else{
				if(logsDetails.getLogs().getAdmin()!=null || logsDetails.getLogs().getHost()!=null || logsDetails.getLogs().getPartitions()!=null ){
					
					if(!(logsDetails.getLogs().getAdmin()!=null && logsDetails.getLogs().getAdmin().getOptions()!=null && logsDetails.getLogs().getAdmin().getOptions().size()>0 
							|| logsDetails.getLogs().getHost()!=null && logsDetails.getLogs().getHost().getOptions()!=null 
								&& logsDetails.getLogs().getHost().getOptions().size()>0
							|| logsDetails.getLogs().getPartitions()!=null && logsDetails.getLogs().getPartitions().getOptions()!=null && logsDetails.getLogs().getPartitions().getOptions().size()>0)){
						requiredFieldMessage.append("Please provide required logs details.").append(CaviumConstant.COMMA);
					}
				} else {
					requiredFieldMessage.append("Please provide required logs details.").append(CaviumConstant.COMMA);
				}
			}
		}if("configure".equals(type)){
			if(StringUtils.isEmpty(logsDetails.getLoggerType())){
				requiredFieldMessage.append(CaviumConstant.LOGGER_TYPE).append(CaviumConstant.COMMA);
			}	
		}
		logger.info("End of checkMandatoryFieldsForSecurityLogs Method in ApplianceManagementController Class");	 
	}
	
	@RequestMapping(value = "configureSecurityLoggerType", method = RequestMethod.PUT)
	public List<Response> configureSecurityLoggerType(@RequestBody List<LogsDetails>  logsDetailsList){
		List<Response> responseList=new ArrayList<Response>();
		String loggedInUser = userAttributes.getlogInUserName();
		List<ApplianceDetailModel> dualListForLoginHSM=new ArrayList<>();
		try{
			for(LogsDetails logsDetails:logsDetailsList){
				Response res = new Response();	
				StringBuilder requiredFieldsMessage= new StringBuilder();
				String type="configure";
				ApplianceDetailModel applianceDetailModel=new ApplianceDetailModel();
			
					if(logsDetails.getApplianceId() > 0){
						ApplianceDetailModel  applianceDetail = applianceRepository.getApplianceById(logsDetails.getApplianceId(), StoreType.PERMANENT);
						if(applianceDetail!=null) {
							
							if(!StringUtils.isEmpty(logsDetails.getUsername()) && !StringUtils.isEmpty(logsDetails.getPassword()) && applianceDetail.isCredentialSaved()==false) {
								logsDetails.setOperationPassword(logsDetails.getPassword());
								logsDetails.setOperationUsername(logsDetails.getUsername());
								applianceDetailModel.setOperationUsername(logsDetails.getUsername());
								applianceDetailModel.setOperationPassword(logsDetails.getPassword());
							}if(logsDetails.getDualFactorDetails()!=null) {
									if(applianceDetail.getFipsState().equalsIgnoreCase("3") && applianceDetail.isCredentialSaved()==false) {
									if(logsDetails.getDualFactorDetails()!=null && StringUtils.isEmpty(logsDetails.getDualFactorDetails().getDualFactorAuthServerPortNo())) {
										generateRequiredField(requiredFieldsMessage, "dualFactorAuthServerPortNo is required");
									}
									if(logsDetails.getDualFactorDetails()!=null && StringUtils.isEmpty(logsDetails.getDualFactorDetails().getDualFactorCertificateId())) {
										generateRequiredField(requiredFieldsMessage, "dualFactorCertificateId is required");
									}
									if(logsDetails.getDualFactorDetails()!=null && StringUtils.isEmpty(logsDetails.getDualFactorDetails().getDualFactorKeyFileId())) {
										generateRequiredField(requiredFieldsMessage, "dualFactorKeyFileId is required");
									}
									if(requiredFieldsMessage!=null && requiredFieldsMessage.length() == 0) {
										if(!StringUtils.isEmpty(applianceDetailModel.getOperationUsername())) {
											applianceDetail.setOperationUsername(applianceDetailModel.getOperationUsername());
										}if(!StringUtils.isEmpty(applianceDetailModel.getOperationPassword())) {
											applianceDetail.setOperationPassword(applianceDetailModel.getOperationPassword());
										}
										DualFactorUsersRelationshipModel dual=logsDetails.getDualFactorDetails();
										dualListForLoginHSM=applianceService.saveDualFactorDetails(dual, dualListForLoginHSM, applianceDetail, loggedInUser);
									}
								}else {
										generateRequiredField(requiredFieldsMessage, "Appliance not initialized with dual factor");
									}
								}else {
									if(applianceDetail.getFipsState().equalsIgnoreCase("3")) {
										generateRequiredField(requiredFieldsMessage, "dualFactorDetails is required");
									}
								}
							
							checkMandatoryFieldsForSecurityLogs(requiredFieldsMessage, logsDetails,type,applianceDetail.isCredentialSaved());
							
							if(StringUtils.isEmpty(String.valueOf(requiredFieldsMessage)))
							{
							logsDetails.setApplianceId(applianceDetail.getApplianceId());
							logsDetails.setApplianceIp(applianceDetail.getIpAddress());
							logsDetails.setApplianceName(applianceDetail.getApplianceName());
							CaviumResponseModel responseModel=getCaviumResponseModel();
							responseModel.setResponseCode("200");
							List<ApplianceDetailModel> errorLoginHSM=null;
							if(dualListForLoginHSM!=null && dualListForLoginHSM.size() > 0) {
								errorLoginHSM=applianceService.validateCredentialsByLoginHSM(dualListForLoginHSM);
								if(errorLoginHSM!=null && !errorLoginHSM.isEmpty()) {
									ApplianceDetailModel errorApp=(ApplianceDetailModel)errorLoginHSM.get(0);
									if(!StringUtils.isEmpty(errorApp.getErrorMessage())) {
										responseModel.setResponseCode("412");
										responseModel.setResponseMessage(errorApp.getErrorMessage());
									}else {
										responseModel.setResponseCode("200");
									}
								}
							}
							if(responseModel!=null && responseModel.getResponseCode().equalsIgnoreCase("200")) {
								responseModel = applianceService.updateConfigureLoggerType(logsDetails);	
								if(responseModel!=null){
									res.setCode(responseModel.getResponseCode());
									if("200".equals(responseModel.getResponseCode())){
										res.setStatus("success");
										res.setCode("200");
										res.setMessage(responseModel.getResponseMessage());	
										res.setId(logsDetails.getApplianceId());
									}else{
										res.setStatus("failed");
										res.setMessage(responseModel.getResponseMessage());	
										res.setId(logsDetails.getApplianceId());
								 
									}
									res.setId(applianceDetail.getApplianceId());		
									res.setName(applianceDetail.getApplianceName());
								}else{
									res.setStatus("failed");
									res.setCode("412");
									res.setMessage("Response is coming as a null");
									res.setId(applianceDetail.getApplianceId());		
									res.setName(applianceDetail.getApplianceName());
								}
							}else {
								res.setStatus("failed");
								res.setCode("412");
								res.setMessage(responseModel.getResponseMessage());	
								res.setId(logsDetails.getApplianceId());
							}
						}else{
							res.setCode("412");
							res.setStatus("failed");
							if(!StringUtils.isEmpty(logsDetails.getApplianceId())){
								res.setMessage("Mandatory fields missing : "+ requiredFieldsMessage.substring(0,requiredFieldsMessage.length()-1) +" for ApplianceId " + logsDetails.getApplianceId());	
							} 
						}
						}else{
							res.setStatus("failed");
							res.setCode("404");
							res.setMessage("ApplianceId not exist");	
							res.setId(logsDetails.getApplianceId());	
						}
					}else{
						res.setMessage("ApplianceId is required");
						res.setStatus("failed");
						res.setCode("412");
					}

				responseList.add(res);

			}
		}catch (Exception e) {
			logger.info(" Error coming in getSecurityLogsUrl method of ApplianceManagementController class ");	// TODO: handle exception
		}
		return responseList;
	}
	
	@RequestMapping(value = "getSecurityLoggerType", method = RequestMethod.GET)
	public List<Response> getSecurityLoggerType(@RequestParam("applianceIds") String[] applianceIds){
		List<Response> responseList=new ArrayList<Response>();
		try{
			for(String id:applianceIds){
				Response res = new Response();	
				StringBuilder requiredFieldsMessage= new StringBuilder();
				LogsDetails logsDetails=new LogsDetails();
				if(!StringUtils.isEmpty(id)){
					ApplianceDetailModel  applianceDetail = applianceRepository.getApplianceById(Long.valueOf(id), StoreType.PERMANENT);
						if(applianceDetail!=null) {
							
							if(StringUtils.isEmpty(requiredFieldsMessage.toString())){
							logsDetails.setApplianceIp(applianceDetail.getIpAddress());
							logsDetails.setApplianceId(applianceDetail.getApplianceId());
							logsDetails.setApplianceName(applianceDetail.getApplianceName());
							CaviumResponseModel responseModel=getCaviumResponseModel();

							responseModel = applianceService.getAlreadyConfiguredLoggerType(logsDetails);	
							
							if(responseModel!=null){
								res.setCode(responseModel.getResponseCode());
								if("200".equals(responseModel.getResponseCode())){
									res.setStatus("success");
									res.setCode("200");
									res.setMessage(responseModel.getResponseMessage());	
									res.setId(logsDetails.getApplianceId());
								}else{
									res.setStatus("failed");						
									res.setId(logsDetails.getApplianceId());
									res.setMessage(responseModel.getResponseMessage());
								}
								res.setId(applianceDetail.getApplianceId());		
								res.setName(applianceDetail.getApplianceName());
							}else{
								res.setStatus("failed");
								res.setCode("412");
								res.setMessage("Response is coming as a null");
								res.setId(applianceDetail.getApplianceId());		
								res.setName(applianceDetail.getApplianceName());
							}
						}
					 else{ 
						 res.setCode("412");
							res.setStatus("Failed");
							if(!StringUtils.isEmpty(logsDetails.getApplianceId())){
								res.setMessage("Mandatory fields missing : "+ requiredFieldsMessage.substring(0,requiredFieldsMessage.length()-1) +" for ApplianceId " + logsDetails.getApplianceId());	
							} 
						}
						}else{
							res.setStatus("failed");
							res.setCode("404");
							res.setMessage("ApplianceId not exist");	
							res.setId(logsDetails.getApplianceId());		
						}
					}else{
						res.setMessage("ApplianceId is required");
						res.setStatus("failed");
						res.setCode("412");
					}

				responseList.add(res);

			}
		}catch (Exception e) {
			logger.info(" Error coming in getSecurityLogsUrl method of ApplianceManagementController class ");
		}
		return responseList;
	}
	
	@RequestMapping(value = "uploadMCOKeys", method = RequestMethod.POST)
	public List<Response> uploadMCOKeys(@RequestBody List<MCOKeyDetails>  MCOKeyDetailsList){
		List<Response> responseList=new ArrayList<Response>();
		String loggedInUser = userAttributes.getlogInUserName();
		List<ApplianceDetailModel> dualListForLoginHSM=new ArrayList<>();
		try{
			for(MCOKeyDetails mcoKeyDetails:MCOKeyDetailsList){
				ApplianceDetailModel applianceDetailModel=new ApplianceDetailModel();
				MCOKeyCertificateDetails mcoKeyCertificateDetails= new MCOKeyCertificateDetails();
				Response res = new Response();	
				StringBuilder requiredFieldsMessage= new StringBuilder();		
					if(!StringUtils.isEmpty(mcoKeyDetails.getApplianceId())){
						ApplianceDetailModel  applianceDetail = applianceRepository.getApplianceById(Long.valueOf(mcoKeyDetails.getApplianceId()), StoreType.PERMANENT);
						if(applianceDetail!=null) {
							
							checkMandatoryFieldsForMCOKeys(requiredFieldsMessage, mcoKeyDetails,applianceDetail.isCredentialSaved());
							
							if(!StringUtils.isEmpty(mcoKeyDetails.getUsername())) {
								applianceDetailModel.setOperationUsername(mcoKeyDetails.getUsername());
								mcoKeyCertificateDetails.setOperationUsername(mcoKeyDetails.getUsername());
							}
							if(!StringUtils.isEmpty(mcoKeyDetails.getPassword())) {
								applianceDetailModel.setOperationPassword(mcoKeyDetails.getPassword());
								mcoKeyCertificateDetails.setOperationPassword(mcoKeyDetails.getPassword());
							}
							
							if(mcoKeyDetails.getDualFactorDetails()!=null) {
								if(applianceDetail.getFipsState().equalsIgnoreCase("3") && applianceDetail.isCredentialSaved()==false) {
								if(mcoKeyDetails.getDualFactorDetails()!=null && StringUtils.isEmpty(mcoKeyDetails.getDualFactorDetails().getDualFactorAuthServerPortNo())) {
									generateRequiredField(requiredFieldsMessage, "dualFactorAuthServerPortNo is required");
								}
								if(mcoKeyDetails.getDualFactorDetails()!=null && StringUtils.isEmpty(mcoKeyDetails.getDualFactorDetails().getDualFactorCertificateId())) {
									generateRequiredField(requiredFieldsMessage, "dualFactorCertificateId is required");
								}
								if(mcoKeyDetails.getDualFactorDetails()!=null && StringUtils.isEmpty(mcoKeyDetails.getDualFactorDetails().getDualFactorKeyFileId())) {
									generateRequiredField(requiredFieldsMessage, "dualFactorKeyFileId is required");
								}
								if(requiredFieldsMessage!=null && requiredFieldsMessage.length() == 0) {
									if(!StringUtils.isEmpty(applianceDetailModel.getOperationUsername())) {
										applianceDetail.setOperationUsername(applianceDetailModel.getOperationUsername());
									}
									if(!StringUtils.isEmpty(applianceDetailModel.getOperationPassword())) {
										applianceDetail.setOperationPassword(applianceDetailModel.getOperationPassword());
									}
									DualFactorUsersRelationshipModel dual=mcoKeyDetails.getDualFactorDetails();
									dualListForLoginHSM=applianceService.saveDualFactorDetails(dual, dualListForLoginHSM, applianceDetail, loggedInUser);
									dualListForLoginHSM.add(applianceDetailModel);
								}
							}else {
									generateRequiredField(requiredFieldsMessage, "Appliance not initialized with dual factor");
								}
							}else {
								if(applianceDetail.getFipsState().equalsIgnoreCase("3")) {
									generateRequiredField(requiredFieldsMessage, "dualFactorDetails is required");
								}
							}
							
							if(StringUtils.isEmpty(String.valueOf(requiredFieldsMessage))){	
							mcoKeyCertificateDetails.setApplianceId(applianceDetail.getApplianceId());
							mcoKeyCertificateDetails.setApplianceName(applianceDetail.getApplianceName());
							mcoKeyCertificateDetails.setApplianceIp(applianceDetail.getIpAddress());
							CaviumResponseModel responseModel=getCaviumResponseModel();
							
							responseModel.setResponseCode("200");
							List<ApplianceDetailModel> errorLoginHSM=null;
							if(dualListForLoginHSM!=null && dualListForLoginHSM.size() > 0) {
								errorLoginHSM=applianceService.validateCredentialsByLoginHSM(dualListForLoginHSM);
								if(errorLoginHSM!=null && !errorLoginHSM.isEmpty()) {
									ApplianceDetailModel errorApp=(ApplianceDetailModel)errorLoginHSM.get(0);
									if(!StringUtils.isEmpty(errorApp.getErrorMessage())) {
										responseModel.setResponseCode("412");
										responseModel.setResponseMessage(errorApp.getErrorMessage());
									}else {
										responseModel.setResponseCode("200");
									}
								}
							}
							if(responseModel!=null && responseModel.getResponseCode().equalsIgnoreCase("200")) {
								responseModel = applianceService.uploadMCOKeyCertificate(mcoKeyCertificateDetails,null,mcoKeyDetails.getUploadedFileId());
								if(responseModel!=null){
									res.setCode(responseModel.getResponseCode());
									if("200".equals(responseModel.getResponseCode())){
										res.setStatus("success");
										res.setCode("200");
										res.setMessage(responseModel.getResponseMessage());	
										res.setId(Long.valueOf(mcoKeyDetails.getApplianceId()));
									}else{
										res.setStatus("failed");
										res.setId(Long.valueOf(mcoKeyDetails.getApplianceId()));
										res.setMessage(responseModel.getResponseMessage());
									}
									res.setId(applianceDetail.getApplianceId());		
									res.setName(applianceDetail.getApplianceName());
								}else{
									res.setStatus("failed");
									res.setCode("412");
									res.setMessage("Response is coming as a null");
									res.setId(applianceDetail.getApplianceId());		
									res.setName(applianceDetail.getApplianceName());
								}
							}else {
								res.setStatus("failed");
								res.setCode("412");
								res.setMessage("LoginHSM for dual factor failed.");	
								res.setId(Long.valueOf(mcoKeyDetails.getApplianceId()));
								}
							}
							else{
								res.setCode("412");
								res.setStatus("Failed");
								if(!StringUtils.isEmpty(mcoKeyDetails.getApplianceId())){
									res.setMessage("Mandatory fields missing : "+ requiredFieldsMessage.substring(0,requiredFieldsMessage.length()-1) +" for ApplianceId " + mcoKeyDetails.getApplianceId());	
								}else{
									res.setMessage("Mandatory Fields missing : "+requiredFieldsMessage.substring(0,requiredFieldsMessage.length()-1) );		
								}

							}
						}else{
							res.setStatus("failed");
							res.setCode("404");
							res.setMessage("ApplianceId not exist");	
							res.setId(Long.valueOf(mcoKeyDetails.getApplianceId()));		
						}
					}else{
						res.setMessage("ApplianceId is required");
						res.setStatus("failed");
						res.setCode("412");
					}
				responseList.add(res);

			}
		}catch (Exception e) {
			logger.info(" Error coming in getSecurityLogsUrl method of ApplianceManagementController class ");	// TODO: handle exception
		}
		return responseList;
	}
	
	public void  checkMandatoryFieldsForMCOKeys(StringBuilder requiredFieldMessage,MCOKeyDetails mcoKeyDetails,boolean isCredentialsSaved){
		logger.info("Start of checkMandatoryField Method in ApplianceManagementController Class");

		if(StringUtils.isEmpty(mcoKeyDetails.getApplianceId())){
			requiredFieldMessage.append(CaviumConstant.APPLIANCE_ID).append(CaviumConstant.COMMA);
		}
	 
			if(StringUtils.isEmpty(mcoKeyDetails.getUsername()) && isCredentialsSaved==false){
				requiredFieldMessage.append(CaviumConstant.CRYPTO_OFFICER_NAME).append(CaviumConstant.COMMA);
			}
			if(StringUtils.isEmpty(mcoKeyDetails.getPassword()) && isCredentialsSaved==false){
				requiredFieldMessage.append(CaviumConstant.CRYPTO_OFFICER_PASSWORD).append(CaviumConstant.COMMA);
			}
			if(StringUtils.isEmpty(mcoKeyDetails.getUploadedFileId())){
				requiredFieldMessage.append(CaviumConstant.UPLOADED_FILE_ID).append(CaviumConstant.COMMA);
			}
			logger.info("End of checkMandatoryFieldsForMCOKeys Method in ApplianceManagementController Class");	 
	}
	
	public void  checkMandatoryFieldForHSMCertificateURL(StringBuilder requiredFieldMessage,HSMOwnerCertificatesModel hsmOwnerCertificatesDetail){
		if(StringUtils.isEmpty(hsmOwnerCertificatesDetail.getApplianceId())){
			requiredFieldMessage.append(CaviumConstant.APPLIANCE_ID).append(CaviumConstant.COMMA);
		}	
		if(StringUtils.isEmpty(hsmOwnerCertificatesDetail.getHsmCertificateType())){
			requiredFieldMessage.append(CaviumConstant.HSM_CERTIFICATE_TYPE).append(CaviumConstant.COMMA);
		}

	}

	
	@RequestMapping(value = "getHSMDetails", method = RequestMethod.GET, produces="application/json")
	public String getHSMDetails(@RequestParam("applianceIds")  String[] applianceIds) {

		List<String> reponseList= new ArrayList<String>();
		for(String id:applianceIds){

			if(!StringUtils.isEmpty(id)){
				ApplianceDetailModel appDB=applianceRepository.getApplianceById(Long.valueOf(id), StoreType.PERMANENT);
				if(appDB!=null && !StringUtils.isEmpty(appDB.getIpAddress())){
					String response=applianceManagementService.getHSMDetail(appDB.getIpAddress());
					reponseList.add(response);
				}else{
					JSONObject json= new JSONObject(); 
					json.put("status","failed");
					json.put("message","ApplianceId does not exists");
					json.put("code","404");
					json.put("applianceId",id);
					String failureResponse=json.toString();	
					reponseList.add(failureResponse);
				}
			}else{
				JSONObject json= new JSONObject(); 
				json.put("status","failed");
				json.put("message","ApplianceId is required");
				json.put("code","412");
				String failureResponse=json.toString();
				reponseList.add(failureResponse);
			}
		}

		return reponseList.toString();
	}
	
	/**
	 * This method is used to delete the given appliances
	 * @param applianceModels
	 * @return
	 */
	@RequestMapping(value = "deleteListOfAppliancesByIds", method = RequestMethod.DELETE)
	public final List<Response> deleteListOfAppliancesByIds(@RequestParam("applianceIds") String[] applianceIds){
		List<Response> responseList=new ArrayList<>();
		List<ApplianceDetailModel> listOfApp=new ArrayList<>();
		ApplianceDeleteFailureModel deleteValidateList=new ApplianceDeleteFailureModel();
		
		try {
			
			for(String id: applianceIds) {
				ApplianceDetailModel detailModel=new ApplianceDetailModel();
				Response response=new Response();
				if(!StringUtils.isEmpty(id)) {
					ApplianceDetailModel  appModels = applianceRepository.findOne(Long.parseLong(id));
					if(appModels!=null) {
						detailModel.setApplianceId(appModels.getApplianceId());
						detailModel.setApplianceName(appModels.getApplianceName());
						listOfApp.add(detailModel);
					}else {
						response.setCode("404");
						response.setStatus("failed");
						response.setMessage("Appliance does not exists into the system.");
						responseList.add(response);
					}
					
				}else {
					response.setCode("412");
					response.setMessage("applianceId is required.");
					responseList.add(response);
				}
			}
			
			if(listOfApp!=null && listOfApp.size() > 0) {
				deleteValidateList=applianceService.validateDeleteAppliance(listOfApp);
				List<ApplianceDetailModel> fipsList=new ArrayList<>();
				List<ApplianceDetailModel> successList=new ArrayList<>();
				List<ApplianceDetailModel> culsterList=new ArrayList<>();
				
				if(deleteValidateList.getFipsStateNonZeroize()!=null && deleteValidateList.getFipsStateNonZeroize().size() > 0) {
					fipsList=deleteValidateList.getFipsStateNonZeroize();
				}if(deleteValidateList.getSuccessList()!=null && deleteValidateList.getSuccessList().size() > 0) {
					successList=deleteValidateList.getSuccessList();
				}if(deleteValidateList.getDueToCluster()!=null && deleteValidateList.getDueToCluster().size() > 0) {
					culsterList=deleteValidateList.getDueToCluster();
				}
				if((fipsList!=null && fipsList.size() > 0) || (successList!=null && successList.size() > 0)) {
					for(ApplianceDetailModel app:fipsList) {
						successList.add(app);
					}
					
					for(ApplianceDetailModel app: successList) {
						Response response=new Response();
						CaviumResponseModel caviumResponseModel=applianceService.deleteAppliances(app);
						response.setCode(caviumResponseModel.getResponseCode());
						if(!StringUtils.isEmpty(caviumResponseModel.getResponseCode()) && caviumResponseModel.getResponseCode().equalsIgnoreCase("200")) {
							response.setStatus("success");
						}else {
							response.setStatus("failed");
						}
						response.setMessage(caviumResponseModel.getResponseMessage());
						response.setApplianceIp(app.getIpAddress());
						responseList.add(response);
					}
				}
				
				if(culsterList!=null && culsterList.size() > 0) {
					for(ApplianceDetailModel app: culsterList) {
						Response response=new Response();
						response.setCode("412");
						response.setStatus("failed");
						response.setMessage("Appliance can not be deleted due to cluster association.");
						response.setApplianceIp(app.getIpAddress());
						responseList.add(response);
					}
				}
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during delete appliances.");
		}
		return responseList;
	}
	
	@RequestMapping(value = "firmwareUpgrade", method = RequestMethod.PUT,consumes = {"multipart/form-data"})
	public List<Response> firmwareUpgrade(@RequestPart("appliances") String appliance, @RequestPart("signFile") MultipartFile signFile,@RequestPart("imageFile") MultipartFile imageFile)
	{
		String loggedInUser = userAttributes.getlogInUserName();
		List<Response> responseList=new ArrayList<>();
		try {
			if (signFile.isEmpty() || imageFile.isEmpty()) {
				Response res=new Response();
				res.setCode("412");
				res.setStatus("Failed");
				res.setMessage("either image or sign file is empty.");
				responseList.add(res);
			}else {
				File signFileConvertedFile = CaviumUtil.convertMultipartFileIntoNewFile(signFile);
				File imageFileConvertedFile = CaviumUtil.convertMultipartFileIntoNewFile(imageFile);
				if(!StringUtils.isEmpty(appliance)) {
						ObjectMapper mapper=new ObjectMapper();
						TypeFactory typeFactory = mapper.getTypeFactory();
						CollectionType collectionType = typeFactory.constructCollectionType(
								List.class, FirmwareUpgradeDetailModel.class);
						List<FirmwareUpgradeDetailModel> fwList =  mapper.readValue(appliance, collectionType);   
						ExecutorService executorService = Executors.newFixedThreadPool(10);
						if(fwList!=null && fwList.size() > 0) {
							for(FirmwareUpgradeDetailModel firmwareModel: fwList) {
								Long appId = new Long(firmwareModel.getApplianceId());
								
								StringBuilder errors=new StringBuilder();
								validateFirmwareUpgrdae(firmwareModel, errors,loggedInUser);
								if(StringUtils.isEmpty(errors.toString())) {
									ApplianceDetailModel app=new ApplianceDetailModel();
									app.setApplianceId(appId);
									app.setOperationUsername(firmwareModel.getUsername());
									app.setOperationPassword(firmwareModel.getPassword());
									app.setFirmwareUpgradeDetailModel(firmwareModel);
									/**
									 * Call parallel processing
									 */
									executorService.execute(new Runnable() {
									    public void run() {
									    	applianceService.doApplianceFirmwareUpgrade(app, imageFileConvertedFile, signFileConvertedFile,loggedInUser);
									    }
									});
									
									/**
									 * Update appliance detail model for firmware upgrade
									 */
									ApplianceDetailModel dbAppliance=applianceRepository.findOne(app.getApplianceId());
									dbAppliance.setLastOperationPerformed("FirmwareUpgrade");
									dbAppliance.setLastOperationStatus("In-Progress");
									dbAppliance.setCode("200");
									dbAppliance.setMessage("success");
									dbAppliance.setErrorMessage("");
									applianceRepository.save(dbAppliance);
									dbAppliance.setMessage("Firmware Upgrade operation initiated successfully");
									
									Response res=new Response();
									res.setMessage("Firmware Upgrade operation initiated successfully.");
									res.setCode("200");
									res.setId(dbAppliance.getApplianceId());
									res.setName(dbAppliance.getApplianceName());
									res.setStatus("success");
									responseList.add(res);
								}else {
									Response res=new Response();
									res.setMessage(errors.toString());
									res.setCode("412");
									res.setStatus("failed");
									res.setId(appId);
									responseList.add(res);
								}
							}
						}
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during applianceFirmwareUpgrade in ApplinaceController");
		}
		return responseList;
	}
	
	/**
	 * This method is used to get list of appliances
	 * @return
	 */
	@RequestMapping(value = "getApplianceById/{applianceId}", method = RequestMethod.GET)
	public Response getApplianceById(@PathVariable("applianceId") String applianceId) {
		logger.info("inside getApplianceById");
		Response response=new Response();
		List<Object> applianceModels=new ArrayList<>();
		try {
			if(!StringUtils.isEmpty(applianceId)) {

				ApplianceDetailModel   applianceDetailModel = applianceService.getApplianceById(applianceId);
				if(applianceDetailModel!=null) {
					ApplianceModel app = new ApplianceModel();
					app.setApplianceId(applianceDetailModel.getApplianceId());
					app.setApplianceName(applianceDetailModel.getApplianceName());
					app.setApplianceStatus(applianceDetailModel.getApplianceStatus());
					app.setSerialNumber(applianceDetailModel.getSerialNumber());
					if(applianceDetailModel.isCredentialSaved()) {
						app.setCredentialsSaved(true);
					}else {
						app.setCredentialsSaved(false);
					}
					
					if (!StringUtils.isEmpty(applianceDetailModel.getNetworkTimezone())) {
						Timezone timezone = new Timezone();
						timezone.setTimeZone(applianceDetailModel.getNetworkTimezone());
						app.setDateTime(timezone);
					}

					Network network = new Network();
					network.setIpAddress(applianceDetailModel.getIpAddress());
					app.setNetwork(network);

					Zone zone = new Zone();
					zone.setZoneId(applianceDetailModel.getZoneId());
					zone.setZoneName(applianceDetailModel.getCityName());
					app.setZone(zone);

					applianceModels.add(app);
					response.setCode("200");
					response.setMessage("Success");
					response.setData(applianceModels);
				}else {
					response.setCode("404");
					response.setMessage("Appliance does not exists.");
				}
			}else {
				response.setCode("412");
				response.setMessage("ApplianceId required.");
			}
		} catch (Exception e) {
			logger.error("error occured during getListOfAllAppliances" + e.getMessage());
		}
		return response;
	}
	
	/**
	 * This method is used to get list of appliances
	 * @return
	 */
	@RequestMapping(value = "getListOfAppliancesByIds", method = RequestMethod.GET)
	public Response getListOfAppliancesByIds(@RequestParam("applianceIds") String[] applianceIds) {
		logger.info("inside getApplianceById");
		Response response=new Response();
		List<Object> applianceModels=new ArrayList<>();
		try {
			if(applianceIds!=null && applianceIds.length!=0) {
				for(String id:applianceIds) {
					ApplianceDetailModel   applianceDetailModel = applianceService.getApplianceById(id);
					if(applianceDetailModel!=null) {
						ApplianceModel app = new ApplianceModel();
						app.setApplianceId(applianceDetailModel.getApplianceId());
						app.setApplianceName(applianceDetailModel.getApplianceName());
						app.setApplianceStatus(applianceDetailModel.getApplianceStatus());
						app.setSerialNumber(applianceDetailModel.getSerialNumber());
						if(applianceDetailModel.isCredentialSaved()) {
							app.setCredentialsSaved(true);
						}else {
							app.setCredentialsSaved(false);
						}
						
						if (!StringUtils.isEmpty(applianceDetailModel.getNetworkTimezone())) {
							Timezone timezone = new Timezone();
							timezone.setTimeZone(applianceDetailModel.getNetworkTimezone());
							app.setDateTime(timezone);
						}

						Network network = new Network();
						network.setIpAddress(applianceDetailModel.getIpAddress());
						app.setNetwork(network);

						Zone zone = new Zone();
						zone.setZoneId(applianceDetailModel.getZoneId());
						zone.setZoneName(applianceDetailModel.getCityName());
						app.setZone(zone);

						applianceModels.add(app);
					}else {
						response.setCode("404");
						response.setMessage("Appliance does not exists.");
						}
					}
				response.setCode("200");
				response.setMessage("success");
				response.setData(applianceModels);
			}else {
				response.setCode("412");
				response.setMessage("ApplianceId required.");
			}
		} catch (Exception e) {
			logger.error("error occured during getListOfAllAppliances" + e.getMessage());
		}
		return response;
	}
	
	private void validateFirmwareUpgrdae(FirmwareUpgradeDetailModel firmWareModel,StringBuilder requiredFiledNotAvailable,String loggedInUser) {
		try {
			List<ApplianceDetailModel> dualListForLoginHSM=new ArrayList<>();
			ApplianceDetailModel appmodel=new ApplianceDetailModel();
			if(firmWareModel!=null && !StringUtils.isEmpty(firmWareModel.getApplianceId())) {
				
				ApplianceDetailModel apdb=applianceRepository.findOne(Long.valueOf(firmWareModel.getApplianceId()));
				appmodel.setApplianceId(Long.valueOf(firmWareModel.getApplianceId()));
				if(apdb!=null && apdb.isCredentialSaved()==false) {
					if(firmWareModel!=null && StringUtils.isEmpty(firmWareModel.getUsername())) {
						generateRequiredField(requiredFiledNotAvailable, "username is required");
					}else{
						appmodel.setOperationUsername(firmWareModel.getUsername());
					}if(firmWareModel!=null && StringUtils.isEmpty(firmWareModel.getPassword())) {
						generateRequiredField(requiredFiledNotAvailable, "password is required");
					}else {
						appmodel.setOperationPassword(firmWareModel.getPassword());
					}
					
					if(firmWareModel.getDualFactorDetails()!=null) {
						if(apdb.getFipsState().equalsIgnoreCase("3") && apdb.isCredentialSaved()==false) {
						if(firmWareModel.getDualFactorDetails()!=null && StringUtils.isEmpty(firmWareModel.getDualFactorDetails().getDualFactorAuthServerPortNo())) {
							generateRequiredField(requiredFiledNotAvailable, "dualFactorAuthServerPortNo is required");
						}
						if(firmWareModel.getDualFactorDetails()!=null && StringUtils.isEmpty(firmWareModel.getDualFactorDetails().getDualFactorCertificateId())) {
							generateRequiredField(requiredFiledNotAvailable, "dualFactorCertificateId is required");
						}
						if(firmWareModel.getDualFactorDetails()!=null && StringUtils.isEmpty(firmWareModel.getDualFactorDetails().getDualFactorKeyFileId())) {
							generateRequiredField(requiredFiledNotAvailable, "dualFactorKeyFileId is required");
						}
						if(requiredFiledNotAvailable!=null && requiredFiledNotAvailable.length() == 0) {
							DualFactorUsersRelationshipModel dual=firmWareModel.getDualFactorDetails();
							dualListForLoginHSM=applianceService.saveDualFactorDetails(dual, dualListForLoginHSM, appmodel, loggedInUser);
						}
					}else {
						if(apdb.getFipsState().equalsIgnoreCase("3") && apdb.isCredentialSaved()) {
							generateRequiredField(requiredFiledNotAvailable, "dual factor details input not required as credentials are saved");
						}else {
							generateRequiredField(requiredFiledNotAvailable, "Appliance not initialize with dual factor");
							}
						
						}
					}else {
						if(apdb.getFipsState().equalsIgnoreCase("3")) {
							generateRequiredField(requiredFiledNotAvailable, "dualFactorDetails is required");
						}
					}
				}else {
					if(apdb==null) {
						generateRequiredField(requiredFiledNotAvailable, "appliance does not exists");
					}
				}
			if(firmWareModel!=null && StringUtils.isEmpty(firmWareModel.getHsmFirmwareType())) {
				generateRequiredField(requiredFiledNotAvailable, "hsmFirmwareType is required");
			}
			
			/**
			 * Validating loginHSM
			 */
		
			if(dualListForLoginHSM!=null && dualListForLoginHSM.size() > 0) {
				dualListForLoginHSM=applianceService.validateCredentialsByLoginHSM(dualListForLoginHSM);
				ApplianceDetailModel appErrors=(ApplianceDetailModel)dualListForLoginHSM.get(0);
				if(!StringUtils.isEmpty(appErrors.getErrorMessage())) {
					generateRequiredField(requiredFiledNotAvailable, appErrors.getErrorMessage());
				}else {
					requiredFiledNotAvailable=null;
				}
			}
			
			}else {
				generateRequiredField(requiredFiledNotAvailable, "applianceId is required.");
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during validation of firmware upgrade.");
		}
	}
	
	

}
