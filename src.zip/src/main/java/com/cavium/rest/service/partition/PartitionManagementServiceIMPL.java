package com.cavium.rest.service.partition;

public class PartitionManagementServiceIMPL {

}
