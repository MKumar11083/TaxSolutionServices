package com.cavium.mail;

import java.util.Map;

import org.apache.velocity.VelocityContext;
import org.springframework.mail.MailException;

/**
 * Interface provides methods for mail functionality
 * @author RK00490847
 */
public interface MailserviceInf {

	public void sendMail(String senderName, String senderAddress,  Map<String,String>  mapTo,
			 Map<String,String>  mapCc,  Map<String,String>  mapBcc, String strSubject, VelocityContext context,
			String strTemplate) throws MailException;

}
