package com.cavium.service.recentactivity;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.cavium.model.recentactivity.RecentActivity;
import com.cavium.repository.recentactivity.RecentActivityRepository;
import com.cavium.repository.user.UserRepository;
import com.cavium.utill.CaviumConstant;

@Component
public class RecentActivityServiceImpl implements RecentActivityService {

	@Autowired
	private RecentActivityRepository recentActivityRepository;
	@Autowired
	private UserRepository userrepository;
	private Logger logger = Logger.getLogger(this.getClass());
	
	public void createRecentActivity(String loggedInUser, String message,String moduleName) {
		// TODO Auto-generated method stub
		try {
			Calendar calendar = new GregorianCalendar();
			TimeZone timeZone = calendar.getTimeZone();
			String roleid=userrepository.getRoleID(loggedInUser);
			List<RecentActivity> recentlist= getRecentActivity(loggedInUser,moduleName);
			logger.info("Message in recentActivity :: " + message);
			if(recentlist.size() == 100) {
				RecentActivity recentact=recentlist.get(99);
				recentact.setUserGroupId(roleid);
				recentact.setMessage(message);
				recentact.setCreatedDate(new Date());
				recentact.setTimezone("["+timeZone.toZoneId()+"]");
				if(CaviumConstant.USER_LOGOUT_MANAGEMENT.equals(moduleName)){
					recentact.setAlreadyRead(true);	
				}
				recentact.setModuleName(moduleName);
				recentActivityRepository.save(recentact);
			}else {
				if(!StringUtils.isEmpty(roleid)) {
					RecentActivity activity=new RecentActivity();
					activity.setUserGroupId(roleid);
					activity.setMessage(message);
					activity.setCreatedDate(new Date());
					activity.setTimezone("["+timeZone.toZoneId()+"]");
					activity.setModuleName(moduleName);
					if(CaviumConstant.USER_LOGOUT_MANAGEMENT.equals(moduleName)){
						activity.setAlreadyRead(true);	
					}
					recentActivityRepository.save(activity);
				}
			}
			
		} catch (Exception e) {
			logger.error("Error occured due to db error inside createRecentActivity ::" + e.getMessage());
			// TODO: handle exception
		}
	}

	@Override
	public List<RecentActivity> getRecentActivity(String roleId,String moduleName) {
		// TODO Auto-generated method stub
		List<RecentActivity> recentActivity=null;
		try {
			String groupid=userrepository.getRoleID(roleId);
			if(!StringUtils.isEmpty(moduleName)) {
				recentActivity=recentActivityRepository.getRecentActivity(groupid,moduleName);
			}else {
				recentActivity=recentActivityRepository.getRecentActivityForDashboard(groupid);
			}
		
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured due to db error inside createRecentActivity ::" + e.getMessage());
		}
		return recentActivity;
	}
	
	@Override
	public RecentActivity getRecentActivityForNotification(String roleId) {
		RecentActivity recentActivity=null;
		try {
			boolean alreadyRead=false;
			String groupid=userrepository.getRoleID(roleId);
			recentActivity=recentActivityRepository.getRecentActivityForNotification(alreadyRead,groupid);		
			if(recentActivity!=null)
			{
				List<RecentActivity> recentlist= recentActivityRepository.getAllUnreadRecentActivites(alreadyRead, groupid);
								if (recentlist.size() > 1) {
									recentActivity.setMoreRecords(true);
								} else {
									recentActivity.setMoreRecords(false);
								}
				alreadyRead=true;
				recentActivityRepository.updateAlreadyReadValue(alreadyRead,groupid);
			}
		 } catch (Exception e) {			 
			logger.error("Error occured due to db error inside getRecentActivityForNotification ::" + e.getMessage());
		}
		return recentActivity;
	}
}
