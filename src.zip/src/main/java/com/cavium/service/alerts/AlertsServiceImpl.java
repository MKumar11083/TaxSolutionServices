package com.cavium.service.alerts;



import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.cavium.model.alerts.Alerts;
import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.partition.PartitionDetailModel;
import com.cavium.repository.alerts.AlertsRepository;
import com.cavium.repository.appliance.ApplianceRepository;
import com.cavium.repository.partition.PartitionRepository;
import com.cavium.repository.user.UserRepository;
import com.cavium.utill.CaviumConstant;

@Component
public class AlertsServiceImpl implements AlertsService {

	@Autowired
	private AlertsRepository alertsRepository;
	@Autowired
	private UserRepository userrepository;
	@Autowired
	private ApplianceRepository applianceRepository;
	@Autowired
	private PartitionRepository partitionRepository;
	private Logger logger = Logger.getLogger(this.getClass());
	
	public void createAlert(String loggedInUser, String message,String moduleType) {
		// TODO Auto-generated method stub
		try {
			Calendar calendar = new GregorianCalendar();
			TimeZone timeZone = calendar.getTimeZone();
			String roleid=userrepository.getRoleID(loggedInUser);
			logger.info("Message in Alerts :: " + message);
			List<Alerts> alertList= getAlerts(loggedInUser,moduleType);
			if(alertList.size() == 100) {
				Alerts alert=alertList.get(99);
				alert.setUserGroupId(roleid);
				alert.setMessage(message);
				alert.setCreatedDate(new Date());
				alert.setTimezone("["+timeZone.toZoneId()+"]");
				alert.setModuleType(moduleType);
				alertsRepository.save(alert);
			}else {
				if(!StringUtils.isEmpty(roleid)) {
					Alerts alert=new Alerts();
					alert.setUserGroupId(roleid);
					alert.setMessage(message);
					alert.setCreatedDate(new Date());
					alert.setTimezone("["+timeZone.toZoneId()+"]");
					alert.setModuleType(moduleType);
					alertsRepository.save(alert);
				}
			}
			
		} catch (Exception e) {
			logger.error("Error occured due to db error inside createAlert ::" + e.getMessage());
			// TODO: handle exception
		}
	}

	
	public void createAlert(String loggedInUser, String message,String moduleName,Long moduleId,String moduleType) {
		// TODO Auto-generated method stub
		Long applianceId=null;
		String applianceName=null;
		String ip=null;
		if((!StringUtils.isEmpty(moduleType) && moduleType.equalsIgnoreCase(CaviumConstant.APPLIANCE_MANAGEMENT)) && moduleId!=null) {
			ApplianceDetailModel dbAppliance = applianceRepository.findOne(moduleId);
			applianceId=dbAppliance.getApplianceId();
			applianceName=dbAppliance.getApplianceName();
			ip=dbAppliance.getIpAddress();
			
		}if((!StringUtils.isEmpty(moduleType) &&  moduleType.equalsIgnoreCase(CaviumConstant.PARTITION_MANAGEMENT)) && moduleId!=null) {
			PartitionDetailModel pdm=partitionRepository.findOne(moduleId);
			if(pdm!=null && pdm.getApplianceDetailModel()!=null) {
				applianceId=pdm.getApplianceDetailModel().getApplianceId();
				applianceName=pdm.getApplianceDetailModel().getApplianceName();
				ip=pdm.getApplianceDetailModel().getIpAddress();
			}
		}
		try {
			Calendar calendar = new GregorianCalendar();
			TimeZone timeZone = calendar.getTimeZone();
			String roleid=userrepository.getRoleID(loggedInUser);
			logger.info("Message in Alerts :: " + message);
			List<Alerts> alertList= getAlerts(loggedInUser,moduleType);
			if(alertList.size() == 100) {
				Alerts alert=alertList.get(99);
				alert.setUserGroupId(roleid);
				alert.setMessage(message);
				alert.setCreatedDate(new Date());
				alert.setTimezone("["+timeZone.toZoneId()+"]");
				alert.setModuleId(moduleId);
				alert.setModuleName(moduleName);
				alert.setModuleType(moduleType);
				alert.setApplianceId(applianceId);
				alert.setApplianceName(applianceName);
				alert.setApplianceIp(ip);
				alertsRepository.save(alert);
			}else {
				if(!StringUtils.isEmpty(roleid)) {
					Alerts alert=new Alerts();
					alert.setUserGroupId(roleid);
					alert.setMessage(message);
					alert.setTimezone("["+timeZone.toZoneId()+"]");
					alert.setCreatedDate(new Date());
					alert.setModuleId(moduleId);
					alert.setModuleName(moduleName);
					alert.setModuleType(moduleType);
					alert.setApplianceId(applianceId);
					alert.setApplianceName(applianceName);
					alert.setApplianceIp(ip);
					alertsRepository.save(alert);
				}
			}
			
		} catch (Exception e) {
			logger.error("Error occured due to db error inside createAlert ::" + e.getMessage());
			// TODO: handle exception
		}
	}
	
	@Override
	public List<Alerts> getAlerts(String roleId,String moduleType) {
		// TODO Auto-generated method stub
		List<Alerts> alerts=null;
		try {
			String groupid=userrepository.getRoleID(roleId);
			if(!StringUtils.isEmpty(moduleType)) {
				alerts=alertsRepository.getAlerts(groupid,moduleType);
			}else {
				alerts=alertsRepository.getAlertsForDashboard(groupid);
			}
			
		} catch (Exception e) { 
			logger.error("Error occured due to db error inside getAlerts ::" + e.getMessage());
		}
		return alerts;
	}
	
	@Override
	public Alerts getAlertForNotification(String roleId) {
		Alerts alerts=null;
		try {
			boolean alreadyRead=false;
			String groupid=userrepository.getRoleID(roleId);
			alerts=alertsRepository.getAlertForNotification(alreadyRead,groupid);		
			if(alerts!=null)
			{
				List<Alerts> alertsList = alertsRepository.getAllUnreadAlerts(alreadyRead, groupid);
								
								if (alertsList.size() > 1) {
									alerts.setMoreRecords(true);
								} else {
									alerts.setMoreRecords(false);
								}
				alreadyRead=true;
				alertsRepository.updateAlreadyReadValue(alreadyRead,groupid);
			}
		 } catch (Exception e) {			 
			logger.error("Error occured due to db error inside getAlertsForNotification ::" + e.getMessage());
		}
		return alerts;
	}
	
}
