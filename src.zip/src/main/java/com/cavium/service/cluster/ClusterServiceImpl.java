package com.cavium.service.cluster;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.appliance.DualFactorAuthDetailModel;
import com.cavium.model.appliance.DualFactorUsersRelationshipModel;
import com.cavium.model.appliance.InitializeApplianceDetailModel;
import com.cavium.model.appliance.InitializeAppliancesRelationshipModel;
import com.cavium.model.cluster.ClusterDetailModel;
import com.cavium.model.cluster.ClusterPartitionsRelationship;
import com.cavium.model.partition.PartitionData;
import com.cavium.model.partition.PartitionDetailModel;
import com.cavium.model.recentactivity.InProgressActivity;
import com.cavium.model.user.UserDetailModel;
import com.cavium.pojo.ConnectedPartitions;
import com.cavium.pojo.UserAttributes;
import com.cavium.repository.appliance.ApplianceRepository;
import com.cavium.repository.appliance.DualFactorUsersRelationshipRepository;
import com.cavium.repository.appliance.InitializeAppliancesRelationshipReposiotry;
import com.cavium.repository.appliance.InitializeRepository;
import com.cavium.repository.cluster.ClusterPartitionsRelationshipRepository;
import com.cavium.repository.cluster.ClusterRepository;
import com.cavium.repository.partition.PartitionDataRepository;
import com.cavium.repository.partition.PartitionRepository;
import com.cavium.repository.user.UserGroupRepository;
import com.cavium.repository.user.UserRepository;
import com.cavium.service.alerts.AlertsService;
import com.cavium.service.appliance.ApplianceService;
import com.cavium.service.fileupload.FileUploadService;
import com.cavium.service.partition.PartitionService;
import com.cavium.service.recentactivity.InProgressActivityService;
import com.cavium.service.recentactivity.RecentActivityService;
import com.cavium.service.user.UserService;
import com.cavium.utill.CaviumConstant;
import com.cavium.utill.CaviumResponseModel;
import com.cavium.utill.CaviumUtil;
import com.cavium.utill.RestClient;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class ClusterServiceImpl implements ClusterService{

	private Logger logger = Logger.getLogger(this.getClass());

	/**
	 * This class is used to set the response attributes for incoming requests
	 */
	@Lookup
	public CaviumResponseModel getCaviumResponseModel() {
		return null;
	}
	@Autowired
	private UserService userService;

	@Autowired
	private FileUploadService fileUploadService;
	/**
	 * This Interface is used to get the values from the property file
	 */
	@Autowired
	Environment env;

	@Autowired
	RestClient restClient;

	@Autowired
	UserGroupRepository userGroupRepository;


	@Autowired
	private ClusterRepository clusterRepository;

	@Autowired
	private UserAttributes userAttributes;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private PartitionRepository partitionRepository;

	@Autowired
	private ApplianceService applianceService;


	@Autowired
	private AlertsService alertsService;

	@Autowired
	private PartitionService partitionService;

	@Autowired
	private InProgressActivityService inProgressActivityService;

	@Autowired
	private ApplianceRepository applianceRepository;

	@Autowired
	private InitializeRepository initializeRepository;

	@Autowired
	private InitializeAppliancesRelationshipReposiotry initializeAppliancesRelationshipReposiotry;

	@Autowired
	ClusterPartitionsRelationshipRepository clusterPartitionsRelationshipRepository;

	@Autowired
	private RecentActivityService recentActivityService;

	@Autowired
	private DualFactorUsersRelationshipRepository dfUsersRelationshipRepository;

	@Autowired
	private PartitionDataRepository partitionDataRepository;


	public final ClusterPartitionsRelationship comparePartitionsDetails(ClusterPartitionsRelationship clusterPartitionsRelationship){
		logger.info("Start of comparePartitionsDetails Method of ClusterServiceImpl class");
		PartitionData partitionData=new PartitionData();
		ResponseEntity<String> response=null;
		try {
			response=restClient.invokeGETMethod("https://"+clusterPartitionsRelationship.getIpAddress()+"/liquidsa/partition/"+clusterPartitionsRelationship.getPartitionName()+"");
		} catch (KeyManagementException e) {

			logger.error("Error occured during restClient call for partitioninfo in comparePartitionsDetails method of ClusterServiceImpl class  :: "+e.getMessage());
		} catch (KeyStoreException e) {

			logger.error("Error occured during restClient call for partitioninfo in comparePartitionsDetails method of ClusterServiceImpl class ::  "+e.getMessage());
		} catch (NoSuchAlgorithmException e) {
			logger.error("Error occured during restClient call for partitioninfo in comparePartitionsDetails method  of ClusterServiceImpl class :: "+e.getMessage());
		}
		if(response != null && response.getBody() != null ){
			JSONObject jsonObject=new JSONObject(response.getBody());
			partitionData=partitionService.validatePartitionInformationModel(jsonObject);
			clusterPartitionsRelationship.setPartitionData(partitionData);
			Integer maxKeys=clusterPartitionsRelationship.getPartitionData().getMaxKeys();
			Integer occupiedSessionKeys=clusterPartitionsRelationship.getPartitionData().getOccupiedSessionKeys();
			Integer	occupiedTokenKeys=clusterPartitionsRelationship.getPartitionData().getOccupiedTokenKeys();
			Integer sslContextUsed=clusterPartitionsRelationship.getPartitionData().getOccupiedSslCtxs();
			Integer totalsslContext=clusterPartitionsRelationship.getPartitionData().getTotalSslCtxs();
			if(totalsslContext!=null && sslContextUsed!=null){
				Integer sslContextAvaliable=totalsslContext-sslContextUsed;
				clusterPartitionsRelationship.getPartitionData().setSslContextAvaliable(sslContextAvaliable);
			} 
			if(maxKeys!=null && occupiedSessionKeys!=null && occupiedTokenKeys!=null){
				Integer keysAvaliable=maxKeys-occupiedSessionKeys-occupiedTokenKeys;
				Integer keysUsed=occupiedSessionKeys+occupiedTokenKeys;			
				clusterPartitionsRelationship.getPartitionData().setKeysAvaliable(keysAvaliable);
				clusterPartitionsRelationship.getPartitionData().setKeysUsed(keysUsed);
			}
		}
		logger.info("end of comparePartitionsDetails Method of ClusterServiceImpl class");
		return clusterPartitionsRelationship;
	}


	public ClusterDetailModel createCluster(ClusterDetailModel clusterDetailModel){
		logger.info("Start of createCluster Method of ClusterServiceImpl class");
		ResponseEntity<String> response=null;
		int maximumVersion=0;
		int recordCount=0;
		String loggedInUser = userAttributes.getlogInUserName();
		List<Long> deletedPartitionsIds=new ArrayList<Long>();
		List<String> ipList= new ArrayList<String>();
		UserDetailModel userDetailModel=userService.getUserDetails(loggedInUser);
		if(!StringUtils.isEmpty(clusterDetailModel.getClusterName())) {
			logger.info("cluster Name is not empty  :: "+clusterDetailModel.getClusterName());
			Long groupId=userDetailModel.getObjUserGroupModel().getId();
			String clusterName=clusterDetailModel.getClusterName();
			recordCount=clusterRepository.clusterNameExistorNotinGroup(clusterName,groupId);
			if(recordCount==0 || clusterDetailModel.getClusterId()!=null){
				logger.info("cluster Name :: "+clusterDetailModel.getClusterName());			
				maximumVersion= getMaximumChannelVersion(clusterDetailModel);				
				List<Integer> alreadyAddedNodeIdsList=null;
				if(maximumVersion!=-1){
					int failedCount=0;
					Long clusterId=clusterDetailModel.getClusterId();
					if(clusterId!=null){
						Integer maxClusterVersionNum=clusterRepository.getmaxCluterVersionNumber(clusterId);
						if(maxClusterVersionNum!=null && maxClusterVersionNum>maximumVersion){
							maximumVersion=maxClusterVersionNum;
						}
						alreadyAddedNodeIdsList=clusterPartitionsRelationshipRepository.getListOfNodeIdsForClusterId(clusterDetailModel.getClusterId());
					}
					logger.info(" No error is coming in getting cav Server configuration for Partitions");
					StringBuilder errorMessages= new StringBuilder();
					List<ClusterPartitionsRelationship>	clusterPartitionsRelationshipList=clusterDetailModel.getClusterPartitionsRelationships();
				int	requestCount=clusterPartitionsRelationshipList.size();		
					try {
						for(ClusterPartitionsRelationship clusterPartitionsRelationship : clusterPartitionsRelationshipList)
						{
							Long partitionId=clusterPartitionsRelationship.getPartitionId();
							if(partitionId!=null){
								PartitionDetailModel partitionDetailModel=partitionRepository.findOne(partitionId);
								clusterPartitionsRelationship.setPartitionDetailModel(partitionDetailModel);
							}
							JSONObject json = new JSONObject(); 
							ApplianceDetailModel dbAppliance=applianceRepository.findOne(clusterPartitionsRelationship.getApplianceId()); 
							if(dbAppliance!=null) {  
								long applianceId=dbAppliance.getApplianceId();
								List<DualFactorUsersRelationshipModel> dfmodelList=dfUsersRelationshipRepository.getDualFactorDetails(loggedInUser, applianceId);		
								DualFactorUsersRelationshipModel dfmodel=null;
								if(dfmodelList!=null && dfmodelList.size()>0){
									dfmodel=dfmodelList.get(0);
								}
								InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(applianceId);
								if(initmodel!=null) {
									InitializeApplianceDetailModel initAppDetailModel = initializeRepository.findOne(initmodel.getInitializeId());
									DualFactorAuthDetailModel dualAuthModel=initAppDetailModel.getDualFactorAuthDetailModel();
									if(!StringUtils.isEmpty(clusterPartitionsRelationship.getOperationPerformedUserName()) && !StringUtils.isEmpty(clusterPartitionsRelationship.getOperationPerformedPassword())) {
										if(initAppDetailModel.getAuthenticationLevel()==0) {
											json.put("username", clusterPartitionsRelationship.getOperationPerformedUserName());
											json.put("password", clusterPartitionsRelationship.getOperationPerformedPassword());
										}
										if(initAppDetailModel.getAuthenticationLevel() == 1 && dfmodel==null){
											dfmodel=createDualFile(loggedInUser, applianceId,initAppDetailModel.getCryptoOfficerName(),CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()),dualAuthModel);
										}
										if(initAppDetailModel.getAuthenticationLevel()==1 && dfmodel!=null) {
											json.put("username", clusterPartitionsRelationship.getOperationPerformedUserName());
											json.put("password", clusterPartitionsRelationship.getOperationPerformedPassword());

											json.put("dualFactorKeyFile", dfmodel.getDualFactorKeyFileId());
											json.put("dualFactorPort", Integer.parseInt(dfmodel.getDualFactorAuthServerPortNo()));
											json.put("dualFactorCertificate", dfmodel.getDualFactorCertificateId());
										}
									}else {
										if(initAppDetailModel.getAuthenticationLevel()==0) {
											json.put("username", initAppDetailModel.getCryptoOfficerName());
											json.put("password", CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));
										}	
										if(initAppDetailModel.getAuthenticationLevel() == 1 && dfmodel==null){
											dfmodel=createDualFile(loggedInUser, applianceId,initAppDetailModel.getCryptoOfficerName(),CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()),dualAuthModel);
										}
										if(initAppDetailModel.getAuthenticationLevel()==1 && dfmodel!=null) {
											json.put("username", initAppDetailModel.getCryptoOfficerName());
											json.put("password", CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));										 
											json.put("dualFactorKeyFile", dfmodel.getDualFactorKeyFileId());
											json.put("dualFactorPort", Integer.parseInt(dfmodel.getDualFactorAuthServerPortNo()));
											json.put("dualFactorCertificate", dfmodel.getDualFactorCertificateId());
										}
									}
								}
								else {
									if(dfmodel!=null){
										json.put("dualFactorKeyFile", dfmodel.getDualFactorKeyFileId());
										json.put("dualFactorPort", Integer.parseInt(dfmodel.getDualFactorAuthServerPortNo()));
										json.put("dualFactorCertificate", dfmodel.getDualFactorCertificateId());
									}
									if(!StringUtils.isEmpty(clusterPartitionsRelationship.getOperationPerformedUserName()) && !StringUtils.isEmpty(clusterPartitionsRelationship.getOperationPerformedPassword())) {
										json.put("username", clusterPartitionsRelationship.getOperationPerformedUserName());
										json.put("password", clusterPartitionsRelationship.getOperationPerformedPassword());
									}else {
										clusterDetailModel.setCode("409");
										clusterDetailModel.setErrorMessage("Cluster not created due to credentails not available");
										alertsService.createAlert(loggedInUser,"Device "+clusterDetailModel.getClusterName()+"  try to perofrm created by "+loggedInUser+ " at "+CaviumUtil.formatDateTimeFromCurrenDate(new Date()) +" did not create due to credentail not provided.",CaviumConstant.CLUSTER_MANAGEMENT);
										logger.error("Credentails not provided  in createCluster method of ClusterServiceImpl class");
										return clusterDetailModel;	
									}
								}
								json.put("partitionName", clusterPartitionsRelationship.getPartitionName());
								json.put("clusterVersion",maximumVersion+1);
								List<Map<String,Object>> clusterList= new ArrayList<Map<String,Object>>();


								for(ClusterPartitionsRelationship clusterPartitionsRelation : clusterPartitionsRelationshipList)
								{
									if((!clusterPartitionsRelationship.getPartitionId().equals(clusterPartitionsRelation.getPartitionId())) || clusterPartitionsRelationshipList.size()==1){
										Map<String,Object> clusterMap= new HashMap<String,Object>();
										clusterMap.put("nodeId",clusterPartitionsRelation.getNodeId());
										clusterMap.put("zoneId", clusterPartitionsRelation.getZoneId());
										clusterMap.put("mainChannelPort",clusterPartitionsRelation.getMainChannelPort());
										clusterMap.put("backChannelPort",clusterPartitionsRelation.getBackChannelPort());
										clusterMap.put("remoteEth0IPAddr",clusterPartitionsRelation.getRemoteEth0Addr());
										clusterMap.put("utilChannelPort",clusterPartitionsRelation.getUtilChannelPort());
										if(clusterPartitionsRelation.getRemoteEth1Addr()!=null  && !clusterPartitionsRelation.getRemoteEth1Addr().equalsIgnoreCase("null")){
											clusterMap.put("remoteEth1IPAddr",clusterPartitionsRelation.getRemoteEth1Addr());
										}
										clusterList.add(clusterMap);
									}
								}
								json.put("cluster",clusterList);
								if(!StringUtils.isEmpty(ipList) && ipList.contains(clusterPartitionsRelationship.getIpAddress())){
									Thread.sleep(8000); // 8 second
								}
								response=restClient.invokePOSTMethodForOperations("https://"+clusterPartitionsRelationship.getIpAddress()+"/liquidsa/add_cluster_node",json);
								if (response != null && response.getBody() != null) {								
									ObjectMapper mapper = new ObjectMapper();
									clusterDetailModel.setCreatedBy(loggedInUser);
									JsonNode root = mapper.readTree(response.getBody());
								
									if (response != null && response.getBody() != null
											&& response.getBody().contains("success")) {								
										ipList.add(clusterPartitionsRelationship.getIpAddress());								  
										boolean isAdded=false;
										try{
											 if(clusterPartitionsRelationshipList!=null && clusterPartitionsRelationshipList.size()>0 ){
												 if(alreadyAddedNodeIdsList== null || (alreadyAddedNodeIdsList!=null && alreadyAddedNodeIdsList.size()==0 ) || (alreadyAddedNodeIdsList!=null && !alreadyAddedNodeIdsList.contains(clusterPartitionsRelationship.getNodeId()))){
													String errorMessage="";
													String lastOperationStatus="In-Progress";
													String lastOperationPerformed=CaviumConstant.CREATE_CLUSTER;
													String status="Completed";	
													boolean partOfCluster=true;
													partitionRepository.updatePartitionStatus(status,lastOperationStatus,lastOperationPerformed,errorMessage,partitionId);
													partitionRepository.updatePartOfCluster(partOfCluster,partitionId);
													List <ClusterPartitionsRelationship> list= new ArrayList<ClusterPartitionsRelationship>();
													clusterDetailModel.setClusterVersion(maximumVersion+1);
													clusterDetailModel.setClusterName(clusterName);
													clusterDetailModel.setGroupId(groupId);
													clusterDetailModel.setLastOperationPerformed("create Cluster");
													clusterDetailModel.setLastOperationStatus("In-Progress");
													list.add(clusterPartitionsRelationship);
														if(clusterDetailModel.getClusterId()!=null){
													List<ClusterPartitionsRelationship>	alreadyAdded=clusterPartitionsRelationshipRepository.getListOfPartitionsForClusterId(clusterDetailModel.getClusterId());
													list.addAll(alreadyAdded);
														}
												clusterDetailModel.setClusterPartitionsRelationships(list);
												clusterDetailModel.setErrorMessage("");
												clusterDetailModel.setMessage("");
												ClusterDetailModel clusterDetailModelDB=clusterRepository.save(clusterDetailModel);	
												isAdded=true;
												 }
												requestCount=requestCount-1;
												if(clusterDetailModel!=null && clusterDetailModel.getClusterId()!=null){
													clusterRepository.updateRequestCount(Long.valueOf(requestCount),clusterDetailModel.getClusterId());
												}
											}											
										}catch (Exception e) {
											clusterDetailModel.setMessage("Error coming while creating Cluster.");
											clusterDetailModel.setCode("415");
											logger.error("error coming while saving cluster details in Database in createCluster method of ClusterServiceImpl class :: "+e.getMessage());
										}
										updateInProgressActivity(dbAppliance.getApplianceName(),clusterPartitionsRelationship, loggedInUser, root,clusterDetailModel.getClusterId(),false,isAdded);										 
										PartitionDetailModel pdmObj=clusterPartitionsRelationship.getPartitionDetailModel();
										if(pdmObj==null){
											pdmObj	=partitionRepository.findOne(partitionId);
										}
										if(StringUtils.isEmpty(String.valueOf(errorMessages).trim())){
											clusterDetailModel.setMessage("Cluster Creation initiated Successfully.");
										}else{
											clusterDetailModel.setMessage(pdmObj.getPartitionName() + ":: Cluster Creation initiated Successfully."+"@#"+errorMessages);	
										}
										pdmObj.setMessage("Create partition " + pdmObj.getPartitionName() +" initiated successfully for  cluster "+clusterDetailModel.getClusterName()+"");
										pdmObj.setCode("200");
										clusterDetailModel.setCode("200");
										clusterPartitionsRelationship.setPartitionDetailModel(pdmObj);

									} else {
										failedCount=failedCount+1;
										requestCount=requestCount-1;
										if(clusterDetailModel!=null && clusterDetailModel.getClusterId()!=null){
											clusterRepository.updateRequestCount(Long.valueOf(requestCount),clusterDetailModel.getClusterId());
										}
										PartitionDetailModel pdmObj=clusterPartitionsRelationship.getPartitionDetailModel();
										if(pdmObj==null){
											pdmObj	=partitionRepository.findOne(partitionId);
										}
										pdmObj=partitionService.getErrorMessage(response, pdmObj, loggedInUser,CaviumConstant.CREATE_CLUSTER);

										alertsService.createAlert(loggedInUser,"Partition "+pdmObj.getPartitionName()+" creation on cluster "+clusterDetailModel.getClusterName() +" by "+clusterDetailModel.getCreatedBy()+" did not complete due to "+pdmObj.getErrorMessage()+"",clusterDetailModel.getClusterName(),pdmObj.getPartitionId(),CaviumConstant.PARTITION_MANAGEMENT);
										logger.error("Getting error status in  response while calling Cavium Rest API in createCluster method of ClusterServiceImpl class");
										clusterPartitionsRelationship.setPartitionDetailModel(pdmObj);
										String lastOperationStatus="Failed";
										String lastOperationPerformed=CaviumConstant.CREATE_CLUSTER;
										String status="Failed";	
										String errorMessage=pdmObj.getErrorMessage();
										errorMessages=errorMessages.append(pdmObj.getPartitionName() +" :: " + errorMessage).append("@#");
									 if(alreadyAddedNodeIdsList== null || (alreadyAddedNodeIdsList!=null && alreadyAddedNodeIdsList.size()==0 ) || (alreadyAddedNodeIdsList!=null && !alreadyAddedNodeIdsList.contains(clusterPartitionsRelationship.getNodeId()))){
										boolean partOfCluster=false;
										partitionRepository.updatePartOfCluster(partOfCluster,partitionId);
										partitionRepository.updatePartitionStatus(status,lastOperationStatus,lastOperationPerformed,errorMessage,partitionId);
										deletedPartitionsIds.add(partitionId);
										 }								
									}
								} else {
									failedCount=failedCount+1;
									logger.error("response is coming null while calling Cavium Rest API in createCluster method of ClusterServiceImpl class");
									PartitionDetailModel pdmObj=clusterPartitionsRelationship.getPartitionDetailModel();
									if(pdmObj==null){
										pdmObj	=partitionRepository.findOne(partitionId);
									}
									String lastOperationStatus="Failed";
									String lastOperationPerformed=CaviumConstant.CREATE_CLUSTER;
									String status="Failed";	
									String errorMessage="Response coming as null";
									errorMessages=errorMessages.append(pdmObj.getPartitionName() +" :: " + errorMessage).append("@#");
									partitionRepository.updatePartitionStatus(status,lastOperationStatus,lastOperationPerformed,errorMessage,partitionId);
									 if(alreadyAddedNodeIdsList== null || (alreadyAddedNodeIdsList!=null && alreadyAddedNodeIdsList.size()==0 ) || (alreadyAddedNodeIdsList!=null && !alreadyAddedNodeIdsList.contains(clusterPartitionsRelationship.getNodeId()))){
									boolean partOfCluster=false;
									partitionRepository.updatePartOfCluster(partOfCluster,partitionId);
									deletedPartitionsIds.add(partitionId);
									 }
									alertsService.createAlert(loggedInUser,"Partition "+pdmObj.getPartitionName()+" creation on cluster "+clusterDetailModel.getClusterName() +" by "+clusterDetailModel.getCreatedBy()+" did not complete due to internal error",clusterDetailModel.getClusterName(),pdmObj.getPartitionId(),CaviumConstant.PARTITION_MANAGEMENT);
									clusterPartitionsRelationship.setPartitionDetailModel(pdmObj);
								 }
							}
						}
						if(clusterPartitionsRelationshipList!=null && clusterPartitionsRelationshipList.size()>0){
							if(failedCount==clusterPartitionsRelationshipList.size()){
								clusterRepository.delete(clusterDetailModel);
								clusterDetailModel.setLastOperationPerformed("");
								clusterDetailModel.setLastOperationStatus("");
								if(!StringUtils.isEmpty(errorMessages)) {
									String errorMessage=String.valueOf(errorMessages);
									errorMessage=errorMessage.substring(0,errorMessage.length()-2);
									clusterDetailModel.setMessage(errorMessage);
									clusterDetailModel.setErrorMessage(errorMessage);
								}
								else{
									clusterDetailModel.setMessage("All partitions have some errors while added to cluster.");
									clusterDetailModel.setErrorMessage("All partitions have some errors while added to cluster.");
								}
								clusterDetailModel.setCode("415");
							}else{
								if(deletedPartitionsIds.size()>0){
									clusterDetailModel.setDeletedPartitionIds(deletedPartitionsIds);
								}
							}
						}

					}
					catch (Exception e) {
						clusterDetailModel.setLastOperationPerformed("");
						clusterDetailModel.setLastOperationStatus("");
						clusterDetailModel.setMessage("Error coming while creating Cluster.");
						clusterDetailModel.setErrorMessage("Error coming while creating Cluster.");
						clusterDetailModel.setCode("415");
						logger.error("Some error is coming while calling Cavium Rest API in createCluster method of ClusterServiceImpl class .." +e.getMessage());
					}
				}
			}else{
				clusterDetailModel.setLastOperationPerformed("");
				clusterDetailModel.setLastOperationStatus("");
				clusterDetailModel.setCode("409");
				clusterDetailModel.setMessage("Cluster Name already exist.Please provide another name.");
				clusterDetailModel.setErrorMessage("Cluster Name already exist.Please provide another name.");		
				return clusterDetailModel;	

			}
		}
		logger.info("end of createCluster Method of ClusterServiceImpl class");
		if(clusterDetailModel!=null && clusterDetailModel.getMessage()!=null && clusterDetailModel.getMessage().contains("@#"))
		{
			clusterDetailModel.setMessage("200");
			clusterDetailModel.setMessage(clusterDetailModel.getMessage().substring(0,clusterDetailModel.getMessage().length()-2));
		}

		return clusterDetailModel;
	}

	private void updateInProgressActivity(String applianceName,ClusterPartitionsRelationship clusterPartitionsRelationship,String loggedInUser, JsonNode root,Long clusterId,boolean parttionDeleted,boolean partitionAdded) {
		try {
		InProgressActivity activity = new InProgressActivity();
			activity.setCreatedBy(loggedInUser);
			activity.setIpAddress(clusterPartitionsRelationship.getIpAddress());
			Integer jobId = 0;
			if (!root.path("jobId").isNull()) {
				jobId = root.path("jobId").asInt();
			} else {
				jobId = 000;
			}
			activity.setJobId(jobId);
			activity.setModuleName(CaviumConstant.CLUSTER_MANAGEMENT);
			activity.setOperationName(root.path("operation").asText());
			activity.setStatus("In-Progress");
			activity.setPartitionId(clusterPartitionsRelationship.getPartitionId());
			activity.setClusterId(clusterId);
			activity.setPartitionDeleted(parttionDeleted);
			activity.setPartitionAdded(partitionAdded);
			activity.setApplianceName(applianceName);
			inProgressActivityService.createInProgressActivity(activity);
		} catch (Exception e) {
			logger.error("Error occured during updateInProgressActivity"+e.getMessage());
		}
		
	}

	public ClusterDetailModel removePartitionsFromCluster(ClusterDetailModel clusterDetailModel){

		logger.info("Start of removeCluster Method of ClusterServiceImpl class");
		ResponseEntity<String> response=null;
		String loggedInUser = userAttributes.getlogInUserName();
		Long clusterId=	clusterDetailModel.getClusterId();
		String lastOperationPerformed=CaviumConstant.REMOVE_CLUSTER;
		List<String> ipList= new ArrayList<String>();
		clusterDetailModel.setErrorMessage("");
		clusterDetailModel.setMessage("");
		try{
			int partitionsCount=clusterPartitionsRelationshipRepository.getNumberOfPartitionForCluster(clusterDetailModel.getClusterId());
			if(clusterDetailModel.getOperationType()!=null && "removeCluster".equals(clusterDetailModel.getOperationType()) && partitionsCount==1)
			{
				PartitionDetailModel pdmObj=null;
				Long partitionId=null;
				try{
					boolean partOfCluster=false;
					partitionId=clusterDetailModel.getClusterPartitionsRelationships().get(0).getPartitionId();
					partitionRepository.updatePartOfCluster(partOfCluster,partitionId);
					pdmObj=partitionRepository.findOne(partitionId);
					String lastOperationStatus="Completed";
					String status="Completed";	
					String errorMessage="";
					partitionRepository.updatePartitionStatus(status,lastOperationStatus,lastOperationPerformed,errorMessage,partitionId);
					//partitionRepository.updatePartitionDetails(status,lastOperationStatus,lastOperationPerformed,errorMessage,partitionId,partOfCluster);
					clusterPartitionsRelationshipRepository.deletePartitionFromCluster(partitionId);
					clusterRepository.delete(clusterDetailModel);
					clusterDetailModel.setMessage(clusterDetailModel.getClusterName()+ " deleted successfully.");
					clusterDetailModel.setCode("200");
					recentActivityService.createRecentActivity(loggedInUser, "Partition "+pdmObj.getPartitionName()+" deleted successfully on cluster "+clusterDetailModel.getClusterName()+" by" +loggedInUser+".",CaviumConstant.PARTITION_MANAGEMENT);
				}catch (Exception e) {
					boolean partOfCluster=true;
					partitionId=clusterDetailModel.getClusterPartitionsRelationships().get(0).getPartitionId();
					partitionRepository.updatePartOfCluster(partOfCluster,partitionId);
					String lastOperationStatus="failed";
					String status="failed";	
					clusterDetailModel.setCode("408");
					String errorMessage=e.getMessage();
					partitionRepository.updatePartitionStatus(status,lastOperationStatus,lastOperationPerformed,errorMessage,partitionId);	
				//	partitionRepository.updatePartitionDetails(status,lastOperationStatus,lastOperationPerformed,errorMessage,partitionId,partOfCluster);
					logger.error("error coming while deleting single partition from Cluster ::"+e.getMessage());
					clusterDetailModel.setErrorMessage("error coming while deleting cluster"+ clusterDetailModel.getClusterName());
					alertsService.createAlert(loggedInUser,"Partition "+pdmObj.getPartitionName()+" deletion on cluster "+clusterDetailModel.getClusterName() +" by "+clusterDetailModel.getCreatedBy()+"  not complete due to "+e.getMessage()+"",clusterDetailModel.getClusterName(),pdmObj.getPartitionId(),CaviumConstant.PARTITION_MANAGEMENT);
				}

			}
			else{
				Integer clusterVersionNumber=clusterRepository.getmaxCluterVersionNumber(clusterId);
				int	maximumclusterVersion=clusterVersionNumber+1;
				Long clusterVersion=Long.parseLong(String.valueOf(maximumclusterVersion));
				clusterRepository.updateClusterVersionNumber(clusterVersion,clusterId);
				StringBuilder errorMessages= new StringBuilder();
				StringBuilder successMessage=  new StringBuilder();
				int	requestCount=clusterDetailModel.getClusterPartitionsRelationships().size();
				for(ClusterPartitionsRelationship clusterPartitionsRelationship : clusterDetailModel.getClusterPartitionsRelationships())
				{
					Long partitionId=clusterPartitionsRelationship.getPartitionId();
					PartitionDetailModel partitionDetailModel=partitionRepository.findOne(partitionId);
					clusterPartitionsRelationship.setPartitionDetailModel(partitionDetailModel);
					JSONObject json = new JSONObject(); 
					ApplianceDetailModel dbAppliance=applianceRepository.findOne(clusterPartitionsRelationship.getApplianceId()); 
					if(dbAppliance!=null) {  
						long applianceId=dbAppliance.getApplianceId();
						InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(applianceId);
						List<DualFactorUsersRelationshipModel> dfmodelList=dfUsersRelationshipRepository.getDualFactorDetails(loggedInUser, applianceId);		
						DualFactorUsersRelationshipModel dfmodel=null;
						if(dfmodelList!=null && dfmodelList.size()>0){
							dfmodel=dfmodelList.get(0);
						}
						if(initmodel!=null) {
							InitializeApplianceDetailModel initAppDetailModel = initializeRepository.findOne(initmodel.getInitializeId());
							DualFactorAuthDetailModel dualAuthModel=initAppDetailModel.getDualFactorAuthDetailModel();
							if(!StringUtils.isEmpty(clusterPartitionsRelationship.getOperationPerformedUserName()) && !StringUtils.isEmpty(clusterPartitionsRelationship.getOperationPerformedPassword())) {
								if(initAppDetailModel.getAuthenticationLevel()==0) {
									json.put("username", clusterPartitionsRelationship.getOperationPerformedUserName());
									json.put("password", clusterPartitionsRelationship.getOperationPerformedPassword());
								}
								if(initAppDetailModel.getAuthenticationLevel() == 1 && dfmodel==null){
									dfmodel=createDualFile(loggedInUser, applianceId,initAppDetailModel.getCryptoOfficerName(),CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()),dualAuthModel);
								}

								if(initAppDetailModel.getAuthenticationLevel()==1 && dfmodel!=null) {
									json.put("username", clusterPartitionsRelationship.getOperationPerformedUserName());
									json.put("password", clusterPartitionsRelationship.getOperationPerformedPassword());
									json.put("dualFactorKeyFile", dfmodel.getDualFactorKeyFileId());
									json.put("dualFactorPort", Integer.parseInt(dfmodel.getDualFactorAuthServerPortNo()));
									json.put("dualFactorCertificate", dfmodel.getDualFactorCertificateId());
								}
							}else {
								if(initAppDetailModel.getAuthenticationLevel()==0) {
									json.put("username", initAppDetailModel.getCryptoOfficerName());
									json.put("password", CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));
									if(initAppDetailModel.getAuthenticationLevel() == 1 && dfmodel==null){
										dfmodel=createDualFile(loggedInUser, applianceId,initAppDetailModel.getCryptoOfficerName(),CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()),dualAuthModel);
									}
								}if(initAppDetailModel.getAuthenticationLevel()==1 && dfmodel!=null) {
									json.put("username", initAppDetailModel.getCryptoOfficerName());
									json.put("password", CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));
									json.put("dualFactorKeyFile", dfmodel.getDualFactorKeyFileId());
									json.put("dualFactorPort", Integer.parseInt(dfmodel.getDualFactorAuthServerPortNo()));
									json.put("dualFactorCertificate", dfmodel.getDualFactorCertificateId());
								}
							}
						}
						else {
							if(dfmodel!=null){
								json.put("dualFactorKeyFile", dfmodel.getDualFactorKeyFileId());
								json.put("dualFactorPort", Integer.parseInt(dfmodel.getDualFactorAuthServerPortNo()));
								json.put("dualFactorCertificate", dfmodel.getDualFactorCertificateId());
							}
							if(!StringUtils.isEmpty(clusterPartitionsRelationship.getOperationPerformedUserName()) && !StringUtils.isEmpty(clusterPartitionsRelationship.getOperationPerformedPassword())) {
								json.put("username", clusterPartitionsRelationship.getOperationPerformedUserName());
								json.put("password", clusterPartitionsRelationship.getOperationPerformedPassword());
							}else {
								clusterDetailModel.setCode("409");
								clusterDetailModel.setErrorMessage("Cluster not created due to credentails not available");
								alertsService.createAlert(loggedInUser,"Device "+clusterDetailModel.getClusterName()+"  try to perofrm created by "+loggedInUser+ " at "+CaviumUtil.formatDateTimeFromCurrenDate(new Date()) +" not create due to credentail not provided.",CaviumConstant.CLUSTER_MANAGEMENT);
								logger.error("Credentails not provided  in createCluster method of ClusterServiceImpl class");
								return clusterDetailModel;	
							}
						}
						json.put("partitionName", clusterPartitionsRelationship.getPartitionName());

						json.put("clusterVersion",maximumclusterVersion);	

						List<String> remoteEth0IPAddrList =new ArrayList<String>();
						if(clusterDetailModel.getOperationType()!=null && "removeCluster".equals(clusterDetailModel.getOperationType())){
							for(ClusterPartitionsRelationship clusterPartitionsRelation : clusterDetailModel.getClusterPartitionsRelationships()){
								if(!clusterPartitionsRelationship.getDeletedPartitionId().equals(clusterPartitionsRelation.getDeletedPartitionId())){
									if(clusterPartitionsRelation.getRemoteEth0Addr()!=null && !clusterPartitionsRelation.getRemoteEth0Addr().equalsIgnoreCase("null")){
										remoteEth0IPAddrList.add(clusterPartitionsRelation.getRemoteEth0Addr());
									}
								}
							}
						}else{
							if(clusterPartitionsRelationship.getDeletedPartitionId()!=null){
								for(ClusterPartitionsRelationship clusterPartitionsRelation : clusterDetailModel.getClusterPartitionsRelationships()){
									if(!clusterPartitionsRelationship.getDeletedPartitionId().equals(clusterPartitionsRelation.getDeletedPartitionId())){
										if(clusterPartitionsRelation.getRemoteEth0Addr()!=null && !clusterPartitionsRelation.getRemoteEth0Addr().equalsIgnoreCase("null")){
											remoteEth0IPAddrList.add(clusterPartitionsRelation.getRemoteEth0Addr());
										}
									}
								}
							}
							if(clusterPartitionsRelationship.getDeletedPartitionId()==null){
								for(ClusterPartitionsRelationship clusterPartitionsRelation : clusterDetailModel.getClusterPartitionsRelationships()){
									if(clusterPartitionsRelation.getDeletedPartitionId()!=null){

										if(clusterPartitionsRelation.getRemoteEth0Addr()!=null && !clusterPartitionsRelation.getRemoteEth0Addr().equalsIgnoreCase("null")){
											remoteEth0IPAddrList.add(clusterPartitionsRelation.getRemoteEth0Addr());
										}		
									}
								}
							}
						}
						if(remoteEth0IPAddrList.size()>0){
							json.put("remoteEth0IPAddr",remoteEth0IPAddrList);
						}
					
					if(!StringUtils.isEmpty(ipList) && ipList.contains(clusterPartitionsRelationship.getIpAddress())){
						Thread.sleep(8000); // 8 second
					}
						response=restClient.invokePOSTMethodForOperations("https://"+clusterPartitionsRelationship.getIpAddress()+"/liquidsa/remove_cluster_node",json);
						if (response != null && response.getBody() != null) {						
							ObjectMapper mapper = new ObjectMapper();
							clusterDetailModel.setCreatedBy(loggedInUser);
							JsonNode root = mapper.readTree(response.getBody());
							if (response != null && response.getBody() != null
									&& response.getBody().contains("success")) {
								String lastOperationStatus="In-Progress";
								ipList.add(clusterPartitionsRelationship.getIpAddress());
								String status="Completed";								 						 
								String errorMessage="";		
								requestCount=requestCount-1;
								if(clusterDetailModel!=null && clusterDetailModel.getClusterId()!=null){
									clusterRepository.updateRequestCount(Long.valueOf(requestCount),clusterDetailModel.getClusterId());
								 }			
								clusterRepository.updateClusterDetails(lastOperationStatus, lastOperationPerformed, errorMessage, clusterId);
								  clusterDetailModel.setCode("200");
								  if(clusterDetailModel.getErrorMessage()==null || clusterDetailModel.getErrorMessage().equalsIgnoreCase("")){
										successMessage=successMessage.append("Delete partition " + partitionDetailModel.getPartitionName() +" initiated successfully for cluster "+clusterDetailModel.getClusterName()).append("@#");
										clusterDetailModel.setMessage(String.valueOf(successMessage));
									}
									if(clusterDetailModel.getErrorMessage()!=null && !clusterDetailModel.getErrorMessage().equalsIgnoreCase("")){
										successMessage=successMessage.append(clusterDetailModel.getErrorMessage()+partitionDetailModel.getPartitionName() + " :: " +partitionDetailModel.getErrorMessage()).append("@#");
										clusterDetailModel.setMessage(String.valueOf(successMessage));
									}
							 
								partitionDetailModel.setMessage("Delete partition " + partitionDetailModel.getPartitionName() +" initiated successfully for cluster "+clusterDetailModel.getClusterName()+"");
								partitionDetailModel.setCode("200");
								partitionRepository.save(partitionDetailModel);
								partitionRepository.updatePartitionStatus(status,lastOperationStatus,lastOperationPerformed,errorMessage,partitionId);
								boolean partitionDeleted=false;
								if(clusterPartitionsRelationship.getDeletedPartitionId()!=null){
									partitionDeleted=true;
								}
								updateInProgressActivity(dbAppliance.getApplianceName(),clusterPartitionsRelationship, loggedInUser, root,clusterDetailModel.getClusterId(),partitionDeleted,false);
							} else {
								requestCount=requestCount-1;
								if(clusterDetailModel!=null && clusterDetailModel.getClusterId()!=null)
								{
									clusterRepository.updateRequestCount(Long.valueOf(requestCount),clusterDetailModel.getClusterId());
								 }
								
								partitionDetailModel= partitionService.getErrorMessage(response, partitionDetailModel, loggedInUser,"remove Cluster"); 
								clusterDetailModel.setCode(partitionDetailModel.getCode());
								if(clusterDetailModel.getMessage()==null || clusterDetailModel.getMessage().equalsIgnoreCase("")){
									errorMessages=errorMessages.append(partitionDetailModel.getPartitionName() + " :: " +partitionDetailModel.getErrorMessage()).append("@#");
									clusterDetailModel.setErrorMessage(String.valueOf(errorMessages));
								}
								if(clusterDetailModel.getMessage()!=null && !clusterDetailModel.getMessage().equalsIgnoreCase("")){
									errorMessages=errorMessages.append(clusterDetailModel.getMessage()+partitionDetailModel.getPartitionName() + " :: " +partitionDetailModel.getErrorMessage()).append("@#");
									clusterDetailModel.setErrorMessage(String.valueOf(errorMessages));
								}
								partitionRepository.save(partitionDetailModel);
								alertsService.createAlert(loggedInUser,"Partition "+partitionDetailModel.getPartitionName()+" removal on cluster "+clusterDetailModel.getClusterName() +" by "+clusterDetailModel.getCreatedBy()+" did not complete due to "+partitionDetailModel.getErrorMessage()+"",partitionDetailModel.getPartitionName(),partitionDetailModel.getPartitionId(),CaviumConstant.PARTITION_MANAGEMENT);
								logger.error("Getting error status in  response while calling Cavium Rest API in removeCluster method of ClusterServiceImpl class");
							}
						} else {
							partitionDetailModel= partitionService.getErrorMessage(response, partitionDetailModel, loggedInUser,"remove Cluster");			
							alertsService.createAlert(loggedInUser,"Partition "+partitionDetailModel.getPartitionName()+" removal on cluster "+clusterDetailModel.getClusterName() +" by "+clusterDetailModel.getCreatedBy()+" did not complete due to "+partitionDetailModel.getErrorMessage()+"",partitionDetailModel.getPartitionName(),partitionDetailModel.getPartitionId(),CaviumConstant.PARTITION_MANAGEMENT);
							logger.error("Error  in response in  removePartitionsFromCluster method of ClusterServiceImpl class");
							clusterDetailModel.setCode(partitionDetailModel.getCode());
							if(clusterDetailModel.getMessage()==null || clusterDetailModel.getMessage().equalsIgnoreCase("")){
								errorMessages=errorMessages.append(partitionDetailModel.getPartitionName() + " :: " +partitionDetailModel.getErrorMessage()).append("@#");
								clusterDetailModel.setErrorMessage(String.valueOf(errorMessages));
							}
							if(clusterDetailModel.getMessage()!=null && !clusterDetailModel.getMessage().equalsIgnoreCase("")){
								errorMessages=errorMessages.append(clusterDetailModel.getMessage()+"@#"+partitionDetailModel.getPartitionName() + " :: " +partitionDetailModel.getErrorMessage()).append("@#");
								clusterDetailModel.setErrorMessage(String.valueOf(errorMessages));
							}
							partitionRepository.save(partitionDetailModel);
						}
					} 
				}
			}
		}catch (Exception e) {
			logger.info("Some error is coming in removeCluster Method of ClusterServiceImpl class :: " +e.getMessage());
		}
		logger.info("End of removeCluster Method of ClusterServiceImpl class");
		if(clusterDetailModel!=null && clusterDetailModel.getMessage()!=null && clusterDetailModel.getMessage().contains("@#"))
		{
			if(clusterDetailModel.getOperationType()!=null && "removeCluster".equals(clusterDetailModel.getOperationType())){
				if(StringUtils.isEmpty(clusterDetailModel.getErrorMessage())){
				clusterDetailModel.setMessage("Delete Cluster initiated successfully for cluster "+clusterDetailModel.getClusterName()+"");
				}
			}
			else{
				if(StringUtils.isEmpty(clusterDetailModel.getErrorMessage())){
				clusterDetailModel.setMessage("Delete partitions initiated successfully for cluster "+clusterDetailModel.getClusterName()+"");
				}
			}
			clusterDetailModel.setCode("200");
		}
		if(clusterDetailModel!=null && clusterDetailModel.getErrorMessage()!=null && clusterDetailModel.getErrorMessage().contains("@#"))
		{
			clusterDetailModel.setCode("409");
			clusterDetailModel.setErrorMessage(clusterDetailModel.getErrorMessage().substring(0,clusterDetailModel.getErrorMessage().length()-2));
		}
		return clusterDetailModel;
	}


	public List<ClusterDetailModel>  listOfClusters(String loggedInUser){
		List<ClusterDetailModel> clusterDetailModels= new ArrayList<ClusterDetailModel>();
		try {
			UserDetailModel objUserDetailModel=userRepository.findOne(loggedInUser);
			Long groupId=objUserDetailModel.getObjUserGroupModel().getId();
			if(objUserDetailModel!=null && objUserDetailModel.getObjUserACLDetailsModel().getAclName().equals(env.getProperty("user.superadmin"))) {
				clusterDetailModels = clusterRepository.findAll();
			}else {
				clusterDetailModels = clusterRepository.getListOfClusterByGroupId(groupId);
			}

		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured due to db error inside listOfClusters Method of class ClusterServiceImpl ::" + e.getMessage());
			//responseModel.setResponseCode("500");
			//responseModel.setResponseMessage(env.getProperty("applianceList.failureDB"));
		}
		return clusterDetailModels;

	}



	public ClusterDetailModel getPartitionsConnectivityDetails(ClusterDetailModel clusterDetailModel){

		ResponseEntity<String> response=null;
		clusterDetailModel=clusterRepository.findOne(clusterDetailModel.getClusterId());
		String loggedInUser = userAttributes.getlogInUserName();
		StringBuilder errorMessages= new StringBuilder();
		for(ClusterPartitionsRelationship clusterPartitionsRelationship : clusterDetailModel.getClusterPartitionsRelationships())
		{
			try{
				if(clusterPartitionsRelationship !=null && clusterPartitionsRelationship.getPartitionDetailModel()!=null && clusterPartitionsRelationship.getPartitionDetailModel().getApplianceDetailModel()!=null){
					Long partId=clusterPartitionsRelationship.getPartitionDetailModel().getPartitionId();
					response=restClient.invokeGETMethod("https://"+clusterPartitionsRelationship.getPartitionDetailModel().getApplianceDetailModel().getIpAddress()+"/liquidsa/cav_server_stats/"+clusterPartitionsRelationship.getPartitionDetailModel().getPartitionName()+"");
					if(response!=null && response.getBody()!=null && response.getBody().contains("success")) {
						ObjectMapper mapper = new ObjectMapper();
						JsonNode root = mapper.readTree(response.getBody());
						if(!root.isNull()){	
							String status = root.path("status").asText();
							if("success".equalsIgnoreCase(status)){
								JsonNode dataNode = root.path("data");
								if(!dataNode.isNull() && dataNode.size()>0){
									int	tombstoneKeys=dataNode.path("tombstoneKeys").asInt();
									clusterPartitionsRelationship.setTombstoneKeys(tombstoneKeys);
									JsonNode serverList = dataNode.path("serverList");
									List<ConnectedPartitions> connectedPartitionsList = new ArrayList<ConnectedPartitions>();
									if (serverList.isArray() && !serverList.isNull()) {
										for (final JsonNode serverNod : serverList) {
											String connectivityStatus=serverNod.path("status").asText();
											boolean keySynced=serverNod.path("keySynced").asBoolean();
											int nodeId=serverNod.path("nodeid").asInt();
											Long clusterId=clusterDetailModel.getClusterId();
											Long partitionId=clusterPartitionsRelationshipRepository.findPartitionIdAgainstNodeId(Long.parseLong(String.valueOf(nodeId)),clusterId);
											//List<Integer> partitionIds=partitionDataRepository.findPartitionIdAgainstNodeId(String.valueOf(nodeId));
											//Long partitionId=null;
											/*if(clus!=null && clus.size() > 0) {
												ClusterPartitionsRelationship relationship=clus.get(0);
											  partitionId=relationship.getPartitionId();
											}*/
											ConnectedPartitions connectedPartitions= new ConnectedPartitions();
											connectedPartitions.setKeySynced(keySynced);
											connectedPartitions.setNodeId(nodeId);
											connectedPartitions.setConnectivityStatus(connectivityStatus);
											if(partitionId!=null){
												connectedPartitions.setPartitionId(partitionId);
											}
											/*if(partitionIds!=null && partitionIds.size()>0){
											connectedPartitions.setPartitionId(new Long(partitionIds.get(0)));
											}*/
											connectedPartitionsList.add(connectedPartitions);
										}
										clusterPartitionsRelationship.setConnectedPartitions(connectedPartitionsList);
									}

								}
								clusterDetailModel.setCode("200");
							}
						}

					}else {
						logger.error("Error coming  while calling getPartitionsConnectivityDetailsr method of ClusterServiceImpl class");
						PartitionDetailModel pdmObj=clusterPartitionsRelationship.getPartitionDetailModel();
						if(pdmObj==null){
							pdmObj	=partitionRepository.findOne(partId);
						}
						pdmObj= partitionService.getErrorMessage(response, pdmObj, loggedInUser,"Partitions Connectivity in Cluster"); 
						List<ConnectedPartitions> connectedPartitionsList = new ArrayList<ConnectedPartitions>();
						String connectivityStatus="disconnected";
						boolean keySynced=false;
						int nodeId=0;
						for(ClusterPartitionsRelationship clusterPartitionsRelation : clusterDetailModel.getClusterPartitionsRelationships())
						{
							Long partitionId=clusterPartitionsRelation.getPartitionDetailModel().getPartitionId();				

							if(partitionId!=null && !partitionId.equals(partId)){
								ConnectedPartitions connectedPartitions= new ConnectedPartitions();
								connectedPartitions.setKeySynced(keySynced);
								connectedPartitions.setNodeId(nodeId);
								connectedPartitions.setConnectivityStatus(connectivityStatus);
								connectedPartitions.setPartitionId(partitionId);	
								connectedPartitionsList.add(connectedPartitions);
							}

						}
						clusterPartitionsRelationship.setConnectedPartitions(connectedPartitionsList);
						errorMessages=errorMessages.append(pdmObj.getPartitionName() +" :: " + pdmObj.getErrorMessage()).append("@#");
						clusterDetailModel.setErrorMessage(String.valueOf(errorMessages));
					}
				}
			}catch (KeyManagementException e) {
				logger.error("Error occured during restClient call for partitioninfo in comparePartitionsDetails method of ClusterServiceImpl class  :: "+e.getMessage());
			} catch (KeyStoreException e) {

				logger.error("Error occured during restClient call for partitioninfo in comparePartitionsDetails method of ClusterServiceImpl class ::  "+e.getMessage());
			} catch (NoSuchAlgorithmException e) {
				logger.error("Error occured during restClient call for partitioninfo in comparePartitionsDetails method  of ClusterServiceImpl class :: "+e.getMessage());
			}
			catch (Exception e) {
				logger.error("Error occured during restClient call for partitioninfo in comparePartitionsDetails method  of ClusterServiceImpl class :: "+e.getMessage());
			}
		}

		if(clusterDetailModel!=null && clusterDetailModel.getMessage()!=null && clusterDetailModel.getMessage().contains("@#"))
		{
			clusterDetailModel.setMessage(clusterDetailModel.getMessage().substring(0,clusterDetailModel.getMessage().length()-2));
			clusterDetailModel.setCode("200");
		}
		if(clusterDetailModel!=null && clusterDetailModel.getErrorMessage()!=null && clusterDetailModel.getErrorMessage().contains("@#"))
		{
			clusterDetailModel.setErrorMessage(clusterDetailModel.getErrorMessage().substring(0,clusterDetailModel.getErrorMessage().length()-2));
			clusterDetailModel.setCode("409");
		}
		return clusterDetailModel;
	}

	private int getMaximumChannelVersion(ClusterDetailModel clusterDetailModel){

		int maximumVersion=0;
		try {
			ResponseEntity<String> response=null;
			for(ClusterPartitionsRelationship clusterPartitionsRelationship : clusterDetailModel.getClusterPartitionsRelationships())
			{
				Long partitionId=clusterPartitionsRelationship.getPartitionId();
				if(partitionId!=null && clusterPartitionsRelationship.getApplianceId()==null && clusterPartitionsRelationship.getPartitionName()==null){
					PartitionDetailModel partitionDetailModel=partitionRepository.findOne(partitionId);
					String partitionName=partitionDetailModel.getPartitionName();
					Long applianceId=partitionDetailModel.getApplianceDetailModel().getApplianceId();
					clusterPartitionsRelationship.setApplianceId(applianceId);
					clusterPartitionsRelationship.setPartitionName(partitionName);		
				}
				response=restClient.invokeGETMethod("https://"+clusterPartitionsRelationship.getIpAddress()+"/liquidsa/cav_server_config/"+clusterPartitionsRelationship.getPartitionName()+"");
				if(response!=null && response.getStatusCode().name().equals("OK")) {
					ObjectMapper mapper = new ObjectMapper();
					if(response.getBody()!=null && !response.getBody().contains("cl_status") ){
						JsonNode root = mapper.readTree(response.getBody());
						if(!root.isNull()){						
							String status = root.path("status").asText();
							if("success".equalsIgnoreCase(status)){
								JsonNode dataNode = root.path("data");
								if(!dataNode.isNull() && dataNode.size()>0){
									if(dataNode.has("channelVersion")) {
										int channelVersion = dataNode.path("channelVersion").asInt();
										if(maximumVersion<channelVersion){
											maximumVersion=channelVersion;
										}
										if(dataNode.has("backChannelPort")) {
											int backChannelPort = dataNode.path("backChannelPort").asInt();
											clusterPartitionsRelationship.setBackChannelPort(backChannelPort);
										}
										if(dataNode.has("mainChannelPort")) {
											int mainChannelPort = dataNode.path("mainChannelPort").asInt();
											clusterPartitionsRelationship.setMainChannelPort(mainChannelPort);
										}
										if(dataNode.has("utilChannelPort")) {
											int utilChannelPort = dataNode.path("utilChannelPort").asInt();
											clusterPartitionsRelationship.setUtilChannelPort(utilChannelPort);
										}


									}								
								}
							}
							if("error".equalsIgnoreCase(status)){
								if(root.has("cl_status")) {
									//String cl_status = root.path("cl_status").asText();
									maximumVersion=-1;
									logger.error("error coming while getting partition data for Partition :: "+clusterPartitionsRelationship.getPartitionName()+ " of appliance :: "+clusterPartitionsRelationship.getIpAddress() );
									break;
								}
							}
						}
					}else{
						JsonNode  errorRoot = mapper.readTree(response.getBody());
						if(errorRoot.has("cl_status")) {
							//String cl_status = errorRoot.path("cl_status").asText();
							maximumVersion=-1;
							break;
						}
					}
				}
			}
		}
		catch (Exception e) {
			clusterDetailModel.setMessage("Error coming while creating Cluster.");
			clusterDetailModel.setCode("415");
			logger.error("error coming while getting cav Server configuration for Partitions in createCluster method of ClusterServiceImpl class :: "+e.getMessage());
			maximumVersion=-1;
		}
		return maximumVersion;
	}

	public void deletedPartitionIds(List<Long> partitionsIds){
		for( Long partitionId:partitionsIds){

			logger.info("deleted partition Id :: "+partitionId);
			int i=clusterPartitionsRelationshipRepository.deletePartitionFromCluster(partitionId);
			logger.info("number of deleted partitions :: "+i);
			if(i>0){
				logger.info(partitionId +" deleted suceesfully ");
			}
		}
	}

	public DualFactorUsersRelationshipModel  createDualFile(String loggedInUser, Long applianceId,String coUsername,String coPassword,DualFactorAuthDetailModel dualAuthModel)
	{
		DualFactorUsersRelationshipModel dualFactorUsersRelationship=null;
		try{	
			File convertedFile=null;
			String certificateId=null;
			CaviumResponseModel caviumResponseModel=getCaviumResponseModel();
			String keyfileName=dualAuthModel.getKeyfileName();
			String keyfileExtension=dualAuthModel.getKeyfileExtension();
			String keyfileContent=dualAuthModel.getKeyfileContent();
			String certificateName=dualAuthModel.getCertificateName();
			String certificateExtension=dualAuthModel.getCertificateExtension();
			String certificateContent=dualAuthModel.getCertificateContent();
			String portNumber=dualAuthModel.getDualFactorAuthServerPortNo();

			ApplianceDetailModel appliance=applianceRepository.findOne(applianceId);
			try{
				convertedFile= CaviumUtil.createFile(keyfileName,keyfileExtension,keyfileContent);
			}catch (IOException e) {
				logger.error("Error while creating Key file in createDualFile method :: "+e.getMessage());
			}
			caviumResponseModel=fileUploadService.uploadFile(convertedFile,coUsername,coPassword,"LoginHSM",appliance.getIpAddress(),null);
			String	keyFileId=caviumResponseModel.getResponseMessage();
			if(convertedFile!=null){
				Files.deleteIfExists(Paths.get(convertedFile.getAbsolutePath()));
			}	
			if(caviumResponseModel!=null && "200".equals(caviumResponseModel.getResponseCode()))
			{
				try{
					convertedFile= CaviumUtil.createFile(certificateName,certificateExtension,certificateContent);
				}catch (IOException e) {
					logger.error("Error while creating Certificate in createDualFile method :: "+e.getMessage()); 

				}
				caviumResponseModel=fileUploadService.uploadFile(convertedFile,coUsername,coPassword,"LoginHSM",appliance.getIpAddress(),null);
				certificateId=caviumResponseModel.getResponseMessage();
				if(convertedFile!=null){
					Files.deleteIfExists(Paths.get(convertedFile.getAbsolutePath()));
				}
				if(caviumResponseModel!=null && "200".equals(caviumResponseModel.getResponseCode()))
				{
					try{
						convertedFile= CaviumUtil.createFile(certificateName,certificateExtension,certificateContent);
					}catch (IOException e) {
						logger.error("Error while creating Certificate in createDualFile method :: "+e.getMessage()); 

					}
					caviumResponseModel=fileUploadService.uploadFile(convertedFile,coUsername,coPassword,"LoginHSM",appliance.getIpAddress(),null);
					certificateId=caviumResponseModel.getResponseMessage();
					if(convertedFile!=null){
						Files.deleteIfExists(Paths.get(convertedFile.getAbsolutePath()));
					}
					if(caviumResponseModel!=null && "200".equals(caviumResponseModel.getResponseCode()))
					{
						dfUsersRelationshipRepository.deleteDfDetailsForUserAgainstAppliance(loggedInUser, appliance.getApplianceId());	
						if(caviumResponseModel!=null && certificateId!=null &&  keyFileId!=null){	
							String url="https://"+appliance.getIpAddress()+"/liquidsa/login";
							JSONObject body=new JSONObject();
							body.put("username", coUsername);
							body.put("password", coPassword);
							body.put("dualFactorKeyFile",keyFileId);
							body.put("dualFactorPort",Integer.parseInt(portNumber));
							body.put("dualFactorCertificate",certificateId);;
							ResponseEntity<String> response=null;
							response=restClient.invokePOSTMethodForOperations(url, body);
							if(response != null && response.getBody() != null
									&& response.getBody().contains("success")) {						 
								dualFactorUsersRelationship= new DualFactorUsersRelationshipModel();
								dualFactorUsersRelationship.setUserId(loggedInUser);
								dualFactorUsersRelationship.setApplianceId(appliance.getApplianceId());
								dualFactorUsersRelationship.setDualFactorCertificateId(certificateId);
								dualFactorUsersRelationship.setDualFactorKeyFileId(keyFileId);
								dualFactorUsersRelationship.setDualFactorAuthServerPortNo(portNumber);
								dualFactorUsersRelationship.setApplianceIp(appliance.getIpAddress());
								dfUsersRelationshipRepository.save(dualFactorUsersRelationship);
							}else{
								appliance=applianceService.getErrorMessage(response, appliance, loggedInUser, "loginHSM");
								alertsService.createAlert(loggedInUser,"Upload DualFactor Certificate performed on device "+appliance.getApplianceName()+" by "+loggedInUser+" did not uploaded due to "+appliance.getErrorMessage() ,appliance.getApplianceName(),appliance.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
							}
						}
					}else{
						alertsService.createAlert(loggedInUser,"Upload DualFactor Certificate performed on device "+appliance.getApplianceName()+" by "+loggedInUser+" did not uploaded due to "+caviumResponseModel.getResponseMessage() ,appliance.getApplianceName(),appliance.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);				 
					}
				}else{
					alertsService.createAlert(loggedInUser,"Upload DualFactor Key File performed on device "+appliance.getApplianceName()+" by "+loggedInUser+" did not uploaded due to "+caviumResponseModel.getResponseMessage() ,appliance.getApplianceName(),appliance.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);				 
				}				 

			}
		}catch (Exception e) {
			logger.error("Error in createDualFile method :: "+e.getMessage()); 
		}
		return dualFactorUsersRelationship;
	}
			}


