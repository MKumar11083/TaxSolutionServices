package com.cavium.service.cluster;

import java.util.List;

import com.cavium.model.cluster.ClusterDetailModel;
import com.cavium.model.cluster.ClusterPartitionsRelationship;
import com.cavium.model.partition.PartitionDetailModel;

public interface ClusterService {
	

	/*CaviumResponseModel createCluster(List<ClusterDetailModel> Clusterinfo);

	CaviumResponseModel modifyCluster(String loggedInUser, ClusterDetailModel clusterinfo);
	
	ClusterDetailModel deleteCluster(ClusterDetailModel clusterinfo);

	List<ClusterDetailModel> getListOfClusters();

	
	ClusterDetailModel getClusterById(String ClusterID);
	
	List<ClusterDetailModel> listOfClusterByGroupId(String loggedInUser);*/
	
	
	public  ClusterPartitionsRelationship comparePartitionsDetails(ClusterPartitionsRelationship clusterPartitionsRelationship);
	
	public ClusterDetailModel createCluster(ClusterDetailModel clusterPartitionsModel);
	
	public ClusterDetailModel removePartitionsFromCluster(ClusterDetailModel clusterPartitionsModel);
	
	public  List<ClusterDetailModel> listOfClusters(String loggedInUser);
	
 
	
	public ClusterDetailModel  getPartitionsConnectivityDetails(ClusterDetailModel clusterDetailModel);
	
	public void deletedPartitionIds(List<Long> partitionsIds);
		
}
