package com.cavium.service.hostadminvm;



import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.appliance.DualFactorAuthDetailModel;
import com.cavium.model.appliance.DualFactorUsersRelationshipModel;
import com.cavium.model.appliance.InitializeApplianceDetailModel;
import com.cavium.model.appliance.InitializeAppliancesRelationshipModel;
import com.cavium.model.hostadminvm.monitorstats.Cpu;
import com.cavium.model.hostadminvm.monitorstats.Cpus;
import com.cavium.model.hostadminvm.monitorstats.Details;
import com.cavium.model.hostadminvm.monitorstats.Eth0;
import com.cavium.model.hostadminvm.monitorstats.Eth1;
import com.cavium.model.hostadminvm.monitorstats.Info;
import com.cavium.model.hostadminvm.monitorstats.Lo;
import com.cavium.model.hostadminvm.monitorstats.Memory;
import com.cavium.model.hostadminvm.monitorstats.MonitorStats;
import com.cavium.model.hostadminvm.monitorstats.Network;
import com.cavium.model.hostadminvm.monitorstats.Pcpu;
import com.cavium.model.hostadminvm.monitorstats.Sit;
import com.cavium.model.hostadminvm.monitorstats.Usage;
import com.cavium.model.hostadminvm.monitorstats.UsageInfo;
import com.cavium.pojo.ApplianceCityDetail;
import com.cavium.pojo.ApplianceInfo;
import com.cavium.pojo.HSMInfo;
import com.cavium.pojo.UserAttributes;
import com.cavium.pojo.hostadminvm.AdminSNMPConfig;
import com.cavium.pojo.hostadminvm.AdminSNMPData;
import com.cavium.pojo.hostadminvm.AdminVMConfig;
import com.cavium.pojo.hostadminvm.AdminVMData;
import com.cavium.pojo.hostadminvm.Advanced;
import com.cavium.pojo.hostadminvm.AuthMode;
import com.cavium.pojo.hostadminvm.Data;
import com.cavium.pojo.hostadminvm.DiskSpace;
import com.cavium.pojo.hostadminvm.DrvReqIdQueue;
import com.cavium.pojo.hostadminvm.FwReqIdQueue;
import com.cavium.pojo.hostadminvm.General;
import com.cavium.pojo.hostadminvm.HostStats;
import com.cavium.pojo.hostadminvm.PrivMode;
import com.cavium.pojo.hostadminvm.RamStats;
import com.cavium.pojo.hostadminvm.RxQueue;
import com.cavium.pojo.hostadminvm.StaticIpToHostConfig;
import com.cavium.pojo.hostadminvm.SwapStats;
import com.cavium.pojo.hostadminvm.SystemUpTime;
import com.cavium.pojo.hostadminvm.TxQueue;
import com.cavium.pojo.hostadminvm.Vmstats;
import com.cavium.repository.alerts.AlertsRepository;
import com.cavium.repository.appliance.ApplianceRepository;
import com.cavium.repository.appliance.DesignationAppliance;
import com.cavium.repository.appliance.DualFactorUsersRelationshipRepository;
import com.cavium.repository.appliance.InitializeAppliancesRelationshipReposiotry;
import com.cavium.repository.appliance.InitializeRepository;
import com.cavium.repository.cluster.ClusterPartitionsRelationshipRepository;
import com.cavium.repository.hostadmin.monitorstats.MonitorStatsRepository;
import com.cavium.repository.recentactivity.InProgressActivityRepository;
import com.cavium.repository.user.UserGroupRepository;
import com.cavium.service.alerts.AlertsService;
import com.cavium.service.fileupload.FileUploadService;
import com.cavium.service.recentactivity.RecentActivityServiceImpl;
import com.cavium.utill.CaviumConstant;
import com.cavium.utill.CaviumResponseModel;
import com.cavium.utill.CaviumUtil;
import com.cavium.utill.RestClient;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
/**
 *  * @author RK00490847
 *  Class is used as a service implementation for HostAdminVM Screen
 */
@Component
public class HostAdminVMServiceImpl implements HostAdminVMService {
	private Logger logger = Logger.getLogger(this.getClass());

	/**
	 * ApplicationRepository - Repository class for perform Database operation on ApplicationDetailModel
	 */
	@Autowired
	private ApplianceRepository applianceRepository;


	@Autowired
	private InitializeRepository initializeRepository;

	@Autowired
	private InitializeAppliancesRelationshipReposiotry initializeAppliancesRelationshipReposiotry;
	
	
	@Autowired
	private MonitorStatsRepository monitorStatsRepository;
	
	@Autowired
	private InProgressActivityRepository inProgressActivityRepository;
 
	@Autowired
	private ClusterPartitionsRelationshipRepository clusterPartitionsRelationshipRepository;
 
	@Autowired
	private DualFactorUsersRelationshipRepository dfUsersRelationshipRepository;
	
	@Autowired
	private FileUploadService fileUploadService;
	
	@Autowired
	private UserAttributes userAttributes;
	@Autowired
	private AlertsRepository alertsRepository;
	
	@Autowired
	private RecentActivityServiceImpl recentActivityService;

	@Autowired
	private AlertsService alertsService;

	/**
	 * This class is used to set the response attributes for incoming requests
	 */
	@Lookup
	public CaviumResponseModel getCaviumResponseModel() {
		return null;
	}

	/**
	 * This Interface is used to get the values from the property file
	 */
	@Autowired
	Environment env;

	@Autowired
	RestClient restClient;

	@Autowired
	DesignationAppliance designationAppliance;

	@Autowired
	UserGroupRepository userGroupRepository;


	/*
	 * This method is used to get AdminHost Details from Cavium REST API
	 * 
	 */
	public HostStats GetHostAdminVMStats(ApplianceDetailModel applianceDetailModel,HostStats hostStats,String apiName){
		try{
			ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/"+apiName);
			if(response!=null && response.getStatusCode().name().equals("OK")) {
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						String status = root.path("status").asText();
					//	JsonNode errors = root.path("errors");
						String operation = root.path("operation").asText();
						String partitionName = root.path("partitionName").asText();
						long startTime = root.path("startTime").asLong();
						long endTime = root.path("endTime").asLong();
						String startDateTime=CaviumUtil.formatDatefromLong(startTime);
						String endDateTime=CaviumUtil.formatDatefromLong(endTime);
						String message = root.path("message").asText();
						String jobId = root.path("jobId").asText();
						JsonNode dataNode = root.path("data");
						hostStats.setStatus(status);
						hostStats.setEndTime(endDateTime);
						hostStats.setStartTime(startDateTime);
						hostStats.setOperation(operation);
						hostStats.setPartitionName(partitionName);
						hostStats.setMessage(message);
						hostStats.setJobId(jobId);						 
					/*	if(!errors.isNull()){
							Iterator<JsonNode> itr = errors.elements();					         
							while (itr.hasNext()) {
								JsonNode temp = itr.next();
							}
						}*/
						if(!dataNode.isNull()){
							if(dataNode.has("vmstats")){
								Data data = new Data();
								hostStats.setDataObject(data);
								JsonNode vmstatsNode = dataNode.path("vmstats");
								if(!vmstatsNode.isNull()){
									Vmstats vmstats= new Vmstats();
									data.setVmstatsObject(vmstats);
									if(vmstatsNode.has("cavServerStatus")){										
										double cavServerStatus=vmstatsNode.path("cavServerStatus").asDouble();
										vmstats.setCavServerStatus(cavServerStatus);
									}
									if(vmstatsNode.has("systemUpTime")){										
										JsonNode systemUpTimeNode = vmstatsNode.path("systemUpTime");
										if(!systemUpTimeNode.isNull()){
											long totalSeconds=0;
											SystemUpTime systemUpTime= new SystemUpTime();
											vmstats.setSystemUpTimeObject(systemUpTime);
											if(systemUpTimeNode.has("hours")){
												long hours=systemUpTimeNode.path("hours").asLong();
												systemUpTime.setHours(hours);
												totalSeconds=totalSeconds+CaviumUtil.hoursToSeconds(hours);
											}
											if(systemUpTimeNode.has("minutes")){
												long minutes=systemUpTimeNode.path("minutes").asLong();
												systemUpTime.setMinutes(minutes);
												totalSeconds=totalSeconds+CaviumUtil.minutesToSeconds(minutes);
											}
											if(systemUpTimeNode.has("seconds")){
												long seconds=systemUpTimeNode.path("seconds").asLong();
												systemUpTime.setSeconds(seconds);
												totalSeconds=totalSeconds+seconds;
											}
											systemUpTime.setFormatedDate(CaviumUtil.timeInDaysHoursFormat(totalSeconds));
										}
									}
									if(vmstatsNode.has("rxQueue")){
										JsonNode rxQueueNode = vmstatsNode.path("rxQueue");
										if(!rxQueueNode.isNull()){
											RxQueue rxQueue= new RxQueue();
											vmstats.setRxQueueObject(rxQueue);
											if(rxQueueNode.has("rdt")){
												double rdt=rxQueueNode.path("rdt").asDouble();
												rxQueue.setRdt(rdt);
											}
											if(rxQueueNode.has("rdh")){
												double rdh=rxQueueNode.path("rdh").asDouble();
												rxQueue.setRdh(rdh);
											}						 
										}
									}
									if(vmstatsNode.has("drvReqIdQueue")){
										JsonNode drvReqIdQueueNode = vmstatsNode.path("drvReqIdQueue");
										if(!drvReqIdQueueNode.isNull()){
											DrvReqIdQueue drvReqIdQueue = new DrvReqIdQueue();
											vmstats.setDrvReqIdQueueObject(drvReqIdQueue);
											if(drvReqIdQueueNode.has("head")){
												double head=drvReqIdQueueNode.path("head").asDouble();
												drvReqIdQueue.setHead(head);
											}
											if(drvReqIdQueueNode.has("tail")){
												double tail=drvReqIdQueueNode.path("tail").asDouble();
												drvReqIdQueue.setTail(tail);
											}						 
										}
									}
									if(vmstatsNode.has("ramStats(mb)")){
										JsonNode ramStatsNode = vmstatsNode.path("ramStats(mb)");
										if(!ramStatsNode.isNull()){
											RamStats ramStats= new RamStats();
											vmstats.setRamStats(ramStats);
											if(ramStatsNode.has("total")){
												double total=ramStatsNode.path("total").asDouble();
												ramStats.setTotal(total);
											}
											if(ramStatsNode.has("free")){
												double free=ramStatsNode.path("free").asDouble();
												ramStats.setFree(free);
											}	
											ramStats.setUsed(ramStats.getTotal()-ramStats.getFree());
											ramStats.setUsedPercentage(CaviumUtil.calculatePercetage(ramStats.getTotal(),ramStats.getUsed()));
										}
									}
									if(vmstatsNode.has("diskSpace(mb)")){
										JsonNode diskSpaceNode = vmstatsNode.path("diskSpace(mb)");
										if(!diskSpaceNode.isNull()){
											DiskSpace diskSpace= new DiskSpace();
											vmstats.setDiskSpace(diskSpace);
										 
											if(diskSpaceNode.has("total")){
												double total=diskSpaceNode.path("total").asDouble();
												diskSpace.setTotal(total);
											}
											if(diskSpaceNode.has("free")){
												double free=diskSpaceNode.path("free").asDouble();
												diskSpace.setFree(free);
											}	
											diskSpace.setUsed(diskSpace.getTotal()-diskSpace.getFree());
											diskSpace.setUsedPercentage(CaviumUtil.calculatePercetage(diskSpace.getTotal(),diskSpace.getUsed()));
										}
									}
									
									if(vmstatsNode.has("txQueue")){
										JsonNode txQueueNode = vmstatsNode.path("txQueue");
										if(!txQueueNode.isNull()){
											TxQueue txQueue= new TxQueue();
											vmstats.setTxQueueObject(txQueue);
											if(txQueueNode.has("tdh")){
												double tdh=txQueueNode.path("tdh").asDouble();
												txQueue.setTdh(tdh);
											}
											if(txQueueNode.has("tdt")){
												double tdt=txQueueNode.path("tdt").asDouble();
												txQueue.setTdt(tdt);
											}						 
										}
									}
									if(vmstatsNode.has("fwReqIdQueue")){
										JsonNode fwReqIdQueueNode = vmstatsNode.path("fwReqIdQueue");
										if(!fwReqIdQueueNode.isNull()){
											FwReqIdQueue fwReqIdQueue= new FwReqIdQueue();
											vmstats.setFwReqIdQueueObject(fwReqIdQueue);
											if(fwReqIdQueueNode.has("head")){
												double head=fwReqIdQueueNode.path("head").asDouble();
												fwReqIdQueue.setHead(head);
											}
											if(fwReqIdQueueNode.has("tail")){
												double tail=fwReqIdQueueNode.path("tail").asDouble();
												fwReqIdQueue.setTail(tail);
											}						 
										}
									}
									if(vmstatsNode.has("swapStats(mb)")){
										JsonNode swapStatsNode = vmstatsNode.path("swapStats(mb)");
										if(!swapStatsNode.isNull()){
											SwapStats swapStats= new SwapStats();
											vmstats.setSwapStats(swapStats);
											if(swapStatsNode.has("total")){
												double total=swapStatsNode.path("total").asDouble();
												swapStats.setTotal(total);
											}
											if(swapStatsNode.has("free")){
												double free=swapStatsNode.path("free").asDouble();
												swapStats.setFree(free);
											}
											swapStats.setUsedPercentage(CaviumUtil.calculatePercetage(swapStats.getTotal(),swapStats.getUsed()));
										}
									}							
									if(vmstatsNode.has("linkStatus(eth0)")){
										double linkStatusEth0=vmstatsNode.path("linkStatus(eth0)").asDouble();
										vmstats.setLinkStatusEth0(linkStatusEth0);
									}
									if(vmstatsNode.has("cpuUsage(%)")){
										double cpuUsage=vmstatsNode.path("cpuUsage(%)").asDouble();	
										vmstats.setCpuUsage(cpuUsage);
									}
									if(vmstatsNode.has("linkStatus(eth1)")){
										double linkStatusEth01=vmstatsNode.path("linkStatus(eth1)").asDouble();
										vmstats.setLinkStatusEth1(linkStatusEth01);
									}
									if(vmstatsNode.has("processCount")){
										double processCount=vmstatsNode.path("processCount").asDouble();
										vmstats.setProcessCount(processCount);
									}
									if(vmstatsNode.has("freeSpace(mb)")){
										double freeSpace=vmstatsNode.path("freeSpace(mb)").asDouble();
										vmstats.setFreeSpace(freeSpace);									 
									}
									if(vmstatsNode.has("driverStatus")){
										double driverStatus=vmstatsNode.path("driverStatus").asDouble();
										vmstats.setDriverStatus(driverStatus);		
										if(driverStatus==0){
											vmstats.setDriverStatusStr("down");
										}
										if(driverStatus==1){
											vmstats.setDriverStatusStr("Up");
										}
									}		
								}

							}
						}
					}
				}
			}
		}catch(Exception exp){
			logger.error("Error occured during fetch AdminHostStats Info of class ApplianceServiceImpl ::" + exp.getMessage());
		}
		return hostStats;
	}
	/*
	 * This method is used to get Appliance Information from Cavium REST API 
	 *
	 */
	public ApplianceInfo GetApplianceInfo(ApplianceDetailModel applianceDetailModel ,ApplianceInfo applianceInfo){
		try{
			ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/appliance_info");
			if(response!=null && response.getStatusCode().name().equals("OK")) {
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						String status = root.path("status").asText();
					//	JsonNode errors = root.path("errors");
						String operation = root.path("operation").asText();
						long startTime = root.path("startTime").asLong();
						long endTime = root.path("endTime").asLong();
						String startDateTime=CaviumUtil.formatDatefromLong(startTime);
						String endDateTime=CaviumUtil.formatDatefromLong(endTime);
						String message = root.path("message").asText();
						applianceInfo.setStatus(status);
						applianceInfo.setOperation(operation);
						applianceInfo.setStartTime(startDateTime);
						applianceInfo.setEndTime(endDateTime);
						applianceInfo.setErrorMessage(message);
					/*	if(!errors.isNull()){
							Iterator<JsonNode> itr = errors.elements();					         
							while (itr.hasNext()) {
								JsonNode temp = itr.next();    
							}
						}*/						
						JsonNode dataNode = root.path("data");
						if(!dataNode.isNull()){
							if(dataNode.has("linuxVersion")) {
								String linuxVersion = dataNode.path("linuxVersion").asText();
								applianceInfo.setLinuxVersion(linuxVersion);
							}
							if(dataNode.has("serialNum")) {
								String serialNum = dataNode.path("serialNum").asText();
								applianceInfo.setSerialNum(serialNum);
							}
							if(dataNode.has("firmwareVersion")) {
								String firmwareVersion = dataNode.path("firmwareVersion").asText();
								applianceInfo.setFirmwareVersion(firmwareVersion);
							}
						}
					}
				}
			}		
		}catch(Exception exp){
			logger.error("Error occured during fetch Appliance Info of class ApplianceServiceImpl ::" + exp.getMessage());	
		}
		return applianceInfo;
	}

	/*
	 * This method is used to get HSM Information from Cavium REST API 
	 *  
	 */

	public HSMInfo getHSMInfo(ApplianceDetailModel applianceDetailModel,HSMInfo objHSMInfo){
		try{

			ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/info");
			if(response!=null && response.getStatusCode().name().equals("OK")) {
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						String status = root.path("status").asText();
					//	JsonNode errors = root.path("errors");
						String operation = root.path("operation").asText();
						String partitionName = root.path("partitionName").asText();
						long startTime = root.path("startTime").asLong();
						long endTime = root.path("endTime").asLong();
						String startDateTime=CaviumUtil.formatDatefromLong(startTime);
						String endDateTime=CaviumUtil.formatDatefromLong(endTime);
						String message = root.path("message").asText();
						int jobId = root.path("jobId").asInt();
						JsonNode dataNode = root.path("data");
						objHSMInfo.setStatus(status);
						objHSMInfo.setOperation(operation);
						objHSMInfo.setPartitionName(partitionName);
						objHSMInfo.setStartTime(startDateTime);
						objHSMInfo.setEndTime(endDateTime);
						objHSMInfo.setErrorMessage(message);
						objHSMInfo.setJobId(jobId);
				/*		if(!errors.isNull()){
							Iterator<JsonNode> itr = errors.elements();                                       
							while (itr.hasNext()) {
								JsonNode temp = itr.next();                                              
							}
						}*/
						if(!dataNode.isNull()){
							if(dataNode.has("totalPublicMemory(KB)")) {
								int totalPublicMemory = dataNode.path("totalPublicMemory(KB)").asInt();
								objHSMInfo.setTotalPublicMemory(totalPublicMemory);
							}
							if(dataNode.has("mwVersion")) {
								String mwVersion = dataNode.path("mwVersion").asText();
								objHSMInfo.setMwVersion(mwVersion);
							}
							if(dataNode.has("hardwareMinor")) {
								String hardwareMinor = dataNode.path("hardwareMinor").asText();
								objHSMInfo.setHardwareMinor(hardwareMinor);
							}
							if(dataNode.has("systemVendorId")) {
								String systemVendorId = dataNode.path("systemVendorId").asText();
								objHSMInfo.setSystemVendorId(systemVendorId);
							}
							if(dataNode.has("cuLoginFailure")) {
								int cuLoginFailure = dataNode.path("cuLoginFailure").asInt();
								objHSMInfo.setCuLoginFailure(cuLoginFailure);
							}
							if(dataNode.has("rwSessionCount")) {
								int rwSessionCount = dataNode.path("rwSessionCount").asInt();
								objHSMInfo.setRwSessionCount(rwSessionCount);
							}
							if(dataNode.has("coLoginFailure")) {
								int coLoginFailure = dataNode.path("coLoginFailure").asInt();
								objHSMInfo.setCoLoginFailure(coLoginFailure);
							}
							if(dataNode.has("freePrivateMemory(KB)")) {
								int freePrivateMemory = dataNode.path("freePrivateMemory(KB)").asInt();
								objHSMInfo.setFreePrivateMemory(freePrivateMemory);
							}
							if(dataNode.has("slaveConfig")) {
								String slaveConfig = dataNode.path("slaveConfig").asText();
								objHSMInfo.setSlaveConfig(slaveConfig);
							}
							if(dataNode.has("temperature")) {
								String temperature = dataNode.path("temperature").asText();
								objHSMInfo.setTemperature(temperature);
							}
							if(dataNode.has("firmwareMajor")) {
								String firmwareMajor = dataNode.path("firmwareMajor").asText();
								objHSMInfo.setFirmwareMajor(firmwareMajor);;
							}
							if(dataNode.has("label")) {
								String label = dataNode.path("label").asText();
								objHSMInfo.setLabel(label);
							}
							if(dataNode.has("subSystemId")) {
								String subSystemId = dataNode.path("subSystemId").asText();
								objHSMInfo.setSubSystemId(subSystemId);
							}
							if(dataNode.has("manufacturerId")) {
								String manufacturerId = dataNode.path("manufacturerId").asText();
								objHSMInfo.setManufacturerId(manufacturerId);
							}
							if(dataNode.has("masterConfig")) {
								String masterConfig = dataNode.path("masterConfig").asText();
								objHSMInfo.setMasterConfig(masterConfig);
							}
							if(dataNode.has("authenticationPath")) {
								int authenticationPath = dataNode.path("authenticationPath").asInt();
								objHSMInfo.setAuthenticationPath(authenticationPath);

							}
							if(dataNode.has("classCode")) {
								int classCode = dataNode.path("classCode").asInt();
								objHSMInfo.setClassCode(classCode);
							}
							if(dataNode.has("maxSessionCount")) {
								int maxSessionCount = dataNode.path("maxSessionCount").asInt();
								objHSMInfo.setMaxSessionCount(maxSessionCount);
							}
							if(dataNode.has("manufacturerId")) {
								String manufacturerId = dataNode.path("manufacturerId").asText();
								objHSMInfo.setManufacturerId(manufacturerId);
							}
							if(dataNode.has("sessionCount")) {
								int sessionCount = dataNode.path("sessionCount").asInt();
								objHSMInfo.setSessionCount(sessionCount);
							}
							if(dataNode.has("firmwareId")) {
								String firmwareId = dataNode.path("firmwareId").asText();
								objHSMInfo.setFirmwareId(firmwareId);
							}
							if(dataNode.has("maxRwSessionCount")) {
								int maxRwSessionCount = dataNode.path("maxRwSessionCount").asInt();
								objHSMInfo.setMaxRwSessionCount(maxRwSessionCount);
							}
							if(dataNode.has("buildNumber")) {
								String buildNumber = dataNode.path("buildNumber").asText();
								objHSMInfo.setBuildNumber(buildNumber);
							}
							if(dataNode.has("hardwareMajor")) {
								String hardwareMajor = dataNode.path("hardwareMajor").asText();
								objHSMInfo.setHardwareMajor(hardwareMajor);
							}
							if(dataNode.has("minPswdLen")) {
								int minPswdLen = dataNode.path("minPswdLen").asInt();
								objHSMInfo.setMinPswdLen(minPswdLen);
							}
							if(dataNode.has("maxPswdLen")) {
								int maxPswdLen = dataNode.path("maxPswdLen").asInt();
								objHSMInfo.setMaxPswdLen(maxPswdLen);
							}
							if(dataNode.has("totalPrivateMemory(KB)")) {
								int totalPrivateMemory = dataNode.path("totalPrivateMemory(KB)").asInt();
								objHSMInfo.setTotalPrivateMemory(totalPrivateMemory);
							}
							if(dataNode.has("firmwareMinor")) {
								String firmwareMinor = dataNode.path("firmwareMinor").asText();
								objHSMInfo.setFirmwareMinor(firmwareMinor);
							}
							if(dataNode.has("partNumber")) {
								String partNumber = dataNode.path("partNumber").asText();
								objHSMInfo.setPartNumber(partNumber);
							}
							if(dataNode.has("freePublicMemory(KB)")) {
								int freePublicMemory = dataNode.path("freePublicMemory(KB)").asInt();
								objHSMInfo.setFreePublicMemory(freePublicMemory);
							}
							if(dataNode.has("serialNumber")){
								String serialNumber = dataNode.path("serialNumber").asText();
								objHSMInfo.setSerialNumber(serialNumber);
							}
							if(dataNode.has("fipsState")) {
								String fipsState = dataNode.path("fipsState").asText();
								objHSMInfo.setFipsState(fipsState);                                      
							}
							if(dataNode.has("hsmFlags")) {
								int hsmFlags = dataNode.path("hsmFlags").asInt();
								objHSMInfo.setHsmFlags(hsmFlags);
							}
							if(dataNode.has("model")) {
								String model = dataNode.path("model").asText();
								objHSMInfo.setModel(model);
							}
							if(dataNode.has("deviceId")) {
								String deviceId = dataNode.path("deviceId").asText();
								objHSMInfo.setDeviceId(deviceId);
							}
							if(dataNode.has("mcoFixedKeyFingerprint")) {
								String mcoFixedKeyFingerprint = dataNode.path("mcoFixedKeyFingerprint").asText();
								objHSMInfo.setMcoFixedKeyFingerprint(mcoFixedKeyFingerprint);;
							}
							if(dataNode.has("vendorFixedKeyFingerprint")) {
								String vendorFixedKeyFingerprint = dataNode.path("vendorFixedKeyFingerprint").asText();								
								objHSMInfo.setVendorFixedKeyFingerprint(vendorFixedKeyFingerprint);
							}
							
							
						}
					}
				}
			}
		}catch(Exception exp){
			logger.error("Error occured during fetch HSM Info of class ApplianceServiceImpl ::" + exp.getMessage()); 
		}
		return objHSMInfo;
	}


	@Override
	public AdminVMConfig GetAdminVMConfig(ApplianceDetailModel applianceDetailModel , AdminVMConfig adminVMConfig){
		try{
			ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/admin_vm_net_config");
			if(response!=null && response.getStatusCode().name().equals("OK")) {
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
					    String status = root.path("status").asText();
						String operation = root.path("operation").asText();
						String partitionName = root.path("partitionName").asText();
						long startTime = root.path("startTime").asLong();
						long endTime = root.path("endTime").asLong();
						String startDateTime=CaviumUtil.formatDatefromLong(startTime);
						String endDateTime=CaviumUtil.formatDatefromLong(endTime);
						String message = root.path("message").asText();
						String jobId = root.path("jobId").asText();
						adminVMConfig.setStatus(status);
						adminVMConfig.setOperation(operation);
						adminVMConfig.setPartitionName(partitionName);
						adminVMConfig.setStartTime(startDateTime);
						adminVMConfig.setEndTime(endDateTime);
						adminVMConfig.setMessage(message);
						adminVMConfig.setJobId(jobId);
						List<String> listSearchDomainName= new ArrayList<String>();
						List<String> listdnsServers= new ArrayList<String>();
						List<StaticIpToHostConfig> liststaticIpToHostConfig= new ArrayList<StaticIpToHostConfig>();
						JsonNode dataNode = root.path("data");
						if(!dataNode.isNull()){
							if(dataNode.has("general")){
								AdminVMData adminVMData = new AdminVMData();
								adminVMConfig.setAdminVMData(adminVMData);
								JsonNode generalNode = dataNode.path("general");
								if(!generalNode.isNull()){
									General general= new General();
									general.setSubnet(generalNode.path("subnet").asText());
									general.setIp(generalNode.path("ip").asText());
									general.setType(generalNode.path("type").asText());
									if("Static".equalsIgnoreCase(general.getType())){
										general.setDhcp(false);
									}
									else{
										general.setDhcp(true);
									}
									if(generalNode.has("gateway")) {
									general.setGateway(generalNode.path("gateway").asText());
									}
									if(generalNode.has("hostname")) {
									general.setHostname(generalNode.path("hostname").asText());
									}
									if(generalNode.has("macAddress")) {
									general.setMacAddress(generalNode.path("macAddress").asText());
									}
									if(generalNode.has("vlan")) {
									general.setVlan(generalNode.path("vlan").asText());
									}
									if(generalNode.has("macStatic")) {
									general.setMacStatic(generalNode.path("macStatic").asBoolean());
									}
									adminVMData.setGeneral(general);
								}

								JsonNode advancedNode = dataNode.path("advanced");
								if(!advancedNode.isNull()){
									Advanced  advanced = new Advanced();
									JsonNode searchDomainNames=	advancedNode.path("searchDomainNames");
									JsonNode staticIpToHostConfigs=	advancedNode.path("staticIpToHostConfig");
									JsonNode dnsServers=advancedNode.path("dnsServers");

									if(!searchDomainNames.isNull()){
										Iterator<JsonNode> searchDomainName = searchDomainNames.elements();					         
										while (searchDomainName.hasNext()) {
											JsonNode temp = searchDomainName.next();    
											listSearchDomainName.add(temp.asText());
											advanced.setEnableDNSService(true);
										}
										advanced.setSearchDomainNames(listSearchDomainName);
										
									}
									if(!dnsServers.isNull()){
										Iterator<JsonNode> dnsServer = dnsServers.elements();					         
										while (dnsServer.hasNext()) {
											JsonNode temp = dnsServer.next();
											listdnsServers.add(temp.asText());
											advanced.setEnableDNSService(true);
										}
										advanced.setDnsServers(listdnsServers);
										
									}
									/*	if (searchDomainNames.isArray()) {
									    for (final JsonNode searchDomainName : searchDomainNames) {
									    	listSearchDomainName.add(searchDomainName.asText());
									    }
									    	advanced.setSearchDomainNames(listSearchDomainName);
									    }*/

									if (staticIpToHostConfigs.isArray()) {
										for (final JsonNode staticIpToHostConfig : staticIpToHostConfigs) {
											StaticIpToHostConfig obj= new StaticIpToHostConfig();
											//	listSearchDomainName.add(staticIpToHostConfig.asText());
											if(staticIpToHostConfig.has("alias")) {
											obj.setAlias(staticIpToHostConfig.get("alias").asText());
											}
											if(staticIpToHostConfig.has("hostname")) {
											obj.setHostname(staticIpToHostConfig.get("hostname").asText());
											}
											if(staticIpToHostConfig.has("ip")) {
											obj.setIp(staticIpToHostConfig.get("ip").asText());
											}
											liststaticIpToHostConfig.add(obj);
										}
										advanced.setStaticIpToHostConfig(liststaticIpToHostConfig); 
									}
									adminVMData.setAdvanced(advanced);
								}
							}
						}
					}
				}
			}
		}catch (JsonProcessingException e) {
			logger.error("Error occured inside GetAdminVMConfig Method of class ApplianceServiceImpl ::" + e.getMessage());
		}
		catch (IOException e) {
			logger.error("Error occured inside GetAdminVMConfig Method of class ApplianceServiceImpl ::" + e.getMessage());
		}catch (Exception e) {
			logger.error("Error occured inside GetAdminVMConfig Method of class ApplianceServiceImpl ::" + e.getMessage());
		}
		return adminVMConfig;
	}


	@Override
	public AdminSNMPConfig GetAdminSNMPConfig(ApplianceDetailModel applianceDetailModel , AdminSNMPConfig adminSNMPConfig){
		try{
			ResponseEntity<String> response=restClient.invokeGETMethod("https://"+applianceDetailModel.getIpAddress()+"/liquidsa/admin_snmp_config");
			if(response!=null && response.getStatusCode().name().equals("OK")) {
				ObjectMapper mapper = new ObjectMapper();
				if(response.getBody()!=null){
					JsonNode root = mapper.readTree(response.getBody());
					if(!root.isNull()){
						JsonNode dataNode = root.path("data");

						if(!dataNode.isNull()){
							AdminSNMPData adminSNMPData = new AdminSNMPData();
							adminSNMPConfig.setAdminSNMPData(adminSNMPData);
							if(dataNode.path("uname").asText()!=null){
								adminSNMPData.setUname(dataNode.path("uname").asText());
							}else{
								adminSNMPData.setUname("");
							}
							adminSNMPData.setEngineId(dataNode.path("engineId").asText()!=null?dataNode.path("engineId").asText():"");
							adminSNMPData.setPort(dataNode.path("port").asInt());
							adminSNMPData.setIp(dataNode.path("ip").asText()!=null?dataNode.path("ip").asText():"");
							String trapEnabled=dataNode.path("trapEnabled").asText();
							if(!StringUtils.isEmpty(trapEnabled) && trapEnabled.equalsIgnoreCase("yes")) {
								adminSNMPData.setEnableTrap(true);
							}
							String enabled=dataNode.path("enabled").asText();
							if(!StringUtils.isEmpty(enabled) && enabled.equalsIgnoreCase("yes")) {
								adminSNMPData.setEnabled(true);
							}

							PrivMode privMode= new PrivMode();
							String priv=dataNode.path("priv").asText();
							String privPwd=dataNode.path("privPwd").asText();
							if(!StringUtils.isEmpty(priv) && priv.equalsIgnoreCase("None")) {
								privMode.setEncryption("Disable");
							}else {
								privMode.setEncryption(priv);
							}
							if(!StringUtils.isEmpty(privPwd) && privPwd.equalsIgnoreCase("none")) {
								privMode.setPassword("Disable");
							}else {
								privMode.setPassword(privPwd);
							}
							adminSNMPData.setPrivMode(privMode);

							AuthMode authMode = new AuthMode();
							String auth=dataNode.path("auth").asText();
							String authPwd=dataNode.path("authPwd").asText();
							if(!StringUtils.isEmpty(auth) && auth.equalsIgnoreCase("None")) {
								authMode.setEncryption("Disable");
							}else {
								authMode.setEncryption(auth);
							}
							if(!StringUtils.isEmpty(authPwd) && authPwd.equalsIgnoreCase("none")) {
								authMode.setPassword("Disable");
							}else {
								authMode.setPassword(authPwd);
							}
							adminSNMPData.setAuthMode(authMode);
						}
					}
				}
			}
		}catch (JsonProcessingException e) {
			logger.error("Error occured inside GetAdminVMConfig Method of class ApplianceServiceImpl ::" + e.getMessage());
		}
		catch (IOException e) {
			logger.error("Error occured inside GetAdminVMConfig Method of class ApplianceServiceImpl ::" + e.getMessage());
		}catch (Exception e) {
			logger.error("Error occured inside GetAdminVMConfig Method of class ApplianceServiceImpl ::" + e.getMessage());
		}
		return adminSNMPConfig;
	}

	@Override
	public CaviumResponseModel hostMonitorStats(ApplianceDetailModel app,String apiName) {

		// TODO Auto-generated method stub
		synchronized (app) {
		ResponseEntity<String> response = null;
		CaviumResponseModel responseMonitorStats=new CaviumResponseModel();
		try {			 
			if(app!=null) {
				ApplianceDetailModel dbAppliance=applianceRepository.findOne(app.getApplianceId()); 
				if(dbAppliance!=null) {
					response=restClient.invokeGETMethod("https://"+app.getIpAddress()+"/liquidsa/monitor_stats/"+apiName);
					 if(response!=null && response.getBody()!=null && response.getBody().contains("success")) {
						responseMonitorStats.setResponseCode("200");
						responseMonitorStats.setResponseMessage(response.getBody());
						ObjectMapper mapper = new ObjectMapper();
						Date date = new Date();   // given date
						Calendar calendar = GregorianCalendar.getInstance(); // creates a new calendar instance
						calendar.setTime(date);   // assigns calendar to given date 
						calendar.get(Calendar.HOUR_OF_DAY); // gets hour in 24h format
						calendar.get(Calendar.HOUR);        // gets hour in 12h format
						calendar.get(Calendar.MINUTE);       // gets month number, NOTE this is zero based!
						String hoursMinute=calendar.get(Calendar.HOUR_OF_DAY)+":"+calendar.get(Calendar.MINUTE);
						
						JsonNode root = mapper.readTree(response.getBody());
							if(!root.isNull()){
							MonitorStats monitorStats= new MonitorStats();
								JsonNode data = root.path("data");
								String status = root.path("status").asText();
								String operation = root.path("operation").asText();
								monitorStats.setOperation(operation);
								monitorStats.setStatus(status);
								if(!data.isNull() && data.size()>0){
									com.cavium.model.hostadminvm.monitorstats.Data dataObj= new com.cavium.model.hostadminvm.monitorstats.Data();
									monitorStats.setData(dataObj);
									JsonNode network = data.path("network");
									JsonNode pcpu = data.path("pcpu");
									JsonNode cpu = data.path("cpu");
									JsonNode memory = data.path("memory");
									
									// for Memory Object 
									 if(!memory.isNull() && memory.size()>0){
										 Memory memoryObj= new Memory();
									
										 String usageInPercentage= memory.path("usageInPercentage").asText();									
										 String updatedTime=	 memory.path("updatedTime").asText();
										 memoryObj.setUsageInPercentage(usageInPercentage);
										 memoryObj.setUpdatedTime(updatedTime);
										 JsonNode details = memory.path("details");
											if (details.isArray() && details.size()>0) {
												List<Details> detailsList= new ArrayList<Details>();
												for (final JsonNode detail : details) {
												Details detailsObj= new Details();											
												String cpudetail=detail.get("cpu").asText();
												String command=	detail.get("command").asText();
												String mem=detail.get("mem").asText();
												String pid=	detail.get("pid").asText();
												detailsObj.setCommand(command);
												detailsObj.setCpu(cpudetail);
												detailsObj.setMem(mem);
												detailsObj.setPid(pid);
												detailsObj.setMemory(memoryObj);
												detailsList.add(detailsObj);
												 }
												memoryObj.setDetails(detailsList);
											 }
										  JsonNode usages = memory.path("usage");
										  List<Usage> usageList= new ArrayList<Usage>();
											if (usages.isArray() && usages.size()>0) {
												for (final JsonNode usage : usages) {
												Usage usageObj= new Usage();												 
												int total=	usage.get("total").asInt();
												int shared=	usage.get("shared").asInt();
												int free=	usage.get("free").asInt();
												int cache=	usage.get("cache").asInt();
												int buffers=	usage.get("buffers").asInt();
												String name=usage.get("name").asText();
												int used=usage.get("used").asInt();
												usageObj.setTotal(total);
												usageObj.setShared(shared);
												usageObj.setFree(free);
												usageObj.setCache(cache);
												usageObj.setBuffers(buffers);
												usageObj.setName(name);
												usageObj.setUsed(used);
												usageObj.setMemory(memoryObj);
												usageList.add(usageObj);
												 }
												memoryObj.setUsage(usageList);
											 }
											 dataObj.setMemory(memoryObj);
									  }
									  if(!pcpu.isNull() && pcpu.size()>0){
										  Pcpu pcpuObj= new Pcpu();									
										  JsonNode infos = pcpu.path("info");
										if (infos.isArray() && infos.size()>0) {
											List<Info> infoList= new ArrayList<Info>();
										 for (final JsonNode info : infos) {
										Info infoObj= new Info();
										int nThread=info.get("nThread").asInt();
										String name=info.get("name").asText();
										String cpuPercent=info.get("cpuPercent").asText();
										int cpuDetail=info.get("cpu").asInt();
										infoObj.setnThread(nThread);
										infoObj.setName(name);
										infoObj.setCpu(cpuDetail);
										infoObj.setCpuPercent(cpuPercent);
										infoObj.setPcpu(pcpuObj);
										infoList.add(infoObj);
											 }
											pcpuObj.setInfo(infoList);
										 }
										JsonNode cpus = pcpu.path("cpus");
										if(!cpus.isNull() && cpus.size()>0){
											List<Cpus> cpusList= new ArrayList<Cpus>();
										  Iterator<JsonNode> itr = cpus.elements();                           
										  while (itr.hasNext()) {
											  Cpus cpusObj= new Cpus();
											JsonNode cpuNameNode = itr.next();
											String cpuName=cpuNameNode.asText();
											cpusObj.setCpuName(cpuName);
											cpusObj.setPcpu(pcpuObj);
											cpusList.add(cpusObj);
								  }
										  pcpuObj.setListCpus(cpusList);
										}
										  dataObj.setPcpu(pcpuObj);
									  }
									 if(!cpu.isNull() && cpu.size()>0){
										Cpu cpuObj= new Cpu();									
									String updatedTime=	cpu.path("updatedTime").asText();
									double totalUsage=cpu.path("totalUsage").asDouble();										
									String	totalUsageStr=String.valueOf(totalUsage);
									cpuObj.setTotalUsage(totalUsageStr);
									cpuObj.setUpdatedTime(updatedTime);
									JsonNode usageInfos = cpu.path("usageInfo");
										 if (usageInfos.isArray() && usageInfos.size()>0) {
											List<UsageInfo> usageInfoList = new ArrayList<UsageInfo>();
												for (final JsonNode usageInfo : usageInfos) {
												 UsageInfo usageInfoObj= new UsageInfo();
												String usage=usageInfo.get("usage").asText();
												String memUsage= usageInfo.get("memUsage").asText();
													int pid=usageInfo.get("pid").asInt();
													String pidStr=String.valueOf(pid);
												String command=	usageInfo.get("command").asText();		
												usageInfoObj.setUsage(usage);
												usageInfoObj.setMemUsage(memUsage);
												usageInfoObj.setPid(pidStr);
												usageInfoObj.setCommand(command);
												usageInfoObj.setCpu(cpuObj);
												usageInfoList.add(usageInfoObj);
												 }
												cpuObj.setUsageInfo(usageInfoList);
											 }
											dataObj.setCpu(cpuObj);
								  }
									 if(!network.isNull() && network.size()>0){
										 Network networkObj= new Network();
								
									String updatedTime=network.path("updatedTime").asText();
									networkObj.setUpdatedTime(updatedTime);
										JsonNode sit0 = network.path("sit0");								 
										JsonNode eth0 = network.path("eth0");
										JsonNode eth1 = network.path("eth1");
										JsonNode lo = network.path("lo");
										 if (sit0!=null && sit0.size()>0) {
											 	Sit sitObj= new Sit();
											 	String incoming=sit0.path("incoming").asText();
												String outgoing=	sit0.path("outgoing").asText();
												String stats=	sit0.path("stats").asText();
												String	macAddress=sit0.path("macAddress").asText();	
												sitObj.setIncoming(incoming);
												sitObj.setOutgoing(outgoing);
												sitObj.setMacAddress(macAddress);
												sitObj.setStats(stats);
												networkObj.setSit0(sitObj); 
											 }
										 if (eth0!=null && eth0.size()>0) {
											 Eth0  eth0Obj= new Eth0();
												String eth0_ipv4Address=	eth0.path("ipv4Address").asText();
												String eth0_macAddress=eth0.path("macAddress").asText();
												String eth0_outgoing=eth0.path("outgoing").asText();
												String eth0_incoming=eth0.path("incoming").asText();		
												String eth0_ipv6Address=eth0.path("ipv6Address").asText();
												String eth0_macBroadcast=eth0.path("macBroadcast").asText();
												String eth0_ipv4Broadcast=	eth0.path("ipv4Broadcast").asText();
												String eth0_ipv6Netmask	=eth0.path("ipv6Netmask").asText();	
												String eth0_ipv4Netmask=	eth0.path("ipv4Netmask").asText();	
												String eth0_stats=	eth0.path("stats").asText();
												eth0Obj.setIpv4Address(eth0_ipv4Address);
												eth0Obj.setMacAddress(eth0_macAddress);
												eth0Obj.setOutgoing(eth0_outgoing);
												eth0Obj.setIncoming(eth0_incoming);
												eth0Obj.setIpv6Address(eth0_ipv6Address);
												eth0Obj.setMacBroadcast(eth0_macBroadcast);
												eth0Obj.setIpv4Netmask(eth0_ipv4Netmask);
												eth0Obj.setIpv4Broadcast(eth0_ipv4Broadcast);
												eth0Obj.setIpv6Netmask(eth0_ipv6Netmask);
												eth0Obj.setStats(eth0_stats);
												networkObj.setEth0(eth0Obj);
											 }
										 if (eth1!=null && eth1.size()>0) {
											 Eth1 eth1Obj= new Eth1();

											 String eth1_incoming=eth1.get("incoming").asText();
											String eth1_outgoing=eth1.path("outgoing").asText();
											String eth1_stats=	eth1.path("stats").asText();
												String eth1_macBroadcast=eth1.path("macBroadcast").asText();		
												String eth1_macAddress=eth1.path("macAddress").asText();
												eth1Obj.setIncoming(eth1_incoming);
												eth1Obj.setOutgoing(eth1_outgoing);
												eth1Obj.setStats(eth1_stats);
												eth1Obj.setMacBroadcast(eth1_macBroadcast);
												eth1Obj.setMacAddress(eth1_macAddress);
												networkObj.setEth1(eth1Obj);
												 }
											 
										 if (lo!=null && lo.size()>0) {
											 Lo loObj= new Lo();
											 	String lo_ipv4Address=	lo.path("ipv4Address").asText();
											 	String lo_macAddress=	lo.path("macAddress").asText();
											 	String lo_outgoing=lo.path("outgoing").asText();
											 	String lo_incoming= lo.path("incoming").asText();
											 	String lo_ipv6Address=lo.path("ipv6Address").asText();
											 	String lo_ipv6Netmask=lo.path("ipv6Netmask").asText();
											 	String lo_ipv4Netmask=lo.path("ipv4Netmask").asText();
											 	String lo_stats=lo.path("stats").asText();
											 	loObj.setIpv4Address(lo_ipv4Address);
											 	loObj.setMacAddress(lo_macAddress);
											 	loObj.setOutgoing(lo_outgoing);
											 	loObj.setIncoming(lo_incoming);
											 	loObj.setIpv6Address(lo_ipv6Address);
											 	loObj.setIpv6Netmask(lo_ipv6Netmask);
											 	loObj.setIpv4Netmask(lo_ipv4Netmask);
											 	loObj.setStats(lo_stats);
											 	networkObj.setLo(loObj);
											  }
											 dataObj.setNetwork(networkObj);
								 }	
									 monitorStats.setData(dataObj);
							}
								 monitorStats.setApplianceIp(app.getIpAddress());			
								 monitorStats.setHoursminutes(hoursMinute);
								 monitorStats.setCreatedDate(new Date());
								 monitorStats.setApiName(apiName);	
							
								createMonitorStats(app.getIpAddress(),monitorStats.getApiName(),monitorStats);
							}						
			 
					}else {
						if(response!=null && response.getBody()!=null && response.getBody().contains("busy")) {
							responseMonitorStats.setResponseCode("409");
							responseMonitorStats.setResponseMessage(env.getProperty("appliance.system.busy.cavium"));
						}if(response!=null && response.getBody()!=null && response.getBody().contains("bad credentials")) {
							responseMonitorStats.setResponseCode("409");
							responseMonitorStats.setResponseMessage(env.getProperty("appliance.badcredentials.cavium"));
						}if(response!=null && response.getStatusCodeValue()== 408){
							responseMonitorStats.setResponseCode("408");
							responseMonitorStats.setResponseMessage(env.getProperty("appliance.connectionerror.cavium"));
						}if(response!=null && response.getBody()!=null && response.getBody().contains("11008")) {
							responseMonitorStats.setResponseCode("11008");
							responseMonitorStats.setResponseMessage(env.getProperty("appliance.badcredentials.cavium"));
						}if(response!=null && response.getBody()!=null && response.getBody().contains("errors")) {
							responseMonitorStats.setResponseCode("405");
							responseMonitorStats.setResponseMessage(env.getProperty("appliance.internalerror.cavium"));
						}
					}

				}else {
					responseMonitorStats.setResponseCode("409");
					responseMonitorStats.setResponseMessage(env.getProperty("appliance.notexists.cavium"));
				}
			}
		} catch (Exception e) {			  
			logger.info("Error occured during getting monitorStats into hostMonitorStats method of class HostAdminVMServiceImpl"+e.getMessage());
		}
		return responseMonitorStats;
		}
	}


	public List<ApplianceCityDetail>listAppliancesDetailCityWise(List<ApplianceDetailModel> listApplianceDetailModels){
		TreeMap<String,ApplianceCityDetail> cityNameMap= new TreeMap<String, ApplianceCityDetail>(String.CASE_INSENSITIVE_ORDER);
		ApplianceCityDetail objApplianceCityDetail= null;	
		List<ApplianceCityDetail> listApplianceToplology=null;
		for (Iterator<ApplianceDetailModel> iterator = listApplianceDetailModels.iterator(); iterator.hasNext();) {
			ApplianceDetailModel applianceDetailModel = (ApplianceDetailModel) iterator.next();
			String cityName=applianceDetailModel.getCityName();
			logger.info("cityName :: Appliance Status "+cityName +"::"+applianceDetailModel.getApplianceStatus());	 
			if("Active".equals(applianceDetailModel.getApplianceStatus())){

				if(!cityNameMap.containsKey(cityName)){
					objApplianceCityDetail= new ApplianceCityDetail();
					objApplianceCityDetail.setCityName(cityName);
					cityNameMap.put(cityName,objApplianceCityDetail);	
				}					 					
				if(cityNameMap.containsKey(cityName)){
					objApplianceCityDetail=cityNameMap.get(cityName);
					objApplianceCityDetail.getApplianceStatus().setActiveStatus((objApplianceCityDetail.getApplianceStatus().getActiveStatus()+1));
				}
			}
			if("Inactive".equals(applianceDetailModel.getApplianceStatus())){
				if(!cityNameMap.containsKey(cityName)){		
					objApplianceCityDetail= new ApplianceCityDetail();
					objApplianceCityDetail.setCityName(cityName);
					cityNameMap.put(cityName,objApplianceCityDetail);
				}					 					
				if(cityNameMap.containsKey(cityName)){
					objApplianceCityDetail=cityNameMap.get(cityName);
					objApplianceCityDetail.getApplianceStatus().setInactiveStatus((objApplianceCityDetail.getApplianceStatus().getInactiveStatus()+1));
				}
			}
			if("Suspended".equals(applianceDetailModel.getApplianceStatus())){
				if(!cityNameMap.containsKey(cityName)){
					objApplianceCityDetail= new ApplianceCityDetail();
					objApplianceCityDetail.setCityName(cityName);
					cityNameMap.put(cityName,objApplianceCityDetail);	
				}					 					
				if(cityNameMap.containsKey(cityName)){
					objApplianceCityDetail=cityNameMap.get(cityName);
					objApplianceCityDetail.getApplianceStatus().setSuspendedStatus((objApplianceCityDetail.getApplianceStatus().getSuspendedStatus()+1));
				}
			}
		}
		listApplianceToplology = new ArrayList<ApplianceCityDetail>(cityNameMap.values());
		return listApplianceToplology;
	}
	/*
	 * setHostNetorkVmConfig is used to send the network Data in Cavium Rest API 
	 * @ requestParam : adminVMData
	 *  
	 */
	public CaviumResponseModel setHostNetorkVmConfig(String applianceIp,AdminVMData adminVMData){
		CaviumResponseModel responseModel=getCaviumResponseModel();
		try{
			JSONObject json = new JSONObject(); 
			String loggedInUser = userAttributes.getlogInUserName();
			if(adminVMData.getApplianceId()!=null){
				ApplianceDetailModel dbAppliance=applianceRepository.findOne(Long.parseLong(adminVMData.getApplianceId())); 
				if(dbAppliance!=null) {  
					long applianceId=dbAppliance.getApplianceId();
					InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(applianceId);
					List<DualFactorUsersRelationshipModel> dfmodelList=dfUsersRelationshipRepository.getDualFactorDetails(loggedInUser, applianceId);		
					DualFactorUsersRelationshipModel dfmodel=null;
					if(dfmodelList!=null && dfmodelList.size()>0){
					 dfmodel=dfmodelList.get(0);
					}
					if(initmodel!=null) {
						InitializeApplianceDetailModel initAppDetailModel = initializeRepository.findOne(initmodel.getInitializeId());
						DualFactorAuthDetailModel dualAuthModel=initAppDetailModel.getDualFactorAuthDetailModel();
					
						if(!StringUtils.isEmpty(adminVMData.getUsername()) && !StringUtils.isEmpty(adminVMData.getPassword())) {
							if(initAppDetailModel.getAuthenticationLevel()==0) {
								json.put("username", adminVMData.getUsername());
								json.put("password", adminVMData.getPassword());
							}if(initAppDetailModel.getAuthenticationLevel() == 1 && dfmodel==null){								 
								dfmodel=createDualFile(loggedInUser, initmodel.getInitializeId(),initAppDetailModel.getCryptoOfficerName(),CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()),dualAuthModel);
							}
							if(initAppDetailModel.getAuthenticationLevel()==1 && dualAuthModel!=null) {
								json.put("username", adminVMData.getUsername());
								json.put("password", adminVMData.getPassword());
								json.put("dualFactorKeyFile", dfmodel.getDualFactorKeyFileId());
								json.put("dualFactorPort", Integer.parseInt(dfmodel.getDualFactorAuthServerPortNo()));
								json.put("dualFactorCertificate", dfmodel.getDualFactorCertificateId());
							 
							}
						}else {
							if(initAppDetailModel.getAuthenticationLevel()==0) {
								json.put("username", initAppDetailModel.getCryptoOfficerName());
								json.put("password", CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));
							}
							if(initAppDetailModel.getAuthenticationLevel() == 1 && dfmodel==null){
								dfmodel=createDualFile(loggedInUser, initmodel.getInitializeId(),initAppDetailModel.getCryptoOfficerName(),CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()),dualAuthModel);
							}
							if(initAppDetailModel.getAuthenticationLevel()==1 && dualAuthModel!=null) {
								json.put("username", initAppDetailModel.getCryptoOfficerName());
								json.put("password", CaviumUtil.decrypt(initAppDetailModel.getConfirmCryptoOfficerpassword()));
								json.put("dualFactorKeyFile", dfmodel.getDualFactorKeyFileId());
								json.put("dualFactorPort", Integer.parseInt(dfmodel.getDualFactorAuthServerPortNo()));
								json.put("dualFactorCertificate", dfmodel.getDualFactorCertificateId());
							}
						}
					}else {
						if(dfmodel!=null){
							json.put("dualFactorKeyFile", dfmodel.getDualFactorKeyFileId());
							json.put("dualFactorPort", Integer.parseInt(dfmodel.getDualFactorAuthServerPortNo()));
							json.put("dualFactorCertificate", dfmodel.getDualFactorCertificateId());
							}
						if(!StringUtils.isEmpty(adminVMData.getUsername()) && !StringUtils.isEmpty(adminVMData.getPassword())) {
							json.put("username", adminVMData.getUsername());
							json.put("password", adminVMData.getPassword());
						}else {
							responseModel.setResponseCode("409");
							responseModel.setResponseMessage("Host Network data not saved due to credentials not available");
							return responseModel;
						}
					}


					Map<String,Object> general= new HashMap<String,Object>();
				if(adminVMData.getGeneral().getDhcp()!=null && adminVMData.getGeneral().getDhcp()) {
					general.put("dhcp", adminVMData.getGeneral().getDhcp());	
				}else {
					general.put("gateway", adminVMData.getGeneral().getGateway());
					general.put("ip",adminVMData.getGeneral().getIp());
					general.put("subnetMask", adminVMData.getGeneral().getSubnet());		
					general.put("vlan", Integer.parseInt(adminVMData.getGeneral().getVlan()));	
					Map<String,Object> mac= new HashMap<String,Object>();
					mac.put("staticMac", adminVMData.getGeneral().getMacStatic());
					mac.put("address", adminVMData.getGeneral().getMacAddress());
					general.put("mac", mac);
				}
					json.put("general",general);
					Map<String,Object> advanced= new HashMap<String,Object>();
					Map<String,Object> dnsConfig= new HashMap<String,Object>();
					if(adminVMData.getAdvanced()!=null){
						if(adminVMData.getAdvanced().getEnableDNSService()!=null){
						dnsConfig.put("enableService",adminVMData.getAdvanced().getEnableDNSService());
						}
						if(adminVMData.getAdvanced().getEnableDNSService()==null){
							dnsConfig.put("enableService",false);
							}
						
						 
						if(adminVMData.getAdvanced().getSearchDomainNames()!=null){
						dnsConfig.put("searchDomainNames", adminVMData.getAdvanced().getSearchDomainNames());
						}
						if(adminVMData.getAdvanced().getDnsServers()!=null){
						dnsConfig.put("dnsServers", adminVMData.getAdvanced().getDnsServers());
						}
						if(dnsConfig.size()>0){
						advanced.put("dnsConfig", dnsConfig);
						}
						Map<String,Object> staticIpToHostConfig= new HashMap<String,Object>();
						if(adminVMData.getAdvanced().getRemovedHostIPs()!=null && adminVMData.getAdvanced().getRemovedHostIPs().size()>0){
							 staticIpToHostConfig.put("remove",adminVMData.getAdvanced().getRemovedHostIPs());
								advanced.put("staticIpToHostConfig", staticIpToHostConfig);
						}					
						List<Map<String,Object>> addList= new ArrayList<Map<String,Object>>();
						if(adminVMData.getAdvanced().getStaticIpToHostConfig()!=null && adminVMData.getAdvanced().getStaticIpToHostConfig().size()>0){
							for (Iterator<StaticIpToHostConfig> iterator = adminVMData.getAdvanced().getStaticIpToHostConfig().iterator(); iterator.hasNext();) {
								StaticIpToHostConfig  obj = (StaticIpToHostConfig) iterator.next();
								Map<String,Object> staticIpToHostConfigMap= new HashMap<String,Object>();
							
								staticIpToHostConfigMap.put("ip", obj.getIp());
								staticIpToHostConfigMap.put("hostname", obj.getHostname());
								staticIpToHostConfigMap.put("alias", obj.getAlias());
								addList.add(staticIpToHostConfigMap);
							}
							staticIpToHostConfig.put("add",addList);
							advanced.put("staticIpToHostConfig", staticIpToHostConfig);
							
							//json.put("staticIpToHostConfig",staticIpToHostConfig);
						}
						if(advanced!=null && advanced.size()>0){
						json.put("advanced",advanced);
						}
					}
					ResponseEntity<String> response=restClient.invokePOSTMethodForOperations("https://"+applianceIp+"/liquidsa/admin_vm_net_config", json);
					if(response!=null && response.getStatusCode().name().equals("OK")) {
						ObjectMapper mapper = new ObjectMapper();
						if(response.getBody()!=null){
							JsonNode root = mapper.readTree(response.getBody());
							if(!root.isNull()){
								String status = root.path("status").asText();
								if("success".equalsIgnoreCase(status)){
									responseModel.setResponseCode("200");
									responseModel.setResponseMessage("data saved successfully");
									recentActivityService.createRecentActivity(loggedInUser, "Network Setting details on "+dbAppliance.getApplianceName()+" updated by "+loggedInUser+".",CaviumConstant.APPLIANCE_MANAGEMENT);
									if((adminVMData.getGeneral().getDhcp()==null || adminVMData.getGeneral().getDhcp()==false) && adminVMData.getGeneral().getIp()!=null){
									updateApplianceIp(applianceIp,adminVMData.getGeneral().getIp());
									}
								}else{
									JsonNode errors = root.path("errors");						
									  if(!errors.isNull() && errors.size() > 0){
										   StringBuilder sbmessage=new StringBuilder();
												StringBuilder sbcode=new StringBuilder();
												Iterator<JsonNode> itr = errors.elements();	
												while (itr.hasNext()) {
													JsonNode temp = itr.next();
													sbcode.append(""+temp.asInt()+"");
													if(env.containsProperty(""+temp.asInt()+"")) {
														sbmessage.append(env.getProperty(""+temp.asInt()+""));
													}else {
														sbmessage.append("Error message not available");
													}
													sbcode.append(",");
													sbmessage.append(",");
												}
												String message=sbmessage.toString();
												message=message.substring(0, message.length()-1);
												message=message+".";
												String code=sbcode.toString();
												code=code.substring(0, code.length()-1);
												code=code+".";
												responseModel.setResponseCode(code);											
												responseModel.setResponseMessage(message);
												alertsService.createAlert(loggedInUser,"Device "+dbAppliance.getApplianceName()+"  try to perform update Network Setting details by "+loggedInUser+" did not update due to "+responseModel.getResponseMessage() ,dbAppliance.getApplianceName(),dbAppliance.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
											} else {
												String encodeMessage = "";
												encodeMessage = root.path("message").asText();
												encodeMessage = CaviumUtil.decodeMessageBase64(encodeMessage);
												responseModel.setResponseCode("409");											
												responseModel.setResponseMessage(encodeMessage);
												 alertsService.createAlert(loggedInUser,"Device "+dbAppliance.getApplianceName()+"  try to perform update Network Setting details by "+loggedInUser+" did not update due to "+responseModel.getResponseMessage() ,dbAppliance.getApplianceName(),dbAppliance.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
											}
								}
									
								 
							}
						} 
					}
					else {
						responseModel.setResponseCode("409");
						responseModel.setResponseMessage(env.getProperty("appliance.notexists.cavium"));
						 alertsService.createAlert(loggedInUser,"Device "+dbAppliance.getApplianceName()+"  try to perform update Network Setting details by "+loggedInUser+" does not exist in system.",CaviumConstant.APPLIANCE_MANAGEMENT);
					}
				}else {
					responseModel.setResponseCode("409");
					responseModel.setResponseMessage(env.getProperty("appliance.notexists.cavium"));
					alertsService.createAlert(loggedInUser,"Device "+adminVMData.getApplianceIp()+"  try to perform update Network Setting details by "+loggedInUser+" does not exist in system.",CaviumConstant.APPLIANCE_MANAGEMENT);
				}
			}else{
				responseModel.setResponseCode("409");
				responseModel.setResponseMessage("appliance Id coming as blank");
			}
		}
		catch (Exception e) {
			logger.error("Error occured during data save for HostNetorkVmConfig in network."+e.getMessage());
		}

		return responseModel;
	}
	
 
	 
	public void createMonitorStats(String applianceIp,String apiName,MonitorStats monitorStats ) {
		try {
			List<MonitorStats> monitorStatList= monitorStatsRepository.getMonistorStats(apiName,applianceIp);
			if(monitorStatList.size() == 5) {
				monitorStatsRepository.delete(monitorStatList.get(4).getMonitorStatsId());
				//monitorStats.setMonitorStatsId(monitorStatList.get(4).getMonitorStatsId());
				monitorStatsRepository.save(monitorStats);
			}else {
			
				monitorStatsRepository.save(monitorStats);
				}
		} catch (Exception e) {
		  logger.error("Error occured due to db error inside createMonitorStats ::" + e.getMessage());
		 }
	}
	
	public List<MonitorStats> getMonitorStats(String applianceIp,String apiName) {
		List<MonitorStats> monitorStatList=null;
		try {
			  monitorStatList= monitorStatsRepository.getMonistorStats(apiName,applianceIp);
		} catch (Exception e) {	 
			logger.error("Error occured due to db error inside getMonitorStats ::" + e.getMessage());
			 
		}
		return monitorStatList;
	}
	
	public CaviumResponseModel updateApplianceIp(String ipAddress,String newIpAddress){
		 CaviumResponseModel responseModel=getCaviumResponseModel();
		try {
			inProgressActivityRepository.updateApplianceIp(newIpAddress, ipAddress);
			clusterPartitionsRelationshipRepository.updateApplianceIp(newIpAddress, ipAddress);
			applianceRepository.updateApplianceIp(newIpAddress, ipAddress);
			monitorStatsRepository.updateApplianceIp(newIpAddress, ipAddress);	
			alertsRepository.updateIpAddress(newIpAddress, ipAddress);
			responseModel.setResponseCode("200");
			responseModel.setResponseMessage("success");
		} catch (Exception e) {
			// TODO: handle exception
			responseModel.setResponseCode("409");
			responseModel.setResponseMessage("Failed");
			logger.error("Error occured during updateApplianceIp inside class HostAdminVMServiceImpl"+e.getMessage());
		}
		return responseModel;
	}
	
	public DualFactorUsersRelationshipModel  createDualFile(String loggedInUser, Long applianceId,String coUsername,String coPassword,DualFactorAuthDetailModel dualAuthModel)
	{
		DualFactorUsersRelationshipModel dualFactorUsersRelationship=new DualFactorUsersRelationshipModel();
		try{	
			File convertedFile=null;
			String certificateId=null;
			CaviumResponseModel caviumResponseModel=getCaviumResponseModel();
			String keyfileName=dualAuthModel.getKeyfileName();
			String keyfileExtension=dualAuthModel.getKeyfileExtension();
			String keyfileContent=dualAuthModel.getKeyfileContent();
			String certificateName=dualAuthModel.getCertificateName();
			String certificateExtension=dualAuthModel.getCertificateExtension();
			String certificateContent=dualAuthModel.getCertificateContent();
			String portNumber=dualAuthModel.getDualFactorAuthServerPortNo();

			ApplianceDetailModel appliance=applianceRepository.findOne(applianceId);
			try{
				convertedFile= CaviumUtil.createFile(keyfileName,keyfileExtension,keyfileContent);
			}catch (IOException e) {
				logger.error("Error while creating Key file in createDualFile method :: "+e.getMessage());
			}
			caviumResponseModel=fileUploadService.uploadFile(convertedFile,coUsername,coPassword,"LoginHSM",appliance.getIpAddress(),null);
			String	keyFileId=caviumResponseModel.getResponseMessage();
			if(convertedFile!=null){
				Files.deleteIfExists(Paths.get(convertedFile.getAbsolutePath()));
			}	
			if(caviumResponseModel!=null && "200".equals(caviumResponseModel.getResponseCode()))
			{
				try{
					convertedFile= CaviumUtil.createFile(certificateName,certificateExtension,certificateContent);
				}catch (IOException e) {
					logger.error("Error while creating Certificate in createDualFile method :: "+e.getMessage()); 

				}
				caviumResponseModel=fileUploadService.uploadFile(convertedFile,coUsername,coPassword,"LoginHSM",appliance.getIpAddress(),null);
				certificateId=caviumResponseModel.getResponseMessage();
				if(convertedFile!=null){
					Files.deleteIfExists(Paths.get(convertedFile.getAbsolutePath()));
				}

				if(caviumResponseModel!=null && certificateId!=null &&  keyFileId!=null){					 
					dualFactorUsersRelationship.setUserId(loggedInUser);
					dualFactorUsersRelationship.setApplianceId(appliance.getApplianceId());
					dualFactorUsersRelationship.setDualFactorCertificateId(certificateId);
					dualFactorUsersRelationship.setDualFactorKeyFileId(keyFileId);
					dualFactorUsersRelationship.setDualFactorAuthServerPortNo(portNumber);
					dfUsersRelationshipRepository.save(dualFactorUsersRelationship);
				}

			}
		}catch (Exception e) {
			logger.error("Error in createDualFile method :: "+e.getMessage()); 
		}
		return dualFactorUsersRelationship;
	}
}

