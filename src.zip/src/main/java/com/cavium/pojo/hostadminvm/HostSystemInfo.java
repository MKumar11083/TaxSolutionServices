package com.cavium.pojo.hostadminvm;

import org.springframework.stereotype.Component;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.pojo.ApplianceInfo;
import com.cavium.pojo.HSMInfo;
import com.cavium.pojo.PartitionsDetails;
@Component
public class HostSystemInfo {
	
	HSMInfo hsmInfo;
	ApplianceInfo applianceInfo;
	PartitionsDetails partitionsDetails;
	HostStats hostStats;
	AdminVMConfig adminVMConfig;
	AdminSNMPConfig adminSNMPConfig;
	ApplianceDetailModel applianceDetailModel;
	/**
	 * @return the hsmInfo
	 */
	public HSMInfo getHsmInfo() {
		return hsmInfo;
	}
	/**
	 * @param hsmInfo the hsmInfo to set
	 */
	public void setHsmInfo(HSMInfo hsmInfo) {
		this.hsmInfo = hsmInfo;
	}
	/**
	 * @return the applianceInfo
	 */
	public ApplianceInfo getApplianceInfo() {
		return applianceInfo;
	}
	/**
	 * @param applianceInfo the applianceInfo to set
	 */
	public void setApplianceInfo(ApplianceInfo applianceInfo) {
		this.applianceInfo = applianceInfo;
	}
	/**
	 * @return the partitionsDetails
	 */
	public PartitionsDetails getPartitionsDetails() {
		return partitionsDetails;
	}
	/**
	 * @param partitionsDetails the partitionsDetails to set
	 */
	public void setPartitionsDetails(PartitionsDetails partitionsDetails) {
		this.partitionsDetails = partitionsDetails;
	}
	/**
	 * @return the hostStats
	 */
	public HostStats getHostStats() {
		return hostStats;
	}
	/**
	 * @param hostStats the hostStats to set
	 */
	public void setHostStats(HostStats hostStats) {
		this.hostStats = hostStats;
	}
	/**
	 * @return the adminVMConfig
	 */
	public AdminVMConfig getAdminVMConfig() {
		return adminVMConfig;
	}
	/**
	 * @param adminVMConfig the adminVMConfig to set
	 */
	public void setAdminVMConfig(AdminVMConfig adminVMConfig) {
		this.adminVMConfig = adminVMConfig;
	}
	/**
	 * @return the adminSNMPConfig
	 */
	public AdminSNMPConfig getAdminSNMPConfig() {
		return adminSNMPConfig;
	}
	/**
	 * @param adminSNMPConfig the adminSNMPConfig to set
	 */
	public void setAdminSNMPConfig(AdminSNMPConfig adminSNMPConfig) {
		this.adminSNMPConfig = adminSNMPConfig;
	}
	/**
	 * @return the applianceDetailModel
	 */
	public ApplianceDetailModel getApplianceDetailModel() {
		return applianceDetailModel;
	}
	/**
	 * @param applianceDetailModel the applianceDetailModel to set
	 */
	public void setApplianceDetailModel(ApplianceDetailModel applianceDetailModel) {
		this.applianceDetailModel = applianceDetailModel;
	}
	 
	

}
