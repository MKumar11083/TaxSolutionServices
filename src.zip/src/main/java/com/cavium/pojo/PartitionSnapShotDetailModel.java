package com.cavium.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Table(name = "partition_snapshot_details")
public class PartitionSnapShotDetailModel {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	@Column(name="zeroized_state")
	private int zeroizedState;
	@Column(name="fip_mode")
	private int fipMode;
	@Column(name="fip_mode_with_dualfactor")
	private int fipModeWithDualfactor;
	@Column(name="non_fip_mode")
	private int nonFipMode;
	@Column(name="avaliable_partition_slots")
	private int avaliablePartitionSlots;
	@Column(name="total_partition_slots")
	private int totalPartitionSlots;
	@Column(name="occupied_partition_slots")
	private int occupiedPartitionSlots;
	@Column(name="partition_functional_status")
	private int partitionFunctionalStatus;
	@Column(name="partition_non_functional_status")
	private int partitionNonFunctionalStatus;
	@Column(name="user_name")
	private String userName;
	@Column(name="appliance_name")
	private String applianceName;
	@Column(name="appliance_id")
	private Long applianceId;
	
	 
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * @return the zeroizedState
	 */
	public int getZeroizedState() {
		return zeroizedState;
	}
	/**
	 * @param zeroizedState the zeroizedState to set
	 */
	public void setZeroizedState(int zeroizedState) {
		this.zeroizedState = zeroizedState;
	}
	/**
	 * @return the fipMode
	 */
	public int getFipMode() {
		return fipMode;
	}
	/**
	 * @param fipMode the fipMode to set
	 */
	public void setFipMode(int fipMode) {
		this.fipMode = fipMode;
	}
	/**
	 * @return the fipModeWithDualfactor
	 */
	public int getFipModeWithDualfactor() {
		return fipModeWithDualfactor;
	}
	/**
	 * @param fipModeWithDualfactor the fipModeWithDualfactor to set
	 */
	public void setFipModeWithDualfactor(int fipModeWithDualfactor) {
		this.fipModeWithDualfactor = fipModeWithDualfactor;
	}
	/**
	 * @return the nonFipMode
	 */
	public int getNonFipMode() {
		return nonFipMode;
	}
	/**
	 * @param nonFipMode the nonFipMode to set
	 */
	public void setNonFipMode(int nonFipMode) {
		this.nonFipMode = nonFipMode;
	}
	/**
	 * @return the avaliablePartitionSlots
	 */
	public int getAvaliablePartitionSlots() {
		return avaliablePartitionSlots;
	}
	/**
	 * @param avaliablePartitionSlots the avaliablePartitionSlots to set
	 */
	public void setAvaliablePartitionSlots(int avaliablePartitionSlots) {
		this.avaliablePartitionSlots = avaliablePartitionSlots;
	}
	/**
	 * @return the totalPartitionSlots
	 */
	public int getTotalPartitionSlots() {
		return totalPartitionSlots;
	}
	/**
	 * @param totalPartitionSlots the totalPartitionSlots to set
	 */
	public void setTotalPartitionSlots(int totalPartitionSlots) {
		this.totalPartitionSlots = totalPartitionSlots;
	}
	/**
	 * @return the occupiedPartitionSlots
	 */
	public int getOccupiedPartitionSlots() {
		return occupiedPartitionSlots;
	}
	/**
	 * @param occupiedPartitionSlots the occupiedPartitionSlots to set
	 */
	public void setOccupiedPartitionSlots(int occupiedPartitionSlots) {
		this.occupiedPartitionSlots = occupiedPartitionSlots;
	}
	/**
	 * @return the partitionFunctionalStatus
	 */
	public int getPartitionFunctionalStatus() {
		return partitionFunctionalStatus;
	}
	/**
	 * @param partitionFunctionalStatus the partitionFunctionalStatus to set
	 */
	public void setPartitionFunctionalStatus(int partitionFunctionalStatus) {
		this.partitionFunctionalStatus = partitionFunctionalStatus;
	}
	/**
	 * @return the partitionNonFunctionalStatus
	 */
	public int getPartitionNonFunctionalStatus() {
		return partitionNonFunctionalStatus;
	}
	/**
	 * @param partitionNonFunctionalStatus the partitionNonFunctionalStatus to set
	 */
	public void setPartitionNonFunctionalStatus(int partitionNonFunctionalStatus) {
		this.partitionNonFunctionalStatus = partitionNonFunctionalStatus;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getApplianceName() {
		return applianceName;
	}
	public void setApplianceName(String applianceName) {
		this.applianceName = applianceName;
	}
	public Long getApplianceId() {
		return applianceId;
	}
	public void setApplianceId(Long applianceId) {
		this.applianceId = applianceId;
	}
	
	
} 
 
