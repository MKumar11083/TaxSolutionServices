package com.cavium.pojo;

public class ConnectedPartitions {
	
	private String connectivityStatus;
	private boolean keySynced;
	private Integer nodeId;
	private Long partitionId;
	 
	/**
	 * @return the keySynced
	 */
	public boolean isKeySynced() {
		return keySynced;
	}
	/**
	 * @param keySynced the keySynced to set
	 */
	public void setKeySynced(boolean keySynced) {
		this.keySynced = keySynced;
	}
	/**
	 * @return the connectivityStatus
	 */
	public String getConnectivityStatus() {
		return connectivityStatus;
	}
	/**
	 * @param connectivityStatus the connectivityStatus to set
	 */
	public void setConnectivityStatus(String connectivityStatus) {
		this.connectivityStatus = connectivityStatus;
	}
	/**
	 * @return the nodeId
	 */
	public Integer getNodeId() {
		return nodeId;
	}
	/**
	 * @param nodeId the nodeId to set
	 */
	public void setNodeId(Integer nodeId) {
		this.nodeId = nodeId;
	}
	/**
	 * @return the partitionId
	 */
	public Long getPartitionId() {
		return partitionId;
	}
	/**
	 * @param partitionId the partitionId to set
	 */
	public void setPartitionId(Long partitionId) {
		this.partitionId = partitionId;
	}
	 

}
