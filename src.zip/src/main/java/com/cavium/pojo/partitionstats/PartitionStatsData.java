package com.cavium.pojo.partitionstats;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

@Entity
@Table(name = "partition_stats_data_details")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class PartitionStatsData implements Serializable {
	
 

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@JsonProperty(access = Access.WRITE_ONLY)
	@Column(name = "id", nullable = false)
	private Long id;
	
@Column(name = "vm_status")
 private Long vmStatus;
@OneToOne(cascade=CascadeType.ALL,fetch = FetchType.LAZY)
 @JoinColumn(name = "vmstats",nullable = false)
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
 private Vmstats vmstats;
/**
 * @return the vmStatus
 */
public Long getVmStatus() {
	return vmStatus;
}
/**
 * @param vmStatus the vmStatus to set
 */
public void setVmStatus(Long vmStatus) {
	this.vmStatus = vmStatus;
}
/**
 * @return the vmstats
 */
public Vmstats getVmstats() {
	return vmstats;
}
/**
 * @param vmstats the vmstats to set
 */
public void setVmstats(Vmstats vmstats) {
	this.vmstats = vmstats;
}
/**
 * @return the id
 */
public Long getId() {
	return id;
}
/**
 * @param id the id to set
 */
public void setId(Long id) {
	this.id = id;
}


  
}
