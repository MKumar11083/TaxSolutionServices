package com.cavium.pojo.partitionstats;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

@Entity
@Table(name = "partition_stats_vm_details")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Vmstats  implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@JsonProperty(access = Access.WRITE_ONLY)
	@Column(name = "id", nullable = false)
	private Long id;
	
	 @OneToOne(cascade=CascadeType.ALL,fetch = FetchType.LAZY)
	 @JoinColumn(name = "tx_queue",nullable = false)
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
 private TxQueue txQueue;
	
	@Column(name = "link_status_eth0")
 private Long linkStatusEth0;
	
	@Column(name = "link_status_eth1")
 private Long linkStatusEth1;
	
	@Column(name = "cav_server_status")
 private Long cavServerStatus;
	
 @OneToOne(cascade=CascadeType.ALL,fetch = FetchType.LAZY)
 @JoinColumn(name = "drv_req_id_queue",nullable = false)
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
 private DrvReqIdQueue drvReqIdQueue;
 
 @Column(name = "cpu_usage_percentage")
 private Long cpuUsagePercentage;
 
 @OneToOne(cascade=CascadeType.ALL,fetch = FetchType.LAZY)
 @JoinColumn(name = "disk_space_in_mb",nullable = false)
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
 private DiskSpaceInMb diskSpaceInMb;
 
 @OneToOne(cascade=CascadeType.ALL,fetch = FetchType.LAZY)
 @JoinColumn(name = "fw_req_id_queue",nullable = false)
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
 private FwReqIdQueue fwReqIdQueue;
 
 @OneToOne(cascade=CascadeType.ALL,fetch = FetchType.LAZY)
 @JoinColumn(name = "system_up_time",nullable = false)
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
 private SystemUpTime systemUpTime;
 
	@Column(name = "driver_status")
 private Long driverStatus;
 
	@Column(name = "process_count")
 private Long processCount;
	
 @OneToOne(cascade=CascadeType.ALL,fetch = FetchType.LAZY)
 @JoinColumn(name = "swap_stats_in_mb",nullable = false)
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"}) 
 private SwapStatsInMb swapStatsInMb;
 
 @OneToOne(cascade=CascadeType.ALL,fetch = FetchType.LAZY)
 @JoinColumn(name = "rx_queue",nullable = false)
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"}) 
 private RxQueue rxQueue;
 
 @OneToOne(cascade=CascadeType.ALL,fetch = FetchType.LAZY)
 @JoinColumn(name = "ram_stats_in_mb",nullable = false)
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
 private RamStatsinMb ramStatsInMb;
/**
 * @return the txQueue
 */
public TxQueue getTxQueue() {
	return txQueue;
}
/**
 * @param txQueue the txQueue to set
 */
public void setTxQueue(TxQueue txQueue) {
	this.txQueue = txQueue;
}
/**
 * @return the linkStatusEth0
 */
public Long getLinkStatusEth0() {
	return linkStatusEth0;
}
/**
 * @param linkStatusEth0 the linkStatusEth0 to set
 */
public void setLinkStatusEth0(Long linkStatusEth0) {
	this.linkStatusEth0 = linkStatusEth0;
}
/**
 * @return the linkStatusEth1
 */
public Long getLinkStatusEth1() {
	return linkStatusEth1;
}
/**
 * @param linkStatusEth1 the linkStatusEth1 to set
 */
public void setLinkStatusEth1(Long linkStatusEth1) {
	this.linkStatusEth1 = linkStatusEth1;
}
/**
 * @return the cavServerStatus
 */
public Long getCavServerStatus() {
	return cavServerStatus;
}
/**
 * @param cavServerStatus the cavServerStatus to set
 */
public void setCavServerStatus(Long cavServerStatus) {
	this.cavServerStatus = cavServerStatus;
}
/**
 * @return the drvReqIdQueue
 */
public DrvReqIdQueue getDrvReqIdQueue() {
	return drvReqIdQueue;
}
/**
 * @param drvReqIdQueue the drvReqIdQueue to set
 */
public void setDrvReqIdQueue(DrvReqIdQueue drvReqIdQueue) {
	this.drvReqIdQueue = drvReqIdQueue;
}
/**
 * @return the cpuUsagePercentage
 */
public Long getCpuUsagePercentage() {
	return cpuUsagePercentage;
}
/**
 * @param cpuUsagePercentage the cpuUsagePercentage to set
 */
public void setCpuUsagePercentage(Long cpuUsagePercentage) {
	this.cpuUsagePercentage = cpuUsagePercentage;
}
/**
 * @return the diskSpaceInMb
 */
public DiskSpaceInMb getDiskSpaceInMb() {
	return diskSpaceInMb;
}
/**
 * @param diskSpaceInMb the diskSpaceInMb to set
 */
public void setDiskSpaceInMb(DiskSpaceInMb diskSpaceInMb) {
	this.diskSpaceInMb = diskSpaceInMb;
}
/**
 * @return the fwReqIdQueue
 */
public FwReqIdQueue getFwReqIdQueue() {
	return fwReqIdQueue;
}
/**
 * @param fwReqIdQueue the fwReqIdQueue to set
 */
public void setFwReqIdQueue(FwReqIdQueue fwReqIdQueue) {
	this.fwReqIdQueue = fwReqIdQueue;
}
/**
 * @return the systemUpTime
 */
public SystemUpTime getSystemUpTime() {
	return systemUpTime;
}
/**
 * @param systemUpTime the systemUpTime to set
 */
public void setSystemUpTime(SystemUpTime systemUpTime) {
	this.systemUpTime = systemUpTime;
}
/**
 * @return the driverStatus
 */
public Long getDriverStatus() {
	return driverStatus;
}
/**
 * @param driverStatus the driverStatus to set
 */
public void setDriverStatus(Long driverStatus) {
	this.driverStatus = driverStatus;
}
/**
 * @return the processCount
 */
public Long getProcessCount() {
	return processCount;
}
/**
 * @param processCount the processCount to set
 */
public void setProcessCount(Long processCount) {
	this.processCount = processCount;
}
/**
 * @return the swapStatsInMb
 */
public SwapStatsInMb getSwapStatsInMb() {
	return swapStatsInMb;
}
/**
 * @param swapStatsInMb the swapStatsInMb to set
 */
public void setSwapStatsInMb(SwapStatsInMb swapStatsInMb) {
	this.swapStatsInMb = swapStatsInMb;
}
/**
 * @return the rxQueue
 */
public RxQueue getRxQueue() {
	return rxQueue;
}
/**
 * @param rxQueue the rxQueue to set
 */
public void setRxQueue(RxQueue rxQueue) {
	this.rxQueue = rxQueue;
}
 
/**
 * @return the id
 */
public Long getId() {
	return id;
}
/**
 * @param id the id to set
 */
public void setId(Long id) {
	this.id = id;
}
/**
 * @return the ramStatsInMb
 */
public RamStatsinMb getRamStatsInMb() {
	return ramStatsInMb;
}
/**
 * @param ramStatsInMb the ramStatsInMb to set
 */
public void setRamStatsInMb(RamStatsinMb ramStatsInMb) {
	this.ramStatsInMb = ramStatsInMb;
}

 
}
