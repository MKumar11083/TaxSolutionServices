package com.cavium.pojo.partitionstats;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

@Entity
@Table(name = "partition_stats_system_up_time_details")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class SystemUpTime implements Serializable {

/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
@JsonProperty(access = Access.WRITE_ONLY)
@Column(name = "id", nullable = false)
private Long id;

@Column(name = "hours")
 private Long hours;

@Column(name = "seconds")
 private Long seconds;

@Column(name = "minutes")
 private Long minutes;
/**
 * @return the hours
 */
public Long getHours() {
	return hours;
}
/**
 * @param hours the hours to set
 */
public void setHours(Long hours) {
	this.hours = hours;
}
/**
 * @return the seconds
 */
public Long getSeconds() {
	return seconds;
}
/**
 * @param seconds the seconds to set
 */
public void setSeconds(Long seconds) {
	this.seconds = seconds;
}
/**
 * @return the minutes
 */
public Long getMinutes() {
	return minutes;
}
/**
 * @param minutes the minutes to set
 */
public void setMinutes(Long minutes) {
	this.minutes = minutes;
}
/**
 * @return the id
 */
public Long getId() {
	return id;
}
/**
 * @param id the id to set
 */
public void setId(Long id) {
	this.id = id;
}

 
}
