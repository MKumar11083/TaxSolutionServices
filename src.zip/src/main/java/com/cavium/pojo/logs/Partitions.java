package com.cavium.pojo.logs;

import java.util.ArrayList;

public class Partitions {
	
	private ArrayList<String> options;
	private ArrayList<String> partitionsNames;

	public ArrayList<String> getOptions() {
		return this.options;
	}

	public void setOptions(ArrayList<String> options) {
		this.options = options;
	}

	public ArrayList<String> getPartitionsNames() {
		return partitionsNames;
	}

	public void setPartitionsNames(ArrayList<String> partitionsNames) {
		this.partitionsNames = partitionsNames;
	}

	

}
