package com.cavium.pojo.logs;

import com.cavium.model.appliance.DualFactorUsersRelationshipModel;

public class LogsDetails {
	private String username;
	private long applianceId;
	private String operationUsername;
	private String operationPassword;
	private String applianceName;
	private String applianceIp;
	private String loggerType;
	private String password;
	private Logs logs;
	private DualFactorUsersRelationshipModel dualFactorDetails;

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Logs getLogs() {
		return this.logs;
	}

	public void setLogs(Logs logs) {
		this.logs = logs;
	}

	/**
	 * @return the applianceId
	 */
	public long getApplianceId() {
		return applianceId;
	}

	/**
	 * @param applianceId
	 *            the applianceId to set
	 */
	public void setApplianceId(long applianceId) {
		this.applianceId = applianceId;
	}

	/**
	 * @return the operationUsername
	 */
	public String getOperationUsername() {
		return operationUsername;
	}

	/**
	 * @param operationUsername
	 *            the operationUsername to set
	 */
	public void setOperationUsername(String operationUsername) {
		this.operationUsername = operationUsername;
	}

	/**
	 * @return the operationPassword
	 */
	public String getOperationPassword() {
		return operationPassword;
	}

	/**
	 * @param operationPassword
	 *            the operationPassword to set
	 */
	public void setOperationPassword(String operationPassword) {
		this.operationPassword = operationPassword;
	}

	/**
	 * @return the applianceName
	 */
	public String getApplianceName() {
		return applianceName;
	}

	/**
	 * @param applianceName
	 *            the applianceName to set
	 */
	public void setApplianceName(String applianceName) {
		this.applianceName = applianceName;
	}

	/**
	 * @return the applianceIp
	 */
	public String getApplianceIp() {
		return applianceIp;
	}

	/**
	 * @param applianceIp
	 *            the applianceIp to set
	 */
	public void setApplianceIp(String applianceIp) {
		this.applianceIp = applianceIp;
	}

	/**
	 * @return the loggerType
	 */
	public String getLoggerType() {
		return loggerType;
	}

	/**
	 * @param loggerType
	 *            the loggerType to set
	 */
	public void setLoggerType(String loggerType) {
		this.loggerType = loggerType;
	}

	public DualFactorUsersRelationshipModel getDualFactorDetails() {
		return dualFactorDetails;
	}

	public void setDualFactorDetails(DualFactorUsersRelationshipModel dualFactorDetails) {
		this.dualFactorDetails = dualFactorDetails;
	}
}