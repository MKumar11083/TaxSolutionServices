package com.cavium.controller.acl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.user.UserACLDetailsModel;
import com.cavium.service.user.UserService;
/*
 * This SearchUserACLController class is used for searching the ACL based on input in request
 *  @author RK00490847
 */	
@RestController
@RequestMapping("rest")
public class SearchUserACLController {

	// logger - instance of application log.
	private Logger logger = Logger.getLogger(this.getClass());

	// userService - Service class provide the interface for the Repository Operation.
	@Autowired
	private UserService userService;

	/*
	 * This searchACLs method will return the List of ACLs details. 
	 *  @return	
	 *  - The List of ACLs Details
	 */	@RequestMapping(value = "searchACLDetails" ,method = RequestMethod.POST)
	 public final  List<UserACLDetailsModel> searchACLs(@RequestBody UserACLDetailsModel userACLDetailsModel){
		 logger.info("Entered in searchACLDetails method");		 
		 List<UserACLDetailsModel> aclDetails= new ArrayList<UserACLDetailsModel>();
		 aclDetails = userService.getACLDetails(userACLDetailsModel);		
		 logger.info("End of searchACLDetails method");
		 return aclDetails;		
	 }
}
