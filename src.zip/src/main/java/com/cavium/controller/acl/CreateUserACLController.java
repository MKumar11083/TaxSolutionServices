package com.cavium.controller.acl;



import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.user.ACLRoleModel;
import com.cavium.model.user.ApplicationDetailModel;
import com.cavium.model.user.UserACLDetailsModel;
import com.cavium.pojo.UserAttributes;
import com.cavium.service.user.UserService;
import com.cavium.utill.CaviumResponseModel;


/*
 * This CreateUserACLController class is used for creating the new UserACL in Database.
 *  @author RK00490847
 */

@RestController
@RequestMapping("rest")
public class CreateUserACLController {
	// logger - instance of application log.
	private Logger logger = Logger.getLogger(this.getClass());

	// userService - Service class provide the interface for the Repository Operation.
	@Autowired
	private UserService userService;

	// userAttributes - get LogIn User Details
	@Autowired
	private UserAttributes userAttributes;

	@Lookup
	public CaviumResponseModel getCaviumResponseModel() {
		return null;
	};

	// get Property Value from Property File
	@Autowired
	Environment env;


	/*
	 * This getAllPermissionDetails method will return all the Permission. 	  
	 *  @return	
	 *  		- The List of All Permissions.
	 */
	@RequestMapping(value = "getAllPermissionsDetails" ,method = RequestMethod.GET)
	protected final  List<ApplicationDetailModel> getAllPermissionDetails() {
		List<ApplicationDetailModel> listApplicationDetailModel = userService.getAllPermissions();
		return listApplicationDetailModel;
	}

	/*
	 * This method will create the ACL and return the success message or error message . 
	 * 
	 *  @param RequestBody
	 *  		- UserACLDetailsModel from Request	  
	 *  @return responseModel
	 *  		-  CaviumResponseModel Object
	 */

	@RequestMapping(value="createACL", method = RequestMethod.POST)
	public final CaviumResponseModel createACL(
			@RequestBody  UserACLDetailsModel userAclDetailsModel )
	{
		CaviumResponseModel responseModel= getCaviumResponseModel();
		if(userAclDetailsModel.getAclName()!=null) {
		logger.info("Entered in createACL method");
		List<ACLRoleModel>	listACLrole = new ArrayList<ACLRoleModel>();
		userAclDetailsModel.setListACLRoleModel(listACLrole);
		userAclDetailsModel.setUsername(userAttributes.getlogInUserName());	
		responseModel=userService.createACL(userAclDetailsModel);
		logger.info("Entered of createACL method");
		}else {
			responseModel.setResponseCode("204");
			responseModel.setResponseMessage("userACL Name Empty");
			logger.error("userACL Name Empty");
		}
		logger.info("ResponseModel for createACL :: " + responseModel.toString());
		return responseModel;
	}


}
