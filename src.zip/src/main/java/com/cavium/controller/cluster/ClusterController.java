package com.cavium.controller.cluster;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.core.env.Environment;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.cluster.ClusterDetailModel;
import com.cavium.model.cluster.ClusterPartitionsRelationship;
import com.cavium.model.partition.PartitionDetailModel;
import com.cavium.pojo.UserAttributes;
import com.cavium.repository.cluster.ClusterRepository;
import com.cavium.repository.partition.PartitionRepository;
import com.cavium.repository.recentactivity.InProgressActivityRepository;
import com.cavium.service.cluster.ClusterService;
import com.cavium.service.partition.PartitionService;
import com.cavium.utill.CaviumResponseModel;

@RestController
@RequestMapping("rest")
public class ClusterController {

	@Autowired
	Environment env;



	@Autowired
	private UserAttributes userAttributes;

	@Autowired
	private PartitionService partitionService;

	@Autowired
	private InProgressActivityRepository inProgressActivityRepository;

	@Autowired
	private ClusterRepository clusterRepository;

	@Autowired
	private PartitionRepository partitionRepository;

	@Lookup
	public CaviumResponseModel getCaviumResponseModel() {
		return null;
	}


	@Autowired
	private ClusterService clusterService;

	private Logger logger = Logger.getLogger(this.getClass());



	@RequestMapping(value = "comparePartitionsDetails", method = RequestMethod.POST)
	public final ClusterDetailModel comparePartitionsDetails(@RequestBody ClusterDetailModel clusterPartitionsModel){
		try{
			logger.info("start of comparePartitionsDetails method  of ClusterController class");
			List<ClusterPartitionsRelationship> clusterPartitionsRelationships=new ArrayList<ClusterPartitionsRelationship>();
		 
			Integer maxKeys=null;	 
			String refpartitionName;
			Integer reftotalsslContext=null;
			String refFipState=null;
			String refApplianceName;
			Integer	refMaxAcclrDevCount=null;
			String mcoFixedKeyFingerprint=null;
			String mcoFixedKeyFingerprintAppName=null;
			for(ClusterPartitionsRelationship clusterPartitionsRel: clusterPartitionsModel.getClusterPartitionsRelationships())
			{
				Long partitionId=clusterPartitionsRel.getPartitionId();
				PartitionDetailModel pdm=partitionRepository.findOne(partitionId);
				 if(mcoFixedKeyFingerprint==null){
					 mcoFixedKeyFingerprint=pdm.getApplianceDetailModel().getMcoFixedKeyFingerprint();
					 mcoFixedKeyFingerprintAppName=pdm.getApplianceDetailModel().getApplianceName();
				 }
				 if(mcoFixedKeyFingerprint!=null && !(mcoFixedKeyFingerprint.equalsIgnoreCase(pdm.getApplianceDetailModel().getMcoFixedKeyFingerprint())))
				 {
					 clusterPartitionsModel.setCode("415");
					 clusterPartitionsModel.setErrorMessage("McoFixedKeyFingerprint for Appliance "+mcoFixedKeyFingerprintAppName+" is not matched with other Appliances.");
					 logger.error("McoFixedKeyFingerprint for Appliance "+mcoFixedKeyFingerprintAppName+" is not matched with other Appliances.");
					return clusterPartitionsModel; 
				 }
				
			}
			for(ClusterPartitionsRelationship clusterPartitionsRelationship: clusterPartitionsModel.getClusterPartitionsRelationships())
			{
				Long partitionId=clusterPartitionsRelationship.getPartitionId();
				if(partitionId!=null && clusterPartitionsRelationship.getApplianceId()==null && clusterPartitionsRelationship.getPartitionName()==null){
					PartitionDetailModel partitionDetailModel=partitionRepository.findOne(partitionId);
					String partitionName=partitionDetailModel.getPartitionName();
					Long applianceId=partitionDetailModel.getApplianceDetailModel().getApplianceId();
					clusterPartitionsRelationship.setApplianceId(applianceId);
					clusterPartitionsRelationship.setPartitionName(partitionName);		
				}
				clusterPartitionsRelationship=clusterService.comparePartitionsDetails(clusterPartitionsRelationship);
				if(clusterPartitionsRelationship.getPartitionData()!=null){
					if(clusterPartitionsRelationship.getPartitionData().getFipsState()!=null && clusterPartitionsRelationship.getPartitionData().getFipsState().replaceAll(" ","").contains("-1[zeroized]")){
						clusterPartitionsModel.setErrorMessage(clusterPartitionsRelationship.getPartitionName()+ " partition is not initialized. Please initilized first");
						clusterPartitionsModel.setCode("409");					 
						 if(clusterPartitionsModel.getClusterId()!=null){
							clusterPartitionsModel=clusterRepository.findOne(clusterPartitionsModel.getClusterId());
						}
						clusterPartitionsModel.setErrorMessage(clusterPartitionsRelationship.getPartitionName()+ " partition is not initialized. Please initilized first");
						clusterPartitionsModel.setCode("409");		
						return clusterPartitionsModel;
						} 
					 clusterPartitionsRelationships.add(clusterPartitionsRelationship);
				 }
				else{
					 if(clusterPartitionsModel.getClusterId()!=null){
						clusterPartitionsModel=clusterRepository.findOne(clusterPartitionsModel.getClusterId());
					}
					clusterPartitionsModel.setErrorMessage("Appliance Ip " +clusterPartitionsRelationship.getIpAddress() +" is not reachable.");
					logger.error("Appliance Ip " +clusterPartitionsRelationship.getIpAddress() +" is not reachable.");
					clusterPartitionsModel.setCode("409");
					return clusterPartitionsModel;	
				}
			}
		 
			List<Integer> nodeIdList= new ArrayList<Integer>();
			boolean isnodeIdSame=false;	
			for(ClusterPartitionsRelationship clusterPartitionsRel: clusterPartitionsModel.getClusterPartitionsRelationships())
			{
				
				Integer nodeId=Integer.parseInt(clusterPartitionsRel.getPartitionData().getNodeId());
				if(nodeId!=clusterPartitionsRel.getNodeId()){
				clusterPartitionsRel.setNodeId(nodeId);
				Long partitionId=clusterPartitionsRel.getPartitionId();
				partitionService.updateNodeIdforPartitionId(nodeId,partitionId);
				}
				if(nodeId!=null && nodeIdList.contains(nodeId))
				{
					isnodeIdSame=true;	
				}
				nodeIdList.add(nodeId);
			}
			if(isnodeIdSame){
			clusterPartitionsModel.setErrorMessage("NodeId for each partitions should be unique.");
			clusterPartitionsModel.setCode("409");
			return clusterPartitionsModel;
			}
			if(clusterPartitionsRelationships!=null && clusterPartitionsRelationships.size()>0){
				maxKeys=clusterPartitionsRelationships.get(0).getPartitionData().getMaxKeys();
				refFipState=clusterPartitionsRelationships.get(0).getPartitionData().getFipsState();			 
				reftotalsslContext=	clusterPartitionsRelationships.get(0).getPartitionData().getTotalSslCtxs();
				refMaxAcclrDevCount=clusterPartitionsRelationships.get(0).getPartitionData().getMaxAcclrDevCount();
				refpartitionName=clusterPartitionsRelationships.get(0).getPartitionData().getName();
				refApplianceName=clusterPartitionsRelationships.get(0).getApplianceName();
				 
				for(ClusterPartitionsRelationship clusterPartitionsRelationship :clusterPartitionsRelationships){				
					Integer compareMaxKeys=clusterPartitionsRelationship.getPartitionData().getMaxKeys();
					String compareFipsState=clusterPartitionsRelationship.getPartitionData().getFipsState();
					Integer totalsslContext=clusterPartitionsRelationship.getPartitionData().getTotalSslCtxs();
					Integer	maxAcclrDevCount=clusterPartitionsRelationship.getPartitionData().getMaxAcclrDevCount();
					if(refFipState!=null){
						if(!refFipState.equalsIgnoreCase(compareFipsState))
						{
							clusterPartitionsModel.setCode("409");
							clusterPartitionsModel.setErrorMessage("FipsStates of other partitions are not matched with "+ refpartitionName +" of Appliance "+refApplianceName);
							logger.error("FipsStates of partitions not matched with "+ refpartitionName);
							return clusterPartitionsModel;
						}
					}
					if(!maxKeys.equals(compareMaxKeys) || !reftotalsslContext.equals(totalsslContext) || !refMaxAcclrDevCount.equals(maxAcclrDevCount))
					{ 
						clusterPartitionsModel.setCode("415");
						clusterPartitionsModel.setErrorMessage("Partition details for other partitions are not matched with "+refpartitionName+" of Appliance "+refApplianceName +". Do you want to continue.?");
						logger.error("Partition data is not matched with "+refpartitionName+" for Appliance "+refApplianceName );
						return clusterPartitionsModel;
					}
				}
			} 
		}catch (Exception e) {
			logger.error("Some error is  coming in comparePartitionsDetails method  of ClusterController class :: "+e.getMessage());	 
		}
		logger.info("end of comparePartitionsDetails method  of ClusterController class");
		return clusterPartitionsModel;
	}

	@RequestMapping(value = "comparePartitionsAndCreateCluster", method = RequestMethod.POST)
	public final ClusterDetailModel comparePartitionsAndCreateCluster(@RequestBody ClusterDetailModel clusterPartitionsModel){
		clusterPartitionsModel=comparePartitionsDetails(clusterPartitionsModel);
		if(clusterPartitionsModel.getErrorMessage()==null&& clusterPartitionsModel.getCode()==null){
			logger.info("start of compareAndcreateCluster method  of ClusterController class");
			try{
				clusterPartitionsModel=clusterService.createCluster(clusterPartitionsModel);
			}catch (Exception e) {
				logger.error("some error is coming in comparePartitionsAndCreateCluster method  of ClusterController class :: "+e.getMessage());
			}		
		}
		logger.info("end of comparePartitionsAndCreateCluster method  of ClusterController class");
		return	clusterPartitionsModel;
	}

	@RequestMapping(value = "createCluster", method = RequestMethod.POST)
	public final ClusterDetailModel createCluster(@RequestBody ClusterDetailModel clusterPartitionsModel){

		logger.info("start of createCluster method  of ClusterController class");
		try{
			clusterPartitionsModel=clusterService.createCluster(clusterPartitionsModel);
			if(clusterPartitionsModel.getDeletedPartitionIds()!=null && clusterPartitionsModel.getDeletedPartitionIds().size()>0){
				clusterService.deletedPartitionIds(clusterPartitionsModel.getDeletedPartitionIds());
			}
		}catch (Exception e) {
			clusterPartitionsModel.setLastOperationPerformed("");
			clusterPartitionsModel.setLastOperationStatus("");
			clusterPartitionsModel.setMessage("Error coming while creating Cluster.");
			clusterPartitionsModel.setErrorMessage("Error coming while creating Cluster.");
			clusterPartitionsModel.setCode("415");
			logger.error("Some error is coming while calling  Rest API in createCluster method of ClusterServiceImpl class .." +e.getMessage());

		}		
		logger.info("end of createCluster method  of ClusterController class");
		return	clusterPartitionsModel;
	}

	@RequestMapping(value = "removePartitionsFromCluster", method = RequestMethod.DELETE)
	public final List<ClusterDetailModel> removePartitionsFromCluster(@RequestBody ClusterDetailModel clusterDetailModel){

		logger.info("start of removeCluster method  of ClusterController class");
		List<ClusterDetailModel> clusterDetailModels= new ArrayList<ClusterDetailModel>();

		try{
			clusterDetailModel=clusterService.removePartitionsFromCluster(clusterDetailModel);
			clusterDetailModels.add(clusterDetailModel);
		}catch (Exception e) {
			logger.error("some error is coming in removeCluster method  of ClusterController class :: "+e.getMessage());
		}


		logger.info("end of removeCluster method  of ClusterController class");
		return	clusterDetailModels;
	}

	@RequestMapping(value = "listClusters", method = RequestMethod.GET)
	public final  List<ClusterDetailModel> listOfClusters(){

		logger.info("start of listOfClusters method  of ClusterController class");
		List<ClusterDetailModel> clusterDetailModels= new ArrayList<ClusterDetailModel>();
		List<PartitionDetailModel> partitionsList= new ArrayList<>();
		try{
			String loggedInUser = userAttributes.getlogInUserName();
			clusterDetailModels=clusterService.listOfClusters(loggedInUser);
			for(ClusterDetailModel clusterDetailModel: clusterDetailModels)
			{
				//clusterDetailModel = clusterService.getPartitionsConnectivityDetails(clusterDetailModel);
				 for ( ClusterPartitionsRelationship clusterPartitionsRelationship : clusterDetailModel.getClusterPartitionsRelationships()){
					partitionsList.add(clusterPartitionsRelationship.getPartitionDetailModel());
				}
				partitionService.setObjectsInPartitionDetailModel(partitionsList);
			}
			inProgressActivityRepository.deleteInProgressActivityByStatus();
		}catch (Exception e) {
			logger.error("some error is coming in listOfClusters method  of ClusterController class :: "+e.getMessage());
		}		
		logger.info("end of listOfClusters method  of ClusterController class");
		
		return	clusterDetailModels;
	}



	@RequestMapping(value = "listOfNotAssignedPartitions", method = RequestMethod.GET)
	public List<PartitionDetailModel> getListOfNotAssignedPartitions() {

		List<PartitionDetailModel> listPartitions=new ArrayList<PartitionDetailModel>();
		try {
			String loggedInUser = userAttributes.getlogInUserName();
			listPartitions=partitionService.getListOfNotAssignedPartitions(loggedInUser);

		} catch (Exception e) {

			logger.error("Error occured during getListOfNotAssignedPartitions method of clusterController class :: "+e.getMessage());
		}
		return listPartitions;
	}

	@RequestMapping(value = "partitionsConnectivityDetails", method = RequestMethod.POST)
	public ClusterDetailModel getpartitionsConnectivityDetails(@RequestBody ClusterDetailModel clusterDetailModel) {

		try {
			List<PartitionDetailModel> partitionsList= new ArrayList<>();

			clusterDetailModel = clusterService.getPartitionsConnectivityDetails(clusterDetailModel);
			for ( ClusterPartitionsRelationship clusterPartitionsRelationship : clusterDetailModel.getClusterPartitionsRelationships()){
				partitionsList.add(clusterPartitionsRelationship.getPartitionDetailModel());
			}
			partitionService.setObjectsInPartitionDetailModel(partitionsList);

		} catch (Exception e) {
			logger.error("Error occured during partitionsConnectivityDetails method of clusterController class :: "+e.getMessage());
		}
		return clusterDetailModel;
	}

}
