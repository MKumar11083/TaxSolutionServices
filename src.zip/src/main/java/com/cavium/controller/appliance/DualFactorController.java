package com.cavium.controller.appliance;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.appliance.DualFactorModel;
import com.cavium.utill.CaviumUtil;
import com.cavium.utill.ResposeModel;
import com.cavium.utill.RestClient;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("rest")
public class DualFactorController {
	
	@Lookup
	public ResposeModel getCaviumResponseModel() {
		return null;
	}
	@Autowired
	RestClient restClient;
	
	@Autowired
	Environment env;
	
	private Logger logger = Logger.getLogger(this.getClass());
	@RequestMapping(value = "default/rebootAppliance", method = RequestMethod.POST)
	public final ResposeModel createAppliance(@RequestBody List<DualFactorModel> listOfDualFactorModel) throws KeyManagementException, KeyStoreException, NoSuchAlgorithmException {
		logger.info("rebootAppliance with the details:" + listOfDualFactorModel);
		ResposeModel responseModel=getCaviumResponseModel();
		try {
			for(DualFactorModel dual: listOfDualFactorModel) {
				if(!StringUtils.isEmpty(dual.getIpAddress())) {
						JSONObject body=new JSONObject(dual);
					    body.remove("ipAddress");
					    ResponseEntity<String>  response = restClient.invokePOSTMethodForOperations("https://"+dual.getIpAddress()+"/liquidsa/admin_vm_reboot",body);
					    if(response!=null && response.getBody()!=null && response.getBody().contains("success")) {
					    	responseModel.setCode(200);
					    	responseModel.setMessage("Appliance rebooted successfully.");
					    }else {
					    	responseModel=getErrorMessage(response);
					    }
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during reboot applaince inside DualFactorController"+e.getMessage());
			responseModel.setCode(000);
			responseModel.setMessage(e.getMessage());
		}
		return responseModel;
	}
	
	private  ResposeModel getErrorMessage(ResponseEntity<String>  response) {
		ResposeModel resposeModel=new ResposeModel();
		try {
			if(response.getBody()!=null) {
				ObjectMapper mapper = new ObjectMapper();
				JsonNode root = mapper.readTree(response.getBody());
				JsonNode errors = root.path("errors");
				if(root!=null){
					if(!root.isNull()) {
						if(response.getBody().contains("busy")) {
							String operation = root.path("operation").asText();
							resposeModel.setMessage("Appliance is busy due to operation "+operation+" is being performed");
							resposeModel.setCode(000);
							return resposeModel;
						}
						if(response.getBody().contains("errors")) {
							
							if(!errors.isNull() && errors.size() > 0){
								String operation = root.path("operation").asText();
								logger.info("Error size"+errors.size()+" is Array"+errors.isArray());
								StringBuilder sbmessage=new StringBuilder();
								StringBuilder sbcode=new StringBuilder();
								 Iterator<JsonNode> itr = errors.elements();	
						            while (itr.hasNext()) {
						                JsonNode temp = itr.next();
						                sbcode.append(""+temp.asInt()+"");
						                if(env.containsProperty(""+temp.asInt()+"")) {
						                	 sbmessage.append(env.getProperty(""+temp.asInt()+""));
						                }else {
						                	 sbmessage.append("Error message not available for "+operation+"");
						                }
						                sbcode.append(",");
						                sbmessage.append(",");
						            }
						            String message=sbmessage.toString();
						            message=message.substring(0, message.length()-1);
						            message=message+".";
						            String code=sbcode.toString();
						            code=code.substring(0, code.length()-1);
						            code=code+".";
						            resposeModel.setCode(Integer.parseInt(code));
						            resposeModel.setMessage(message);
							} else {
								String encodeMessage = "";
								if (errors.size() == 0) {
									encodeMessage = root.path("message").asText();
									encodeMessage = CaviumUtil.decodeMessageBase64(encodeMessage);
									resposeModel.setMessage(encodeMessage);
								}else {
									resposeModel.setMessage("No message found");
								}
							}
						}
					}
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during getErrorMessage"+e.getMessage());
		}
		return resposeModel;
	}

}
