package com.cavium.controller.recentactivity;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.model.recentactivity.RecentActivity;
import com.cavium.pojo.UserAttributes;
import com.cavium.service.recentactivity.RecentActivityService;
import com.cavium.utill.CaviumConstant;

@RestController
@RequestMapping("rest")
public class RecentActivityController {
	
	private Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	private RecentActivityService recentActivityService;
	
	@Autowired
	private UserAttributes userAttributes;
	
	 
	@RequestMapping(value = "recentActivitiesForAppliance", method = RequestMethod.GET)
	public List<RecentActivity> getRecentActivitiesForAppliance() {
		List<RecentActivity> recentActivity = null;
		logger.info("inside getRecentActivitiesForAppliance method");
		try {
			String loggedInUser = userAttributes.getlogInUserName();
			recentActivity=recentActivityService.getRecentActivity(loggedInUser,CaviumConstant.APPLIANCE_MANAGEMENT);
		} catch (Exception e) {
			logger.error("error occured during getRecentActivitiesForAppliance" + e.getMessage());
		}
		return recentActivity;
	}

	@RequestMapping(value = "recentActivitiesForPartition", method = RequestMethod.GET)
	public List<RecentActivity> getRecentActivitiesForPartition() {
		List<RecentActivity> recentActivity = null;
		logger.info("inside getRecentActivitiesForPartition method");
		try {
			String loggedInUser = userAttributes.getlogInUserName();
			recentActivity=recentActivityService.getRecentActivity(loggedInUser,CaviumConstant.PARTITION_MANAGEMENT);
		} catch (Exception e) {
			logger.error("error occured during recentActivitiesForPartition" + e.getMessage());
		}
		return recentActivity;
	}
	
	@RequestMapping(value = "recentActivityForNotification", method = RequestMethod.GET)
	public RecentActivity getRecentActivityForNotification() {
		RecentActivity recentActivity = null;
		logger.info("inside getRecentActivitiesForPartition method");
		try {
			String loggedInUser = userAttributes.getlogInUserName();
			recentActivity=recentActivityService.getRecentActivityForNotification(loggedInUser);
		} catch (Exception e) {
			logger.error("error occured during recentActivityForNotification" + e.getMessage());
		}
		return recentActivity;
	}
	 
}

