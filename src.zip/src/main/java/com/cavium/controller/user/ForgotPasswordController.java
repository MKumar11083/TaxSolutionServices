package com.cavium.controller.user;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.persistence.EntityNotFoundException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.mail.MailException;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cavium.mail.MailUtil;
import com.cavium.model.user.UserDetailModel;
import com.cavium.service.user.UserService;
import com.cavium.utill.CaviumResponseModel;
import com.cavium.utill.CaviumUtil;

/**
 * @author RK00490847
 * 
 */
@RestController
@RequestMapping("rest")
public class ForgotPasswordController {

	// logger - instance of application log.
	private Logger logger = Logger.getLogger(this.getClass());

	// userService - Service class provide the interface for the Repository Operation.
	@Autowired
	private UserService userService;
 
	@Autowired
	MailUtil mailutil;
 
	@Lookup
	public CaviumResponseModel getCaviumResponseModel() {
		return null;
	}

	// for Dynamic Messages
	@Autowired
	private ResourceBundleMessageSource messageSource;

	@RequestMapping(value = "forgotPassword", method = RequestMethod.POST)
	public final CaviumResponseModel forgotPassword(@RequestBody UserDetailModel userDetailModel) {
		CaviumResponseModel responseModel=getCaviumResponseModel();
		try{
		String userId = userDetailModel.getUserName();
		logger.info("User " + userId + " invoked the forgot password link");
		String newPassword = CaviumUtil.getRandomText(); 
		 responseModel=userService.forgotPassword(userId, null, newPassword);
		}
		catch(MailException exp){
			
			responseModel.setResponseCode("-230");
			String message=	messageSource.getMessage("forgotpassword.mail.fail", 
					new Object[] {}, Locale.US);
			responseModel.setResponseMessage(message);	
			 
		}
		catch(EntityNotFoundException exp){
			responseModel.setResponseCode("-230");
			String message="user does not exist";
			responseModel.setResponseMessage(message);
		}
		catch(Exception exp){		 
			responseModel.setResponseCode("-230");
		 String message=	messageSource.getMessage("forgotpassword.mail.fail", 
						new Object[] {}, Locale.US);
				responseModel.setResponseMessage(message);
				 
			
		}
		return responseModel;
	}
}
