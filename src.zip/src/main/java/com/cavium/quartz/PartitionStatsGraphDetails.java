package com.cavium.quartz;

/*
 * Created by RK00490847. For PartitionStatsGraphDetails Graphs for Partitions
 */

import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cavium.repository.partition.PartitionRepository;
import com.cavium.service.partition.PartitionService;


@Component
public class PartitionStatsGraphDetails implements Job {
 
	@Autowired
	private PartitionService partitionService;
	
	@Autowired
	private PartitionRepository partitionRepository;
	 
	
	private Logger logger = Logger.getLogger(this.getClass());
	
    public void execute(JobExecutionContext context) throws JobExecutionException {/*
    	logger.info("start of PartitionStatsGraphDetails Scheduler");
     	
    List<Integer> PartitionIds=	partitionRepository.getAllPartitions();
		try {
			
			for (Iterator<Integer> iterator = PartitionIds.iterator(); iterator.hasNext();) {
				Integer PartitionId = (Integer) iterator.next();
				if(PartitionId!=null) {
					partitionService.savePartitionStatsDetails(new Long(PartitionId));
			 }
			}
		} catch (Exception e) {
			logger.error("error while running PartitionStatsGraphDetails scheduler ::" +e.getMessage());
		}	
		logger.info("end of PartitionStatsGraphDetails Scheduler");
    */}
    
 
}