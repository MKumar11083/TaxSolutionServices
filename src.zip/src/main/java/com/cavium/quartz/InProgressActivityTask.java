package com.cavium.quartz;

import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.appliance.InitializeApplianceDetailModel;
import com.cavium.model.appliance.InitializeAppliancesRelationshipModel;
import com.cavium.model.cluster.ClusterDetailModel;
import com.cavium.model.partition.PartitionDetailModel;
import com.cavium.model.recentactivity.InProgressActivity;
import com.cavium.repository.appliance.ApplianceRepository;
import com.cavium.repository.appliance.DualFactorUsersRelationshipRepository;
import com.cavium.repository.appliance.InitializeAppliancesRelationshipReposiotry;
import com.cavium.repository.appliance.InitializeRepository;
import com.cavium.repository.cluster.ClusterPartitionsRelationshipRepository;
import com.cavium.repository.cluster.ClusterRepository;
import com.cavium.repository.partition.PartitionRepository;
import com.cavium.repository.recentactivity.InProgressActivityRepository;
import com.cavium.service.alerts.AlertsService;
import com.cavium.service.appliance.ApplianceService;
import com.cavium.service.recentactivity.RecentActivityServiceImpl;
import com.cavium.utill.CaviumConstant;
import com.cavium.utill.CaviumUtil;
import com.cavium.utill.RestClient;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class InProgressActivityTask implements Job {
	private Logger logger = Logger.getLogger(this.getClass());

	@Autowired
	private InProgressActivityRepository inProgressActivityRepository;
	@Autowired
	RestClient restClient;
	@Autowired
	private PartitionRepository partitionRepository;
	@Autowired
	private ClusterRepository clusterRepository;
	@Autowired 
	private ApplianceRepository applianceRepository;
	@Autowired
	Environment env;
	@Autowired
	private AlertsService alertsService;
	@Autowired
	private RecentActivityServiceImpl recentActivityServiceImpl;
	@Autowired
	private InitializeAppliancesRelationshipReposiotry initializeAppliancesRelationshipReposiotry;
	@Autowired
	private InitializeRepository initializeRepository;
	@Autowired
	private ApplianceService applianceService;
	@Autowired
	private ClusterPartitionsRelationshipRepository clusterPartitionsRelationshipRepository;
	@Autowired
	private DualFactorUsersRelationshipRepository dfUsersRelationshipRepository;

 

	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		// TODO Auto-generated method stub
		logger.info("Starting in-progress task");
		List<InProgressActivity> listInp=null;
		ResponseEntity<String> response=null;
		try {
			listInp=inProgressActivityRepository.getInProgressStatusList();
			if(listInp!=null && listInp.size() > 0) {
				for(InProgressActivity in: listInp) {
					boolean isIDAvailable=false;
					if(in.getApplianceID()!=null && in.getApplianceID() > 0) {
						ApplianceDetailModel app=applianceRepository.findOne(in.getApplianceID());
						if(app!=null) {
							isIDAvailable=true;
						}
					}if(in.getPartitionId()!=null && in.getPartitionId() > 0) {
						PartitionDetailModel pdm=partitionRepository.findOne(in.getPartitionId());
						if(pdm!=null) {
							isIDAvailable=true;
						}
					}if(in.getClusterId()!=null && in.getClusterId() > 0) {
						ClusterDetailModel cls=clusterRepository.findOne(in.getClusterId());
						if(cls!=null) {
							isIDAvailable=true;
						}
					}
					if(isIDAvailable) {
						logger.info("Inprogress activity starting for "+in.getId()+" for operation "+in.getOperationName()+"");
						try{
						 if(in.getJobId()!=null && in.getJobId()!=0 && !in.getOperationName().contains("Firmware")) {
							response=restClient.invokeGETMethod("https://"+in.getIpAddress()+"/liquidsa/notification/"+in.getJobId()+"");
							if(response!=null && response.getBody()!=null) {
								ObjectMapper mapper = new ObjectMapper();
								JsonNode root = mapper.readTree(response.getBody());
								if(!root.isNull()){							 
									if(!root.path("status").isNull() && root.path("status").asText().equals("success")) {
										logger.info("starting success block for in-progress activity for "+in.getId()+" for "+in.getOperationName()+"");
										PartitionDetailModel partitionDetailModel=null;
										in.setStatus("Completed");
										logger.info("...Response status coming as Success....");
										if(in.getPartitionId()!=null  && in.getPartitionId() > 0) {
										  logger.info("...Partition Id ...."+in.getPartitionId());
											  partitionDetailModel=partitionRepository.findOne(in.getPartitionId());
											  if(in.getOperationName()!=null && (in.getOperationName().equalsIgnoreCase("DeletePartition") || in.getOperationName().equalsIgnoreCase("CreatePartition") || in.getOperationName().equalsIgnoreCase("ResizePartition") || in.getOperationName().equalsIgnoreCase("ZeroizeHSM") || in.getOperationName().equalsIgnoreCase("InitHSM"))  ){
													ApplianceDetailModel applianceDetailModel =applianceService.updateApplianceDetails(partitionDetailModel.getApplianceDetailModel());
													applianceRepository.save(applianceDetailModel);
												}
											  logger.info("saving partition deatils for "+in.getId()+" for "+in.getOperationName()+"....");
												partitionDetailModel.setLastOperationStatus("Completed");
												partitionDetailModel.setLastOperationPerformed(in.getOperationName());
												partitionDetailModel.setErrorMessage("");
												partitionDetailModel.setCode("200");
												partitionRepository.save(partitionDetailModel);
												logger.info("ending save partition deatils for "+in.getId()+" for "+in.getOperationName()+"....");
											
											  
											if(in.getOperationName().equalsIgnoreCase("AddClusterNode")){
												logger.info("...Start of Add cluster Node Block....");	
												ClusterDetailModel cdm=	clusterRepository.findOne(in.getClusterId());
												 logger.info("...Cluster Details model...."+cdm);
												 recentActivityServiceImpl.createRecentActivity(in.getCreatedBy(), "Partition "+partitionDetailModel.getPartitionName()+" created successfully on cluster "+cdm.getClusterName()+" by" +in.getCreatedBy()+".",CaviumConstant.PARTITION_MANAGEMENT);
												int count=inProgressActivityRepository.allInprogressActivityCompletedorNot(in.getClusterId());
												if(count==1){										
												String	lastOperationStatus="Completed";
												String	lastOperationPerformed=in.getOperationName();
												String errorMessage="";
												Long clusterId=cdm.getClusterId();
												clusterRepository.updateClusterDetails(lastOperationStatus,lastOperationPerformed ,errorMessage,clusterId);
												cdm.setCode("200");											
											 logger.info("...end of Add cluster Node Block....");	
											}
										}
											 if(in.getOperationName().equalsIgnoreCase("RemoveClusterNode")){
											logger.info("...Start of remove cluster node Block....");
											boolean partOfCluster=false;										
											if(in.isPartitionDeleted()){
												partitionRepository.updatePartOfCluster(partOfCluster,in.getPartitionId());
												clusterPartitionsRelationshipRepository.deletePartitionFromCluster(in.getPartitionId());
											}
											ClusterDetailModel cdm=	clusterRepository.findOne(in.getClusterId());
											logger.info("...Cluster Detail Model...."+cdm);
											int count=inProgressActivityRepository.allInprogressActivityCompletedorNot(in.getClusterId());
											if(count==1){										
												String	lastOperationStatus="Completed";
												String	lastOperationPerformed=in.getOperationName();
												String errorMessage="";
												if(cdm!=null) {
												Long clusterId=cdm.getClusterId();
												logger.info("...Cluster Id ...."+clusterId);
												clusterRepository.updateClusterDetails(lastOperationStatus,lastOperationPerformed ,errorMessage,clusterId);
												cdm.setCode("200");	
												}
										  	 }
											 if(cdm!=null && cdm.getClusterPartitionsRelationships()!=null && (cdm.getClusterPartitionsRelationships().size()==0)){
												int pendingRequestCount=clusterRepository.getPendingRequestCount(in.getClusterId());
												if(pendingRequestCount==1){
												clusterRepository.delete(cdm);
												}
												}
												if(cdm!=null) {
												partitionDetailModel.setMessage("Partition " + partitionDetailModel.getPartitionName() +" deleted successfully from cluster "+cdm.getClusterName()+".");
												}
												else {
													partitionDetailModel.setMessage("Partition " + partitionDetailModel.getPartitionName() +" deleted successfully from cluster.");
													}
											 
											}
											
											
											logger.error("....ending of Remove cluster block..."); 
											if(partitionDetailModel.getApplianceDetailModel()!=null){
												Long applianceId= partitionDetailModel.getApplianceDetailModel().getApplianceId();
												int numberOfpartitions=partitionRepository.getNumberofInprogressPartitions(applianceId);
												if(numberOfpartitions==0){
													boolean grayedOut=false;
												partitionRepository.updateGrayedOut(grayedOut, applianceId);
												applianceRepository.updateGrayedOut(grayedOut, applianceId);	
												logger.info("...update Status to Actual Status....");
													}							
											}
											
											if(in.getOperationName()!=null && in.getOperationName().equalsIgnoreCase("DeletePartition")) {
												applianceService.deletePartitionData(partitionDetailModel,in.getCreatedBy(),in.getOperationName());								
												 logger.info("...Delete partition Data....");
											}
											
											
											if(!in.getOperationName().equalsIgnoreCase("AddClusterNode")){
												recentActivityServiceImpl.createRecentActivity(in.getCreatedBy(), ""+in.getOperationName()+" performed on "+partitionDetailModel.getPartitionName()+" by "+in.getCreatedBy()+".",CaviumConstant.PARTITION_MANAGEMENT);
												}
										}
										
										if(in.getApplianceID()!=null && in.getApplianceID() > 0) {
											
											ApplianceDetailModel app=applianceRepository.findOne(in.getApplianceID());
											
											  if(in.getOperationName()!=null && (in.getOperationName().equalsIgnoreCase("ZeroizeHSM") || in.getOperationName().equalsIgnoreCase("InitHSM"))  ){
													ApplianceDetailModel applianceDetailModel =applianceService.updateApplianceDetails(app);
													applianceRepository.save(applianceDetailModel);
												}
											if(in.getOperationName()!=null && in.getOperationName().equalsIgnoreCase("ZeroizeHSM"))
											{
												logger.info("starting for ZeroizeHSM for "+in.getId()+" for "+in.getOperationName()+" ");
												
												applianceService.deletePartitionsAndInitializeFromDB(app,in.getCreatedBy(),in.getOperationName());
												applianceRepository.updateApplianceStatus(false,false,false,false,in.getApplianceID());
											    dfUsersRelationshipRepository.deleteDfDetailsAgainstAppliance(app.getApplianceId());
												logger.info("ending for ZeroizeHSM for "+in.getId()+" for "+in.getOperationName()+"");
											}
											else{
												app.setLastOperationStatus("Completed");
												app.setLastOperationPerformed(in.getOperationName());
												app.setErrorMessage("");
												app.setCode("200");
												applianceRepository.save(app);
											}
											recentActivityServiceImpl.createRecentActivity(in.getCreatedBy(), ""+in.getOperationName()+" performed on Device "+app.getApplianceName()+" by "+in.getCreatedBy()+".",CaviumConstant.APPLIANCE_MANAGEMENT);
										 
											Long applianceId=in.getApplianceID();										
											int numberOfpartitions=partitionRepository.getNumberofInprogressPartitions(applianceId);
											if(numberOfpartitions==0){
											boolean grayedOut=false;
											partitionRepository.updateGrayedOut(grayedOut, applianceId);	
												}
											if(in.getOperationName()!=null && in.getOperationName().equalsIgnoreCase("systemReboot")){
											dfUsersRelationshipRepository.deleteDfDetailsAgainstAppliance(in.getApplianceID());
											}
										 }
										
										
										logger.info("ending success block for in-progress activity.");
										
									}else {
										logger.info("starting error block for in-progress activity.");
										if(!root.path("status").isNull() && (root.path("status").asText().equals("error") || root.path("status").asText().equals("warning"))) {
											in.setStatus("Failed");
											logger.info("...Response status coming as Error or Warning....");
											if(in.getPartitionId()!=null && in.getPartitionId() > 0) {
												PartitionDetailModel partitionDetailModel=partitionRepository.findOne(in.getPartitionId());
												if(in.getOperationName().equalsIgnoreCase("AddClusterNode")){
													logger.info("...Start of AddClusterNode in error block......");
													partitionDetailModel.setLastOperationStatus("Failed");
													partitionDetailModel.setLastOperationPerformed(in.getOperationName());							
													partitionDetailModel=getErrorMessageForPartition(response, partitionDetailModel);
													in.setStatus("Failed");
													partitionRepository.save(partitionDetailModel);
													logger.info("...Partition Detail model Save......");
													if(in.isPartitionAdded()){
													clusterPartitionsRelationshipRepository.deletePartitionFromCluster(in.getPartitionId());
													boolean partOfCluster=false;
													partitionRepository.updatePartOfCluster(partOfCluster,in.getPartitionId());	
													}
													ClusterDetailModel cdm=	clusterRepository.findOne(in.getClusterId());
													int count=inProgressActivityRepository.allInprogressActivityCompletedorNot(in.getClusterId());
													if(cdm!=null){
														alertsService.createAlert(cdm.getCreatedBy(),"Partition "+partitionDetailModel.getPartitionName()+" creation on cluster "+cdm.getClusterName() +" by "+cdm.getCreatedBy()+" did not complete due to "+partitionDetailModel.getErrorMessage()+".",cdm.getClusterName(),in.getPartitionId(),CaviumConstant.PARTITION_MANAGEMENT);
													}
													 logger.info("...updatePart ofcluster in partition......");
													if(count==1){
														int partitionsCount=clusterPartitionsRelationshipRepository.getNumberOfPartitionForCluster(in.getClusterId());
														if(partitionsCount==0){
															if(cdm!=null){
																int pendingRequestCount=clusterRepository.getPendingRequestCount(in.getClusterId());
																if(pendingRequestCount==1){
														clusterRepository.delete(cdm);
														logger.info("...Delete cluster......");
															}
														}
														}else{
															if(cdm!=null){
																String	lastOperationStatus="Completed";
																String	lastOperationPerformed=in.getOperationName();
																String errorMessage="";
																Long clusterId=cdm.getClusterId();
																clusterRepository.updateClusterDetails(lastOperationStatus,lastOperationPerformed ,errorMessage,clusterId);
														 
															cdm.setCode("200");
															}
														}
													 }
											  logger.info("...End of AddClusterNode in error block......");
												}
												if(!in.getOperationName().equalsIgnoreCase("AddClusterNode")){
												partitionDetailModel.setLastOperationStatus("Failed");
												partitionDetailModel.setLastOperationPerformed(in.getOperationName());
												partitionDetailModel=getErrorMessageForPartition(response, partitionDetailModel);
												in.setStatus("Failed");
												partitionRepository.save(partitionDetailModel);
												 if(in.getOperationName().equalsIgnoreCase("RemoveClusterNode")){
														logger.info("...Start of RemoveClusterNode in error block......");
														partitionDetailModel.setMessage("");		
														int count=inProgressActivityRepository.allInprogressActivityCompletedorNot(in.getClusterId());
														ClusterDetailModel cdm=	clusterRepository.findOne(in.getClusterId());
														logger.info("...ClusterDetail model error block......"+cdm);
														if(count==1){
															String	lastOperationStatus="Completed";
															String	lastOperationPerformed=in.getOperationName();
															String errorMessage="";
															Long clusterId=cdm.getClusterId();
															clusterRepository.updateClusterDetails(lastOperationStatus,lastOperationPerformed ,errorMessage,clusterId);
															cdm.setCode("200");
														}
														partitionRepository.save(partitionDetailModel);			 
													}
													
												
												if(in.getOperationName()!=null && !in.getOperationName().equalsIgnoreCase("CreatePartition")) {
													alertsService.createAlert(partitionDetailModel.getCreatedBy(),""+in.getOperationName()+" "+partitionDetailModel.getPartitionName()+" of "+partitionDetailModel.getApplianceDetailModel().getApplianceName()+" by "+partitionDetailModel.getCreatedBy()+" failed due to "+partitionDetailModel.getErrorMessage()+".",partitionDetailModel.getPartitionName(),partitionDetailModel.getPartitionId(),CaviumConstant.PARTITION_MANAGEMENT);
												}
												}
												if(partitionDetailModel.getApplianceDetailModel()!=null){											
													Long applianceId= partitionDetailModel.getApplianceDetailModel().getApplianceId();											
													 int numberOfpartitions=partitionRepository.getNumberofInprogressPartitions(applianceId);
													if(numberOfpartitions==0){
													 boolean grayedOut=false;
													partitionRepository.updateGrayedOut(grayedOut, applianceId);
													applianceRepository.updateGrayedOut(grayedOut, applianceId);
													logger.info("...update Status to actual Status......");
													}											
													}		
												if(in.getOperationName()!=null && in.getOperationName().equalsIgnoreCase("CreatePartition")) {
													alertsService.createAlert(partitionDetailModel.getCreatedBy(),""+in.getOperationName()+" performed on "+partitionDetailModel.getPartitionName()+" by "+partitionDetailModel.getCreatedBy()+" did not "+in.getOperationName()+" due to "+partitionDetailModel.getErrorMessage()+".",partitionDetailModel.getPartitionName(),null,CaviumConstant.PARTITION_MANAGEMENT);
													logger.info("...Start of deletePartitionData in error block......");
													applianceService.deletePartitionData(partitionDetailModel,in.getCreatedBy(),in.getOperationName());
													logger.info("...End of deletePartitionData in error block......");
												}		
											}if(in.getApplianceID() !=null && in.getApplianceID() > 0) {
												ApplianceDetailModel app=applianceRepository.findOne(in.getApplianceID());
												
												app=getErrorMessageForAppliance(response, app);
												app.setLastOperationStatus("Failed");
												app.setLastOperationPerformed(in.getOperationName());
												applianceRepository.save(app);
												alertsService.createAlert(app.getCreatedBy(),""+in.getOperationName()+" performed on "+app.getApplianceName()+" by "+app.getCreatedBy()+" did not "+in.getOperationName()+" due to "+app.getErrorMessage()+".",app.getApplianceName(),app.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
												in.setStatus("Failed");
												if(in.getOperationName()!=null && in.getOperationName().equalsIgnoreCase("InitHSM")) {
													InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(app.getApplianceId());
													InitializeApplianceDetailModel init=initializeRepository.findOne(initmodel.getInitializeId());
													initializeAppliancesRelationshipReposiotry.delete(initmodel);
													initializeRepository.delete(init);
												    dfUsersRelationshipRepository.deleteDfDetailsAgainstAppliance(app.getApplianceId());
													app.setApplianceinitialized(false);
													app.setApplianceDualFactorInitialized(false);
													app.setCredentialSaved(false);
													applianceRepository.save(app);
												}
											 
												Long applianceId=in.getApplianceID();
												int numberOfpartitions=partitionRepository.getNumberofInprogressPartitions(applianceId);
													if(numberOfpartitions==0){
													 boolean grayedOut=false;
												partitionRepository.updateGrayedOut(grayedOut, applianceId);		
													}
											 }
										}
										logger.info("ending error block for in-progress activity.");
									}
									
									
								}
							}
						}else {
							if(in.getJobId()!=null && in.getJobId()==0) {
								logger.info("...Start of JobIb Zero block......");
								if(!in.getOperationName().contains("Firmware")) {
									
									response=restClient.invokeGETMethod("https://"+in.getIpAddress()+"/liquidsa/notification");
									
									if(response!=null && response.getBody()!=null) {
										ObjectMapper mapper = new ObjectMapper();
										JsonNode root = mapper.readTree(response.getBody());
										if(!root.isNull()){
											
											if(!root.path("status").isNull() && root.path("status").asText().equals("success")) {
												logger.info("...starting for of jobid zero block......");
												in.setStatus("Completed");
												if(in.getPartitionId()!=null  && in.getPartitionId() > 0) {
													PartitionDetailModel partitionDetailModel=partitionRepository.findOne(in.getPartitionId());
													partitionDetailModel.setErrorMessage("");
													partitionDetailModel.setCode("200");
													partitionDetailModel.setLastOperationStatus("Completed");
													partitionDetailModel.setLastOperationPerformed(in.getOperationName());
													partitionRepository.save(partitionDetailModel);
													recentActivityServiceImpl.createRecentActivity(in.getCreatedBy(), ""+in.getOperationName()+" performed on "+partitionDetailModel.getPartitionName()+" by "+in.getCreatedBy()+".",CaviumConstant.PARTITION_MANAGEMENT);
													 
														if(partitionDetailModel.getApplianceDetailModel()!=null){
															 
															Long applianceId= partitionDetailModel.getApplianceDetailModel().getApplianceId();
															int numberOfpartitions=partitionRepository.getNumberofInprogressPartitions(applianceId);
																if(numberOfpartitions==0){
																 boolean grayedOut=false;
															partitionRepository.updateGrayedOut(grayedOut, applianceId);
															applianceRepository.updateGrayedOut(grayedOut, applianceId);
																}
														  }											
												}if(in.getApplianceID()!=null && in.getApplianceID() > 0) {
													ApplianceDetailModel app=applianceRepository.findOne(in.getApplianceID());
													app.setCode("200");
													app.setLastOperationPerformed(in.getOperationName());
													app.setLastOperationStatus("Completed");
													applianceRepository.save(app);
													recentActivityServiceImpl.createRecentActivity(in.getCreatedBy(), ""+in.getOperationName()+" performed on "+app.getApplianceName()+" by "+in.getCreatedBy()+".",CaviumConstant.APPLIANCE_MANAGEMENT);
													Long applianceId=in.getApplianceID();
													int numberOfpartitions=partitionRepository.getNumberofInprogressPartitions(applianceId);
														if(numberOfpartitions==0){
														 boolean grayedOut=false;
														 partitionRepository.updateGrayedOut(grayedOut, applianceId);
														}	
														if(in.getOperationName()!=null && in.getOperationName().equalsIgnoreCase("systemReboot")){
															dfUsersRelationshipRepository.deleteDfDetailsAgainstAppliance(in.getApplianceID());
															}
												}
												logger.info("...ending for of jobid zero block......");
												
											}else {
												logger.info("...starting error block for of jobid zero......");
												if(!root.path("status").isNull() && (root.path("status").asText().equals("error") || root.path("status").asText().equals("warning"))) {
													logger.info("...inside error block for of jobid zero......");
													if(in.getPartitionId()!=null && in.getPartitionId() > 0) {
														
														PartitionDetailModel partitionDetailModel=partitionRepository.findOne(in.getPartitionId());
														partitionDetailModel.setLastOperationStatus("Failed");
														partitionDetailModel.setLastOperationPerformed(in.getOperationName());
														partitionDetailModel=getErrorMessageForPartition(response, partitionDetailModel);
														in.setStatus("Failed");
														partitionRepository.save(partitionDetailModel);
														
														alertsService.createAlert(partitionDetailModel.getCreatedBy(), 
																 ""+in.getOperationName()+" performed on "+partitionDetailModel.getPartitionName()+" by "+partitionDetailModel.getCreatedBy()+" by "+partitionDetailModel.getCreatedBy()+" did not perfomed "+in.getOperationName()+" due to "+partitionDetailModel.getErrorMessage()+".",partitionDetailModel.getPartitionName(),partitionDetailModel.getPartitionId(),CaviumConstant.PARTITION_MANAGEMENT);
														if(partitionDetailModel.getApplianceDetailModel()!=null){
														Long applianceId= partitionDetailModel.getApplianceDetailModel().getApplianceId();
															 int numberOfpartitions=partitionRepository.getNumberofInprogressPartitions(applianceId);
																if(numberOfpartitions==0){
																 boolean grayedOut=false;
																 partitionRepository.updateGrayedOut(grayedOut, applianceId);
																 applianceRepository.updateGrayedOut(grayedOut, applianceId);
																}
														}											
														
													}if(in.getApplianceID() !=null && in.getApplianceID() > 0) {
														
														ApplianceDetailModel app=applianceRepository.findOne(in.getApplianceID());
														app.setLastOperationPerformed(in.getOperationName());
														app.setLastOperationStatus("Failed");
														app=getErrorMessageForAppliance(response, app);
														applianceRepository.save(app);
														alertsService.createAlert(app.getCreatedBy(),""+in.getOperationName()+" performed on "+app.getApplianceName()+" by "+app.getCreatedBy()+" did not "+in.getOperationName()+".",app.getApplianceName(),app.getApplianceId(),CaviumConstant.APPLIANCE_MANAGEMENT);
														in.setStatus("Failed");
														
														if(in.getOperationName()!=null && in.getOperationName().equalsIgnoreCase("InitHSM")) {
															InitializeAppliancesRelationshipModel initmodel = initializeAppliancesRelationshipReposiotry.getInitializeIdByApplianceId(app.getApplianceId());
															InitializeApplianceDetailModel init=initializeRepository.findOne(initmodel.getInitializeId());
															initializeAppliancesRelationshipReposiotry.delete(initmodel);
															initializeRepository.delete(init);
															dfUsersRelationshipRepository.deleteDfDetailsAgainstAppliance(app.getApplianceId());
															app.setApplianceDualFactorInitialized(false);
															app.setApplianceinitialized(false);
															app.setCredentialSaved(false);
															applianceRepository.save(app);
														}
												 
														Long applianceId=in.getApplianceID();
														 if(applianceId!=null) {
															int numberOfpartitions=partitionRepository.getNumberofInprogressPartitions(applianceId);
															if(numberOfpartitions==0){
															 boolean grayedOut=false;
															partitionRepository.updateGrayedOut(grayedOut, applianceId);
															}
															 
														}
													}
													logger.info("...ending error block for of jobid zero......");
												}
											}
										}
									}
								}
								
							}
						}
						 inProgressActivityRepository.save(in);
						}catch(Exception exp){
							logger.error("Error occured during iteration on inprogress task for "+in.getId()+" for operation "+in.getOperationName()+""+exp.getMessage());
							in.setStatus("Failed");
							inProgressActivityRepository.save(in);
							if(in.getApplianceID()!=null && in.getApplianceID() > 0 && in.getPartitionId()!=null && in.getPartitionId() > 0) {
								alertsService.createAlert(in.getCreatedBy(),""+in.getOperationName()+" performed on "+in.getPartitionName()+" by "+in.getCreatedBy()+" did not "+in.getOperationName()+" due to "+exp.getMessage()+".",in.getPartitionName(),in.getPartitionId(),CaviumConstant.PARTITION_MANAGEMENT);
							}else {
								if(in.getClusterId()!=null && in.getClusterId() > 0) {
									ClusterDetailModel cdm=	clusterRepository.findOne(in.getClusterId());
									if(cdm!=null){
									alertsService.createAlert(cdm.getCreatedBy(),"Partition "+in.getPartitionName()+" creation on cluster "+cdm.getClusterName() +" by "+cdm.getCreatedBy()+" did not complete due to "+exp.getMessage()+".",cdm.getClusterName(),in.getPartitionId(),CaviumConstant.PARTITION_MANAGEMENT);
										}	
									}else {
										if(in.getApplianceID()!=null && in.getApplianceID() > 0 && in.getPartitionId()==null) {
											alertsService.createAlert(in.getCreatedBy(),""+in.getOperationName()+" performed on "+in.getApplianceName()+" by "+in.getCreatedBy()+" did not "+in.getOperationName()+".",in.getApplianceName(),in.getApplianceID(),CaviumConstant.APPLIANCE_MANAGEMENT);
										}
								}
							}
						}
						logger.info("Sending loop for "+in.getId()+" for operation "+in.getOperationName()+"");
					}else {
						if(in.getClusterId()!=null && in.getClusterId() > 0) {
							ClusterDetailModel cdm=	clusterRepository.findOne(in.getClusterId());
							if(cdm!=null){
							     alertsService.createAlert(cdm.getCreatedBy(),"Partition "+in.getPartitionName()+" creation on cluster "+cdm.getClusterName() +" by "+cdm.getCreatedBy()+" did not complete due to id not exists in the system.",cdm.getClusterName(),in.getPartitionId(),CaviumConstant.PARTITION_MANAGEMENT);
								}	
							}else {
								if(in.getApplianceID()!=null && in.getApplianceID() > 0) {
									alertsService.createAlert(in.getCreatedBy(),""+in.getOperationName()+" performed on "+in.getApplianceName()+" by "+in.getCreatedBy()+" did not "+in.getOperationName()+".",in.getApplianceName(),in.getApplianceID(),CaviumConstant.APPLIANCE_MANAGEMENT);
								}
								if(in.getPartitionId()!=null  && in.getPartitionId() > 0) {
									alertsService.createAlert(in.getCreatedBy(),""+in.getOperationName()+" performed on "+in.getPartitionName()+" by "+in.getCreatedBy()+" did not "+in.getOperationName()+".",in.getApplianceName(),in.getApplianceID(),CaviumConstant.APPLIANCE_MANAGEMENT);
								}
							}
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error occured in-progress task :: "+e.getMessage());

		}
		logger.info("Ending in-progress task..");
	}

	/**
	 * This method is used for error handling for partition management
	 * @param partitionDetailModel
	 * @param root
	 * @return
	 */
	private PartitionDetailModel getErrorMessageForPartition(ResponseEntity<String> response,PartitionDetailModel partitionDetailModel) {
		try {

			if(response==null) {
				partitionDetailModel.setErrorMessage(env.getProperty("partition.applainceinternalerror.cavium"));
			}

			if(response!=null && response.getStatusCodeValue()== 408){
				partitionDetailModel.setErrorMessage(env.getProperty("partition.connectionerror.cavium"));
			}

			if(response.getBody()!=null) {
				ObjectMapper mapper = new ObjectMapper();
				JsonNode root = mapper.readTree(response.getBody());
				if(root!=null){
					if(!root.isNull()) {
						if(response.getBody().contains("busy")) {
							String operation = root.path("operation").asText();
							partitionDetailModel.setLastOperationPerformed(operation);
							partitionDetailModel.setErrorMessage("Appliance is busy due to operation "+operation+" is being performed on partition "+partitionDetailModel.getPartitionName()+".");
						}
						if(response.getBody().contains("errors")) {
							JsonNode errors = root.path("errors");
							String operation = root.path("operation").asText();
							if(!errors.isNull() && errors.size() > 0){
								logger.info("Error size from Cavium Rsponse :: "+errors.size()+" is Array "+errors.isArray());
								StringBuilder sbmessage=new StringBuilder();
								StringBuilder sbcode=new StringBuilder();
								Iterator<JsonNode> itr = errors.elements();	
								while (itr.hasNext()) {
									JsonNode temp = itr.next();
									sbcode.append(""+temp.asInt()+"");
									if(env.containsProperty(""+temp.asInt()+"")) {
										sbmessage.append(env.getProperty(""+temp.asInt()+""));
									}else {
										sbmessage.append("Error message not available");
									}
									sbcode.append(",");
									sbmessage.append(",");
								}
								String message=sbmessage.toString();
								message=message.substring(0, message.length()-1);
								message=message+".";
								String code=sbcode.toString();
								code=code.substring(0, code.length()-1);
								code=code+".";
								partitionDetailModel.setLastOperationPerformed(operation);
								partitionDetailModel.setErrorMessage(message);
							}else {
								String encodeMessage = "";
								if (errors.size() == 0) {
									encodeMessage = root.path("message").asText();
									encodeMessage = CaviumUtil.decodeMessageBase64(encodeMessage);
									partitionDetailModel.setCode("");
									partitionDetailModel.setMessage(encodeMessage);
								}else {
									partitionDetailModel.setCode("");
									partitionDetailModel.setMessage("No message found");
								}
							}
						}
					}
				}
			}
		} catch (Exception e) {
			 logger.error("Error occured while setting error code and message.." +e.getMessage());
		}
		return partitionDetailModel;
	}


	private ApplianceDetailModel getErrorMessageForAppliance(ResponseEntity<String> response,ApplianceDetailModel applianceDetailModel) {
		try {

			if(response==null) {
				applianceDetailModel.setErrorMessage(env.getProperty("appliance.applainceinternalerror.cavium"));
			}

			if(response!=null && response.getStatusCodeValue()== 408){
				applianceDetailModel.setErrorMessage(env.getProperty("appliance.connectionerror.cavium"));
			}

			if(response.getBody()!=null) {
				ObjectMapper mapper = new ObjectMapper();
				JsonNode root = mapper.readTree(response.getBody());
				if(root!=null){
					if(!root.isNull()) {
						if(response.getBody().contains("busy")) {
							String operation = root.path("operation").asText();
							applianceDetailModel.setLastOperationPerformed(operation);
							applianceDetailModel.setErrorMessage(""+applianceDetailModel.getApplianceName()+" is busy due to operation "+operation+" is being performed");
						}
						if(response.getBody().contains("errors")) {
							JsonNode errors = root.path("errors");
							String operation = root.path("operation").asText();
							if(!errors.isNull() && errors.size() > 0){
								logger.info("Error size"+errors.size()+" is Array"+errors.isArray());
								StringBuilder sbmessage=new StringBuilder();
								StringBuilder sbcode=new StringBuilder();
								Iterator<JsonNode> itr = errors.elements();	
								while (itr.hasNext()) {
									JsonNode temp = itr.next();
									sbcode.append(""+temp.asInt()+"");
									if(env.containsProperty(""+temp.asInt()+"")) {
										sbmessage.append(env.getProperty(""+temp.asInt()+""));
									}else {
										sbmessage.append("Error message not available");
									}
									sbcode.append(",");
									sbmessage.append(",");
								}
								String message=sbmessage.toString();
								message=message.substring(0, message.length()-1);
								message=message+".";
								String code=sbcode.toString();
								code=code.substring(0, code.length()-1);
								code=code+".";
								applianceDetailModel.setLastOperationPerformed(operation);
								applianceDetailModel.setErrorMessage(message);
							}else {
								String encodeMessage = "";
								if (errors.size() == 0) {
									encodeMessage = root.path("message").asText();
									encodeMessage = CaviumUtil.decodeMessageBase64(encodeMessage);
									applianceDetailModel.setCode("");
									applianceDetailModel.setMessage(encodeMessage);
								}else {
									applianceDetailModel.setCode("");
									applianceDetailModel.setMessage("No message found");
								}
							}
						}
					}
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured while setting error code and message..");
		}
		return applianceDetailModel;
	}

}
