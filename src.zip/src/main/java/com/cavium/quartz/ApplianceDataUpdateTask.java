package com.cavium.quartz;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.appliance.StoreType;
import com.cavium.model.partition.PartitionDetailModel;
import com.cavium.repository.appliance.ApplianceRepository;
import com.cavium.repository.partition.PartitionDataRepository;
import com.cavium.repository.partition.PartitionRepository;
import com.cavium.service.appliance.ApplianceService;
import com.cavium.service.partition.PartitionService;
import com.cavium.utill.RestClient;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class ApplianceDataUpdateTask implements Job {
	
	private Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	RestClient restClient;
	@Autowired
	private PartitionRepository partitionRepository;
	@Autowired 
	private ApplianceRepository applianceRepository;
	@Autowired
	private ApplianceService applianceService;
	@Autowired
	Environment env;
	@Autowired
	private PartitionService partitionService;
	@Autowired
	private PartitionDataRepository partitionDataRepository;
	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		// TODO Auto-generated method stub
		try {
				
			logger.info("Appliance data update job start............");
			List<ApplianceDetailModel> applianceList=applianceRepository.getAllListOfAppliances(StoreType.PERMANENT);
			if(applianceList!=null && applianceList.size() > 0) {
				for(ApplianceDetailModel app: applianceList) {
					if(app.isGrayedOut() == false && !StringUtils.isEmpty(app.getLastOperationStatus()) && !app.getLastOperationStatus().equalsIgnoreCase("In-Progress")) {
						ResponseEntity<String> response=restClient.invokeGETMethod("https://"+app.getIpAddress()+"/liquidsa/info");
						if(response!=null && response.getBody()!=null && response.getBody().contains("success")) {
							app.setApplianceStatus("Active");
							app.setPingCount(0);
							if(!StringUtils.isEmpty(app.getIpAddress())) {
								try {
									applianceService.updateApplianceInfo(app);
								} catch (Exception e) {
									// TODO: handle exception
									logger.error("Error occured during update appliance details from appliance data update job.."+e.getMessage());
								}
							}
							if(app.getApplianceId()!=null) {
								List<PartitionDetailModel> partitionDetailList=partitionRepository.getListOfPartitionByApplianceID(Long.valueOf(app.getApplianceId()));
								if(partitionDetailList!=null && partitionDetailList.size() > 0) {
									for(PartitionDetailModel pdm:partitionDetailList) {
										try {
											/**
											  Update network config details
											 */
											
											partitionService.getPartitionNetworkStatsInfo(pdm);
											  
											/**
											   * Update partition data
											   */
											  
										
											partitionService.updatePartitionData(pdm);
											
											} catch (Exception e) {
											// TODO: handle exception
												logger.error("Error occured during parittion data update task");
											}
										}
									}
								}
							}else {
								int count= 0;
								if(app.getPingCount()!=null) {
									count=app.getPingCount();
								}
								if(count > 2) {
									app.setPingCount(0);
									app.setApplianceStatus("Inactive");
									if(app.getApplianceId()!=null) {
										List<PartitionDetailModel> partitionDetailList=partitionRepository.getListOfPartitionByApplianceID(Long.valueOf(app.getApplianceId()));
										if(partitionDetailList!=null && partitionDetailList.size() > 0) {
											for(PartitionDetailModel pdm:partitionDetailList) {
												try {
													partitionDataRepository.updateFipsStatus("5[Inactive]", pdm.getPartitionId());
												}catch (Exception e) {
													// TODO: handle exception
													logger.error("Error occured during partition inactive");
												}
											}
										}
									}
								}else {
									app.setPingCount(count+1);	
								}
								applianceRepository.save(app);
							}
					}
				}
				}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Error occured during data update in ApplianceDataUpdateJob scheduler.."+e.getMessage());
		}finally {
			logger.info("Appliance data update job end............");
		}
	}
	
}
