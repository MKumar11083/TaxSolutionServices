package com.cavium.oauth.config;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.web.authentication.AbstractAuthenticationTargetUrlRequestHandler;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.cavium.model.appliance.InitializeApplianceDetailModel;
import com.cavium.service.appliance.ApplianceService;
import com.cavium.service.recentactivity.RecentActivityServiceImpl;
import com.cavium.service.user.UserService;
import com.cavium.utill.CaviumConstant;

/**
 * MK00497144 
 * Spring Security logout handler
 */
@Component
public class CustomLogoutSuccessHandler extends AbstractAuthenticationTargetUrlRequestHandler
		implements LogoutSuccessHandler {

	private static final String BEARER_AUTHENTICATION = "Bearer ";
	private static final String HEADER_AUTHORIZATION = "authorization";
	private Logger logger = Logger.getLogger(this.getClass());
	@Autowired
	private TokenStore tokenStore;
	@Autowired
	private RecentActivityServiceImpl recentActivityServiceImpl;
	@Autowired
	private ApplianceService applianceService;
	@Autowired
	private UserService userService;

	public CustomLogoutSuccessHandler(TokenStore tokenStore,RecentActivityServiceImpl recentActivityServiceImpl,ApplianceService applianceService,UserService userService) {
		this.tokenStore = tokenStore;
		this.recentActivityServiceImpl=recentActivityServiceImpl;
		this.applianceService=applianceService;
		this.userService=userService;
	}
	/**
	 * This method is used to logout the current user with given token
	 */
	@Override
	public void onLogoutSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication)
			throws IOException, ServletException {
		logger.info("inside onLogoutSuccess");

		String token = request.getHeader(HEADER_AUTHORIZATION);
		JSONObject json = new JSONObject(); 
		if (token != null && token.startsWith(BEARER_AUTHENTICATION)) {

			OAuth2AccessToken oAuth2AccessToken = tokenStore.readAccessToken(token.split(" ")[1]);
			
			if (oAuth2AccessToken != null) {
				tokenStore.removeAccessToken(oAuth2AccessToken);
				String loggedInUser = (String)oAuth2AccessToken.getAdditionalInformation().get("username");
				json.put("code", "200");
				json.put("msg", "User successfuly logout");
				response.setStatus(HttpServletResponse.SC_OK);
				try{
				applianceService.deleteDualFactorDetailsForUser(loggedInUser);
				}catch (Exception e) {
					logger.error("inside onLogoutSuccess method  for deleteDualFactorDetailsForUser Functionality :: "+e.getMessage());
				}
				if(loggedInUser!=null)
				{
				boolean loginStatus=false;
				userService.updateLoginStatus(loggedInUser,loginStatus);					
				}
				recentActivityServiceImpl.createRecentActivity(loggedInUser, "User "+loggedInUser+" logged-out successfully.",CaviumConstant.USER_LOGOUT_MANAGEMENT);
			}else {
				json.put("error", "invalid_token");
				json.put("error_description", "Invalid access token: "+token.split(" ")[1]);
				response.setStatus(HttpServletResponse.SC_NOT_FOUND);
			}
		}
		response.setContentType("application/json");
		response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		out.print(json.toString());
		out.flush();
	}

}