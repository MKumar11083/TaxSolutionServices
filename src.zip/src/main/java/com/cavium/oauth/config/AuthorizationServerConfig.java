package com.cavium.oauth.config;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.oauth2.config.annotation.configurers.ClientDetailsServiceConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableAuthorizationServer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerEndpointsConfigurer;
import org.springframework.security.oauth2.provider.approval.UserApprovalHandler;
import org.springframework.security.oauth2.provider.token.DefaultAccessTokenConverter;
import org.springframework.security.oauth2.provider.token.TokenEnhancer;
import org.springframework.security.oauth2.provider.token.TokenStore;
/*
 * This class is used to authorize the request by oauth server as this class behaves like a oauth server
 * */
@Configuration
@EnableAuthorizationServer
public class AuthorizationServerConfig extends AuthorizationServerConfigurerAdapter {
	private Logger logger = Logger.getLogger(this.getClass());
   

    @Autowired
    private TokenStore tokenStore;

    @Autowired
    private UserApprovalHandler userApprovalHandler;

    @Autowired
    private AuthenticationManager authenticationManager;
    
    @Autowired
	Environment env;
    
    /*
     * This method is used to configure the oauth authorization server with given constant fields
     * */
    @Override
    public void configure(ClientDetailsServiceConfigurer configurer) throws Exception {
    	logger.info("inside the AuthorizationServerConfig class config method ");
    	String tokenValidity=env.getProperty("application.oauth2.token.validity");
    	String refreshTokenValidity=env.getProperty("application.oauth2.refreshtoken.validity");
        configurer
                .inMemory()
                .withClient(env.getProperty("application.oauth2.client.id"))
                .secret(env.getProperty("application.oauth2.client.secret"))
                .authorizedGrantTypes(env.getProperty("application.oauth2.grant.type1"),env.getProperty("application.oauth2.grant.type2"))
                .scopes(env.getProperty("application.oauth2.scope.type"))
                .accessTokenValiditySeconds(Integer.parseInt(tokenValidity)).
                refreshTokenValiditySeconds(Integer.parseInt(refreshTokenValidity));
    }
    
    /*
     * This method is used to configure the token store
     * */
    @Override
    public void configure(AuthorizationServerEndpointsConfigurer endpoints) {
        endpoints.tokenStore(tokenStore).tokenEnhancer(tokenEnhancer()).userApprovalHandler(userApprovalHandler)
                .authenticationManager(authenticationManager);
    }
    
    @Bean
    public TokenEnhancer tokenEnhancer() {
       return new CustomTokenEnhancer();
    }
    
    @Bean
    public DefaultAccessTokenConverter accessTokenConverter() {
        return new DefaultAccessTokenConverter();
    }
}