package com.cavium.repository.recentactivity;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cavium.model.recentactivity.RecentActivity;

@Repository
public interface RecentActivityRepository  extends JpaRepository<RecentActivity, String> {
	
	
	@Query(value="select * from recent_activites rec where rec.user_groupid= :usergroupid && rec.module_name= :moduleName order by rec.created_date desc",nativeQuery=true)
	public List<RecentActivity> getRecentActivity(@Param("usergroupid") String usergroupid ,@Param("moduleName") String moduleName  );
	
	@Query(value="select * from recent_activites rec where rec.user_groupid= :usergroupid order by rec.created_date desc",nativeQuery=true)
	public List<RecentActivity> getRecentActivityForDashboard(@Param("usergroupid") String usergroupid);
	
	@Query(value="select * from recent_activites rec where rec.user_groupid= :usergroupid && already_read=:alreadyRead order by rec.id desc LIMIT 1",nativeQuery=true)
	public RecentActivity getRecentActivityForNotification(@Param("alreadyRead") boolean alreadyRead,@Param("usergroupid") String usergroupid);
 
	@Transactional
	@Modifying
	@Query(value="update recent_activites set already_read=:alreadyRead  where user_groupid=:usergroupid",nativeQuery=true)
	public int updateAlreadyReadValue(@Param("alreadyRead") boolean alreadyRead, @Param("usergroupid") String usergroupid);
	 	
	@Query(value="select * from recent_activites where user_groupid= :usergroupid && already_read=:alreadyRead",nativeQuery=true)
	public List<RecentActivity> getAllUnreadRecentActivites(@Param("alreadyRead") boolean alreadyRead, @Param("usergroupid") String usergroupid);
	
}
