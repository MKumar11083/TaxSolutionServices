package com.cavium.repository.cluster;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.cavium.model.cluster.ClusterPartitionsRelationship;
import com.cavium.model.recentactivity.InProgressActivity;

public interface ClusterPartitionsRelationshipRepository extends JpaRepository<ClusterPartitionsRelationship,Long> {
		
		@Transactional
	    @Modifying
	  	@Query(value="delete from cluster_partitions_relationship  where partition_id = :partitionId",nativeQuery=true)
	  	public int deletePartitionFromCluster(@Param("partitionId") Long partitionId);
	    
	    @Query(value="select * from cluster_partitions_relationship cluster where cluster.partition_id = :partitionId",nativeQuery=true)
	    public List<ClusterPartitionsRelationship> getListOfClusters(@Param("partitionId") Long partitionId);
	    
	    @Query(value="select count(*) from cluster_partitions_relationship cluster where cluster.cluster_id = :clusterId",nativeQuery=true)
	    public int getNumberOfPartitionForCluster(@Param("clusterId") Long clusterId);
	
	    @Transactional
	    @Modifying
	  	@Query(value="delete from cluster_partitions_relationship  where cluster_id = :clusterId",nativeQuery=true)
	  	public int deleteAllPartitionsFromCluster(@Param("clusterId") Long clusterId);
	    
	    
	    @Query(value="select partition_id from cluster_partitions_relationship cluster where cluster.node_id = :nodeId and cluster.cluster_id = :clusterId",nativeQuery=true)
	    public  Long findPartitionIdAgainstNodeId(@Param("nodeId") Long nodeId,@Param("clusterId") Long clusterId);
	    
	    @Transactional
	    @Modifying
		@Query("update ClusterPartitionsRelationship relationship set relationship.ipAddress=:newIpAddress where relationship.ipAddress=:ipAddress")
		public int updateApplianceIp(@Param("newIpAddress") String newIpAddress,@Param("ipAddress") String ipAddress);
	    
	    @Query(value="select * from cluster_partitions_relationship cluster where cluster.cluster_id = :clusterId",nativeQuery=true)
	    public List<ClusterPartitionsRelationship> getListOfPartitionsForClusterId(@Param("clusterId") Long clusterId);
	    
	    @Query(value="select node_id from cluster_partitions_relationship cluster where cluster.cluster_id = :clusterId",nativeQuery=true)
	    public List<Integer> getListOfNodeIdsForClusterId(@Param("clusterId") Long clusterId);
	    
	    
	    
}
