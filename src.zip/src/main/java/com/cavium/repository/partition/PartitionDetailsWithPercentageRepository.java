package com.cavium.repository.partition;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cavium.pojo.PartitionDetailsWithPercentage;

@Repository
public interface PartitionDetailsWithPercentageRepository extends JpaRepository<PartitionDetailsWithPercentage, Long>{
	
	
	@Query(value="select  * from partition_snapshot_graph_details snap where snap.appliance_id=:applianceId and snap.user_name=:userName",nativeQuery=true)
	public List<PartitionDetailsWithPercentage> getListOfPartitionSnapShotDetailModel(@Param("userName") String userName,@Param("applianceId") Long applianceId);
	
	@Transactional
	@Modifying
	@Query(value="delete from partition_snapshot_graph_details where appliance_id=:applianceId",nativeQuery=true)
	public void deleteSnapShotGraphDetailsById(@Param("applianceId") Long applianceId);
}
