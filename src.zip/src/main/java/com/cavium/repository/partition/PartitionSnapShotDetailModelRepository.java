package com.cavium.repository.partition;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cavium.pojo.PartitionSnapShotDetailModel;

@Repository
public interface PartitionSnapShotDetailModelRepository extends JpaRepository<PartitionSnapShotDetailModel, Long>{
	
	
	@Query(value="select  * from partition_snapshot_details snap where snap.appliance_id=:applianceId and snap.user_name=:userName",nativeQuery=true)
	public PartitionSnapShotDetailModel getListOfPartitionSnapShotDetailModel(@Param("userName") String userName,@Param("applianceId") Long applianceId);
	
	@Transactional
	@Modifying
	@Query(value="delete from partition_snapshot_details where appliance_id=:applianceId",nativeQuery=true)
	public void deleteSnapShotDetailsById(@Param("applianceId") Long applianceId);

}
