package com.cavium.repository.appliance;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cavium.model.appliance.DualFactorUsersRelationshipModel;

@Repository
public interface DualFactorUsersRelationshipRepository extends JpaRepository<DualFactorUsersRelationshipModel, Long> {
	
	
	  @Query(value="select * from  dualfactor_users_relationship where user_id=:loginUser and appliance_id=:applianceId" ,nativeQuery=true)
	  public List<DualFactorUsersRelationshipModel> getDualFactorDetails(@Param("loginUser") String loginUser,@Param("applianceId") Long applianceId);
	  
	  @Query(value="select * from  dualfactor_users_relationship where user_id=:loginUser and appliance_ip=:applianceIp" ,nativeQuery=true)
	  public List<DualFactorUsersRelationshipModel> getDualFactorDetailsbyIp(@Param("loginUser") String loginUser,@Param("applianceIp") String applianceIp);
	  
	  
	  @Transactional
	  @Modifying
	  @Query(value="delete from  dualfactor_users_relationship where user_id=:loginUser" ,nativeQuery=true)
	  public int deleteDualFactorDetailsForUser(@Param("loginUser") String loginUser);
	  
	  
	  @Transactional
	  @Modifying
	  @Query(value="delete from  dualfactor_users_relationship where user_id=:loginUser and appliance_id=:applianceId" ,nativeQuery=true)
	  public int deleteDfDetailsForUserAgainstAppliance(@Param("loginUser") String loginUser,@Param("applianceId") Long applianceId);

	  @Transactional
	  @Modifying
	  @Query(value="delete from  dualfactor_users_relationship where user_id=:loginUser and appliance_ip=:applianceIp" ,nativeQuery=true)
	  public int deleteDfDetailsForUserAgainstApplianceIp(@Param("loginUser") String loginUser,@Param("applianceIp") String applianceIp);
	  
 
	  @Transactional
	  @Modifying
	  @Query(value="delete from  dualfactor_users_relationship where appliance_id=:applianceId" ,nativeQuery=true)
	  public int deleteDfDetailsAgainstAppliance(@Param("applianceId") Long applianceId);
	  
	  
	  @Transactional
		@Modifying
		@Query(value="update dualfactor_users_relationship set appliance_id=:applianceId  where appliance_ip=:applianceIp",nativeQuery=true)
		public int updateAppIpToAppId(@Param("applianceId") Long applianceId,@Param("applianceIp") String applianceIp);
	 
	  
}
