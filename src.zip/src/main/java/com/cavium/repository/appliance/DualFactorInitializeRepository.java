package com.cavium.repository.appliance;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cavium.model.appliance.DualFactorAuthDetailModel;
import com.cavium.model.appliance.InitializeApplianceDetailModel;

@Repository
public interface DualFactorInitializeRepository extends JpaRepository<DualFactorAuthDetailModel, Long> {
	
	
	@Query("select dfmodel from DualFactorAuthDetailModel dfmodel where dfmodel.initializeApplianceDetailModel=:initObj")
	public DualFactorAuthDetailModel getDFDetailsByInitializeId(@Param("initObj") InitializeApplianceDetailModel initObj);
 

}


