package com.cavium.repository.user;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cavium.model.user.ApplicationDetailModel;

@Repository
public interface ApplicationRepository
  extends JpaRepository<ApplicationDetailModel, Long>
{
 
}
