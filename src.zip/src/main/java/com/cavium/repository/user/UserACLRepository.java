package com.cavium.repository.user;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cavium.model.user.UserACLDetailsModel;

@Repository
public interface UserACLRepository
  extends JpaRepository<UserACLDetailsModel, Long>
{
	@Query("SELECT objUserACLDetailsModel FROM UserACLDetailsModel objUserACLDetailsModel WHERE objUserACLDetailsModel.aclName =:aclName")
	  public List<UserACLDetailsModel> findACLDetailsForACLName(@Param("aclName") String aclName);
	
	 @Query("SELECT objUserACLDetailsModel FROM UserACLDetailsModel objUserACLDetailsModel  WHERE  objUserACLDetailsModel.aclName LIKE CONCAT('%', :aclName,'%') group by objUserACLDetailsModel.id")
	  public List<UserACLDetailsModel> listACLDetails(@Param("aclName") String aclName);
	 
	 
	  @Query(value="select descr from  acl_details where id=:aclId" ,nativeQuery=true)
	  public String getACLName(@Param("aclId") Long aclId);
	  
	  @Query(value="select descr from  acl_details where id in (select acl_id from user_details where role=:groupId)",nativeQuery=true)	  
	  public List<String> getACLNamesForGroupId(@Param("groupId") Long groupId);
}

