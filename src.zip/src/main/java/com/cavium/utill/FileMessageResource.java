package com.cavium.utill;

import java.io.IOException;

import org.springframework.core.io.ByteArrayResource;
import org.springframework.web.multipart.MultipartFile;

public class FileMessageResource extends ByteArrayResource {

    /**
     * The filename to be associated with the {@link MimeMessage} in the form data.
     */
    private final String filename;

    /**
     * Constructs a new {@link FileMessageResource}.
     * @param byteArray A byte array containing data from a {@link MimeMessage}.
     * @param filename The filename to be associated with the {@link MimeMessage} in
     * 	the form data.
     */
    public FileMessageResource(MultipartFile multipartFile) throws IOException {
       
        super(multipartFile.getBytes());
		this.filename = multipartFile.getOriginalFilename();
      
    }

    @Override
    public String getFilename() {
        return filename;
    }
}
