package com.cavium.utill;
import java.io.IOException;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.log4j.Logger;
import org.snmp4j.CommandResponder;
import org.snmp4j.CommandResponderEvent;
import org.snmp4j.MessageDispatcherImpl;
import org.snmp4j.Snmp;
import org.snmp4j.TransportMapping;
import org.snmp4j.mp.MPv1;
import org.snmp4j.mp.MPv2c;
import org.snmp4j.mp.MPv3;
import org.snmp4j.security.AuthHMAC192SHA256;
import org.snmp4j.security.AuthHMAC256SHA384;
import org.snmp4j.security.AuthMD5;
import org.snmp4j.security.AuthSHA;
import org.snmp4j.security.Priv3DES;
import org.snmp4j.security.PrivDES;
import org.snmp4j.security.SecurityModels;
import org.snmp4j.security.SecurityProtocols;
import org.snmp4j.security.USM;
import org.snmp4j.security.UsmUser;
import org.snmp4j.security.UsmUserEntry;
import org.snmp4j.smi.Address;
import org.snmp4j.smi.GenericAddress;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.TcpAddress;
import org.snmp4j.smi.UdpAddress;
import org.snmp4j.smi.VariableBinding;
import org.snmp4j.transport.DefaultTcpTransportMapping;
import org.snmp4j.transport.DefaultUdpTransportMapping;
import org.snmp4j.util.MultiThreadedMessageDispatcher;
import org.snmp4j.util.ThreadPool;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.stereotype.Component;

import com.cavium.model.appliance.ApplianceDetailModel;
import com.cavium.model.snmptraps.SNMPTrapsModel;
import com.cavium.pojo.hostadminvm.AdminSNMPConfig;
import com.cavium.repository.snmptraps.SNMPTrapsRepository;
import com.cavium.service.appliance.ApplianceService;
import com.cavium.service.hostadminvm.HostAdminVMService;

@Component
public class SNMPTrapReceiver implements CommandResponder {

	private Logger logger = Logger.getLogger(this.getClass());
	private MultiThreadedMessageDispatcher dispatcher;
	private Snmp snmp = null;
	private Address listenAddress;
	private ThreadPool threadPool;

	@Autowired
	private ApplianceService applianceService;

	@Autowired
	private SNMPTrapsRepository snmpRepository;

	@Autowired
	private HostAdminVMService hostAdminVMService;
	
	 
	private Map<String,Object> snmpObjects= new HashMap<String,Object>();

	public SNMPTrapReceiver() {
	}
	@Lookup
	public AdminSNMPConfig getAdminSNMPConfig() {
		return null;
	}

	@PreDestroy
	public void distroyObjects()
	{
		 logger.info("Start of distroyObjects method ..."); 
		 
		 for (Map.Entry<String,Object> entry : snmpObjects.entrySet())
		 {
	          Object snmpObject= entry.getValue();
	             try{
	            	 ((Snmp) snmpObject).close();
	              }catch (Exception ex) {
	            	 logger.error("error in distroyObjects method ..."+ex.getMessage()); 
				}
	      }
	}
	public void run(ApplianceDetailModel app) {
		try {
			logger.info("Start of run method SNMP Trap Listener in run method of SNMPTrapReceiver class");
			init(app);
			logger.info("End of run method SNMP Trap Listener in run method of SNMPTrapReceiver class");
			if(snmp!=null){
				snmp.addCommandResponder(this);
			}
			logger.info(" SNMP Trap Listener added in Command Responder in run method of SNMPTrapReceiver class");
		} catch (Exception ex) {
			ex.printStackTrace();
			logger.error("error in run method ..."+ex.getMessage());
			System.out.println("error in run method ..."+ex.getMessage());
		}
	}

	@PostConstruct
	public void  allApplianceDetails()
	{
		createSNMPObjectForAllApliances();
	}

	
	private void init(ApplianceDetailModel applianceDetailModel) throws UnknownHostException, IOException {
		threadPool = ThreadPool.create("Trap", 10);
		 
		logger.info("............Init Method.....");
		dispatcher = new MultiThreadedMessageDispatcher(threadPool,
				new MessageDispatcherImpl());
		TransportMapping<?> transport=null;
		try{
			logger.info("Appliance Ip in SNMPTrapReceiver class "+ applianceDetailModel.getIpAddress());
			AdminSNMPConfig	adminSNMPConfig=hostAdminVMService.GetAdminSNMPConfig(applianceDetailModel,getAdminSNMPConfig());
			StringBuilder address= new StringBuilder();
			if(adminSNMPConfig.getAdminSNMPData()!=null && adminSNMPConfig.getAdminSNMPData().getAuthMode()!=null && adminSNMPConfig.getAdminSNMPData().getPrivMode()!=null){
				String managerIp=adminSNMPConfig.getAdminSNMPData().getIp();
				int managerPort=adminSNMPConfig.getAdminSNMPData().getPort();
				String engineId=adminSNMPConfig.getAdminSNMPData().getEngineId();
				String userName=adminSNMPConfig.getAdminSNMPData().getUname();
				boolean enableTrap=adminSNMPConfig.getAdminSNMPData().getEnableTrap();
				logger.info("...SNMP Trap  for Appliance IP.....  "+applianceDetailModel.getIpAddress()+ " :: "+ enableTrap);
				logger.info("...EngineId..... :: "+engineId +"......SNMPUserName..... ::"+userName);
				String authModeEncryption=adminSNMPConfig.getAdminSNMPData().getAuthMode().getEncryption();
				String authModePassword=adminSNMPConfig.getAdminSNMPData().getAuthMode().getPassword();
				String privModeEncryption=adminSNMPConfig.getAdminSNMPData().getPrivMode().getEncryption();
				String privModePassword=adminSNMPConfig.getAdminSNMPData().getPrivMode().getPassword();
				logger.info("getting all details from SNMP Config ");
				if(enableTrap){
					removeObjectFromMap(applianceDetailModel.getIpAddress());
					address.append("udp:").append(managerIp).append("/").append(managerPort);
					logger.info("...Address after Appending ManagerIp and ManagerPort... "+address);
					listenAddress = GenericAddress.parse(System.getProperty(
							"snmp4j.listenAddress", String.valueOf(address)));

					if (listenAddress instanceof UdpAddress) {
						transport = new DefaultUdpTransportMapping(
								(UdpAddress) listenAddress,true);
					} else {

						transport = new DefaultTcpTransportMapping(
								(TcpAddress) listenAddress);
					}
					 
					//USM usm = new USM(SecurityProtocols.getInstance(), new OctetString(
					//		MPv3.createLocalEngineID()), 0);
					System.out.println("............End of transport .....");
					logger.info("............End of transport .....");
					USM usm = new USM(SecurityProtocols.getInstance(), new OctetString(engineId), 0);

					usm.setEngineDiscoveryEnabled(true);

					snmp = new Snmp(dispatcher, transport);
					snmp.getMessageDispatcher().addMessageProcessingModel(new MPv1());
					snmp.getMessageDispatcher().addMessageProcessingModel(new MPv2c());
					snmp.getMessageDispatcher().addMessageProcessingModel(new MPv3(usm));
					SecurityModels.getInstance().addSecurityModel(usm);					 
					System.out.println("............End of addSecurityModel .....");
					logger.info("............End of addSecurityModel .....");
					OID authOID=null;
					String authName=null;
					OID privOID=null;
					if(authModeEncryption.equalsIgnoreCase("md5")){
						authOID=AuthMD5.ID;
						authName="MD5";
					}
					if(authModeEncryption.equalsIgnoreCase("sha") || authModeEncryption.equalsIgnoreCase("sha128") || authModeEncryption.equalsIgnoreCase("sha192")){
						authOID=AuthSHA.ID;
						authName="SHA-1";
					}
					if(authModeEncryption.equalsIgnoreCase("sha256")){
						authOID=AuthHMAC192SHA256.ID;
						authName="SHA-256";
					}
					if(authModeEncryption.equalsIgnoreCase("sha384")){
						authOID=AuthHMAC256SHA384.ID;
						authName="SHA-384";
					}
					if(authModeEncryption.equalsIgnoreCase("Disable")){
						authOID=null;
						authName=null;
					}


					if(privModeEncryption.equalsIgnoreCase("des") || privModeEncryption.equalsIgnoreCase("aes128") ||privModeEncryption.equalsIgnoreCase("aes192") ||privModeEncryption.equalsIgnoreCase("aes256") ){
						privOID=PrivDES.ID;
					}
					if(privModeEncryption.equalsIgnoreCase("3des")){
						privOID=Priv3DES.ID;
					}
					if(privModeEncryption.equalsIgnoreCase("Disable")){				 
						privOID=null;
					}
					System.out.println("............Start of Add user  with authOID ,authName, privOID , userName and authModeEncryption ,privModeEncryption details....." + authOID  +" :: "+authName +" :: " +privOID +" :: "+userName +" :: "+authModeEncryption +" :: "+privModeEncryption);
					logger.info("............Start of Add user  with authOID ,authName, privOID , userName and authModeEncryption ,privModeEncryption details....." + authOID  +" :: "+authName +" :: " +privOID +" :: "+userName +" :: "+authModeEncryption +" :: "+privModeEncryption);
					if(!authModeEncryption.equalsIgnoreCase("Disable") && !privModeEncryption.equalsIgnoreCase("Disable")){
						snmp.getUSM().addUser(
								new OctetString(userName),
								new UsmUser(new OctetString(userName), authOID,
										new OctetString(authModePassword), privOID,
										new OctetString(privModePassword),new OctetString(engineId)));
						 logger.info("with in authModeEncryption not NULL  and privModeEncryption mode not NULL for Appliance :: "+applianceDetailModel.getIpAddress()); 
						System.out.println("with in authModeEncryption not NULL  and privModeEncryption mode not NULL for Appliance :: "+applianceDetailModel.getIpAddress()); 
					}
					else if(authModeEncryption.equalsIgnoreCase("Disable") && privModeEncryption.equalsIgnoreCase("Disable")){
						snmp.getUSM().addUser(new OctetString(userName),
								new UsmUser(new OctetString(userName), null, null, null, null));
						logger.info("with in authModeEncryption is NULL and privModeEncryption is NULL  for Appliance :: "+applianceDetailModel.getIpAddress()); 
						System.out.println("with in authModeEncryption is NULL and privModeEncryption is NULL  for Appliance :: "+applianceDetailModel.getIpAddress());
					}
					else if(!authModeEncryption.equalsIgnoreCase("Disable") && privModeEncryption.equalsIgnoreCase("Disable")){
						snmp.getUSM().addUser(new OctetString(userName),
								new UsmUser(new OctetString(userName), authOID, new OctetString(authModePassword), null, null,new OctetString(engineId)));
						logger.info("with in authModeEncryption is not NULL and privModeEncryption is NULL for Appliance :: "+applianceDetailModel.getIpAddress()); 
						System.out.println("with in authModeEncryption is not NULL and privModeEncryption is NULL for Appliance :: "+applianceDetailModel.getIpAddress()); 
					}
					else if(authModeEncryption.equalsIgnoreCase("Disable") && !privModeEncryption.equalsIgnoreCase("Disable")){
						snmp.getUSM().addUser(new OctetString(userName),
								new UsmUser(new OctetString(userName), null, null, privOID, new OctetString(privModePassword),new OctetString(engineId)));
						logger.info("with in authModeEncryption is NULL and privModeEncryption is Not NULL for Appliance :: "+applianceDetailModel.getIpAddress()); 
						System.out.println("with in authModeEncryption is NULL and privModeEncryption is Not NULL for Appliance :: "+applianceDetailModel.getIpAddress()); 
					}
					System.out.println("............End of add user  with authOID ,authName, privOID details.....");
					logger.info("............End of add user  with authOID ,authName, privOID details.....");
					snmp.listen();
					if(snmp.getUSM()!=null && snmp.getUSM().getUserTable()!=null){
					for(UsmUserEntry usmUserEntry :snmp.getUSM().getUserTable().getUserEntries())
					{
						if(usmUserEntry!=null && usmUserEntry.getUsmUser()!=null){
						logger.info("............USM user Detail in SNMP Object for Appliance ....."+usmUserEntry.getUsmUser().toString() + ":: "+applianceDetailModel.getIpAddress());
						System.out.println("............USM user Detail in SNMP Object for Appliance ....."+usmUserEntry.getUsmUser().toString() + ":: "+applianceDetailModel.getIpAddress());
						}
				 }
					}
					snmpObjects.put(applianceDetailModel.getIpAddress(), snmp);
					System.out.println("............End of init Method.....");
					logger.info("......End of init Method..............");
				}
			}
		}
		catch(SocketException socketExp){
			socketExp.printStackTrace();
			logger.error("......SocketException   ..."+socketExp.getMessage());
			System.out.println("......SocketException   ..."+socketExp.getMessage());
		}
		catch(Exception exp){
			exp.printStackTrace();
			logger.error("error in init method ..."+exp.getMessage());
			System.out.println("error in init method ..."+exp.getMessage());
		}
		//}
	}

	public void processPdu(CommandResponderEvent event) {

		synchronized (event) {
			try{
				logger.info("...................Start of processPdu......................");
				System.out.println("...................Start of processPdu......................");
				StringBuffer msg = new StringBuffer();
				logger.info(".........CommandResponderEvent Object ...  :: "+event.toString());
				System.out.println(".........CommandResponderEvent Object ...  :: "+event.toString());
				Address addr = event.getPeerAddress();
				String applianceIp =null;

				if(addr!=null){
					applianceIp = addr.toString().split("/")[0];
					logger.info("......applianceIp from CommandResponderEvent Object.............."+applianceIp);
					System.out.println("......applianceIp from CommandResponderEvent Object.............."+applianceIp);
					ApplianceDetailModel applianceDetailModel= new ApplianceDetailModel();
					applianceDetailModel.setIpAddress(applianceIp);
					AdminSNMPConfig adminSNMPConfig=hostAdminVMService.GetAdminSNMPConfig(applianceDetailModel,getAdminSNMPConfig());
					boolean enableTrap=false;
					if(adminSNMPConfig.getAdminSNMPData()!=null && adminSNMPConfig.getAdminSNMPData().getAuthMode()!=null && adminSNMPConfig.getAdminSNMPData().getPrivMode()!=null){
						enableTrap=adminSNMPConfig.getAdminSNMPData().getEnableTrap();
					}

					if(enableTrap){
						msg.append(event.toString());
						Vector<? extends VariableBinding> varBinds = event.getPDU()
								.getVariableBindings();
						if (varBinds != null && !varBinds.isEmpty()) {
							Iterator<? extends VariableBinding> varIter = varBinds.iterator();
							while (varIter.hasNext()) {
								VariableBinding var = varIter.next();
								if(var.getVariable()!=null){
									//logger.info(".....variables :: "+var.getVariable().toString());
								//	System.out.println(".....variables :: "+var.getVariable().toString());
								}
								msg.append(var.toString()).append(";");
							}
						}
						logger.info("......Creating SNMPTrapsModel Model..............");
						System.out.println("......Creating SNMPTrapsModel Model..............");
						SNMPTrapsModel obj=  new SNMPTrapsModel();
						obj.setMessageRecvd(msg.toString());
						obj.setApplianceIp(applianceIp);
						snmpRepository.save(obj);	
						logger.info("......Saved of  of SNMPTrapsModel Model..............");
						System.out.println("......Saved of  of SNMPTrapsModel Model..............");
					}
				}

			}catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error in processPdu..."+e.getMessage());
				logger.info("Error in processPdu..."+e.getMessage());
			}
		}
	}
	
	public void createSNMPObjectForAllApliances(){
		logger.info("Start of createSNMPObjectForAllApliances Method");
	List<ApplianceDetailModel> applianceDetailModels = new ArrayList<ApplianceDetailModel>(); ;
		 
		applianceDetailModels=applianceService.getAllPermanentAppliances();
		for(ApplianceDetailModel  applianceDetailModel: applianceDetailModels){
		try{
		init(applianceDetailModel);
		if(snmp!=null){
			snmp.addCommandResponder(this);
		}
		}catch (Exception e) {
			logger.info("Error in allApplianceDetails method"+e.getMessage());
		}
	}
		logger.info("end of  createSNMPObjectForAllApliances Method");
	}
	
	public void removeObjectFromMap(String applianceIp){
		 
		 
		 Object snmpObject=snmpObjects.get(applianceIp);
		 try{
            if(snmpObject!=null){
           	((Snmp) snmpObject).close();
            }
             
            }catch (Exception ex) {
           	 logger.error("error in distroyObjects method ..."+ex.getMessage()); 
			}
	}
}
