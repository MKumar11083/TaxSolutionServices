package com.cavium.utill;

import java.util.List;

public class UserRoles {

	private String firstname;
	private String lastname;
	private List<String> roles;
	private String status;
	private String tempPassowrd;
	private String groupId;
	 
	/**
	 * @return the tempPassowrd
	 */
	public String getTempPassowrd() {
		return tempPassowrd;
	}
 
	/**
	 * @return the groupId
	 */
	public String getGroupId() {
		return groupId;
	}

	/**
	 * @param groupId the groupId to set
	 */
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	/**
	 * @param tempPassowrd the tempPassowrd to set
	 */
	public void setTempPassowrd(String tempPassowrd) {
		this.tempPassowrd = tempPassowrd;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
 	 
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public List<String> getRoles() {
		return roles;
	}
	public void setRoles(List<String> roles) {
		this.roles = roles;
	}
	
}
