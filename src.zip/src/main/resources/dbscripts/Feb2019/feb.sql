-- 8 Feb 2019 --
insert into permission(id,short_permission,permission_description,app_id) values((select max(id+1) from permission as id) ,'ROLE_UM_EDIT_APPLIANCE_OPERATION','Edit Appliance Operation','5');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),(select id from permission where short_permission="ROLE_UM_EDIT_APPLIANCE_OPERATION"));
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SecondaryUser'),(select id from permission where short_permission="ROLE_UM_EDIT_APPLIANCE_OPERATION"));
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='GroupAdmin'),(select id from permission where short_permission="ROLE_UM_EDIT_APPLIANCE_OPERATION"));
-- 11 Feb 2019 --
alter table appliance_details add column ping_count MEDIUMINT UNSIGNED;

---- 13 Feb 2019------
alter table appliance_details drop column dual_factor_details_session_saved;

--16 Feb 2019---  
alter table appliance_details add column mco_fixed_key_fingerprint varchar(250); 
 
 
 ======================
create table partition_snapshot_details(ID MEDIUMINT UNSIGNED NOT NULL AUTO_INCREMENT,zeroized_state MEDIUMINT,fip_mode MEDIUMINT,fip_mode_with_dualfactor MEDIUMINT,
			non_fip_mode MEDIUMINT,avaliable_partition_slots MEDIUMINT,
			total_partition_slots MEDIUMINT,occupied_partition_slots MEDIUMINT,
			partition_functional_status MEDIUMINT,partition_non_functional_status MEDIUMINT,
            user_name varchar(100),appliance_name varchar(100),appliance_id Long,PRIMARY KEY (ID));

create table partition_snapshot_graph_details(ID MEDIUMINT UNSIGNED NOT NULL AUTO_INCREMENT,percentage Double,type varchar(100),
	appliance_name varchar(100),appliance_id Long,user_name varchar(100), PRIMARY KEY (ID));
    
