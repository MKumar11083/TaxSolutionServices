alter table appliance_details add column grayed_out bit default 0;
alter table partition_configuration add column grayed_out bit default 0;
 alter table snmp_trap_recvr add column appliance_ip varchar(200);
    
alter table dual_factor_auth drop column dual_factor_auth_server_address;
alter table dual_factor_auth drop column dual_factor_auth_server_cert_id;
alter table dual_factor_auth add column dual_factor_certificate_id varchar(250);
alter table dual_factor_auth add column dual_factor_key_file_id varchar(250);
alter table dual_factor_auth add column session_only bit default 0;
alter table initialize add column appliance_id MEDIUMINT UNSIGNED;
alter table  appliance_details add column appliance_dual_factor_initialized bit default 0;
alter table  appliance_details add column dual_factor_details_session_saved bit default 0;
alter table  user_details add column login_status bit default 0;



alter table recent_activites add column already_read bit default 0;
alter table alerts add column already_read bit default 0;

ALTER TABLE dual_factor_auth add column keyfile_content MEDIUMTEXT;
ALTER TABLE dual_factor_auth add column keyfile_name varchar(250) ;
ALTER TABLE dual_factor_auth add column keyfile_extension varchar(250) ;
ALTER TABLE dual_factor_auth add column certificate_content MEDIUMTEXT;
ALTER TABLE dual_factor_auth add column  certificate_name varchar(250) ;
ALTER TABLE dual_factor_auth add column certificate_extension varchar(250) ;

 

 create table dualfactor_users_relationship (
    ID MEDIUMINT UNSIGNED NOT NULL AUTO_INCREMENT,
	dualfactor_id MEDIUMINT UNSIGNED,
	user_id varchar(45),
    PRIMARY KEY (id)
);


alter table dual_factor_auth drop column session_only;
alter table dual_factor_auth drop column  dual_factor_auth_server_cert_id;
alter table dual_factor_auth drop column dual_factor_certificate_id;
alter table dual_factor_auth drop column dual_factor_key_file_id;

alter table dualfactor_users_relationship drop column dualfactor_id;
alter table dualfactor_users_relationship add column dual_factor_key_file_id varchar(250);
alter table dualfactor_users_relationship add column dual_factor_certificate_id varchar(250);
alter table dualfactor_users_relationship add column appliance_ip varchar(250);
alter table dualfactor_users_relationship add column appliance_id MEDIUMINT UNSIGNED ;
alter table dualfactor_users_relationship add column dual_factor_auth_server_port_no MEDIUMINT UNSIGNED ;
alter table dualfactor_users_relationship drop column appliance_ip;