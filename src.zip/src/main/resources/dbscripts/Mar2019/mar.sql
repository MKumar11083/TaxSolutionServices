--------01/03/2019---------
create table partition_snapshot_details(ID MEDIUMINT UNSIGNED NOT NULL AUTO_INCREMENT,zeroized_state MEDIUMINT,fip_mode MEDIUMINT,fip_mode_with_dualfactor MEDIUMINT,
			non_fip_mode MEDIUMINT,avaliable_partition_slots MEDIUMINT,
			total_partition_slots MEDIUMINT,occupied_partition_slots MEDIUMINT,
			partition_functional_status MEDIUMINT,partition_non_functional_status MEDIUMINT,
            user_name varchar(100),appliance_name varchar(100),appliance_id Long,PRIMARY KEY (ID));

create table partition_snapshot_graph_details(ID MEDIUMINT UNSIGNED NOT NULL AUTO_INCREMENT,percentage Double,type varchar(100),
	appliance_name varchar(100),appliance_id Long,user_name varchar(100), PRIMARY KEY (ID));
 
------------05/03/2019--------------------------
	alter table cluster_details add pending_requests_count MEDIUMINT;
-----------11/03/2019------------------------------------------------
	alter table inprogress_activity add partition_added bit(1) default 0;
----------12/03/2019----------------------
	insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='MonitorUser'),(select id from permission where short_permission="ROLE_UM_DASHBOARD_USERS_GRAPH"));