insert into permission(id,short_permission,permission_description,app_id) values('30','ROLE_UM_SNMP_CONFIGURE','Snmp Configure','5');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='GroupAdmin'),'30');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SecondaryUser'),'30');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),'30');
 
insert into permission(id,short_permission,permission_description,app_id) values('31','READ_WRITE_PERMISSION','READ WRITE PERMISSION','5');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='GroupAdmin'),'31');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SecondaryUser'),'31');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SuperAdmin'),'31');


insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='GroupAdmin'),'15');
insert into acl_role (acl_id,permission_id) values((select id from acl_details where descr='SecondaryUser'),'15');


alter table appliance_details add column total_partitions MEDIUMINT UNSIGNED;


alter table appliance_details add column occupied_partitions MEDIUMINT UNSIGNED;