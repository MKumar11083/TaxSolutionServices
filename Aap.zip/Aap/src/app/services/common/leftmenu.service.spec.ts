import { TestBed, inject } from '@angular/core/testing';

import { LeftmenuService } from './leftmenu.service';

describe('LeftmenuService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [LeftmenuService]
    });
  });

  it('should be created', inject([LeftmenuService], (service: LeftmenuService) => {
    expect(service).toBeTruthy();
  }));
});
