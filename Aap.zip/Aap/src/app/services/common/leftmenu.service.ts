import { Injectable } from '@angular/core';
import * as leftMenuData from './../../../assets/data/leftmenu.json';

@Injectable()
export class LeftmenuService {
  leftMenuMap :Map<string, CustomModules>;
  submodules: CustomModules;
  leftMenuModulesList: Array<leftMenuModules> = [];
  constructor() {
    
    }

    getLeftMenuDetails(taskSet : Set<any>){
      
       let leftMenuDatas = (<any>leftMenuData);
       this.leftMenuMap = new Map<string, CustomModules>();
       leftMenuDatas.forEach(modules => {
        for(let id of modules.taskId){
          if(taskSet.has(id)){
           this.submodules = this.leftMenuMap.get(modules.moduleName);
           if(this.submodules == undefined){
             this.submodules = new CustomModules(modules.icon,modules,modules.submenu);
           }
           else{
            this.submodules.icon = modules.icon;
            this.submodules.modules.push(modules); 
           }
           this.leftMenuMap.set(modules.moduleName,this.submodules);
           break;
         }
        }
        if(modules.taskId.length == 0){
          this.submodules = this.leftMenuMap.get(modules.moduleName)
          if(this.submodules == undefined){
            this.submodules = new CustomModules(modules.icon,modules,modules.submenu);
            
          }
          else{
            this.submodules.icon = modules.icon;
           this.submodules.modules.push(modules); 
          }
          this.leftMenuMap.set(modules.moduleName,this.submodules);
        }  
       });


       return this.leftMenuMap;
      }

      getLeftMenuModuleList(map:Map<string, CustomModules>){
        this.leftMenuModulesList = new Array<leftMenuModules>();
        map.forEach((value: CustomModules, key: string) => {
          let modLink:string;
          if(!value.hasSubMenu){
            let modObj=value.modules[0];
            modLink=modObj['link'];
          }
          this.leftMenuModulesList.push(new leftMenuModules(key,value.icon,value.modules,value.hasSubMenu,modLink));
          
      });
      return this.leftMenuModulesList;
      }

}

export class CustomModules {
 icon: string;
 modules: Object[]=[];
 hasSubMenu: boolean;
constructor(icon:string, modules:Object, hasSubMenu:boolean) {
  this.icon = icon;
  this.modules.push(modules);
  this.hasSubMenu = hasSubMenu
  }

}


export class leftMenuModules {
  title: string;
  icon: string;
  modules: any;
  hasSubMenu: boolean;
  moduleLink:string;
 constructor(title: string,icon:string, modules:Object, hasSubMenu:boolean,modLink:string) {
   this.title = title;
   this.icon = icon;
   this.modules=modules;
   this.hasSubMenu = hasSubMenu;
   this.moduleLink = modLink;
   }
 
 }