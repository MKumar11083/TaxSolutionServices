import { Injectable } from '@angular/core';
import { Cookie } from 'ng2-cookies';
@Injectable()
export class RolesService {
    //public rolesSet: Set<any>;
    
    setRoles(response) {
       var rolesList = [];
        if (response.roles) {
           //rolesSet = new Set(response.roles);
            //sessionStorage.setItem("roles",response.roles)
            // response.roles.forEach(role => {
            //     rolesList.push(role);
            // });
        }
        
        // console.log(sessionStorage.getItem("roles"));
    }

    getRoles() {
        //console.log(Cookie.get("roles"));
        //console.log(this.rolesSet);
        //return this.rolesSet;
        return sessionStorage.getItem("roles");
    }
}
