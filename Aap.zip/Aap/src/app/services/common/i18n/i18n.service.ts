import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Injectable()
export class I18nService {
  errorMessages = [];
  errorMessage = '';

  constructor(private _translate: TranslateService) { }

  getI18NMessagesForError(res, path, params) {
    this.errorMessages = [];
      if (res != null) {
          let body = JSON.parse(res['_body']);
          let obj = body.fields;
          if(obj){
            for (var key in obj) {
                if (body.fields.hasOwnProperty(key)) {
                  let ky = obj[key];
                  this.errorMessages.push(this.getI18n(path + '.messages' + '.' + ky, params));
                }
            }
          }else{
            if(res.status === 500){
              this.errorMessages.push(this.getI18n('messages.internal-error', {}));
            }
          }
          return this.errorMessages;
      }
  }

  getI18NMessagesForSuccess(res, path, params) {
    this.errorMessages = [];
      if (res != null) {
          let key = JSON.parse(res['_body']);
          this.errorMessages.push(this.getI18n(path + '.messages' + '.' + key, params));
      }      
    return this.errorMessages;
  }

  getI18NMessages(key, params) {
    this.errorMessages = [];
      if (key != null) {
        let msg = '';
        if(params){
            msg = this.getI18n(key, params);
        }
        this.errorMessages.push(msg);
      }
      return this.errorMessages;
  }

  getI18NMessage(key, params) {
    this.errorMessage = undefined;
      if (key != null) {
        this.errorMessage = this.getI18n(key, params);
      }
      return this.errorMessage;
  }

  getI18n(key, params) {
      let message;
      this._translate.get(key, params).subscribe(res => {
          message = res;
      });
      return message;
  }
}
