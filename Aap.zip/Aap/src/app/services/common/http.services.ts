import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { Configuration } from '../../app.constants';
import { Observable } from 'rxjs/Observable';
import { Cookie } from 'ng2-cookies';
@Injectable()
export class HttpServices {
    errorMessages = [];
    private apiUrl: string;
    private newUrl:string;
    constructor(private _http: Http, private _configuration: Configuration) {
        this.apiUrl = _configuration.ServerWithApiUrl;
    }
   
    options() {
        let headers = new Headers({
            'Content-type': 'application/json',
            'Authorization': 'Bearer '+Cookie.get('access_token')
          });
        let options = new RequestOptions({ headers: headers });
        return options;
    }

    httpGet(url: String) {
        // alert("Inside HTTP"+Cookie.get('access_token'));
        // console.log(this.options());
        // console.log(url);
        
        return this._http.get(this.apiUrl + url, this.options())
            .map(res => res.json())
            
    }

    httpPost(model, url: String) {
        return this._http.post(this.apiUrl + url, model, this.options())
            .map(res => res.json())
    }
    httpPut(model, url: String) {
        return this._http.put(this.apiUrl + url, model, this.options())
            .map(res => res)
    }
    httpDelete(url: String) {
        return this._http.delete(this.apiUrl + url, this.options())
            .map(res => res)
    }
    httpDeleteOperationWithBody(url:String,model){
        let headers = new Headers({ 'Content-Type': 'application/json' ,
        'Authorization': 'Bearer '+Cookie.get('access_token')});
           let options = new RequestOptions({
             headers: headers,
             body : model
           });
        return this._http.delete(this.apiUrl + url, options)
        .map(res => res)
    }
    
   
}
