import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { HttpServices } from './../services/common/http.services';

@Injectable()
export class AppliancemanagementService {

  constructor(private _httpServices: HttpServices, private _http: Http) {
  }
  
//  getApplianceList() {
//   let url = "/listAppliance";
//     return this._httpServices.httpGet(url);
//  }

  addAppliance(form) {
  console.log(form);
  let url = "/createUser";
  return this._httpServices.httpPost(form, url);
}
 getAllListAppliances() {
  let url = "/listAppliance";
 return this._httpServices.httpGet(url);
}
getAllSnapshotDetails(){
  let url = "/getSnapshotDetails";
  return this._httpServices.httpGet(url);
}
setRebootActivity(form) {
  let url = "/rebootAppliance";
 return this._httpServices.httpPost(form,url);
}
firmwareUpgrade(form){
  let url = "/applianceFirmwareUpgrade";
  return this._httpServices.httpPost(form,url);

}
setZeroise(form){
  let url = "/zeroizeAppliance";
  return this._httpServices.httpPost(form,url);
}
getHostSystemInfo() {
  let url = "/getHostSystemInfo/10.89.7.150/";
 return this._httpServices.httpGet(url);
}

searchAppliances(model) {
  let url = "/searchAppliance ";
  return this._httpServices.httpPost(model, url);
}
}
