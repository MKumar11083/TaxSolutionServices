import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Configuration } from '../app.constants';
import { HttpServices } from './../services/common/http.services';
import { Cookie } from 'ng2-cookies';
@Injectable()
export class UserManagementService {
    private apiUrl: string;
    private userId: any = [];
    constructor(private _httpServices: HttpServices, private _http: Http) {

    }
    getUsersList() {
        let url = "/listUsers";
        return this._httpServices.httpGet(url);
    }
    getdropdownList() {
        let url = "/getGroupACLDetails";
        return this._httpServices.httpGet(url);
    }
    createUser(form) {
        console.log(form);
        let url = "/createUser";
        return this._httpServices.httpPost(form, url);
    }
    modifyUser(form) {
        console.log("modify .........");
        console.log(form);
        let url = "modifyUser";
        return this._httpServices.httpPut(form, url);
    }

    setuserId(userid) {
        console.log(userid);
        this.userId = userid;
    }
    getuserId() {
        return this.userId;
    }
    getUserById(userId) {
        let url = "/getUserDetail/" + userId;
        return this._httpServices.httpGet(url);
    }
    deleteUser(userIds) {
        console.log(userIds);
        let userDetailModel =
            {
                "deletedUserIds": userIds
            }

        let url = "deleteUser";
        return this._httpServices.httpDeleteOperationWithBody(url, userDetailModel);

    }
    searchUsers(model) {
        let url = "searchUserDetails";
        return this._httpServices.httpPost(model, url);
    }

}

