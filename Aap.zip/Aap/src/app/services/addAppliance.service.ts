import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Configuration } from '../app.constants';
import { HttpServices } from './../services/common/http.services';
import { Cookie } from 'ng2-cookies';

@Injectable()
export class AddApplianceService {
   
    private apiUrl: string;
    private userId: any =[];
    constructor(private _httpServices: HttpServices,private _http:Http) {

    }
    getAllListAppliances() {
        let url = "/listAppliance";
        return this._httpServices.httpGet(url);
    }

    verifyAppliances(form){

        let url = "/validateAppliance";
        return this._httpServices.httpPost(form._value, url);
    }

    addAppliance(form){

        console.log(form);
        let url="/createAppliance";
        return this._httpServices.httpPost(form, url);
       // return this._httpServices.httpPost();
    }
 
}