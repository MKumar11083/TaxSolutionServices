export function setOption(value,label){
    let option=new Option();
    option.value=value;
    option.label=label;
    return option;
}

export function setValueToSelect(value){
    let setValue=[];
    setValue.push(value);
    return setValue;
}

export function splitTime(time:string){
  let date =new Date();
  let splitTime=time.split(':')
  date.setHours(parseInt(splitTime[0]));
  date.setMinutes(parseInt(splitTime[1]));
  return date;
}

class Option {
    value: any;
    label: any;
}