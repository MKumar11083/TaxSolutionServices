import { Component, OnInit, OnDestroy } from '@angular/core';
import { Configuration } from '../../app.constants';
import { NgxPermissionsService } from 'ngx-permissions';
import { LoginService } from './../../services/login.service';
import { Router } from '@angular/router';
import { Cookie } from 'ng2-cookies';
import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { Keepalive } from '@ng-idle/keepalive';
declare var $: any;
declare var jQuery: any;
@Component({
  selector: 'app-secure',
  templateUrl: './secure.component.html',
  styleUrls: ['./secure.component.css']
})
export class SecureComponent implements OnInit {
  errorMsg: string;
  idleState = 'Not started.';
  timedOut = false;
  lastPing?: Date = null;
  constructor(private permissionsService: NgxPermissionsService,
    private _loginService: LoginService,
    private _router: Router,
    private idle: Idle, private keepalive: Keepalive
  ) {

    // sets an idle timeout of 5 seconds, for testing purposes.

    idle.setIdle(50000);
    // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
    idle.setTimeout(5);
    // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
    idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

    // idle.onIdleEnd.subscribe(() => this.idleState = '');
    idle.onTimeout.subscribe(() => {
      this.idleState = 'Timed out!';
      this.timedOut = true;
      console.log("timeout");

    });
    // idle.onIdleStart.subscribe(() => this.idleState = '');
    idle.onTimeoutWarning.subscribe((countdown) => {
      $("#sessionTimeout").modal("show");
      this.idleState = 'You will time out in ' + countdown + ' seconds!';
    }
    );

    // sets the ping interval to 15 seconds
    keepalive.interval(15);

    keepalive.onPing.subscribe(() => this.lastPing = new Date());

    this.reset();
  }

  reset() {
    $("#sessionTimeout").modal("hide");
    this.idle.watch();
   // this.idleState = 'Started.';
    this.timedOut = false;
  }

  goToLogin() {
    this.idle.stop();
    this.idle.ngOnDestroy(); //includes this.idle.stop() and this.clearInterrupts() both.
    
    this.reset();
    $("#sessionTimeout").modal("hide");
    sessionStorage.clear();
    Cookie.delete('access_token');
    this._router.navigate(['/login']);
  }

  ngOnInit() {
    $('body').resize();
    this._loginService.getUserRoles().subscribe(
      response => {
        console.log(response);
        this.checkUserRolesOrStatus(response);
      },
      error => {
        console.log(error);
      }
    );
  }


  /* This method is to load the roles of the logged in user*/
  checkUserRolesOrStatus(response) {
    const notActiveUser = "You are not a active User";
    const notPartOfGroup = "You are not a part of any Group"
    if (response.groupId != null) {
      /* If status is "SUSPENDED" ,user will not able to login*/
      if (response.status == "SUSPENDED") {
        this.failToLogin(notActiveUser);
        this._router.navigate(['/login']);
      } else {
        this.permissionsService.loadPermissions(response.roles);
        //sessionStorage.setItem("username",response.firstname);
      }
    } else {
      this.failToLogin(notPartOfGroup);
      this._router.navigate(['/login']);
    }
  }

  failToLogin(errorMessage) {
    debugger;
    Cookie.delete('access_token');
    Cookie.delete('refresh_token');
    this.errorMsg = errorMessage;
    sessionStorage.setItem("errorMsg",errorMessage);
  }


}
