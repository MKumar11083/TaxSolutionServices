import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
declare var $: any;
@Component({
  selector: 'app-leftmenu',
  templateUrl: './app-leftmenu.component.html',
  styleUrls: ['./app-leftmenu.component.css']
})
export class AppLeftmenuComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
    $(document).ready(() => {
      const trees: any = $('[data-widget="tree"]');
      trees.tree();
    });
  }

  navigateURL(URL){
    console.log(URL);
    this.router.navigateByUrl(URL);
  }
}
