import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppLeftmenuComponent } from './app-leftmenu.component';

describe('AppLeftmenuComponent', () => {
  let component: AppLeftmenuComponent;
  let fixture: ComponentFixture<AppLeftmenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppLeftmenuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppLeftmenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
