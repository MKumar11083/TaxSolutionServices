import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { Cookie } from 'ng2-cookies';
@Component({
  selector: 'app-header',
  templateUrl: './app-header.component.html',
  styleUrls: ['./app-header.component.css']
})
export class AppHeaderComponent implements OnInit {

  constructor(private _router:Router) { }
  username :string;
  ngOnInit() {
    this.username=sessionStorage.getItem("username");
  }
  logout() {
    sessionStorage.clear();
    Cookie.delete('access_token');
    this._router.navigate(['/login']);
  }
}
