import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'fontResize'
})
export class FontResizePipe implements PipeTransform {

  transform(value: string, args?: any): string {
    let size = "32px";
    let lngth = 0;
    if(value){
      if(typeof value == 'number'){
        lngth = (''+value).length;
      }else if(typeof value == 'string'){
        lngth = value.length;
      }
      if(lngth > 8  && lngth < 13){
        size = "24px";
      }else if (lngth > 12){
        size = "16px";
      }
    }
    return size;
  }
}
