import { DateFormat2Pipe } from './date-format2.pipe';

describe('DateFormat2Pipe', () => {
  it('create an instance', () => {
    const pipe = new DateFormat2Pipe();
    expect(pipe).toBeTruthy();
  });
});
