import { JodaTimeFormatPipe } from './joda-time-format.pipe';

describe('JodaTimeFormatPipe', () => {
  it('create an instance', () => {
    const pipe = new JodaTimeFormatPipe();
    expect(pipe).toBeTruthy();
  });
});
