import { Component, OnInit ,ChangeDetectorRef} from '@angular/core';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, FormControl } from '@angular/forms';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
import { AddApplianceService } from './../../../../services/addAppliance.service'

declare var jquery:any;
declare var $ :any;
declare var bootbox: any;
@Component({
  selector: 'app-add-appliance',
  templateUrl: './add-appliance.component.html',
  styleUrls: ['./add-appliance.component.css']
})
export class AddApplianceComponent implements OnInit {
  
  showlist :  boolean = true;
  form: FormGroup;
  public successMessage:string;
  private groupsList:string;
  getValidateRes:object[]=[];
   getValidateRes1:object[]=[];
   getValidateRes3:object[]=[];
  private applianceSent:object[]=[];
  private localStorageApplianceSent:object[]=[];
  private onPageApplianceSent:object[]=[];
  showApp:object[]=[];
   showAppliance:boolean=false;
   private checkboxFlag:string;
   private getAddStatusFlag:string;
   private localStorageDefault:object[]=[];
     displayErrors: any = []; 
   showmessage:boolean=false;
   utcNames=["(GMT-12:00) International Date Line West",
   "(GMT-11:00) Midway Island, Samoa",
   "(GMT-12:00) Tijuana, Baja California",
"(GMT-12:00) Bogota, Lima, Quito, Rio Branco",
  "(GMT-12:00) Eastern Time",
   "(GMT+05:30) Chennai, Kolkata, Mumbai, New Delhi",
   "(GMT+07:00) Bangkok, Hanoi, Jakarta",
   "(GMT+05:30) Sri Jayawardenapura",
   "(GMT+08:00) Beijing, Chongqing, Hong Kong, Urumqi",
  "(GMT+12:00) Fiji, Kamchatka, Marshall Is.",
   "(GMT+12:00) Auckland, Wellington"
]
   
    

  constructor(
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private _addApplianceService :AddApplianceService,
    private chRef: ChangeDetectorRef,
  

    private builder: FormBuilder) { }
  
  ngOnInit() {
    debugger;
    this.createForm();

  
   if("applianceArray1" in localStorage){

    debugger;
    this.showAppliance=true;
    debugger;
    var temp=[];
    
    
    temp.push(JSON.parse(localStorage.getItem("applianceArray1")));
    if(temp.length>0){
    for(var i=0;i<temp.length;i++){
     // console.log(localStorage.getItem("applianceArray1")[i]);
      this.getValidateRes1=temp[i];
    }
  }
    //this.getValidateRes1.push(JSON.parse(localStorage.getItem("applianceArray1")));
     console.log(this.getValidateRes1); 

   }
    
  }
  toggle(){
    this.showlist = true;
  }
  toggle1(){
    this.showlist = false;
  }

  createForm() {
      
      this.form = this.builder.group({
      applianceName: ['', Validators.required],
      authID: ['', Validators.required],
      serialNumber: ['', Validators.required],
      networkTimezone: [''],
      ipAddress: ['', Validators.required],  
      gatewayIp: [''],
      subnetMask: [''],
      networkMode: [''],    
      hostName: [''],
      ipmiIP: ['', Validators.required],
      userName: ['', Validators.required],    
      userPassword: ['', Validators.required],
      cityName:['',Validators.required]

    });
  }

  /* onSubmit function is to create users*/
  

  onSuccessOperation(res) {
    let response = JSON.parse(res['_body']);
    console.log(response);
    this.successMessage = response.responseMessage;
  }

  onErrorOperation(errResp) {
  }

   // create a form errors
   public formValidationFields = {
    "applianceName": '',
    "authID": '',
    "serialNumber": '',
    // "network": '',
     "ipAddress": '',
    // "gatewayIP": '',
    // "subnetMask": '',
    // "networkMode": '',
    // "hostname": '',
    "ipmiIP": '',
    "userName": '',
    "userPassword": '',
    "cityName" :''
  }

  isFieldValid(field: string) {
   
    if (this.form.get(field).touched) {
      this.formValidationFields = this._fieldErrorDisplayService.validateField(this.form, field, this.formValidationFields, "addAppliance")
    }
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  submitApplication(isValid: boolean){
    
    
    debugger;
    if (isValid) {
    this._addApplianceService.verifyAppliances(this.form).subscribe((res) => {
      console.log("UserGroup is created");
      
      this.getValidateRes=(res);
     console.log("Inside success");
      console.log("this is getValidateReS"+this.getValidateRes["code"]);
       if(this.getValidateRes["code"]=="200"){
        let message = this.getValidateRes["message"]+".Appliance is verified and  is available to add.";
        bootbox.dialog({
          message: message,
          buttons: {
            
            ok: {
              label: "Ok",
              className: 'btn btn-primary btn-flat',
              
            }
          }
        });
          // alert(this.getValidateRes["message"]);
           this.showApp.push(res);

           if("applianceArray1" in localStorage){
           this.localStorageDefault=JSON.parse(localStorage.getItem("applianceArray1"));
                 
           }
           this.localStorageDefault.push(res);
           localStorage.setItem("applianceArray1",JSON.stringify(this.localStorageDefault));

          
       }
      else if(this.getValidateRes["code"]=="409"){
        

        let message = this.getValidateRes["message"];
        bootbox.dialog({
          message: message,
          buttons: {
            
            ok: {
              label: "Ok",
              className: 'btn btn-primary btn-flat',
              
            }
          }
        });
       
       
        //this.showAppliance=true;

        //localStorage.setItem("applianceArray1",JSON.stringify(this.getValidateRes));

       



       }
       
  
    },
    (err) => {

      let message ="Sorry! Please try to add appliance again"
        bootbox.dialog({
          message: message,
          buttons: {
            
            ok: {
              label: "Ok",
              className: 'btn btn-primary btn-flat',
              
            }
          }
        });
     // console.log(JSON.stringify(err._body));
    });


   
    
  }  
  else{
    this.formValidationFields = this._fieldErrorDisplayService.validateForm(this.form, this.formValidationFields, "addAppliance", false)
    
  }
}

deleteAppliance(){
 
  if(this.localStorageDefault.length){
    for(var i=0;i<this.showApp.length;i++){
      for(var j=0;j<this.localStorageDefault.length;j++){
       if(this.localStorageDefault[j]["applianceName"]==this.showApp[i]["applianceName"]){
          
         let index31=j;
         this.localStorageDefault.splice(index31,1);
         localStorage.setItem("applianceArray1",JSON.stringify(this.localStorageDefault));
       }
  
      }
  
    
   }
  }
  for(var i=0;i<this.onPageApplianceSent.length;i++){
     for(var j=0;j<this.showApp.length;j++){
      if(this.onPageApplianceSent[i]["applianceName"]==this.showApp[j]["applianceName"]){
         
        let index3=j;
        this.showApp.splice(index3,1);
      }

     }

   
  }

  for(var i=0;i<this.localStorageApplianceSent.length;i++){
    for(var j=0;j<this.getValidateRes1.length;j++)
    
  if(this.localStorageApplianceSent[i]["applianceName"]==this.getValidateRes1[j]["applianceName"]){

    let index14=j;
    this.getValidateRes1.splice(index14,1);
    localStorage.setItem("applianceArray1",JSON.stringify(this.getValidateRes1));
  }
}




  for(var i=0;i<this.onPageApplianceSent.length;i++){
     for(var j=0;j<this.showApp.length;j++){
      if(this.onPageApplianceSent[i]["applianceName"]==this.showApp[j]["applianceName"]){
         
        let index3=j;
        this.showApp.splice(index3,1);
      }

     }

   
  }
  
  if(this.localStorageDefault.length){
  for(var i=0;i<this.showApp.length;i++){
    for(var j=0;j<this.localStorageDefault.length;j++){
     if(this.localStorageDefault[j]["applianceName"]==this.showApp[i]["applianceName"]){
        
       let index31=j;
       this.localStorageDefault.splice(index31,1);
       localStorage.setItem("applianceArray1",JSON.stringify(this.localStorageDefault));
     }

    }

  
 }
}
  this.chRef.detectChanges();
  
}
  





  addApplianceToList(){

    debugger;
    if(this.localStorageApplianceSent.length>0){

      for(var i=0;i<this.localStorageApplianceSent.length;i++){
        this.localStorageApplianceSent[i]["applianceStatus"]="Active";

        this.applianceSent.push(this.localStorageApplianceSent[i]);
      
      }
    }
   if(this.onPageApplianceSent.length>0){


    for(var i=0;i<this.onPageApplianceSent.length;i++){
      this.onPageApplianceSent[i]["applianceStatus"]="Active"

      this.applianceSent.push(this.onPageApplianceSent[i]);
     

    }

   }
   
    this._addApplianceService.addAppliance(this.applianceSent).subscribe((res) => {
      console.log("UserGroup is created");
      
     this.getAddStatusFlag=res;

     if(this.getAddStatusFlag["responseCode"]=="200"){
      
      for(var i=0;i<this.applianceSent.length;i++){
        for(var j=0;j<this.getValidateRes1.length;j++){

          if(this.getValidateRes1[j]["applianceName"]==this.applianceSent[i]["applianceName"]){

                let deleteIndex=j;
                this.getValidateRes1.splice(deleteIndex,1);
          }
        
        }


      }
      for(var i=0;i<this.applianceSent.length;i++){
        for(var j=0;j<this.showApp.length;j++){
          if(this.showApp[j]["applianceName"]==this.applianceSent[i]["applianceName"]){

            let deleteIndex1=j;
            this.showApp.splice(deleteIndex1,1);
      }
        
        }


      }
      localStorage.setItem("applianceArray1",JSON.stringify(this.getValidateRes1));

     }
     let message = "Appliances added successfully.Please click OK to continue.";
     bootbox.dialog({
       message: message,
       buttons: {
         
         ok: {
           label: "Ok",
           className: 'btn btn-primary btn-flat',
           callback: () => this.reloadPage()
         }
       }
     });
       
     
    },
    (err) => {
      console.log(JSON.stringify(err._body));
    });

  }
  reloadPage(){
    location.reload();
}
  
  addApplianceEvent(event,value){

    debugger;
    if (event.target.checked) {
    if(this.showApp.length>0){
       for(var i=0;i<this.showApp.length;i++){
        if(this.showApp[i]["applianceName"]==value){
           delete this.showApp[i]["applianceId"];
            this.onPageApplianceSent.push(this.showApp[i]);


           
       }

       }

    }
    if(this.getValidateRes1.length>0){
    for (var i=0;i<this.getValidateRes1.length;i++){
      if(this.getValidateRes1[i]["applianceName"]==value){
        delete this.getValidateRes1[i]["applianceId"];
        this.localStorageApplianceSent.push(this.getValidateRes1[i]);

       
   

      }

      

    }
  }
}
  else{
    for(var i=0;i<this.onPageApplianceSent.length;i++){

      if(this.onPageApplianceSent[i]["applianceName"]==value){

        let index=i;
        this.onPageApplianceSent.splice(index,1);
      }
    }
    for(var i=0;i<this.localStorageApplianceSent.length;i++){
    if(this.localStorageApplianceSent[i]["applianceName"]==value){

      let index1=i;
      this.localStorageApplianceSent.splice(index1,1);
    }
  }
    /*let index = this.onPageApplianceSent.indexOf(value);
    this.onPageApplianceSent.splice(index);
    let index1=this.localStorageApplianceSent.indexOf(value)
    this.localStorageApplianceSent.splice(index);*/

  }
   /* if(this.onPageApplianceSent.length!=null || this.localStorageApplianceSent.length!=null)

    this.applianceSent.push(this.getValidateRes1[i]);
    debugger;
    this.checkboxFlag=event;
    console.log(this.checkboxFlag);*/


  }
  

}
