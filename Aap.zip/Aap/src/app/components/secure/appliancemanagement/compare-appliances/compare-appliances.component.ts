import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { ChartsModule, Color } from 'ng2-charts';
declare var $: any;

declare var jQuery: any;
@Component({
  selector: 'app-compare-appliances',
  templateUrl: './compare-appliances.component.html',
  styleUrls: ['./compare-appliances.component.css']
})
export class CompareAppliancesComponent implements OnInit {
  @Input() selectedAppliances: any = [];
  @Input() allAppliances: any = [];
  @Output() messageEvent = new EventEmitter<String>();
  unselectedAppliancesList: any = [];
  applianceList: any = [];
  message: string;
  constructor() { }
  // Doughnut
  public doughnutChartLabels: string[] = ['Used', 'Available'];
  public doughnutChartData: number[] = [];
  public doughnutChartType: string = 'doughnut';

  ngOnInit() {
    this.unselectedAppliancesList = this.allAppliances;
    this.createSelectedAppliancesList();

  }


  createSelectedAppliancesList() {
    this.selectedAppliances.forEach(obj => {
      let applianceObj = {
        "partitionList": []
      };
      applianceObj["appName"] = obj.applianceName;
      applianceObj["appId"] = obj.applianceId;
      applianceObj["status"] = obj.applianceStatus;
      let usedSize: number = 0;
      let availableSize: number = 0;
      let partitionSize: number = 0;
      let doughnutChartData: number[] = [];
      obj.partitionDetailModels.forEach(partitionObj => {
        let partition = {};
        partition["name"] = partitionObj.partitionName;
        partition["size"] = partitionObj.partitionSize;
        partition["type"] = partitionObj.partitionType;
        usedSize = usedSize + parseInt(partitionObj.partitionUsedSize);
        availableSize = availableSize + parseInt(partitionObj.partitionAvailableSize);
        partitionSize = partitionSize + parseInt(partitionObj.partitionSize);
        applianceObj.partitionList.push(partition);
      });
      if (usedSize != 0) {
        doughnutChartData.push(usedSize);
      }
      if (availableSize != 0) {
        doughnutChartData.push(availableSize);
      }
      applianceObj["partitionSize"] = partitionSize;
      applianceObj["donutData"] = doughnutChartData;
      this.applianceList.push(applianceObj);
      console.log(this.applianceList);
    });
  }
  public chartOptions = {
    responsive: true,
    legend: {
      display: true,
      position: 'right',
      labels: {
        boxWidth: 10
      }
    }
  };

  public mycolors: Array<Color> = [
    {
      backgroundColor: [
        'rgba(244, 99, 132, 0.8)',
        'rgba(64, 162, 235, 0.8)',
        'rgba(255, 206, 86, 0.8)',
        'rgba(70, 192, 192, 0.8)',
        'rgba(287, 159, 64, 0.8)',
        'rgba(153, 102, 255, 0.8)',
        "#e28e41", "#3366cc", "#109618", "#dc3921"],
      hoverBackgroundColor: ["#e28e41", "#3366cc", "#109618",
        "#dc3912", "#8dcd8d", "#41545e",
        "#01acb2", "#e8681e", "#700e6e",
        "#d119b8"],
    }
  ];

  closeAppliance() {
    this.applianceList = []
    this.selectedAppliances = [];
    this.messageEvent.emit("false");
  }

  addMore() {
    let selectedIds = [];
    selectedIds = this.selectedAppliances.map(item => item.applianceId);
    this.unselectedAppliancesList = this.unselectedAppliancesList.filter(
      val => !selectedIds.includes(val.applianceId));
    $("#listappliances").modal("show");
  }

  closeModal() {
    $("#listappliances").modal("hide");
  }


  selectAppliances(event, applianceId) {
    if (event.checked) {
      this.allAppliances.find
        (appliance => {
          if (appliance.applianceId == applianceId) {
            this.selectedAppliances.push(appliance);
          }
        })
    } else {
      this.allAppliances.find
        (appliance => {
          if (appliance.applianceId == applianceId) {
            let index = this.selectedAppliances.indexOf(applianceId);
            this.selectedAppliances.splice(index);
          }
        })
    }
  }

  showAppliances() {
    this.message = '';
    this.checkValidationsForAppliances();
  }

  checkValidationsForAppliances() {
    if (this.selectedAppliances.length > 6) {
      this.message = "Maximum appliances to compare is 6.";

    } else {
      this.applianceList = [];
      this.createSelectedAppliancesList();
      this.closeModal();
    }
  }

  removeAppliance(applianceId) {
    debugger;
    // this.unselectedAppliancesList = this.unselectedAppliancesList.filter(
    //   val => !appId.includes(val.applianceId));

    //   console.log( this.unselectedAppliancesList);
    let selectedIds=[];
    selectedIds.push(applianceId);
    this.selectedAppliances = this.selectedAppliances.filter(
      val => !selectedIds.includes(val.applianceId));
      console.log(this.selectedAppliances);

  
      this.showAppliances();

  }

}
