import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-by-discovery',
  templateUrl: './add-by-discovery.component.html',
  styleUrls: ['./add-by-discovery.component.css']
})
export class AddByDiscoveryComponent implements OnInit {
  displayErrors: any = [];
  successMessage : string;
  constructor() { }

  ngOnInit() {
  }

}
