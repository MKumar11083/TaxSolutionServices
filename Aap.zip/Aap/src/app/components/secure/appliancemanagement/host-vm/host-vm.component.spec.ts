import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HostVmComponent } from './host-vm.component';

describe('HostVmComponent', () => {
  let component: HostVmComponent;
  let fixture: ComponentFixture<HostVmComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HostVmComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HostVmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
