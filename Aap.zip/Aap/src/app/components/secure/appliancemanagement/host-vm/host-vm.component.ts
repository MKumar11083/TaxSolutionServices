import { Component, OnInit } from '@angular/core';
import {ChartsModule, Color} from 'ng2-charts'; 
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';

declare var $: any;
declare var Highcharts: any;


@Component({
  selector: 'app-host-vm',
  templateUrl: './host-vm.component.html',
  styleUrls: ['./host-vm.component.css']
})
export class HostVmComponent implements OnInit {
  resourceUsage:any = [];
  hostInfo:any = [];
  adapterInfo:any = [];
  stats:any = [];
  showlist :  boolean = true;
  showlist1 : boolean = true;
  showlist2 : boolean = true;

  public temp: any[] = [[25, 22]];
  constructor(private _applianceManagementService: AppliancemanagementService) { }

  ngOnInit() {

    this._applianceManagementService.getHostSystemInfo().subscribe(
      res => {
        this.resourceUsage = res.partitionsDetails;
        console.log("hello", this.resourceUsage); 
        this.hostInfo = res.applianceInfo;
        console.log("hello", this.hostInfo); 
        this.adapterInfo = res.hsmInfo;
        console.log("hello", this.adapterInfo); 
        this.stats = res.hostStats;
        console.log("hello", this.stats); 

        if(this.stats!=null){
          if(this.stats.dataObject!=null){
            if(this.stats.dataObject.vmstatsObject!=null){
          this.gaugeValue = this.stats.dataObject.vmstatsObject.cpuUsage;
      }
    }
  }
        if(this.stats!=null){
          if(this.stats.dataObject!=null){
            if(this.stats.dataObject.vmstatsObject!=null){
              if(this.stats.dataObject.vmstatsObject.ramStats!=null){
          this.gaugeValue2 = this.stats.dataObject.vmstatsObject.ramStats.usedPercentage;
        }
      }
    }
  }
       if(this.stats!=null){
          if(this.stats.dataObject!=null){
            if(this.stats.dataObject.vmstatsObject!=null){
              if(this.stats.dataObject.vmstatsObject.swapStats!=null){
          this.gaugeValue3 = this.stats.dataObject.vmstatsObject.swapStats.usedPercentage;
        }
      }
    }
  }

        // if(this.stats.dataObject!=null){
        //   if(this.stats.dataObject.vmstatsObject!=null){
        //     if(this.stats.dataObject.vmstatsObject.ramStats!=null){
        //       console.log("ramStats", this.stats.dataObject.vmstatsObject.ramStats.total); 
        //   }
        // }
        // }
        this.doughnutChartData.push(this.resourceUsage.occupiedKeys);
        this.doughnutChartData.push(this.resourceUsage.freeKeys);

        this.doughnutChartData1.push(this.resourceUsage.occupiedAcclrDev);
        this.doughnutChartData1.push(this.resourceUsage.freeAcclrDev);

        this.doughnutChartData2.push(this.resourceUsage.occupiedContexts);
        this.doughnutChartData2.push(this.resourceUsage.freeContexts);
        

        //response.forEach(element => {
          //   console.log(element);
      },
      error => {
        console.log(error);
      },
    );
    Highcharts.chart('container', {
      chart: {
        type: 'area'
      },
      
      xAxis: {
        categories: ['18:10', '18:20', '18:30','18:40','18:50'],
        tickmarkPlacement: 'on',
        title: {
          text:'TIME',
          enabled: true
        }
      },
      credits:{enabled:false},
      exporting: { enabled: false },
      yAxis: {
        title: {
          text: 'MB'
        },
        labels: {
          formatter: function () {
            return this.value / 1000;
          }
        }
      },
      tooltip: {
        split: true,
        valueSuffix: 'MB'
      },
      plotOptions: {
        area: {
          stacking: 'normal',
          lineColor: '#666666',
          lineWidth: 1,
          marker: {
            lineWidth: 1,
            lineColor: '#666666'
          }
        }
      },
      series: [{
        name: 'Free Space',
        data: [37, 25, 39,42,50]
      }, {
        name: 'Cache',
        data: [16, 17, 11,23,26]
      }, {
        name: 'Buffered',
        data: [13, 23, 26,45,31]
      }, {
        name: 'Used',
        data: [18, 31, 54,32,62]
      }, {
        name: 'Shared',
        data: [12, 22, 32,15,26]
      }]
    });
  
    

    Highcharts.setOptions({
      chart: {
          inverted: true,
          marginLeft: 135,
          type: 'bullet'
      },
      title: {
          text: null
      },
      legend: {
          enabled: false
      },
      yAxis: {
          gridLineWidth: 0
      },
      plotOptions: {
          series: {
              pointPadding: 0.25,
              borderWidth: 0,
              color: '#000',
              targetOptions: {
                  width: '200%'
              }
          }
      },
      credits: {
          enabled: false
      },
      exporting: {
          enabled: false
      }
  });
   
  Highcharts.chart('temperature', {
    chart: {
        marginTop: 40
    },
    title: {
        text: 'Adapter Temperature'
    },
    xAxis: {
         categories: ['']
    },
    yAxis: {
        plotBands: [{
            from: 0,
            to: 150,
            color: '#66CC33'
        }, {
            from: 150,
            to: 225,
            color: '#FFCC00'
        }, {
            from: 225,
            to: 9e9,
            color: '#CC3300'
        }],
        title: null
    },
    series: [{
        data: [{
            y: 275,
            target: 250
        }]
    }],
    tooltip: {
        pointFormat: '<b>{point.y}</b> '
    }
});
  
  
  
  }

  toggle(){
    this.showlist = true;
  }
  toggle1(){
    this.showlist = false;
  }

  toggle2(){
    this.showlist1 = true;
  }
  toggle3(){
    this.showlist1 = false;
  }

  toggle4(){
    this.showlist2 = true;
  }
  toggle5(){
    this.showlist2 = false;
  }

   //Doughnut
   public doughnutChartData:number[] = [];
   public doughnutChartData1:number[] = [];
   public doughnutChartData2:number[] = [];
   public doughnutChartType:string = 'doughnut';
   public doughnutChartLabels:string[] = ['Used', 'Available'];
   public chartOptions = {
     responsive: true,
     legend: {
     display: true,
     position: 'bottom',
     labels :{
     boxWidth: 10
     }
     } 
     }; 
   public mycolors: Array<Color> = [
     {
     backgroundColor:[ 
      //'rgba(244, 99, 132, 0.8)',
     //'rgba(64, 162, 235, 0.8)',
     // 'rgba(255, 206, 86, 0.8)',
     // 'rgba(70, 192, 192, 0.8)',
     // 'rgba(287, 159, 64, 0.8)',
     // 'rgba(153, 102, 255, 0.8)',
     'rgb(247, 113, 131)',
     'rgb(84, 198, 233)'],
     hoverBackgroundColor: [  'rgb(247, 113, 131)','rgb(84, 198, 233)'],
     }
     ]; 
  
   // events
   public chartClicked(e:any):void {
     console.log(e);
   }
  
   public chartHovered(e:any):void {
     console.log(e);
   }

  gaugeType = "arch";
  gaugeThickness=25;
  gaugeThresholdConfig = {
    '0': {color: 'rgb(0,179,30'},
    '60': {color:'rgb(230,191,0'},
    '80': {color:'rgb(204,0,0'}
  };
  gaugeAppendText = "%";
  
  // hostVM gauge
  gaugeValue = [];
  gaugeValue1 = 67;
  gaugeValue2 = [];
  gaugeValue3 = [];

  // adminVM gauge
  gaugeValue4 = 7;
  gaugeValue5 = 67;
  gaugeValue6 = 90;
  gaugeValue7 =  0;


  // lineChart1
  public lineChartData:Array<any> = [
    {data: [18, 48, 77, 9, 100, 27, 40], label: 'Series A'},
    {data: [28, 48, 40, 19, 86, 27, 90], label: 'Series B'},
  ];
  public lineChartLabels:Array<any> = ['16:10', '16:20', '16:30', '16:40', '16:50', '17:00', '17:20'];
  public lineChartOptions:any = {
    responsive: true,
    legend: {
      display: true,
      position: 'bottom'
      } 
  };
  public lineChartColors:Array<any> = [
    { // red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
    },
    
    { // blue
      backgroundColor: 'rgba(255,255,255,0.2)',
      borderColor: 'rgba(0,170,204,1)',
      pointBackgroundColor: 'rgba(0,170,204,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(0,170,204,1)'
    },

  ];
  public lineChartLegend:boolean = true;
  public lineChartType:string = 'line';

  // events
  public chartClicked1(e:any):void {
    console.log(e);
  }
 
  public chartHovered1(e:any):void {
    console.log(e);
  }

   // lineChart2
   public lineChartData2:Array<any> = [
    {data: [18, 48, 77, 9, 100, 27, 40], label: 'Series A'},
    {data: [28, 48, 40, 19, 86, 27, 90], label: 'Series B'},
  ];
  public lineChartLabels2:Array<any> = ['16:10', '16:20', '16:30', '16:40', '16:50', '17:00', '17:20'];
  public lineChartOptions2:any = {
    responsive: true,
    legend: {
      display: true,
      position: 'bottom'
      } 
  };
  public lineChartColors2:Array<any> = [
    { // red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
    },
    
    { // blue
      backgroundColor: 'rgba(255,255,255,0.2)',
      borderColor: 'rgba(0,170,204,1)',
      pointBackgroundColor: 'rgba(0,170,204,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(0,170,204,1)'
    },

  ];
  public lineChartLegend2:boolean = true;
  public lineChartType2:string = 'line';

  // events
  public chartClicked2(e:any):void {
    console.log(e);
  }
 
  public chartHovered2(e:any):void {
    console.log(e);
  }

 
// lineChart3
public lineChartData3:Array<any> = [
  {data: [40, 59, 55, 81, 56, 55, 40], label: 'Series A'},
  {data: [28, 48, 40, 19, 86, 27, 60], label: 'Series B'},
];
public lineChartLabels3:Array<any> = ['18:10', '18:20', '18:30', '18:40','18:50', '19:00', '19:10'];
public lineChartOptions3:any = {
  responsive: true,
  legend: {
    display: true,
    position: 'bottom'
    } 
};
public lineChartColors3:Array<any> = [
  { // blue
    backgroundColor: 'rgba(0,149,179,0)',
    borderColor: 'rgba(0,149,179,1)',
    pointBackgroundColor: 'rgba(0,149,179,1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(0,149,179,0.8)'
  },
  { // yellow
    backgroundColor: 'rgba(230,230,0,0)',
    borderColor: 'rgba(230,230,0,1)',
    pointBackgroundColor: 'rgba(230,230,0,1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(230,230,0,1)'
  },
  
];
public lineChartLegend3:boolean = true;
public lineChartType3:string = 'line';


// events
public chartClicked3(e:any):void {
  console.log(e);
}

public chartHovered3(e:any):void {
  console.log(e);
}

// lineChart4
public lineChartData4:Array<any> = [
  {data: [65, 59, 80, 81, 56, 55, 40], label: 'Series A'},
  {data: [28, 48, 40, 19, 86, 27, 90], label: 'Series B'},
  {data: [18, 48, 77, 9, 100, 27, 40], label: 'Series C'},
  {data: [40, 90, 56, 70, 30, 27, 40], label: 'Series D'},

];
public lineChartLabels4:Array<any> = ['18:10', '18:20', '18:30', '18:40','18:50', '19:00', '19:10'];
public lineChartOptions4:any = {
  responsive: true,
  legend: {
    display: true,
    position: 'bottom'
    } 
};
public lineChartColors4:Array<any> = [
  { // blue
    backgroundColor: 'rgba(0,149,179,0)',
    borderColor: 'rgba(0,149,179,1)',
    pointBackgroundColor: 'rgba(0,149,179,1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(0,149,179,0.8)'
  },
  { // yellow
    backgroundColor: 'rgba(230,230,0,0)',
    borderColor: 'rgba(230,230,0,1)',
    pointBackgroundColor: 'rgba(230,230,0,1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(230,230,0,1)'
  },
  
  { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
  },
  
  { //green
    backgroundColor: 'rgba(34,204,0,0)',
    borderColor: 'rgba(34,204,0,1)',
    pointBackgroundColor: 'rgba(34,204,0,1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(34,204,0,0.8)'
  },
  
];
public lineChartLegend4:boolean = true;
public lineChartType4:string = 'line';


// events
public chartClicked4(e:any):void {
  console.log(e);
}

public chartHovered4(e:any):void {
  console.log(e);
}


// lineChart5
public lineChartData5:Array<any> = [
  {data: [25, 40, 30, 81, 56, 55, 40], label: 'Outgoing'},
  {data: [12, 20, 15, 18, 25, 15, 26], label: 'Incoming'},

];
public lineChartLabels5:Array<any> = ['18:10', '18:20', '18:30', '18:40','18:50', '19:00', '19:10'];
public lineChartOptions5:any = {
  responsive: true,
  legend: {
    display: true,
    position: 'bottom'
    } 
};
public lineChartColors5:Array<any> = [
  { // blue
    backgroundColor: 'rgba(0,149,179,0)',
    borderColor: 'rgba(0,149,179,1)',
    pointBackgroundColor: 'rgba(0,149,179,1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(0,149,179,0.8)'
  },

  { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
  },
  
];
public lineChartLegend5:boolean = true;
public lineChartType5:string = 'line';


// events
public chartClicked5(e:any):void {
  console.log(e);
}

public chartHovered5(e:any):void {
  console.log(e);
}

// lineChart6
public lineChartData6:Array<any> = [
  {data: [25, 40, 30, 81, 56, 55, 40], label: 'Outgoing'},
  {data: [12, 20, 15, 18, 25, 15, 26], label: 'Incoming'},

];
public lineChartLabels6:Array<any> = ['18:10', '18:20', '18:30', '18:40','18:50', '19:00', '19:10'];
public lineChartOptions6:any = {
  responsive: true,
  legend: {
    display: true,
    position: 'bottom'
    } 
};
public lineChartColors6:Array<any> = [
  { // blue
    backgroundColor: 'rgba(0,149,179,0)',
    borderColor: 'rgba(0,149,179,1)',
    pointBackgroundColor: 'rgba(0,149,179,1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(0,149,179,0.8)'
  },

  { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
  },
  
];
public lineChartLegend6:boolean = true;
public lineChartType6:string = 'line';


// events
public chartClicked6(e:any):void {
  console.log(e);
}

public chartHovered6(e:any):void {
  console.log(e);
}

// lineChart7
public lineChartData7:Array<any> = [
  {data: [65, 59, 80, 81, 56, 55, 40], label: 'Series A'},
  {data: [28, 48, 40, 19, 86, 27, 90], label: 'Series B'},
  {data: [18, 48, 77, 9, 100, 27, 40], label: 'Series C'},
  {data: [40, 90, 56, 70, 30, 27, 40], label: 'Series D'},

];
public lineChartLabels7:Array<any> = ['18:10', '18:20', '18:30', '18:40','18:50', '19:00', '19:10'];
public lineChartOptions7:any = {
  responsive: true,
  legend: {
    display: true,
    position: 'bottom'
    } 
};
public lineChartColors7:Array<any> = [
  { // blue
    backgroundColor: 'rgba(0,149,179,0)',
    borderColor: 'rgba(0,149,179,1)',
    pointBackgroundColor: 'rgba(0,149,179,1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(0,149,179,0.8)'
  },
  { // yellow
    backgroundColor: 'rgba(230,230,0,0)',
    borderColor: 'rgba(230,230,0,1)',
    pointBackgroundColor: 'rgba(230,230,0,1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(230,230,0,1)'
  },
  
  { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
  },
  
  { //green
    backgroundColor: 'rgba(34,204,0,0)',
    borderColor: 'rgba(34,204,0,1)',
    pointBackgroundColor: 'rgba(34,204,0,1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(34,204,0,0.8)'
  },
  
];
public lineChartLegend7:boolean = true;
public lineChartType7:string = 'line';


// events
public chartClicked7(e:any):void {
  console.log(e);
}

public chartHovered7(e:any):void {
  console.log(e);
}

// lineChart8
public lineChartData8:Array<any> = [
  {data: [25, 40, 30, 81, 56, 55, 40], label: 'Outgoing'},
  {data: [12, 20, 15, 18, 25, 15, 26], label: 'Incoming'},

];
public lineChartLabels8:Array<any> = ['18:10', '18:20', '18:30', '18:40','18:50', '19:00', '19:10'];
public lineChartOptions8:any = {
  responsive: true,
  legend: {
    display: true,
    position: 'bottom'
    } 
};
public lineChartColors8:Array<any> = [
  { // blue
    backgroundColor: 'rgba(0,149,179,0)',
    borderColor: 'rgba(0,149,179,1)',
    pointBackgroundColor: 'rgba(0,149,179,1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(0,149,179,0.8)'
  },

  { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
  },
  
];
public lineChartLegend8:boolean = true;
public lineChartType8:string = 'line';


// events
public chartClicked8(e:any):void {
  console.log(e);
}

public chartHovered8(e:any):void {
  console.log(e);
}

// lineChart9
public lineChartData9:Array<any> = [
  {data: [25, 40, 30, 81, 56, 55, 40], label: 'Outgoing'},
  {data: [12, 20, 15, 18, 25, 15, 26], label: 'Incoming'},

];
public lineChartLabels9:Array<any> = ['18:10', '18:20', '18:30', '18:40','18:50', '19:00', '19:10'];
public lineChartOptions9:any = {
  responsive: true,
  legend: {
    display: true,
    position: 'bottom'
    } 
};
public lineChartColors9:Array<any> = [
  { // blue
    backgroundColor: 'rgba(0,149,179,0)',
    borderColor: 'rgba(0,149,179,1)',
    pointBackgroundColor: 'rgba(0,149,179,1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(0,149,179,0.8)'
  },

  { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
  },
  
];
public lineChartLegend9:boolean = true;
public lineChartType9:string = 'line';


// events
public chartClicked9(e:any):void {
  console.log(e);
}

public chartHovered9(e:any):void {
  console.log(e);
}

// lineChart10
public lineChartData10:Array<any> = [
  {data: [70, 59, 83, 81, 60, 87, 83], label: 'Head'},
  {data: [65, 48, 55, 50, 56, 60, 78], label: 'Tail'},
  {data: [45, 35, 45, 65, 47, 52, 40], label: 'Head'},
  {data: [27, 22, 33, 30, 38, 27, 32], label: 'Tail'},

];
public lineChartLabels10:Array<any> = ['18:10', '18:20', '18:30', '18:40','18:50', '19:00', '19:10'];
public lineChartOptions10:any = {
  responsive: true,
  legend: {
    display: true,
    position: 'bottom'
    } 
};
public lineChartColors10:Array<any> = [
  { // blue
    backgroundColor: 'rgba(0,102,204,0)',
    borderColor: 'rgba(0,102,204,1)',
    pointBackgroundColor: 'rgba(0,102,204,1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(0,102,204,0.8)'
  },
  { //green
    backgroundColor: 'rgba(89,179,0,0)',
    borderColor: 'rgba(89,179,0,1)',
    pointBackgroundColor: 'rgba(89,179,0,1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(89,179,0,0.8)'
  },
  
  { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
  },
  
  { // purple
    backgroundColor: 'rgba(102,0,153,0)',
    borderColor: 'rgba(102,0,153,1)',
    pointBackgroundColor: 'rgba(102,0,153,1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(102,0,153,1)'
  },
  
];
public lineChartLegend10:boolean = true;
public lineChartType10:string = 'line';


// events
public chartClicked10(e:any):void {
  console.log(e);
}

public chartHovered10(e:any):void {
  console.log(e);
}

// lineChart11
public lineChartData11:Array<any> = [
  {data: [70, 59, 83, 81, 60, 87, 83], label: 'Head'},
  {data: [65, 48, 55, 50, 56, 60, 78], label: 'Tail'},
  {data: [45, 35, 45, 65, 47, 52, 40], label: 'Head'},
  {data: [27, 22, 33, 30, 38, 27, 32], label: 'Tail'},
];
public lineChartLabels11:Array<any> = ['18:10', '18:20', '18:30', '18:40','18:50', '19:00', '19:10'];
public lineChartOptions11:any = {
  responsive: true,
  legend: {
    display: true,
    position: 'bottom'
    } 
};
public lineChartColors11:Array<any> = [
  { // blue
    backgroundColor: 'rgba(0,102,204,0)',
    borderColor: 'rgba(0,102,204,1)',
    pointBackgroundColor: 'rgba(0,102,204,1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(0,102,204,0.8)'
  },
  { //green
    backgroundColor: 'rgba(89,179,0,0)',
    borderColor: 'rgba(89,179,0,1)',
    pointBackgroundColor: 'rgba(89,179,0,1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(89,179,0,0.8)'
  },
  
  { //red
      backgroundColor: 'rgba(255,255,255,0)',
      borderColor: 'rgba(255,51,85,1)',
      pointBackgroundColor: 'rgba(255,51,85,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(255,51,85,0.8)'
  },
  
  { // purple
    backgroundColor: 'rgba(102,0,153,0)',
    borderColor: 'rgba(102,0,153,1)',
    pointBackgroundColor: 'rgba(102,0,153,1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(102,0,153,1)'
  },
  
];
public lineChartLegend11:boolean = true;
public lineChartType11:string = 'line';


// events
public chartClicked11(e:any):void {
  console.log(e);
}

public chartHovered11(e:any):void {
  console.log(e);
}






  
}
