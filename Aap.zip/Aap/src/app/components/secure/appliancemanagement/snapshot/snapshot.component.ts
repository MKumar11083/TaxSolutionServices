import { Component, OnInit } from '@angular/core';
import  { ChartsModule,  Color }  from  'ng2-charts';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
declare var Chart: any;
declare var Morris: any;
@Component({
  selector: 'app-snapshot',
  templateUrl: './snapshot.component.html',
  styleUrls: ['./snapshot.component.css']
})
export class SnapshotComponent implements OnInit {
  recentActivityList: any = [];
  resourceUsage: any = [];
  private details: string;
  constructor(private _applianceManagementService: AppliancemanagementService) { }
  public topologyDoughnutChartLabel: string[] = ['Active','Inactive','Suspended'];
  public topologyDoughnutChartData: number[] = [];
  public topologyDoughnutChartType: string = 'doughnut';
  myBarChart : any;
  ngOnInit() {
    this._applianceManagementService.getAllSnapshotDetails().subscribe(
      res => {
        console.log(res);
        //this.recentActivityList = res.recentActivity;
       let colors = ["blue","red","green"];
       let count  = 0;
        res.recentActivity.forEach(element => {
          let recentActivity ={};
          if(count==3){
            count = 0;
          }
          recentActivity['message']= element.message;
          recentActivity['color']=colors[count];
          this.recentActivityList.push(recentActivity);
          count++;
        });
        console.log("hello", this.recentActivityList);
        this.resourceUsage = res.partitionsDetails;
        console.log("hello", this.resourceUsage);
        if (this.resourceUsage != null) {
          let availableKeys = this.resourceUsage.totalKeys - this.resourceUsage.occupiedKeys;
          this.doughnutChartData.push(this.resourceUsage.occupiedKeys);
          this.doughnutChartData.push(availableKeys);

          let availableDevices = this.resourceUsage.totalAcclrDev - this.resourceUsage.occupiedAcclrDev;
          this.doughnutChartData1.push(this.resourceUsage.occupiedAcclrDev);
          this.doughnutChartData1.push(availableDevices);

          let availableContexts = this.resourceUsage.totalContexts - this.resourceUsage.occupiedContexts;
          this.doughnutChartData2.push(this.resourceUsage.occupiedContexts);
          this.doughnutChartData2.push(availableContexts);

        }
        this.listApplianceToplology = res.listApplianceToplology;
        this.createTopologyBarChart();
        this.createTopologyDonutChart();

      },
      error => {
        console.log(error);
      },
    );
  }
  listApplianceToplology = []
  createTopologyBarChart() {
    
    var barlabels = this.listApplianceToplology.map(item => item.cityName)
    var d0 = this.listApplianceToplology.map(item => item.applianceStatus.activeStatus);
    var d1 = this.listApplianceToplology.map(item => item.applianceStatus.inactiveStatus);
    var d2 = this.listApplianceToplology.map(item => item.applianceStatus.suspendedStatus);
   
   this. myBarChart= new Chart(document.getElementById("topology-bar"), {
      type: 'bar',
      data: {
        labels: barlabels,
        datasets: [
          {
            label: "Active",
            backgroundColor: "rgb(64, 197, 64)",
            data: d0
          }, {
            label: "Inactive",
            backgroundColor: "rgba(235, 109, 107, 0.911)",
            data: d1
          },
          {
            label: "Suspend",
            backgroundColor: "rgba(247, 220, 67, 0.911)",
            data: d2
          }
        ]
      },
      options: {
        title: {
          display: true,
          text: ''
        }, scales: {
          yAxes: [{
            scaleLabel: {
              display: true,
              labelString: "",
              gridLines: {
                drawBorder: true,
              },
            }
          }],
          xAxes: [{
            barPercentage: 0.9,
            scaleLabel: {
              display: true,
              labelString: ""
            }
          }]
        }
      }
    });
  }
  createTopologyDonutChart(){
    let activeStatus : number = 0;
    let inactiveStatus : number = 0;
    let suspendedStatus : number = 0;
    //var barlabels = this.listApplianceToplology.map(item => item.cityName)
    this.listApplianceToplology.forEach(obj => {
      activeStatus = activeStatus+parseInt(obj.applianceStatus.activeStatus);
      inactiveStatus =inactiveStatus+parseInt(obj.applianceStatus.inactiveStatus);
      suspendedStatus=suspendedStatus+parseInt(obj.applianceStatus.suspendedStatus);
    });
    this.topologyDoughnutChartData.push(activeStatus);
    this.topologyDoughnutChartData.push(inactiveStatus);
    this.topologyDoughnutChartData.push(suspendedStatus);
  }

  public barChartOptions: any = {
    scaleShowVerticalLines: false,
    responsive: true,
    legend: {
      display: true,
      position: 'bottom',
      labels :{
        boxWidth: 10
      }
    } 
  };
  public barChartLabels: string[] = ["Ban","Hyd","Mum"];
  public barChartType: string = 'bar';
  public barChartLegend: boolean = false;




  //Doughnut
  public doughnutChartData: number[] = [];
  public doughnutChartData1: number[] = [];
  public doughnutChartData2: number[] = [];
  public doughnutChartType: string = 'doughnut';
  public doughnutChartLabels: string[] = ['Used', 'Available'];
  public  chartOptions  =  {
    responsive:  true,
    legend:  {
      display:  true,
      position:  'bottom',
      labels: {
        boxWidth:  10
      }
    }
  };
  public donutcolors:  Array<Color>  =  [
    {
      backgroundColor: [
          'rgb(64, 197, 64)',
          'rgba(235, 109, 107, 0.911)',
         'rgba(247, 220, 67, 0.911)'
        ]
    }
  ];
  public  mycolors:  Array<Color>  =  [
    {
      backgroundColor: [
        //'rgba(244, 99, 132, 0.8)',
        //'rgba(64, 162, 235, 0.8)',
        // 'rgba(255, 206, 86, 0.8)',
        // 'rgba(70, 192, 192, 0.8)',
        // 'rgba(287, 159, 64, 0.8)',
        // 'rgba(153, 102, 255, 0.8)',
        'rgb(247, 113, 131)',
        'rgb(84, 198, 233)'],
      hoverBackgroundColor:  ['rgb(247, 113, 131)', 'rgb(84, 198, 233)'],
    }
  ];

  // events
  public chartClicked1(e: any): void {
    console.log(e);
  }

  public chartHovered1(e: any): void {
    console.log(e);
  }

  showBarChart : boolean =true;
  toggleCharts(){
    this.showBarChart = false;
  }

  toggleCharts1(){
    this.showBarChart = true;
  }

}
