import { Component, OnInit } from '@angular/core';
import { AppliancemanagementService } from './../../../../services/appliancemanagement.service';
import { AnonymousSubscription } from "rxjs/Subscription";
import { DataTableResource } from './../../data-table/index';
import { I18nService } from '../../../../services/common/i18n/i18n.service';
import { BreadcrumbService } from './../../../../services/common/breadcrumb.service';
import { FormBuilder,FormGroup } from '@angular/forms';
declare var $: any;
declare var bootbox: any;
declare var jQuery: any;
@Component({
  selector: 'app-list-appliance',
  templateUrl: './list-appliance.component.html',
  styleUrls: ['./list-appliance.component.css'],

})
export class ListApplianceComponent implements OnInit {
  debugger;
  username: string = '';
  password: string = '';
  private groupsList: string;
  private details: string;
  private getInfoMessage: any = [];
  show: boolean = false;
  show1: boolean = false;
  listofAppliances: AnonymousSubscription;
  appliancesList: any = [];
  private selectedCheckboxData: object[] = [];
  itemResource: any;
  displayErrors: any = [];
  showList: boolean = true;
  showListAppliance: boolean = true;
  showCompareAppliance: boolean = false;

  rebootUp: boolean = false;
  rebootdown: boolean = true;
  zeroiseUp: boolean = false;
  zeroisedown: boolean = true;
  firmwareUpgradeUp: boolean = false;
  firmwareUpgradedown: boolean = true;
  selectedAppliances: any = [];
  intializedown : boolean =true;
  intializeUp:boolean=false;
  form: FormGroup;
  searchApplianceSubsc: AnonymousSubscription;

  constructor(private _applianceManagementService: AppliancemanagementService,
    private _I18nService: I18nService, private _breadcrumbService: BreadcrumbService,
    private _formBuilder: FormBuilder,) { }

  ngOnInit() {
    this.createForm();
    this.selectedAppliances = [];
    this._breadcrumbService.getBreadCrumbDetails("list-appliance");
    this._applianceManagementService.getAllListAppliances().subscribe(
      res => {
        this.appliancesList = res;

        console.log("hello", this.appliancesList);

      },
      error => {
        console.log(error);
      },


    );
  }

  over(ip: string) {
    for (var i = 0; i < this.appliancesList.length; i++) {
      if (this.appliancesList[i]["ipAddress"] == ip) {
        this.details = (this.appliancesList[i]);


      }
    }
  }

  toggle() {
    this.showList = false;
  }
  toggle1() {
    this.showList = true;
  }

  onErrorOperation(error) {
    console.log('OnError' + JSON.stringify(error));
    this.displayErrors = this._I18nService.getI18NMessagesForError(error, "", "");
    console.log('errorMessages -->' + JSON.stringify(this.displayErrors));
  }

  getApplianceCheckData(event, value) {

    if (event.target.checked) {
      for (var i = 0; i < this.appliancesList.length; i++) {
        if (this.appliancesList[i]["ipAddress"] == value) {
          this.selectedCheckboxData.push(this.appliancesList[i]);


        }
      }
      this.rebootUp = true;
      this.rebootdown = false;
      this.zeroiseUp = true;
      this.zeroisedown = false;
      this.firmwareUpgradeUp = true;
      this.firmwareUpgradedown = false;
      this.intializeUp =true;
      this.intializedown=false;
    }
    else {

      if (this.selectedCheckboxData.length == 1) {
        this.selectedCheckboxData.pop();
        this.rebootUp = false;
        this.rebootdown = true;
        this.zeroiseUp = false;
        this.zeroisedown = true;
        this.firmwareUpgradeUp = false;
        this.firmwareUpgradedown = true;
        this.intializeUp=false;
        this.intializedown=true;


      }
      else {
        for (var i = 0; i < this.selectedCheckboxData.length; i++) {

          if (this.selectedCheckboxData[i]["ipAddress"] == value) {

            let index = i;
            this.selectedCheckboxData.splice(index, 1);
          }
        }
        if (this.selectedCheckboxData.length == 0) {
          this.rebootUp = false;
          this.rebootdown = true;
          this.zeroiseUp = false;
          this.zeroisedown = true;
          this.firmwareUpgradeUp = false;
          this.firmwareUpgradedown = true;
          this.intializeUp=false;
          this.intializedown=true;
        }
        else {
          this.rebootUp = true;
          this.rebootdown = false;
          this.zeroiseUp = true;
          this.zeroisedown = false;
          this.firmwareUpgradeUp = true;
          this.firmwareUpgradedown = false;
          this.intializeUp =true;
          this.intializedown=false;
        }
      }

    }
    /* if(this.onPageApplianceSent.length!=null || this.localStorageApplianceSent.length!=null)
 
     this.applianceSent.push(this.getValidateRes1[i]);
     debugger;
     this.checkboxFlag=event;
     console.log(this.checkboxFlag);*/


  }
  saveUserData() {

    if (this.selectedCheckboxData.length > 0) {

      for (var i = 0; i < this.selectedCheckboxData.length; i++) {
        this.selectedCheckboxData[i]["userName"] = this.username;
        this.selectedCheckboxData[i]["userPassword"] = this.password;
      }

      this._applianceManagementService.setRebootActivity(JSON.stringify(this.selectedCheckboxData)).subscribe(
        res => {
          this.getInfoMessage = res;

          let message = res[0]["message"];
          bootbox.dialog({
            message: message,
            buttons: {

              ok: {
                label: "Ok",
                className: 'btn btn-primary btn-flat',
                callback: () => location.reload()
              }
            }
          });

        },
        error => {
          console.log(error);
        },


      )
      this.selectedCheckboxData = [];
      this.username = '';
      this.password = '';
    }
    else {
      let message = "Sorry! No appliance selected to reboot."
      bootbox.dialog({
        message: message,
        buttons: {

          ok: {
            label: "Ok",
            className: 'btn btn-primary btn-flat',

          }
        }
      });

    }


  };
  saveUserData1() {
    debugger;
    if (this.selectedCheckboxData.length > 0) {
      debugger;
      for (var i = 0; i < this.selectedCheckboxData.length; i++) {
        this.selectedCheckboxData[i]["userName"] = this.username;
        this.selectedCheckboxData[i]["userPassword"] = this.password;
      }

      this._applianceManagementService.firmwareUpgrade(JSON.stringify(this.selectedCheckboxData)).subscribe(
        res => {
          this.getInfoMessage = res;

          let message = res[0]["message"];
          bootbox.dialog({
            message: message,
            buttons: {

              ok: {
                label: "Ok",
                className: 'btn btn-primary btn-flat',
                callback: () => location.reload()
              }
            }
          });

        },
        error => {
          console.log(error);
        },


      )
      this.selectedCheckboxData = [];
      this.username = '';
      this.password = '';
    }
    else {
      let message = "Sorry! No appliance selected to reboot."
      bootbox.dialog({
        message: message,
        buttons: {

          ok: {
            label: "Ok",
            className: 'btn btn-primary btn-flat',

          }
        }
      });

    }


  };
  saveUserData2() {
    debugger;
    if (this.selectedCheckboxData.length > 0) {
      debugger;
      for (var i = 0; i < this.selectedCheckboxData.length; i++) {
        this.selectedCheckboxData[i]["userName"] = this.username;
        this.selectedCheckboxData[i]["userPassword"] = this.password;
      }

      this._applianceManagementService.setZeroise(JSON.stringify(this.selectedCheckboxData)).subscribe(
        res => {
          this.getInfoMessage = res;

          let message = res[0]["message"];
          bootbox.dialog({
            message: message,
            buttons: {

              ok: {
                label: "Ok",
                className: 'btn btn-primary btn-flat',
                callback: () => location.reload()
              }
            }
          });

        },
        error => {
          console.log(error);
        },


      )
      this.selectedCheckboxData = [];
      this.username = '';
      this.password = '';
    }
    else {
      let message = "Sorry! No appliance selected to reboot."
      bootbox.dialog({
        message: message,
        buttons: {

          ok: {
            label: "Ok",
            className: 'btn btn-primary btn-flat',

          }
        }
      });

    }


  };
  saveIntilaizeData(){
    debugger;
    if(this.selectedCheckboxData.length>0)
    {
    debugger;
    for(var i=0;i<this.selectedCheckboxData.length;i++){
    this.selectedCheckboxData[i]["userName"]=this.username;
    this.selectedCheckboxData[i]["userPassword"]=this.password;
  }
    
    // this._applianceManagementService.setRebootActivity(JSON.stringify(this.selectedCheckboxData)).subscribe(
    //   res => {
    //     this.getInfoMessage = res;

    //     let message = "Appliances added successfully.Please click OK to continue.";
    // bootbox.dialog({
    //   message: message,
    //   buttons: {
        
    //     ok: {
    //       label: "Ok",
    //       className: 'btn btn-primary btn-flat',
    //       callback: () => location.reload()
    //     }
    //   }
    // });

    //   },
    //   error => {
    //     console.log(error);
    //   },
   

    // )
    this.selectedCheckboxData=[];
    this.username='';
    this.password='';
  }
  else{
    let message ="Sorry! No appliance selected to reboot."
    bootbox.dialog({
      message: message,
      buttons: {
        
        ok: {
          label: "Ok",
          className: 'btn btn-primary btn-flat',
          
        }
      }
    });

  }
    
  };
  compareAppliance() {
    this.showListAppliance = false;
    this.showCompareAppliance = true;
    this.checkValidationsForAppliances();
  }

  checkValidationsForAppliances() {
    if (this.selectedAppliances.length <= 1) {
      this.showListAppliance = true;
      this.showCompareAppliance = false;
      let message = "<b class=text-red>Please select atleast two appliance to compare</b>";
      bootbox.dialog({
        message: message,
        buttons: {
          cancel: {
            label: "Cancel",
            className: 'btn btn-primary btn-flat'
          }
        }
      });
    } else if (this.selectedAppliances.length > 6) {
      this.showListAppliance = true;
      this.showCompareAppliance = false;
      let message = "<b class=text-red>Maximum appliances to compare is 6.</b>";
      bootbox.dialog({
        message: message,
        buttons: {
          cancel: {
            label: "Cancel",
            className: 'btn btn-primary btn-flat'
          }
        }
      });
    }
  }
  selectApplianceItems(event, applianceId: string) {
    if (event.target.checked) {
      this.appliancesList.find
        (appliance => {
          if (appliance.applianceId == applianceId) {
            this.selectedAppliances.push(appliance);
          }
        })
    } else {
      this.appliancesList.find
        (appliance => {
          if (appliance.applianceId == applianceId) {
            let index = this.selectedAppliances.indexOf(applianceId);
            this.selectedAppliances.splice(index);
          }
        })
    }
  }
  closeAppliance($event) {
    this.selectedAppliances = [];
    this.showCompareAppliance = false;
    this.showListAppliance = true;
  }
  
  // create form for advanced search.
  createForm() {
    this.form = this._formBuilder.group({
      applianceName: '',
      ipAddress: '',
      applianceStatus: '',
      hostName: '',
      ipmiIp :'',
    });
  }

  // basic search operation
  searchAppliances(id) {
    let applianceDetailsModel = {
      "applianceName": id.value
    }
    this.getSearchResults(applianceDetailsModel);
  }
// show search modal
  showAdvancedSearch(){
    $("#searchModel").modal("show");
    //this.getUserGroupAndACLDetails();
    this.form.reset();
  }

  // advance search operation
  advanceSearchAppliances() {
    this.getSearchResults(this.form.value);
    $("#searchModel").modal("hide");
  }

// get the search results
  getSearchResults(applianceDetailsModel) {
    this.searchApplianceSubsc = this._applianceManagementService.searchAppliances(applianceDetailsModel).subscribe(
      response => {
        this.appliancesList =response;
        if (response != null) {
          this.itemResource = new DataTableResource(this.appliancesList);
        }
      },
      error => {
        this.onErrorOperation(error);
      }
    )
  }

  // // destroy method 
  // public ngOnDestroy(): void {
  //   if (this.searchUserSubsc) {
  //     this.searchUserSubsc.unsubscribe();
  //   }
  //   if (this.listofUsers) {
  //     this.listofUsers.unsubscribe();
  //   }
  //   if (this.deleteUserSubsc) {
  //     this.deleteUserSubsc.unsubscribe();
  //   }
  // }

}

