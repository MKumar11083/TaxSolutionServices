import { Component, OnInit, OnDestroy, ElementRef, ViewChild,AfterViewInit  } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { NgForm } from '@angular/forms';
import { BreadcrumbService } from './../../../services/common/breadcrumb.service';
import { DataTableResource } from './../../secure/data-table/index';
import { I18nService } from '../../../services/common/i18n/i18n.service';
import { setOption } from './../../../common/select-option';
import { ChartsModule, Color } from 'ng2-charts';

import { AnonymousSubscription } from "rxjs/Subscription";
import { Router } from '@angular/router';
import { LoginService } from './../../../services/login.service';
declare var $: any;
import { BaseChartDirective } from 'ng2-charts/ng2-charts';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit,AfterViewInit {
  stats: any;
   @ViewChild(BaseChartDirective) chart: BaseChartDirective;
	
  constructor(private _breadcrumbService: BreadcrumbService,
    private _router: Router, private _loginService: LoginService,
  ) {

  }
  ngAfterViewInit() {
    this.loadData();
    //this.loadChart3();
}

public barChart3Labels:string[] = ['BLR','CHI','HYD'];
public barChart3Type:string = 'bar';
public barChart3Legend:boolean = true;

public barChart3Data:any[] = [
    {data: [], label: ''}
 
];
public barChart3Colors:Array<any> = [
  { // green
    backgroundColor: 'lightgreen',
    borderColor: 'green'
  },
  { // red
    backgroundColor: 'pink',
    borderColor: 'red'
  }
];
  public barChartOptions: any = {
    scaleShowVerticalLines: false,
    responsive: true,
    legend: {
      display: true,
      position: 'bottom',
      labels :{
        boxWidth: 10
      }
    } 
  };
  public barChartLabels: string[] = ["Ban","Hyd","Mum"];
  public barChartType: string = 'bar';
  public barChartLegend: boolean = false;

  public barChartData: any[] = [
    { data: [65, 59, 80, 81], label: 'Series A'  ,
    fillColor: "#fff",
    strokeColor: "yellow",
    highlightFill: "red",
    highlightStroke: "rgba(151,187,205,1)"}
   
    

 

  ];


  // private datasets_lines: { label: string, data:any }[] = [
  //   {
  //     label: '',
  //     data: []

  //   }
  // ];
  public datasets_lines: any[] = [
    {
      data: [],
      borderWidth: 1,
     
    }
  ]; 

  public barChartData1 = [{
    id:Number,
    label:String,
    value1:Number,
    value2:Number,
    value3:Number
  }]
  private labels_line = Array<any>();
  ngOnInit() {
    this._breadcrumbService.getBreadCrumbDetails("home");
 
  }


  loadData(){
    this._loginService.getTopologyDetails().subscribe(
      response => {

        // $.each(response, (indx, obj)  => {
        //   console.log(indx);
        //   console.log(obj);
        //   let activitystatus ='Numbe';
        //   let inactivestatus =Number;
        //   let suspendstatus =Number;
        //   activitystatus =obj.applianceStatus.activeStatus;
        //    inactivestatus =obj.applianceStatus.inactiveStatus;
        //    suspendstatus =obj.applianceStatus.suspendedStatus;

        //   const data0=[activitystatus,inactivestatus,suspendstatus];
        //    this.barChartData[indx].data = data0;
        // });
        console.log(response);
        this.stats = response;
        this.datasets_lines = [];
        //this.barChart3Data=[];
        let activeArray: any[];
        let inactiveArray: any[];
        let suspendArray: any[];
        activeArray = [];
        inactiveArray = [];
        suspendArray = [];
        console.log(this.stats.map(item => item.cityName));
        console.log(this.stats.map(item => item.applianceStatus.activeStatus));
        console.log(this.stats.map(item => item.applianceStatus.inactiveStatus));
        console.log(this.stats.map(item => item.applianceStatus.suspendedStatus));
       
          //this.barChartLabels.push(stat.cityName);
          // activeArray.push(stat.applianceStatus.activeStatus);
          // inactiveArray.push(stat.applianceStatus.inactiveStatus);
          // suspendArray.push(stat.applianceStatus.suspendedStatus);
          var d0=this.stats.map(item => item.applianceStatus.activeStatus);
          var d1=this.stats.map(item => item.applianceStatus.inactiveStatus);
          var d2=this.stats.map(item => item.applianceStatus.suspendedStatus);
          this.barChart3Data .push (
            { data:  d0, 
                label: 'Active' 
               }
          );
          this.barChart3Data .push (
            { data:  d1, 
                label: 'Inactive' 
               }
          );
          this.barChart3Data .push (
            { data:  d2, 
                label: 'Suspend' 
               }
          );
        //   this.barChart3Data = [
        //     {data: [d0], label: 'Succesful'},
        //     {data: [d1], label: 'Failed'},
        //     {data: [d2], label: 'dsf'}
        // ];
        this.chart.labels =this.barChartLabels;
        this.chart.data = this.barChart3Data;
        console.log(this.barChart3Data);
        $.each(response, (indx, obj)  => {
        this.barChartData1.push(
          {
            id:indx,
            label:obj.cityName,
            value1:obj.applianceStatus.activeStatus,
            value2:obj.applianceStatus.activeStatus,
            value3:obj.applianceStatus.activeStatus,
          }
        )
      });
        let clone = JSON.parse(JSON.stringify(this.barChart3Data));
        clone[0].data = d0;
         clone[1].data = d1;
         clone[2].data = d2;
        console.log(clone);
        this.barChart3Data = clone;
        // this.labels_line = this.getDates();


        console.log(this.barChartData1);
        console.log(this.datasets_lines);
        console.log(this.barChartData);
        // response.forEach(element => {
        //   console.log(element);
        //   let activitystatus =Number;
        //   let inactivestatus =Number;
        //   let suspendstatus =Number;
        //   activitystatus =element.applianceStatus.activeStatus;
        //    inactivestatus =element.applianceStatus.inactiveStatus;
        //    suspendstatus =element.applianceStatus.suspendedStatus;
        //    const data0 = [ activitystatus, inactivestatus,suspendstatus ];
        //  let d = [
        //     { data: [activitystatus,inactivestatus,suspendstatus] ,
        //     label : 'bangalore'},

        //     ];
        //     this.barChartData.push(d);
        // });
        //console.log(this.barChartData);
        // this.dataresponse.forEach(element=>{
        //   let d = [
        //        { data: [element.actvitestatus] ,label : ''},

        //         ];
        //       this.barChartData.push(d);
        // });

      
      }, error => {

      }
    );
  }
  public mycolors: Array<Color> = [
    {
      backgroundColor: [
        'rgba(244, 99, 132, 0.8)',
        'rgba(64, 162, 235, 0.8)',
        'rgba(255, 206, 86, 0.8)',
        'rgba(70, 192, 192, 0.8)',
        'rgba(287, 159, 64, 0.8)',
        'rgba(153, 102, 255, 0.8)',
        "#e28e41", "#3366cc", "#109618", "#dc3921"],
      hoverBackgroundColor: ["#e28e41", "#3366cc", "#109618", "#dc3912", "#8dcd8d", "#41545e", "#01acb2", "#e8681e", "#700e6e", "#d119b8"],
    }
  ];
  public donutChartData = [{
    id: 0,
    label: 'water : 20',
    value: 20,
    color: 'rgba(244, 99, 132, 0.8)',
  }, {
    id: 1,
    label: 'land',
    value: 20,
    color: 'rgba(64, 162, 235, 0.8)',
  }, {
    id: 2,
    label: 'sand',
    value: 30,
    color: 'rgba(255, 206, 86, 0.8)',
  }, {
    id: 3,
    label: 'grass',
    value: 20,
    color: 'rgba(70, 192, 192, 0.8)',
  }];

  public colors = ['rgba(244, 99, 132, 0.8)', 'rgba(64, 162, 235, 0.8)', 'rgba(70, 192, 192, 0.8)']
  //public  dataColumns = [1]; // Single Bar Chart
  public dataColumns = [3]; // Stacked Bar Chart
  //public  dataColumns = [2, 1]; // Multi Stacked Bar Chart
  

  public chartOptions = {
    newLegendLabels: ['NEW: Download Sales'],
    responsive: true,
    legend: {
      display: true,
      position: 'bottom',
      labels: {
        boxWidth: 10
      }
    }
  };




  // Doughnut
  public doughnutChartLabels: string[] = ['Download Sales', 'In-Store Sales', 'Mail-Order Sales'];
  public doughnutChartData: number[] = [350, 450, 100];
  public doughnutChartType: string = 'doughnut';
  public colorType = ['red', 'green', 'blue'];




  // events
  public chartClicked(e: any): void {
    console.log(e);
  }

  public chartHovered(e: any): void {
    console.log(e);
  }

  public randomize(): void {
    // Only Change 3 values
    let data = [
      Math.round(Math.random() * 100),
      59,
      80,
      (Math.random() * 100),
      56,
      (Math.random() * 100),
      40];
    let clone = JSON.parse(JSON.stringify(this.barChartData));
    clone[0].data = data;
    this.barChartData = clone;

  }
  

}

