import { Component, OnInit, OnDestroy } from '@angular/core';
import { BreadcrumbService } from './../../../../services/common/breadcrumb.service';
import { UserGroupManagementService } from './../../../../services/common/user-group-management.service';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, FormControl, FormArray } from '@angular/forms';
import { AnonymousSubscription } from "rxjs/Subscription";
import { Router } from '@angular/router';
import { I18nService } from '../../../../services/common/i18n/i18n.service';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
declare var $: any;
@Component({
  selector: 'app-creategroup',
  templateUrl: './creategroup.component.html',
  styleUrls: ['./creategroup.component.css']
})
export class CreategroupComponent implements OnInit, OnDestroy {
  form: FormGroup;
  applianceList: any = [];
  selectedApplianceList = [];
  unSelectedApplianceList = [];
  successMessage: any = [];
  errorMessages: any = [];
  createGroupSubsc: AnonymousSubscription;
  getApplianceGroupSubsc: AnonymousSubscription;
  constructor(private _breadcrumbService: BreadcrumbService,
    private _userGroupManagementService: UserGroupManagementService,
    private formBuilder: FormBuilder,
    private _I18nService: I18nService,
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private router: Router) { }

  ngOnInit() {
    this._breadcrumbService.getBreadCrumbDetails("create-groups");
    this.createForm();
    this.getApplianceDetails();
    this.selectedApplianceList = [];
    this.unSelectedApplianceList = [];
  }

  createForm() {
    this.form = this.formBuilder.group({
      roleName:['', Validators.required],
      listApplianceIds: '',
      defaultGroupApplianceIds: ''
    });
  }
  public formValidationFields = {
    "roleName": '',
  }

  isFieldValid(field: string) {
    if (this.form.get(field).touched) {
      this.formValidationFields = this._fieldErrorDisplayService.validateField(this.form, field, this.formValidationFields, "modifygroup")
    }
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }
  getApplianceDetails() {
    this.getApplianceGroupSubsc = this._userGroupManagementService.getlistofApplicance().subscribe(
      (res) => {
        res.forEach(appliance => {
          this.unSelectedApplianceList.push(appliance.objApplianceDetailModel.applianceId);
          let obj = {
            "applianceId": appliance.objApplianceDetailModel.applianceId,
            "applianceName": appliance.objApplianceDetailModel.applianceName,
            "applianceStatus": appliance.objApplianceDetailModel.applianceStatus,
          }
          this.applianceList.push(obj);
        });
      },
      (err) => {
        this.onErrorOperation(err);
      }
    );
  }

  checkedItems(event, value) {
    if (event.target.checked) {
      let index = this.unSelectedApplianceList.indexOf(value);
      this.unSelectedApplianceList.splice(index, 1);
      this.selectedApplianceList.push(value);
    } else {
      let index = this.selectedApplianceList.indexOf(value);
      this.selectedApplianceList.splice(index, 1);
      this.unSelectedApplianceList.push(value);
    }
  }
  onSubmit(isValid:boolean) {
    if(isValid){
      this.form.get('listApplianceIds').setValue(this.selectedApplianceList);
      this.form.get('defaultGroupApplianceIds').setValue(this.unSelectedApplianceList);
      this.createGroupSubsc = this._userGroupManagementService.createGroup(this.form.value).subscribe(
        (res) => {
          this.unSelectedApplianceList = [];
          this.selectedApplianceList = [];
          this.onSuccessOperation(res);
        },
        (err) => {
          this.onErrorOperation(err);
        }
      );
    }else{
        this.formValidationFields = this._fieldErrorDisplayService.validateForm(this.form, this.formValidationFields, "modifygroup", false)
        this.scrollToTop();
    }
  }

  onSuccessOperation(response) {
    this.successMessage = [];
    this.errorMessages = [];
    let res = response;
    if (res.responseCode == "200") {
     // this.successMessage.push(res.responseMessage);
     sessionStorage.setItem("msg",res.responseMessage);
     this.router.navigateByUrl("/managegrouplist");
    } else if (res.responseCode == "204" || res.responseCode == "500" || res.responseCode == "-230") {
      this.errorMessages.push(res.responseMessage);
    } else {
      this.errorMessages.push(res.responseMessage);
    }
    this.scrollToTop();
  }


  scrollToTop(){
    window.scrollTo(0, 0);
  }

  onErrorOperation(error) {
    this.scrollToTop();
    console.log('OnError' + JSON.stringify(error));
    this.errorMessages = this._I18nService.getI18NMessagesForError(error, "", "");
    console.log('errorMessages -->' + JSON.stringify(this.errorMessages));
  }

  public ngOnDestroy(): void {
    if (this.createGroupSubsc) {
      this.createGroupSubsc.unsubscribe();
    }
    if (this.getApplianceGroupSubsc) {
      this.getApplianceGroupSubsc.unsubscribe();
    }

  }
}



