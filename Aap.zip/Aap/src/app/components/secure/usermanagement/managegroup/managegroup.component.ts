
import { Component, OnInit, Injectable, ViewChild, OnDestroy } from '@angular/core';
import { BreadcrumbService } from './../../../../services/common/breadcrumb.service';
import { DataTableResource } from './../../data-table/index';
import { UserGroupManagementService } from './../../../../services/common/user-group-management.service';
import { AnonymousSubscription } from "rxjs/Subscription";
import { I18nService } from '../../../../services/common/i18n/i18n.service';
declare var $: any;
declare var bootbox: any;
@Component({
  selector: 'app-managegroup',
  templateUrl: './managegroup.component.html',
  styleUrls: ['./managegroup.component.css']
})
@Injectable()
export class ManagegroupComponent implements OnInit, OnDestroy {

  limit: number;
  pagination: boolean = false;
  groupsList: any = [];
  viewApplianceList: any;
  itemResource: any;
  itemCount = 0;
  show: boolean = false;
  show1: boolean = false;
  selectCount = 0;
  selectedGroupList: any = [];
  displayErrors: any = [];
  successMessage: any = [];
  getGroupListSubsc: AnonymousSubscription;
  deleteGroupSubsc: AnonymousSubscription;
  searchGroupSubsc: AnonymousSubscription;
  constructor(
    private _breadcrumbService: BreadcrumbService,
    private _userGroupManagementService: UserGroupManagementService,
    private _I18nService:I18nService) { }

  ngOnInit() {
    sessionStorage.removeItem("selectedGroupList");
    this._breadcrumbService.getBreadCrumbDetails("manage-groups");
    this.getGroupList();
    this.displayErrors = [];
    this.successMessage = [];
    let successMsg = sessionStorage.getItem("msg");
    if(successMsg!=null){
      this.successMessage.push(successMsg);
    }
    sessionStorage.removeItem("msg");
  }

  getGroupList() {
    this.getGroupListSubsc = this._userGroupManagementService.getGroupList().subscribe(
      res => {
        this.groupsList = res;
        this.itemResource = new DataTableResource(res);
      },
      error => {
        this.onErrorOperation(error);
      },

    )
  }

  searchGroup(searchName) {
    let params={};
    params["roleName"]=searchName;
    this.searchGroupSubsc = this._userGroupManagementService.searchGroup(params).subscribe(
      response => {
        this.groupsList = [];
        if (response != null) {
          this.groupsList = response;
          this.itemResource = new DataTableResource(this.groupsList);
        }
      },
      error => {
        this.onErrorOperation(error);
      }
    )
  }
  checkedItems(event, value) {
    if (event.checked) {
      if (this.selectCount == 0) {
        this.selectCount = 1;
        this.show = true;
        this.show1 = false;
      } else if (this.selectCount > 0) {
        this.selectCount++;
        this.show1 = true;
        this.show = false;
      }
      this.selectedGroupList.push(value);
    } else {
      this.selectCount--;
      if (this.selectCount == 0) {
        this.show = false;
        this.show1 = false;
      } else if (this.selectCount == 1) {
        this.show = true;
        this.show1 = false;
      }
      let index = this.selectedGroupList.indexOf(value);
      this.selectedGroupList.splice(index);
    }
    sessionStorage.setItem("selectedGroupList", this.selectedGroupList);

  }

  bootboxMessage() {

    let message = "Do you want to delete the selected group(s)";
    bootbox.dialog({
      message: message,
      buttons: {
        cancel: {
          label: "Cancel",
          className: 'btn btn-secondary btn-flat'
        },
        ok: {
          label: "OK",
          className: 'btn btn-primary btn-flat',
          callback: () => this.deleteGroups()
        }
      }
    });
  }

  deleteGroups() {
    let groupIds = sessionStorage.getItem("selectedGroupList");
    this.deleteGroupSubsc = this._userGroupManagementService.deleteGroups(groupIds).subscribe(
      data => {
        this.show = false;
        this.show1 = false;
        this.selectCount = 0;
        sessionStorage.removeItem("selectedGroupList");
        this.selectedGroupList = [];
        let groupIds = sessionStorage.getItem("selectedGroupList");
        this.onSuccessOperation(data);
        this.getGroupList();
      },
      err => this.onErrorOperation(err)
    )
  }

  onSuccessOperation(res) {
    this.successMessage = [];
    this.displayErrors =[];
    let responseBody = res.json();
    responseBody.forEach(response => {
      if (response.responseCode == "200") {
        this.successMessage.push(response.responseMessage);
      } else if (response.responseCode == "-230") {
        this.displayErrors.push(response.responseMessage);
      }
    });


  }

  onErrorOperation(error) {
    console.log('OnError' + JSON.stringify(error));
    this.displayErrors = this._I18nService.getI18NMessagesForError(error, "", "");
    console.log('errorMessages -->' + JSON.stringify(this.displayErrors));
  }


  public ngOnDestroy(): void {
    if (this.deleteGroupSubsc) {
      this.deleteGroupSubsc.unsubscribe();
    }
    if (this.getGroupListSubsc) {
      this.getGroupListSubsc.unsubscribe();
    }
    if (this.searchGroupSubsc) {
      this.searchGroupSubsc.unsubscribe();
    }
  }
  /**
  * Reloads the grid with paged data based on the offset and limit sent.
  * 
  * @param {Object} params - The params contains the offset and limit to display.
  */


  reloadItems(params) {
    if (this.itemResource) {
      this.itemResource.query(params).then(items => this.groupsList = items);
    }
  }





  /**
  * Defines a meaningfull description for row and On mouse over event displays information on tooltip.
  * 
  * @param {Object} item - the current moused over item.
  */
}


