import { Component, OnInit, OnDestroy } from '@angular/core';
import { BreadcrumbService } from './../../../../services/common/breadcrumb.service';
import { DataTableResource } from './../../data-table/index';
import { UserManagementService } from './../../../../services/usermanagement.service';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, FormControl } from '@angular/forms';
import { AnonymousSubscription } from "rxjs/Subscription";
import { I18nService } from '../../../../services/common/i18n/i18n.service';
import { RolesService } from '../../../../services/common/roles/roles.service';

//import { NgxPermissionsService } from 'ngx-permissions';
declare var $: any;
declare var bootbox: any;
declare var jQuery: any;

@Component({
  selector: 'app-manageuser',
  templateUrl: './manageuser.component.html',
  styleUrls: ['./manageuser.component.css']
})
export class ManageuserComponent implements OnInit, OnDestroy {
  itemUsersResource: any;
  form: FormGroup;
  limit: number;
  pagination: boolean = false;
  usersList: any = [];
  selectedUsersList: any = [];
  itemResource: any;
  itemCount = 0;
  selectCount = 0;
  show: boolean = false;
  show1: boolean = false;
  userId: string;
  displayErrors: any = [];
  successMessage: any = [];
  searchUserSubsc: AnonymousSubscription;
  deleteUserSubsc: AnonymousSubscription;
  listofUsers: AnonymousSubscription;
  aclList: any;
  groupList: any;
  selectplaceholder: "Select";
  canClearSelect : boolean = true;
  constructor(
    private _breadcrumbService: BreadcrumbService,
    private _formBuilder: FormBuilder,
    private _userManagementService: UserManagementService,
    private _I18nService: I18nService,
    private _rolesService: RolesService) { }

  ngOnInit() {
    this._breadcrumbService.getBreadCrumbDetails("manage-users");
    this.createForm();
    this.getUserList();
    this.displayErrors= [];
    this.successMessage= [];
    let successMsg = sessionStorage.getItem("msg");
    if(successMsg!=null){
      this.successMessage.push(successMsg);
    }
    sessionStorage.removeItem("msg");
  }
// create form for advanced search.
  createForm() {
    this.form = this._formBuilder.group({
      userName: '',
      lastName: '',
      firstName: '',
      userGroupId: '',
      userACLId :'',
      emailId : '',
      phoneNumber : ''
    });
  }
  // To get all the users.
  getUserList() {
    this.show = false;
    this.show1 = false;
    this.listofUsers = this._userManagementService.getUsersList().subscribe(
      res => {
        console.log(res);
        this.usersList = [];
        this.iterateResponse(res);
        this.itemResource = new DataTableResource(this.usersList);
      },
      error => {
        this.onErrorOperation(error);
      },
    )
  }

  // get the usergroup and acl details
  getUserGroupAndACLDetails(){
    this._userManagementService.getdropdownList().subscribe(
      res => {
       if(res){
         let options = [];
         let options1 = [];
         $.each(res.listUserACLDetailsModel, function (key, obj) {
           options.push(setOption(obj.id, obj.aclName));
         });
         this.aclList = options;
         $.each(res.listUserGroupModel, function (key, obj) {
           options1.push(setOption(obj.id, obj.roleName));
         });
         this.groupList = options1;
       }
      },
      error => {
        this.onErrorOperation(error);
      },

    )
  }
  // This is method is to iterate the list of users and to display in data table.
  iterateResponse(res): void {
    let username = '';
    let firstname = String;
    let lastname = String;
    let aclName = '';
    let emailId = String;
    let userGroup = '';
    let phonenumber = String;
    let status = String;

    res.forEach(element => {
      if (element.userName) {
        username = element.userName;
      }

      if (element.firstName) {
        firstname = element.firstName;
      }
      if (element.lastName) {
        lastname = element.lastName;
      }

      if (element.objUserACLDetailsModel != null) {
        if (element.objUserACLDetailsModel.aclName != null) {
          aclName = element.objUserACLDetailsModel.aclName;
        } else {
          aclName = '';
        }
      } else {
        aclName = '';
      }
      if (element.emailId) {
        emailId = element.emailId;
      }
      if (element.objUserGroupModel != null) {
        if (element.objUserGroupModel.roleName != null) {
          userGroup = element.objUserGroupModel.roleName
        } else {
          userGroup = '';
        }
      } else {
        userGroup = '';
      }
      if (element.phoneNumber) {
        phonenumber = element.phoneNumber;
      }
      if (element.status) {
        status = element.status
      }
      let row = {
        "username": username,
        "firstname": firstname,
        "lastname": lastname,
        "aclName": aclName,
        "emailId": emailId,
        "userGroup": userGroup,
        "phonenumber": phonenumber,
        "status": status
      }
      this.usersList.push(row);
    });
  }
  /**
  * Reloads the grid with paged data based on the offset and limit sent.
  * 
  * @param {Object} params - The params contains the offset and limit to display.
  */


  reloadItems(params) {
    if (this.itemResource) {
      this.itemResource.query(params).then(items => this.usersList = items);
    }
  }

  // To select or unselect the list of users.
  checkedItems(event, value) {
    if (event.checked) {
      if (this.selectCount == 0) {
        this.selectCount = 1;
        this.show = true;
        this.show1 = false;
      } else if (this.selectCount > 0) {
        this.selectCount++;
        this.show1 = true;
        this.show = false;
      }
      this.selectedUsersList.push(value);
    } else {
      this.selectCount--;
      if (this.selectCount == 0) {
        this.show = false;
        this.show1 = false;
      } else if (this.selectCount == 1) {
        this.show = true;
        this.show1 = false;
      }
      let index = this.selectedUsersList.indexOf(value);
      this.selectedUsersList.splice(index);
    }
    this._userManagementService.setuserId(this.selectedUsersList);
  }

  // delete user operation function.
  bootboxMessage() {
    let message = "Do you want to delete the selected user(s)";
    bootbox.dialog({
      message: message,
      buttons: {
        cancel: {
          label: "Cancel",
          className: 'btn btn-secondary btn-flat'
        },
        ok: {
          label: "Ok",
          className: 'btn btn-primary btn-flat',
          callback: () => this.deleteUserDetailsByUserId()
        }
      }
    });
  }
  // delete callback function 
  deleteUserDetailsByUserId() {
    let userId = this._userManagementService.getuserId();
    this.deleteUserSubsc = this._userManagementService.deleteUser(userId).subscribe(
      data => {
        this.show= false;
        this.show1 = false;
        this.selectCount =0;
        this.onSuccessOrErrorOperation(data);
        this.getUserList();
      },
      err => this.onErrorOperation(err)
    )
  }

  // To display success or error messages on page.
  onSuccessOrErrorOperation(res) {
    this.successMessage = [];
    this.displayErrors =[];
    let responseBody = res.json();
    responseBody.forEach(response => {
      if (response.responseCode == "200") {
        this.successMessage.push(response.responseMessage);
      } else if (response.responseCode == "-230") {
        this.displayErrors.push(response.responseMessage);
      } else if(response.responseCode== "204"){
        this.displayErrors.push(response.responseMessage);
      }
    });
  }

  // To display error messages on page
  onErrorOperation(error) {
    console.log('OnError' + JSON.stringify(error));
    this.displayErrors = this._I18nService.getI18NMessagesForError(error, "", "");
    console.log('errorMessages -->' + JSON.stringify(this.displayErrors));
  }

  // basic search operation
  searchUsers(id) {
    let params = {}
    params["userName"]=id.value;
    this.getSearchResults(params);
  }
// show search modal
  showAdvancedSearch(){
    $("#searchModel").modal("show");
    this.getUserGroupAndACLDetails();
    this.form.reset();
  }

  // advance search operation
  advanceSearchUsers() {
    this.getSearchResults(this.form.value);
    $("#searchModel").modal("hide");
  }

// get the search results
  getSearchResults(userDetailsModel) {
    this.searchUserSubsc = this._userManagementService.searchUsers(userDetailsModel).subscribe(
      response => {
        this.usersList = [];
        if (response != null) {
          this.iterateResponse(response);
          this.itemResource = new DataTableResource(this.usersList);
        }
      },
      error => {
        this.onErrorOperation(error);
      }
    )
  }


  // destroy method 
  public ngOnDestroy(): void {
    if (this.searchUserSubsc) {
      this.searchUserSubsc.unsubscribe();
    }
    if (this.listofUsers) {
      this.listofUsers.unsubscribe();
    }
    if (this.deleteUserSubsc) {
      this.deleteUserSubsc.unsubscribe();
    }
  }

  closeMessage(){
    this.displayErrors = [];
    this.successMessage = [];
  }
  /**
  * Defines a meaningfull description for row and On mouse over event displays information on tooltip.
  * 
  * @param {Object} item - the current moused over item.
  */
}
export function setOption(value, label) {
  let option = new Option();
  option.value = value;
  option.label = label;
  return option;
} 

