import { Component, OnInit, OnDestroy } from '@angular/core';
import { BreadcrumbService } from './../../../../services/common/breadcrumb.service';
import { UserManagementService } from './../../../../services/usermanagement.service';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule, FormGroup, FormControl } from '@angular/forms';
declare var $: any;
import { Observable } from 'rxjs/Observable';
import { AnonymousSubscription } from "rxjs/Subscription";
import { Router } from '@angular/router';
import { I18nService } from '../../../../services/common/i18n/i18n.service';
import { FieldErrorDisplayService } from './../../../../services/common/field-error-display.service';
@Component({

  selector: 'app-modifyuser',
  templateUrl: './modifyuser.component.html',
  styleUrls: ['./modifyuser.component.css']
})
export class ModifyuserComponent implements OnInit, OnDestroy {

  form: FormGroup;
  list : any = [];
  successMsg: string;
  aclList: any = [];
  groupList: any = [];
  modifyusersubsc: AnonymousSubscription;
  displayErrors: any = [];
  successMessage: any = [];
  public selectplaceholder = "Select the Options";
  canClearSelect: boolean = true;

  constructor(private _breadcrumbService: BreadcrumbService,
    private _userManagementService: UserManagementService,
    private _formBuilder: FormBuilder,
    private _I18nService: I18nService,
    private _fieldErrorDisplayService: FieldErrorDisplayService,
    private router: Router) { }

  ngOnInit() {
    this._breadcrumbService.getBreadCrumbDetails("modify-users");
    this.modifyForm();
    this.list.push("ACTIVE");
    this.list.push("SUSPENDED");
    let userId = this._userManagementService.getuserId();
    this.getUserDetailsByUserId(userId[0]);
  }

  modifyForm() {
    this.form = this._formBuilder.group({
      userName: ['', Validators.required],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      emailId: ['', Validators.required],
      phoneNumber: ['', Validators.required],
      userGroupId: [null,Validators.required],
      userACLId: [null,Validators.required],
      status: [''],
      temporaryPassword: "N",
      message: ''
    });
  }

  public formValidationFields = {
    "userName": '',
     "firstName": '',
    "lastName": '',
    "emailId": '',
    "phoneNumber": '',
    "userGroupId": '',
    "userACLId": '',
    "status": '',
    
  }
  isFieldValid(field: string) {
    if (this.form.get(field).touched) {
      this.formValidationFields = this._fieldErrorDisplayService.validateField(this.form, field, this.formValidationFields, "modifyuser")
    }
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  onSubmit(isValid: boolean) {
    if (isValid) {
      let status = this.form.get("status").value;
     
    this.form.patchValue({ status: status });
    this.modifyusersubsc = this._userManagementService.modifyUser(this.form.value).subscribe(
        data => {
          //this.form.controls['status'].setValue("ACTIVE");
          this.onSuccessOperation(data)
        },
        err => this.onErrorOperation(err)
      );
    } else {
      this.formValidationFields = this._fieldErrorDisplayService.validateForm(this.form, this.formValidationFields, "modifyuser", false)
    }
  }
  // To display success or error messages on page.
  onSuccessOperation(response) {
    this.successMessage = [];
    this.displayErrors = [];
    let res = response.json();
    if (res.responseCode == "200") {
      //this.successMessage.push(res.responseMessage);
       sessionStorage.setItem("msg",res.responseMessage);
       this.router.navigateByUrl("/manageuserlist");
    } else if (res.responseCode == "204" || res.responseCode == "409" || res.responseCode == "500") {
      this.displayErrors.push(res.responseMessage);
    } else {
      this.displayErrors.push(res.responseMessage);
    }
  }

  // To display error messages on page
  onErrorOperation(error) {
    console.log('OnError' + JSON.stringify(error));
    this.displayErrors = this._I18nService.getI18NMessagesForError(error, "", "");
    console.log('errorMessages -->' + JSON.stringify(this.displayErrors));
  }

  // reset form.
  reset() {
    this.form.controls['firstName'].reset();
    this.form.controls['lastName'].reset();
    this.form.controls['emailId'].reset();
    this.form.controls['phoneNumber'].reset();
    this.form.controls['userGroupId'].reset();
    this.form.controls['userACLId'].reset();
    this.form.controls['message'].reset();
    this.form.get('status').setValue("ACTIVE");
    
  }


  getUserDetailsByUserId(userId) {
    this._userManagementService.getUserById(userId).subscribe(
      (res) => {
        console.log(res.listUserGroupModel);
        let aclArray = [];
        let groupArray = [];

        // $.each(res.listUserACLDetailsModel, function (key, obj) {
        //   aclArray.push(setOption(obj.id, obj.aclName));
        // });
        this.aclList = res.listUserACLDetailsModel;
        // $.each(res.listUserGroupModel, function (key, obj) {
        //   groupArray.push(setOption(obj.id, obj.roleName));
        // });
        //groupArray.push(setOption("140", "NEWGroup55"));
        this.groupList = res.listUserGroupModel;

        if (res.userDetailModel != null) {
          if (res.userDetailModel.userName != null) {
            this.form.patchValue({ userName: res.userDetailModel.userName });
          }
          if (res.userDetailModel.firstName != null) {
            this.form.patchValue({ firstName: res.userDetailModel.firstName });
          }
        }
        if (res.userDetailModel != null) {
          if (res.userDetailModel.lastName != null) {
            this.form.patchValue({ lastName: res.userDetailModel.lastName });
          }
        }
        if (res.userDetailModel != null) {
          if (res.userDetailModel.emailId != null) {
            this.form.patchValue({ emailId: res.userDetailModel.emailId });
          }
        }
        if (res.userDetailModel != null) {
          if (res.userDetailModel.phoneNumber != null) {
            this.form.patchValue({ phoneNumber: res.userDetailModel.phoneNumber });
          }
        }
        if (res.userDetailModel.objUserGroupModel != null) {
          if (res.userDetailModel.objUserGroupModel.id != null) {

            //this.form.controls['userGroupId'].setValue(setValueToSelect(res.userDetailModel.objUserGroupModel.id)); 
            //this.form.controls['userGroupId1'].setValue("114");
            let value = this.setValueToSelect(res.userDetailModel.objUserGroupModel.id);
            console.log(value);
            //this.form.get('userGroupId').patchValue("140");
            this.form.controls['userGroupId'].setValue(res.userDetailModel.objUserGroupModel.id);
          }else{
            this.form.controls['userGroupId'].setValue("");
          }
        }else{
          
          this.form.controls['userGroupId'].setValue("");
        }
        if (res.userDetailModel.status != null) {
          if (res.userDetailModel.status == "ACTIVE") {
            this.form.controls['status'].setValue("ACTIVE");
          } else if (res.userDetailModel.status == "SUSPENDED") {
            this.form.controls['status'].setValue("SUSPENDED");
          }
        }
        if (res.userDetailModel.objUserACLDetailsModel != null) {
          this.form.controls['userACLId'].setValue(res.userDetailModel.objUserACLDetailsModel.id);
          //this.form.controls['userACLId'].setValue(this.setValueToSelect(res.userDetailModel.objUserACLDetailsModel.id));
        }
        if (res.userDetailModel != null) {
          if (res.userDetailModel.message != null) {
            this.form.controls['message'].setValue(res.userDetailModel.message);
          }
        }

      },
      (err) => {
        this.onErrorOperation(err);
      }
    );
  }

  public ngOnDestroy(): void {
    if (this.modifyusersubsc) {
      this.modifyusersubsc.unsubscribe();
    }
  }
  setValueToSelect(value) {
    let setValue = [];
    setValue.push(value);
    return setValue;
  }
}
export function setOption(value, label) {
  let option = new Option();
  option.value = value;
  option.label = label;
  return option;
}
