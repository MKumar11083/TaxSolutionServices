import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule }  from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpModule } from '@angular/http';
import { HttpClientModule, HttpClient ,HTTP_INTERCEPTORS} from '@angular/common/http';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { AppRoutingModule } from './app-routing.module';
import { InlineEditorModule } from '@qontu/ngx-inline-editor';
import { ChartsModule } from 'ng2-charts';
import { NgxPermissionsModule } from 'ngx-permissions';
import { NgxGaugeModule } from 'ngx-gauge';
import {MatButtonModule, MatCheckboxModule,MatTooltipModule} from '@angular/material';

import { AppComponent } from './app.component';
import { DataTableModule } from './components/secure/data-table/index';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
import { MomentModule } from 'angular2-moment';

//custom pipes
import { NotAvailStrPipe } from './pipes/not-avail-str.pipe';
import { JodaTimeFormatPipe } from './pipes/joda-time-format.pipe';
import { DateTimeFormatPipe } from './pipes/date-time-format.pipe';
import { DateFormatPipe } from './pipes/date-format.pipe';
import { MapToIterable } from './pipes/map-to-Iterable';
import { FormatNumberPipe } from './pipes/format-number.pipe';


import { LoginComponent } from './components/public/login/login.component';
import { PublicComponent } from './layout/public/public.component';
import { SecureComponent } from './layout/secure/secure.component';
import{CreateUserComponent} from './components/secure/usermanagement/create-user/create-user.component';
//common
import { AuthGuard } from './../auth/auth.guard';
import { HomeComponent } from './components/secure/home/home.component';
import { Configuration } from './app.constants';
import { FileUploadComponent } from './components/secure/file-upload/file-upload.component'


//services
import { BreadcrumbComponent } from './components/secure/common/breadcrumb/breadcrumb.component';
import { BreadcrumbService } from './services/common/breadcrumb.service';
import { FieldErrorDisplayComponentComponent } from './components/secure/common/field-error-display-component/field-error-display-component.component';
import { BsDatepickerModule,TimepickerModule } from 'ngx-bootstrap';
import { FieldErrorDisplayService } from './services/common/field-error-display.service';
import { LeftmenuService } from './services/common/leftmenu.service';
import { ResourceManagmentValidator } from './validators/resourcemanagment-validator';
import {  SelectModule} from './components/secure/angular2-select';
import { I18nService } from './services/common/i18n/i18n.service';
import { LoaderSpinnerComponent } from './components/secure/common/loader-spinner/loader-spinner.component';
import { RolesService } from './services/common/roles/roles.service';
import { FontResizePipe } from './pipes/font-resize.pipe';
import { FileService } from './services/common/fileupload.service';
import { DateFormat2Pipe } from './pipes/date-format2.pipe';
import { ManageuserComponent } from './components/secure/usermanagement/manageuser/manageuser.component';
import { AppHeaderComponent } from './layout/secure/app-header/app-header.component';
import { AppFooterComponent } from './layout/secure/app-footer/app-footer.component';
import { AppLeftmenuComponent } from './layout/secure/app-leftmenu/app-leftmenu.component';
import { UserManagementService} from './services/usermanagement.service';
import { HttpServices} from './services/common/http.services';
import {UserGroupManagementService} from './services/common/user-group-management.service';
import { ManagegroupComponent } from './components/secure/usermanagement/managegroup/managegroup.component';
import { CreategroupComponent } from './components/secure/usermanagement/creategroup/creategroup.component';
import { ModifyuserComponent } from './components/secure/usermanagement/modifyuser/modifyuser.component';
import { ManageAclComponent } from './components/secure/usermanagement/manage-acl/manage-acl.component';
import { CreateAclComponent } from './components/secure/usermanagement/create-acl/create-acl.component';
import { ModifygroupComponent} from './components/secure/usermanagement/modifygroup/modifygroup.component';
import { LoginService} from './../app/services/login.service';
import { ListApplianceComponent } from './components/secure/appliancemanagement/list-appliance/list-appliance.component';
import { AddApplianceComponent } from './components/secure/appliancemanagement/add-appliance/add-appliance.component';
import { AddByDiscoveryComponent } from './components/secure/appliancemanagement/add-by-discovery/add-by-discovery.component';
import { SnapshotComponent } from './components/secure/appliancemanagement/snapshot/snapshot.component';
import { AppliancemanagementService} from './services/appliancemanagement.service';
import { AddApplianceService} from './services/addAppliance.service';
import { CompareAppliancesComponent} from './components/secure/appliancemanagement/compare-appliances/compare-appliances.component';
import { HostVmComponent } from './components/secure/appliancemanagement/host-vm/host-vm.component';

// import { DoughnutChartComponent, PieChartComponent, BarChartComponent } from 'angular-d3-charts';

export function HttpLoaderFactory(http: HttpClient) {
  //return new TranslateHttpLoader(http, '/dist/assets/i18n/', '.json');
  return new TranslateHttpLoader(http);
}

@NgModule({
  declarations: [
    AppComponent,
    NotAvailStrPipe,
    LoginComponent,
    PublicComponent,
    SecureComponent,
    HomeComponent,
    BreadcrumbComponent,
    FieldErrorDisplayComponentComponent,
    ResourceManagmentValidator,
    DateTimeFormatPipe,
    FileUploadComponent,
    LoaderSpinnerComponent,
    JodaTimeFormatPipe,
    DateFormatPipe,
    MapToIterable,
    FormatNumberPipe,
    FontResizePipe,
    DateFormat2Pipe,
    ManageuserComponent,
    AppHeaderComponent,
    AppFooterComponent,
    AppLeftmenuComponent,
    CreateUserComponent,
    ManagegroupComponent,
    CreategroupComponent,
    ModifyuserComponent,
    ManageAclComponent,
    CreateAclComponent,ModifygroupComponent,
    ListApplianceComponent,
    AddApplianceComponent,
    AddByDiscoveryComponent,
    SnapshotComponent,
    CompareAppliancesComponent,
    HostVmComponent

  ],
  imports: [
    BrowserModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    HttpClientModule,
    ChartsModule,
    NgxGaugeModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    }),
    AppRoutingModule,
    DataTableModule,
    SelectModule,	
    InlineEditorModule,
    BsDatepickerModule.forRoot(),
    TimepickerModule.forRoot(),
    NgxPermissionsModule.forRoot(),
    MatButtonModule, MatCheckboxModule,MatTooltipModule,
    MomentModule,
    NgIdleKeepaliveModule.forRoot()
  ],
  providers: [ Configuration, AuthGuard,
			  BreadcrumbService,
			  FieldErrorDisplayService,
			  LeftmenuService,
        I18nService, 
        LoginService,
        RolesService, FileUploadComponent, FileService,UserManagementService,
        HttpServices,UserGroupManagementService,AppliancemanagementService,AddApplianceService,
        
  ],
  bootstrap: [AppComponent],
  exports: [MatButtonModule, MatCheckboxModule,MatTooltipModule],
})
export class AppModule { }
