//Common jquery functions

$.fn.clearForm = function() {
	$(".errors").removeClass('alert');
	$(".errors").removeClass('alert-danger');
	$(".errors").html('');
  return this.each(function() {
    var type = this.type, tag = this.tagName.toLowerCase();
    if(this.disabled==true)
		return;
    
    if (tag == 'form')
      return $(':input',this).clearForm();
    if (type == 'text' || type == 'password' || tag == 'textarea')
    	{
    		this.value = '';
    	}
    else if (type == 'checkbox' || type == 'radio'){
    	this.checked = false;
    	if($(this).hasClass("switch-checkbox")){
    		$(this).bootstrapSwitch('destroy');
    		$(this).bootstrapSwitch();
    		if($(this).is('#autoPasswordFlag')){
    			autoPwdGeneration();
    		}
    	}
    }else if(type == 'select-multiple'){
        $(this).multiselect();
    }
    else if (tag == 'select'){
      this.selectedIndex = 0;
      $(this).select2();
    //  $(this).trigger("liszt:updated")
    }else if (type=='file'){
    	$(":file").filestyle('clear');
    }
  });
};

$(function(){
	var exportEle = $("#exportTypes").clone();
	var tableEle = $("#exportTypes").prev();
	$("#exportTypes").remove();
	$(exportEle).insertBefore($(tableEle));
	/*if(!$("#exportTypes").prev().hasClass("rightAlign")){
		$("#exportTypes").css("float","left");
		$($("#exportTypes").prev()).remove();		
		$($("#exportTypes").prev()).css({"display":"inline-block", "padding-left": "760px"});
	}*/
});


function submitGlobalForm(formId){
	 var mainObj=$("#search-type-select").val();
	 document.forms[formId].action = mainObj;
	 document.forms[formId].submit();	
}
function clearSesion(){
	sessionStorage.removeItem("sessionId");
	sessionStorage.removeItem("navigateSimDetailsPage");
	sessionStorage.removeItem("treeViewName");
	sessionStorage.clear();
}
$(document).ready(function(){
	$(window).scroll(function () {
      if ($(this).scrollTop() > 50) {
          $('#toTop').fadeIn();
      } else {
          $('#toTop').fadeOut();
      }
  });
  // scroll body to 0px on click
  $('#toTop').click(function () {
      $('#toTop').tooltip('hide');
      $('body,html').animate({
          scrollTop: 0
      }, 1200);
      return false;
  });
})

