$(document).ready(function(){
	
	$(".breadcrumb li:last").after('<span class="timestamp-display"></span>');
	//$("#search-elements").hide();
	/*$( ".search-expand" ).click(function() {
		$( "#search-elements" ).slideToggle( "slow" );
	});*/
	//new changes added by mahi start
	/*sessionStorage.setItem("sessionId", "dashboard");
	  $('.main-menu li a').click(function(){
		sessionStorage.setItem("sessionId", $(this).parent('li').attr("id"));
	});*/
	  
	var leftsidebar = sessionStorage.getItem("leftsidebar");
	if(leftsidebar!=null && leftsidebar!=undefined && leftsidebar=='minified'){
		$('.left-sidebar').addClass('minified');
		$('.content-wrapper').addClass('expanded');
	}if(leftsidebar!=null && leftsidebar!=undefined && leftsidebar=='expanded'){
		$('.left-sidebar').removeClass('minified');
		$('.content-wrapper').removeClass('expanded');
	}
	//end

	/************************
	/*	LAYOUT
	/************************/

	// set minimum height for content wrapper
	$(window).bind("load resize scroll", function () {
		calculateContentMinHeight();
	});

	function calculateContentMinHeight() {
		$('#main-content-wrapper').css('min-height', $('#left-sidebar').height());
	}


	/************************
	/*	MAIN NAVIGATION
	/************************/

	$('.main-menu .js-sub-menu-toggle').on('click', function(e){
		var clickedMenuId=$(this).attr('id');
		e.preventDefault();
		//new changes as per requirement added by mahi
		  $('.main-menu').find('li').each(function(){
			  var currId=$(this).find('a').attr('id');
			 if($(this).hasClass('active') && clickedMenuId != currId){
				 $(this).removeClass('active');
			 }
			 if($(this).find(' > a .toggle-icon').hasClass('fa-angle-up') && clickedMenuId != currId){
				 $(this).find(' > a .toggle-icon').removeClass('fa-angle-up').addClass('fa-angle-down')
			 }
			 if($(this).find('ul').hasClass('sub-menu')){
				 if($(this).find('ul').css('display') == 'block'){
					 $(this).find('ul').css('display', 'none')
					 $(this).find('ul').removeAttr("style");
				 }
				 $(this).find('ul').removeClass("open");
			 }
		 }); 
		//end  
		$li = $(this).parent('li');
		if( !$li.hasClass('active')){
			$li.find(' > a .toggle-icon').removeClass('fa-angle-down').addClass('fa-angle-up');
			$li.addClass('active');
			$li.find('ul.sub-menu').slideDown(300);
			//new changes as per requirement added by mahi
			var leftsidebar = sessionStorage.getItem("leftsidebar");
			if(leftsidebar!=null && leftsidebar!=undefined && leftsidebar=='expanded'){
				$li.find('ul.sub-menu').addClass('open');
			}
			//end
		}
		else {
			$li.find(' > a .toggle-icon').removeClass('fa-angle-up').addClass('fa-angle-down');
			$li.removeClass('active');
			$li.find('ul.sub-menu')
				.slideUp(300);
		}
	});

	// checking for minified left sidebar
	checkMinified();

	$('.js-toggle-minified').on('click', function() {
		if(!$('.left-sidebar').hasClass('minified')) {
			$('.left-sidebar').addClass('minified');
			$('.content-wrapper').addClass('expanded');
			sessionStorage.setItem('leftsidebar', 'minified');
		} else {
			$('.left-sidebar').removeClass('minified');
			$('.content-wrapper').removeClass('expanded');
			sessionStorage.setItem('leftsidebar', 'expanded');
		}
		
		checkMinified();
	});

	function checkMinified() {
		if(!$('.left-sidebar').hasClass('minified')) {
			setTimeout( function() {

				$('.left-sidebar .sub-menu.open')
				.css('display', 'block')
				.css('overflow', 'visible')
				.siblings('.js-sub-menu-toggle').find('.toggle-icon').removeClass('fa-angle-down').addClass('fa-angle-up');
			}, 200);

			$('.main-menu > li > a > .text').animate({
				opacity: 1
			}, 1000);

		} else {
			$('.left-sidebar .sub-menu.open')
			.css('display', 'none')
			.css('overflow', 'hidden');

			$('.main-menu > li > a > .text').animate({
					opacity: 0
			}, 200);
		}
	}

	$('.toggle-sidebar-collapse').on('click', function() {
		if( $(window).width() < 992) {
			// use float sidebar
			if(!$('.left-sidebar').hasClass('sidebar-float-active')) {
				$('.left-sidebar').addClass('sidebar-float-active');
			} else {
				$('.left-sidebar').removeClass('sidebar-float-active');
			}
		} else {
			// use collapsed sidebar
			if(!$('.left-sidebar').hasClass('sidebar-hide-left')) {
				$('.left-sidebar').addClass('sidebar-hide-left');
				$('.content-wrapper').addClass('expanded-full');
			} else {
				$('.left-sidebar').removeClass('sidebar-hide-left');
				$('.content-wrapper').removeClass('expanded-full');
			}
		}
	});

	$(window).bind("load resize", determineSidebar);

	function determineSidebar() {

		if( $(window).width() < 992) {
			$('body').addClass('sidebar-float');

		}else {
			$('body').removeClass('sidebar-float');
		}
	}

	// main responsive nav toggle
	$('.main-nav-toggle').clickToggle(
		function() {
			$('.left-sidebar').slideDown(300)
		},
		function() {
			$('.left-sidebar').slideUp(300);
		}
	);

	// slimscroll left navigation
	if( $('body.sidebar-fixed').length > 0 ) {
		$('body.sidebar-fixed .sidebar-scroll').slimScroll({
			height: '100%',
			wheelStep: 5,
		});
	}


	//*******************************************
	/*	LIVE SEARCH
	/********************************************/

	$mainContentCopy = $('.main-content').clone();
	$('.searchbox input[type="search"]').keydown( function(e) {
		var $this = $(this);
		
		setTimeout(function() {
			var query = $this.val();
			
			if( query.length > 2 ) {
				var regex = new RegExp(query, "i");
				var filteredWidget = [];

				$('.widget-header h3').each( function(index, el){
					var matches = $(this).text().match(regex);

					if( matches != "" && matches != null ) {
						filteredWidget.push( $(this).parents('.widget') );
					}
				});

				if( filteredWidget.length > 0 ) {
					$('.main-content .widget').hide();
					$.each( filteredWidget, function(key, widget) {
						widget.show();
					});
				}else{
					console.log('widget not found');
				}
			}else {
				$('.main-content .widget').show();
			}
		}, 0);
	});

	// widget remove
	$('.widget .btn-remove').click(function(e){

		e.preventDefault();
		$(this).parents('.widget').fadeOut(300, function(){
			$(this).remove();
		});
	});
	/*if value present in advanced search any input value than start by mahi*/
	var valueExist=false;
	$('#search-elements :input').each(function(){ 
		//$.isNumeric(
		var value=$(this).val();
		if($(this).hasClass('form-control')){
			if($.isNumeric(value) && value!='0'){
				valueExist=true;
			}else if(value!='0' && value != ""){
				valueExist=true;
			}
		}
	});
	$('#search-elements').find('select').each(function() {
		var value=$(this).val();
		if($(this).hasClass('select2')){
			if($.isNumeric(value) && value!='0'){
				valueExist=true;
			}else if(value!='0' && value != ""){
				valueExist=true;
			}
		}
	});
	if(valueExist){
		$('#search-elements').show();
	}else{
		$('#search-elements').hide();
		$('.btn-toggle-expand').find('i.fa-chevron-up').toggleClass('fa-chevron-down');
	}
	/*end */
	// widget toggle expand
	var affectedElement = $('.widget-content');
	$('.widget .btn-toggle-expand').clickToggle(
		function(e) {
			e.preventDefault();

			// if has scroll
			if( $(this).parents('.widget').find('.slimScrollDiv').length > 0 ) {
				affectedElement = $('.slimScrollDiv');
			}
			//$(this).parents('.widget').find(affectedElement).slideUp(300);
			//changed newly as per requirement by mahi
			if($(this).children("i").hasClass("fa-chevron-up") && valueExist){
				$(this).parents('.widget').find(affectedElement).slideUp(300);
			}else{
				//by default slide down
				$(this).parents('.widget').find(affectedElement).slideDown(300);
			}
			$(this).find('i.fa-chevron-up').toggleClass('fa-chevron-down');
		},
		function(e) {
			e.preventDefault();

			// if has scroll
			if( $(this).parents('.widget').find('.slimScrollDiv').length > 0 ) {
				affectedElement = $('.slimScrollDiv');
			}
			//$(this).parents('.widget').find(affectedElement).slideDown(300);
			//changed newly as per requirement by mahi
			if($(this).children("i").hasClass("fa-chevron-down") && valueExist){
				$(this).parents('.widget').find(affectedElement).slideDown(300);
			}else{
				//by default slide up
				$(this).parents('.widget').find(affectedElement).slideUp(300);
			}
			$(this).find('i.fa-chevron-up').toggleClass('fa-chevron-down');
		}
	);

	// widget focus
	$('.widget .btn-focus').clickToggle(
		function(e) {
			e.preventDefault();
			$(this).find('i.fa-eye').toggleClass('fa-eye-slash');
			$(this).parents('.widget').find('.btn-remove').addClass('link-disabled');
			$(this).parents('.widget').addClass('widget-focus-enabled');
			$('body').addClass('focus-mode');
			$('<div id="focus-overlay"></div>').hide().appendTo('body').fadeIn(300);

		},
		function(e) {
			e.preventDefault();
			$theWidget = $(this).parents('.widget');
			
			$(this).find('i.fa-eye').toggleClass('fa-eye-slash');
			$theWidget.find('.btn-remove').removeClass('link-disabled');
			$('body').removeClass('focus-mode');
			$('body').find('#focus-overlay').fadeOut(function(){
				$(this).remove();
				$theWidget.removeClass('widget-focus-enabled');
			});
		}
	);

	/************************
	/*	BOOTSTRAP TOOLTIP
	/************************/

	$('body').tooltip({
		selector: "[data-toggle=tooltip]",
		container: "body"
	});


	/************************
	/*	BOOTSTRAP ALERT
	/************************/

	$('.alert .close').click( function(e){
		e.preventDefault();
		$(this).parents('.alert').fadeOut(300);
	});


	//*******************************************
	/*	TEXTAREA
	/********************************************/

	$('.textarea-msg span').html($('.textarea-with-counter').attr('maxlength') + ' characters remaining');

	$('.textarea-with-counter').keyup(function() {
		var textMax = $(this).attr('maxlength');
		var textLength = $(this).val().length;
		var textRemaining = textMax - textLength;
		$(this).next().find('span').html(textRemaining + ' characters remaining');
	});
});

// toggle function
$.fn.clickToggle = function( f1, f2 ) {
	return this.each( function() {
		var clicked = false;
		$(this).bind('click', function() {
			if(clicked) {
				clicked = false;
				return f2.apply(this, arguments);
			}

			clicked = true;
			return f1.apply(this, arguments);
		});
	});

}

// var $select = $('.select2').select2({
//     //placeholder: 'Choose',
//     allowClear: true
// });
/*
 * When you change the value the select via select2, it triggers
 * a 'change' event, but the jquery validation plugin
 * only re-validates on 'blur'
 */
// $select.on('change', function() {
//   $(this).trigger('blur');
// });

if ($('#exportTypes').length) {
	$('#exportTypes').children('a').attr('target', '_blank');
}


//*******************************************
/*	WIDGET SLIM SCROLL
/********************************************/

if( $('.widget-scrolling').length > 0) {
	$('.widget-scrolling .widget-content').slimScroll({
		height: '325px',
		wheelStep: 5,
	});
}
if( $('.widget-scrolling-grp').length > 0) {
	$('.widget-scrolling-grp .widget-content').slimScroll({
		height: '370px',
		wheelStep: 5,
	});
}