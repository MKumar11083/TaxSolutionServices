var isActive=false;
var url = window.location.pathname, 
urlRegExp = new RegExp(url.replace(/\/$/,'') + "$");
$('.main-menu li.active').removeClass('active');
// now grab every link from the navigation
 var globalUrl = url.split('/');
 var globalJoin=globalUrl[1]+"/"+globalUrl[2];
 var isGlobalActive=false;
 var removeActiveObj;
$('li ul li a').each(function(){
	var currentUrl = $(this).attr('href').split('/');
    var currentJoin=currentUrl[1]+"/"+currentUrl[2];
    // and test its normalized href against the url pathname regexp
    if($(this).attr('href')==url){
//    if(urlRegExp.test(this.href.replace(/\/$/,''))){
       /*  $(this).addClass('active'); */
        $(this).parent('li').addClass('active');
        $(this).parent('li').parent('ul').addClass('open');
        $(this).parent('li').parent('ul').parent('li').addClass('active');
        isActive=true;
    }else if(globalJoin==currentJoin && !isGlobalActive && !isActive){
    	$(this).parent('li').parent('ul').addClass('open');
        $(this).parent('li').parent('ul').parent('li').addClass('active');
        isGlobalActive=true;
        removeActiveObj=this;
    }
});
if(isGlobalActive && (isActive==false || isActive==true)){
	$(removeActiveObj).parent('li').parent('ul').removeClass('open');
	$(removeActiveObj).parent('li').parent('ul').parent('li').removeClass('active');
	var hrefUrl = sessionStorage.getItem("hrefUrl");
	var singleLi=false;
	$('li a').each(function(){
		var currentUrl = $(this).attr('href');
		if(currentUrl!=undefined && currentUrl==hrefUrl){
			$(this).parent('li').addClass('active');
			$(this).parent('li').parent('ul').addClass('open');
	        $(this).parent('li').parent('ul').parent('li').addClass('active');
			singleLi=true;
		}
	});
}
if(isGlobalActive==false && isActive==false){
	var sessionId = sessionStorage.getItem("sessionId");
	$("#"+sessionId).addClass('active');
}