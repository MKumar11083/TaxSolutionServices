 $(document).ready( function() {
	 	//	$('.commonsearch').hide();
	 		var data=getModuleNames();
			var searchObj=document.getElementById("search-type-select");
			if(searchObj!=undefined){
				$.each(data, function(key,value){
					var   opt = document.createElement("option");
					opt.text= value.key;
					opt.value = value.value;
					
					searchObj.appendChild(opt);
				});
				document.getElementById("search-type-select").value = "/dsp/usermgmt/searchUser.htm";
				$('.multiselect-single-lg').multiselect({
					buttonClass: 'btn btn-default btn-lg',
					templates: {
						li: '<li><a href="javascript:void(0);"><label><i></i></label></a></li>' // mandatory for single selection
					}
				});
				$('#search-type-select').multiselect();
			}
            $("#filterButton").click(function(){
				var module =$("#search-type-select").val();
				var filterDetails=getFilters();
				var getValue= getValues(module,filterDetails);
				var selectDropDown = {};
				var datePickerApply = {};
				var html="";
		        /*form submission code */
		        var count=0;
				$.each(getValue, function(key,value){
					if(count%2!=0 || count==0){
						html=html+"<div class='row'>";
					}
					html=html+"<div class='col-sm-6'>";
					if(value.type=="select2"){
						html=html+"<select id='"+value.name+"' name='"+value.name+"' size='1' class='select2'></select>";
						html=html+"</div>";
						selectDropDown[value.name]=value.name;
					}else if(value.type=="datepicker"){
						 html=html+"<div class='input-group date' id='"+value.name+"'>";
						 html=html+"<input type='"+value.type+"' class='form-control' name='"+value.name+"' readOnly='true' placeholder='"+value.name+"'>";
						 html=html+"<span class='input-group-addon'> <span class='glyphicon glyphicon-calendar date-icon'></span></span></div></div>";
						 datePickerApply[value.name]=value.name;
					}else{
						html=html+"<div class='form-group'><label for='"+value.name+"' class='control-label sr-only'>"+value.name+"</label><div class='input-group'>";
						html=html+"<input type='"+value.type+"' class='form-control' name='"+value.name+"' id='"+value.name+"' placeholder='"+value.name+"'>";
						html=html+"<span class='input-group-addon'><i class='fa fa-search'></i></span></div></div></div>";
					}
			        if(count%2!=0){
			        	html=html+"</div><br/>";
			        }
			        count++;
				})
			    $("#childModal2").html(html);
				if(!$.isEmptyObject(datePickerApply)){
					$.each(datePickerApply, function( key, value ) {
						$('#'+key).datepicker({
							format: 'dd/M/yyyy',
							//  autoclose:true,
							endDate: "today",
							maxDate: 0
						}).on('changeDate', function (ev) {
							$(this).datepicker('hide');
						});
					});
				}
				if(!$.isEmptyObject(selectDropDown)){
					$.each(selectDropDown, function( key, value ) {
						var dynaUrl=getAjaxUrl(key,module);
						var destinationObect=document.getElementById(key);
						createDefaultOptions(destinationObect);
						$.ajax({
							url : dynaUrl,
							type: "GET",
							contentType: "application/json",
							dataType: 'json',
							success : function(data) {
								$.each(data, function(key,value){
									createOptionsInSelect(value,destinationObect);
								});
							},
							error: function(error){
								console.log("MAHI");
							}
						});
						$("#"+key).select2();
					});
				}
			});
        	$('.searchicon').click(function(){
        		$('.commonsearch').show();
        		$('.searchicon').hide();
        	})
        	$('#overlay').bind('click', function(event){
        		$('.commonsearch').hide();
        		$('.searchicon').show();
        	});
 });
 function getValues(module,filterArray) {
 	for ( var key in filterArray) {
 		if(filterArray[key].hasOwnProperty(module)){
 			return filterArray[key][module];
 			}
 		}
 }
//Adding the  module names
 function getModuleNames() {
	 var data = [
		{"key":"Users","value":"/dsp/usermgmt/searchUser.htm"},
		{"key":"Orders","value":"/dsp/ordermgmt/searchOrders.htm"},
		{"key":"SIM Details","value":"/dsp/inventorymgmt/simInventory.htm"}
		
	 ];
	 
	 return data;
 }
 function getFilters() {
	 var allFilter =[];
	 var searchFilter=[{
	      '/dsp/usermgmt/searchUser.htm' :[
											{'name': 'firstName', 'type' : 'text'},
											{'name': 'username', 'type' : 'text'},
											{'name': 'email', 'type' : 'text'},
											{'name': 'groupId', 'type' : 'select2'}
	                                      ],
	            
	      '/dsp/ordermgmt/searchOrders.htm' :[
						                      {'name': 'electricalProfileId', 'type' : 'select2'},
						         	          {'name': 'orderStatus', 'type' : 'select2'},
						         	          {'name': 'fromDate', 'type' : 'datepicker'},
						         	          {'name': 'toDate', 'type' : 'datepicker'},
						         	          {'name': 'groupId', 'type' : 'select2'},
						         	          {'name': 'id', 'type' : 'text'}
					         	             ],
	         	            
	      '/dsp/inventorymgmt/simInventory.htm' :[
	                                              {'name': 'iccid', 'type' : 'text'},
	                                              {'name': 'imsi', 'type' : 'text'},
	                                              {'name': 'provisionStatus', 'type' : 'select2'}
	                                             ]
	 	}]
	 return searchFilter;
}
function getAjaxUrl(ajaxId,module){
	var ajaxUrl={
			'/dsp/usermgmt/searchUser.htm':{
				'groupId':'/dsp/usermgmt/searchUser/groupList.htm'
			},
			'/dsp/ordermgmt/searchOrders.htm':{
				'electricalProfileId' :'/dsp/ordermgmt/searchOrders/electricalProfileList.htm',
				'orderStatus':'/dsp/ordermgmt/searchOrders/orderStatusList.htm',
				'groupId':'/dsp/ordermgmt/searchOrders/groupList.htm'
			},
			 '/dsp/inventorymgmt/simInventory.htm':{
				 'provisionStatus':'/dsp/inventorymgmt/simInventory/simStatusList.htm'
			 }
			
	}
	return ajaxUrl[module][ajaxId];
}
function createOptionsInSelect(value,destinationObject){
	var  opt = document.createElement("option");
	if(destinationObject.id=="groupId"){
		opt.text= value.fullName;
		opt.value = value.groupId;
		destinationObject.appendChild(opt);
	}else if(destinationObject.id=="electricalProfileId"){
		opt.text= value.electricalProfileName;
		opt.value = value.electricalProfileId;
		destinationObject.appendChild(opt);
	}else if(destinationObject.id=="orderStatus"){
		opt.text= value;
		opt.value = value;
		destinationObject.appendChild(opt);
	}else if(destinationObject.id=="provisionStatus"){
		opt.text= value;
		opt.value = value;
		destinationObject.appendChild(opt);
	}
}
function createDefaultOptions(destinationObject){
	var  opt = document.createElement("option");
	if(destinationObject.id=="groupId"){
		opt.text= "Select Group";
		opt.value ="0";
		destinationObject.appendChild(opt);
	}else if(destinationObject.id=="electricalProfileId"){
		opt.text= "Select SIM Type";
		opt.value ="0";
		destinationObject.appendChild(opt);
	}else if(destinationObject.id=="orderStatus"){
		opt.text= "Select Order Status";
		opt.value ="";
		destinationObject.appendChild(opt);
	}else if(destinationObject.id=="provisionStatus"){
		opt.text= "Select SIM Status";
		opt.value ="";
		destinationObject.appendChild(opt);
	}
}
function validate(form){
	var firstName = form.firstName.value;
	var email = form.email.value;
	var username = form.username.value;
	var groupId = form.groupId.value;
	return true;
}