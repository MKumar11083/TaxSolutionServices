/**
 * @license @product.name@ JS v@product.version@ (@product.date@)
 * Module for adding patterns and images as point fills.
 *
 * (c) 2010-2018 Highsoft AS
 * Author: Torstein Hønsi, Øystein Moseng
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/pattern-fill.src.js';
